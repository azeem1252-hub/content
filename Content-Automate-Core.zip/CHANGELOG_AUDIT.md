# Audit & Repair Changelog: Verlytic Studio

All notable changes, bug fixes, database schema updates, and feature implementations completed during this audit.

---

## 1. Database Schema & Persistence (`storage/db.py`)
- **Added `studio_api_keys` Table**:
  - Columns: `id TEXT PRIMARY KEY`, `name TEXT`, `prefix TEXT`, `key_hash TEXT`, `created_at TIMESTAMP`, `last_used_at TIMESTAMP`.
  - Implemented `create_api_key(name)`, `get_api_keys()`, `delete_api_key(key_id)`, and `validate_api_key(raw_token)`.
- **Added `workspace_team_members` Table**:
  - Columns: `id TEXT PRIMARY KEY`, `name TEXT`, `email TEXT`, `role TEXT`, `status TEXT`, `created_at TIMESTAMP`, `last_active TIMESTAMP`, `avatar_color TEXT`.
  - Implemented `get_team_members()`, `add_team_member(name, email, role, avatar_color)`, and `remove_team_member(member_id)`.
- **Added Import `import os`**: Fixed runtime `NameError: name 'os' is not defined` in `storage/db.py`.
- **Added `website_id` Filtering to `get_all_posts()`**: Filter posts cleanly per-site via pipeline run associations.

---

## 2. Backend API Layer (`web/app.py`)
- **Added Developer API Key Routes**:
  - `GET /api/keys`: Returns all registered studio keys with masked prefixes.
  - `POST /api/keys`: Generates a cryptographically random token, stores SHA-256 hash, and returns the full token once.
  - `DELETE /api/keys/{key_id}`: Revokes and removes the key from SQLite.
  - `POST /api/keys/test-webhook`: Pings server loopback and returns true roundtrip latency.
- **Added Workspace Collaboration Routes**:
  - `GET /api/team`: Returns workspace collaborators and reviewers.
  - `POST /api/team`: Adds a new team collaborator.
  - `DELETE /api/team/{member_id}`: Removes collaborator access.
- **Sanitized Search & AI Visibility (`/api/audit/geo-visibility`)**:
  - Removed hardcoded `if "game" in domain_lower:` branches.
  - Wired live query measurement through `ai_visibility.py`, extracted real citations, and persisted snapshots into `ai_visibility_snapshots`.
- **Sanitized AI ROI Analytics (`/api/analytics/ai-roi`)**:
  - Eliminated fabricated `$169,590.96` revenue when sites have zero posts.
  - Honestly returns `data_basis: "no_data"` with `$0.00` value when unmeasured.

---

## 3. Pipeline Adapters & Intelligence (`pipeline/adapters/`)
- **`keyword_intelligence.py`**:
  - Updated `_fallback_site_candidates()` to dynamically extract keyword seeds from actual published posts rather than hardcoded gaming titles.
  - Updated `fetch_competitor_candidates()` to dynamically formulate competitor content gaps based on the website's true niche.
- **`technical_audit.py`**:
  - Standardized return contract to always include `health_score`, `crawl_score`, and `issues`, eliminating UI fallback to hardcoded numbers.
- **`ai_visibility.py`**:
  - Added primary LLM fallbacks (Gemini REST / Groq / Mistral) when specialized search API quotas are exceeded.

---

## 4. Frontend Application Layer (`frontend/`)
- **`frontend/src/lib/api.ts`**:
  - Added client methods: `getApiKeys()`, `createApiKey()`, `deleteApiKey()`, `testWebhookPing()`, `getTeamMembers()`, `addTeamMember()`, and `removeTeamMember()`.
- **`ApiKeysPage.tsx`**:
  - Replaced client-side `Math.random()` simulation with real backend calls to `/api/keys`.
  - Added full token modal display with single-copy guarantee and security advisory.
  - Replaced fake 42ms setTimeout webhook test with real `/api/keys/test-webhook` roundtrip test.
- **`TeamPage.tsx`**:
  - Replaced static mock member array with real `/api/team` data from SQLite.
  - Wired real invite submission and member removal actions.
- **`BillingPage.tsx`**:
  - Removed fake Stripe checkout, fake Visa 4242, and mock invoice PDF downloads.
  - Converted into an honest **License & Operational Resource Monitor** displaying real disk usage, published article counts, connected websites, and active AI inference models.
- **`AuthPage.tsx`**:
  - Removed simulated 500ms `setTimeout` authentication flows.
  - Wired real server health ping with honest local operator session initialization.
- **`AnalyticsPage.tsx`**:
  - Removed all hardcoded static fallback cards across AI ROI, SERP, Technical SEO, Backlinks, and Knowledge Graph tabs.
- **`KeywordsPage.tsx`**:
  - Dynamically passes competitor domains configured on the active website rather than hardcoding gaming domains.

---

## 5. Verification & Testing
- Full pytest test suite passed 100% with 0 errors.
- Frontend compiled with `npm run build` with 0 TypeScript/Vite errors.
- Packaging script re-generated clean zip: `Content-Automate-Core.zip` (~4.18 MB, 341 files).
