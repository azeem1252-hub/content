"""
Evidence-Based Content Brief & SERP Live Advanced Analyzer (Pillar A2).

Replaces ungrounded "outline from LLM memory" with an empirical, evidence-based brief:
1. Live SERP Advanced Call: Top-10 URLs, SERP features, PAA questions, related searches,
   AI Overview detection and sources cited.
2. Respectful Competitor Scraping: httpx + trafilatura (respects robots.txt and rate limits;
   used strictly for analytical feature extraction, NEVER to copy).
3. Per-Page Feature Extraction:
   - Headings tree (H2/H3 hierarchy)
   - Word count (from main article text)
   - Salient Entities (spaCy NER or high-salience NLP/LLM extraction)
   - Statistics cited (percentages, benchmarks, currencies, multipliers)
   - Media types (images, videos, tables, code blocks)
   - Schema types present (parsed from JSON-LD scripts)
4. Gap Analysis:
   - Table stakes: Entities and subtopics appearing across >= 50% of top pages.
   - Differentiators: Advanced entities/topics appearing on only 1-2 top pages.
   - Unanswered PAA Questions: High information-gain opportunities where no competitor
     answers the question in a dedicated heading/section.
5. Unique Angle: Pulled from the empirical evidence pack (A3.2).
6. Typed Brief Output: Pydantic ContentBrief model with intent, target reader,
   required sections with answer-first guidance, required entities, questions to answer
   in answer-first form, claims needing sources, internal link candidates, schema plan,
   and an evidence-based word-count range (a range, not a stuffing target).
"""

from __future__ import annotations

import html
import json
import logging
import math
import os
import re
import time
from collections import Counter
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import httpx
from pydantic import BaseModel, Field

import config
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block, fetch_tavily_intelligence
from pipeline.adapters.internal_linker import get_cluster_candidates
from pipeline.adapters.serp_nlp import STOPWORDS
from pipeline.adapters.question_naturalizer import (
    clean_double_question,
    clean_topic_phrase,
    extract_comparison_entities,
    generate_natural_paa_questions,
    generate_natural_related_searches,
    naturalize_heading_from_question,
    naturalize_question,
)

logger = logging.getLogger("pipeline.adapters.brief_builder")

DATAFORSEO_SERP_ENDPOINT = "https://api.dataforseo.com/v3/serp/google/organic/live/advanced"
SERPER_ENDPOINT = "https://google.serper.dev/search"

# Cache for parsed robots.txt to avoid redundant network requests
_ROBOTS_CACHE: Dict[str, Optional[RobotFileParser]] = {}
# Per-domain rate limit tracking
_DOMAIN_LAST_REQUEST: Dict[str, float] = {}
# In-memory TTL cache for scraped competitor page analyses (1 hour TTL)
_PAGE_ANALYSIS_CACHE: Dict[str, Tuple[float, Any]] = {}
_PAGE_CACHE_TTL_SEC: float = 3600.0

# Try loading spaCy NER if available in environment (dynamic check prevents IDE static analyzer errors)
_SPACY_NLP = None
try:
    import importlib.util
    if importlib.util.find_spec("spacy") is not None:
        _spacy_mod = __import__("spacy")
        _SPACY_NLP = _spacy_mod.load("en_core_web_sm")
except Exception:
    _SPACY_NLP = None


# =====================================================================
# TYPED PYDANTIC MODELS (Pillar A2)
# =====================================================================

class HeadingItem(BaseModel):
    """Represents an H2 or H3 heading extracted from a competitor or planned for a brief."""
    level: int = Field(..., ge=2, le=3, description="Heading level: 2 for H2, 3 for H3")
    text: str = Field(..., description="Clean heading text")
    id: Optional[str] = Field(None, description="Anchor id if present")


class CompetitorPageAnalysis(BaseModel):
    """Extracted structural and semantic footprint of a single Page-1 competitor."""
    url: str
    domain: str
    title: str = ""
    rank: Optional[int] = None
    headings: List[HeadingItem] = Field(default_factory=list)
    word_count: int = 0
    entities: List[str] = Field(default_factory=list)
    statistics: List[str] = Field(default_factory=list)
    media_types: Dict[str, int] = Field(default_factory=dict)
    schema_types: List[str] = Field(default_factory=list)
    is_scraped: bool = False
    error: Optional[str] = None


class SerpAnalysisResult(BaseModel):
    """Aggregate result from the live advanced SERP call and competitor feature extraction."""
    query: str
    provider: str
    top_urls: List[Dict[str, Any]] = Field(default_factory=list)
    serp_features: List[str] = Field(default_factory=list)
    paa_questions: List[str] = Field(default_factory=list)
    related_searches: List[str] = Field(default_factory=list)
    has_ai_overview: bool = False
    ai_overview_sources: List[Dict[str, str]] = Field(default_factory=list)
    competitor_pages: List[CompetitorPageAnalysis] = Field(default_factory=list)
    table_stakes_entities: List[str] = Field(default_factory=list)
    differentiator_entities: List[str] = Field(default_factory=list)
    unanswered_paa_questions: List[str] = Field(default_factory=list)
    average_word_count: int = 0


class BriefSection(BaseModel):
    """Structured requirement for a specific section within the content brief."""
    heading: str
    level: int = Field(default=2, ge=2, le=3)
    intent_goal: str
    answer_first_guidance: Optional[str] = Field(
        None,
        description="Direct 40-50 word answer format positioned at the section start for GEO/snippets"
    )
    required_entities: List[str] = Field(default_factory=list)
    required_statistics_or_claims: List[str] = Field(default_factory=list)
    notes: Optional[str] = None


class ContentBrief(BaseModel):
    """
    Evidence-based content brief for editorial and generative authoring.
    Replaces generic 'outline from LLM memory' with empirical SERP facts.
    """
    primary_keyword: str
    intent: str
    target_reader: str
    unique_angle: str
    required_sections: List[BriefSection] = Field(default_factory=list)
    required_entities: List[str] = Field(default_factory=list)
    questions_to_answer: List[Dict[str, str]] = Field(
        default_factory=list,
        description="Questions with answer-first guidance, including unanswered PAA opportunities"
    )
    claims_needing_sources: List[str] = Field(
        default_factory=list,
        description="Empirical or statistical claims that require verified citations"
    )
    internal_link_candidates: List[Dict[str, str]] = Field(default_factory=list)
    schema_plan: List[str] = Field(default_factory=list)
    word_count_range: Dict[str, Any] = Field(
        default_factory=dict,
        description="Calculated depth range from Page-1 competitors (a range, not a target to stuff)"
    )
    serp_summary: Optional[Dict[str, Any]] = None


# =====================================================================
# CONFIGURATION & UTILITY HELPERS
# =====================================================================

def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


def _domain_of(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc[4:] if netloc.startswith("www.") else netloc
    except Exception:
        return ""


def _rate_limit_domain(netloc: str, min_interval: float = 0.3) -> None:
    """Enforces polite delay between requests to the same domain."""
    now = time.time()
    last = _DOMAIN_LAST_REQUEST.get(netloc, 0.0)
    elapsed = now - last
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _DOMAIN_LAST_REQUEST[netloc] = time.time()


# =====================================================================
# 1. SERP LIVE ADVANCED CALL
# =====================================================================

def fetch_serp_live_advanced(
    keyword: str,
    depth: int = 10,
    website_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Executes a live advanced SERP call for the primary keyword:
    - Top 10 organic URLs with positions, titles, snippets
    - SERP features (featured_snippet, people_also_ask, ai_overview, video, etc.)
    - PAA questions (People Also Ask)
    - Related searches
    - AI Overview detection and which sources it cites
    """
    clean_kw = keyword.strip()
    if not clean_kw:
        return _empty_serp_response(clean_kw)

    # 1. DataForSEO Live Advanced
    df_login = _cfg("DATAFORSEO_LOGIN")
    df_password = _cfg("DATAFORSEO_PASSWORD")
    if df_login and df_password:
        try:
            with httpx.Client(timeout=45.0) as client:
                resp = client.post(
                    DATAFORSEO_SERP_ENDPOINT,
                    auth=(df_login, df_password),
                    json=[{"keyword": clean_kw, "language_code": "en", "location_code": 2840, "depth": depth}],
                )
                if resp.status_code == 200:
                    data = resp.json()
                    task = (data.get("tasks") or [{}])[0]
                    result = (task.get("result") or [{}])[0]
                    items = result.get("items") or []

                    top_urls = []
                    features = set()
                    paa_questions = []
                    related_searches = []
                    has_ai_overview = False
                    ai_overview_sources = []

                    for item in items:
                        itype = item.get("type") or ""
                        if itype in ("ai_overview", "generative_search_experience") or "ai_overview" in itype:
                            has_ai_overview = True
                            features.add("ai_overview")
                            # Extract cited sources
                            for ref in item.get("items") or item.get("references") or []:
                                ref_url = ref.get("url") or ref.get("link")
                                if ref_url:
                                    ai_overview_sources.append({
                                        "title": ref.get("title") or "",
                                        "url": ref_url,
                                        "domain": _domain_of(ref_url),
                                    })
                        elif itype == "people_also_ask":
                            features.add("people_also_ask")
                            for paa in item.get("items") or []:
                                q_text = paa.get("title") or paa.get("question")
                                if q_text and q_text.strip():
                                    paa_questions.append(q_text.strip())
                        elif itype == "related_searches":
                            features.add("related_searches")
                            for rel in item.get("items") or []:
                                term = rel.get("title") or rel.get("keyword") or str(rel)
                                if term and term.strip():
                                    related_searches.append(term.strip())
                        elif itype == "organic":
                            pos = item.get("rank_group") or item.get("rank_absolute") or (len(top_urls) + 1)
                            top_urls.append({
                                "position": pos,
                                "rank": pos,
                                "title": item.get("title") or "",
                                "url": item.get("url") or "",
                                "domain": item.get("domain") or _domain_of(item.get("url") or ""),
                                "snippet": item.get("description") or "",
                            })
                        elif itype:
                            features.add(itype)

                    # Deduplicate questions and searches
                    paa_questions = list(dict.fromkeys(paa_questions))
                    related_searches = list(dict.fromkeys(related_searches))
                    top_urls = sorted(top_urls, key=lambda x: x.get("rank") or 999)[:depth]

                    return {
                        "query": clean_kw,
                        "provider": "dataforseo",
                        "top_urls": top_urls,
                        "serp_features": sorted(features),
                        "paa_questions": paa_questions[:10],
                        "related_searches": related_searches[:10],
                        "has_ai_overview": has_ai_overview,
                        "ai_overview_sources": ai_overview_sources[:8],
                    }
        except Exception as e:
            logger.warning(f"DataForSEO live advanced call failed for '{clean_kw}': {e}")

    # 2. Serper.dev Live Search
    serper_key = _cfg("SERPER_API_KEY")
    if serper_key:
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.post(
                    SERPER_ENDPOINT,
                    headers={"X-API-KEY": serper_key, "Content-Type": "application/json"},
                    json={"q": clean_kw, "num": depth},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    top_urls = []
                    features = set()
                    paa_questions = []
                    related_searches = []
                    has_ai_overview = bool(data.get("ai_overview") or data.get("answerBox"))
                    ai_overview_sources = []

                    if has_ai_overview:
                        features.add("ai_overview")
                        ans_box = data.get("answerBox") or {}
                        if ans_box.get("link"):
                            ai_overview_sources.append({
                                "title": ans_box.get("title") or "",
                                "url": ans_box.get("link"),
                                "domain": _domain_of(ans_box.get("link")),
                            })

                    for idx, org in enumerate(data.get("organic", [])[:depth], start=1):
                        link = org.get("link") or ""
                        top_urls.append({
                            "position": org.get("position") or idx,
                            "rank": org.get("position") or idx,
                            "title": org.get("title") or "",
                            "url": link,
                            "domain": _domain_of(link),
                            "snippet": org.get("snippet") or "",
                        })

                    for paa in data.get("peopleAlsoAsk", []):
                        q = paa.get("question")
                        if q:
                            paa_questions.append(q.strip())
                            features.add("people_also_ask")

                    for rel in data.get("relatedSearches", []):
                        q = rel.get("query")
                        if q:
                            related_searches.append(q.strip())
                            features.add("related_searches")

                    return {
                        "query": clean_kw,
                        "provider": "serper",
                        "top_urls": top_urls,
                        "serp_features": sorted(features),
                        "paa_questions": paa_questions[:10],
                        "related_searches": related_searches[:10],
                        "has_ai_overview": has_ai_overview,
                        "ai_overview_sources": ai_overview_sources,
                    }
        except Exception as e:
            logger.warning(f"Serper search call failed for '{clean_kw}': {e}")

    # 3. Tavily Intelligence Fallback
    tavily_data = fetch_tavily_intelligence(clean_kw, max_results=depth, search_depth="basic")
    raw_results = tavily_data.get("results") or []
    if raw_results:
        top_urls = []
        ai_sources = []
        for idx, r in enumerate(raw_results[:depth], start=1):
            url = r.get("url") or ""
            top_urls.append({
                "position": idx,
                "rank": idx,
                "title": r.get("title") or "",
                "url": url,
                "domain": _domain_of(url),
                "snippet": (r.get("content") or "")[:260],
            })
            if idx <= 2:
                ai_sources.append({"title": r.get("title") or "", "url": url, "domain": _domain_of(url)})

        paa = generate_natural_paa_questions(clean_kw, count=5)
        related = generate_natural_related_searches(clean_kw, count=4)
        return {
            "query": clean_kw,
            "provider": "tavily",
            "top_urls": top_urls,
            "serp_features": ["organic", "ai_overview", "people_also_ask"],
            "paa_questions": paa,
            "related_searches": related,
            "has_ai_overview": True,
            "ai_overview_sources": ai_sources,
            "ai_overview_summary": tavily_data.get("answer"),
        }

    # 4. Fallback for Zero-Credentials Environments: return explicit unconfigured status
    # rather than fabricating non-existent SERP rankings and fake competitor URLs (AUD-22)
    return _empty_serp_response(clean_kw)


def _empty_serp_response(query: str) -> Dict[str, Any]:
    return {
        "query": query,
        "provider": "unconfigured",
        "top_urls": [],
        "serp_features": [],
        "paa_questions": [],
        "related_searches": [],
        "has_ai_overview": False,
        "ai_overview_sources": [],
    }


def _build_simulated_serp(keyword: str, depth: int) -> Dict[str, Any]:
    """Generates an evidence-aligned simulated SERP footprint for test and offline resilience."""
    clean = keyword.lower()
    domains = ["dev.to", "medium.com", "github.com", "archdaily.com", "stackoverflow.com", "infoworld.com"]
    top_urls = []
    for i in range(1, min(depth + 1, 11)):
        d = domains[(i - 1) % len(domains)]
        clean_subj = clean_topic_phrase(keyword)
        top_urls.append({
            "position": i,
            "rank": i,
            "title": f"The Complete Guide to {clean_subj.title()} — Architectural Deep Dive #{i}",
            "url": f"https://{d}/articles/{re.sub(r'[^a-z0-9]+', '-', clean)}-guide-{i}",
            "domain": d,
            "snippet": f"Learn the mechanics, trade-offs, and empirical benchmarks of {clean_subj}. Detailed analysis of architecture and best practices.",
        })

    paa = generate_natural_paa_questions(keyword, count=5)
    related = generate_natural_related_searches(keyword, count=4)
    ai_sources = [
        {"title": top_urls[0]["title"], "url": top_urls[0]["url"], "domain": top_urls[0]["domain"]},
        {"title": top_urls[1]["title"], "url": top_urls[1]["url"], "domain": top_urls[1]["domain"]},
    ]
    return {
        "query": keyword,
        "provider": "simulated",
        "top_urls": top_urls,
        "serp_features": ["ai_overview", "featured_snippet", "people_also_ask", "related_searches"],
        "paa_questions": paa,
        "related_searches": related,
        "has_ai_overview": True,
        "ai_overview_sources": ai_sources,
    }


# =====================================================================
# 2. ROBOTS.TXT CHECKING & POLITE SCRAPING
# =====================================================================

def is_allowed_by_robots(url: str, user_agent: str = "*", timeout: float = 4.0) -> bool:
    """
    Checks if fetching `url` is permitted by the domain's robots.txt.
    Cached per domain root to eliminate duplicate network overhead and respect webmasters.
    """
    try:
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return True
        domain_root = f"{parsed.scheme}://{parsed.netloc}"

        if domain_root in _ROBOTS_CACHE:
            rp = _ROBOTS_CACHE[domain_root]
            return rp.can_fetch(user_agent, url) if rp is not None else True

        robots_url = f"{domain_root}/robots.txt"
        rp = RobotFileParser()
        try:
            with httpx.Client(
                timeout=timeout,
                follow_redirects=True,
                headers={"User-Agent": "Mozilla/5.0 (Compatible; ContentAutomateBot/1.0; +http://localhost/bot)"},
            ) as client:
                resp = client.get(robots_url)
                if resp.status_code == 200:
                    rp.parse(resp.text.splitlines())
                    _ROBOTS_CACHE[domain_root] = rp
                    return rp.can_fetch(user_agent, url)
                elif resp.status_code in (401, 403):
                    _ROBOTS_CACHE[domain_root] = None
                    return False
                else:
                    _ROBOTS_CACHE[domain_root] = None
                    return True
        except Exception:
            _ROBOTS_CACHE[domain_root] = None
            return True
    except Exception as e:
        logger.debug(f"robots.txt parser error for {url}: {e}")
        return True


# =====================================================================
# 3. FEATURE EXTRACTION (HEADINGS, WORD COUNT, ENTITIES, STATS, MEDIA, SCHEMA)
# =====================================================================

def extract_headings_from_html(html_text: str) -> List[HeadingItem]:
    """Extracts H2 and H3 headings from HTML text into a clean structured list."""
    headings: List[HeadingItem] = []
    pattern = re.compile(r"<(h[23])(?:\s+[^>]*)?>(.*?)</\1>", re.IGNORECASE | re.DOTALL)
    for match in pattern.finditer(html_text):
        tag = match.group(1).lower()
        level = 2 if tag == "h2" else 3
        raw_text = re.sub(r"<[^>]+>", "", match.group(2))
        clean_text = " ".join(html.unescape(raw_text).split()).strip()
        if clean_text and len(clean_text) >= 3:
            headings.append(HeadingItem(level=level, text=clean_text))
    return headings


def extract_media_types_from_html(html_text: str) -> Dict[str, int]:
    """Counts rich media elements present in the competitor page HTML."""
    return {
        "images": len(re.findall(r"<img\b", html_text, re.I)),
        "videos": len(re.findall(r"<video\b|<iframe\b[^>]*?(?:youtube|vimeo|player|wistia)", html_text, re.I)),
        "tables": len(re.findall(r"<table\b", html_text, re.I)),
        "code_blocks": len(re.findall(r"<pre\b|<code\b", html_text, re.I)),
    }


def extract_schema_types_from_html(html_text: str) -> List[str]:
    """Parses JSON-LD scripts (<script type='application/ld+json'>) and extracts all @type schemas."""
    schema_types: Set[str] = set()
    matches = re.finditer(
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html_text,
        re.I | re.S,
    )
    for m in matches:
        content = m.group(1).strip()
        if not content:
            continue
        try:
            data = json.loads(content)
            _collect_schema_types(data, schema_types)
        except Exception:
            # Handle possible slight JSON-LD syntax issues in scraped competitor pages
            pass
    return sorted(schema_types)


def _collect_schema_types(node: Any, types: Set[str]) -> None:
    if isinstance(node, dict):
        t = node.get("@type")
        if isinstance(t, str) and t.strip():
            types.add(t.strip())
        elif isinstance(t, list):
            for sub in t:
                if isinstance(sub, str) and sub.strip():
                    types.add(sub.strip())
        if "@graph" in node and isinstance(node["@graph"], list):
            for item in node["@graph"]:
                _collect_schema_types(item, types)
        for v in node.values():
            if isinstance(v, (dict, list)):
                _collect_schema_types(v, types)
    elif isinstance(node, list):
        for item in node:
            _collect_schema_types(item, types)


STAT_PATTERNS = [
    re.compile(r"\b\d+(?:\.\d+)?%\b"),
    re.compile(r"\b\d+(?:\.\d+)?x\b", re.I),
    re.compile(r"\$\d+(?:,\d{3})*(?:\.\d+)?(?:\s?(?:billion|million|trillion|k|m|b))?\b", re.I),
    re.compile(r"\b\d+(?:\.\d+)?\s?(?:ms|fps|gb|tb|mb|hz|ghz|tps|req/s|ops/s|p99|p95)\b", re.I),
]


def extract_statistics_from_text(text: str, max_stats: int = 10) -> List[str]:
    """Identifies concrete statistical metrics, percentages, and benchmark assertions."""
    stats = []
    sentences = re.split(r"[.!?\n\r]+", text)
    seen = set()
    for s in sentences:
        s_clean = " ".join(s.split()).strip()
        if not (15 <= len(s_clean) <= 180):
            continue
        for rgx in STAT_PATTERNS:
            if rgx.search(s_clean):
                if s_clean not in seen:
                    seen.add(s_clean)
                    stats.append(s_clean)
                break
        if len(stats) >= max_stats:
            break
    return stats


def extract_entities_from_text(text: str, max_entities: int = 25) -> List[str]:
    """
    Extracts high-salience named entities and domain concepts.
    Uses spaCy NER if available; otherwise falls back to NLP proper noun & capital phrase mining.
    """
    if not text:
        return []

    # Priority 1: spaCy NER
    if _SPACY_NLP is not None:
        try:
            doc = _SPACY_NLP(text[:6000])
            ents = []
            for ent in doc.ents:
                clean_e = ent.text.strip()
                if (
                    clean_e
                    and len(clean_e) >= 3
                    and ent.label_ in ("ORG", "PRODUCT", "PERSON", "GPE", "WORK_OF_ART", "EVENT", "LAW")
                    and clean_e.lower() not in STOPWORDS
                ):
                    ents.append(clean_e.title())
            counts = Counter(ents)
            return [e for e, _ in counts.most_common(max_entities)]
        except Exception as e:
            logger.debug(f"spaCy NER extraction fallback: {e}")

    # Priority 2: High-salience NLP entity mining (Proper nouns, Title Case)
    raw_entities = re.findall(r"\b[A-Z][a-z0-9]+(?:\s+[A-Z][a-z0-9]+){0,2}\b", text)
    clean_entities = []
    for ent in raw_entities:
        ent_lower = ent.lower()
        parts = ent_lower.split()
        if any(p in STOPWORDS for p in parts):
            continue
        if len(ent) < 3 or len(parts) > 3:
            continue
        clean_entities.append(ent.strip().title())

    counts = Counter(clean_entities)
    return [e for e, _ in counts.most_common(max_entities)]


def scrape_and_analyze_page(
    url: str,
    rank: Optional[int] = None,
    timeout: float = 8.0,
    check_robots: bool = True,
) -> CompetitorPageAnalysis:
    """
    Fetches a single competitor page via httpx, extracts article text with trafilatura,
    and extracts headings, word count, entities, statistics, media types, and schemas.
    STRICT COMPLIANCE: Content is used for analysis only, NEVER copied or stored verbatim.
    """
    import trafilatura

    domain = _domain_of(url)

    # 0. Cache hit check
    if not os.getenv("PYTEST_CURRENT_TEST"):
        cached = _PAGE_ANALYSIS_CACHE.get(url)
        if cached and (time.time() - cached[0]) < _PAGE_CACHE_TTL_SEC:
            c_res = cached[1]
            if rank is not None and c_res.rank != rank:
                return c_res.model_copy(update={"rank": rank})
            return c_res

    # 1. Respect robots.txt
    if check_robots and not is_allowed_by_robots(url):
        logger.info(f"Scraper: Skipping {url} (disallowed by robots.txt)")
        return CompetitorPageAnalysis(
            url=url,
            domain=domain,
            rank=rank,
            is_scraped=False,
            error="Disallowed by robots.txt",
        )

    # 2. Domain rate-limiting
    parsed = urlparse(url)
    _rate_limit_domain(parsed.netloc)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 (Compatible; ContentAutomateBot/1.0)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }

    try:
        with httpx.Client(timeout=timeout, follow_redirects=True, headers=headers) as client:
            resp = client.get(url)
            if resp.status_code != 200:
                return CompetitorPageAnalysis(
                    url=url,
                    domain=domain,
                    rank=rank,
                    is_scraped=False,
                    error=f"HTTP status {resp.status_code}",
                )
            html_text = resp.text
    except Exception as e:
        logger.warning(f"Failed to fetch competitor page {url}: {e}")
        return CompetitorPageAnalysis(
            url=url,
            domain=domain,
            rank=rank,
            is_scraped=False,
            error=str(e),
        )

    # Extract title
    title_match = re.search(r"<title[^>]*>(.*?)</title>", html_text, re.I | re.S)
    title = html.unescape(re.sub(r"<[^>]+>", "", title_match.group(1)).strip()) if title_match else ""

    # Extract main text using trafilatura (analysis only, never copy)
    main_text = ""
    try:
        main_text = trafilatura.extract(
            html_text,
            include_comments=False,
            include_tables=False,
            output_format="txt",
        ) or ""
    except Exception as e:
        logger.debug(f"trafilatura extraction fallback for {url}: {e}")

    # Fallback to basic text extraction if trafilatura extracted empty body
    if not main_text:
        stripped = re.sub(r"<(script|style|svg|nav|header|footer)[^>]*>.*?</\1>", " ", html_text, flags=re.I | re.S)
        clean_text = re.sub(r"<[^>]+>", " ", stripped)
        main_text = " ".join(html.unescape(clean_text).split())

    words = main_text.split()
    word_count = len(words)

    headings = extract_headings_from_html(html_text)
    entities = extract_entities_from_text(main_text)
    statistics = extract_statistics_from_text(main_text)
    media_types = extract_media_types_from_html(html_text)
    schema_types = extract_schema_types_from_html(html_text)

    res = CompetitorPageAnalysis(
        url=url,
        domain=domain,
        title=title,
        rank=rank,
        headings=headings,
        word_count=word_count,
        entities=entities,
        statistics=statistics,
        media_types=media_types,
        schema_types=schema_types,
        is_scraped=True,
    )
    if not os.getenv("PYTEST_CURRENT_TEST"):
        _PAGE_ANALYSIS_CACHE[url] = (time.time(), res)
    return res


def fetch_and_analyze_competitors(
    top_urls: List[Dict[str, Any]],
    max_pages: int = 5,
    check_robots: bool = True,
) -> List[CompetitorPageAnalysis]:
    """
    Batches competitor page scraping across the top results up to max_pages.
    Uses concurrent ThreadPoolExecutor for high-speed parallel retrieval.
    Returns structured CompetitorPageAnalysis records preserving rank order.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    target_urls = [u for u in top_urls if u.get("url")][:max_pages]
    if not target_urls:
        return []

    def _scrape_worker(item: Dict[str, Any]) -> CompetitorPageAnalysis:
        url = item.get("url")
        rank = item.get("rank") or item.get("position")
        if not url:
            return CompetitorPageAnalysis(url="", domain="", rank=rank, is_scraped=False, error="Empty URL")
        try:
            return scrape_and_analyze_page(url, rank=rank, check_robots=check_robots)
        except Exception as e:
            logger.warning(f"Error analyzing competitor page {url}: {e}")
            return CompetitorPageAnalysis(
                url=url,
                domain=_domain_of(url),
                rank=rank,
                is_scraped=False,
                error=str(e),
            )

    workers = min(len(target_urls), 5)
    results_map: Dict[str, CompetitorPageAnalysis] = {}

    with ThreadPoolExecutor(max_workers=workers) as pool:
        future_to_url = {pool.submit(_scrape_worker, item): item.get("url") for item in target_urls}
        for fut in as_completed(future_to_url):
            target_url = future_to_url[fut]
            try:
                res = fut.result()
                results_map[target_url] = res
            except Exception as e:
                results_map[target_url] = CompetitorPageAnalysis(
                    url=target_url or "",
                    domain=_domain_of(target_url or ""),
                    is_scraped=False,
                    error=str(e),
                )

    analyses = []
    for item in target_urls:
        u = item.get("url")
        if u and u in results_map:
            analyses.append(results_map[u])
    return analyses


# =====================================================================
# 4. GAP ANALYSIS (TABLE STAKES VS DIFFERENTIATORS VS UNANSWERED PAA)
# =====================================================================

def analyze_serp_gaps(
    competitor_pages: List[CompetitorPageAnalysis],
    paa_questions: List[str],
) -> Dict[str, Any]:
    """
    Conducts comparative gap analysis across Page-1 competitor pages:
    - Table stakes: Entities and concepts appearing on >= 50% of scraped competitor pages.
    - Differentiators: Entities appearing on only 1-2 competitor pages.
    - Unanswered PAA Questions: Questions where no competitor heading addresses the premise.
    """
    scraped_pages = [p for p in competitor_pages if p.is_scraped]
    num_pages = len(scraped_pages)

    # 1. Entity Frequency Mapping
    entity_page_counts: Counter = Counter()
    for p in scraped_pages:
        unique_page_entities = set(e.strip().title() for e in p.entities if e.strip())
        for e in unique_page_entities:
            entity_page_counts[e] += 1

    table_stakes_entities: List[str] = []
    differentiator_entities: List[str] = []

    if num_pages >= 2:
        table_stakes_threshold = max(2, int(0.5 * num_pages + 0.5))
        for ent, count in entity_page_counts.most_common():
            if count >= table_stakes_threshold:
                table_stakes_entities.append(ent)
            elif count <= max(1, int(0.35 * num_pages)):
                differentiator_entities.append(ent)
    elif num_pages == 1:
        all_sorted = [e for e, _ in entity_page_counts.most_common()]
        table_stakes_entities = all_sorted[:6]
        differentiator_entities = all_sorted[6:16]
    else:
        table_stakes_entities = []
        differentiator_entities = []

    # 2. Heading Texts for Question Resolution
    heading_texts = []
    for p in scraped_pages:
        for h in p.headings:
            heading_texts.append(h.text.lower())

    # 3. Unanswered PAA Questions (Your Opportunity)
    question_stopwords = {
        "how", "what", "why", "when", "where", "who", "which", "can", "does", "do", "is",
        "are", "the", "a", "an", "to", "in", "for", "of", "and", "or", "best", "should"
    }
    unanswered_paa: List[str] = []

    for q in paa_questions:
        q_clean = q.strip().rstrip("?")
        q_tokens = [
            w.lower() for w in re.findall(r"\b\w+\b", q_clean)
            if w.lower() not in question_stopwords and len(w) >= 3
        ]
        if not q_tokens:
            continue

        answered = False
        for h_text in heading_texts:
            matched = sum(1 for tok in q_tokens if tok in h_text)
            if (matched / len(q_tokens)) >= 0.60:
                answered = True
                break

        if not answered:
            unanswered_paa.append(q)

    # Compute average word count across scraped competitors
    valid_word_counts = [p.word_count for p in scraped_pages if p.word_count >= 300]
    avg_word_count = int(sum(valid_word_counts) / len(valid_word_counts)) if valid_word_counts else 2000

    return {
        "table_stakes_entities": table_stakes_entities[:15],
        "differentiator_entities": differentiator_entities[:15],
        "unanswered_paa_questions": unanswered_paa,
        "scraped_page_count": num_pages,
        "average_word_count": avg_word_count,
    }


# =====================================================================
# 5. DEPTH & WORD COUNT RANGE (A RANGE, NOT A STUFFING TARGET)
# =====================================================================

def calculate_word_count_range(competitor_pages: List[CompetitorPageAnalysis]) -> Dict[str, Any]:
    """
    Derives an evidence-based word-count range based on Page-1 competitor lengths.
    Explicitly outputs a flexible range, not an arbitrary keyword-stuffing target.
    """
    valid_counts = [p.word_count for p in competitor_pages if p.is_scraped and p.word_count >= 300]
    if valid_counts:
        avg_words = int(sum(valid_counts) / len(valid_counts))
        min_words = max(1000, int(avg_words * 0.90))
        max_words = min(5000, max(min_words + 300, int(avg_words * 1.25)))
        target_median = avg_words
    else:
        min_words = 1800
        max_words = 2600
        target_median = 2200

    return {
        "min": min_words,
        "max": max_words,
        "target_median": target_median,
        "guidance": (
            f"Recommended depth range: {min_words}–{max_words} words (competitor median: {target_median}). "
            "This is an evidence-based range for exhaustive topic coverage, not an arbitrary keyword stuffing target."
        ),
    }


# =====================================================================
# 6. SCHEMA PLANNING
# =====================================================================

def plan_schema(
    topic: str,
    search_intent: str,
    has_paa: bool,
    competitor_schemas: List[str],
) -> List[str]:
    """Plans validated Schema.org types based on topic, intent, and competitor standards."""
    schemas = ["Article"]
    t_lower = topic.lower()

    if any(k in t_lower for k in ("how to", "guide", "tutorial", "setup", "install", "how-to")):
        schemas.append("HowTo")
    if any(k in t_lower for k in ("engine", "architecture", "code", "algorithm", "python", "api", "nextjs", "system")) or "TechArticle" in competitor_schemas:
        schemas.append("TechArticle")

    if has_paa or "faq" in t_lower or "question" in search_intent.lower():
        schemas.append("FAQPage")

    schemas.append("BreadcrumbList")

    if "ItemList" in competitor_schemas and "ItemList" not in schemas:
        schemas.append("ItemList")

    return list(dict.fromkeys(schemas))


# =====================================================================
# 7. UNIQUE ANGLE RESOLUTION (FROM EVIDENCE PACK A3.2)
# =====================================================================

def resolve_unique_angle(
    evidence_pack: Optional[Dict[str, Any]] = None,
    angle_or_hook: Optional[str] = None,
    primary_keyword: str = "",
    unanswered_paa: Optional[List[str]] = None,
    differentiators: Optional[List[str]] = None,
) -> str:
    """
    Pulls the unique angle from the evidence pack (A3.2), or derives an empirical angle
    combining unanswered PAA questions, differentiator entities, and verified benchmarks.
    """
    # 1. Pull directly from evidence pack (A3.2)
    if evidence_pack:
        if isinstance(evidence_pack, dict):
            if evidence_pack.get("unique_angle"):
                return str(evidence_pack["unique_angle"]).strip()
            if evidence_pack.get("primary_finding"):
                return str(evidence_pack["primary_finding"]).strip()
            if evidence_pack.get("counter_intuitive_takeaway"):
                return str(evidence_pack["counter_intuitive_takeaway"]).strip()
            if evidence_pack.get("benchmark_summary"):
                return str(evidence_pack["benchmark_summary"]).strip()
        elif isinstance(evidence_pack, list) and len(evidence_pack) > 0:
            for item in evidence_pack:
                if isinstance(item, dict):
                    for k in ("unique_angle", "primary_finding", "counter_intuitive_takeaway", "benchmark_summary", "title", "content"):
                        val = item.get(k)
                        if val and str(val).strip():
                            return str(val).strip()

    # 2. Pull from user/state angle_or_hook
    if angle_or_hook and angle_or_hook.strip():
        return angle_or_hook.strip()

    # 3. Derive evidence-backed unique angle from differentiators and unanswered PAA
    diff_str = ", ".join(differentiators[:2]) if differentiators else "architectural and performance constraints"
    paa_str = unanswered_paa[0] if (unanswered_paa and len(unanswered_paa) > 0) else f"production optimization for {primary_keyword}"
    return f"Empirical benchmark & architectural analysis: Solving '{paa_str}' through {diff_str} with zero performance degradation."


# =====================================================================
# 8. COMPLETE EVIDENCE-BASED BRIEF BUILDER
# =====================================================================

def build_evidence_based_brief(
    topic: str,
    primary_keyword: Optional[str] = None,
    website_id: Optional[str] = None,
    brand_profile: Optional[Dict[str, Any]] = None,
    evidence_pack: Optional[Dict[str, Any]] = None,
    niche_slug: Optional[str] = None,
    editorial_niche: Optional[str] = None,
    target_audience: Optional[str] = None,
    angle_or_hook: Optional[str] = None,
    editorial_archetype: Optional[str] = None,
    design_guide: Optional[Dict[str, Any]] = None,
    slug: Optional[str] = None,
    max_competitors_to_scrape: int = 5,
    check_robots: bool = True,
) -> ContentBrief:
    """
    Core Entry Point for Pillar A2.
    Builds a fully-typed, evidence-based content brief from live SERP intelligence.
    """
    kw = (primary_keyword or topic).strip()
    logger.info(f"Building evidence-based content brief for '{kw}' (topic: '{topic}')")

    # 1. SERP Live Advanced Call
    serp_data = fetch_serp_live_advanced(kw, depth=10, website_id=website_id)
    top_urls = serp_data.get("top_urls", [])
    serp_features = serp_data.get("serp_features", [])
    raw_paa = serp_data.get("paa_questions", [])
    paa_questions = [clean_double_question(q) for q in raw_paa if q]
    if not paa_questions:
        paa_questions = generate_natural_paa_questions(kw, count=5)
    related_searches = serp_data.get("related_searches", [])
    has_ai_overview = serp_data.get("has_ai_overview", False)
    ai_overview_sources = serp_data.get("ai_overview_sources", [])

    # 2. Competitor Page Scraping & Feature Extraction
    provider = serp_data.get("provider", "unconfigured")
    if provider in ("dataforseo", "serper", "tavily") and top_urls:
        competitor_pages = fetch_and_analyze_competitors(
            top_urls,
            max_pages=max_competitors_to_scrape,
            check_robots=check_robots,
        )
    else:
        competitor_pages = []

    # 3. Gap Analysis
    gaps = analyze_serp_gaps(competitor_pages, paa_questions)
    table_stakes = gaps["table_stakes_entities"]
    differentiators = gaps["differentiator_entities"]
    unanswered_paa = gaps["unanswered_paa_questions"]

    # If no entities extracted (e.g. offline/mock/unconfigured), populate context-aware fallbacks
    clean_subj = clean_topic_phrase(kw).title()
    if not table_stakes:
        table_stakes = [clean_subj, f"{clean_subj} Fundamentals", "Implementation Strategy", "Best Practices"]
    if not differentiators:
        niche_ctx = (editorial_niche or (brand_profile.get("niche") if brand_profile else "") or "").strip().lower()
        if any(g in niche_ctx for g in ("game", "gaming", "unreal", "unity", "graphics")):
            differentiators = ["Deterministic Physics", "Sub-Tick Simulation", "Memory Optimization"]
        else:
            differentiators = [
                f"{clean_subj} Architecture & Workflow",
                "Production Optimization & Reliability",
                "Comparative Evaluation & Metrics",
            ]

    # 4. Pull Unique Angle from Evidence Pack (A3.2)
    unique_angle = resolve_unique_angle(
        evidence_pack=evidence_pack,
        angle_or_hook=angle_or_hook,
        primary_keyword=kw,
        unanswered_paa=unanswered_paa,
        differentiators=differentiators,
    )

    # 5. Internal Link Candidates
    cluster_candidates = get_cluster_candidates(topic=topic, website_id=website_id, exclude_slug=slug, limit=4)
    internal_link_items = [
        {
            "title": c.get("title") or "",
            "slug": c.get("slug") or "",
            "target_url": f"/posts/{c.get('slug')}",
            "context": f"Connects topical cluster authority to {c.get('title')}",
        }
        for c in cluster_candidates if c.get("slug")
    ]

    # 6. Schema Plan
    all_competitor_schemas = [s for p in competitor_pages for s in p.schema_types]
    schema_types = plan_schema(
        topic=topic,
        search_intent="informational",
        has_paa=bool(paa_questions),
        competitor_schemas=all_competitor_schemas,
    )

    # 7. Word Count Range
    word_count_range = calculate_word_count_range(competitor_pages)

    # 8. Questions to Answer in Answer-First Form
    questions_to_answer = []
    seen_q_texts = set()

    # If the user's primary keyword is a question or comparison, place it as the top question target
    primary_q = naturalize_question(kw)
    primary_comp = extract_comparison_entities(kw)
    if primary_comp or kw.strip().endswith("?") or any(kw.lower().startswith(w + " ") for w in ("what", "how", "why", "when", "which", "where", "can", "should", "is", "are")):
        clean_pq = clean_double_question(primary_q)
        seen_q_texts.add(clean_pq.lower())
        questions_to_answer.append({
            "question": clean_pq,
            "answer_first_form": (
                f"Direct Answer Target: Lead immediately with a concise, factual 40-50 word resolution "
                f"answering '{clean_pq}' before detailing technical architecture, code, or benchmark evidence."
            ),
            "opportunity_type": "primary_serp_intent",
        })

    # Include unanswered PAA questions as priority opportunities
    for q in unanswered_paa:
        clean_q = naturalize_question(clean_double_question(q))
        if clean_q.lower() in seen_q_texts:
            continue
        seen_q_texts.add(clean_q.lower())
        questions_to_answer.append({
            "question": clean_q,
            "answer_first_form": (
                f"Direct Answer Target: Lead immediately with a concise, factual 40-50 word resolution "
                f"answering '{clean_q}' before detailing code, ratios, or benchmark evidence."
            ),
            "opportunity_type": "unanswered_paa_opportunity",
        })
        if len(questions_to_answer) >= 4:
            break

    # Fill with remaining PAA questions if any
    for q in paa_questions:
        clean_q = naturalize_question(clean_double_question(q))
        if clean_q.lower() not in seen_q_texts and len(questions_to_answer) < 6:
            seen_q_texts.add(clean_q.lower())
            questions_to_answer.append({
                "question": clean_q,
                "answer_first_form": (
                    f"Direct Answer Target: Provide an authoritative 2-sentence direct answer "
                    f"to establish topical consensus for '{clean_q}'."
                ),
                "opportunity_type": "serp_consensus_paa",
            })

    # 9. Claims Needing Sources
    clean_kw_subj = clean_topic_phrase(kw)
    claims_needing_sources = [
        f"Empirical benchmarks comparing {clean_kw_subj} latency and compute overhead against legacy implementations.",
        "Quantitative measurements of memory allocations and throughput under peak load.",
        "Production telemetry or real-world deployment metrics supporting performance conclusions.",
    ]
    # Add any specific competitor statistics identified during extraction
    for p in competitor_pages:
        for stat in p.statistics[:2]:
            if stat not in claims_needing_sources:
                claims_needing_sources.append(f"Cite verifiable benchmark for claim: '{stat[:100]}'")
            if len(claims_needing_sources) >= 5:
                break
        if len(claims_needing_sources) >= 5:
            break

    # 10. Synthesize Structured Sections via LLM (or robust deterministic generator)
    reader = target_audience or "Senior Engineers, Technical Leads, and Domain Practitioners demanding practical mastery"
    intent_desc = "Informational — architectural deep dive with actionable production benchmarks"

    required_sections = _synthesize_brief_sections(
        topic=topic,
        primary_keyword=kw,
        target_reader=reader,
        unique_angle=unique_angle,
        table_stakes=table_stakes,
        differentiators=differentiators,
        unanswered_paa=unanswered_paa,
        internal_links=internal_link_items,
        editorial_archetype=editorial_archetype,
    )

    # Combined required entities (table stakes + top differentiators)
    required_entities = list(dict.fromkeys(table_stakes[:8] + differentiators[:6]))

    # Package SERP summary for observability
    serp_summary = {
        "provider": serp_data.get("provider"),
        "features": serp_features,
        "has_ai_overview": has_ai_overview,
        "ai_overview_sources": ai_overview_sources,
        "competitor_count": len(competitor_pages),
        "scraped_count": len([p for p in competitor_pages if p.is_scraped]),
        "table_stakes_count": len(table_stakes),
        "differentiator_count": len(differentiators),
        "unanswered_paa_count": len(unanswered_paa),
        "average_competitor_word_count": gaps.get("average_word_count", 2000),
    }

    return ContentBrief(
        primary_keyword=kw,
        intent=intent_desc,
        target_reader=reader,
        unique_angle=unique_angle,
        required_sections=required_sections,
        required_entities=required_entities,
        questions_to_answer=questions_to_answer,
        claims_needing_sources=claims_needing_sources,
        internal_link_candidates=internal_link_items,
        schema_plan=schema_types,
        word_count_range=word_count_range,
        serp_summary=serp_summary,
    )


def _synthesize_brief_sections(
    topic: str,
    primary_keyword: str,
    target_reader: str,
    unique_angle: str,
    table_stakes: List[str],
    differentiators: List[str],
    unanswered_paa: List[str],
    internal_links: List[Dict[str, str]],
    editorial_archetype: Optional[str] = None,
) -> List[BriefSection]:
    """
    Produces the structured BriefSection list using LLM synthesis or fallback heuristics.
    Enforces answer-first guidance, required entities, and explicit integration of gap findings.
    """
    system_instruction = (
        "You are an elite Head of SEO & Editorial Strategy. "
        "Create an evidence-based article brief structure with 5-6 H2 sections and selected H3 subtopics. "
        "Each section must designate: heading, level, intent_goal, answer_first_guidance (40-50 word direct answer), "
        "required_entities, and required_statistics_or_claims. "
        "Return a strict JSON object with a 'sections' array."
    )

    prompt = f"""Topic: {topic}
Primary Keyword: {primary_keyword}
Target Reader: {target_reader}
Unique Angle from Evidence Pack: {unique_angle}
Table Stakes Entities (must cover): {', '.join(table_stakes[:6])}
Differentiator Entities (competitive advantage): {', '.join(differentiators[:4])}
Unanswered PAA Questions to Address: {', '.join(unanswered_paa[:3]) if unanswered_paa else 'Standard search queries'}
Internal Link Anchors: {', '.join(l['title'] for l in internal_links)}

Produce 5 to 6 comprehensive H2 sections. Format strictly as JSON:
{{
  "sections": [
    {{
      "heading": "H2 Heading text containing keyword or variant",
      "level": 2,
      "intent_goal": "What technical problem this section solves for the reader",
      "answer_first_guidance": "Direct 40-50 word bolded statement answering the section premise up-front",
      "required_entities": ["Entity 1", "Entity 2"],
      "required_statistics_or_claims": ["Specific benchmark or ratio to include"]
    }}
  ]
}}
"""
    try:
        raw = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.3)
        parsed = extract_json_block(raw)
        if parsed and isinstance(parsed.get("sections"), list) and len(parsed["sections"]) >= 3:
            sections = []
            for s in parsed["sections"]:
                if isinstance(s, dict) and s.get("heading"):
                    heading_clean = clean_double_question(str(s["heading"]).strip())
                    af_raw = s.get("answer_first_guidance")
                    af_clean = clean_double_question(str(af_raw)) if af_raw else None
                    sections.append(BriefSection(
                        heading=heading_clean,
                        level=int(s.get("level") or 2),
                        intent_goal=str(s.get("intent_goal") or "").strip(),
                        answer_first_guidance=af_clean,
                        required_entities=[str(e).strip() for e in s.get("required_entities", []) if str(e).strip()],
                        required_statistics_or_claims=[str(c).strip() for c in s.get("required_statistics_or_claims", []) if str(c).strip()],
                        notes=s.get("notes"),
                    ))
            if sections:
                return sections
    except Exception as e:
        logger.debug(f"LLM brief section synthesis error: {e}")

    # Fallback deterministic section generator
    clean_subj = clean_topic_phrase(primary_keyword)
    comp = extract_comparison_entities(primary_keyword)
    if comp:
        first_heading = f"Core Differences: {comp[0].title()} vs. {comp[1].title()}"
        first_guidance = (
            f"Direct Answer: {comp[0].title()} dynamic simulation differs fundamentally from {comp[1].title()} "
            "by executing continuous solver constraints rather than fixed transform keyframes."
        )
    else:
        first_heading = f"Core Mechanics: Understanding {clean_subj.title()}"
        first_guidance = (
            f"Direct Answer: {clean_subj.title()} operates by establishing deterministic constraints "
            "across the execution cycle, eliminating overhead while guaranteeing reproducible behavior."
        )

    sections = [
        BriefSection(
            heading=first_heading,
            level=2,
            intent_goal="Establish foundational technical consensus and solve primary user definition intent",
            answer_first_guidance=first_guidance,
            required_entities=table_stakes[:3],
            required_statistics_or_claims=["Baseline throughput and latency measurements under default configurations"],
        ),
        BriefSection(
            heading="Architectural Implementation: Step-by-Step Blueprint",
            level=2,
            intent_goal="Provide production-ready implementation patterns with concrete architectural configurations",
            answer_first_guidance="Direct Answer: Configure the pipeline using decoupled stages to isolate bottleneck threads.",
            required_entities=table_stakes[3:6] if len(table_stakes) >= 6 else table_stakes[:2],
            required_statistics_or_claims=["Empirical memory allocation reduction percentages"],
        ),
    ]

    # Dedicated section for unanswered PAA questions (Opportunity)
    if unanswered_paa:
        unanswered_h = naturalize_heading_from_question(unanswered_paa[0])
        sections.append(BriefSection(
            heading=unanswered_h,
            level=2,
            intent_goal="Directly answer the highest-impact question competitors omit from their guides",
            answer_first_guidance=(
                f"Direct Answer: The solution lies in applying {differentiators[0] if differentiators else 'continuous validation'}, "
                "pre-calculating collision sweeps before state commit."
            ),
            required_entities=differentiators[:2],
            required_statistics_or_claims=["Benchmark measurements proving tunneling or failure elimination"],
        ))

    sections.extend([
        BriefSection(
            heading=f"Competitive Benchmarks & Unique Edge: {unique_angle[:50]}",
            level=2,
            intent_goal="Demonstrate empirical proof of the proprietary angle pulled from the evidence pack",
            answer_first_guidance="Direct Answer: In head-to-head empirical testing, this approach yields superior frame stability.",
            required_entities=differentiators[2:5] if len(differentiators) >= 5 else differentiators,
            required_statistics_or_claims=["Side-by-side benchmark comparison metrics against standard industry tools"],
        ),
        BriefSection(
            heading="Production Verification & Architectural Best Practices",
            level=2,
            intent_goal="Summarize practical deployment guidelines and diagnostic checklists",
            answer_first_guidance="Direct Answer: Always implement automated sanity assertions before deploying updates to production.",
            required_entities=table_stakes[:2],
            required_statistics_or_claims=["Maximum recommended batch size and execution limits"],
        ),
    ])

    return sections


# =====================================================================
# 9. BRIEF TO MARKDOWN CONVERTER (FOR DRAFT NODE INGESTION)
# =====================================================================

def brief_to_outline_markdown(brief: ContentBrief) -> str:
    """
    Converts a typed ContentBrief into the comprehensive Markdown outline format
    expected by draft_node and editorial authors.
    """
    lines = [
        f"# Content Brief & Production Outline: {brief.primary_keyword.title()}",
        "",
        f"**Search Intent:** {brief.intent}",
        f"**Target Reader:** {brief.target_reader}",
        f"**Unique Angle (Evidence Pack A3.2):** {brief.unique_angle}",
        f"**Word Count Range:** {brief.word_count_range.get('min', 1800)}–{brief.word_count_range.get('max', 2500)} words "
        f"(Median: {brief.word_count_range.get('target_median', 2100)}) — *Depth guidance, not a stuffing target*",
        "",
        "## Required Entities & Topical Authority Footprint",
        f"- **Table Stakes & Differentiators:** {', '.join(brief.required_entities)}",
        "",
        "## Direct Answer Targets for Google AI Overviews & Featured Snippets (Answer-First Form)",
    ]

    for q_item in brief.questions_to_answer:
        q = q_item.get("question", "")
        af = q_item.get("answer_first_form", "")
        opp = q_item.get("opportunity_type", "opportunity")
        lines.append(f"- **Q: {q}** ({opp})")
        lines.append(f"  - *{af}*")

    lines.extend([
        "",
        "## Structured Section Blueprint",
    ])

    for sec in brief.required_sections:
        prefix = "###" if sec.level == 3 else "##"
        lines.append(f"{prefix} {sec.heading}")
        lines.append(f"- **Goal:** {sec.intent_goal}")
        if sec.answer_first_guidance:
            lines.append(f"- **Answer-First Target:** {sec.answer_first_guidance}")
        if sec.required_entities:
            lines.append(f"- **Required Entities:** {', '.join(sec.required_entities)}")
        if sec.required_statistics_or_claims:
            lines.append(f"- **Empirical Evidence / Stats to Cite:** {', '.join(sec.required_statistics_or_claims)}")
        if sec.notes:
            lines.append(f"- **Editorial Note:** {sec.notes}")
        lines.append("")

    if brief.claims_needing_sources:
        lines.append("## Claims Requiring Verified Sources")
        for claim in brief.claims_needing_sources:
            lines.append(f"- [ ] {claim}")
        lines.append("")

    if brief.internal_link_candidates:
        lines.append("## Topical Cluster Internal Link Plan")
        for link in brief.internal_link_candidates:
            lines.append(f"- Link to: [{link.get('title')}]({link.get('target_url')}) ({link.get('context')})")
        lines.append("")

    if brief.schema_plan:
        lines.append("## Structured Data Schema Plan")
        lines.append(f"- **JSON-LD Schemas:** {', '.join(brief.schema_plan)}")
        lines.append("")

    return "\n".join(lines)
