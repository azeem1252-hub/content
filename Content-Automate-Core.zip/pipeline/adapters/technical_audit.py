"""
Technical SEO Audit Engine (Pillar V: Machine-Readability & Site Health).

The Action Center previously claimed "technical fixes" but only executed content
and schema changes. This adapter performs the actual crawl-and-diagnose pass:

  - Sitemap/robots discovery and a bounded same-origin crawl
  - Per-page: title/meta length, H1, canonical, meta-robots, lang, JSON-LD,
    hreflang, image alt coverage
  - Site-wide: broken internal links, redirect chains, robots/sitemap presence
  - Core Web Vitals (LCP / CLS / INP) via the free PageSpeed Insights API

Findings are structured ({url, category, severity, detail}) and persisted so the
Action Center can act on them. No credentials are required for the crawl; only
CWV requires PAGESPEED_API_KEY.
"""

from __future__ import annotations

import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse, urlunparse

import httpx
from bs4 import BeautifulSoup

import config

logger = logging.getLogger("pipeline.adapters.technical_audit")

USER_AGENT = (
    "Mozilla/5.0 (compatible; ContentPipelineAuditBot/1.0; +https://localhost) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
)
PAGESPEED_ENDPOINT = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed"
_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}


def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


def _norm_url(url: str) -> str:
    """Normalizes a URL for de-duplication (drops fragment/query/known index files)."""
    try:
        parts = urlparse(url)
        path = parts.path or "/"
        for index_file in ("/index.html", "/index.htm"):
            if path.endswith(index_file):
                path = path[: -len(index_file)] or "/"
        return urlunparse((parts.scheme, parts.netloc.lower(), path, "", "", ""))
    except Exception:  # noqa: BLE001
        return url


def _same_origin(url: str, base: str) -> bool:
    try:
        return urlparse(url).netloc.lower() == urlparse(base).netloc.lower()
    except Exception:  # noqa: BLE001
        return False


def _severity_for(category: str) -> str:
    return {
        "broken_link": "high",
        "redirect_chain": "medium",
        "noindex": "critical",
        "missing_canonical": "medium",
        "missing_title": "high",
        "missing_meta_description": "medium",
        "missing_h1": "medium",
        "multiple_h1": "low",
        "missing_schema": "medium",
        "missing_lang": "low",
        "image_alt": "low",
        "hreflang": "low",
        "title_length": "medium",
        "meta_description_length": "low",
        "core_web_vitals": "high",
        "robots_txt": "medium",
        "large_page": "low",
    }.get(category, "low")


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

def discover_urls(base_url: str, max_pages: int = 25, timeout: float = 12.0) -> List[str]:
    """Discovers same-origin URLs from sitemap.xml, robots.txt and homepage links."""
    base = base_url.rstrip("/")
    discovered: List[str] = []
    seen: Set[str] = set()

    def push(url: str) -> None:
        norm = _norm_url(url)
        if norm and norm not in seen and _same_origin(norm, base):
            seen.add(norm)
            discovered.append(norm)

    push(base)

    with httpx.Client(timeout=timeout, follow_redirects=True, headers={"User-Agent": USER_AGENT}) as client:
        # robots.txt -> sitemap directives
        sitemap_urls: List[str] = []
        try:
            robots = client.get(f"{base}/robots.txt")
            if robots.status_code == 200:
                for m in re.findall(r"(?im)^\s*sitemap:\s*(\S+)", robots.text):
                    sitemap_urls.append(m.strip())
        except Exception:  # noqa: BLE001
            pass
        if not sitemap_urls:
            sitemap_urls = [f"{base}/sitemap.xml"]

        for sitemap in sitemap_urls[:3]:
            try:
                res = client.get(sitemap)
                if res.status_code != 200:
                    continue
                locs = re.findall(r"<loc>\s*(.*?)\s*</loc>", res.text, re.IGNORECASE | re.DOTALL)
                # Nested sitemap index
                if "<sitemapindex" in res.text.lower():
                    for nested in locs[:3]:
                        try:
                            nres = client.get(nested.strip())
                            if nres.status_code == 200:
                                for nl in re.findall(r"<loc>\s*(.*?)\s*</loc>", nres.text, re.IGNORECASE | re.DOTALL):
                                    push(nl.strip())
                        except Exception:  # noqa: BLE001
                            continue
                else:
                    for loc in locs:
                        push(loc.strip())
            except Exception:  # noqa: BLE001
                continue

        if len(discovered) >= max_pages:
            return discovered[:max_pages]

        # Homepage links
        try:
            home = client.get(base)
            if home.status_code == 200:
                soup = BeautifulSoup(home.text, "html.parser")
                for a in soup.find_all("a", href=True):
                    href = a["href"].strip()
                    if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                        continue
                    push(urljoin(base + "/", href))
        except Exception:  # noqa: BLE001
            pass

    return discovered[:max_pages]


# ---------------------------------------------------------------------------
# Page analysis
# ---------------------------------------------------------------------------

def analyze_page(url: str, html: str, status_code: int, headers: Optional[dict] = None) -> List[Dict[str, Any]]:
    """Returns technical findings for a single fetched page."""
    findings: List[Dict[str, Any]] = []
    if status_code >= 400:
        findings.append({"url": url, "category": "broken_link", "severity": _severity_for("broken_link"),
                         "detail": f"Page returned HTTP {status_code}."})
        return findings

    soup = BeautifulSoup(html or "", "html.parser")

    title_tag = soup.find("title")
    title_text = (title_tag.get_text(strip=True) if title_tag else "")
    if not title_text:
        findings.append({"url": url, "category": "missing_title", "severity": _severity_for("missing_title"),
                         "detail": "Page has no <title> element."})
    elif not (20 <= len(title_text) <= 70):
        findings.append({"url": url, "category": "title_length", "severity": _severity_for("title_length"),
                         "detail": f"Title is {len(title_text)} chars (target 20-70): '{title_text[:80]}'"})

    desc = soup.find("meta", attrs={"name": "description"})
    desc_text = (desc.get("content") or "").strip() if desc else ""
    if not desc_text:
        findings.append({"url": url, "category": "missing_meta_description", "severity": _severity_for("missing_meta_description"),
                         "detail": "Page has no meta description."})
    elif not (80 <= len(desc_text) <= 165):
        findings.append({"url": url, "category": "meta_description_length", "severity": _severity_for("meta_description_length"),
                         "detail": f"Meta description is {len(desc_text)} chars (target 80-165)."})

    h1s = soup.find_all("h1")
    if not h1s:
        findings.append({"url": url, "category": "missing_h1", "severity": _severity_for("missing_h1"),
                         "detail": "Page has no H1 heading."})
    elif len(h1s) > 1:
        findings.append({"url": url, "category": "multiple_h1", "severity": _severity_for("multiple_h1"),
                         "detail": f"Page has {len(h1s)} H1 headings (expected 1)."})

    canonical = soup.find("link", attrs={"rel": lambda v: v and "canonical" in v})
    if not canonical or not canonical.get("href"):
        findings.append({"url": url, "category": "missing_canonical", "severity": _severity_for("missing_canonical"),
                         "detail": "Page has no canonical link."})

    robots_meta = soup.find("meta", attrs={"name": "robots"})
    robots_content = (robots_meta.get("content") or "").lower() if robots_meta else ""
    if "noindex" in robots_content:
        findings.append({"url": url, "category": "noindex", "severity": _severity_for("noindex"),
                         "detail": "Page is marked noindex and cannot rank."})

    if not soup.find("html", attrs={"lang": True}):
        findings.append({"url": url, "category": "missing_lang", "severity": _severity_for("missing_lang"),
                         "detail": "<html> has no lang attribute."})

    ld_json = soup.find_all("script", type="application/ld+json")
    if not ld_json:
        findings.append({"url": url, "category": "missing_schema", "severity": _severity_for("missing_schema"),
                         "detail": "No JSON-LD structured data found (reduces GEO/AI citation eligibility)."})

    hreflangs = soup.find_all("link", attrs={"rel": lambda v: v and "alternate" in v and v is not None})
    hreflang_values = [l.get("hreflang") for l in hreflangs if l.get("hreflang")]
    if hreflang_values and "x-default" not in [str(h).lower() for h in hreflang_values]:
        findings.append({"url": url, "category": "hreflang", "severity": _severity_for("hreflang"),
                         "detail": "hreflang alternate set is missing an x-default entry."})

    images = soup.find_all("img")
    missing_alt = [img for img in images if not (img.get("alt") or "").strip()]
    if images and len(missing_alt) / max(1, len(images)) > 0.3:
        findings.append({"url": url, "category": "image_alt", "severity": _severity_for("image_alt"),
                         "detail": f"{len(missing_alt)}/{len(images)} images are missing alt text."})

    if len(html or "") > 2_000_000:
        findings.append({"url": url, "category": "large_page", "severity": _severity_for("large_page"),
                         "detail": f"HTML payload is {len(html) // 1024} KB (recommended < 2 MB)."})

    return findings


def check_links(base_url: str, links: List[str], max_checks: int = 40, timeout: float = 8.0) -> List[Dict[str, Any]]:
    """HEAD/GET-checks internal links for breakage and redirect chains."""
    findings: List[Dict[str, Any]] = []
    checked = 0
    with httpx.Client(timeout=timeout, follow_redirects=False, headers={"User-Agent": USER_AGENT}) as client:
        for link in links:
            if checked >= max_checks:
                break
            checked += 1
            try:
                resp = client.head(link)
                if resp.status_code in (405, 501) or resp.status_code >= 400:
                    resp = client.get(link)
                if resp.status_code >= 400:
                    findings.append({"url": link, "category": "broken_link", "severity": _severity_for("broken_link"),
                                     "detail": f"Internal link returns HTTP {resp.status_code}."})
                elif resp.status_code in (301, 302, 307, 308):
                    resolved = urljoin(link, resp.headers.get("location", ""))
                    trials = 0
                    current = resolved
                    while trials < 3:
                        trials += 1
                        hop = client.head(current)
                        if hop.status_code in (301, 302, 307, 308):
                            current = urljoin(current, hop.headers.get("location", ""))
                            continue
                        break
                    if trials >= 2:
                        findings.append({"url": link, "category": "redirect_chain", "severity": _severity_for("redirect_chain"),
                                         "detail": f"Link redirects through {trials} hops to {current}."})
            except Exception as e:  # noqa: BLE001
                findings.append({"url": link, "category": "broken_link", "severity": _severity_for("broken_link"),
                                 "detail": f"Link could not be reached: {type(e).__name__}"})
    return findings


def fetch_core_web_vitals(url: str) -> Dict[str, Any]:
    """Fetches Core Web Vitals from the PageSpeed Insights API (optional key)."""
    key = _cfg("PAGESPEED_API_KEY")
    params = {"url": url, "strategy": "mobile", "category": "performance"}
    if key:
        params["key"] = key
    try:
        with httpx.Client(timeout=60.0) as client:
            resp = client.get(PAGESPEED_ENDPOINT, params=params)
            if resp.status_code != 200:
                return {"configured": bool(key), "measured": False, "error": f"HTTP {resp.status_code}"}
            data = resp.json()
            lh = data.get("lighthouseResult") or {}
            audits = lh.get("audits") or {}
            metrics = {
                "performance_score": round(float((lh.get("categories") or {}).get("performance", {}).get("score") or 0) * 100),
                "lcp_ms": (audits.get("largest-contentful-paint") or {}).get("numericValue"),
                "cls": (audits.get("cumulative-layout-shift") or {}).get("numericValue"),
                "tbt_ms": (audits.get("total-blocking-time") or {}).get("numericValue"),
                "fcp_ms": (audits.get("first-contentful-paint") or {}).get("numericValue"),
                "inp_ms": (data.get("loadingExperience", {}).get("metrics", {}).get("INTERACTION_TO_NEXT_PAINT", {}) or {}).get("percentile"),
            }
            return {"configured": True, "measured": True, "url": url, "metrics": metrics}
    except Exception as e:  # noqa: BLE001
        return {"configured": bool(key), "measured": False, "error": str(e)}


def cwv_findings(vitals: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Converts CWV metrics into findings against Google's thresholds."""
    if not vitals.get("measured"):
        return []
    metrics = vitals.get("metrics") or {}
    url = vitals.get("url") or ""
    findings: List[Dict[str, Any]] = []

    lcp = metrics.get("lcp_ms")
    if lcp and lcp > 2500:
        findings.append({"url": url, "category": "core_web_vitals", "severity": "high",
                         "detail": f"LCP is {round(lcp)}ms (good threshold is < 2500ms)."})
    cls = metrics.get("cls")
    if cls and cls > 0.1:
        findings.append({"url": url, "category": "core_web_vitals", "severity": "high",
                         "detail": f"CLS is {round(cls, 3)} (good threshold is < 0.1)."})
    inp = metrics.get("inp_ms")
    if inp and inp > 200:
        findings.append({"url": url, "category": "core_web_vitals", "severity": "medium",
                         "detail": f"INP is {round(inp)}ms (good threshold is < 200ms)."})
    tbt = metrics.get("tbt_ms")
    if tbt and tbt > 600:
        findings.append({"url": url, "category": "core_web_vitals", "severity": "medium",
                         "detail": f"Total blocking time is {round(tbt)}ms (target < 600ms)."})
    return findings


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run_technical_audit(
    website_id: Optional[str],
    base_url: str,
    max_pages: Optional[int] = None,
    check_cwv: bool = True,
) -> Dict[str, Any]:
    """Crawls a site, produces findings, persists them, and returns a summary."""
    from storage.db import replace_technical_findings

    if not base_url:
        return {"configured": False, "findings": [], "error": "base_url is required"}

    try:
        cap = max_pages or int(getattr(config, "TECHNICAL_AUDIT_MAX_PAGES", 25) or 25)
    except (TypeError, ValueError):
        cap = 25
    cap = max(1, min(cap, 100))

    base = base_url.rstrip("/")
    urls = discover_urls(base, max_pages=cap)
    findings: List[Dict[str, Any]] = []
    internal_links: Set[str] = set()
    crawled = 0

    with httpx.Client(timeout=12.0, follow_redirects=True, headers={"User-Agent": USER_AGENT}) as client:
        for url in urls:
            try:
                resp = client.get(url)
            except Exception as e:  # noqa: BLE001
                findings.append({"url": url, "category": "broken_link", "severity": "high",
                                 "detail": f"Page could not be fetched: {type(e).__name__}"})
                continue
            crawled += 1
            findings.extend(analyze_page(url, resp.text, resp.status_code))
            if resp.status_code == 200:
                try:
                    soup = BeautifulSoup(resp.text, "html.parser")
                    for a in soup.find_all("a", href=True):
                        href = a["href"].strip()
                        if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                            continue
                        absolute = urljoin(url, href)
                        if _same_origin(absolute, base):
                            internal_links.add(_norm_url(absolute))
                except Exception:  # noqa: BLE001
                    pass

    # robots.txt presence
    try:
        with httpx.Client(timeout=8.0, follow_redirects=True, headers={"User-Agent": USER_AGENT}) as client:
            robots = client.get(f"{base}/robots.txt")
            if robots.status_code != 200 or not robots.text.strip():
                findings.append({"url": f"{base}/robots.txt", "category": "robots_txt", "severity": "medium",
                                 "detail": "robots.txt is missing or empty (no crawl directives/sitemap reference)."})
    except Exception:  # noqa: BLE001
        pass

    link_findings = check_links(base, sorted(internal_links - set(urls))[:60], max_checks=40)
    findings.extend(link_findings)

    vitals_summary: Optional[Dict[str, Any]] = None
    if check_cwv:
        vitals = fetch_core_web_vitals(base)
        vitals_summary = vitals
        findings.extend(cwv_findings(vitals))

    # De-duplicate findings (url + category + detail)
    deduped: List[Dict[str, Any]] = []
    seen_findings: Set[Tuple[str, str, str]] = set()
    for f in findings:
        key = (f.get("url") or "", f.get("category") or "", f.get("detail") or "")
        if key not in seen_findings:
            seen_findings.add(key)
            deduped.append(f)
    deduped.sort(key=lambda f: _SEVERITY_ORDER.get(f.get("severity") or "low", 9))

    replace_technical_findings(website_id, deduped)

    by_severity: Dict[str, int] = {}
    by_category: Dict[str, int] = {}
    for f in deduped:
        by_severity[f.get("severity") or "low"] = by_severity.get(f.get("severity") or "low", 0) + 1
        by_category[f.get("category") or "other"] = by_category.get(f.get("category") or "other", 0) + 1

    score = 100
    score -= by_severity.get("critical", 0) * 12
    score -= by_severity.get("high", 0) * 6
    score -= by_severity.get("medium", 0) * 3
    score -= by_severity.get("low", 0) * 1
    calc_score = max(0, min(100, score))

    result = {
        "configured": True,
        "website_id": website_id,
        "base_url": base,
        "pages_crawled": crawled,
        "pages_discovered": len(urls),
        "internal_links_checked": len(link_findings),
        "findings": deduped,
        "issues": deduped,
        "finding_count": len(deduped),
        "by_severity": by_severity,
        "by_category": by_category,
        "health_score": calc_score,
        "crawl_score": calc_score,
        "core_web_vitals": vitals_summary,
    }
    logger.info(
        f"Technical audit of {base}: {crawled} pages crawled, {len(deduped)} findings "
        f"({by_severity.get('critical', 0)} critical, {by_severity.get('high', 0)} high)."
    )
    return result


def get_site_health(website_id: Optional[str]) -> Dict[str, Any]:
    """Returns stored findings grouped for the Studio UI."""
    from storage.db import get_technical_findings

    findings = get_technical_findings(website_id, limit=1000)
    by_severity: Dict[str, int] = {}
    by_category: Dict[str, int] = {}
    for f in findings:
        by_severity[f.get("severity") or "low"] = by_severity.get(f.get("severity") or "low", 0) + 1
        by_category[f.get("category") or "other"] = by_category.get(f.get("category") or "other", 0) + 1
    score = 100
    score -= by_severity.get("critical", 0) * 12
    score -= by_severity.get("high", 0) * 6
    score -= by_severity.get("medium", 0) * 3
    score -= by_severity.get("low", 0) * 1
    final_score = max(0, min(100, score))
    return {
        "finding_count": len(findings),
        "by_severity": by_severity,
        "by_category": by_category,
        "health_score": final_score,
        "crawl_score": final_score,
        "findings": findings[:100],
        "issues": findings[:100],
    }
