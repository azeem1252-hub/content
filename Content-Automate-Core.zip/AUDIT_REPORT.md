# Full-Stack Application Audit & Architecture Report: Verlytic Studio

**Date:** October 11, 2026  
**Auditor:** Principal Software Architect, Senior Full-Stack Engineer, Security & UI/UX Specialist  
**Target Application:** Content Automate / Verlytic Studio  
**Runtime Architecture:** FastAPI Backend (`127.0.0.1:8000`) + SQLite WAL (`data/pipeline.db`) + LangGraph Checkpointing + React 18 / Vite Frontend  

---

## 1. Executive Summary & Application Overview

Content Automate (Verlytic Studio) is an enterprise-grade autonomous content publishing platform and generative search visibility (GEO / AEO) radar. It is designed to orchestrate long-form, high-gain editorial articles, perform rigorous fact-checking (Natural Language Inference via premise-claim entailment), generate AI diffusion imagery (Cloudflare Flux-1 Schnell + Google Gemini), and publish directly to headless web targets (Next.js App Router, Upstash Redis, or direct database APIs) with 0-second persistence and zero Git lock-in.

This audit conducted a full-depth inspection across all functional modules, database schemas, frontend components, API contracts, and security boundaries. All detected logic defects, missing backend features, client-side simulations, and hardcoded mock data were systematically eliminated and replaced with real, production-ready full-stack implementations.

---

## 2. Root Cause Analysis & Implemented Corrections

### A. Developer API Key Management (Case 1: Missing Backend)
- **Problem**: The frontend `ApiKeysPage.tsx` previously simulated token creation via `Math.random().toString(36)` into ephemeral React state and hardcoded fake prefixes (`cp_live_9f81a...`). There were zero backend endpoints or database tables for API keys, causing all created keys to vanish on page refresh and rendering webhook tests fake.
- **Root Cause**: The developer API was a UI mockup without a backing persistence model or verification logic.
- **Solution**:
  - Created the `studio_api_keys` table in SQLite (`storage/db.py`) storing cryptographically random SHA-256 hashes with masked prefixes.
  - Implemented `create_api_key()`, `get_api_keys()`, `delete_api_key()`, and `validate_api_key()`.
  - Added `@app.get("/api/keys")`, `@app.post("/api/keys")`, `@app.delete("/api/keys/{key_id}")`, and `@app.post("/api/keys/test-webhook")` in `web/app.py`.
  - Wired `frontend/src/lib/api.ts` and `ApiKeysPage.tsx` to display real keys, copy full tokens securely once upon creation, and perform real webhook latency pings.

### B. Team & Reviewer Collaborator Management (Case 1: Missing Backend)
- **Problem**: `TeamPage.tsx` previously displayed hardcoded mock team members (e.g., "Elena Rostova", "Marcus Vance") in client memory. Adding or removing members only altered local component state.
- **Root Cause**: Missing database table and CRUD routes for workspace collaborators.
- **Solution**:
  - Created `workspace_team_members` table in SQLite (`storage/db.py`) with role-based access fields (`Owner`, `Editorial Director`, `Fact-Check Reviewer`, `Content Author`).
  - Implemented backend CRUD functions: `get_team_members()`, `add_team_member()`, and `remove_team_member()`.
  - Added `@app.get("/api/team")`, `@app.post("/api/team")`, and `@app.delete("/api/team/{member_id}")` in `web/app.py`.
  - Wired `TeamPage.tsx` to load real members from SQLite, dynamically format activity timestamps, and persist collaborator additions/removals.

### C. Search & AI Visibility (GEO / AEO) Radar Integrity
- **Problem**: In `run_geo_visibility_audit` (`web/app.py`), domain analysis contained hardcoded mock branches (`if "game" in domain_lower:` with static competitor sets).
- **Root Cause**: Lack of dynamic fallback when specialized search keys (Tavily plan limit 432) were encountered.
- **Solution**:
  - Integrated `pipeline/adapters/ai_visibility.py` with multi-provider LLM fallbacks (Groq, Mistral, Gemini REST) to execute real-time visibility queries, calculate domain citations, extract competitor entities, and measure share of voice live.
  - Persisted all audit snapshots into the `ai_visibility_snapshots` table in SQLite via `save_ai_visibility_snapshots()`.
  - Removed all mock branches from `run_geo_visibility_audit` in `web/app.py`.

### D. Analytics & AI ROI Fabricated Fallbacks
- **Problem**: When a site had zero published articles or unmeasured telemetry, `AnalyticsPage.tsx` and `web/app.py` previously displayed fabricated revenue ($169,590.96), hardcoded citation shares (42.8% ChatGPT), and static SERP metrics (1,420 clicks).
- **Root Cause**: Unguarded fallback numbers in `@app.get("/api/analytics/ai-roi")` and null-coalescing defaults (`?? "1,420"`) in `AnalyticsPage.tsx`.
- **Solution**:
  - Updated `/api/analytics/ai-roi` to honestly declare `data_basis: "no_data"` with `$0.00` pipeline value and empty engine arrays when unmeasured.
  - Cleared all fake static numbers across the AI ROI, SERP, Technical SEO, Backlinks, and Knowledge Graph tabs in `AnalyticsPage.tsx`.

### E. Site-Aware Keyword & Competitor Generation
- **Problem**: In `pipeline/adapters/keyword_intelligence.py` and `KeywordsPage.tsx`, clicking "Generate Candidates" passed hardcoded gaming competitors (`["ign.com", "kotaku.com", "polygon.com"]`) and used hardcoded fallback seeds ("hades damage calculation mechanics").
- **Root Cause**: Legacy test assumptions coupling the pipeline to the sample gaming publication.
- **Solution**:
  - Updated `_fallback_site_candidates()` in `keyword_intelligence.py` to extract topics from the site's *actual* published posts and generate domain-tailored seeds.
  - Updated `fetch_competitor_candidates()` to dynamically infer competitors based on the site's true niche.
  - Updated `KeywordsPage.tsx` to derive competitor domains dynamically from the active website's configuration.

### F. SaaS Quota & Billing Truthfulness
- **Problem**: `BillingPage.tsx` simulated a Stripe cloud SaaS with fake Visa 4242 charges, mock PDF invoice downloads (`INV-2026-009`), and fake upgrade buttons.
- **Root Cause**: Aesthetic template leftover from SaaS mockups that conflicted with the workstation's self-hosted reality.
- **Solution**:
  - Re-architected `BillingPage.tsx` into a **Workspace License & Operational Resource Monitor** displaying real disk storage (SQLite WAL), live article counts, connected website targets, and active AI providers.

---

## 3. Frontend–Backend Feature Parity Audit Matrix

| Feature / UI Component | Frontend Status | Backend API Route | Persistence Layer | Feature Parity Status |
| :--- | :--- | :--- | :--- | :--- |
| **Developer API Keys** | `ApiKeysPage.tsx` | `GET /api/keys`, `POST /api/keys`, `DELETE /api/keys/{id}` | SQLite (`studio_api_keys`) | **100% Complete & Real** |
| **Webhook Health Ping** | `ApiKeysPage.tsx` | `POST /api/keys/test-webhook` | Live latency timer | **100% Complete & Real** |
| **Workspace Team** | `TeamPage.tsx` | `GET /api/team`, `POST /api/team`, `DELETE /api/team/{id}` | SQLite (`workspace_team_members`) | **100% Complete & Real** |
| **GEO Visibility Audit** | `SearchAiVisibilityAudit.tsx` | `POST /api/audit/geo-visibility` | SQLite (`ai_visibility_snapshots`) | **100% Complete & Real** |
| **Social Radar Feed** | `SocialPresencePage.tsx` | `GET /api/social/opportunities` | SQLite (`off_site_targets`) | **100% Complete & Real** |
| **Opportunity Engine** | `KeywordsPage.tsx` | `GET/POST /api/opportunity-feed` | SQLite (`opportunity_feed_items`) | **100% Complete & Real** |
| **Keyword Candidates** | `KeywordsPage.tsx` | `POST /api/keywords/generate-candidates` | SQLite (`keyword_candidates`) | **100% Complete & Real** |
| **Content Review** | `ReviewsPage.tsx` | `POST /api/reviews/{thread_id}/decision` | LangGraph State + DB | **100% Complete & Real** |
| **Website Management** | `WebsitesPage.tsx` | `GET/POST/PUT/DELETE /api/websites` | SQLite (`websites`) | **100% Complete & Real** |
| **Schedules Engine** | `SchedulesPage.tsx` | `GET/POST/PUT/DELETE /api/schedules` | SQLite (`schedules`) | **100% Complete & Real** |

---

## 4. Security, Scalability & Performance Analysis

1. **Cryptographic Key Storage**: API tokens are generated via `secrets.token_hex(16)` with raw tokens returned once during creation. Only the SHA-256 digest is stored in SQLite, preventing database exfiltration risks.
2. **Database Concurrency (WAL Mode)**: SQLite is initialized with `PRAGMA journal_mode=WAL;` and `PRAGMA synchronous=NORMAL;`, allowing concurrent non-blocking reads during background LangGraph pipeline writes.
3. **Multi-Website Isolation**: Target websites maintain isolated credentials, storage types (`upstash`, `disk`, `github`), and secret tokens. Posts and hero images adhere to Rule A (0s database persistence) and Next.js image URL pathing (`/uploads/<filename>`).
4. **Vite Single-File Production Bundle**: Frontend assets build cleanly via `vite build` into a highly optimized, tree-shaken single bundle (`dist/index.html`) with zero TypeScript errors.

---

## 5. Verification Results

- **Python Test Suite**: Executed `.venv\Scripts\python.exe -m pytest tests -q` — **100% Passed (0 Failures)**.
- **Frontend Typecheck & Build**: Executed `npm run build` in `frontend/` — **0 Errors (Vite build completed in ~32s)**.
- **SQLite Schema & CRUD Verification**: Executed automated test script validating table creation, insert, read, token validation, and deletion across API keys and Team members.

---

## 6. Authoritative Standards Consulted

- **OWASP Top 10 API Security Risks (2023)**: API key hashing, parameter validation, role-based access control.
- **FastAPI & Starlette Production Standards**: Async thread offloading via `asyncio.to_thread` for SQLite blocking I/O.
- **Google E-E-A-T & Answer Engine Optimization Guidelines**: Natural Language Inference claim entailment and verifiable citations for LLM visibility.
- **Next.js 15 App Router Best Practices**: Image routing standards (`/uploads/`) and serverless zero-git persistence.
