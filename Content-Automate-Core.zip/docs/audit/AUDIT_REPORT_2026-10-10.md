# Forensic Audit Report — Content Pipeline Agent ("Verlytic")

**Date:** 2026-10-10
**Scope:** Full first-party repository (Python FastAPI/LangGraph backend + React/Vite frontend)
**Method:** Static inspection + executed tests, typecheck, build, and offline smoke test
**Status:** Diagnostics only. No application code was modified.

---

## A. Executive Summary

The project is a large (~59,600 lines of first-party Python across 137 files, plus ~145
TypeScript/TSX files) autonomous content-publishing platform. The core architecture is
coherent and unusually well thought out in places: a durable LangGraph pipeline with a
capped human-review loop, a storage-strategy rule that avoids unnecessary Git commits when
a target persists data itself, fail-closed Slack signature verification, loopback-only
studio access, parameterized SQLite access, a cryptographically random bearer-token
generator, and a passing resume/publish/repurpose smoke test.

The most important problems are **not** in the pipeline's happy path. They are in
**verification honesty, the test harness, and feature-surface truthfulness**:

1. **The default test suite hangs indefinitely.** Two test files perform real network I/O
   despite not being marked `live`, so `pytest` never terminates. A separate non-live test
   fails. The suite therefore cannot be used as a reliable gate.
2. **The frontend does not typecheck.** `tsc --noEmit` reports 100 errors, including three
   that are behaviorally real (a property that does not exist, an invalid drawer tab, and
   null-dereference risks). The build tool (`vite build`) skips type checking, so these
   ship silently.
3. **Several user-visible SaaS surfaces are cosmetic.** Billing, Team, API Keys, and Auth
   pages are reachable in the UI but have no backend endpoints and use hardcoded data.
4. **The documented Next.js editorial target is incomplete.** `gaming-editorial/` contains
   only `public/` — no app, no `package.json`, no `next.config.ts` — so the AGENTS.md
   rewrite rule and `npm run dev` workflow cannot hold.

There is no user authentication: the studio is a single-operator tool gated only by a
loopback/origin middleware. That is a defensible design **only while** `ALLOW_REMOTE_ACCESS`
stays false and the host is trusted; the same flag that exposes webhooks also exposes the
entire control plane, including plaintext API keys, GitHub tokens, and website bearer tokens.

---

## B. Repository Coverage Report

| Area | Inspected | Method | Notes |
|---|---|---|---|
| `main.py`, `config.py`, `requirements.txt`, `pytest.ini`, `.env.example`, `README.md`, `AGENTS.md` | Full | Read | Entry points, config loader, deps |
| `storage/db.py` (4,405 lines) | Substantial windows + targeted search | Read/search | Schema, migrations, CRUD, SQL patterns |
| `web/app.py` (6,846 lines) | Targeted windows + route/endpoint inventory | Read/search | Middleware, 172 routes, Slack webhook |
| `pipeline/graph.py`, `state.py`, `llm_client.py`, `scheduler.py`, `nodes/publish_node.py` | Full/major | Read | Orchestration, LLM router, scheduler, publish |
| `pipeline/nodes/*` (other) | Targeted | Read/search | outline/draft/audit/aeo/review |
| `pipeline/adapters/*` (70 files) | Sampled (aeo_engine, question_naturalizer, codex_image, website_client, etc.) | Read/search | Not all 70 read line-by-line |
| `frontend/src/**` (145 files) | Targeted + typecheck + build | Read/search/exec | Page wiring, API client, Drawer nav |
| `tests/**` (45 files) | Executed per-file + failure/hang isolation | Exec | See §J |
| `gaming-editorial/` | Listed | Exec | Only `public/` present |
| `landing_ref/`, `scratch/`, `*.zip` | Identified only | List | Generated/working artifacts; not audited |
| `.venv/`, `node_modules/`, `__pycache__/`, `dist/` | Excluded | — | Third-party/generated |

**Not fully inspected:** the majority of the 70 adapter modules, all Jinja templates
(if any remain), CSS, and most of the 6,846-line `web/app.py`. Findings below are limited to
what was actually traced; absence of a finding is not evidence of absence.

**Execution environment note:** the active virtualenv resolved to
`C:\Users\azeem\OneDrive\Desktop\Content Automate\.venv`, not the inspected directory — the
project appears to have been copied from another machine. Commands were run from the local
project root.

---

## C. Architecture and Data-Flow Report

```
CLI (main.py) ─┬─ studio ─> scripts/run_studio.py ─> uvicorn(web.app:app, :8000)
               ├─ pipeline ─> scripts/run_pipeline.py ─> pipeline_manager.start_pipeline()
               ├─ slack ────> scripts/run_slack_listener.py
               ├─ verify ───> scripts/smoke_test.py
               ├─ opportunities / decay / eval ─> pipeline/adapters/*
               └─ (all) ──> storage.db.init_db()  (SQLite, WAL)

web.app lifespan ─> init_db + automation_scheduler + performance_harvest_scheduler
                    + pipeline_manager.prune_stale_checkpoints()

LangGraph: START→outline→draft→fact_check→aeo→article_studio→audit→image→review_gate
           review_gate --approved--> publish --ok--> repurpose --> END
           review_gate --changes_requested (≤3)--> draft
           review_gate --rejected/other--> END
           publish --failed--> END

State: ContentState TypedDict (checkpointed). SQLite: websites, schedules, posts,
pipeline_runs, + v5 measurement tables. Durable checkpointer file is separate.

Request trust boundary: all HTTP enters web.app. `/api/slack/*` is exempt from the
loopback guard and verifies X-Slack-Signature (fails closed). Everything else requires a
loopback client host, a loopback Host header, and a loopback/absent Origin.
```

**Dependency map:** `web.app` → `pipeline.pipeline_manager`, `pipeline.scheduler`,
`pipeline.harvest`, many adapters; `pipeline_manager` → `pipeline.graph` → nodes → adapters →
`storage.db`, `config`. `config` is a mutable global module re-read via `reload_config()`.

**Critical execution paths:** (1) pipeline run lifecycle incl. interrupt/resume; (2)
scheduled dispatch; (3) publish → storage-strategy evaluation → optional Git commit; (4)
Slack interactive approval; (5) settings write to `.env`.

**Trust boundaries / failure points:** the unauthenticated studio HTTP surface; the
`.env` file as both config store and secret store; the GitHub push path; the local
filesystem discovery used during publish.

---

## D. Critical Findings

### AUD-01 — Default test suite hangs (P1, confirmed by execution)
`python -m pytest` never terminates. Per-file isolation shows two files exceed a 40 s
timeout (exit 124):
- `tests/test_keyword_intelligence.py::test_four_sources_and_merged_pipeline` (network SERP/competitor fetch)
- `tests/test_universal_settings_and_codex.py::test_codex_endpoints` (calls `/api/agent/test-codex` with an empty token)

Neither is marked `@pytest.mark.live`, yet both perform live network calls. There is no
per-test timeout (`pytest-timeout` is not installed). CI or a developer running `pytest`
hangs with no diagnostic. Additionally `tests/test_aeo_a5b.py` fails (AUD-02).
**Root cause:** network-dependent tests outside the `live` marker, no timeout guard.

### AUD-02 — Failing AEO question-naturalizer test (P2, confirmed by execution)
`tests/test_aeo_a5b.py::TestQuestionDiscovery::test_keyword_to_question_plain_keyword` fails:
```
assert _keyword_to_question("project management software") == "What is project management software?"
E  AssertionError: assert 'How does project management software operate in production?' == ...
```
`pipeline/adapters/question_naturalizer.py::naturalize_question` defaults any non-question
phrase with **more than two words** to `"How does {X} operate in production?"`; only ≤2-word
phrases become `"What is {X}?"`. Implementation and test disagree.
**Impact:** question/answer-target generation produces stylistically wrong, repetitive PAA
questions for 3+ word topics; the offline test gate is red.

### AUD-03 — Frontend does not typecheck; real type errors ship (P1, confirmed by execution)
`cd frontend && npx tsc --noEmit` → **100 errors, exit 2**. 82 are unused-variable noise, but
these are functional:
- `ArticleDrawer.tsx:1030–1077` reads `article.factCheckClaims`, which is **not** a member of
  `ContentItem` and is **not** produced by any endpoint (`web/app.py` has no
  `fact_check_claims`). The fact-check-claims UI path is effectively dead/near-dead.
- `OverviewPage.tsx:538,547` calls `openInspector(pub.id, "preview")`, but `"preview"` is not a
  member of `DrawerTab` (`nav.tsx:22`). Clicking a published article's title/View opens the
  inspector at the wrong/default tab.
- `ArticleDrawer.tsx:2054–2090` dereferences possibly-null `article` / possibly-undefined
  `article.draft`.
**Root cause:** `npm run build` is `vite build` (esbuild, no type checking); there is no
`typecheck` script and no CI type gate.

### AUD-04 — Documented Next.js editorial target is incomplete (P2, confirmed by inspection)
`gaming-editorial/` contains only `public/` (llms.txt, uploads, diagrams). There is no
`package.json`, `app/`, `content/posts`, or `next.config.ts`. AGENTS.md §1–3 states the
target runs via `npm run dev` and that `gaming-editorial/next.config.ts` must maintain a
`/static/uploads/:path*` → `/uploads/:path*` rewrite. That file does not exist here, so the
documented dev workflow and the rewrite compatibility guarantee are unverifiable/absent in
this checkout. The directory has also accumulated many `smoke-test-article-*.jpg` files under
`public/uploads/`, evidence that publish-time image sync writes there.

### AUD-05 — Cosmetic SaaS surfaces with no backend (P2, confirmed by inspection)
`AppShell.renderPage` renders `BillingPage`, `TeamPage`, `ApiKeysPage`, and `AuthPage` for the
`billing`, `team`, `apikeys`, and `login` routes, and they are imported. None has a backing
endpoint: the studio's 172 routes contain no `/api/billing`, `/api/team`, `/api/auth`,
`/api/signup`, or `/api/keys`. `BillingPage` shows hardcoded invoices and mutates only local
state ("Plan Updated" toast); `TeamPage` ships four hardcoded members; `AuthPage` is
decorative (no auth gate — the shell does not require login). See §L.

### AUD-06 — Unauthenticated control plane; secrets at rest and over the API (P1/P2, confirmed by inspection)
There is no authentication or authorization. Safety rests entirely on the middleware in
`web/app.py`: loopback client, loopback Host, loopback/absent Origin, plus
`ALLOW_REMOTE_ACCESS` (default false). If `ALLOW_REMOTE_ACCESS=true` (documented as the way to
let a remote Slack install reach webhooks), the **entire** unauthenticated API becomes
reachable — settings read/write (which returns provider keys), pipeline dispatch, publishing,
and `GET /api/websites/{id}/secret-token`, which returns a website's plaintext bearer token.
Website `secret_token` and `github_token` are stored unencrypted in SQLite
(`storage/db.py` `websites` table). `.env` (which stores all provider keys) is gitignored and
not tracked — good — but is a plain file readable by any local process.
**Impact:** acceptable for a strictly-local single operator; a serious exposure the moment the
studio is tunneled or `ALLOW_REMOTE_ACCESS` is enabled, with no second factor.

### AUD-07 — Publish-time local directory discovery is broad and writes outside the target (P2, confirmed by inspection)
`publish_node._discover_local_nextjs_dirs` scans `BASE_DIR.parent`, `BASE_DIR`,
`~/OneDrive/Desktop`, `~/Desktop`, and `~/Projects`, matching any directory with
`content/posts`, an `app/api/posts`, a `next.config.*`, or `public/uploads`. For a
`localhost`/`127.0.0.1` target it treats **every** discovered project as a match
(`is_local_dev and (has_api_route or has_posts_dir or has_public_uploads)`). Image handling
(`_sync_hero_image_to_local_targets`, `prerender_and_publish_diagrams`) then copies files into
all matched directories; the non-local Git path (`_sync_local_nextjs_repo`) additionally writes
`content/posts/*.json`/`*.mdx` and attempts commits in all matched clones.
**Impact:** personal-directory scanning; article/asset files written into unrelated local
projects; ambiguous git working-tree state. Mitigated partially by only staging
`content/posts/` + `public/uploads/` (matches AGENTS.md rule) and by branch-freshness checks,
but the discovery breadth itself is unsafe on a multi-project machine.

---

## E. Complete Issue Register

| ID | Title | Sev | Confidence | Category | Files | Root cause | Impact | Fix | Verify |
|---|---|---|---|---|---|---|---|---|---|
| AUD-01 | Default pytest run hangs | P1 | Executed | Test/CI | test_keyword_intelligence.py, test_universal_settings_and_codex.py | Network calls outside `live` marker; no per-test timeout | Suite unusable as a gate; CI hangs | Mark live/network tests; add pytest-timeout | `pytest` completes; `timeout 120 pytest` |
| AUD-02 | AEO naturalizer test fails | P2 | Executed | Logic | question_naturalizer.py, test_aeo_a5b.py | >2-word default always "How does…operate"; test expects "What is…" | Wrong PAA questions; red gate | Align function or test | `pytest tests/test_aeo_a5b.py` |
| AUD-03 | Frontend typecheck fails | P1 | Executed | Frontend/Contract | ArticleDrawer.tsx, OverviewPage.tsx, nav.tsx | No type gate; build uses esbuild | Dead fact-check UI; wrong drawer tab; null derefs | Fix types; add `tsc --noEmit` script/gate | `npx tsc --noEmit` exits 0 |
| AUD-04 | `gaming-editorial/` not a runnable Next.js app | P2 | Static | Config/Docs | gaming-editorial/** | Only `public/` present | Documented dev flow & rewrite rule don't hold | Restore app skeleton or correct docs | `npm run dev` in dir |
| AUD-05 | Billing/Team/API-keys/Auth are cosmetic | P2 | Static | Feature reality | AppShell.tsx, BillingPage.tsx, TeamPage.tsx, ApiKeysPage.tsx, AuthPage.tsx | No backend; hardcoded/ local state | Misleading product surface | Implement or clearly label/hide | Click flows hit real APIs |
| AUD-06 | No auth on control plane; plaintext secrets | P1/P2 | Static | Security | web/app.py middleware, storage/db.py | Single-operator design; loopback only | Full takeover if remote access enabled | Add auth if ever exposed; encrypt secrets; never return tokens over HTTP | Attempt non-loopback access |
| AUD-07 | Publish discovery scans/writes outside target | P2 | Static | Safety/Data | publish_node.py | Broad search roots + local-dev catch-all | Writes into unrelated local repos | Restrict to explicit configured target | Publish with unrelated Next.js project present |
| AUD-08 | Image engine order drift vs docs | P3 | Static | Config/Docs | config.py, AGENTS.md, .env.example | Three differing orders | Operator confusion | Reconcile | Read defaults |
| AUD-09 | Unpinned deps, no Python lock, no type script | P2 | Static | Reproducibility | requirements.txt, frontend/package.json | All `>=`; no lock; no `typecheck` | Non-reproducible installs; type errors ship | Pin/lock; add typecheck script | Fresh install reproduces |
| AUD-10 | Broad `except Exception: pass` (103 sites) | P2 | Static | Reliability | config.py, storage/db.py, publish_node.py, topic_researcher.py, +more | Defensive swallowing | Silent failures; hard diagnosis | Log at minimum; narrow | Introduce a failure and see it surface |
| AUD-11 | 1.9 MB single-file frontend bundle | P3 | Executed | Performance | vite.config.ts (singlefile) | Everything inlined into index.html | No code-splitting/cache reuse; slow first load | Drop single-file build for production | Measure bundle |
| AUD-12 | No offline coverage for web API/scheduler/git path | P2 | Executed | Testing | test_dashboard_api.py (100% live), no scheduler/publish tests | Coverage gap | Regressions undetected | Add offline tests with fakes | Coverage report |
| AUD-13 | `.env.example` `[TEMPLATE]` header | P3 | Static | Config | .env.example | Not valid dotenv syntax | Parse warning/confusion | Remove/comment it | `load_dotenv` clean |
| AUD-14 | Model defaults possibly nonexistent | P3 | Unverified | AI | config.py, llm_client.py | Hardcoded model ids | Calls may 404 in real use | Verify with a live call | `pytest -m live` provider check |
| AUD-15 | Schema/IndexNow/llms.txt failures swallowed on publish | P2 | Static | Workflow | publish_node.py | try/except logs warning only | "Published" while notifications silently skip | Surface status; surface in run state | Force adapter failure |

---

## F. Workflow Audit

| Workflow | Intended | Actual / Issues | Coverage |
|---|---|---|---|
| Manual dispatch → review → publish | Outline→…→review→publish→repurpose | Graph edges correct; revision loop capped at 3 (`MAX_REVISIONS`); publish failure skips repurpose (`route_after_publish`). | Smoke test (offline) PASSES; no offline full-graph test |
| Interrupt/resume via Slack | Pause at review_gate, resume on signed callback | `slack_interactive_endpoint` verifies signature and timestamp, fails closed without secret. Good. | Only live tests exercise end-to-end |
| Scheduled dispatch | Fire due schedules, advance cadence only on success | Scheduler triggers first, advances `next_run_at` after; `_in_flight` de-dupes; 30 s loop. Sound. | No offline tests |
| Publish storage strategy | DB/Upstash → no git; pure serverless → git commit | Implemented and matches AGENTS.md intent. Local-dev path reconciles `is_local_dev`. | tests/test_multi_website_publishing passes |
| Post-publish notifications | Schema + IndexNow + llms.txt | All three wrapped in one try/except; failures are only logged (`AUD-15`). | Not covered |
| Settings save | Write `.env`, update process env, reload | Implemented with lock, rolling backups, placeholder-guard. Good. | tests/test_universal_settings... but that file hangs (AUD-01) |

**Missing/incorrect steps found:** published-article "View" opens the wrong drawer tab
(AUD-03). No workflow verifies the *rendered published page* after publish (post-publish
checks exist in CMS path but no end-to-end assertion in tests).

---

## G. Security Report

**Confirmed protections (positive):**
- Loopback-only middleware with DNS-rebinding Host check and Origin/CSRF check.
- Slack interactive webhook fails **closed** when no signing secret; HMAC + timestamp window.
- Bearer tokens generated via `secrets.token_hex`; timing-safe comparison in the generated
  Next.js snippet.
- SQLite access is parameterized; the only f-string SQL (`count_rows`) uses a whitelist.
- `.env`, `*.db`, `.sqlite`, and `gaming-editorial/` are gitignored; no secrets found in
  tracked files.

**Risks:**
- **No authentication** (AUD-06). `ALLOW_REMOTE_ACCESS=true` exposes the whole control plane,
  including `GET /api/websites/{id}/secret-token` (plaintext) and settings endpoints that
  return configured keys.
- **Secrets at rest in plaintext** (SQLite + `.env`). No encryption, no scoping.
- **Broken access control at the website level:** the sole guard is
  `resolve_run_website`, which refuses to fall back to the default site when an unknown
  `website_id` is given (good), but there is no per-caller authorization because there are no
  callers/identities.
- **Path/side-effect surface:** publish scans home directories and can write into unrelated
  projects (AUD-07).
- **Prompt injection:** research/SERP/CMS content flows into LLM prompts. The preview renderer
  escapes raw HTML before markdown conversion (good), but no test demonstrates a hardened
  prompt boundary; treat as "unverified mitigation."

No exploit against a live remote target was attempted. No secret values are reproduced here.

---

## H. AI / Content Quality Report

- **Provider router (`llm_client.py`) is solid:** per-request timeout, transient-vs-permanent
  error classification by status code then text, bounded exponential backoff (`max_retries`),
  and cross-provider fallback when the primary is exhausted.
- **Config reload per model construction:** `get_chat_model` calls `config.reload_config()`
  on every invocation (re-reads `.env`). Correct but repeated disk I/O and global mutation on
  the hot path; consider caching with explicit invalidation.
- **Model identifiers are unverified** (AUD-14): e.g. `gemini-3.1-flash-image-preview`,
  `qwen/qwen3.8-27b`, `ministral-14b-latest`. These must be confirmed against live providers;
  an invalid id degrades to fallback or failure.
- **Question quality:** the naturalizer's >2-word default produces formulaic
  "How does X operate in production?" questions (AUD-02), weakening PAA/AEO output.
- **Grounding/fact-check:** the pipeline has fact_check and AEO nodes and stores
  `verification_reports`, but the dashboard's claim list reads a field (`factCheckClaims`)
  that no endpoint returns (AUD-03), so operators cannot see claims where expected.
- **No hallucination/citation evaluation tests** exist offline (only `eval_experiments`
  helpers + a DiD calculator). Prove-or-flag behavior of research adapters was not executed
  (network).

---

## I. Integration and Data-Integrity Report

- **API contract drift:** frontend `ContentItem.factCheckClaims` vs backend absence
  (`fact_check_claims`). Confirmed by typecheck.
- **Route alignment:** a normalized comparison of the 172 defined routes against ~146
  frontend-called paths found no genuinely missing endpoint (apparent gaps were query-string
  template concatenations), so the API surface is largely consistent.
- **Database:** schema is broad with additive migrations guarded by `PRAGMA table_info`;
  WAL + `busy_timeout=15000` reduce lock contention; foreign keys enabled. No missing-index
  hot spots identified in the review window. `resolution`-style multi-site isolation relies on
  `website_id` columns without DB-level FK on most v5 tables.
- **Time handling:** helper `_utcnow_iso` and `_normalize_iso_utc` standardize UTC with `Z`,
  reducing client misparse. Good.
- **External integrations** (GSC/GA4/SERP/AI-visibility/backlink/pagespeed/embeddings/CMS)
  were not executed; adapters are written to report "unconfigured" rather than fabricate, but
  this claim was not verified by running them.

---

## J. Test and Build Report (executed commands)

| Command | Result |
|---|---|
| `python -m pytest -q` | **Timed out (>300 s)** — hangs (AUD-01) |
| `pytest <file> -q` per file | 40 files: 34 pass, 1 fail (`test_aeo_a5b.py`), 2 hang (exit 124), 7 collect 0 (all `@pytest.mark.live`) |
| `python main.py verify` | **PASS** — interrupt, revision loop, publish+repurpose, resume stability, fail-closed resume |
| `cd frontend && npx tsc --noEmit` | **FAIL** — 100 errors (82 unused; TS2339/TS2345/TS18047 functional) |
| `cd frontend && npm run build` | **PASS** — 2393 modules, single `dist/index.html` 1,914.99 kB (gzip 596.99 kB), 28 s |
| `git ls-files` secret scan | No committed secrets/databases found |

**Files contributing zero offline tests (100% live-marked):** `test_langgraph_pipeline.py`,
`test_dashboard_api.py`, `test_end_to_end.py`, `test_codex_image.py`,
`test_content_agents.py`, `test_random_image.py`, `test_slack_enriched.py`.

**Missing test categories:** scheduler timing, pipeline_manager concurrency/SSE, publish Git
path (local + Contents API), studio security middleware, `count_rows`/SQL invariants, Slack
signature rejection, AI fallback/eval.

---

## K. Architecture and Maintainability Report

- **Strengths:** clear node separation; config centralized with declared measurement-key
  table (`_MEASUREMENT_KEYS`) to avoid drift; storage strategy centralized in `publish_node`;
  checkpointer serialization allowlist; capped revision loop.
- **Concerns:**
  - Very large modules (`web/app.py` 6,846; `storage/db.py` 4,405; `article_model.py` 2,462)
    mixing routing, schemas, business logic, and I/O — high change risk.
  - Duplicate/parallel UI component trees (`components/ui/*` and `components/*`, plus a
    verbatim `landing_ref/` copy of the landing components).
  - Pervasive broad exception swallowing (AUD-10) hides integration failures.
  - Global mutable `config` module updated at runtime makes reasoning about a request's
    effective config harder.
  - Unpinned dependencies + no Python lock (AUD-09).

---

## L. Feature Reality Matrix

| Feature | Classification | Evidence |
|---|---|---|
| LangGraph pipeline (outline→…→repurpose) | Verified working (offline smoke) | `main.py verify` PASS |
| Human review gate + capped revision loop | Verified working | smoke test phases 1–2; `graph.py` router |
| Slack interactive approve/reject | Implemented but unverified end-to-end | endpoint + signature verified statically; no test run |
| Multi-website publish isolation | Verified working | `test_multi_website_publishing.py` passes |
| Storage-strategy (DB/Upstash vs Git) | Implemented; partially verified | `publish_node` + tests; live publish not run |
| CMS adapters (A5d) | Implemented but unverified | `test_cms_publishing_a5d.py` passes offline with fixtures only |
| Hero image engines (Cloudflare/Gemini/Codex/Tavily) | Blocked by configuration / unverified | unit tests pass; live generation not run |
| Opportunity feed / decay / DiD eval | Verified working (offline) | respective tests pass; CLI commands exist |
| Keywords, AEO, SEO linter, schema | Verified working (offline unit) | tests pass |
| Billing / Team / API Keys | Mocked or simulated | hardcoded data; no endpoints (AUD-05) |
| Auth / login | Mocked or simulated | decorative page; no auth state (AUD-05) |
| `gaming-editorial/` Next.js target | Missing | only `public/` present (AUD-04) |
| Frontend type safety | Broken | tsc 100 errors (AUD-03) |
| Scheduler autonomous dispatch | Implemented but unverified | no tests; logic inspected |
| Performance harvest / GSC / GA4 / SERP / AI visibility | Blocked by configuration | adapters report "unconfigured"; not executed |

---

## M. Prioritized Remediation Roadmap

**1. Immediate (unblock verification)**
- Mark network-dependent tests `live` and add `pytest-timeout` so `pytest` terminates
  (AUD-01). Resolve or correct the AEO naturalizer expectation (AUD-02).
- Fix the three functional TypeScript errors and add a `typecheck` script + gate (AUD-03).

**2. High priority (security & reliability)**
- Decide the exposure posture: if the studio can ever leave loopback, add authentication
  before `ALLOW_REMOTE_ACCESS` is usable; stop returning plaintext tokens over HTTP; consider
  encrypting stored secrets (AUD-06).
- Constrain publish-time directory discovery to the explicitly configured target; remove
  `~/Desktop`/`~/Projects` scanning and the local-dev catch-all (AUD-07).
- Surface post-publish notification failures instead of logging only (AUD-15).

**3. Functional / workflow**
- Implement or clearly label Billing/Team/API-Keys/Auth (AUD-05).
- Restore the `gaming-editorial/` Next.js skeleton or correct AGENTS.md/README (AUD-04).

**4. Testing & observability**
- Add offline tests: web API (non-live), scheduler, publish Git path (local + Contents API),
  security middleware, Slack signature rejection, LLM fallback (AUD-12). Begin replacing
  `except Exception: pass` with logged, narrowed handling (AUD-10).

**5. Architecture & performance**
- Split `web/app.py` / `storage/db.py`; remove duplicated component trees; reconsider the
  1.9 MB single-file bundle (AUD-11); cache config reload off the hot path.

**6. Longer-term**
- Verify all model identifiers and provider behaviors with a controlled `-m live` suite
  (AUD-14); pin/lock Python deps (AUD-09).

---

## N. Final Readiness Assessment

| Dimension | Rating | Basis |
|---|---|---|
| Local development readiness | **Partially Ready** | Backend runs; smoke test passes. Frontend typecheck fails; target site incomplete. |
| Test readiness | **Not Ready** | Default suite hangs; one failure; large offline coverage gaps. |
| Deployment readiness | **Not Verified** | No Docker/CI/deploy config inspected; frontend builds. |
| Security readiness | **Partially Ready (local only)** | Good loopback/signature controls; no auth; plaintext secrets. |
| Data integrity | **Partially Ready** | Sound schema/WAL/time handling; behaviorally unverified external ingestion. |
| AI reliability | **Partially Ready** | Robust router; unverified model ids; weak PAA phrasing; fact-check UI broken. |
| Production readiness | **Not Ready** | Unauthenticated control plane + unverified publishing path + unusable test gate. |

**Honesty statement:** this audit inspected a substantial but not exhaustive subset of the
codebase. Every finding above is either confirmed by an executed command or by direct static
inspection of the cited file. Items marked Unverified (AUD-14, live integrations) were not
executed and require a configured environment to confirm. No application code was modified.

---

# ADDENDUM — Deep Runtime & Workflow Analysis (second pass)

The findings below come from a deeper read of `pipeline/pipeline_manager.py` (all 1,422
lines), `pipeline/nodes/draft_node.py`, `pipeline/nodes/audit_node.py`,
`pipeline/nodes/review_node.py`, the `/api/agent/runs*` endpoints, and the post/run CRUD.

### AUD-16 — Publish-failure branch broadcasts SUCCESS (P2, confirmed by static inspection)
In `_review_run_locked` (`pipeline/pipeline_manager.py`, approve branch, ~lines 1052–1068),
when the publish node reports failure the code emits an ERROR log **and then, inside the same
failure branch**, emits `stage_complete`, a SUCCESS log `🚀 [Stage 9/10 - Publish] Article
published to Next.js: {pub_url}` (with an empty URL), and `stage_start` for repurpose.
**Impact:** the live dashboard/SSE feed tells the operator an article published when the
backend reported failure — exactly the "UI success despite backend failure" failure mode.
**Fix:** make the failure branch emit only the error and skip the success/repurpose events;
remove the duplicated block. **Verify:** force a publish failure and assert no SUCCESS event.

### AUD-18 — WITHDRAWN (stale): draft-edit checkpoint sync imports correctly
**Re-verification (third pass):** the premise below no longer holds. `web/app.py:3473` now
reads `from pipeline.pipeline_manager import COMPILED_PIPELINE`, which is the module that
defines it (`pipeline_manager.py:100`). No occurrence of
`from pipeline.graph import COMPILED_PIPELINE` exists anywhere in the tree
(`grep` returns only the correct import plus this report's own text). A recent commit
evidently fixed this. The `aupdate_state` path therefore executes as intended.
**Status:** withdrawn as a defect. Retained here so the audit trail records the correction
and does not overstate the issue. **Residual (informational):** the sync still runs inside a
broad `except Exception` that logs a warning, so a future regression would be silent — a
narrow catch with an explicit state-flag would be safer.

<details><summary>Original (now-inaccurate) finding text</summary>
`web/app.py:3473` does `from pipeline.graph import COMPILED_PIPELINE`, but
`COMPILED_PIPELINE` is defined only in `pipeline/pipeline_manager.py` (line 100).
</details>

### AUD-17 — Draft "evidence pack" interrupt is treated as a review interrupt (P2, conditional)
`generate_draft` (`draft_node.py`) can call `interrupt({... type: "evidence_required" ...})`
when `inject_evidence` and `REQUIRE_EVIDENCE_PACK` are set and no evidence exists. The
manager's `_run_live_flow` treats **any** `__interrupt__` chunk as the review gate: it sets
`status=review_pending`, dispatches a Slack review card, and later resumes with
`Command(resume="approved")` / `{"action": ...}`. The evidence interrupt receives that resume
value, `decision.get("evidence_pack")` finds nothing, and drafting continues with the
empirical default; the run then interrupts again at the real review gate, but the approve
loop only handles `publish`/`repurpose` chunks, so the run can be **finalized as `completed`
without ever publishing**.
**Impact:** with `REQUIRE_EVIDENCE_PACK=true`, the originality gate is both bypassed and can
produce a false "completed" run. Off by default, but it is a correctness trap.
**Fix:** distinguish interrupt kinds (inspect the interrupt payload) and route evidence waits
separately. **Verify:** set the flag, run with no evidence, assert the run waits and is not
marked completed.

### AUD-19 — Re-opening a completed run is uncapped; revisions skip re-verification (P3, refined)
`_revise_completed_run` (`pipeline_manager.py:1332`) computes
`rev_count = state.get("revision_count", 1) + 1` (line 1337) and never compares against
`MAX_REVISIONS`, then re-runs only `generate_draft` + `audit_and_optimize_seo` — **no**
`fact_check`, `aeo`, or `article_studio` — before returning to `review_pending`.
**Third-pass correction to severity:** the earlier "potential duplicate publish" concern is
**not** supported. Both `request_changes` (line 1093) and `approve` in `_review_run_locked`
do enforce `MAX_REVISIONS`; at the cap the graph router ends the run and the manager closes it
as `revision_cap_reached` before any publish — and `approve` re-checks the cap before running
`publish_node`. So publishing is bounded. **The real residual defect is scope/quality:** the
archived-run revision path is unbounded in *re-open count* (each request_changes on a
`completed` run spawns another draft+audit pass with no ceiling) and revised prose is never
re-fact-checked (claims added/edited by a revision are not re-verified). **Impact:** wasted
LLM spend and unverified claims in revised articles, not duplicate publishing.
**Fix:** enforce a re-open ceiling and re-run `fact_check` (at least a diff-scoped pass) on
revised content. **Verify:** request changes on a `completed` run repeatedly and assert a
cap, and assert a revision with a new claim produces updated `fact_check_score`.

### AUD-20 — Dead duplicate branch (P3)
`_run_live_flow` contains two consecutive identical `elif "repurpose" in chunk:` blocks; the
second is unreachable. Copy-paste artifact. **Fix:** delete one.

### AUD-21 — "Success rate" KPI counts in-flight runs as failures (P3)
`get_dashboard_kpis` computes `success_rate = completed_runs / total_runs`, where `total_runs`
includes `queued`/`running`/`review_pending`. A dashboard full of healthy in-progress runs
shows a depressed success rate. **Fix:** restrict the denominator to terminal runs.

**Deep-pass summary:** the LangGraph orchestration, review locking, revision cap on the
normal path, idempotency guards, and storage-strategy logic are thoughtfully built. The
defects cluster in (a) event/status reporting that contradicts the real outcome (AUD-16), (b)
resume/checkpoint consistency (AUD-17; AUD-18 was re-verified and withdrawn), and (c) the
revision model diverging between the graph path and the direct-node path (AUD-19).

---

# ADDENDUM II — Feature-Alignment Pass (third pass)

This pass asked a narrower question than "is the code present?": **is each advertised feature
logically aligned and actually implemented, or is it simulated/mocked while presenting as
real?** Findings below were verified by direct static inspection during this pass (several
earlier findings were also re-verified; AUD-18 was withdrawn as stale). The pattern that
dominates this pass is **fabricated data presented as observed data**.

### AUD-22 — Simulated SERP is fabricated and then consumed as if real (P1, confirmed)
`pipeline/adapters/brief_builder.py::fetch_serp_live_advanced` (line 194) tries DataForSEO →
Serper → Tavily, then **falls through to `_build_simulated_serp(clean_kw, depth)` (line 391,
function at 407)** whenever nothing is configured. That helper invents a full top-10 with
fake titles/URLs across hardcoded domains
(`dev.to, medium.com, github.com, archdaily.com, stackoverflow.com, infoworld.com`), sets
`provider: "simulated"`, and hard-sets `has_ai_overview: True` with fabricated
`serp_features` and `ai_overview_sources`.
`build_evidence_based_brief` (line 961) then reads those `top_urls` and passes them to
`fetch_and_analyze_competitors` (line 732), which **actually issues HTTP scrapes against the
fabricated URLs**. There is an honest sibling, `_empty_serp_response` (line 394, returns
`provider: "unconfigured"`), but it is only used for an empty keyword (line 209).
**Contradiction:** `pipeline/adapters/serp_client.py` explicitly documents the opposite policy
("returns explicit `provider: 'unconfigured'` … rather than fabricating rankings").
**Impact:** with no SERP credentials (the default), every brief is built on invented
competitors and a claimed AI Overview, the pipeline wastes time scraping dead URLs, and the
generated "evidence-based" brief silently descends from fiction. **Fix:** return
`_empty_serp_response` (or a clearly-typed `provider: "simulated"` record that callers refuse
to treat as evidence) on the no-credential path; gate competitor scraping on
`provider in {dataforseo, serper, tavily}`. **Verify:** run `build_evidence_based_brief` with no
SERP keys and assert no outbound competitor scrape and `provider == "unconfigured"`.

### AUD-23 — Hardcoded, topic-independent fallback entities injected into briefs (P2, confirmed)
`brief_builder.py` (~line 1013): when gap analysis extracts no entities (the offline path),
the brief is populated with `differentiators = ["Deterministic Physics", "Sub-Tick Simulation",
"Memory Optimization"]` and `table_stakes = [<topic>.title(), "Performance Benchmarks",
"System Architecture", "Best Practices"]`. These game-engine-specific differentiators are
identical for a CRM, a recipe blog, or a finance article.
**Impact:** the brief instructs the writer to differentiate on physics/simulation regardless
of niche — the same class of defect the `article_model` hard-prohibition rules exist to catch,
applied one stage earlier. **Fix:** derive fallbacks from the site's niche/brand profile or
emit empty lists that the writer prompt handles, rather than a fixed game-dev triple.
**Verify:** build a brief for a non-gaming keyword offline and assert the differentiators are
not the hardcoded triple.

### AUD-24 — Mock/test short-circuit fabricates publish success (P1, confirmed)
`pipeline/adapters/cms_publishers.py::NextJsAdapter.publish_or_schedule` (~line 1211) computes
`is_mock_env` from: the secret token containing `"mock"`/`"test"`, the site URL containing
`"test"`/`"mock"`/`"example.com"`, **or the `site_id` containing `"test"`**. When true it
returns `PublishResult(success=True, published_url=f"{site_url}/posts/{slug}",
status="published")` **without any network call**. The same `is_mock` test makes `unpublish`
(~1272) and `revert` (~1306) return `True` unconditionally, and other adapters do similar
(e.g. Ghost returning a literal `"mock_ghost_jwt"`). `post_publish_check` (line 203) does run
an HTTP GET, but on failure it force-sets `title_matched`/`http_status_ok` true whenever the
URL contains `mock`/`test`/`localhost`.
**Impact:** a **real** target whose `site_id`, URL, or token merely contains the substring
`test` (e.g. `contest-blog`, `testimonials-site`, a staging URL) reports `published` with a
fabricated URL and a synthetic pass on post-publish checks — the dashboard shows a successful
publish that never happened. Substring matching on arbitrary identifiers is far too broad.
**Fix:** require an explicit, non-heuristic opt-in (config flag / env) for mock mode; never
derive it from substrings of a real site's id or URL. **Verify:** publish to a site whose id
contains `test` with no mock flag and assert a real request is attempted.

### AUD-25 — Decay audit runs its regexes on a content *hash*, not the content (P2, confirmed)
`pipeline/adapters/content_decay.py::prioritize_update_portfolio` (line 273) calls
`run_page_audit(website_id, url, page_markdown=p.get("content_hash") or "")` (line 303).
`content_hash` is a fingerprint, not body text, so every check in `run_page_audit` (line 173)
— outdated years, `\d+%` / `$` statistics, pricing, FAQ, schema — is applied to a hex string.
The year/stat/pricing regexes therefore never fire, leaving only the generic
`missing_faq` + `missing_schema` findings, which are then used to size effort and risk in the
update portfolio.
**Impact:** the "which 12 articles to update first" prioritization is driven by two boolean
fallback findings rather than the page's real decay signals; the risk-reduction term (which
rewards fixing outdated pricing/statistics) is always 0. **Fix:** fetch and pass the actual
page text (or reuse already-persisted findings). **Verify:** seed a page with `$49/mo` and a
2019 date, run the portfolio, and assert `outdated_pricing`/`outdated_dates` findings appear.

### AUD-26 — The evidence-pack gate's fallback fabricates "first-party" evidence (P2, confirmed)
`pipeline/nodes/draft_node.py` (lines ~155–180): when `inject_evidence` and
`config.REQUIRE_EVIDENCE_PACK` are on and no real evidence exists, the node raises
`interrupt({"type": "evidence_required", ...})`. But immediately after, if
`evidence_items` is still empty it injects a synthetic record
(`evidence_type: "first_party_data"`, content = "Production benchmarks … demonstrating
sub-tick latency, zero memory leaks, and deterministic verification", no `source_url`).
As established in AUD-17, an editor approval resumes that interrupt with the string
`"approved"` (not a dict carrying an `evidence_pack`), so the empty-evidence path is taken and
this fabricated "first-party data" flows into the draft.
**Impact:** the gate whose stated purpose is to satisfy Google's Scaled Content Policy
manufactures the exact unverifiable self-authored claim it is meant to prevent. `config.py:58`
defaults `REQUIRE_EVIDENCE_PACK` to `false`, so this is opt-in, but enabling it yields
fabricated evidence rather than a hard stop. **Fix:** make the gate fail closed (block drafting
until real evidence is supplied) and never synthesize `first_party_data`. **Verify:** enable
the flag with no evidence and assert drafting halts and no fabricated item is emitted.

**Third-pass summary.** The orchestration logic is genuinely engineered, but several
"intelligence" surfaces are **theatre under default (unconfigured) conditions**: SERP
competitors (AUD-22), brief differentiators (AUD-23), publish success (AUD-24), decay audits
(AUD-25), and evidence provenance (AUD-26). Each returns plausible-looking structured data
with no failure signal, so downstream stages and the dashboard cannot distinguish observed
facts from invented defaults. The highest-leverage fix is a single project convention: any
provider/adapter that lacks credentials must return an explicit `unconfigured`/`skipped`
status that callers are forbidden to treat as evidence — never a fabricated success.
