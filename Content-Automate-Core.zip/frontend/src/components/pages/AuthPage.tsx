import { useState } from "react";
import {
  ArrowRight,
  ShieldCheck,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowLeft,
  Check,
} from "lucide-react";
import { Logo } from "../Logo";
import { useNav } from "../../lib/nav";
import { useToast } from "../../lib/toast";
import { cn } from "../../utils/cn";

import { api } from "../../lib/api";

export function AuthPage() {
  const { setPage } = useNav();
  const { push } = useToast();

  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("operator@studio.local");
  const [password, setPassword] = useState("••••••••••••");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.getSystemStatus();
      push({
        title: mode === "signin" ? "Welcome back" : "Workspace session initialized",
        description: "Authenticated local operator session. Connecting to Studio...",
        variant: "success",
      });
      setPage("overview");
    } catch {
      push({
        title: "Connection Warning",
        description: "FastAPI backend on 127.0.0.1:8000 not responding. Launching offline studio interface.",
        variant: "warn",
      });
      setPage("overview");
    } finally {
      setLoading(false);
    }
  };

  const handleOAuth = (provider: string) => {
    push({
      title: `${provider} SSO in Local Mode`,
      description: "Direct local operator session granted.",
      variant: "info",
    });
    setPage("overview");
  };

  return (
    <div className="relative min-h-screen bg-[#F7F6F2] text-[#161719] flex flex-col justify-between selection:bg-[#3157D5]/20 selection:text-[#161719]">
      {/* Editorial Header */}
      <header className="relative z-10 mx-auto flex h-16 w-full max-w-[1280px] items-center justify-between px-5 sm:px-8 lg:px-10 border-b border-[#DFE0DA] bg-white">
        <button
          onClick={() => setPage("landing")}
          className="group inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.08em] text-[#656862] hover:text-[#161719] transition-colors cursor-pointer"
        >
          <ArrowLeft size={13} className="transition-transform group-hover:-translate-x-1" />
          <span>Back to Landing</span>
        </button>

        <button
          onClick={() => setPage("landing")}
          className="cursor-pointer"
          aria-label="Verlytic — home"
        >
          <Logo size={30} tone="light" title="Verlytic" subtitle="Content Operations" />
        </button>

        <div className="hidden sm:flex items-center gap-2">
          <span className="font-mono text-[11px] uppercase tracking-[0.08em] text-[#92958E]">
            Editorial Auth Desk
          </span>
        </div>
      </header>

      {/* Main Authentication Workspace */}
      <main className="relative z-10 flex flex-1 items-center justify-center px-4 py-12 sm:py-16">
        <div className="w-full max-w-[460px] space-y-6">
          {/* Local Operator Bypass Card */}
          <div className="overflow-hidden rounded-[6px] border border-[#DFE0DA] bg-white p-5 shadow-[0_1px_0_rgba(22,23,25,0.04),0_12px_28px_-18px_rgba(22,23,25,0.12)]">
            <div className="flex items-center justify-between pb-2 border-b border-[#DFE0DA]">
              <div className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rounded-full bg-[#3E805C] pulse-dot" />
                <span className="font-mono text-[11px] uppercase tracking-[0.08em] text-[#161719] font-medium">
                  Local Operator Bypass
                </span>
              </div>
              <span className="font-mono text-[10px] uppercase tracking-[0.08em] bg-[#EEF6F1] text-[#3E805C] border border-[#3E805C]/25 px-1.5 py-0.5 rounded-[3px]">
                PORT 8000 · ACTIVE
              </span>
            </div>
            <p className="mt-2.5 text-[13px] leading-snug text-[#656862]">
              FastAPI studio backend detected running locally on <code className="font-mono text-[12px] bg-[#F7F6F2] px-1 py-0.5 rounded text-[#161719]">127.0.0.1:8000</code>. Bypass external authentication to manage your workspaces immediately.
            </p>
            <button
              type="button"
              onClick={() => setPage("overview")}
              className="mt-3.5 flex w-full items-center justify-center gap-2 h-10 rounded-[4px] bg-[#161719] text-white text-xs font-medium hover:bg-[#3157D5] transition-colors cursor-pointer group"
            >
              <span>Continue as Studio Operator</span>
              <ArrowRight size={13} className="transition-transform group-hover:translate-x-0.5" />
            </button>
          </div>

          {/* Primary Authentication Card */}
          <div className="overflow-hidden rounded-[6px] border border-[#DFE0DA] bg-white p-7 sm:p-8 shadow-[0_1px_0_rgba(22,23,25,0.04),0_20px_42px_-26px_rgba(22,23,25,0.18)]">
            <div className="text-left mb-6">
              <span className="label text-[#3157D5]">
                {mode === "signin" ? "Workspace Access" : "New Account"}
              </span>
              <h2 className="mt-2 font-serif text-[30px] font-normal leading-[1.05] tracking-[-0.015em] text-[#161719]">
                {mode === "signin" ? "Sign in to workspace" : "Create your workspace"}
              </h2>
              <p className="mt-2 text-[13px] leading-snug text-[#656862]">
                {mode === "signin"
                  ? "Access verified content intelligence, approval queues, and autonomous publishing."
                  : "Start 14-day free trial · 60 verified articles/month included."}
              </p>
            </div>

            {/* Mode Switcher */}
            <div className="grid grid-cols-2 p-1 rounded-[5px] bg-[#F1EFEB] border border-[#DFE0DA]/80 mb-6">
              <button
                type="button"
                onClick={() => setMode("signin")}
                className={cn(
                  "h-8 rounded-[4px] text-xs font-medium transition-all cursor-pointer",
                  mode === "signin"
                    ? "bg-white text-[#161719] shadow-xs"
                    : "text-[#656862] hover:text-[#161719]"
                )}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setMode("signup")}
                className={cn(
                  "h-8 rounded-[4px] text-xs font-medium transition-all cursor-pointer",
                  mode === "signup"
                    ? "bg-white text-[#161719] shadow-xs"
                    : "text-[#656862] hover:text-[#161719]"
                )}
              >
                Create Account
              </button>
            </div>

            {/* Social SSO Buttons */}
            <div className="grid grid-cols-2 gap-3 mb-5">
              <button
                type="button"
                onClick={() => handleOAuth("Google")}
                className="flex items-center justify-center gap-2 h-10 rounded-[4px] border border-[#DFE0DA] bg-white px-3 text-xs font-medium text-[#161719] hover:bg-[#F7F6F2] hover:border-[#CACDC5] transition cursor-pointer"
              >
                <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.5 8.9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.4s.2-1.7.4-2.4L1.6 7C.6 9 0 10.9 0 12.3s.6 3.3 1.6 5.3l3.7-2.9z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.5-6.7-5.3L1.6 16.4C3.5 20.2 7.4 23.5 12 23.5z"
                  />
                </svg>
                <span>Google</span>
              </button>

              <button
                type="button"
                onClick={() => handleOAuth("GitHub")}
                className="flex items-center justify-center gap-2 h-10 rounded-[4px] border border-[#DFE0DA] bg-white px-3 text-xs font-medium text-[#161719] hover:bg-[#F7F6F2] hover:border-[#CACDC5] transition cursor-pointer"
              >
                <svg className="h-4 w-4 shrink-0 fill-current" viewBox="0 0 24 24">
                  <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                </svg>
                <span>GitHub</span>
              </button>
            </div>

            <div className="relative flex items-center justify-center my-5">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#DFE0DA]" />
              </div>
              <span className="relative bg-white px-3 font-mono text-[10px] uppercase tracking-[0.1em] text-[#92958E]">
                Or with work email
              </span>
            </div>

            {/* Email / Password Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block font-mono text-[11px] uppercase tracking-[0.08em] text-[#161719] mb-1.5 font-medium">
                  Work Email
                </label>
                <div className="relative">
                  <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#92958E]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="you@company.com"
                    className="w-full h-10 rounded-[4px] border border-[#DFE0DA] bg-white pl-9 pr-3 text-xs text-[#161719] placeholder-[#92958E] focus:border-[#3157D5] focus:outline-none focus:ring-1 focus:ring-[#3157D5] transition-colors"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block font-mono text-[11px] uppercase tracking-[0.08em] text-[#161719] font-medium">
                    Password
                  </label>
                  {mode === "signin" && (
                    <button
                      type="button"
                      onClick={() => push({ title: "Reset link sent", description: "Check your inbox for password recovery instructions.", variant: "info" })}
                      className="text-[11px] text-[#3157D5] hover:underline cursor-pointer"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#92958E]" />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="••••••••••••"
                    className="w-full h-10 rounded-[4px] border border-[#DFE0DA] bg-white pl-9 pr-10 text-xs text-[#161719] placeholder-[#92958E] focus:border-[#3157D5] focus:outline-none focus:ring-1 focus:ring-[#3157D5] transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#92958E] hover:text-[#161719] cursor-pointer"
                  >
                    {showPassword ? <EyeOff size={13} /> : <Eye size={13} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 cursor-pointer rounded-[4px] bg-[#161719] text-xs font-medium text-white shadow-xs transition hover:bg-[#3157D5] active:scale-[0.99] disabled:opacity-50 mt-2"
              >
                {loading ? "Authenticating..." : mode === "signin" ? "Sign In to Workspace" : "Create Workspace Account"}
              </button>
            </form>

            {/* Security Guarantee Footnote */}
            <div className="mt-6 pt-4 border-t border-[#DFE0DA] flex items-center justify-center gap-2 text-[11.5px] text-[#656862]">
              <ShieldCheck size={14} className="text-[#3E805C] shrink-0" />
              <span>Human Approval Gate · Verified Sources · SOC2 Ready</span>
            </div>
          </div>
        </div>
      </main>

      {/* Editorial Auth Footer */}
      <footer className="relative z-10 border-t border-[#DFE0DA] bg-white py-5 text-center text-[12px] text-[#656862]">
        <div className="mx-auto flex max-w-[1280px] flex-col sm:flex-row items-center justify-between px-5 sm:px-8 gap-2">
          <span>© 2026 Verlytic Content Operations. All rights reserved.</span>
          <div className="flex items-center gap-4 text-[12px]">
            <a href="#privacy" onClick={(e) => { e.preventDefault(); setPage("landing"); }} className="hover:text-[#161719]">Privacy</a>
            <span className="text-[#DFE0DA]">·</span>
            <a href="#terms" onClick={(e) => { e.preventDefault(); setPage("landing"); }} className="hover:text-[#161719]">Terms</a>
            <span className="text-[#DFE0DA]">·</span>
            <a href="#status" onClick={(e) => { e.preventDefault(); setPage("overview"); }} className="hover:text-[#161719]">Studio Status</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
