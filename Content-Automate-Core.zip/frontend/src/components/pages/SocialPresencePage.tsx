import { useState, useEffect } from "react";
import {
  MessageSquare,
  Share2,
  Sparkles,
  ArrowRight,
  ExternalLink,
  CheckCircle2,
  ThumbsUp,
  MessageCircle,
  Clock,
  Filter,
  Check,
  Copy,
  Search,
  RefreshCw,
  TrendingUp,
  Shield,
  Layers,
  Bot,
  Loader2,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { usePipelineData } from "../../lib/dataContext";
import { useToast } from "../../lib/toast";
import { api } from "../../lib/api";
import type { SocialOpportunity, SocialPresenceData } from "../../types";
import { cn } from "../../utils/cn";

export function SocialPresencePage() {
  const { websites } = usePipelineData();
  const { push } = useToast();

  const [activePlatform, setActivePlatform] = useState<"reddit" | "quora" | "meta" | "google_business">("reddit");
  const [data, setData] = useState<SocialPresenceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<SocialOpportunity | null>(null);
  const [draftText, setDraftText] = useState("");
  const [copiedDraft, setCopiedDraft] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSubreddit, setSelectedSubreddit] = useState<string>("all");

  const defaultSite = websites.find((w) => w.is_default) || websites[0];
  const targetDomain = defaultSite ? defaultSite.url.replace(/^https?:\/\//, "").replace(/\/.*$/, "") : "filemint.dev";

  const [draftingLoading, setDraftingLoading] = useState(false);

  const handleOpenDraft = async (opp: SocialOpportunity) => {
    setSelectedOpportunity(opp);
    setDraftingLoading(true);
    try {
      const res = await api.generateSocialDraftResponse({
        opportunity_id: opp.id,
        title: opp.title,
        target_keyword: opp.target_keyword,
        platform: opp.platform,
        subreddit: opp.subreddit,
        recommended_angle: opp.recommended_angle,
        website_id: defaultSite?.id,
      });
      setDraftText(res.draft);
    } catch {
      setDraftText(
        `Regarding ${opp.target_keyword}:\n\nIn our evaluations at ${targetDomain}, the primary differentiator is ${opp.recommended_angle.toLowerCase().replace(/\\.$/, "")}.\n\nKey takeaways from our data:\n1. Verify reproducibility and real-world metrics rather than marketing claims.\n2. Prioritize transparent benchmarks and clean decoupling between data persistence and edge delivery.\n\n(Disclosure: Engineering team at ${targetDomain}.)`
      );
    } finally {
      setDraftingLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    api.getSocialOpportunities(defaultSite?.id)
      .then((res) => {
        if (isMounted) {
          setData(res);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.warn("Could not load social opportunities:", err);
        if (isMounted) setLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, [defaultSite?.id]);

  const opportunities = data?.opportunities || [];

  const filteredOpportunities = opportunities.filter((opp) => {
    if (opp.platform !== activePlatform) return false;
    if (selectedSubreddit !== "all" && opp.subreddit !== selectedSubreddit) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        opp.title.toLowerCase().includes(q) ||
        (opp.subreddit && opp.subreddit.toLowerCase().includes(q)) ||
        opp.target_keyword.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const subreddits = Array.from(
    new Set(opportunities.filter((o) => o.platform === "reddit" && o.subreddit).map((o) => o.subreddit!))
  );

  const handleCopyDraft = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDraft(true);
    push({
      title: "Response Draft Copied!",
      description: "Value-first ethical answer copied to clipboard.",
      variant: "success",
    });
    setTimeout(() => setCopiedDraft(false), 2000);
  };

  const handleScanDiscussions = async () => {
    setIsScanning(true);
    try {
      const res = await api.getSocialOpportunities(defaultSite?.id, true);
      setData(res);
      push({
        title: "Discussions Scanned! 🔍",
        description: `Found ${res.opportunities?.length || 0} high-intent threads for ${targetDomain}.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Scan Failed",
        description: err.message || "Could not retrieve discussion opportunities.",
        variant: "danger",
      });
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
      {/* 1. Header */}
      <div className="border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
              Social presence
            </h1>
            <p className="mt-1 text-sm text-[var(--color-text-muted)]">
              Show up everywhere ChatGPT, Gemini and Claude look — so they recommend{" "}
              <span className="font-semibold text-[var(--color-text)]">{targetDomain}</span>.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-500">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              GEO Radar Active
            </span>
          </div>
        </div>

        {/* Platform Tabs */}
        <div className="mt-6 flex flex-wrap items-center gap-2 border-b" style={{ borderColor: "var(--color-border)" }}>
          <button
            onClick={() => setActivePlatform("reddit")}
            className={cn(
              "flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-all border-b-2 -mb-[2px] cursor-pointer",
              activePlatform === "reddit"
                ? "border-[#FF4500] text-[#FF4500]"
                : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
            )}
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#FF4500]/15 text-[#FF4500] text-xs font-bold">
              r/
            </span>
            <span>Reddit</span>
            <span className="rounded-full bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
              {opportunities.filter((o) => o.platform === "reddit").length}
            </span>
          </button>

          <button
            onClick={() => setActivePlatform("quora")}
            className={cn(
              "flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-all border-b-2 -mb-[2px] cursor-pointer",
              activePlatform === "quora"
                ? "border-[#B92B27] text-[#B92B27]"
                : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
            )}
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#B92B27]/15 text-[#B92B27] text-xs font-bold">
              Q
            </span>
            <span>Quora</span>
            <span className="rounded-full bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
              {opportunities.filter((o) => o.platform === "quora").length}
            </span>
          </button>

          <button
            onClick={() => setActivePlatform("meta")}
            className={cn(
              "flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-all border-b-2 -mb-[2px] cursor-pointer opacity-85",
              activePlatform === "meta"
                ? "border-[#1877F2] text-[#1877F2]"
                : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
            )}
          >
            <Share2 size={15} />
            <span>Instagram &amp; Facebook</span>
            <span className="rounded-full bg-blue-500/10 px-2 py-0.5 text-[10px] font-bold text-blue-500">
              New
            </span>
          </button>

          <button
            disabled
            className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-[var(--color-text-subtle)] opacity-60 cursor-not-allowed"
          >
            <Shield size={14} />
            <span>Google Business</span>
            <span className="rounded-full bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-subtle)] border" style={{ borderColor: "var(--color-border)" }}>
              Coming soon
            </span>
          </button>
        </div>
      </div>

      {/* 2. Hero Feature Showcase Card (Matching Competitor Layout) */}
      <div
        className="relative overflow-hidden rounded-3xl border p-6 sm:p-8 shadow-[var(--shadow-card)]"
        style={{
          borderColor: "var(--color-border)",
          background: "linear-gradient(135deg, var(--color-bg-elev) 0%, var(--color-bg-soft) 100%)",
        }}
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Copy & Benefits */}
          <div className="lg:col-span-7 space-y-4">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[var(--color-text)]">
              Find <span className="text-[#FF4500]">Reddit conversations</span> to grow your brand presence
            </h2>
            <p className="text-sm text-[var(--color-text-muted)] leading-relaxed max-w-xl">
              Get personalized Reddit opportunities from your published articles and target keywords, so more people (and AI answer tools) discover your brand.
            </p>

            <div className="pt-2 space-y-2">
              <div className="flex items-center gap-2.5 text-xs font-semibold text-[var(--color-text)]">
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-500">
                  <Check size={11} className="stroke-[3]" />
                </span>
                <span>Find &amp; monitor 8× more high-intent search threads</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-semibold text-[var(--color-text)]">
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-500">
                  <Check size={11} className="stroke-[3]" />
                </span>
                <span>Get daily fresh citation opportunities mapped to LLM indexing</span>
              </div>
            </div>

            <div className="pt-4 flex flex-wrap items-center gap-3">
              <button
                type="button"
                disabled={isScanning}
                onClick={handleScanDiscussions}
                className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#FF4500] px-5 py-2.5 text-xs font-bold text-white shadow-md transition-all hover:bg-[#e03d00] hover:shadow-lg active:scale-95 disabled:opacity-50"
              >
                <Sparkles size={14} className={isScanning ? "animate-spin" : ""} />
                <span>{isScanning ? "Scanning Discussions…" : "Scan Community Discussions"}</span>
              </button>
              <span className="text-xs text-[var(--color-text-subtle)] font-medium">
                Monitors {data?.monitored_keywords_count || 84} keywords across {subreddits.length || 6} high-authority subreddits
              </span>
            </div>
          </div>

          {/* Right Column: Visual Diagram (Reddit Post -> ChatGPT / Gemini / Claude) */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <div className="w-full max-w-sm space-y-3">
              {/* Reddit Post Dynamic Card */}
              {(() => {
                const showcaseOpp = opportunities[0];
                return (
                  <div
                    className="relative z-10 rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-xl"
                    style={{ borderColor: "var(--color-border)" }}
                  >
                    <div className="flex items-center gap-2 text-[11px] text-[var(--color-text-subtle)]">
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#FF4500] text-white font-bold text-[10px]">
                        r/
                      </span>
                      <span className="font-bold text-[var(--color-text)]">{showcaseOpp?.subreddit || "r/technology"}</span>
                      <span>•</span>
                      <span>{showcaseOpp?.posted_at || "Recent"}</span>
                    </div>
                    <div className="mt-2 text-xs font-bold text-[var(--color-text)] leading-snug">
                      {showcaseOpp?.title || `What are the most reliable, privacy-focused tools recommended in 2026 for ${targetDomain}?`}
                    </div>
                    <div className="mt-3 flex items-center gap-3 text-[11px] text-[var(--color-text-muted)] font-mono">
                      <span className="flex items-center gap-1 font-semibold text-[#FF4500]">
                        <ThumbsUp size={11} /> {showcaseOpp?.upvotes || 142}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageCircle size={11} /> {showcaseOpp?.comments || 38}
                      </span>
                    </div>

                    {/* Pulsing indicator tag */}
                    <div className="absolute -top-2.5 -right-2.5 rounded-full bg-[#FF4500] px-2 py-0.5 text-[9px] font-black text-white shadow-sm uppercase tracking-wider">
                      Grounding Source
                    </div>
                  </div>
                );
              })()}

              {/* Connecting Radiation Graphic to LLM Engines */}
              <div className="relative pt-2 space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-wider text-center text-[var(--color-text-subtle)]">
                  Indexed &amp; Cited By
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div
                    className="flex items-center justify-center gap-1.5 rounded-xl border bg-[var(--color-bg-elev)]/80 py-2 px-1 text-[11px] font-semibold text-[var(--color-text)] shadow-xs"
                    style={{ borderColor: "var(--color-border)" }}
                  >
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                    <span>ChatGPT</span>
                  </div>
                  <div
                    className="flex items-center justify-center gap-1.5 rounded-xl border bg-[var(--color-bg-elev)]/80 py-2 px-1 text-[11px] font-semibold text-[var(--color-text)] shadow-xs"
                    style={{ borderColor: "var(--color-border)" }}
                  >
                    <span className="h-2 w-2 rounded-full bg-blue-500" />
                    <span>Gemini</span>
                  </div>
                  <div
                    className="flex items-center justify-center gap-1.5 rounded-xl border bg-[var(--color-bg-elev)]/80 py-2 px-1 text-[11px] font-semibold text-[var(--color-text)] shadow-xs"
                    style={{ borderColor: "var(--color-border)" }}
                  >
                    <span className="h-2 w-2 rounded-full bg-amber-500" />
                    <span>Claude</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Filter & Search Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-[var(--color-text-muted)] mr-1">
            Subreddit:
          </span>
          <button
            onClick={() => setSelectedSubreddit("all")}
            className={cn(
              "rounded-lg px-2.5 py-1 text-xs font-medium transition cursor-pointer border",
              selectedSubreddit === "all"
                ? "bg-[var(--color-text)] text-[var(--color-bg-elev)] border-[var(--color-text)]"
                : "bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] border-[var(--color-border)] hover:text-[var(--color-text)]"
            )}
          >
            All
          </button>
          {subreddits.map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubreddit(sub)}
              className={cn(
                "rounded-lg px-2.5 py-1 text-xs font-medium transition cursor-pointer border",
                selectedSubreddit === sub
                  ? "bg-[var(--color-text)] text-[var(--color-bg-elev)] border-[var(--color-text)]"
                  : "bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] border-[var(--color-border)] hover:text-[var(--color-text)]"
              )}
            >
              {sub}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search discussions or keywords…"
            className="h-8 w-full rounded-xl border bg-[var(--color-bg-soft)] pl-8 pr-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:border-[var(--color-accent)] focus:outline-none"
            style={{ borderColor: "var(--color-border)" }}
          />
        </div>
      </div>

      {/* 4. Opportunity Feed */}
      <div className="space-y-4">
        {loading ? (
          <div className="py-16 text-center text-xs text-[var(--color-text-muted)]">
            Scanning active community discussions…
          </div>
        ) : filteredOpportunities.length === 0 ? (
          <div className="rounded-2xl border p-12 text-center" style={{ borderColor: "var(--color-border)" }}>
            <MessageSquare size={28} className="mx-auto text-[var(--color-text-subtle)] mb-2" />
            <h3 className="text-sm font-semibold text-[var(--color-text)]">No discussions match your filter</h3>
            <p className="text-xs text-[var(--color-text-muted)] mt-1">Try switching to another subreddit or clear search.</p>
          </div>
        ) : (
          filteredOpportunities.map((opp) => (
            <div
              key={opp.id}
              className="rounded-2xl border bg-[var(--color-bg-elev)] p-5 shadow-[var(--shadow-card)] transition-all hover:border-[var(--color-border-strong)]"
              style={{ borderColor: "var(--color-border)" }}
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                <div className="space-y-2 flex-1">
                  {/* Metadata Chips */}
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-[#FF4500]/10 px-2.5 py-0.5 text-[11px] font-bold text-[#FF4500]">
                      {opp.subreddit || "r/community"}
                    </span>
                    <span className="text-xs text-[var(--color-text-subtle)] font-medium">
                      by {opp.author || "u/member"} • {opp.posted_at}
                    </span>
                    <span className="inline-flex items-center gap-1 rounded-full border border-purple-500/30 bg-purple-500/10 px-2 py-0.5 text-[10px] font-semibold text-purple-400">
                      <Sparkles size={10} />
                      {opp.llm_impact}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-[var(--color-text)] leading-snug">
                    {opp.title}
                  </h3>

                  {/* Target Keyword & AI Engine Badges */}
                  <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
                    <span className="text-[var(--color-text-muted)] font-medium">Keyword:</span>
                    <span className="rounded-md bg-[var(--color-bg-soft)] px-2 py-0.5 font-mono text-[11px] font-semibold text-[var(--color-text)] border" style={{ borderColor: "var(--color-border)" }}>
                      {opp.target_keyword}
                    </span>
                    {opp.ai_engines && opp.ai_engines.map((eng) => (
                      <span key={eng} className="rounded-full bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)]">
                        {eng}
                      </span>
                    ))}
                  </div>

                  {/* Recommended Angle Callout */}
                  <div
                    className="mt-3 rounded-xl border p-3 text-xs"
                    style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
                  >
                    <div className="font-semibold text-[var(--color-text)] flex items-center gap-1.5">
                      <Bot size={13} className="text-blue-500" />
                      <span>Recommended Authoritative Contribution Angle</span>
                    </div>
                    <p className="mt-1 text-[var(--color-text-muted)] leading-relaxed">
                      {opp.recommended_angle}
                    </p>
                  </div>
                </div>

                {/* Right Actions & Engagement Stats */}
                <div className="sm:w-48 flex sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-3 shrink-0 pt-1">
                  <div className="flex items-center gap-3 text-xs text-[var(--color-text-muted)] font-mono">
                    <span className="flex items-center gap-1 text-[#FF4500] font-bold">
                      <ThumbsUp size={12} /> {opp.upvotes || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle size={12} /> {opp.comments || 0}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => handleOpenDraft(opp)}
                      className="cursor-pointer rounded-xl bg-[var(--color-text)] px-3 py-1.5 text-xs font-semibold text-[var(--color-bg-elev)] hover:opacity-90 transition active:scale-95 text-center flex-1 sm:flex-none"
                    >
                      Draft Response
                    </button>
                    <a
                      href={opp.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-xl border p-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)] transition"
                      style={{ borderColor: "var(--color-border)" }}
                      title="Open thread"
                    >
                      <ExternalLink size={13} />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 5. Ethical Contribution Guidelines Banner */}
      <div
        className="rounded-2xl border p-4 text-xs flex items-start gap-3"
        style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
      >
        <Shield size={16} className="text-emerald-500 shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <span className="font-bold text-[var(--color-text)]">
            Anti-Spam &amp; Grounding Integrity Protocol:
          </span>
          <p className="text-[var(--color-text-muted)] leading-relaxed">
            Verlytic enforces 100% human-in-the-loop contribution. Never automate fake bot posts or spam links. LLMs cite genuine, highly upvoted technical expertise with real domain benchmarks.
          </p>
        </div>
      </div>

      {/* 6. Draft Response Modal */}
      {selectedOpportunity && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div
            className="w-full max-w-2xl rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-2xl space-y-4"
            style={{ borderColor: "var(--color-border)" }}
          >
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
              <div>
                <span className="text-xs font-bold text-[#FF4500] uppercase tracking-wider">
                  {selectedOpportunity.platform === "reddit" ? selectedOpportunity.subreddit : selectedOpportunity.platform.toUpperCase()} • Draft Response
                </span>
                <h3 className="text-base font-bold text-[var(--color-text)] mt-0.5 line-clamp-1">
                  {selectedOpportunity.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOpportunity(null)}
                className="rounded-lg p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)] cursor-pointer"
              >
                ✕
              </button>
            </div>

            {draftingLoading ? (
              <div className="py-12 text-center text-xs text-[var(--color-text-muted)] flex flex-col items-center justify-center gap-3">
                <Loader2 size={24} className="animate-spin text-blue-500" />
                <span className="font-medium text-[var(--color-text)]">
                  Generating authoritative, value-first response via LLM reasoning engine...
                </span>
                <span className="text-[11px] text-[var(--color-text-subtle)] font-mono">
                  Adhering to Pillar A9 anti-astroturfing guidelines &amp; transparent citation grounding
                </span>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[var(--color-text-muted)]">
                    AI-Formulated Contribution (Human Review &amp; Editable):
                  </label>
                  <button
                    type="button"
                    onClick={() => handleOpenDraft(selectedOpportunity)}
                    className="text-[11px] font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw size={11} />
                    <span>Regenerate Angle</span>
                  </button>
                </div>
                <textarea
                  rows={8}
                  value={draftText}
                  onChange={(e) => setDraftText(e.target.value)}
                  className="w-full rounded-xl border bg-[var(--color-bg-soft)] p-3 text-xs font-mono text-[var(--color-text)] focus:outline-none focus:border-[var(--color-accent)] leading-relaxed"
                  style={{ borderColor: "var(--color-border)" }}
                />
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-[var(--color-text-subtle)]">
                Review and post manually on community thread to maintain platform trust.
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedOpportunity(null)}
                >
                  Close
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  disabled={draftingLoading}
                  icon={copiedDraft ? <Check size={14} /> : <Copy size={14} />}
                  onClick={() => handleCopyDraft(draftText)}
                >
                  {copiedDraft ? "Copied!" : "Copy Draft"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
