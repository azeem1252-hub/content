import { useState } from "react";
import {
  ShieldCheck,
  Zap,
  Layers,
  Database,
  Globe,
  CheckCircle2,
  FileText,
  HardDrive,
  Cpu,
  Server,
  ArrowRight,
  ExternalLink,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { useToast } from "../../lib/toast";
import { useNav } from "../../lib/nav";
import { usePipelineData } from "../../lib/dataContext";

export function BillingPage() {
  const { push } = useToast();
  const { setPage } = useNav();
  const { contentItems, websites } = usePipelineData();

  const publishedCount = contentItems.filter((c) => c.status === "Published").length;
  const draftCount = contentItems.filter((c) => c.status === "Drafting" || c.status === "SEO Check").length;
  const reviewPendingCount = contentItems.filter((c) => c.status === "Awaiting Approval").length;

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)]">
              License &amp; Operational Resources
            </h1>
            <span className="border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-xs font-semibold text-emerald-400 font-mono">
              Self-Hosted Studio Edition
            </span>
          </div>
          <p className="mt-1.5 text-sm text-[var(--color-text-muted)]">
            Local autonomous content pipeline engine running on your workstation with complete data isolation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setPage("overview")}
          >
            Studio Overview
          </Button>
        </div>
      </div>

      {/* Active License Summary Card */}
      <div className="border bg-[var(--color-bg-elev)] p-5 sm:p-6" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b pb-5 mb-5" style={{ borderColor: "var(--color-border)" }}>
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center border border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-[var(--color-text)]">
                  Enterprise Studio License
                </h3>
                <span className="border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.2 font-mono text-[10px] font-bold text-emerald-400">
                  Fully Unlocked
                </span>
              </div>
              <div className="mt-1 text-xs text-[var(--color-text-muted)] font-mono">
                Instance URL: <span className="text-[var(--color-text)] font-semibold">http://127.0.0.1:8000</span> · Local loopback execution
              </div>
            </div>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400">
              Unlimited
            </span>
            <span className="text-xs text-[var(--color-text-muted)] font-mono">runs &amp; articles</span>
          </div>
        </div>

        {/* Real-Time Local Operational Usage Gauges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Articles Published */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Articles Published</span>
              <span className="font-mono font-bold text-emerald-400">
                {publishedCount}
              </span>
            </div>
            <div className="text-[11px] text-[var(--color-text-subtle)] font-mono">
              Directly persisted to websites
            </div>
          </div>

          {/* 2. Active Drafts & Review */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">In Pipeline</span>
              <span className="font-mono font-bold text-blue-400">
                {draftCount + reviewPendingCount}
              </span>
            </div>
            <div className="text-[11px] text-[var(--color-text-subtle)] font-mono">
              {reviewPendingCount} awaiting approval
            </div>
          </div>

          {/* 3. Connected Websites */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Connected Websites</span>
              <span className="font-mono font-bold text-purple-400">
                {websites.length}
              </span>
            </div>
            <div className="text-[11px] text-[var(--color-text-subtle)] font-mono">
              Upstash / Database / Git targets
            </div>
          </div>

          {/* 4. Total Pipeline Runs */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Total Pipeline Runs</span>
              <span className="font-mono font-bold text-[var(--color-text)]">
                {contentItems.length}
              </span>
            </div>
            <div className="text-[11px] text-[var(--color-text-subtle)] font-mono">
              Tracked LangGraph checkpoints
            </div>
          </div>
        </div>
      </div>

      {/* Architecture & Storage Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Local Storage Engine */}
        <div className="border bg-[var(--color-bg-elev)] p-5 space-y-4" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <HardDrive size={16} className="text-blue-400" />
            Storage &amp; Data Sovereignty
          </h3>
          <p className="text-xs text-[var(--color-text-muted)]">
            This deployment operates completely under your control with zero cloud vendor lock-in.
          </p>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Primary Database:</span>
              <span className="text-emerald-400 font-bold">SQLite WAL (data/pipeline.db)</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Checkpoints DB:</span>
              <span className="text-emerald-400 font-bold">LangGraph Memory Checkpointer</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Telemetry Isolation:</span>
              <span className="text-emerald-400 font-bold">100% On-Premise / Localhost</span>
            </div>
          </div>
        </div>

        {/* AI & Diffusion Engines */}
        <div className="border bg-[var(--color-bg-elev)] p-5 space-y-4" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <Cpu size={16} className="text-purple-400" />
            Active AI &amp; Generative Subsystems
          </h3>
          <p className="text-xs text-[var(--color-text-muted)]">
            Configured inference pipelines operating via your active provider keys.
          </p>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Text Reasoning:</span>
              <span className="text-blue-400 font-bold">Gemini 2.5 / Groq / Mistral</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Image Diffusion:</span>
              <span className="text-purple-400 font-bold">Cloudflare Flux-1 Schnell</span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
              <span className="text-[var(--color-text-muted)]">Answer Engine Radar:</span>
              <span className="text-emerald-400 font-bold">GEO / AEO Multi-Engine Live</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
