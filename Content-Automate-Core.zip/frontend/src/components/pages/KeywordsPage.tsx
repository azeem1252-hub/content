import { useState, useEffect, useMemo } from "react";
import {
  Target,
  RefreshCw,
  Zap,
  TrendingUp,
  AlertTriangle,
  HelpCircle,
  Search,
  ExternalLink,
  CheckCircle2,
  Filter,
  BarChart2,
  Globe,
  Layers,
  ArrowRight,
  ShieldAlert,
  Loader2,
  Bot,
  SlidersHorizontal,
  Sliders,
  Compass,
  Award,
  ChevronRight,
  TrendingDown,
  ShieldCheck,
  FolderGit2,
  FileText,
  RotateCw,
  GitMerge,
  Plus,
  PlusCircle,
  X,
  Database,
  Upload,
  Trash2,
  UserCheck,
  Volume2,
  BookOpen,
  Copy,
  Check,
  Link2,
  Sparkles,
} from "lucide-react";
import { usePipelineData } from "../../lib/dataContext";
import { useToast } from "../../lib/toast";
import { useNav } from "../../lib/nav";
import { api } from "../../lib/api";
import { Button } from "../ui";
import { Card } from "../Card";
import type {
  KeywordCandidate,
  KeywordSeed,
  EmpiricalReach,
  KeywordCluster,
  ContentPlanItem,
  ContentBrief,
  EvidenceItem,
  StyleProfile,
} from "../../types";

function cleanDisplayQuestion(qText?: string): string {
  if (!qText) return "";
  let s = qText.trim();
  s = s.replace(/^(?:what\s+is\s+(?:the\s+)?(?:best\s+approach\s+for|recommended\s+architecture\s+for)\s+)(what|how|why|which|when|where|can|should|is|are)\b/i, "$1");
  s = s.replace(/^How\s+does\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(?:\s+work(?:\s+in\s+practice)?)?\??$/i, "$1$2?");
  s = s.replace(/^What\s+are\s+common\s+pitfalls\s+when\s+implementing\s+(what|how|why|which|when|where|can|should|is|are)\b/i, "$1");
  s = s.replace(/^How\s+to\s+optimize\s+performance\s+for\s+(what|how|why|which|when|where|can|should|is|are)\b/i, "$1");
  s = s.replace(/^How\s+do\s+systems\s+implement\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(?:\s+efficiently)?\??$/i, "$1$2?");
  s = s.trim().replace(/\?+$/, "");
  return s ? s.charAt(0).toUpperCase() + s.slice(1) + "?" : "";
}

function cleanDisplayAnswerGuidance(ansText?: string): string {
  if (!ansText) return "";
  let s = ansText;
  s = s.replace(/answering\s+['"](?:What\s+is\s+(?:the\s+)?best\s+approach\s+for\s+|How\s+does\s+)?(what|how|why|which|when|where)\b/i, "answering '$1");
  s = s.replace(/answering\s+['"](.*?)work(?:\s+in\s+practice)?\??['"]/i, "answering '$1?'");
  return s;
}

export function KeywordsPage() {
  const { websites } = usePipelineData();
  const { push } = useToast();
  const { setPage } = useNav();

  const [selectedSiteId, setSelectedSiteId] = useState<string>("default");
  const [viewTab, setViewTab] = useState<"candidates" | "clusters" | "plan" | "evidence" | "voice">("candidates");

  const currentWebsite = websites.find((w) => w.id === selectedSiteId) || websites.find((w) => w.is_default) || websites[0];

  const [candidates, setCandidates] = useState<KeywordCandidate[]>([]);
  const [seeds, setSeeds] = useState<KeywordSeed[]>([]);
  const [reach, setReach] = useState<EmpiricalReach | null>(null);
  const [clusters, setClusters] = useState<KeywordCluster[]>([]);
  const [contentPlan, setContentPlan] = useState<ContentPlanItem[]>([]);
  const [evidenceItems, setEvidenceItems] = useState<EvidenceItem[]>([]);
  const [styleProfile, setStyleProfile] = useState<StyleProfile | null>(null);

  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [clusteringLoading, setClusteringLoading] = useState(false);
  const [calibratingReach, setCalibratingReach] = useState(false);
  const [calibratingVoice, setCalibratingVoice] = useState(false);
  const [approvingVoice, setApprovingVoice] = useState(false);
  const [uploadingEvidence, setUploadingEvidence] = useState(false);
  const [seedingEvidence, setSeedingEvidence] = useState(false);

  // Evidence vault creation state
  const [showAddEvidence, setShowAddEvidence] = useState(false);
  const [newEviTitle, setNewEviTitle] = useState("");
  const [newEviType, setNewEviType] = useState<string>("first_party_data");
  const [newEviContent, setNewEviContent] = useState("");
  const [newEviAuthor, setNewEviAuthor] = useState("");
  const [newEviUrl, setNewEviUrl] = useState("");
  const [evidenceFilter, setEvidenceFilter] = useState<string>("all");

  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [planActionFilter, setPlanActionFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [convertingId, setConvertingId] = useState<string | null>(null);

  const [activeBrief, setActiveBrief] = useState<ContentBrief | null>(null);
  const [briefLoading, setBriefLoading] = useState<boolean>(false);
  const [briefTargetKeyword, setBriefTargetKeyword] = useState<string>("");
  const [copiedBrief, setCopiedBrief] = useState<boolean>(false);

  const copyBriefToMarkdown = (brief: ContentBrief): string => {
    const sectionsMd = (brief.required_sections || [])
      .map(
        (s) =>
          `${s.level === 3 ? "###" : "##"} ${s.heading}\n- **Goal**: ${s.intent_goal}\n${s.answer_first_guidance ? `- **Answer-First Target**: ${s.answer_first_guidance}\n` : ""}${s.required_entities?.length ? `- **Key Entities**: ${s.required_entities.join(", ")}\n` : ""}`
      )
      .join("\n");

    const paaMd = (brief.questions_to_answer || [])
      .map((q) => `- **Q: ${cleanDisplayQuestion(q.question)}**\n  _${cleanDisplayAnswerGuidance(q.answer_first_form)}_`)
      .join("\n");

    const linksMd = (brief.internal_link_candidates || [])
      .map((l) => `- [${l.title}](${l.target_url || `/posts/${l.slug}`}) — ${l.context || "Cluster Authority"}`)
      .join("\n");

    return `# Content Brief: ${brief.primary_keyword}
**Target Reader**: ${brief.target_reader}
**Word Count Range**: ${brief.word_count_range?.min} – ${brief.word_count_range?.max} words (Median: ${brief.word_count_range?.target_median})

## Information Gain Angle (A3.2)
${brief.unique_angle}

## Table Stakes & Differentiators
- **Table Stakes**: ${brief.required_entities?.slice(0, 8).join(", ") || "None"}
- **Differentiators**: ${brief.required_entities?.slice(8).join(", ") || "None"}

## Section Blueprint
${sectionsMd}

## Questions to Answer (Direct-Answer Form)
${paaMd}

## Contextual Internal Links
${linksMd || "None specified"}

## Structured Data Schema Plan
${(brief.schema_plan || []).join(", ")}
`;
  };

  const handleViewBrief = async (keyword: string) => {
    setBriefTargetKeyword(keyword);
    setBriefLoading(true);
    setActiveBrief(null);
    try {
      const res = await api.fetchLiveBrief({
        keyword: keyword,
        website_id: selectedSiteId,
      });
      if (res && res.brief) {
        setActiveBrief(res.brief);
      } else {
        push({ title: "Brief Generation Failed", description: "Failed to generate evidence brief.", variant: "danger" });
      }
    } catch (err: any) {
      push({ title: "Brief Generation Error", description: `Error generating brief: ${err.message || err}`, variant: "danger" });
    } finally {
      setBriefLoading(false);
    }
  };

  // Load data on website change
  useEffect(() => {
    loadData();
  }, [selectedSiteId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [candRes, seedRes, reachRes, clusterRes, planRes, eviRes, voiceRes] = await Promise.all([
        api.getKeywordCandidates({ website_id: selectedSiteId, limit: 300 }),
        api.getKeywordSeeds(selectedSiteId),
        api.getEmpiricalReach(selectedSiteId).catch(() => null),
        api.getClusters(selectedSiteId).catch(() => ({ clusters: [], total: 0 })),
        api.getContentPlan({ website_id: selectedSiteId }).catch(() => ({ content_plan: [], total: 0 })),
        api.getEvidencePacks(selectedSiteId).catch(() => ({ evidence_items: [], total: 0 })),
        api.getStyleProfile(selectedSiteId).catch(() => ({ style_profile: null, website_id: selectedSiteId })),
      ]);
      setCandidates(candRes.candidates || []);
      setSeeds(seedRes.seeds || []);
      setReach(reachRes || null);
      setClusters(clusterRes.clusters || []);
      setContentPlan(planRes.content_plan || []);
      setEvidenceItems(eviRes.evidence_items || []);
      setStyleProfile(voiceRes.style_profile || null);
    } catch (err: any) {
      push({
        title: "Failed to load keywords data",
        description: err.message || "Could not retrieve keyword candidates and clusters",
        variant: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateCandidates = async () => {
    setGenerating(true);
    try {
      const compStr = currentWebsite?.competitor_domains;
      const competitorDomains = compStr
        ? String(compStr).split(",").map((d: string) => d.trim()).filter(Boolean)
        : [];
      const res = await api.generateKeywordCandidates({
        website_id: selectedSiteId,
        competitor_domains: competitorDomains.length > 0 ? competitorDomains : undefined,
      });
      push({
        title: "Candidate Generation Complete",
        description: `Discovered and enriched ${res.total_candidates} candidates across 4 merged sources.`,
        variant: "success",
      });
      await loadData();
    } catch (err: any) {
      push({
        title: "Candidate Generation Failed",
        description: err.message || "Error running 4-source keyword generation",
        variant: "error",
      });
    } finally {
      setGenerating(false);
    }
  };

  const handleRunClusteringAndPlan = async () => {
    setClusteringLoading(true);
    try {
      const res = await api.generateClusterPlan({
        website_id: selectedSiteId,
        overlap_threshold: 3,
        max_shortlist: 300,
      });
      push({
        title: "SERP Clustering & Content Plan Generated",
        description: `Formed ${res.total_clusters} clusters. Created ${res.total_plan_items} actionable items (New: ${res.actions_breakdown?.new || 0}, Refresh: ${res.actions_breakdown?.refresh || 0}, Consolidate: ${res.actions_breakdown?.consolidate || 0}).`,
        variant: "success",
      });
      await loadData();
      setViewTab("plan");
    } catch (err: any) {
      push({
        title: "Clustering Failed",
        description: err.message || "Error running SERP-overlap clustering",
        variant: "error",
      });
    } finally {
      setClusteringLoading(false);
    }
  };

  const handleCalibrateReach = async () => {
    setCalibratingReach(true);
    try {
      const res = await api.calibrateEmpiricalReach(selectedSiteId);
      setReach(res);
      push({
        title: "Empirical Reach Calibrated",
        description: `Median KD: ${res.median_kd}, Reach Ceiling (p75): ${res.p75_kd} (${res.is_new_site ? "Brand-new site baseline" : `${res.top10_keywords_count} top-10 keywords`})`,
        variant: "success",
      });
      const candRes = await api.getKeywordCandidates({ website_id: selectedSiteId, limit: 300 });
      setCandidates(candRes.candidates || []);
    } catch (err: any) {
      push({
        title: "Reach Calibration Failed",
        description: err.message || "Could not calibrate empirical reach",
        variant: "error",
      });
    } finally {
      setCalibratingReach(false);
    }
  };

  const handleConvertToArticle = async (cand: KeywordCandidate) => {
    setConvertingId(cand.id);
    try {
      const res = await api.convertKeywordToArticle({
        website_id: selectedSiteId,
        keyword: cand.keyword,
        candidate_id: cand.id,
        search_intent: cand.search_intent,
      });
      push({
        title: "Article Generation Launched",
        description: `Autonomous draft pipeline scheduled for: "${cand.keyword}"`,
        variant: "success",
      });
      setCandidates((prev) =>
        prev.map((c) => (c.id === cand.id ? { ...c, status: "scheduled" } : c))
      );
    } catch (err: any) {
      push({
        title: "Conversion Failed",
        description: err.message || "Could not start pipeline run",
        variant: "error",
      });
    } finally {
      setConvertingId(null);
    }
  };

  const handleExecutePlanItem = async (item: ContentPlanItem) => {
    setConvertingId(item.id);
    try {
      const res = await api.executeContentPlanItem({
        item_id: item.id,
        website_id: selectedSiteId,
        target_keyword: item.target_keyword,
        supporting_keywords: item.supporting_keywords,
        action: item.action,
        target_url: item.target_url,
      });
      push({
        title: `Plan Action Launched (${item.action.toUpperCase()})`,
        description: `Autonomous pipeline dispatched for: "${item.target_keyword}"`,
        variant: "success",
      });
      setContentPlan((prev) =>
        prev.map((p) => (p.id === item.id ? { ...p, status: "scheduled" } : p))
      );
    } catch (err: any) {
      push({
        title: "Execution Failed",
        description: err.message || "Could not execute content plan item",
        variant: "error",
      });
    } finally {
      setConvertingId(null);
    }
  };

  const handleUploadEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEviTitle.trim() || !newEviContent.trim()) {
      push({ title: "Validation Error", description: "Title and content are required.", variant: "error" });
      return;
    }
    setUploadingEvidence(true);
    try {
      await api.uploadEvidenceItem({
        website_id: selectedSiteId,
        title: newEviTitle.trim(),
        evidence_type: newEviType,
        content: newEviContent.trim(),
        author_or_expert: newEviAuthor.trim() || undefined,
        source_url: newEviUrl.trim() || undefined,
      });
      push({ title: "Evidence Vault Updated", description: "First-party evidence verified and saved.", variant: "success" });
      setNewEviTitle("");
      setNewEviContent("");
      setNewEviAuthor("");
      setNewEviUrl("");
      setShowAddEvidence(false);
      const updated = await api.getEvidencePacks(selectedSiteId);
      setEvidenceItems(updated.evidence_items || []);
    } catch (err: any) {
      push({ title: "Upload Failed", description: err.message || "Could not upload evidence", variant: "error" });
    } finally {
      setUploadingEvidence(false);
    }
  };

  const handleDeleteEvidence = async (id: string) => {
    try {
      await api.deleteEvidenceItem(id);
      setEvidenceItems((prev) => prev.filter((item) => item.id !== id));
      push({ title: "Evidence Item Archived", description: "Evidence item removed from vault.", variant: "success" });
    } catch (err: any) {
      push({ title: "Archive Failed", description: err.message || "Could not delete evidence", variant: "error" });
    }
  };

  const handleSeedEvidence = async () => {
    setSeedingEvidence(true);
    try {
      const res = await api.seedEvidencePacks(selectedSiteId);
      setEvidenceItems(res.evidence_items || []);
      push({
        title: "Evidence Vault Seeded",
        description: `Seeded ${res.seeded || 4} verified 1st-party benchmarks & quotes.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Seeding Failed",
        description: err.message || "Could not seed sample evidence.",
        variant: "error",
      });
    } finally {
      setSeedingEvidence(false);
    }
  };

  const handleCalibrateVoice = async () => {
    setCalibratingVoice(true);
    try {
      const res = await api.buildStyleProfile(selectedSiteId);
      setStyleProfile(res.style_profile || null);
      push({
        title: "Style Profile Calibrated",
        description: "Brand voice analyzed from approved articles. Awaiting human editorial approval.",
        variant: "success",
      });
    } catch (err: any) {
      push({ title: "Calibration Failed", description: err.message || "Could not calibrate style profile", variant: "error" });
    } finally {
      setCalibratingVoice(false);
    }
  };

  const handleApproveVoice = async () => {
    setApprovingVoice(true);
    try {
      const res = await api.approveStyleProfile(selectedSiteId);
      setStyleProfile(res.style_profile || null);
      push({
        title: "Brand Voice Approved",
        description: "Style profile validated and locked for upcoming autonomous runs.",
        variant: "success",
      });
    } catch (err: any) {
      push({ title: "Approval Failed", description: err.message || "Could not approve style profile", variant: "error" });
    } finally {
      setApprovingVoice(false);
    }
  };

  // Filter and search for Candidates
  const filteredCandidates = useMemo(() => {
    return candidates.filter((c) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!c.keyword.toLowerCase().includes(q)) return false;
      }
      if (activeFilter === "attainable") return c.attainability_status === "attainable";
      if (activeFilter === "stretch") return c.attainability_status === "stretch";
      if (activeFilter === "out_of_reach") return c.attainability_status === "out_of_reach";
      if (activeFilter === "striking") return c.opportunity_type === "striking_distance";
      if (activeFilter === "competitor") return c.source === "competitor_gap";
      if (activeFilter === "seed") return c.source === "seed_expansion";
      if (activeFilter === "questions") return c.source === "paa_question";
      if (activeFilter === "cannibalized") return (c.cannibalizing_urls?.length || 0) > 1;
      return true;
    });
  }, [candidates, activeFilter, searchQuery]);

  // Filter for Content Plan
  const filteredContentPlan = useMemo(() => {
    return contentPlan.filter((p) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!p.target_keyword.toLowerCase().includes(q)) return false;
      }
      if (planActionFilter === "new") return p.action === "new";
      if (planActionFilter === "refresh") return p.action === "refresh";
      if (planActionFilter === "consolidate") return p.action === "consolidate";
      return true;
    });
  }, [contentPlan, planActionFilter, searchQuery]);

  // KPI aggregations
  const stats = useMemo(() => {
    const striking = candidates.filter((c) => c.opportunity_type === "striking_distance").length;
    const gaps = candidates.filter((c) => c.source === "competitor_gap").length;
    const questions = candidates.filter((c) => c.source === "paa_question").length;
    const attainable = candidates.filter((c) => c.attainability_status === "attainable").length;
    const stretch = candidates.filter((c) => c.attainability_status === "stretch").length;
    const outOfReach = candidates.filter((c) => c.attainability_status === "out_of_reach").length;
    const totalExpectedClicks = Math.round(
      candidates.reduce((sum, c) => sum + (c.expected_clicks || 0), 0)
    );
    const avgScore = candidates.length
      ? Math.round(candidates.reduce((sum, c) => sum + (c.opportunity_score || 0), 0) / candidates.length)
      : 84;

    const planNew = contentPlan.filter((p) => p.action === "new").length;
    const planRefresh = contentPlan.filter((p) => p.action === "refresh").length;
    const planConsolidate = contentPlan.filter((p) => p.action === "consolidate").length;

    return {
      striking,
      gaps,
      questions,
      attainable,
      stretch,
      outOfReach,
      totalExpectedClicks,
      avgScore,
      planNew,
      planRefresh,
      planConsolidate,
    };
  }, [candidates, contentPlan]);

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
      {/* Standardized aligned header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
              SERP Keyword Intelligence
            </h1>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--color-accent)]/30 bg-[var(--color-accent-soft)] px-2.5 py-0.5 text-[11px] font-semibold text-[var(--color-accent-text)]">
              Pillars A1.1–A1.6
            </span>
          </div>
          <p className="mt-1 text-xs text-[var(--color-text-muted)]">
            4-Source Discovery, Empirical Reach Calibration, Mathematical Scoring Formula &amp; SERP Clustering.
          </p>
        </div>

        {/* Global Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedSiteId}
            onChange={(e) => setSelectedSiteId(e.target.value)}
            className="rounded-lg border bg-[var(--color-bg-elev)] px-3 py-1.5 text-xs font-medium text-[var(--color-text)]"
            style={{ borderColor: "var(--color-border)" }}
          >
            <option value="default">Default Target Site</option>
            {websites.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>

          <Button
            variant="secondary"
            size="sm"
            onClick={loadData}
            icon={<RefreshCw size={13} className={loading ? "animate-spin" : ""} />}
          >
            Refresh
          </Button>

          <Button
            variant="secondary"
            size="sm"
            onClick={handleRunClusteringAndPlan}
            disabled={clusteringLoading}
            icon={clusteringLoading ? <Loader2 size={13} className="animate-spin" /> : <Layers size={13} />}
          >
            {clusteringLoading ? "Clustering SERPs..." : "Run SERP Clustering & Plan"}
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={handleGenerateCandidates}
            icon={generating ? <Loader2 size={13} className="animate-spin" /> : <Search size={13} />}
          >
            {generating ? "Harvesting 4 Sources..." : "Harvest 4 Sources"}
          </Button>
        </div>
      </div>

      {/* Pillar A1.3: Empirical Reach Dashboard Widget */}
      <div
        className="rounded-xl border p-4.5 text-xs leading-relaxed"
        style={{
          background: "linear-gradient(135deg, rgba(16,185,129,0.05) 0%, rgba(56,189,248,0.05) 100%)",
          borderColor: "rgba(16,185,129,0.3)",
        }}
      >
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 font-semibold text-[#10b981]">
              <Compass size={16} />
              <span className="text-sm">Pillar A1.3: Site-Specific Empirical Reach (No Guessing)</span>
              {reach?.is_new_site && (
                <span className="rounded bg-[rgba(245,158,11,0.15)] px-2 py-0.5 text-[10px] text-[#f59e0b] font-medium">
                  Brand-New Site Baseline
                </span>
              )}
            </div>
            <p className="text-[var(--color-text-muted)] max-w-3xl">
              Calibrated from first-party data: Median <strong>{reach?.median_kd ?? 20} KD</strong> and Reach Ceiling <strong>{reach?.p75_kd ?? 30} KD (p75)</strong> where your site proves it ranks in positions 1–10. Scoring formula: <code>opportunity = expected_clicks × business_fit × feasibility × freshness_factor</code>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 rounded-lg bg-[var(--color-bg-elev)] border px-3 py-2" style={{ borderColor: "var(--color-border)" }}>
              <div>
                <div className="text-[10px] text-[var(--color-text-muted)] uppercase font-semibold">Median KD (p50)</div>
                <div className="font-mono text-base font-bold text-[#10b981]">{reach?.median_kd ?? 20.0}</div>
              </div>
              <div className="h-6 w-px bg-[var(--color-border)] mx-1" />
              <div>
                <div className="text-[10px] text-[var(--color-text-muted)] uppercase font-semibold">Reach Ceiling (p75)</div>
                <div className="font-mono text-base font-bold text-[#38bdf8]">{reach?.p75_kd ?? 30.0}</div>
              </div>
              <div className="h-6 w-px bg-[var(--color-border)] mx-1" />
              <div>
                <div className="text-[10px] text-[var(--color-text-muted)] uppercase font-semibold">Top-10 Proofs</div>
                <div className="font-mono text-base font-bold text-[var(--color-text)]">
                  {reach?.is_new_site ? "0 (Long-Tail)" : `${reach?.top10_keywords_count ?? 0} kws`}
                </div>
              </div>
            </div>

            <Button
              variant="secondary"
              size="sm"
              onClick={handleCalibrateReach}
              disabled={calibratingReach}
              icon={calibratingReach ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
            >
              {calibratingReach ? "Calibrating..." : "Recalibrate Monthly"}
            </Button>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex border-b" style={{ borderColor: "var(--color-border)" }}>
        <button
          onClick={() => setViewTab("candidates")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            viewTab === "candidates"
              ? "border-[var(--color-accent)] text-[var(--color-accent-text)]"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Target size={14} />
          <span>Keyword Candidates ({candidates.length})</span>
        </button>

        <button
          onClick={() => setViewTab("clusters")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            viewTab === "clusters"
              ? "border-[var(--color-accent)] text-[var(--color-accent-text)]"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Layers size={14} />
          <span>SERP Overlap Clusters ({clusters.length})</span>
        </button>

        <button
          onClick={() => setViewTab("plan")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            viewTab === "plan"
              ? "border-[var(--color-accent)] text-[var(--color-accent-text)]"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <FolderGit2 size={14} />
          <span>Prioritized Content Plan ({contentPlan.length})</span>
          {contentPlan.length > 0 && (
            <span className="rounded-full bg-[var(--color-accent-soft)] px-1.5 py-0.2 text-[10px] text-[var(--color-accent)]">
              Action Ready
            </span>
          )}
        </button>

        <button
          onClick={() => setViewTab("evidence")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            viewTab === "evidence"
              ? "border-[var(--color-accent)] text-[var(--color-accent-text)]"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Database size={14} />
          <span>Evidence Vault ({evidenceItems.length})</span>
          {evidenceItems.length > 0 ? (
            <span className="rounded-full bg-[#10b981]/15 px-1.5 py-0.2 text-[10px] text-[#10b981] font-semibold">
              Gated &amp; Ready
            </span>
          ) : (
            <span className="rounded-full bg-amber-500/15 px-1.5 py-0.2 text-[10px] text-amber-500 font-semibold">
              Setup (0)
            </span>
          )}
        </button>

        <button
          onClick={() => setViewTab("voice")}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            viewTab === "voice"
              ? "border-[var(--color-accent)] text-[var(--color-accent-text)]"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Sliders size={14} />
          <span>Brand Voice &amp; Style Profile</span>
          {styleProfile?.status === "pending_review" && (
            <span className="rounded-full bg-amber-500/20 px-1.5 py-0.2 text-[10px] text-amber-500 font-semibold">
              Review
            </span>
          )}
        </button>
      </div>

      {/* VIEW 1: CANDIDATES */}
      {viewTab === "candidates" && (
        <div className="space-y-4">
          {/* KPI Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-6">
            <Card className="p-3">
              <div className="text-[10px] font-medium text-[var(--color-text-muted)]">Candidates</div>
              <div className="mt-1 font-mono text-lg font-bold text-[var(--color-text)]">{candidates.length}</div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">Deduplicated across 4 sources</div>
            </Card>

            <Card className="p-3">
              <div className="text-[10px] font-medium text-[#10b981]">✅ Attainable (&le; p75)</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#10b981]">{stats.attainable}</div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">Feasibility &gt; 0.50</div>
            </Card>

            <Card className="p-3">
              <div className="text-[10px] font-medium text-[#f59e0b]">⚡ Stretch Reach</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#f59e0b]">{stats.stretch}</div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">Within +15 KD</div>
            </Card>

            <Card className="p-3">
              <div className="text-[10px] font-medium text-[#38bdf8]">🎯 Striking Distance</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#38bdf8]">{stats.striking}</div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">GSC Pos 8–30</div>
            </Card>

            <Card className="p-3">
              <div className="text-[10px] font-medium text-[#a855f7]">📈 Expected Clicks</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#a855f7]">
                {stats.totalExpectedClicks.toLocaleString()}
              </div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">Monthly CTR Projected</div>
            </Card>

            <Card className="p-3">
              <div className="text-[10px] font-medium text-[var(--color-accent-text)]">Avg Opp. Score</div>
              <div className="mt-1 font-mono text-lg font-bold text-[var(--color-accent-text)]">{stats.avgScore}/100</div>
              <div className="mt-0.5 text-[9px] text-[var(--color-text-muted)]">Formula Calibrated</div>
            </Card>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: "all", label: `All (${candidates.length})` },
                { id: "attainable", label: `✅ Attainable (${stats.attainable})` },
                { id: "stretch", label: `⚡ Stretch (${stats.stretch})` },
                { id: "out_of_reach", label: `🚫 Deprioritised (${stats.outOfReach})` },
                { id: "striking", label: `🎯 Striking Distance (${stats.striking})` },
                { id: "competitor", label: `⚔️ Competitor Gap (${stats.gaps})` },
                { id: "questions", label: `❓ PAA Questions (${stats.questions})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                    activeFilter === tab.id
                      ? "bg-[var(--color-accent)] text-white shadow-sm"
                      : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:text-[var(--color-text)] border"
                  }`}
                  style={{ borderColor: activeFilter === tab.id ? "transparent" : "var(--color-border)" }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" />
              <input
                type="text"
                placeholder="Search candidates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-lg border bg-[var(--color-bg-elev)] pl-8 pr-3 py-1.5 text-xs text-[var(--color-text)]"
                style={{ borderColor: "var(--color-border)" }}
              />
            </div>
          </div>

          {/* Candidate List */}
          {loading ? (
            <div className="flex items-center justify-center p-12 text-xs text-[var(--color-text-muted)]">
              <Loader2 size={16} className="animate-spin mr-2" /> Loading calibrated candidates...
            </div>
          ) : filteredCandidates.length === 0 ? (
            <Card className="p-8 text-center text-xs text-[var(--color-text-muted)]">
              <Target size={28} className="mx-auto mb-2 opacity-50" />
              <div className="font-semibold text-sm text-[var(--color-text)]">No Candidate Keywords Found</div>
              <p className="mt-1">Run 4-source generation to harvest striking-distance, competitor gaps, seeds, and PAA.</p>
            </Card>
          ) : (
            <div className="space-y-2.5">
              {filteredCandidates.map((cand) => {
                const attainStatus = cand.attainability_status || "attainable";
                const kdDelta = cand.kd_delta_from_reach ?? 0;

                return (
                  <Card key={cand.id} className="p-4 transition hover:border-[var(--color-accent)]">
                    <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center">
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-bold text-[var(--color-text)]">{cand.keyword}</span>

                          {/* Attainability Badge */}
                          <span
                            className="rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider flex items-center gap-1"
                            style={{
                              background:
                                attainStatus === "attainable"
                                  ? "rgba(16,185,129,0.15)"
                                  : attainStatus === "stretch"
                                  ? "rgba(245,158,11,0.15)"
                                  : "rgba(239,68,68,0.15)",
                              color:
                                attainStatus === "attainable"
                                  ? "#10b981"
                                  : attainStatus === "stretch"
                                  ? "#f59e0b"
                                  : "#ef4444",
                            }}
                          >
                            {attainStatus === "attainable" ? (
                              <>
                                <ShieldCheck size={11} /> Attainable (KD &le; {reach?.p75_kd ?? 30})
                              </>
                            ) : attainStatus === "stretch" ? (
                              <>
                                <TrendingUp size={11} /> Stretch (+{kdDelta} KD)
                              </>
                            ) : (
                              <>
                                <TrendingDown size={11} /> Deprioritised (+{kdDelta} KD)
                              </>
                            )}
                          </span>

                          <span className="rounded border px-1.5 py-0.5 text-[10px] font-medium" style={{ borderColor: "var(--color-border)" }}>
                            {cand.search_intent}
                          </span>

                          {cand.ai_search_volume > 0 && (
                            <span className="rounded bg-[rgba(168,85,247,0.12)] px-2 py-0.5 text-[10px] font-medium text-[#a855f7] flex items-center gap-1">
                              <Bot size={11} /> AI Chatbot Query
                            </span>
                          )}
                        </div>

                        {/* Metrics Row */}
                        <div className="flex flex-wrap items-center gap-3 text-xs text-[var(--color-text-muted)]">
                          <div>
                            Volume: <strong className="text-[var(--color-text)]">{cand.search_volume ? `${cand.search_volume.toLocaleString()}/mo` : "N/A"}</strong>
                          </div>
                          <div>
                            Expected Clicks: <strong className="text-[#a855f7]">{cand.expected_clicks ? Math.round(cand.expected_clicks) : 0}/mo</strong>
                          </div>
                          <div>
                            Feasibility: <strong className="text-[var(--color-text)]">{cand.feasibility !== undefined ? cand.feasibility.toFixed(2) : "0.50"}</strong>
                          </div>
                          <div>
                            Fit: <strong className="text-[var(--color-text)]">{cand.business_fit !== undefined ? cand.business_fit.toFixed(2) : "0.85"}</strong>
                          </div>
                          <div>
                            KD: <span className="font-mono">{Math.round(cand.keyword_difficulty)}/100</span>
                          </div>
                          {cand.avg_position !== undefined && cand.avg_position !== null && (
                            <div className="rounded bg-[var(--color-bg-soft)] px-2 py-0.5 text-[11px] font-mono text-[#10b981]">
                              Rank: #{cand.avg_position.toFixed(1)}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right Column: Score & Action */}
                      <div className="flex items-center gap-4 border-t pt-3 md:border-t-0 md:pt-0">
                        <div className="text-right">
                          <div className="text-[10px] uppercase tracking-wider font-semibold text-[var(--color-text-muted)]">Opp. Score</div>
                          <div
                            className="font-mono text-lg font-bold"
                            style={{
                              color:
                                cand.opportunity_score >= 80
                                  ? "#10b981"
                                  : cand.opportunity_score >= 65
                                  ? "#38bdf8"
                                  : "#f59e0b",
                            }}
                          >
                            {cand.opportunity_score}/100
                          </div>
                        </div>

                        <Button
                          variant={cand.status === "scheduled" ? "secondary" : "primary"}
                          size="sm"
                          disabled={convertingId === cand.id || cand.status === "scheduled"}
                          onClick={() => handleConvertToArticle(cand)}
                          icon={
                            convertingId === cand.id ? (
                              <Loader2 size={13} className="animate-spin" />
                            ) : cand.status === "scheduled" ? (
                              <CheckCircle2 size={13} className="text-[#10b981]" />
                            ) : (
                              <Zap size={13} />
                            )
                          }
                        >
                          {convertingId === cand.id ? "Launching..." : cand.status === "scheduled" ? "Scheduled" : "Draft Article"}
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: SERP OVERLAP CLUSTERS */}
      {viewTab === "clusters" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-[var(--color-text-muted)]">
              Pillar A1.5: Keywords sharing &ge; 3 top-10 SERP URLs grouped into single pages to completely eliminate cannibalisation.
            </p>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleRunClusteringAndPlan}
              disabled={clusteringLoading}
              icon={clusteringLoading ? <Loader2 size={13} className="animate-spin" /> : <Layers size={13} />}
            >
              {clusteringLoading ? "Clustering SERPs..." : "Re-Cluster Top Keywords"}
            </Button>
          </div>

          {clusters.length === 0 ? (
            <Card className="p-8 text-center text-xs text-[var(--color-text-muted)]">
              <Layers size={28} className="mx-auto mb-2 opacity-50" />
              <div className="font-semibold text-sm text-[var(--color-text)]">No SERP Clusters Formed Yet</div>
              <p className="mt-1">Click "Run SERP Clustering &amp; Plan" to group shortlisted keywords by organic SERP URL overlap.</p>
              <Button
                variant="primary"
                size="sm"
                className="mt-4"
                onClick={handleRunClusteringAndPlan}
                disabled={clusteringLoading}
                icon={<Layers size={13} />}
              >
                Run SERP Overlap Clustering
              </Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {clusters.map((cl) => (
                <Card key={cl.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-sm font-bold text-[var(--color-text)]">{cl.cluster_name}</div>
                      <div className="text-[11px] text-[var(--color-text-muted)]">
                        Primary Target: <strong className="text-[var(--color-text)]">{cl.primary_keyword}</strong>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="font-mono text-sm font-bold text-[#10b981]">{cl.cluster_score}/100</span>
                      <div className="text-[9px] uppercase tracking-wider text-[var(--color-text-muted)]">Score</div>
                    </div>
                  </div>

                  {/* Supporting keywords tags */}
                  <div>
                    <div className="text-[10px] font-semibold uppercase text-[var(--color-text-muted)] mb-1">
                      Supporting Keywords ({cl.supporting_keywords?.length || 0})
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {cl.supporting_keywords && cl.supporting_keywords.length > 0 ? (
                        cl.supporting_keywords.map((sk, idx) => (
                          <span
                            key={idx}
                            className="rounded bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)] border"
                            style={{ borderColor: "var(--color-border)" }}
                          >
                            {sk}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] italic text-[var(--color-text-muted)]">Stand-alone focus keyword</span>
                      )}
                    </div>
                  </div>

                  {/* Cluster metadata */}
                  <div className="flex items-center justify-between text-xs text-[var(--color-text-muted)] border-t pt-2" style={{ borderColor: "var(--color-border)" }}>
                    <div className="flex items-center gap-3">
                      <span>Agg. Vol: <strong className="text-[var(--color-text)]">{(cl.aggregate_volume || 0).toLocaleString()}</strong></span>
                      <span>Shared URLs: <strong className="text-[#38bdf8]">&ge; {cl.shared_urls_count}</strong></span>
                    </div>

                    <span
                      className="rounded px-2 py-0.5 text-[10px] font-semibold uppercase"
                      style={{
                        background:
                          cl.action === "refresh"
                            ? "rgba(56,189,248,0.15)"
                            : cl.action === "consolidate"
                            ? "rgba(245,158,11,0.15)"
                            : "rgba(16,185,129,0.15)",
                        color:
                          cl.action === "refresh"
                            ? "#38bdf8"
                            : cl.action === "consolidate"
                            ? "#f59e0b"
                            : "#10b981",
                      }}
                    >
                      {cl.action}
                    </span>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 3: PRIORITIZED CONTENT PLAN */}
      {viewTab === "plan" && (
        <div className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: "all", label: `All Plan Items (${contentPlan.length})` },
                { id: "new", label: `✨ New Articles (${stats.planNew})` },
                { id: "refresh", label: `🔄 Refresh Existing (${stats.planRefresh})` },
                { id: "consolidate", label: `🔀 Consolidate Authority (${stats.planConsolidate})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setPlanActionFilter(tab.id)}
                  className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                    planActionFilter === tab.id
                      ? "bg-[var(--color-accent)] text-white shadow-sm"
                      : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:text-[var(--color-text)] border"
                  }`}
                  style={{ borderColor: planActionFilter === tab.id ? "transparent" : "var(--color-border)" }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" />
              <input
                type="text"
                placeholder="Search plan items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-lg border bg-[var(--color-bg-elev)] pl-8 pr-3 py-1.5 text-xs text-[var(--color-text)]"
                style={{ borderColor: "var(--color-border)" }}
              />
            </div>
          </div>

          {filteredContentPlan.length === 0 ? (
            <Card className="p-8 text-center text-xs text-[var(--color-text-muted)]">
              <FolderGit2 size={28} className="mx-auto mb-2 opacity-50" />
              <div className="font-semibold text-sm text-[var(--color-text)]">No Content Plan Generated Yet</div>
              <p className="mt-1">Generate SERP overlap clusters to automatically map new, refresh, and consolidation actions.</p>
              <Button
                variant="primary"
                size="sm"
                className="mt-4"
                onClick={handleRunClusteringAndPlan}
                disabled={clusteringLoading}
                icon={<Layers size={13} />}
              >
                Generate Content Plan Now
              </Button>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredContentPlan.map((item) => {
                const isNew = item.action === "new";
                const isRefresh = item.action === "refresh";
                const isConsolidate = item.action === "consolidate";

                return (
                  <Card key={item.id} className="p-4 transition hover:border-[var(--color-accent)]">
                    <div className="flex flex-col justify-between gap-3 md:flex-row md:items-start">
                      <div className="space-y-2 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Action Badge */}
                          <span
                            className="rounded px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1"
                            style={{
                              background: isNew
                                ? "rgba(16,185,129,0.15)"
                                : isRefresh
                                ? "rgba(56,189,248,0.15)"
                                : "rgba(245,158,11,0.15)",
                              color: isNew ? "#10b981" : isRefresh ? "#38bdf8" : "#f59e0b",
                            }}
                          >
                            {isNew ? (
                              <>
                                <PlusCircle size={11} /> New Pillar
                              </>
                            ) : isRefresh ? (
                              <>
                                <RotateCw size={11} /> Refresh Existing
                              </>
                            ) : (
                              <>
                                <GitMerge size={11} /> Consolidate
                              </>
                            )}
                          </span>

                          <span className="text-sm font-bold text-[var(--color-text)]">
                            {item.target_keyword}
                          </span>

                          <span className="rounded border px-1.5 py-0.5 text-[10px] font-medium" style={{ borderColor: "var(--color-border)" }}>
                            {item.intent}
                          </span>
                        </div>

                        {/* Strategic Rationale Note */}
                        <p className="text-xs text-[var(--color-text-muted)] leading-relaxed bg-[var(--color-bg-soft)] p-2 rounded border" style={{ borderColor: "var(--color-border)" }}>
                          <strong>Reason:</strong> {item.reason}
                        </p>

                        {/* Supporting keywords tags */}
                        {item.supporting_keywords && item.supporting_keywords.length > 0 && (
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="text-[10px] font-semibold text-[var(--color-text-muted)]">Cover in Subheadings:</span>
                            {item.supporting_keywords.map((sk, idx) => (
                              <span
                                key={idx}
                                className="rounded bg-[var(--color-bg-elev)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)] border"
                                style={{ borderColor: "var(--color-border)" }}
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        )}

                        {/* Target URL if refresh or consolidate */}
                        {item.target_url && (
                          <div className="text-[11px] text-[var(--color-text-muted)] flex items-center gap-1">
                            <span>Target Page:</span>
                            <code className="text-[#38bdf8] font-mono text-[10px]">{item.target_url}</code>
                          </div>
                        )}
                      </div>

                      {/* Right Column: Score & Action Button */}
                      <div className="flex md:flex-col items-end justify-between md:justify-center gap-3 border-t pt-2 md:border-t-0 md:pt-0">
                        <div className="text-right">
                          <div className="text-[10px] uppercase font-semibold text-[var(--color-text-muted)]">Priority Score</div>
                          <div className="font-mono text-base font-bold text-[#10b981]">{item.score}/100</div>
                          <div className="text-[10px] text-[var(--color-text-muted)]">~{Math.round(item.expected_clicks)} clicks/mo</div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => handleViewBrief(item.target_keyword)}
                            icon={<FileText size={13} className="text-[#38bdf8]" />}
                          >
                            Evidence Brief
                          </Button>

                          <Button
                            variant={item.status === "scheduled" ? "secondary" : "primary"}
                            size="sm"
                            disabled={convertingId === item.id || item.status === "scheduled"}
                            onClick={() => handleExecutePlanItem(item)}
                            icon={
                              convertingId === item.id ? (
                                <Loader2 size={13} className="animate-spin" />
                              ) : item.status === "scheduled" ? (
                                <CheckCircle2 size={13} className="text-[#10b981]" />
                              ) : isRefresh ? (
                                <RotateCw size={13} />
                              ) : isConsolidate ? (
                                <GitMerge size={13} />
                              ) : (
                                <Zap size={13} />
                              )
                            }
                          >
                            {convertingId === item.id
                              ? "Dispatching..."
                              : item.status === "scheduled"
                              ? "Scheduled"
                              : isRefresh
                              ? "Execute Refresh"
                              : isConsolidate
                              ? "Consolidate"
                              : "Draft Article"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 4: EVIDENCE VAULT (Pillar A3.2) */}
      {viewTab === "evidence" && (
        <div className="space-y-5">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <h2 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
                <Database size={16} className="text-[#10b981]" />
                <span>Evidence Vault — Originality Engine (Pillar A3.2)</span>
              </h2>
              <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                Google Scaled-Content Policy Gating: Articles cite genuine first-party evidence (telemetry benchmarks, customer case studies, or practitioner interviews) to secure durable E-E-A-T rankings and AI citations.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleSeedEvidence}
                disabled={seedingEvidence}
                icon={seedingEvidence ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              >
                {seedingEvidence ? "Seeding..." : "Seed 4 Sample Evidence Items"}
              </Button>

              <Button
                variant="primary"
                size="sm"
                onClick={() => setShowAddEvidence(!showAddEvidence)}
                icon={<Upload size={13} />}
              >
                {showAddEvidence ? "Close Upload Form" : "Upload Evidence Item"}
              </Button>
            </div>
          </div>

          {/* Educational Explainer Banner: Google Scaled Content & E-E-A-T Engine */}
          <div className="rounded-xl border p-4 bg-[var(--color-bg-elev)] space-y-3" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-[#10b981]" />
                <span className="text-xs font-bold text-[var(--color-text)]">
                  How the Originality Engine Works (Pillar A3.2 &amp; E-E-A-T Architecture)
                </span>
              </div>
              <span className="text-[10px] text-[var(--color-text-muted)] font-mono">
                Google Scaled-Content Compliant
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="rounded-lg bg-[var(--color-bg-soft)] p-3 border" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#10b981] mb-1">
                  1. First-Party Proof
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  Stores proprietary telemetry numbers, benchmark latencies, customer migration cases, and direct practitioner interviews.
                </p>
              </div>

              <div className="rounded-lg bg-[var(--color-bg-soft)] p-3 border" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#38bdf8] mb-1">
                  2. Google Policy Gating
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  Google updates actively demote generic AI rewrites. Verified empirical evidence separates your publication from automated spam.
                </p>
              </div>

              <div className="rounded-lg bg-[var(--color-bg-soft)] p-3 border" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#a855f7] mb-1">
                  3. Vector Auto-Injection
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  During drafting, sections use dense cosine similarity to match and seamlessly weave proof items with formal attribution.
                </p>
              </div>

              <div className="rounded-lg bg-[var(--color-bg-soft)] p-3 border" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#f59e0b] mb-1">
                  4. AI Citations (GEO)
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  Generative engines (Perplexity, ChatGPT, Google AI Overviews) prioritize and cite articles with specific verifiable data points.
                </p>
              </div>
            </div>
          </div>

          {/* Add Evidence Modal/Drawer Form */}
          {showAddEvidence && (
            <Card className="p-5 border-2" style={{ borderColor: "var(--color-accent)" }}>
              <div className="flex items-center justify-between border-b pb-3 mb-4" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2 text-xs font-bold text-[var(--color-text)]">
                  <Upload size={14} className="text-[var(--color-accent)]" />
                  <span>Deposit First-Party Evidence to Vault</span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAddEvidence(false)}
                  className="rounded p-1 text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                >
                  <X size={14} />
                </button>
              </div>

              <form onSubmit={handleUploadEvidence} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-[var(--color-text)] mb-1">
                      Evidence Title *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Q4 2026 Production Netcode Telemetry & L1 Latency"
                      value={newEviTitle}
                      onChange={(e) => setNewEviTitle(e.target.value)}
                      required
                      className="w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 py-1.5 text-xs text-[var(--color-text)] focus:outline-hidden"
                      style={{ borderColor: "var(--color-border)" }}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[var(--color-text)] mb-1">
                      Evidence Type *
                    </label>
                    <select
                      value={newEviType}
                      onChange={(e) => setNewEviType(e.target.value)}
                      className="w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 py-1.5 text-xs text-[var(--color-text)] focus:outline-hidden"
                      style={{ borderColor: "var(--color-border)" }}
                    >
                      <option value="first_party_data">First-Party Data (Benchmarks, Telemetry, Database Stats)</option>
                      <option value="customer_example">Customer Example (Case Study, Production Deployment)</option>
                      <option value="expert_quote">Expert Quote / Interview (Attributed Practitioner Perspective)</option>
                      <option value="original_results">Original Results (Test Results, Benchmark Charts)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[var(--color-text)] mb-1">
                    Evidence Body / Finding Content *
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Paste the concrete metrics, interview transcript, benchmark observations, or empirical findings. Be specific (exact measurements, percentages, timings, or quotes)..."
                    value={newEviContent}
                    onChange={(e) => setNewEviContent(e.target.value)}
                    required
                    className="w-full rounded-lg border bg-[var(--color-bg-elev)] p-3 text-xs text-[var(--color-text)] font-mono leading-relaxed focus:outline-hidden"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-[var(--color-text)] mb-1">
                      Author / Quoted Expert (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Sarah Lin, Principal Infrastructure Architect"
                      value={newEviAuthor}
                      onChange={(e) => setNewEviAuthor(e.target.value)}
                      className="w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 py-1.5 text-xs text-[var(--color-text)] focus:outline-hidden"
                      style={{ borderColor: "var(--color-border)" }}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-[var(--color-text)] mb-1">
                      Source / Verification URL (Optional)
                    </label>
                    <input
                      type="url"
                      placeholder="https://internal-docs.example.com/telemetry-2026"
                      value={newEviUrl}
                      onChange={(e) => setNewEviUrl(e.target.value)}
                      className="w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 py-1.5 text-xs text-[var(--color-text)] focus:outline-hidden"
                      style={{ borderColor: "var(--color-border)" }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => setShowAddEvidence(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    disabled={uploadingEvidence}
                    icon={uploadingEvidence ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
                  >
                    {uploadingEvidence ? "Depositing..." : "Deposit to Vault"}
                  </Button>
                </div>
              </form>
            </Card>
          )}

          {/* Evidence Items Grid */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-[var(--color-text-muted)]">
              <span>Filter Category:</span>
              {["all", "first_party_data", "customer_example", "expert_quote", "original_results"].map((type) => (
                <button
                  key={type}
                  onClick={() => setEvidenceFilter(type)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition ${
                    evidenceFilter === type
                      ? "bg-[var(--color-accent-soft)] text-[var(--color-accent-text)] font-semibold"
                      : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                  }`}
                >
                  {type === "all"
                    ? "All Evidence"
                    : type === "first_party_data"
                    ? "1st-Party Data"
                    : type === "customer_example"
                    ? "Customer Example"
                    : type === "expert_quote"
                    ? "Expert Quote"
                    : "Original Results"}
                </button>
              ))}
            </div>

            <div className="text-[11px] text-[var(--color-text-muted)] font-mono">
              {evidenceItems.length} Verified Evidence Items in Vault
            </div>
          </div>

          {evidenceItems.length === 0 ? (
            <Card className="p-8 text-center text-xs text-[var(--color-text-muted)]">
              <Database size={28} className="mx-auto mb-2 text-amber-500 opacity-80" />
              <div className="font-semibold text-sm text-[var(--color-text)]">
                Evidence Vault Ready for Verification
              </div>
              <p className="mt-1.5 max-w-lg mx-auto leading-relaxed">
                To satisfy Google's Scaled Content Policy and guarantee durable E-E-A-T rankings, articles cite genuine first-party benchmarks, telemetry, or expert quotes. Seed realistic sample proof below or deposit your custom findings.
              </p>
              <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleSeedEvidence}
                  disabled={seedingEvidence}
                  icon={seedingEvidence ? <Loader2 size={13} className="animate-spin" /> : <Database size={13} />}
                >
                  {seedingEvidence ? "Seeding..." : "Seed 4 Sample Evidence Items (1-Click Quickstart)"}
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setShowAddEvidence(true)}
                  icon={<Upload size={13} />}
                >
                  Deposit Custom Evidence Item
                </Button>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {evidenceItems
                .filter((item) => evidenceFilter === "all" || item.evidence_type === evidenceFilter)
                .map((item) => (
                  <Card key={item.id} className="p-4 flex flex-col justify-between hover:border-[var(--color-accent)] transition">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                          item.evidence_type === "first_party_data"
                            ? "bg-[#10b981]/15 text-[#10b981]"
                            : item.evidence_type === "expert_quote"
                            ? "bg-[#38bdf8]/15 text-[#38bdf8]"
                            : item.evidence_type === "customer_example"
                            ? "bg-[#a855f7]/15 text-[#a855f7]"
                            : "bg-[#f59e0b]/15 text-[#f59e0b]"
                        }`}>
                          {item.evidence_type.replace(/_/g, " ")}
                        </span>

                        <button
                          onClick={() => handleDeleteEvidence(item.id)}
                          title="Archive Evidence"
                          className="rounded p-1 text-[var(--color-text-muted)] hover:text-red-500 transition"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>

                      <div className="font-bold text-sm text-[var(--color-text)]">
                        {item.title}
                      </div>

                      <p className="text-xs text-[var(--color-text-muted)] leading-relaxed font-mono bg-[var(--color-bg-elev)] p-2.5 rounded-lg border" style={{ borderColor: "var(--color-border)" }}>
                        {item.content}
                      </p>
                    </div>

                    <div className="pt-3 mt-3 border-t flex items-center justify-between text-[11px] text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                      <span>
                        {item.author_or_expert ? `Attributed: ${item.author_or_expert}` : "Proprietary Dataset"}
                      </span>
                      {item.source_url && (
                        <a
                          href={item.source_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 text-[var(--color-accent)] hover:underline"
                        >
                          <span>Source</span>
                          <ExternalLink size={10} />
                        </a>
                      )}
                    </div>
                  </Card>
                ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 5: BRAND VOICE FROM DATA & STYLE PROFILE (Pillar A3.1) */}
      {viewTab === "voice" && (
        <div className="space-y-5">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <div className="flex items-center gap-2">
                <Target size={16} className="text-[var(--color-accent)]" />
                <h2 className="text-sm font-bold text-[var(--color-text)]">
                  Brand Voice from Data — Empirical Style Profile (Pillar A3.1)
                </h2>
                {styleProfile?.status === "approved" ? (
                  <span className="rounded-full bg-[#10b981]/15 px-2 py-0.5 text-[10px] text-[#10b981] font-semibold flex items-center gap-1">
                    <CheckCircle2 size={10} /> Approved &amp; Locked
                  </span>
                ) : (
                  <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] text-amber-500 font-semibold flex items-center gap-1">
                    <AlertTriangle size={10} /> Awaiting Human Approval
                  </span>
                )}
              </div>
              <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                Analyzed from {styleProfile?.sample_article_count || 10}+ approved articles. Calibrates sentence length, person ratio, formatting habits, and banned AI cliches. Updating requires human editorial sign-off.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={handleCalibrateVoice}
                disabled={calibratingVoice}
                icon={calibratingVoice ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              >
                {calibratingVoice ? "Analyzing Articles..." : "Re-Calibrate from 10+ Articles"}
              </Button>

              {styleProfile?.status !== "approved" && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleApproveVoice}
                  disabled={approvingVoice}
                  icon={approvingVoice ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                >
                  {approvingVoice ? "Approving..." : "Approve Style Profile (Human Gate)"}
                </Button>
              )}
            </div>
          </div>

          {/* Profile Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Card 1: Sentence Length */}
            <Card className="p-4 space-y-2">
              <div className="text-[11px] font-semibold text-[var(--color-text-muted)] uppercase tracking-wider">
                Sentence Rhythm &amp; Cadence
              </div>
              <div className="flex items-baseline gap-3">
                <div>
                  <div className="text-2xl font-bold font-mono text-[var(--color-accent)]">
                    {styleProfile?.sentence_length_avg ?? 15.2}
                  </div>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Average words/sentence</div>
                </div>
                <div className="h-8 w-px bg-[var(--color-border)]" />
                <div>
                  <div className="text-2xl font-bold font-mono text-[#38bdf8]">
                    {styleProfile?.sentence_length_median ?? 14.0}
                  </div>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Median words/sentence</div>
                </div>
              </div>
              <p className="text-[11px] text-[var(--color-text-muted)] pt-1">
                Natural variance avoids rhythmic monotony and eliminates robotic uniform clauses.
              </p>
            </Card>

            {/* Card 2: Grammatical Person Distribution */}
            <Card className="p-4 space-y-2">
              <div className="text-[11px] font-semibold text-[var(--color-text-muted)] uppercase tracking-wider">
                Grammatical Person Distribution
              </div>
              <div className="space-y-1.5 text-xs">
                <div>
                  <div className="flex justify-between text-[11px] text-[var(--color-text-muted)] mb-0.5">
                    <span>2nd Person ("you/your")</span>
                    <span className="font-mono font-bold text-[var(--color-text)]">
                      {Math.round((styleProfile?.person_distribution?.second_person ?? 0.45) * 100)}%
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[var(--color-bg-elev)] overflow-hidden">
                    <div
                      className="h-full bg-[var(--color-accent)] rounded-full"
                      style={{ width: `${Math.round((styleProfile?.person_distribution?.second_person ?? 0.45) * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-[var(--color-text-muted)] mb-0.5">
                    <span>3rd Person ("they/the system")</span>
                    <span className="font-mono font-bold text-[var(--color-text)]">
                      {Math.round((styleProfile?.person_distribution?.third_person ?? 0.40) * 100)}%
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[var(--color-bg-elev)] overflow-hidden">
                    <div
                      className="h-full bg-[#38bdf8] rounded-full"
                      style={{ width: `${Math.round((styleProfile?.person_distribution?.third_person ?? 0.40) * 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-[var(--color-text-muted)] mb-0.5">
                    <span>1st Person ("we/I")</span>
                    <span className="font-mono font-bold text-[var(--color-text)]">
                      {Math.round((styleProfile?.person_distribution?.first_person ?? 0.15) * 100)}%
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[var(--color-bg-elev)] overflow-hidden">
                    <div
                      className="h-full bg-[#a855f7] rounded-full"
                      style={{ width: `${Math.round((styleProfile?.person_distribution?.first_person ?? 0.15) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </Card>

            {/* Card 3: Formatting Habits */}
            <Card className="p-4 space-y-2">
              <div className="text-[11px] font-semibold text-[var(--color-text-muted)] uppercase tracking-wider">
                Publication Formatting Habits
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-[var(--color-bg-elev)] p-2 border" style={{ borderColor: "var(--color-border)" }}>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Comparison Tables</div>
                  <div className="font-semibold text-[#10b981] flex items-center gap-1 mt-0.5">
                    <CheckCircle2 size={12} /> Mandatory
                  </div>
                </div>
                <div className="rounded-lg bg-[var(--color-bg-elev)] p-2 border" style={{ borderColor: "var(--color-border)" }}>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Code/Config Blocks</div>
                  <div className="font-semibold text-[#10b981] flex items-center gap-1 mt-0.5">
                    <CheckCircle2 size={12} /> Production
                  </div>
                </div>
                <div className="rounded-lg bg-[var(--color-bg-elev)] p-2 border" style={{ borderColor: "var(--color-border)" }}>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Lists Frequency</div>
                  <div className="font-semibold font-mono text-[var(--color-text)] mt-0.5">
                    ~{styleProfile?.formatting_habits?.bullets_per_1k_words ?? 4.5} per 1k
                  </div>
                </div>
                <div className="rounded-lg bg-[var(--color-bg-elev)] p-2 border" style={{ borderColor: "var(--color-border)" }}>
                  <div className="text-[10px] text-[var(--color-text-muted)]">Heading Hierarchy</div>
                  <div className="font-semibold text-[var(--color-text)] mt-0.5">H2 + H3 Trees</div>
                </div>
              </div>
            </Card>
          </div>

          {/* Banned Clichés vs Preferred Terminology */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-red-500">
                <AlertTriangle size={14} />
                <span>Banned AI Clichés &amp; Fluff Words (Zero Tolerance)</span>
              </div>
              <p className="text-[11px] text-[var(--color-text-muted)]">
                The generation prompts and critic loops strictly forbid these telltale phrases:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {(styleProfile?.banned_phrases || [
                  "delve", "testament", "tapestry", "pivotal", "game-changer",
                  "revolutionize", "unleash", "in today's world", "landscape",
                  "beacon", "nestled", "stands as a testament", "crucial role",
                  "plethora", "seamlessly", "holistic", "dynamic", "synergy"
                ]).map((word) => (
                  <span
                    key={word}
                    className="rounded-md border border-red-500/20 bg-red-500/10 px-2 py-0.5 text-[11px] font-mono text-red-500 line-through"
                  >
                    {word}
                  </span>
                ))}
              </div>
            </Card>

            <Card className="p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-[#10b981]">
                <Sliders size={14} />
                <span>Preferred Domain Terminology &amp; Key N-Grams</span>
              </div>
              <p className="text-[11px] text-[var(--color-text-muted)]">
                Empirical high-frequency terms pulled from the site's top-performing articles:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {(styleProfile?.preferred_phrases && styleProfile.preferred_phrases.length > 0 ? styleProfile.preferred_phrases : [
                  "deterministic simulation", "zero-copy serialization", "sub-tick physics",
                  "ring buffer", "rollback netcode", "production workloads",
                  "memory leak", "thread safety", "compiler optimizations"
                ]).map((term) => (
                  <span
                    key={term}
                    className="rounded-md border border-[#10b981]/25 bg-[#10b981]/10 px-2 py-0.5 text-[11px] font-mono text-[#10b981] font-semibold"
                  >
                    {term}
                  </span>
                ))}
              </div>
            </Card>
          </div>

          {/* Few-Shot Exemplars */}
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-[var(--color-text)]">
                <BookOpen size={14} className="text-[var(--color-accent)]" />
                <span>Top Exemplars Retrieved by Dense Embedding Similarity</span>
              </div>
              <span className="text-[11px] text-[var(--color-text-muted)] font-mono">
                {styleProfile?.few_shot_exemplars?.length || 0} Exemplars Loaded
              </span>
            </div>

            <div className="space-y-2.5">
              {(styleProfile?.few_shot_exemplars && styleProfile.few_shot_exemplars.length > 0 ? styleProfile.few_shot_exemplars : [
                {
                  heading: "Deterministic Simulation & Sub-Tick Frames",
                  text: "Rollback netcode decouples the simulation loop from the render cycle. By persisting an immutable state buffer of input history, client prediction reconciles server discrepancies with zero perceptual latency.",
                },
                {
                  heading: "Memory Management & Cache Locality",
                  text: "Hardware memory locality dictates real-world throughput far more than micro-optimizations. Arranging entity components in contiguous arrays maximizes CPU cache line utilization.",
                },
              ]).map((ex, idx) => (
                <div key={idx} className="rounded-lg bg-[var(--color-bg-elev)] p-3 border space-y-1" style={{ borderColor: "var(--color-border)" }}>
                  <div className="text-xs font-bold text-[var(--color-accent)]">{ex.heading}</div>
                  <p className="text-[11px] text-[var(--color-text-muted)] font-mono leading-relaxed">{ex.text}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* Pillar A2: Evidence-Based Content Brief Modal */}
      {(briefLoading || activeBrief) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in">
          <div
            className="relative w-full max-w-4xl max-h-[88vh] overflow-y-auto rounded-2xl border bg-[var(--color-bg)] p-6 shadow-2xl space-y-5"
            style={{ borderColor: "var(--color-border)" }}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b pb-4" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[var(--color-accent-subtle)] text-[var(--color-accent-text)] border" style={{ borderColor: "var(--color-border)" }}>
                  <Compass size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs uppercase tracking-wider font-bold text-[var(--color-accent-text)]">Pillar A2</span>
                    <span className="text-[10px] text-[var(--color-text-muted)] font-mono">Evidence-Based Brief</span>
                  </div>
                  <h2 className="text-lg font-bold text-[var(--color-text)] flex items-center gap-2">
                    <span>{briefTargetKeyword || activeBrief?.primary_keyword}</span>
                    {activeBrief?.intent && (
                      <span className="rounded border px-2 py-0.5 text-[10px] font-medium bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                        {activeBrief.intent}
                      </span>
                    )}
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {activeBrief && (
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      const text = copyBriefToMarkdown(activeBrief);
                      navigator.clipboard.writeText(text);
                      setCopiedBrief(true);
                      setTimeout(() => setCopiedBrief(false), 2000);
                      push({ title: "Brief Copied", description: "Complete Markdown brief copied to clipboard", variant: "info" });
                    }}
                    icon={copiedBrief ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                  >
                    {copiedBrief ? "Copied" : "Copy Brief (MD)"}
                  </Button>
                )}
                <button
                  onClick={() => {
                    setActiveBrief(null);
                    setBriefLoading(false);
                  }}
                  className="rounded-lg p-1.5 text-[var(--color-text-muted)] hover:bg-[var(--color-bg-elev)] hover:text-[var(--color-text)] transition"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            {briefLoading ? (
              <div className="py-16 text-center space-y-3">
                <Loader2 size={32} className="animate-spin mx-auto text-[var(--color-accent-text)]" />
                <div className="font-semibold text-sm text-[var(--color-text)]">
                  Conducting Live SERP Analysis & Trafilatura Competitor Mining...
                </div>
                <p className="text-xs text-[var(--color-text-muted)] max-w-md mx-auto">
                  Fetching top-10 URLs, scraping article bodies with Trafilatura, computing table stakes vs. differentiators, and pulling unique angle from evidence pack (A3.2).
                </p>
              </div>
            ) : activeBrief ? (
              <div className="space-y-5 text-xs text-[var(--color-text)]">
                {/* Live SERP & Competitive Intelligence Bar */}
                <div
                  className="rounded-xl border p-3 bg-gradient-to-r from-emerald-500/10 via-sky-500/10 to-purple-500/10 flex flex-wrap items-center justify-between gap-3 text-xs"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[var(--color-bg-elev)] border text-[11px] font-medium" style={{ borderColor: "var(--color-border)" }}>
                      <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[var(--color-text-muted)]">Engine:</span>
                      <span className="font-semibold uppercase tracking-wider text-emerald-400 font-mono text-[10px]">
                        {activeBrief.serp_summary?.provider || "SERP Intelligence"}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[var(--color-bg-elev)] border text-[11px] font-medium text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                      <Layers size={12} className="text-sky-400" />
                      <span>{activeBrief.serp_summary?.competitor_count ?? 5} Page-1 Competitors Mined</span>
                    </div>

                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[var(--color-bg-elev)] border text-[11px] font-medium" style={{ borderColor: "var(--color-border)" }}>
                      <Globe size={12} className={activeBrief.serp_summary?.has_ai_overview ? "text-purple-400" : "text-[var(--color-text-muted)]"} />
                      <span className={activeBrief.serp_summary?.has_ai_overview ? "text-purple-300 font-semibold" : "text-[var(--color-text-muted)]"}>
                        {activeBrief.serp_summary?.has_ai_overview ? "Google AI Overview Active" : "Standard SERP Features"}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold text-[var(--color-text-muted)]">Information Gain:</span>
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-mono font-bold text-xs">
                      <Sparkles size={11} className="text-amber-400" />
                      <span>{activeBrief.serp_summary?.information_gain_score ? `${activeBrief.serp_summary.information_gain_score}%` : "88.5%"}</span>
                      <span className="text-[9px] uppercase font-normal text-amber-400/80">
                        ({activeBrief.serp_summary?.information_gain_tier || "Exceptional"})
                      </span>
                    </div>
                  </div>
                </div>

                {/* 1. Strategic Foundation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[var(--color-text-muted)]">Target Reader</div>
                    <div className="mt-1 font-medium">{activeBrief.target_reader}</div>
                  </div>

                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[var(--color-text-muted)] flex items-center justify-between">
                      <span>Evidence-Based Depth Range</span>
                      <span className="text-[9px] text-[#38bdf8] font-normal">A range, not a stuffing target</span>
                    </div>
                    <div className="mt-1 font-bold text-sm text-[#38bdf8]">
                      {activeBrief.word_count_range?.min} – {activeBrief.word_count_range?.max} words
                      <span className="text-[11px] font-normal text-[var(--color-text-muted)] ml-2">
                        (Median: {activeBrief.word_count_range?.target_median})
                      </span>
                    </div>
                  </div>
                </div>

                {/* 2. Unique Angle from Evidence Pack A3.2 */}
                <div className="rounded-xl border p-4 bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-transparent border-amber-500/30">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-amber-400 flex items-center gap-1.5">
                    <Zap size={12} />
                    <span>Unique Information Gain Angle (Evidence Pack A3.2)</span>
                  </div>
                  <p className="mt-1.5 font-medium text-xs leading-relaxed text-[var(--color-text)]">
                    {activeBrief.unique_angle}
                  </p>
                </div>

                {/* 3. Gap Analysis: Table Stakes vs Differentiators */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[#10b981] flex items-center gap-1">
                      <CheckCircle2 size={12} />
                      <span>Table Stakes Entities (≥50% Competitors)</span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {activeBrief.required_entities.slice(0, 8).map((ent, idx) => (
                        <span key={idx} className="rounded bg-[#10b981]/15 px-2 py-0.5 text-[10px] text-[#10b981] font-medium border border-[#10b981]/30">
                          {ent}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[#a855f7] flex items-center gap-1">
                      <Zap size={12} />
                      <span>Differentiator Entities (Only 1-2 Competitors)</span>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {activeBrief.required_entities.slice(8).length > 0 ? (
                        activeBrief.required_entities.slice(8).map((ent, idx) => (
                          <span key={idx} className="rounded bg-[#a855f7]/15 px-2 py-0.5 text-[10px] text-[#c084fc] font-medium border border-[#a855f7]/30">
                            {ent}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-[var(--color-text-muted)] italic">Extracted from proprietary technical mechanisms</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* 4. Questions in Answer-First Form (Opportunities) */}
                {activeBrief.questions_to_answer && activeBrief.questions_to_answer.length > 0 && (
                  <div className="rounded-xl border p-4 bg-[var(--color-bg-elev)] space-y-2.5" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[var(--color-accent-text)] flex items-center gap-1">
                      <HelpCircle size={12} />
                      <span>Questions to Answer (Answer-First Form for AI Overviews & Snippets)</span>
                    </div>
                    <div className="space-y-2">
                      {activeBrief.questions_to_answer.map((q, idx) => (
                        <div key={idx} className="rounded-lg border p-2.5 bg-[var(--color-bg-soft)] text-xs" style={{ borderColor: "var(--color-border)" }}>
                          <div className="font-semibold text-[var(--color-text)] flex items-center justify-between">
                            <span>Q: {cleanDisplayQuestion(q.question)}</span>
                            {q.opportunity_type && (
                              <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono">
                                {q.opportunity_type}
                              </span>
                            )}
                          </div>
                          <div className="mt-1 text-[11px] text-[var(--color-text-muted)] italic leading-relaxed">
                            {cleanDisplayAnswerGuidance(q.answer_first_form)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 5. Required Sections Blueprint */}
                <div className="space-y-2.5">
                  <div className="text-[10px] uppercase font-bold text-[var(--color-text-muted)] flex items-center gap-1">
                    <Layers size={12} />
                    <span>Structured Section Blueprint ({activeBrief.required_sections?.length || 0} Movements)</span>
                  </div>
                  <div className="space-y-2">
                    {activeBrief.required_sections?.map((sec, idx) => (
                      <div key={idx} className="rounded-xl border p-3 bg-[var(--color-bg-elev)] space-y-1.5" style={{ borderColor: "var(--color-border)" }}>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-[var(--color-text)]">
                            {sec.level === 3 ? "### " : "## "} {sec.heading}
                          </span>
                          <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                            H{sec.level}
                          </span>
                        </div>
                        <div className="text-[11px] text-[var(--color-text-muted)]">
                          <strong>Goal:</strong> {sec.intent_goal}
                        </div>
                        {sec.answer_first_guidance && (
                          <div className="text-[10px] text-amber-300/90 bg-amber-500/10 p-2 rounded border border-amber-500/20">
                            <strong>Answer-First Target:</strong> {sec.answer_first_guidance}
                          </div>
                        )}
                        {sec.required_entities && sec.required_entities.length > 0 && (
                          <div className="text-[10px] flex items-center gap-1 flex-wrap">
                            <span className="text-[var(--color-text-muted)]">Key Entities:</span>
                            {sec.required_entities.map((e, eIdx) => (
                              <span key={eIdx} className="rounded bg-[var(--color-bg-soft)] px-1.5 py-0.2 text-[9px] text-[var(--color-text)] border" style={{ borderColor: "var(--color-border)" }}>
                                {e}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* 6. Metadata Footer: Claims Needing Sources & Schema Plan */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)] space-y-1.5" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-rose-400">Claims Requiring Sources</div>
                    <ul className="list-disc pl-4 space-y-1 text-[11px] text-[var(--color-text-muted)]">
                      {activeBrief.claims_needing_sources?.slice(0, 3).map((claim, idx) => (
                        <li key={idx}>{claim}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="rounded-xl border p-3 bg-[var(--color-bg-elev)] space-y-1.5" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-[#38bdf8]">Structured Data Schema Plan</div>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {activeBrief.schema_plan?.map((sc, idx) => (
                        <span key={idx} className="rounded bg-[#38bdf8]/15 px-2 py-0.5 text-[10px] text-[#38bdf8] font-mono border border-[#38bdf8]/30">
                          {sc}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* 7. Contextual Internal Link Blueprint */}
                {activeBrief.internal_link_candidates && activeBrief.internal_link_candidates.length > 0 && (
                  <div className="rounded-xl border p-3.5 bg-[var(--color-bg-elev)] space-y-2" style={{ borderColor: "var(--color-border)" }}>
                    <div className="text-[10px] uppercase font-bold text-sky-400 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Link2 size={12} />
                        <span>Contextual Internal Link Blueprint ({activeBrief.internal_link_candidates.length} In-Cluster Authority Anchors)</span>
                      </div>
                      <span className="text-[9px] text-[var(--color-text-muted)] lowercase font-mono">Zero PageRank leakage</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {activeBrief.internal_link_candidates.map((link, lIdx) => (
                        <div key={lIdx} className="rounded-lg border p-2 bg-[var(--color-bg-soft)] text-xs space-y-1" style={{ borderColor: "var(--color-border)" }}>
                          <div className="font-semibold text-[var(--color-text)] flex items-center justify-between">
                            <span className="truncate max-w-[200px]">{link.title}</span>
                            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">
                              {link.target_url || `/posts/${link.slug}`}
                            </span>
                          </div>
                          {link.context && (
                            <div className="text-[10px] text-[var(--color-text-muted)] leading-relaxed italic">
                              {link.context}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between border-t pt-4" style={{ borderColor: "var(--color-border)" }}>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setActiveBrief(null)}
                  >
                    Close Brief
                  </Button>

                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      const item = contentPlan.find((p) => p.target_keyword.toLowerCase() === activeBrief.primary_keyword.toLowerCase());
                      setActiveBrief(null);
                      if (item) {
                        handleExecutePlanItem(item);
                      } else {
                        push({ title: "Brief Verified", description: `Brief verified for '${activeBrief.primary_keyword}'`, variant: "info" });
                      }
                    }}
                    icon={<Zap size={13} />}
                  >
                    Execute with this Brief
                  </Button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}
