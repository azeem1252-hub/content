---
name: interface-design
description: Craft-first interface design for dashboards, admin panels, SaaS apps, tools, settings pages, data interfaces, and interactive products. Use when designing, building, reviewing, auditing, or refining product UI where visual craft, layout hierarchy, tokens, states, visual direction, or design-system consistency matter. Not for marketing pages, landing pages, campaigns, or brand-only work.
---

# Interface Design

Build product interfaces with the craft of a top design team — Linear, Vercel, Stripe, Apple. The difference between those and generic output is not talent. It is that every decision was *decided*, the hierarchy is unmistakable, and a hundred small details are correct at once. This skill is how you get there.

## Scope

**Use for:** Dashboards, admin panels, SaaS apps, tools, settings pages, data interfaces.

**Not for:** Landing pages, marketing sites, campaigns, brand-only work. Use a marketing/frontend design skill for those.

This skill is self-contained: direction, visual hierarchy, design-system architecture, and the polish and motion essentials needed to ship production-grade UI all live here.

---

# The Problem

You will generate generic output. Your training has seen thousands of dashboards, and the patterns are strong. You can follow this entire process — explore the domain, name a signature, state your intent — and still produce a template: warm colors on cold structures, friendly fonts on generic layouts.

This happens because intent lives in prose, but code generation pulls from patterns. The gap between them is where defaults win. Process helps, but it doesn't guarantee craft. You have to catch yourself, and you have to know the concrete moves that defaults don't.

**The bar:** If another AI, given a similar prompt, would produce substantially the same output, you have failed. Not different for its own sake — different because the interface emerged from *this* user, *this* task, *this* world. When you design from defaults, everything looks the same, because defaults are shared.

---

# Where Defaults Hide

Defaults disguise themselves as infrastructure — the parts that feel like they just need to work, not be designed.

- **Typography feels like a container.** But type isn't holding your design, it *is* your design. The weight of a headline, the personality of a label, the texture of a paragraph shape how the product feels before anyone reads a word. Reaching for your usual font means you're not designing.
- **Navigation feels like scaffolding.** But navigation *is* the product — where you are, where you can go, what matters. A page floating in space is a component demo, not software.
- **Data feels like presentation.** But a number on screen is not design. What does it *mean* to the person looking? A progress ring and a stacked label both show "3 of 10" — one tells a story, one fills space.
- **Token names feel like implementation detail.** But `--ink` and `--parchment` evoke a world; `--gray-700` and `--surface-2` evoke a template. Someone reading only your tokens should guess what product this is.

There are no structural decisions. Everything is design. The moment you stop asking "why this?" is the moment defaults take over.

---

# Intent First

Before touching code, answer these. Keep it a compact working brief unless the direction needs user confirmation.

- **Who is this human?** The actual person. Where are they when they open this? What did they do 5 minutes ago, what will they do 5 minutes after?
- **What must they accomplish?** The verb. Connect websites, inspect dispatches, review articles, approve/publish.
- **What should this feel like?** Precision engineering, Linear/Vercel level of polish, high contrast, clean typography.

**Intent must be systemic.** Check every token against the stated intent. For every choice — layout, color temperature, typeface, spacing scale, hierarchy — you must be able to say *why*.

---

# Visual Hierarchy & Composition

## One focal point per view
Every screen has one thing the user came to do. That thing dominates — through size, contrast, position, or the space around it.

## Type scale is a ratio, and weight beats size
Ratio: ~1.25. Body: 14px base (`caption 11 · body 14 · h4 16 · h3 18 · h2 22 · h1 28 · display 44+`).
Weight and opacity do more work than raw size:
- `value: 600-700 / primary`
- `label: 500-600 / secondary`
- `meta: 400 / muted`

## Density is a decision, expressed in px
Tight, workbench feel for technical tooling, generous whitespace between semantic clusters.

## Distribution and restraint (the "expensive" look)
- **~60/30/10**: dominant neutral surface, secondary tone, ~10% communicative accent.
- **One accent, used with intention** (e.g. electric indigo/blue `--primary`).
- **Hierarchy through space and subtle tonal shifts**, not thick dark borders.
- **Optical sizing**: tighten letter-spacing on headings (`-0.02em`); loose line-height on body (`1.5-1.6`).

---

# Craft Foundations

## Subtle Layering
- **Surface elevation:**
  - Canvas: Base background
  - Surface: Cards, panels, toolbars
  - Elevated: Modals, popovers, dropdowns, floating menus
- **Borders:**
  - Dark mode: `rgba(255, 255, 255, 0.08 - 0.14)`
  - Light mode: `#e2e8f0` (subtle) / `#cbd5e1` (medium) / `#94a3b8` (hover)
- **Inputs:**
  - Inset, clean border, subtle background shift (`#ffffff` with `#e2e8f0` border in light mode, `#0a0d14` in dark mode)
- **Tabular numbers:**
  - `font-variant-numeric: tabular-nums` on all counters, metrics, IDs, timestamps.
- **Concentric radius:**
  - Outer radius = inner radius + padding.
- **Hit areas:**
  - Minimum 40px - 44px for primary controls.
- **Motion:**
  - 100-180ms ease-out transitions (`cubic-bezier(0.16, 1, 0.3, 1)`).
  - Tactile press feedback (`transform: scale(0.98)`).
