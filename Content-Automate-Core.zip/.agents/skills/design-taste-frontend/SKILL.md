---
name: design-taste-frontend
description: Anti-slop frontend taste skill for websites, dashboards, and redesigns. Enforces deliberate aesthetic direction, typography, high-contrast layouts, tactile feedback, and eliminates generic AI slop.
---

# tasteskill: Anti-Slop Frontend Skill

> Every rule below is **contextual**. First read the brief, then pull only what fits.

---

## 0. BRIEF INFERENCE (Read the Room Before Anything Else)

Before touching code or tweaking dials, **infer what the user actually wants**. Most LLM design output is bad because the model jumps to a default aesthetic instead of reading the room.

### 0.A Read these signals first
1. **Page kind** - SaaS operations dashboard / mission control, developer tool, Next.js automation platform.
2. **Vibe words** - "Linear-style", "Raycast-clean", "Vercel-sleek", "Supabase dark-mode", "command-center", "pilot cockpit", "ultra-crisp".
3. **Audience** - Senior engineers, content leads, technical operators who appreciate speed, clarity, high density, and tactile response.
4. **Anti-Default Discipline:**
   - Do not default to: AI-purple gradients, centered hero over dark mesh, three equal feature cards, generic glassmorphism on everything, infinite-loop micro-animations everywhere, Inter + slate-900.
   - Use: Obsidian dark mode, 1px precision borders, tactile button feedback (`:active scale(0.98)`), JetBrains Mono for telemetry/slugs, clean typography, purposeful status lights, and responsive split views.

---

## 1. THE THREE DIALS (Core Configuration)

* **`DESIGN_VARIANCE: 6`** - High intentionality, structured asymmetry, clean information architecture.
* **`MOTION_INTENSITY: 5`** - Snappy micro-interactions (120-180ms ease-out), smooth tab switches, no floaty distractors.
* **`VISUAL_DENSITY: 8`** - Command center / pilot cockpit, high telemetry data density, zero wasted whitespace.

---

## 2. DESIGN ENGINEERING DIRECTIVES

### 2.1 Typography
* Sans display: `Plus Jakarta Sans`, `Geist`, or `Inter Tight` for high legibility at all scales.
* Monospace: `JetBrains Mono` or `Geist Mono` for endpoints, secrets, thread IDs, slugs, and timestamps.
* Line length capped at 65-75ch for editorial review previews.
* Zero all-caps shouting everywhere; use subtle tracking `0.04em` on compact uppercase badges only.

### 2.2 Palette & Contrast (WCAG AA Strict)
* **Canvas Dark (Deep Obsidian):** `#090d16`
* **Surface Panels:** `#0f1422`, `#141b2d`
* **Card Tops / Hover:** `#192237`, `#1e293b`
* **Borders (1px Precision):** `rgba(255, 255, 255, 0.08)` to `rgba(255, 255, 255, 0.14)`
* **Primary Luminous Accent (Electric Indigo/Cyan):** `#3b82f6` / `#06b6d4`
* **Success / Live (Emerald):** `#10b981` (active schedules, live connections, published posts)
* **Review Alert (Amber Glow):** `#f59e0b` (pending editorial sign-off)
* **Danger (Crimson):** `#ef4444` (rejections, deletions)

### 2.3 Layout & Density (The Pilot Cockpit Rule)
* Navigation bar: Sleek 56-64px left sidebar with collapsible mode, icons + labels + count pills.
* Status bar: Global persistent telemetry ribbon (Engine status, Next.js targets count, active scheduler loop indicator).
* Studio Deck: 2-column or split asymmetric layout. Left: Config & prompt trigger; Right: live SSE execution logs + state progression.
* Review Station: Split editorial pane with rich Markdown render, SEO score gauge, target destination pill, and immediate Action Bar.

### 2.4 Tactile States
* Hover: Subtle border illumination (`border-color: rgba(255,255,255,0.2)`) and background tint.
* Active/Press: `transform: scale(0.985); transition: 75ms ease;`
* Toast notifications: Bottom-right, stacked, with dismiss on click and progress indicators.
