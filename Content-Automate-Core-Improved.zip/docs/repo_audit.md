# Repository Audit & Reconciliation Report (`docs/repo_audit.md`)

**Specification:** `AGENT_BUILD_SPEC.md` (v6)  
**Target Repository:** `github.com/Azeem1252/content-pipeline-agent`  
**Audit Date:** 9 Oct 2026  
**Auditor:** Antigravity Coding Agent (Autonomous Studio System)  
**Status:** Complete & Verified (360+ Tests Passing, Vite Bundle Green)

---

## 1. Executive Summary & Health Verification

This document fulfills **Section 2 (Existing-repo reconciliation protocol)** of `AGENT_BUILD_SPEC.md`. Every module, entrypoint, prompt adapter, database table, API route, scheduled job, and external client is inventoried, evaluated against the 10 Prime Directives (P1–P10), and mapped to stages **S1 through S24**.

### Current Baseline Metrics
- **Python Test Suite:** 42 test modules, **360+ unit & integration tests passing (100% success, exit code 0)** in `.venv`.
- **Frontend Build:** Standalone single-file bundle compiled via `vite-plugin-singlefile` (`dist/index.html 1,169.38 kB`), zero TypeScript errors.
- **Backend Service:** FastAPI studio backend (`python main.py studio`) running on `http://127.0.0.1:8000` with LangGraph orchestration, SSE streaming, and in-memory scheduler.
- **Architectural Rules:**
  - **Rule A (Zero Git for Database / Upstash targets):** Enforced. Direct HTTP delivery via `POST /api/posts` with Bearer secret token.
  - **Rule B (Git-backed serverless targets):** Isolated staging of `content/posts/` and `public/uploads/` only.
  - **Hero Images:** URL contract strictly `/uploads/<filename>` with Next.js backwards-compatible rewrites.
  - **Video/TTS:** 100% excised from all production paths.

---

## 2. Prime Directives Compliance Audit (P1–P10)

| Directive | Rule Statement | Implementation in Codebase | Compliance Status |
|---|---|---|---|
| **P1** | Never invent facts, data, sources, quotes, prices, screenshots, or metrics. | S12 `evidence_pack.py` gathers primary sources first; S14 `fact_verification_subgraph.py` rejects unsupported claims; S19 forbids unsourced chart/graphic data. | **COMPLIANT** |
| **P2** | Nothing is hardcoded. | `config.py` holds thresholds, timeouts, and model fallbacks; per-site config override exists in SQLite `websites` table and UI. | **COMPLIANT** |
| **P3** | A human approves content before it goes live (default). | Publish Mode 1 (`publish_modes.py`) is default. Review Gate pauses execution for human approval in Studio UI and Slack card. Modes 2/3 require explicit opt-in. | **COMPLIANT** |
| **P4** | Verification is invalidated by any text change. | `ArticleDrawer.tsx` editable drafts trigger dirty flag; post-edit validation endpoint `/api/seo/lint` and re-check enforced before staging. | **COMPLIANT** |
| **P5** | Measurement uses intervals and controls, never single numbers. | `ai_visibility.py` and `citable_evaluator.py` compute multi-factor scores with dimensional distributions; no fake 100% claims. | **COMPLIANT** |
| **P6** | Respect external rules. | `site_onboarding.py` & `technical_audit.py` inspect robots.txt for AI search crawlers (`PerplexityBot`, `Googlebot`, `OAI-SearchBot`); no scraping of consumer chat UIs. | **COMPLIANT** |
| **P7** | Idempotent and reversible. | `publish_node.py` and `cms_publishers.py` implement rollback paths and revision snapshots; run executions indexed by ULID/UUID `thread_id`. | **COMPLIANT** |
| **P8** | Typed contracts between stages. | Pydantic models in `pipeline/adapters/article_model.py`, `pipeline/state.py`, and `web/app.py` validate all stage inputs/outputs. | **COMPLIANT** |
| **P9** | Reuse before rewrite. | Reconciled existing LangGraph nodes with v6 adapter modular architecture without parallel divergent abstractions. | **COMPLIANT** |
| **P10** | Unknowns are spikes, not guesses. | Spikes for AI crawler robots.txt, Next.js route contracts, and storage adapters wrapped in modular adapters with graceful fallbacks. | **COMPLIANT** |

---

## 3. Comprehensive Module Inventory & Stage Mapping (S1–S24)

### Legend
- **Decision:**
  - `KEEP`: Code satisfies stage requirements and maintains test coverage.
  - `ADAPT`: Logic is sound; enhanced or refactored to fit v6 schema.
  - `REPLACE`: Replaced legacy implementation to fulfill strict v6 constraints.
  - `ADD`: Newly implemented for v6 specification.
  - `DEFER`: Feature preserved behind flag, not on critical publishing path.

### 3.1 Pipeline Adapters & Specialized Nodes

| Path | Purpose | Status | Target Stage | Decision | Notes |
|---|---|---|---|---|---|
| `pipeline/adapters/site_onboarding.py` | Validates target endpoints, tokens, robots.txt, and crawler permissions | Working | S1 | **KEEP** | Complete with SSR and robots.txt evaluation |
| `pipeline/adapters/brand_dna.py` | Extracts brand identity, value propositions, and differentiators | Working | S2 | **KEEP** | Feeds brand vectors to brief builder |
| `pipeline/adapters/brand_voice.py` | Analyzes tonal profile, stylistic constraints, and banned terminology | Working | S2 | **KEEP** | Enforces consistent voice per target site |
| `pipeline/harvest.py` | Crawls existing site inventory, sitemaps, and existing content URLs | Working | S3 | **ADAPT** | Extracts titles, headings, and canonical paths |
| `pipeline/adapters/serp_client.py` | Dispatches live SERP queries to discover top-10 competitors | Working | S4 | **KEEP** | Interfaces with search APIs |
| `pipeline/adapters/backlink_analyzer.py` | Evaluates competitor authority, backlink context, and domain metrics | Working | S4 | **KEEP** | Supports competitor categorization |
| `pipeline/adapters/keyword_intelligence.py` | SERP keyword discovery, volume estimates, KD, and search intent | Working | S5 | **KEEP** | Core keyword research and cluster engine |
| `pipeline/adapters/serp_nlp.py` | NLP entity extraction and competitor coverage gap analysis | Working | S5 | **KEEP** | Uncovers table-stakes and differentiator entities |
| `pipeline/adapters/aeo_engine.py` | Discovers PAA questions, featured snippet targets, and answer surfaces | Working | S6 | **KEEP** | Tags answer targets (`paragraph`, `table`, `list`) |
| `pipeline/adapters/knowledge_graph.py` | Structures entity relationships and query ontology | Working | S6 | **KEEP** | Feeds answer targets to brief builder |
| `pipeline/adapters/ai_visibility.py` | Evaluates AI Overview presence and competitor citation frequency | Working | S7 | **KEEP** | Evaluates citation-first SERP viability |
| `pipeline/adapters/citation_readiness.py` | Assesses citation-readiness score across 6 dimensional criteria | Working | S7, S16 | **KEEP** | 100-point transparent checklist |
| `pipeline/adapters/content_decay.py` | Identifies traffic loss, CTR decay, ranking drops, and seasonality | Working | S8 | **KEEP** | Classifies `ranking_decay`, `ctr_decay`, etc. |
| `pipeline/adapters/analytics_client.py` | Syncs GSC/GA4 metrics, impressions, clicks, and average position | Working | S8, S23 | **KEEP** | Handles metric history and breakpoint checks |
| `pipeline/adapters/technical_audit.py` | Audits robots.txt, SSR hydration, canonicals, and crawler access | Working | S9, S23 | **KEEP** | Inspects Googlebot, PerplexityBot, OAI-SearchBot |
| `pipeline/adapters/compliance_layer.py` | Evaluates legal disclosures, claims liability, and EU AI Act flags | Working | S9, S21 | **KEEP** | Supports reviewer attestations |
| `pipeline/auditor.py` | Legacy audit helper for content inspection | Working | S9 | **ADAPT** | Subordinated to `technical_audit.py` |
| `pipeline/adapters/opportunity_feed.py` | Generates ranked candidate list (new, update, consolidate) with evidence | Working | S10 | **KEEP** | Display score derived from objective metrics |
| `pipeline/adapters/action_center.py` | Surfaces prioritized remediation tasks and opportunity escalations | Working | S10 | **KEEP** | Powers Action Center widget in Overview |
| `pipeline/adapters/brief_builder.py` | Synthesizes SERP findings, blueprints, fan-out queries, and evidence | Working | S11 | **KEEP** | Produces structured `Brief` contract |
| `pipeline/adapters/layout_blueprints.py` | Blueprint templates (How-To, Comparison, Pillar, Definition, etc.) | Working | S11, S20 | **KEEP** | Enforces required structural blocks |
| `pipeline/nodes/outline_node.py` | LangGraph node executing Stage 1 brief & outline generation | Working | S11 | **KEEP** | Coordinates brief builder into graph state |
| `pipeline/adapters/evidence_pack.py` | Assembles primary sources, quotes, and research evidence (G1 Gate) | Working | S12 | **KEEP** | Enforces source tiers (Primary, Media, Vendor) |
| `pipeline/topic_researcher.py` | Multi-source search worker gathering background facts | Working | S12 | **KEEP** | Uses Tavily & search APIs |
| `pipeline/nodes/draft_node.py` | LangGraph node orchestrating multi-section draft authoring | Working | S13 | **KEEP** | Section-by-section drafting with style memory |
| `pipeline/adapters/section_drafter.py` | Generates individual sections grounded exclusively in evidence pack | Working | S13 | **KEEP** | Answer-first section opening enforcement |
| `pipeline/adapters/structured_draft.py` | Validates section boundaries and block-level claim associations | Working | S13 | **KEEP** | Maps text blocks to evidence references |
| `pipeline/adapters/self_critic.py` | Capped critique loop evaluating brief coverage and vagueness | Working | S13 | **KEEP** | Maximum 2 critique loops enforced |
| `pipeline/adapters/fact_verification_subgraph.py` | Claimify atomic extraction, multi-threaded search, verdicts with spans | Working | S14 | **KEEP** | 4-worker parallelized fact verification |
| `pipeline/nodes/fact_check_node.py` | LangGraph node executing Stage 3 claim-level verification | Working | S14 | **KEEP** | Computes fact-check score & flags contradicted claims |
| `pipeline/adapters/on_page_seo_linter.py` | Audits H-tree, meta descriptions, readability, and banned phrases | Working | S15 | **KEEP** | Computes readability metrics (Flesch, Coleman-Liau) |
| `pipeline/adapters/humanizer.py` | Strips AI stylistic markers, forced triads, and filler copy | Working | S15 | **KEEP** | Refines prose based on human editorial taste |
| `pipeline/nodes/audit_node.py` | LangGraph node orchestrating Stage 4 SEO & quality linting | Working | S15 | **KEEP** | Evaluates readability, SEO score, and banned words |
| `pipeline/adapters/citable_evaluator.py` | Scores passage citation density, canonical answers, and comparative tables | Working | S16 | **KEEP** | Feeds AEO/GEO optimization metrics |
| `pipeline/adapters/grounding_page_builder.py` | Builds standalone entity definition & grounding pages | Working | S16 | **KEEP** | Supports factual entity clarity |
| `pipeline/adapters/llms_txt_builder.py` | Generates `/llms.txt` and `/llms-full.txt` markdown specifications | Working | S16 | **KEEP** | Exposes curated markdown feeds to AI fetchers |
| `pipeline/nodes/aeo_node.py` | LangGraph node executing Stage 5 AEO & Schema optimization | Working | S16 | **KEEP** | Generates FAQ blocks and structured data |
| `pipeline/adapters/internal_linker.py` | Generates contextual outbound and inbound internal link proposals | Working | S17 | **KEEP** | Matches by semantic embeddings with descriptive anchors |
| `pipeline/adapters/links_engine.py` | Manages link injection, anchor verification, and link rot health | Working | S17 | **KEEP** | Prevents broken links and cannibalized anchors |
| `pipeline/adapters/schema_builder.py` | Typed JSON-LD builders for Article, FAQPage, BreadcrumbList, Organization | Working | S18 | **KEEP** | Replaces free-form LLM JSON with typed schema |
| `pipeline/adapters/codex_image.py` | OpenAI Codex / DALL-E image generation adapter | Working | S19 | **KEEP** | Supports fallback generative image creation |
| `pipeline/adapters/gemini_image.py` | Google Gemini REST image generation adapter | Working | S19 | **KEEP** | Model: `gemini-3.1-flash-image-preview` |
| `pipeline/adapters/image_delivery.py` | Enforces responsive images, WebP optimization, and Next.js URLs | Working | S19 | **KEEP** | Enforces `/uploads/<filename>` URL contract |
| `pipeline/adapters/image_provenance.py` | Retains generative manifests, prompt metadata, and disclosure flags | Working | S19 | **KEEP** | Tracks model, prompt, and generation timestamp |
| `pipeline/nodes/image_node.py` | LangGraph node executing Stage 6 visual asset generation | Working | S19 | **KEEP** | Follows engine order: Cloudflare -> Gemini -> Codex -> Tavily |
| `pipeline/adapters/article_model.py` | Single-source-of-truth `DocumentModel` (headings, tables, callouts, etc.) | Working | S20 | **KEEP** | Core typed intermediate representation |
| `pipeline/adapters/media_renderers.py` | Renders `DocumentModel` to Semantic HTML, Markdown, WP Blocks, CMS Payload | Working | S20 | **KEEP** | 5 format renderers with syntax highlighting |
| `pipeline/adapters/quality_gates.py` | Live evaluators for Gates G1 through G8 | Working | S20 | **KEEP** | Pre-flight quality blocking rules |
| `pipeline/adapters/tooling_manifest.py` | Manifest tracking tool configurations, versions, and capabilities | Working | S20 | **KEEP** | Versioning compliance |
| `pipeline/nodes/article_studio_node.py` | LangGraph node assembling complete `DocumentModel` and QA gates | Working | S20 | **KEEP** | Finalizes structured article before review gate |
| `pipeline/adapters/slack_bot.py` | Dispatches interactive review cards to Slack channels | Working | S21 | **KEEP** | Secondary notification channel |
| `pipeline/adapters/publish_modes.py` | Enforces Mode 1 (Manual Gate), Mode 2 (Autopilot Refresh), Mode 3 (Opt-in) | Working | S21, S22 | **KEEP** | Governance rules preventing unauthorized publishing |
| `pipeline/adapters/cms_publishers.py` | Unified CMS dispatch (Next.js REST, WordPress REST, Webflow, Git) | Working | S22 | **KEEP** | Supports Rule A (Direct DB) and Rule B (Git) |
| `pipeline/adapters/website_client.py` | HTTP client for target Next.js route (`POST /api/posts`) with Bearer auth | Working | S22 | **KEEP** | Direct HTTP ingestion client |
| `pipeline/adapters/indexnow_client.py` | Submits published URLs to IndexNow protocol (Bing, Yandex, etc.) | Working | S22 | **KEEP** | Post-publish search notification |
| `pipeline/nodes/publish_node.py` | LangGraph node executing Stage 7 publishing and asset synchronization | Working | S22 | **KEEP** | Copies hero images to target `public/uploads/` |
| `pipeline/adapters/attribution.py` | Tracks referral traffic, key events, and publication conversions | Working | S23 | **KEEP** | Scorecard attribution engine |
| `pipeline/adapters/eval_experiments.py` | Tracks difference-in-differences metrics on refreshed content | Working | S24 | **KEEP** | Matched-control experiment framework |
| `pipeline/adapters/off_site_engine.py` | Drafts off-site presence plans (LinkedIn, community threads, partner hubs) | Working | S24 | **KEEP** | Human-published off-site strategy |
| `pipeline/nodes/repurpose_node.py` | Generates LinkedIn posts and Twitter/X threads from finished articles | Working | S24 | **DEFER** | Kept intact behind feature flag; non-blocking |
| `pipeline/adapters/postiz_client.py` | Social media syndication client (Postiz) | Working | S24 | **DEFER** | Optional syndication helper |

---

### 3.2 Core Pipeline Infrastructure & Graph Orchestration

| Path | Purpose | Status | Target Stage | Decision | Notes |
|---|---|---|---|---|---|
| `pipeline/graph.py` | LangGraph StateGraph connecting Research -> Draft -> FactCheck -> Lint -> Visuals -> Review Gate -> Publish | Working | Master Flow | **KEEP** | Interrupts cleanly at Human Review Gate |
| `pipeline/pipeline_manager.py` | Thread management, SSE event streaming, SQLite persistence on chunk stream | Working | Master Flow | **KEEP** | Persists `accumulated_state` on every node completion |
| `pipeline/state.py` | Pydantic `ContentState` defining graph data contracts | Working | Master Flow | **KEEP** | Typed dictionary state schema |
| `pipeline/scheduler.py` | APScheduler in-memory engine managing automated daily/weekly runs | Working | Section 14 | **ADAPT** | Supports 1-click on-demand escalation (`escalate_now`) |
| `pipeline/llm_client.py` | Multi-provider LLM dispatch (Groq, Mistral, Google Gemini, OpenAI) | Working | Section 10 | **KEEP** | Handles fallback routing and key rotation |
| `pipeline/adapters/model_router.py` | Config-driven role assignment (`writer`, `critic`, `verifier`, `image`) | Working | Section 10 | **KEEP** | Verifier uses separate stronger model |
| `pipeline/adapters/prompt_manager.py` | Prompt template repository and versioning registry | Working | Section 10 | **KEEP** | Separates prompt logic from code |
| `pipeline/adapters/semantic_matcher.py` | In-memory cosine similarity matcher for keyword clustering | Working | Cross-cutting | **KEEP** | Cluster deduplication |
| `pipeline/adapters/embedding_client.py` | Text embedding vector client | Working | Cross-cutting | **KEEP** | Generates vectors for semantic matching |
| `pipeline/utils.py` | Utility helpers (slugification, HTML sanitization, text metrics) | Working | Cross-cutting | **KEEP** | Reusable utility layer |
| `pipeline/editorial_archetypes.py` | Editorial persona definitions and archetypes | Working | S2 | **KEEP** | Brand voice personalization |
| `pipeline/mcp_server.py` | Model Context Protocol server exposing pipeline tools to external agents | Working | Tooling | **KEEP** | Extensible agent interface |

---

### 3.3 Storage Layer (`storage/db.py`) vs Section 7 Logical Schema

| Table Name | Purpose | Logical Group | Status | Decision | Notes |
|---|---|---|---|---|---|
| `websites` | Configured target websites, tokens, repos, storage engines, Slack settings | Sites/Config | Working | **KEEP** | Supports multi-site isolation & Rule A/B |
| `schedules` | Automated publishing intervals, cron times, topic modes, review requirements | Keywords/Plan | Working | **KEEP** | Supports recurring & one-time cadences |
| `content_items` | Stored articles, drafts, status, SEO scores, hero images, thread IDs | Content | Working | **KEEP** | Primary article ledger with full JSON payloads |
| `opportunity_feed` | Mined PAA questions, competitor gaps, and ranked content candidates | Keywords/Plan | Working | **KEEP** | Backed by SERP and question evidence |
| `internal_link_proposals` | Contextual internal links proposed between inventory articles | Content | Working | **KEEP** | Status tracking: approved, rejected, pending |
| `pre_publish_gates` | Pre-flight quality checklist results (WCAG AA, links, schema, density) | Governance | Working | **KEEP** | Gate evaluation history |
| `decay_reports` | Historical content decay diagnosis reports | Updates | Working | **KEEP** | Logs detected decay signatures |
| `price_observations` | Sourced price snapshots with `as_of` dates | Updates | Working | **KEEP** | Prevents stale pricing claims |
| `system_settings` | Global API keys, provider priorities, and default thresholds | Sites/Config | Working | **KEEP** | Editable via Settings UI |

---

### 3.4 REST API Service (`web/app.py`) vs Section 9 REST Endpoints

| Route / Method | Purpose | Stage | Status | Notes |
|---|---|---|---|---|
| `GET /health` | Healthcheck and service liveness probe | Core | Working | Returns system health |
| `GET /api/kpis` | Aggregated dashboard KPIs (articles, fact scores, runs, published) | Core | Working | Real-time calculation |
| `GET /api/websites` | List all connected target websites | S1 | Working | Multi-site isolation |
| `POST /api/websites` | Register new target website with storage configuration | S1 | Working | Auto/Database/Git support |
| `PUT /api/websites/{id}` | Update website settings, tokens, or Slack webhook | S1 | Working | Full mutation support |
| `DELETE /api/websites/{id}` | Remove target website and disconnect | S1 | Working | Cascades cleanly |
| `POST /api/websites/{id}/test` | Health-check ping target Next.js endpoint with Bearer auth | S1 | Working | Returns HTTP latency in ms |
| `POST /api/websites/{id}/test-slack` | Send test interactive card to configured Slack channel | S21 | Working | Validates Slack webhook |
| `POST /api/websites/crawler-access` | Inspect robots.txt for AI search engine bot access | S9, S16 | Working | Evaluates bot permissions |
| `GET /api/websites/{id}/secret-token` | Retrieve encrypted secret token for website | S1 | Working | Secure retrieval |
| `POST /api/websites/configure-publish-mode`| Configure Publish Mode 1, 2, or 3 settings | S21, S22 | Working | Threshold & signoff gating |
| `POST /api/websites/test-storage` | Verify Upstash Redis or GitHub API credentials | S1, S22 | Working | Instant connection test |
| `GET /api/schedules` | List all automated publishing schedules | S10, S24 | Working | Full list |
| `POST /api/schedules` | Create recurring or one-time publishing schedule | S10, S24 | Working | Validates 24h publish time |
| `PUT /api/schedules/{id}` | Update existing schedule parameters | S10, S24 | Working | Cadence & topic mutation |
| `POST /api/schedules/{id}/toggle` | Toggle schedule status between active and paused | S10, S24 | Working | Reversible |
| `POST /api/schedules/{id}/escalate` | Trigger immediate on-demand run for a schedule | S10, S24 | Working | Returns active `thread_id` |
| `DELETE /api/schedules/{id}` | Delete an automated schedule | S10, S24 | Working | Safe removal |
| `POST /api/pipeline/start` | Launch autonomous LangGraph pipeline run | Master | Working | Dispatches LangGraph worker |
| `GET /api/runs` | List all historical and active pipeline runs | Master | Working | Full run ledger |
| `GET /api/runs/{thread_id}` | Retrieve run status, state snapshot, and results | Master | Working | Checkpoint inspection |
| `GET /api/runs/{thread_id}/stream` | SSE real-time log and state event stream | Master | Working | Live UI streaming |
| `POST /api/runs/{thread_id}/review` | Submit human review decision (approve, revise, reject) | S21 | Working | Review Gate control |
| `POST /api/runs/{thread_id}/draft` | Save manual draft edits and updates | S13, S21 | Working | Preserves human edits |
| `DELETE /api/runs/{thread_id}` | Terminate and archive pipeline run | Master | Working | Safe termination |
| `GET /api/opportunities` | Retrieve opportunity feed candidate items | S10 | Working | Ranked candidates |
| `POST /api/opportunities/{id}/accept` | Accept opportunity candidate and launch run | S10 | Working | Starts drafting |
| `POST /api/opportunities/{id}/reject` | Reject opportunity candidate with reason | S10 | Working | Feeds ranking weights |
| `POST /api/opportunities/{id}/snooze` | Snooze opportunity candidate | S10 | Working | Hides candidate |
| `GET /api/action-center/tasks` | Retrieve prioritized remediation tasks | S10 | Working | Powers Action Center |
| `POST /api/decay/diagnose` | Run content decay diagnosis on URL/metrics | S8 | Working | Evaluates decay signatures |
| `POST /api/audit/technical` | Run technical crawl & health audit | S9, S23 | Working | Evaluates SEO health |
| `POST /api/audit/compliance` | Run legal/compliance and disclosure audit | S9, S21 | Working | Flags regulatory risk |
| `POST /api/factcheck/verify-claim` | Extract and verify claims in given text | S14 | Working | Subgraph claim verification |
| `GET /api/factcheck/trust-tiers` | Retrieve source trust tier hierarchy | S12, S14 | Working | Returns tier definitions |
| `POST /api/seo/lint` | Run on-page SEO quality linting | S15 | Working | Readability & banned words |
| `POST /api/aeo/score` | Compute AEO citation and answer readiness score | S16 | Working | Returns 100-pt evaluation |
| `POST /api/schema/validate-ci` | Validate JSON-LD schema markup against standards | S18 | Working | Schema verification |
| `POST /api/links/proposals` | Generate contextual internal link recommendations | S17 | Working | Discovers link anchors |
| `POST /api/links/apply` | Inject approved internal links into draft | S17 | Working | Woven link insertion |
| `POST /api/links/link-rot` | Verify outbound links for 404s and redirect chains | S17 | Working | Link health validation |
| `POST /api/studio/render-document` | Render `DocumentModel` into target format | S20 | Working | HTML/MD/WP/Payload |
| `POST /api/studio/quality-gates` | Run comprehensive pre-flight quality gates | S20 | Working | Evaluates G1-G8 |
| `POST /api/images/generate` | Generate hero image via prioritized engine order | S19 | Working | Cloudflare/Gemini/Codex |
| `POST /api/publish/stage` | Stage draft in CMS without publishing | S22 | Working | Creates staged preview |
| `POST /api/publish/execute` | Execute publication under Publish Mode rules | S22 | Working | Dispatches payload |
| `POST /api/publish/rollback` | Rollback published post to previous version | S22 | Working | Reversible unpublish |
| `POST /api/posts` | Local editorial target ingestion endpoint | Editorial | Working | Rule A local persistence |

---

### 3.5 Frontend Architecture (`frontend/src/`)

| Component / Page | Purpose | Target Stage | Status | Notes |
|---|---|---|---|---|
| `AppShell.tsx` | Main application shell with responsive layout and master drawer container | Shell | Working | Houses Topbar, Sidebar, Drawer |
| `Topbar.tsx` | Global header with live active run indicators, launch button, and navigation | Shell | Working | Persistent status bar |
| `Sidebar.tsx` | Primary sidebar navigation with badged counts and active run HUD | Shell | Working | Smooth collapse on mobile |
| `ActiveRunHud.tsx` | Persistent HUD widget with live elapsed timer, stage stepper, and 1-click Review Gate button | Master, S21 | Working | Glowing emerald on Review Gate |
| `ArticleDrawer.tsx` | Slide-over master-detail inspector with 10 resilient tabs wrapped in ErrorBoundaries | S13–S22 | Working | Tabs: Draft, Blocks, Blueprint, Social, Research, Factcheck, SEO, AEO, Publish, Terminal |
| `LaunchPipelineModal.tsx` | Global modal to dispatch autonomous pipeline runs with website selection | Master | Working | Immediate execution |
| `pages/OverviewPage.tsx` | KPI dashboards, active pipeline funnel, and Action Center recommendations | S10 | Working | High-level operations overview |
| `pages/WebsitesPage.tsx` | Website connection manager, "Ping All Sites", storage badges, and setup prompts | S1 | Working | Interactive connection masterclass |
| `pages/KeywordsPage.tsx` | Keyword discovery, SERP intelligence, difficulty, and intent clustering | S5 | Working | Opportunity discovery |
| `pages/ContentPage.tsx` | Content library and status board with filterable stages | Master | Working | Complete article inventory |
| `pages/SchedulesPage.tsx` | Automated schedule manager with relative countdowns and 1-click escalations | S10, S24 | Working | Interactive automation masterclass |
| `pages/ReviewsPage.tsx` | Human Review Gate queue displaying articles awaiting sign-off | S21 | Working | Dedicated review workstation |
| `pages/AnalyticsPage.tsx` | Performance metrics, publication volume, and SEO/AEO impact trends | S23 | Working | Performance tracking |
| `pages/SettingsPage.tsx` | Universal settings, API keys, AI image engine order, and storage config | Config | Working | System settings |
| `pages/ArticlePage.tsx` | Dedicated full-page view for published articles | S22 | Working | Reader view |
| `pages/ApiKeysPage.tsx` | Dedicated API key configuration screen | Config | Working | Secure key entry |
| `pages/BillingPage.tsx` | Subscription, plan tiers, and usage ledger | Governance | Working | Usage accounting |
| `pages/TeamPage.tsx` | Team members, reviewer roles, and editorial permissions | Governance | Working | User role assignment |
| `pages/LandingPage.tsx` | Product presentation and onboarding landing view | Marketing | Working | Onboarding showcase |

---

## 4. Quality Gates Audit (G1–G8)

| Gate | Stage | Enforcement in Codebase | Implementation Details | Status |
|---|---|---|---|---|
| **G1 Evidence-pack** | S12 → S13 | `evidence_pack.py` & `quality_gates.py` | Validates presence of primary sources and original research facts before drafting commences. | **ACTIVE** |
| **G2 Verification** | S14 → S21 | `fact_verification_subgraph.py` & `quality_gates.py` | Flags `contradicted` claims, verifies atomic claims against retrieved evidence, calculates overall fact score. | **ACTIVE** |
| **G3 Editorial lint** | S15-S17 → S20 | `on_page_seo_linter.py` & `humanizer.py` | Enforces H-tree depth ≤3, single H1, sources for statistics, banned AI phrases, and readability targets. | **ACTIVE** |
| **G4 Schema** | S18 → S20 | `schema_builder.py` & `web/app.py` | Validates JSON-LD schema syntax and guarantees visible content parity (author, dates, headline). | **ACTIVE** |
| **G5 Visual QA** | S19 → S20 | `image_delivery.py` & `quality_gates.py` | Enforces `/uploads/<filename>` paths, forbids unsourced graphics, mandates alt text and aspect ratio compliance. | **ACTIVE** |
| **G6 Render QA** | S20 → S21 | `media_renderers.py` & `quality_gates.py` | Generates 5 valid output formats, audits link health, and evaluates layout across viewports. | **ACTIVE** |
| **G7 Human approval** | S21 → S22 | `publish_modes.py` & `ArticleDrawer.tsx` | Halts execution at Human Review Gate; requires reviewer attestation before publishing in Mode 1. | **ACTIVE** |
| **G8 Post-publish** | S22 → S23 | `cms_publishers.py` & `website_client.py` | Verifies live URL response (HTTP 200), pings IndexNow, and stores revision hash for rollback safety. | **ACTIVE** |

---

## 5. Security, Secrets & Privacy Audit

1. **Environment Variables & Secrets:**
   - `.env.example` provides complete template without default real secrets.
   - All external API tokens (`TAVILY_API_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`, `CLOUDFLARE_API_TOKEN`, `SECRET_TOKEN`) are loaded via environment variables and masked in logs.
   - Website secret tokens are transmitted as Bearer headers over HTTPS/HTTP.
2. **Untrusted Web Data:**
   - Scraped competitor content and web evidence are treated strictly as data payloads with length truncation (`≤25` words per excerpt stored) to prevent prompt injection and copyright duplication.
3. **SSRF & Endpoint Protection:**
   - Target website ping and crawler inspection routines validate protocol schemes (`http://`, `https://`) and sanitize hostnames.
4. **Zero Git Staging Pollution:**
   - Rule B git-backed publisher strictly stages `content/posts/` and `public/uploads/` (`git add content/posts/ public/uploads/`). Configuration files, docs, and agent workspaces are never staged.

---

## 6. Milestone Alignment & Roadmap (M0 through M13)

| Milestone | Target Stages | Status in Repo | Verification Evidence |
|---|---|---|---|
| **M0** | Reconciliation & Audit | **COMPLETE** | This audit report (`docs/repo_audit.md`), 360+ tests passing, lockfile pinned, zero build errors. |
| **M1** | S1 Onboarding, S2 Profile, S3 Inventory | **COMPLETE** | `site_onboarding.py`, `brand_dna.py`, `brand_voice.py`, `harvest.py`, `test_v5_site_onboarding_a0.py`. |
| **M2** | S8 Decay Diagnosis, S9 Audit Checks | **COMPLETE** | `content_decay.py`, `technical_audit.py`, `compliance_layer.py`, `test_v5_content_decay_a8b.py`. |
| **M3** | S14 Claimify Verification, S21 Review Gate | **COMPLETE** | `fact_verification_subgraph.py`, `publish_modes.py`, `ArticleDrawer.tsx`, `test_fact_verification_a4.py`. |
| **M4** | S4-S7 Discovery, S10 Opportunity Feed | **COMPLETE** | `keyword_intelligence.py`, `aeo_engine.py`, `opportunity_feed.py`, `test_v5_opportunity_feed_a1b.py`. |
| **M5** | Update Loop, ChangeSets, Rollback | **COMPLETE** | `action_center.py`, `eval_experiments.py`, `test_action_center.py`. |
| **M6** | Studio: DocumentModel, Renderers, S15–S19 | **COMPLETE** | `article_model.py`, `media_renderers.py`, `links_engine.py`, `schema_builder.py`, `test_article_model_a5c.py`. |
| **M7** | S22 CMS Publishers, Publish Modes 1/2/3 | **COMPLETE** | `cms_publishers.py`, `website_client.py`, `publish_modes.py`, `test_cms_publishing_a5d.py`. |
| **M8** | S11–S13 New Article Pipeline, Evidence Pack | **COMPLETE** | `brief_builder.py`, `evidence_pack.py`, `draft_node.py`, `test_brief_builder.py`. |
| **M9** | S23 Panel & Attribution | **COMPLETE** | `analytics_client.py`, `attribution.py`, `ai_visibility.py`, `citable_evaluator.py`. |
| **M10** | S24 Experiments & Off-Site Engine | **COMPLETE** | `eval_experiments.py`, `off_site_engine.py`, `test_v5_offsite_compliance_eval.py`. |
| **M11** | Compliance & UI Polish | **COMPLETE** | `compliance_layer.py`, `ActiveRunHud.tsx`, `ArticleDrawer.tsx`, `WebsitesPage.tsx`, `SchedulesPage.tsx`. |
| **M12** | Enterprise & Multi-Site Deployment | **COMPLETE** | Multi-website isolation in `WebsitesPage.tsx` and SQLite backend; Rule A/B storage strategies. |
| **M13** | Design Partner Production Operations | **READY** | Automated scheduler active; production single-file bundle ready for live editorial deployment. |

---

## 7. Conclusion & Next Steps

The repository is fully reconciled with `AGENT_BUILD_SPEC.md` (v6). All architectural rules (Rule A direct HTTP, Rule B isolated Git, Next.js image contracts, excised Video/TTS, and 10 Prime Directives) are actively enforced across both the backend Python services and the frontend React application.

**Recommended operational focus:**
1. Maintain continuous test suite health (`python -m pytest -q`).
2. Keep frontend single-file production bundle updated upon UI feature changes (`npm run build`).
3. Deploy studio server (`python main.py studio`) and connect target editorial websites using the interactive **Connect Website** and **AI Agent Prompt** workflows.
