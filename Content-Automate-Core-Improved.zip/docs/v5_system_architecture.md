# Content Pipeline Agent — v5 Comprehensive System Architecture & Operating Manual

> **System Standard:** Autonomous Multi-Agent SEO / AEO / GEO Publishing Engine  
> **Core Philosophy:** "Every claim sourced, scored, and reviewed by a named human. Empirical reach over third-party scores. Rigorous causal measurement over marketing claims."

---

## 0. Gap Review: What Prior Iterations Got Wrong & How v5 Fixes Them

| # | Gap in Prior Versions | New Research & Reality (2025–2026) | v5 Fix & Implementation |
|---|---|---|---|
| **1** | Recommended FAQPage/HowTo schema as a GEO lever | Google ended FAQ rich results on 7 May 2026; HowTo retired earlier. FAQPage remains valid schema.org, but Google explicitly states no special markup is needed for AI features. AI citation benefits are unproven. | **A5 / A12**: Keeps valid JSON-LD schemas, but treats FAQ citation benefit as an unproven hypothesis tested via matched-control difference-in-differences experiments. |
| **2** | Said Search Console can't show AI Overview data | Google launched the Generative AI performance report (Aug 2026): impressions in AI Overviews + AI Mode by page, country, device, date. | **A8**: Added `generative_ai_performance` table, automated ingestion, and UI telemetry views. |
| **3** | Treated an automated verifier as sufficient | Google’s Oct 1, 2026 AI-content guidance mandates manual fact-checking before publishing, covering titles, metas, structured data, and alt text. | **A4 / A11**: Automated verifier acts as an editorial assistant, not an autonomous replacer. Forced human attestation checklists block unreviewed publishing. |
| **4** | 3–5 samples per prompt; single prompts as unit | Citations churn heavily across runs and paraphrases. One paraphrase study found phrasing variance causes massive source drift. | **A7**: The measurement unit is an intent cluster with 5–10 human-approved paraphrases, evaluated over repeated runs with Wilson/bootstrap 95% confidence intervals. |
| **5** | Leaned on "94% of AI Overviews cite top-20" | Studies show top-10 overlap falling from 76% to 38%. Ranking helps, but AI Overviews draw from deeper and non-owned sources. | **A6**: Calibrated empirical reach; optimization for citation-readiness, entity clarity, and primary data sources. |
| **6** | Almost nothing on off-site presence | Reddit, YouTube, LinkedIn, Wikipedia, and review platforms dominate citation results across all major engines. | **A9**: Dedicated Off-Site Presence Engine analyzing cited 3rd-party domains and drafting earned-presence briefs (strictly anti-astroturfing). |
| **7** | CTR model ignored AI Overviews | Organic CTR on AI-Overview SERPs drops 34–61% (-58% at Pos 1). | **A1 / A1b**: CTR curve adjusts for AIO feature drag; outputs expected clicks as uncertainty ranges $[min, max]$. |
| **8** | No legal / compliance layer | EU AI Act Article 50 (effective Aug 2026): mandatory disclosure unless human-reviewed with editorial responsibility. | **A10**: Reviewer attestation system with immutable SHA-256 version hashes, exemption badges, and IPTC image provenance metadata. |
| **9** | Claim extraction was a single prompt | Single prompt NLI checks hallucinate or fail when evidence is silent. | **A4 / A8b**: Claimify-style atomic decomposition, independent evidence retrieval (querying by claim, not draft wording), deterministic matching, and an `outdated` verdict kind. |
| **10** | No technical SEO audit, crawl/indexing or CWV | Lacked continuous crawl health, bot policy, and Core Web Vitals diagnostics. | **A9b**: Continuous technical audits, robots.txt bot classifier, PageSpeed/CrUX CWV tracking, and IndexNow pings. |
| **11** | No causal measurement | Naive before/after comparisons confuse seasonality and mean-regression with actual impact. | **A12**: Difference-in-Differences (DiD) causal engine with matched holdouts, reporting honest "inconclusive" verdicts when variance is high. |
| **12** | Ignored query fan-out | Answer engines issue dynamic internal sub-queries during research. | **A1 / A2 / A7**: Brief builder extracts sub-questions; logs engine fan-out queries for candidate keyword mining. |
| **13** | AI bot guidance too vague | Crawlers are now bifurcated into training bots vs. search/citation bots. | **A6.2**: Robots.txt auditor distinguishing training bots (`GPTBot`, `CCBot`) from citation bots (`OAI-SearchBot`, `PerplexityBot`). |
| **14** | No build-vs-buy decisions or spikes | Brittle web scraping of chat UIs risks bans and broken selectors. | **0.2 / Part C**: Official APIs for citations; DataForSEO for SERPs/mentions; internal code for scoring, audit, and verification. |

---

## 0.0 & 0.0a Version Evolution Summary

### Changes in v4
1. **AEO (Answer Engine Optimization)**: Dedicated module (`A5b`) with shared SEO/AEO/GEO tri-discipline targeting.
2. **Article Production Studio (`A5c`)**: Single typed JSON document model rendered to semantic HTML, MDX, and CMS blocks with visual decision engines (Mermaid diagrams, Vega-Lite charts, Playwright screenshots).
3. **Publishing Modes (`A5d`)**: Three distinct publish modes. Mode 3 (fully unattended autopilot) is **OFF by default** due to Google's Oct 2026 guidance and EU AI Act Art. 50.
4. **Visual & Performance Rules**: LCP preloading, WebP/AVIF generation, explicit image dimensions, and accessible alt-text checks.

### Changes in v5
1. **Site Onboarding & Inventory (`A0`)**: Business profile extraction (offerings, ICPs, differentiators, tone, YMYL flags), crawl inventory, and orphan page detection.
2. **Opportunity Feed (`A1b`)**: Human-friendly "What should I publish?" recommendations generated from intent templates, backed by verifiable evidence, with impact uncertainty ranges.
3. **Content Decay & Update Agent (`A8b`)**: Low-risk wedge focusing on existing published content first.
4. **Outdated Verdict Label (`A4`)**: Expresses "was true, now outdated" to trigger targeted refreshes.
5. **Significant Update Rule (`A8b.6`)**: Preserves `datePublished`; updates `dateModified` only for substantial revisions, aligning visible HTML, JSON-LD, and sitemap dates.
6. **Metric Breakpoint Protection (`A8b.1`)**: Accounts for Google's Sept 12, 2025 `num=100` deprecation; avoids false decay alarms.
7. **Evidence-Based Update Lift (`A8b.8b`)**: Conservative priors based on matched-control studies rather than headline agency claims.

---

## 0.0b The Three Disciplines as One System

| Discipline | Goal | Primary Surface | Key Performance Indicators | Core Levers |
|---|---|---|---|---|
| **SEO** | Crawled, indexed, and ranked | Blue organic links (Google, Bing) | Clicks, impressions, average rank, indexed URL count | Technical health, crawlability, search intent, internal/backlinks, E-E-A-T |
| **AEO** | Extracted direct answer | In-SERP answers: Featured Snippets, PAA, Knowledge Panels, AI Overviews | Snippet/PAA ownership, zero-click impressions, CTR capture | Question headings, direct answer blocks, semantic HTML lists/tables, entity clarity |
| **GEO** | Cited and mentioned in generative chat | AI Answer engines (ChatGPT, Perplexity, Claude, Gemini) | Domain/URL citation rate, brand mention rate, share of voice | Primary evidence, statistics, quotes, search bot crawl access, 3rd-party earned presence |

*Rule of thumb:* SEO is the foundation. Content that is not indexed cannot be extracted or cited. Every item in the content plan carries target flags `(seo, aeo, geo)`.

---

## 0.0c Master Workflow

```mermaid
sequenceDiagram
    autonumber
    participant A0 as A0: Onboarding & Inventory
    participant A1 as A1 & A1b: Opportunity Feed
    participant A2 as A2 & A4: Research & Claims
    participant A3 as A3 & A5c: Studio & Writer
    participant A11 as A10 & A11: Review Gate
    participant A5d as A5d: Publisher
    participant A8 as A8, A8b & A12: Feedback Loop

    A0->>A1: Crawl pages, business profile, competitor intersection
    A1->>A2: Ranked opportunity feed item accepted by editor
    A2->>A3: SERP brief + fan-out subqueries + evidence pack
    A3->>A4: Drafted article -> claim extraction & independent retrieval
    A4-->>A3: Policy engine verdicts (supported, outdated, contradicted)
    A3->>A11: Complete JSON document model with visual assets
    A11->>A11: Human review: verify checklist, title, schema, alt text
    A11->>A5d: Reviewer attestation signed (SHA-256 version hash recorded)
    A5d->>A8: Staged -> published -> post-publish DOM & schema validation
    A8->>A8: GSC telemetry & 28d/90d decay detection
    A8->>A1: Re-fits empirical reach & feeding update change-sets
```

---

## 0.2 Build vs. Buy Strategy

| Layer | Strategy | Rationale |
|---|---|---|
| **SERP & Keyword Data** | Buy (DataForSEO) | Maintaining global scrapers and keyword indices is brittle and non-core. |
| **Evidence Retrieval** | Buy (Tavily Search API) | Specialized web retrieval optimized for factual passage extraction. |
| **Foundation LLMs** | Buy (OpenAI, Anthropic, Gemini, Mistral, Groq) | Leverage multi-model routing; fast models draft, frontier models critique. |
| **Consumer LLM Scraper** | Buy (DataForSEO LLM Scraper) | Do NOT scrape consumer chat UIs directly (violates terms and breaks frequently). |
| **Core Differentiators** | **BUILD PROPRIETARY** | 1. Site-specific empirical reach & calibrated opportunity scoring (A1)<br>2. Closed-loop Claimify fact verification & outdated claim replacement (A4)<br>3. Content Decay & Update Agent with metric breakpoints (A8b)<br>4. Difference-in-Differences causal measurement engine (A12)<br>5. Regulatory compliance & immutable reviewer attestation records (A10) |

---

## PART A: PRODUCT FEATURES IMPLEMENTATION (A0 – A13)

### A0. Site Onboarding & Content Inventory
* **Module**: [pipeline/adapters/site_onboarding.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/site_onboarding.py)
* **API Endpoints**: `GET/POST /api/onboarding/business-profile/{site_id}`, `GET /api/onboarding/inventory/{site_id}`, `POST /api/onboarding/competitors/{site_id}`
* **Capabilities**:
  * Crawls core pages (home, pricing, docs, about) to produce versioned `business_profiles`.
  * Catalogs URLs: status code, canonicals, H-trees, schemas, word counts, publish/modified dates, images with alt text.
  * Graph traversal computes inbound internal link count and flags orphan pages.
  * Classifies competitors into business rivals vs search competitors (publishers, Reddit, G2).

### A1 & A1b. Keyword Engine & The Opportunity Feed
* **Modules**: [pipeline/adapters/keyword_intelligence.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/keyword_intelligence.py) & [pipeline/adapters/opportunity_feed.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/opportunity_feed.py)
* **API Endpoints**: `GET /api/opportunities/feed/{site_id}`, `POST /api/opportunities/generate/{site_id}`, `POST /api/opportunities/{id}/feedback`
* **CLI**: `python main.py opportunities --site default --limit 10`
* **Capabilities**:
  * Reusable intent templates (`best_of`, `vs_comparison`, `pricing_cost`, `alternatives`, `how_to`, `what_is`, `ai_answer`).
  * Percentile-normalized relative ranking (0–100 scale).
  * Impact ranges with uncertainty ($[min, max]$ clicks) modeling AI Overview drag.
  * Strictly evidence-backed explanation generator: every reason is tied to an `evidence[]` record.
  * Mandatory human-approval flag on comparison and pricing topics.

### A2 & A3. SERP NLP, Briefs & Evidence-Forward Writing
* **Modules**: [pipeline/adapters/brief_builder.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/brief_builder.py), [pipeline/adapters/section_drafter.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/section_drafter.py), [pipeline/adapters/brand_voice.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/brand_voice.py)
* **Capabilities**:
  * Topic and question extraction from SERP top-10, PAA, and engine fan-out queries.
  * Originality gate: requires at least one item of first-party evidence before drafting.
  * Incorporates Princeton/KDD 2024 GEO study guidelines (stats, quotes, and citations elevate AI visibility by ~30–40% on benchmarks).

### A4. Verification Pipeline & Outdated Verdict Handling
* **Module**: [pipeline/adapters/fact_verification_subgraph.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/fact_verification_subgraph.py)
* **Capabilities**:
  * Atomic decomposition: resolves pronouns and decontextualizes claims.
  * Independent evidence retrieval: queries via claim semantics, not draft text.
  * Multi-verdict policy: `supported`, `contradicted`, `unsubstantiated`, and `outdated`.
  * Outdated claims on existing pages trigger replacement proposals rather than hallucination errors.

### A5, A5b & A5c. SEO, AEO & Article Production Studio
* **Modules**: [pipeline/adapters/schema_builder.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/schema_builder.py), [pipeline/adapters/aeo_engine.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/aeo_engine.py), [pipeline/adapters/article_model.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/article_model.py)
* **Capabilities**:
  * Generates typed JSON document models rendered to semantic HTML, MDX, and CMS blocks.
  * AEO format matching: emits direct answer blocks in the format shown on the live SERP (paragraph, list, table).
  * Visual decision engine: Mermaid/D2 architecture diagrams, Vega-Lite/Plotly charts, and Playwright UI screenshots.

### A5d & A11. Publishing Modes & Editorial Governance
* **Modules**: [pipeline/adapters/publish_modes.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/publish_modes.py) & [pipeline/adapters/cms_publishers.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/cms_publishers.py)
* **Capabilities**:
  * **Mode 1**: Automated publish after approval (DEFAULT).
  * **Mode 2**: Low-risk refresh autopilot for minor non-factual updates (opt-in).
  * **Mode 3**: Unattended new-article autopilot (**STRICTLY DISABLED BY DEFAULT**).
  * Post-publish DOM verification, JSON-LD validation, and IndexNow pings.

### A6 & A7. AI Citation Tracking
* **Modules**: [pipeline/adapters/ai_visibility.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/ai_visibility.py) & [pipeline/adapters/citation_readiness.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/citation_readiness.py)
* **Capabilities**:
  * Official API panel tracking (OpenAI web search citations, Perplexity Sonar, Gemini Grounding, Claude web search).
  * Intent clusters with 5–10 paraphrases, repeated runs, and Wilson 95% confidence intervals.
  * Crawler policy auditor separating training crawlers from AI search/citation bots.

### A8 & A8b. Content Decay & Update Agent
* **Modules**: [storage/db.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/storage/db.py) & [pipeline/adapters/content_decay.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/content_decay.py)
* **API Endpoints**: `GET /api/decay/plans/{site_id}`, `POST /api/decay/prioritize/{site_id}`, `GET /api/decay/plans/{id}/changes`
* **CLI**: `python main.py decay --site default --hours 10`
* **Capabilities**:
  * Multi-window detection: 28d vs. prior 28d; 90d YoY seasonality validation.
  * Metric breakpoint awareness: handles the Sept 12, 2025 Google `num=100` deprecation without false alarms.
  * Diagnostic classifier: separates ranking decay, CTR/zero-click decay, demand decay, query drift, and cannibalization.
  * Discrete diff change-set generator: protects established ranking passages and enforces Google date guidance.

### A9. Off-Site Presence Engine
* **Module**: [pipeline/adapters/off_site_engine.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/off_site_engine.py)
* **API Endpoints**: `GET /api/off-site/summary/{site_id}`, `POST /api/off-site/plan/{site_id}`
* **Capabilities**:
  * Discovers high-citation non-owned domains (Reddit, YouTube, LinkedIn, G2, Wikipedia).
  * Drafts earned-presence briefs (discussion angles, timestamped video scripts, data posts).
  * Enforces anti-astroturfing rules: no bot posting, mandatory company affiliation disclosure, no Wikipedia COI edits.

### A10. Compliance, Disclosures & Reviewer Attestation
* **Module**: [pipeline/adapters/compliance_layer.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/compliance_layer.py)
* **API Endpoints**: `GET/POST /api/compliance/settings/{site_id}`, `POST /api/compliance/attest`, `GET /api/compliance/attestations/{site_id}`
* **Capabilities**:
  * **EU AI Act Article 50**: Generates transparency notices or editorial responsibility exemption badges based on human review.
  * **Google 1 Oct 2026 Editorial Guidance**: Enforces a mandatory verification checklist covering titles, meta descriptions, JSON-LD schema, alt text, and claims.
  * Immutable reviewer attestations with cryptographic SHA-256 version hashes.
  * YMYL / public-interest classifier requiring verified expert reviewers.
  * IPTC `DigitalSourceType` image provenance metadata (`trainedAlgorithmicMedia`).

### A12. Evaluation & Causal Experiments
* **Module**: [pipeline/adapters/eval_experiments.py](file:///c:/Users/azeem/OneDrive/Desktop/Content%20Automate/pipeline/adapters/eval_experiments.py)
* **API Endpoints**: `GET /api/experiments/{site_id}`, `POST /api/experiments/launch`, `POST /api/experiments/evaluate-did`
* **CLI**: `python main.py eval --treat-pre 10,12,11 --treat-post 25,27,26 --ctrl-pre 10,11,10 --ctrl-post 11,12,11`
* **Capabilities**:
  * Difference-in-Differences (DiD) causal engine with matched holdouts.
  * Calculates causal effect, standard errors, and 95% confidence intervals.
  * Reports honest `"inconclusive"` verdicts when samples are small or intervals straddle zero.
  * Evaluates fact verifier accuracy (precision, recall, F1) against golden sets.

---

## PART B: ENTERPRISE ARCHITECTURE & DEPLOYMENT

### B1. Multi-Tenant Isolation
* **Website Scoping**: All database tables (`websites`, `pages`, `opportunity_feed_items`, `reviewer_attestations`, `experiments`) partition data strictly by `website_id`.
* **Zero Global Assumptions**: Credentials (CMS tokens, GitHub repos, Slack channels) are configured per tenant and never shared across websites.
* **Storage Independence**: Websites using Upstash Redis or integrated SQL submit articles directly over HTTP without requiring git tokens or repository writes.

### B2. Asynchronous Execution & Checkpointing
* **Orchestration**: LangGraph StateGraph compiled with durable SQLite checkpointing (`pipeline_checkpoints.db`).
* **Resumability**: Interrupted human review gates persist state to disk; runs resume seamlessly upon approval or rejection.
* **Task Scheduling**: APScheduler background runner executes recurrent syncs (Search Console nightly ingestion, weekly crawler audits, decay checks).

### B3. Rate Limiting & API Resiliency
* **Backoff Strategy**: Tenacity exponential backoff with jitter on all LLM and SERP API calls.
* **Batch Endpoints**: Keyword intelligence queries use DataForSEO bulk endpoints (up to 1,000 items per call) with cached responses in SQLite to prevent duplicate expenditure.

---

## PART C: ORDER OF WORK, IMPLEMENTATION SPIKES & RISKS

### C1. Strategic Order of Work
1. **Low-Risk Wedge (Content Decay Agent A8b)**:
   * Operates on existing content already published by a human editor.
   * Carries the lowest scaled-content risk while delivering measurable organic click recovery.
   * Exercises Search Console ingestion, claim verification, Studio diff editing, and reviewer attestations.
2. **Opportunity Feed (A1b)**:
   * Generates prioritized new and update topics backed by real evidence.
3. **Studio Production & Human Gate (A5c, A10, A11)**:
   * Produces structured articles with visual QA, mandatory compliance checklists, and SHA-256 attestation signing.
4. **Causal Measurement Loop (A12)**:
   * Evaluates update outcomes against matched controls to re-fit recoverability weights.

### C2. Validated Spikes & Risk Mitigations
* **Spike 1: Metric Breakpoint Drift**:
  * *Risk*: Comparing pre- and post-Sept 2025 Search Console impressions causes false decay alerts due to Google's `num=100` deprecation.
  * *Mitigation*: The `metric_breakpoints` table marks impression and position comparisons spanning breaks as invalid, relying strictly on clicks.
* **Spike 2: Regulatory & Editorial Non-Compliance**:
  * *Risk*: Publishing unreviewed AI content violates EU AI Act Art. 50 and triggers Google quality penalties.
  * *Mitigation*: Mode 3 unattended publishing is strictly disabled; pre-publish gates enforce a mandatory 5-point verification checklist signed with a cryptographic version hash.
* **Spike 3: Unsubstantiated Marketing Claims**:
  * *Risk*: Over-promising "100%+ traffic increases" or "zero hallucinations".
  * *Mitigation*: The DiD causal calculator outputs confidence intervals and reports "inconclusive" when evidence is ambiguous.

---

## Verification Summary

All 39 automated test modules pass with 100% success rate:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
# Output: 362 passed, 6 warnings in 143.68s

.\.venv\Scripts\python.exe main.py verify
# Output:
# [1/4] Phase 1 interrupted at review gate: OK
# [2/4] Phase 2 revision loop: OK
# [3/4] Phase 3 publish + repurpose: OK
# [4/4] Phase 4 fail-closed state validation: OK
# SMOKE TEST PASSED
```
The architecture and implementation are fully operational and verified.
