# AGENT_BUILD_SPEC.md: Content Pipeline Agent (v6)

**Audience:** an AI coding agent (or developer) building or upgrading `github.com/Azeem1252/content-pipeline-agent`.
**Date:** 9 Oct 2026. **Status:** authoritative build specification. Where this file and any older note disagree, this file wins.
**Companion document:** the v5 implementation plan (rationale and research narrative). This file is the *executable* version: exact flow, contracts, rules, and acceptance tests.

---

## 0. How to use this file (read first)

### 0.1 Reading order
1. Section 0 (rules) → 1 (product) → 2 (repo reconciliation: **do this before writing code**) → 5 (master workflow) → the stage you are building in section 6 → 7-9 (data, config, API) → 13 (tests).
2. Section 3 (evidence register) explains *why* rules exist. Read it before changing any rule.
3. Section 15 gives build order. **Do not start a milestone before its predecessor's Definition of Done is met.**

### 0.2 Prime directives (non-negotiable)

| # | Directive | Meaning in practice |
|---|---|---|
| P1 | **Never invent facts, data, sources, quotes, prices, screenshots, or metrics.** | Every factual statement in generated content traces to a stored `evidence` row. Demo/fixture data is labelled `synthetic`. |
| P2 | **Nothing is hardcoded.** | Thresholds, weights, prompts, model names, bot lists, source tiers, limits, and templates live in versioned config or the database (per tenant/site). Code reads config; it does not contain magic numbers. |
| P3 | **A human approves content before it goes live** (default). | Publish Mode 1 is the default. Modes 2 and 3 are opt-in and gated (see S22). |
| P4 | **Verification is invalidated by any text change.** | If text changes after verification (SEO edit, link insertion, visual caption, human edit), re-run verification on the diff before the next gate. |
| P5 | **Measurement uses intervals and controls, never single numbers.** | AI-citation rates and update uplift are reported with uncertainty; claims of causality need matched controls. |
| P6 | **Respect external rules.** | robots.txt, API terms, rate limits, copyright, privacy law. No scraping consumer chat UIs. No fake accounts or astroturfing. |
| P7 | **Idempotent and reversible.** | Every job can be retried safely. Every publish/update can be rolled back. |
| P8 | **Typed contracts between stages.** | Stages exchange Pydantic models (section 7/Appendix B), not free text. |
| P9 | **Reuse before rewrite.** | If the repo already implements something, adapt it to this spec (section 2). Do not create a parallel implementation. |
| P10 | **Unknowns are spikes, not guesses.** | If an API behaviour is unverified (section 3 marks these), build an adapter interface plus a fake, write a spike note, and do not hardcode assumptions. |

### 0.3 Keywords
**MUST / MUST NOT** = required. **SHOULD** = default unless an ADR justifies otherwise. **MAY** = optional. **(config)** = value comes from config, with the shown value only as the shipped default.

### 0.4 Rules of engagement for the coding agent
1. Before coding, produce `docs/repo_audit.md` (section 2). Before each milestone, write a short plan in `docs/adr/NNNN-title.md` if you make a design choice not covered here.
2. Write tests first for new behaviour; add **characterisation tests** around existing behaviour before changing it.
3. Make small, reviewable commits. One concern per PR.
4. When a requirement is ambiguous, prefer the safest interpretation (more human review, less automation) and record the question in `docs/open_questions.md`. Do not stop work unless the ambiguity blocks correctness or safety.
5. Never commit secrets. Never log secrets, OAuth tokens, or full retrieved web pages.
6. Never silently weaken a gate to make a test pass. If a gate is wrong, change it via an ADR.
7. Report progress by milestone checklist (section 15), listing what passed, what failed, what is deferred.

### 0.5 Definition of Done (applies to every module)
- Typed inputs/outputs; schema validation at boundaries.
- Config-driven; no hardcoded thresholds.
- Unit tests plus at least one contract/fixture test per external API.
- Structured logs with `run_id`, `tenant_id`, `site_id`, `stage`.
- Cost recorded in `cost_ledger` for every paid call.
- Failure modes handled as specified (retry, degrade, or "needs human").
- Documented in `docs/modules/<name>.md` (inputs, outputs, config keys, limits).

---

## 1. Product definition

**One line:** an AI content operations platform that finds which existing pages are decaying and why, tells the user what to publish next with evidence, writes and updates content with verified claims, requires human approval, publishes to the CMS, and measures results against matched controls.

**Positioning:** "Verified, human-approved, measurable content." Hands-off *mechanics*, human-approved *content*.

**Three optimisation targets (every content item carries flags `seo`, `aeo`, `geo`):**

| | SEO | AEO | GEO |
|---|---|---|---|
| Goal | Be crawled, indexed, ranked | Be the extracted answer: featured snippets, People Also Ask, knowledge panels, AI Overviews | Be cited/mentioned in generative chat answers (ChatGPT, Perplexity, Gemini, Claude) |
| KPIs | Rank, clicks, indexed share | Snippet/PAA/AIO ownership, zero-click proxy | Mention and citation rates with intervals |
| Foundation | SEO is the foundation of the other two | | |

**Run types** (the supervisor chooses one per run): `onboard`, `opportunity_refresh`, `new_article`, `update_article`, `consolidate`, `citation_gap_fix`, `technical_fix`, `measure`.

**Strategy:** ship the **update loop** (decay → diagnose → evidence-backed change set → review → publish → measure) **before** mass new-article generation. It carries the least scaled-content risk and reuses the same components.

**Claims the product MUST NOT make (marketing or UI copy):** "zero hallucinations", guaranteed rankings, guaranteed AI citations, "fully hands-off content", unlabelled illustrative numbers, fake logos or testimonials.

---

## 2. Existing-repo reconciliation protocol (do this before coding)

The repo is believed (from its README and folder tree; **verify against the code**) to contain: a LangGraph pipeline (outline → draft → audit → image → Slack review gate → publish → repurpose), Groq/Mistral model routing, SQLite storage, APScheduler, a FastAPI "Mission Control" dashboard, folders `data/ frontend/ pipeline/ scripts/ storage/ web/`, a `ContentState`, and `verify_checkpointer.py`. The README mentions `tests/` and `docs/` that were not present in the tree; `requirements.txt` was incomplete (no Tavily, Gemini SDK, APScheduler) and unpinned.

### 2.1 Audit procedure
1. List every module, entrypoint, prompt, config file, DB table, route, scheduled job, and external API call. Write `docs/repo_audit.md` with one row per item: `path | purpose | status (working/partial/broken/unknown) | target stage | decision`.
2. Run the project. Record what actually works. Fix `requirements.txt` first (add missing packages, pin versions via lockfile) so a clean clone runs.
3. Add characterisation tests for existing behaviour that you intend to keep.
4. Scan git history and `.env` for leaked secrets. If any, list them for rotation (do not print values).

### 2.2 Decision rules

| Decision | When | Action |
|---|---|---|
| **KEEP** | Existing code satisfies the stage contract | Add tests, wire into the new state model |
| **ADAPT** | Logic is useful but shape differs | Refactor behind the new interface; keep behaviour tests green |
| **REPLACE** | Contradicts a prime directive (e.g. hardcoded thresholds, unverified publish) | Build the replacement, migrate callers, then delete the old code in a separate PR |
| **ADD** | Stage does not exist | Build per section 6 |
| **DEFER** | Valid but not needed yet (e.g. repurpose-to-social) | Leave in place, behind a feature flag, out of the critical path |

### 2.3 Expected mapping (verify, then follow the audit result)

| Existing (believed) | Target stage(s) | Default decision |
|---|---|---|
| outline node | S11 Brief builder | ADAPT: must consume SERP/gap data and answer-surface targets |
| draft node | S13 Draft generation | ADAPT: section-by-section, evidence-pack-gated, structured output |
| audit node | S14 verification + S15/S16 lint | REPLACE with claim pipeline; keep any useful lint rules |
| image node | S19 Visuals | ADAPT: split into diagrams/charts/screenshots/images/OG; no generic AI hero by default |
| Slack review gate | S21 Human review | KEEP as a secondary channel; primary review UI is web (forced confirmations, attestations) |
| publish node | S22 Publish | ADAPT: draft-first, idempotent, media upload, post-publish diff, rollback |
| repurpose node | optional later | DEFER behind a flag |
| APScheduler | queue + scheduler (section 14) | REPLACE after features work; until then wrap behind a `Scheduler` interface |
| SQLite | SQLAlchemy models + Alembic | ADAPT now (repository layer), switch engine to Postgres in section 14 |
| `ContentState` | `RunState` (section 5.4) | ADAPT: extend, keep field names where compatible |
| FastAPI dashboard / `frontend/` | web app (section 9) | KEEP what works; build new screens per section 6 (S21, S10, S8) |
| Groq/Mistral router | model router (section 10) | ADAPT: config-driven roles, fallbacks, cost ledger |

### 2.4 Output of this step
`docs/repo_audit.md`, a green test suite on a clean clone, a lockfile, CI skeleton, and an ADR listing every REPLACE decision with its migration plan.

---

## 3. Evidence register (researched facts that shape the rules)

Confidence: **H** = multiple consistent sources or primary docs; **M** = reputable secondary source or a single strong study; **L** = vendor/blog claim or unconfirmed. **Anything marked M/L MUST be verified against the primary source before it appears in customer-facing copy.** Verify date: facts below were gathered 4 Oct 2026.

### 3.1 Search platform rules

| # | Fact | Conf. | Design consequence |
|---|---|---|---|
| E1 | Google's spam policy targets *scaled content abuse*: many pages made mainly to rank with little value. Using AI is not itself a violation | H | Evidence-pack gate, velocity caps, similarity checks, human approval |
| E2 | Google's 1 Oct 2026 AI-content guidance calls **manual** fact-checking and review before publishing critical, including titles, meta descriptions, structured data and alt text | M (secondary reports) | Verifier assists a human; forced-confirmation review; metadata is verified too |
| E3 | Google's August 2026 spam update targeted large volumes of thin/AI/programmatic pages; a September 2026 update was reported still rolling out in early October | M | Auto-pause on anomalies; no Mode 3 by default |
| E4 | Helpful-content guidance (reportedly edited 2 Oct 2026) lists effort, originality, talent or skill, and accuracy as attributes | M | Editorial rubric score per article (not a ranking factor claim) |
| E5 | FAQ rich results ended 7 May 2026; HowTo rich results retired earlier; Google reportedly says no special markup is needed for AI features | M | FAQPage/HowTo are optional and **A/B-tested hypotheses**, not defaults |
| E6 | Google's guidance on dates: show real dates; don't artificially freshen without significant changes; keep visible date, structured data and sitemap `lastmod` consistent | H | Date rules in S24 |
| E7 | Search Console now has a **Generative AI performance report** (announced 3 Jun 2026; all sites from 31 Aug 2026): impressions in AI Overviews + AI Mode by page/country/device/date; reportedly no queries, no clicks, features combined | M | Store as its own table; **spike:** does the API expose it? else scheduled CSV import |
| E8 | GSC API: ≤25,000 rows per request (paginate `startRow`); daily row cap per site per search type; ~2-3 day lag; ~16 months retention; rare queries anonymised; URL Inspection ≈2,000/day/property and 600/min; BigQuery bulk export exists | H | Own history store from day one; bulk export; selective URL inspection |
| E9 | ~12 Sep 2025 Google stopped honouring `num=100`: most sites lost Search Console impressions (one study: 87.7% of 319 properties), average position looked better; clicks not inflated. A later 2026 impression correction is reported but unconfirmed | H (2025 break), L (2026 correction) | `metric_breakpoints` table; YoY impressions/position across a break are "not comparable" |
| E10 | Training crawlers and search/retrieval crawlers are now separate user agents (e.g. GPTBot vs OAI-SearchBot vs ChatGPT-User; ClaudeBot vs Claude-SearchBot vs Claude-User; PerplexityBot vs Perplexity-User; Google-Extended is separate from Googlebot, which governs AI Overviews) | M | Per-tenant bot policy; robots auditor; names in config; verify in vendor docs |
| E11 | IndexNow benefits Bing and participating engines, not Google | M | Use IndexNow + sitemaps; don't rely on it for Google |
| E12 | Core Web Vitals thresholds at p75: LCP ≤2.5s, INP ≤200ms, CLS ≤0.1 | H (verify unchanged) | CWV gates via PageSpeed/CrUX |

### 3.2 AEO / GEO / AI citations

| # | Fact | Conf. | Design consequence |
|---|---|---|---|
| E13 | Featured snippets are chosen automatically; no snippet-specific markup; format follows the existing SERP (paragraph/list/table/video); winners are usually pages already ranking well | M | Eligibility gate (rank near top 10), format matching |
| E14 | Princeton/KDD 2024 GEO study: adding relevant statistics, quotations and citations raised visibility ~30-40% on its benchmark; keyword stuffing didn't help | M (benchmark, not live engines) | Evidence-rich writing **only with real sourced facts**; test in experiments |
| E15 | AI citations are volatile: repeated runs of one prompt share few cited domains; many sources appear on one day only; engines cite largely different sources; brand mentions are steadier than source citations; paraphrases of one intent can differ more than reruns of one prompt | M | Unit = intent cluster with 5-10 paraphrases, reruns, intervals, held-out probes |
| E16 | Large citation studies report Reddit, YouTube, LinkedIn, Wikipedia, review sites and editorial outlets as major cited sources; owned pages are often a minority | M | Off-site presence module (human-published, no astroturfing) |
| E17 | One 2026 study (863k keywords) reported AIO citation overlap with organic top-10 falling from 76% to 38% | M | Ranking helps but isn't sufficient |
| E18 | AI Overviews cut organic CTR (reported 34-61% across studies; Ahrefs −58% at position 1, Dec 2025); studies disagree | M | CTR model depends on SERP features, fitted from own GSC data |
| E19 | `llms.txt` has no confirmed effect on Google; treat as optional/unproven | L | Optional, low priority, measured |
| E20 | Engine APIs return citations differently: OpenAI Responses `web_search` → `url_citation` annotations; Perplexity Sonar → citations/search_results; Gemini Grounding with Google Search → `groundingMetadata.groundingChunks` with **redirect URIs to resolve**; Claude web search tool → search-result blocks + text citations | M-H (verify at build) | One adapter per engine, fixture-tested |
| E21 | DataForSEO AI Optimization APIs: LLM Responses (multi-engine), LLM Scraper (consumer-like results), LLM Mentions (AI Overviews + ChatGPT data; per-request + per-row pricing), AI Keyword Data | M | Tier-2 measurement; confirm prices and coverage in sandbox |

### 3.3 Fact-checking and content updates

| # | Fact | Conf. | Design consequence |
|---|---|---|---|
| E22 | Better claim verification = Claimify-style extraction (selection → disambiguation → decomposition → decontextualisation) + independent evidence retrieval + verdict with cited span; NLI-style checks can be over-confident when evidence is silent | M | S14 design; deterministic numeric/date checks first |
| E23 | Decay is only decay after excluding seasonality, demand drops, technical faults, sitewide updates; validate with YoY; filter by minimum baseline clicks and sustained decline | M | S8 classifier |
| E24 | Update lift evidence: Raptive matched-control analysis of ~103k refreshes found refreshed pages beat similar untouched pages by ~19 percentage points on average, with large variance; image, title and structure changes correlated with larger gains; low-traffic pages (<~20 monthly visits) gained little; HubSpot/Backlinko-style case studies are self-selected | M | Wide conservative impact ranges; minimum-potential filter; matched controls required |
| E25 | EU AI Act Art. 50 applies from 2 Aug 2026: AI-generated text published to inform the public on public-interest matters needs disclosure unless human-reviewed with a person holding editorial responsibility; provider marking duties with a reported grace period to 2 Dec 2026 for systems already on the market | M | Disclosure settings, reviewer attestations; get counsel |
| E26 | AI image providers add provenance (OpenAI C2PA manifests; Google SynthID on Gemini images); re-encoding can drop manifests | M | Keep originals; IPTC `DigitalSourceType`; disclosure flag |

### 3.4 Open spikes (resolve in Milestone M0; record answers in ADRs)
1. Does the GSC API expose the Generative AI report? (else CSV import)
2. Which engine APIs expose the sub-queries (fan-out) they ran?
3. Real DataForSEO costs and rate limits at your volumes (sandbox first).
4. Agreement between your API panel and DataForSEO LLM Scraper on 30 prompts.
5. Are you an EU AI Act Art. 50 "provider" if you sell this? (counsel)
6. Current bot user-agent names per vendor.
7. Date/scope of any 2026 Search Console impression correction (feeds `metric_breakpoints`).

---

## 4. Architecture

### 4.1 Components
```
Web app (React/Next.js)  ──REST/OpenAPI + webhooks──▶  API service (FastAPI)
                                                          │ enqueue
                                  ┌───────────────────────▼──────────────────────┐
                                  │ Job queue (Redis + ARQ/Celery) + scheduler   │
                                  └───────┬───────────────────────────┬──────────┘
                           stateless workers                    crawler/monitor workers
                    (LangGraph supervisor + stage nodes)        (crawl, links, prices, screenshots)
                                  │                                   │
        Postgres (+pgvector): app data, LangGraph checkpoints, evidence, metrics, versions
        Object storage + CDN: media, original images, snapshots, screenshots, exports
        Redis: queue + API cache + rate limiters
        External: GSC, GA4, DataForSEO, Tavily, LLM providers, CMS APIs, PageSpeed/CrUX
        Observability: OpenTelemetry, structured logs, Sentry, Langfuse/LangSmith
```
Until section 14 is built, run on SQLite + in-process scheduler **behind the same repository and scheduler interfaces**, so the engine swap is configuration.

### 4.2 Technology choices (defaults; change via ADR)
Python 3.12; FastAPI; Pydantic v2; SQLAlchemy 2 + Alembic; LangGraph (with `AsyncPostgresSaver` in production); httpx + tenacity; trafilatura + selectolax; spaCy or LLM NER; embeddings via a provider or sentence-transformers; scikit-learn/hdbscan (optional); pgvector; Playwright; mermaid-cli, D2, Graphviz; Vega-Lite/Altair or Plotly; Pillow or pyvips; axe-core; Lighthouse CI; Jinja2; LiteLLM or the existing `llm_client.py` behind one router interface; pytest + pytest-recording (VCR-style); ruff; mypy.

### 4.3 Suggested layout (map existing folders into this; do not duplicate)
```
app/
  core/            config.py, settings, logging, errors, ids, clock
  db/              models/, repositories/, migrations/ (Alembic)
  integrations/    gsc/, ga4/, dataforseo/, tavily/, llm/ (router+adapters), cms/, pagespeed/, crux/
  stages/          s01_onboard … s24_improve  (one package per stage; node + models + tests)
  verify/          claims.py, evidence.py, verdicts.py, policy.py, report.py
  studio/          document_model.py, renderers/, visuals/, links/, schema/, gates/
  measure/         ctr_model.py, decay.py, panel/, snippets.py, experiments.py, stats.py
  graph/           supervisor.py, run_types.py, state.py
  api/             routers/, schemas/, webhooks.py
  workers/         queue.py, scheduler.py, crawler.py, monitors.py
prompts/           <stage>/<name>.v<N>.jinja  + manifest.yaml
config/            defaults.yaml, tenants/<id>.yaml, sites/<id>.yaml
tests/             unit/, contract/, golden/, e2e/
docs/              repo_audit.md, adr/, modules/, open_questions.md
```

### 4.4 Cross-cutting conventions
- **IDs:** ULIDs. **Times:** UTC, stored with timezone. **Money:** integer micro-units + currency.
- **Tenancy:** every table has `tenant_id`; site-scoped tables also `site_id`. Repositories enforce the filter; there is no raw query path without it.
- **Versioning:** articles, prompts, style profiles, and configs are versioned; runs record the versions they used.
- **Immutability:** `approvals`, `verification_reports`, `audit_log`, `price_observations`, `panel_runs` are append-only.
- **Errors:** typed (`RetryableError`, `PermanentError`, `NeedsHuman`). Nodes never swallow errors. `NeedsHuman` pauses the run with a reason and a UI task.
- **External calls:** go through integration clients that apply timeouts, retry with backoff, rate limits, caching (where allowed), and write `cost_ledger`.
- **Untrusted text:** web content, scraped pages, and uploaded documents are *data*. Wrap before prompting, strip instructions, and never give web-reading nodes credentials or publish tools (P6, section 11).

---

## 5. Master workflow

### 5.1 End-to-end flow (the product pipeline)

```
WEBSITE
 ├─ S1  Connect & onboard
 ├─ S2  Understand the business
 ├─ S3  Crawl existing content → inventory
 ├─ S4  Find competitors
 ├─ S5  Find content gaps
 ├─ S6  Find search questions (AEO question mining)
 ├─ S7  Find AI-answer opportunities
 ├─ S8  Detect decay & diagnose
 ├─ S9  Page audit (findings)
 ├─ S10 Build content plan → Opportunity Feed (new / update / consolidate)
 │      ── user chooses an item ──▶ a run starts (new_article or update_article)
 ├─ S11 SERP research & brief
 ├─ S12 Research sources & evidence pack
 ├─ S13 Generate article (or change set for updates)
 ├─ S14 Fact verification (claim-level)
 ├─ S15 SEO optimisation
 ├─ S16 AEO / GEO optimisation
 ├─ S17 Internal linking
 ├─ S18 Schema
 ├─ S19 Images, diagrams, charts, tables
 ├─ S20 Assemble, render, quality gates
 ├─ S21 Human review (forced confirmations, attestation)
 ├─ S22 Publish (mode-controlled) + post-publish checks
 ├─ S23 Measure
 └─ S24 Improve / update (loops back to S8-S10)
```

### 5.2 Ordering rules that differ from a naive reading
1. **Fact verification happens at three points:** (a) *source-first* during S12 (evidence is gathered before writing); (b) *claim-level* in S14 on the draft; (c) **re-verification on any later text change** (S15-S19, S21). Concretely, S15-S19 may only change text through the *document model*, which records a text diff; the gate before S21 fails if any changed text lacks a fresh verdict.
2. **S15-S19 are applied to the document model, not to raw HTML.** Rendering to HTML/CMS formats happens in S20 only.
3. **S6, S7, S9 feed S10.** None of them creates content.
4. **Loops:** S23 → S24 → S8/S10; S14 failure → S13 revision (max 2 loops) → `NeedsHuman`; S20 gate failure → fix task; S21 rejection → revise or abandon with reason.

### 5.3 Run types and the stages they execute

| Run type | Stages | Notes |
|---|---|---|
| `onboard` | S1-S7, S8-S10 first pass | Produces inventory, baseline report, first feed |
| `opportunity_refresh` | S4-S10 | Weekly or on demand |
| `update_article` | S11 (diff mode), S12-S14, S15-S19 (change set only), S20-S23 | Output is a **change set**, not a rewrite |
| `new_article` | S11-S23 | Requires evidence pack (S12) |
| `consolidate` | S9 findings → merge plan → S13 (merge) → S14 → S20-S22 with 301 map | Human approval mandatory |
| `citation_gap_fix` | S7 gap → S11 (competitor-cited pages analysis) → update or new run | |
| `technical_fix` | S9 technical findings → task list (+ CMS fixes where allowed) | |
| `measure` | S23 only (scheduled) | |

### 5.4 Run state (Pydantic `RunState`, stored via LangGraph checkpointer)
```python
class RunState(BaseModel):
    run_id: str; tenant_id: str; site_id: str
    run_type: Literal["onboard","opportunity_refresh","new_article","update_article",
                      "consolidate","citation_gap_fix","technical_fix","measure"]
    status: Literal["queued","running","needs_human","approved","published","failed","cancelled"]
    plan_item_id: str | None          # from S10
    page_id: str | None               # for updates
    flags: dict                       # {"seo":True,"aeo":True,"geo":True}
    brief: Brief | None
    evidence_pack: EvidencePack | None
    document: DocumentModel | None    # current working version
    change_set: ChangeSet | None      # update runs
    claims: list[Claim] = []
    verdicts: list[Verdict] = []
    findings: list[Finding] = []
    gates: dict[str, GateResult] = {}
    visuals: list[VisualAsset] = []
    approvals: list[ApprovalRef] = []
    versions: dict[str,str]           # prompt/style/config versions used
    loop_counts: dict[str,int] = {}   # e.g. {"critique":1,"verify_revise":0}
    cost_micro: int = 0
    errors: list[ErrorRecord] = []
```
Rules: state holds **references (IDs/URLs)** for large objects (pages, evidence text, images), never raw credentials or full web pages.

### 5.5 Supervisor behaviour
- A **Plan-and-Execute** supervisor writes the stage plan for the run type (above) into state before executing; it re-plans only on `NeedsHuman` resolution or explicit user change.
- Worker nodes are the stage functions. Specialised "agents" (research, briefing, writing, verification, editorial) are **nodes with typed I/O**, not free-form conversing agents.
- **Start simple:** one writer node with a capped critique loop. Add specialised sub-agents only if section 13 evals show a gain.
- **Interrupts:** the graph MUST pause at S21 (and at any `NeedsHuman`) using LangGraph `interrupt()` with a persistent checkpointer.
- **Idempotency:** each node computes an `idem_key = hash(run_id, stage, inputs_version)`; re-execution returns stored output.

### 5.6 Gates (blocking checks) at a glance
| Gate | After stage | Blocks | Details |
|---|---|---|---|
| G1 Evidence-pack | S12 | S13 | At least one original input present, unless site config waives it |
| G2 Verification | S14 / re-run | S21 | No `contradicted`; no unsupported stat/quote/date; high-risk claims queued for named human |
| G3 Editorial lint | S15-S17 | S20 | Byline, dates, sources, banned phrases, readability |
| G4 Schema | S18 | S20 | Valid, matches visible content |
| G5 Visual QA | S19 | S20 | No unsourced chart data; diagram/ table checks pass |
| G6 Render QA | S20 | S21 | axe, Lighthouse, links, layout at 3 viewports |
| G7 Human approval | S21 | S22 | Forced confirmations complete; attestation stored |
| G8 Post-publish | S22 | S23 | Live page matches intended document |

---

## 6. Stage specifications

Template for each stage: **Purpose · Trigger · Inputs · Procedure · Outputs · Config · Gates/failure · Acceptance tests.**

### S1. Connect and onboard
- **Purpose:** obtain read access and brand inputs.
- **Inputs:** user OAuth consent (Search Console, GA4: read-only scopes), CMS credentials, sitemap URL(s), brand kit (logo, colours, fonts, style), author profiles (name, photo, credentials, links), optional reviewer experts, crawler/bot policy, publish mode, disclosure settings, languages/locales.
- **Procedure:** run OAuth; list GSC properties and let the user pick; verify GA4 property; test CMS connection with a read-only call; store tokens **encrypted**; schedule history backfill (GSC: max available; also request BigQuery export setup instructions).
- **Outputs:** `sites`, `integrations`, `authors`, `brand_kits`, initial `site_config`.
- **Gates/failure:** missing scope → actionable error (which scope, how to grant); token revoked → mark integration `needs_reauth`, pause dependent jobs.
- **Tests:** OAuth flow with a mocked provider; encrypted token round-trip; tenant isolation.

### S2. Understand the business
- **Procedure:** fetch homepage, product, pricing, about, docs pages (robots-aware). LLM extracts a `BusinessProfile`: offerings, ideal customer profiles, problems solved, differentiators, pricing model, geographies, languages, tone, regulated-topic flags (health/legal/financial/safety), "never say" rules. Present to the user for **confirmation/edit once**; store versioned.
- **Outputs:** `business_profiles` (versioned), brand embedding vector.
- **Config:** `business.regulated_topics`, `business.never_say[]`.
- **Gates:** no downstream scoring runs until the profile is confirmed.
- **Tests:** extraction schema validity on 5 fixture sites; confirmation required.

### S3. Crawl existing content → inventory
- **Procedure:** seed URLs from sitemaps + GSC pages + internal links; polite crawl (robots, per-host rate limit, retries). For each URL store: status, redirects, canonical, indexability (meta robots, headers), title, meta description, H-tree, main text (trafilatura), word count, dates (visible, JSON-LD, sitemap `lastmod`), author, schema types, images + alt, in/out links, products/prices detected, embeddings, content type (blog/product/docs/other), GSC queries mapped to the URL. Detect orphans (in sitemap, zero internal inbound links). Convert blog-like pages to `DocumentModel` (HTML → blocks; deterministic rules first, LLM-assisted classification for ambiguous blocks); keep raw HTML snapshot (`page_versions`).
- **Outputs:** `pages`, `page_versions`, `page_links`, `page_images`, `page_queries`.
- **Config:** `crawl.max_pages`, `crawl.rate_per_host`, `crawl.user_agent`, `crawl.respect_robots=true`.
- **Gates/failure:** blocked by robots → record, skip, report; JS-only content → flag `needs_rendering` and render with Playwright when allowed.
- **Tests:** fixture site with orphan, redirect chain, JS-rendered page, noindex page.

### S4. Find competitors
- **Procedure:** union of user-listed competitors, DataForSEO Labs `competitors_domain`, and recurring domains in SERPs for the site's top queries. Classify each as **business competitor** vs **search competitor** (publisher/review site competing for the same results). User confirms.
- **Outputs:** `competitors(domain, type, evidence, confirmed)`.
- **Tests:** classification rule tests; confirmation persisted.

### S5. Find content gaps
- **Procedure:** for confirmed competitors call Labs `ranked_keywords` and `domain_intersection` against the site's own `ranked_keywords`; map keyword clusters to existing URLs; compute coverage gaps and unanswered-question gaps per page.
- **Outputs:** `keyword_candidates` (source=`competitor_gap`), `page_gaps`.
- **Cost control:** cache results by (endpoint, params hash, location, language); shortlist before SERP calls.

### S6. Find search questions (AEO question mining)
- **Sources:** SERP `google/organic/live/advanced` (People Also Ask, related searches; expand PAA with the API's click-depth parameter after checking the docs), GSC queries filtered by question words (config list per language), support tickets / sales questions the user uploads, and **AI fan-out queries** from your own panel runs where the engine API exposes them.
- **Procedure:** normalise, dedupe by embedding; tag each question with the SERP **answer surface** present (`snippet:paragraph|list|table|video`, `paa`, `aio`, `none`) and the current owner domain; store as `answer_targets`.
- **Outputs:** `keyword_candidates` (source=`question`), `answer_targets`.

### S7. Find AI-answer opportunities
- **Procedure:** for each topic cluster, check (a) AI Overview presence and cited URLs from SERP data, (b) latest panel results (section S23) for citation/mention rate with interval, (c) DataForSEO LLM Mentions `top_mentioned_pages/domains` for who is cited. Flag clusters where an answer surface exists and the site is absent or weak. Mark **citation-first** SERPs (AIO/snippet dominates).
- **Outputs:** `ai_opportunities(cluster_id, engines, cited_competitors[], site_rate, interval, evidence[])`.

### S8. Detect decay and diagnose
- **Purpose:** decide which existing pages need work and *why*. **This is the primary differentiator.**
- **Inputs:** `page_metrics_daily` (clicks, impressions, position, CTR from GSC; sessions/conversions from GA4), `metric_breakpoints`, panel data, SERP snapshots.
- **Detection rules (config):**
  - Compare last 28 days vs prior 28; validate with last 90 days vs same 90 days a year earlier (YoY removes seasonality).
  - Require a minimum baseline (`decay.min_baseline_clicks`, default 100) and a sustained decline (`decay.sustained_weeks`, default 8). Rank by **absolute clicks lost**.
  - Impressions are a leading indicator, **but** comparisons spanning a `metric_breakpoint` are "not comparable" for impressions and position: use clicks, or compare impressions only to post-break baselines. Never alert on a break-coincident drop without clicks-based confirmation.
- **Diagnosis (rules over metrics; an LLM may only explain, never decide):**

| Signature | Diagnosis | Default action |
|---|---|---|
| Position down; impressions flat/down | `ranking_decay` | refresh if near top 10 and sound; rewrite if below 10 or intent changed |
| Impressions + position stable; clicks down | `ctr_decay` | AEO work, title/meta test; accept baseline if structural |
| Impressions and clicks fall, position holds | `demand_decay` | leave alone |
| New queries rising, old fading | `query_drift` | rewrite to new intent |
| YoY pattern matches | `seasonality` | monitor |
| Sudden drop + technical change (noindex, canonical, redirect, template, CWV) | `technical` | fix, restore previous version first |
| Many pages drop near an update date | `sitewide` | no page-level refresh; investigate |
| Two URLs swap for same queries | `cannibalisation` | consolidate |
| Panel citation rate falls | `ai_citation_loss` | GEO refresh |

- **Outputs:** `page_diagnoses(page_id, type, confidence, evidence[], recommended_action, detected_at)`. Ambiguous → `needs_serp_check` (fetch live SERP to confirm).
- **Tests:** synthetic metric series for each signature; seasonality fixture must **not** flag; breakpoint fixture must not alert on impressions.

### S9. Page audit (findings)
For each page (or on demand) run the checks below. Every finding: `{type, severity, evidence, suggested_fix, effort_points, auto_fixable}`.

| Check | Method |
|---|---|
| Old dates | Compare visible date, JSON-LD dates, sitemap `lastmod`; age vs topic volatility |
| Outdated statistics | Re-run claim extraction (S14 logic) on the live page; re-verify time-sensitive claims (stat/date/price/version); verdict `outdated` when superseded; propose sourced replacement |
| Broken links | Status, soft-404, redirect chains; replacement via search |
| Outdated screenshots | Store capture date + source URL at creation; re-capture with Playwright and compare (pHash/SSIM); age flag for non-recapturable images |
| Missing sources | Claims without a linked primary source |
| Missing FAQs/unanswered questions | Questions (S6) not matched to any page passage by embedding similarity (`audit.question_match_threshold`) |
| Weak titles | Page CTR vs CTR model expectation at its position; propose tests (not assumptions) |
| Missing schema | Compare to the article-type blueprint |
| Cannibalisation | GSC query↔multiple URLs + embedding overlap + SERP flip-flop |
| Thin content | Entity/subtopic coverage vs SERP competitors (information gain), not word count alone |
| Outdated products/prices | Extract product/price entities; re-fetch **official** pricing pages/APIs (respect robots/terms; Playwright for dynamic pages); parse deterministically, cross-check with LLM; **any price change requires human confirmation**; store `price_observations` with `as_of`. If unfetchable → flag for manual check |
| Competitor changes | Re-run S11 in diff mode: new top-10 pages, entities, subtopics |
| AI-search position | Latest panel/AIO status |
| Other | Missing author/reviewer, alt text, CWV regression, orphan status |

### S10. Content plan and Opportunity Feed ("What should I publish?")
- **Purpose:** turn data into a ranked, explained list. Users do not manage keywords.
- **Candidate types (templates over real data, config-enabled per site):** "Best [category] for [audience]", "How much does [product] cost", "[A] vs [B]", "Is [product] worth it", "[Product] alternatives", "How to [task]", "What is [concept]", **update** items from S8/S9, **AI-answer** items from S7.
- **Scoring (all weights config):**
```
opportunity   = expected_clicks × business_fit × feasibility × recency_factor
expected_clicks = volume × CTR(target_position, serp_features)         # section 12.1
feasibility   = sigmoid((empirical_reach − KD) / k)                    # reach = median/p75 KD of keywords where site ranks top 10
business_fit  = w1·cos(keyword_emb, brand_emb) + w2·intent_weight + w3·manual_boost
display_score = percentile rank (0-100) within this site's candidate set  # NOT a prediction
```
- **Clustering:** SERP-overlap clustering on the shortlist (top ~200-500): keywords sharing ≥ `cluster.min_shared_urls` (default 3) top-10 URLs join one cluster = one page. Compare to existing URLs → action `new | update | consolidate`.
- **Impact range:** expected clicks × CTR-model uncertainty → show a range and confidence, never a point estimate.
- **Evidence-based explanation:** each item stores `evidence[] = {type, value, source, as_of}`. The UI explanation is **rendered from a template over these rows**; an LLM may rephrase but MUST NOT add facts. **Items without evidence MUST NOT be displayed.**

| Explanation line | Required evidence |
|---|---|
| "Existing page already ranks #N" | GSC avg position for mapped URL+query |
| "K competitors rank above you" | Dated SERP snapshot |
| "Search intent matches your product" | Intent classifier + business-profile match |
| "Existing article can be expanded" | S5/S11 gap output |
| "N related questions found" | S6 questions not answered by the page |
| "Strong internal-link opportunities" | Embedding matches (count + URLs) |
| "AI-answer opportunity detected" | S7 evidence (AIO present, site absent/low rate with interval, who is cited) |

- **Comparison/pricing topics:** product/price claims need verification with `as_of` dates and a human approver; flag for legal review where comparative-advertising rules apply.
- **User actions:** accept, snooze, reject-with-reason; reasons feed weights.
- **Update-portfolio prioritisation:**
```
recoverable_clicks = max(0, baseline_YoY_clicks − current_clicks) × recoverability(diagnosis)
priority = (recoverable_clicks × value_per_click + citation_gap_value + risk_reduction) / effort
```
Select the set maximising total priority within the user's `reviewer_hours_budget` ("these 12 fit your capacity this month"). `recoverability` starts from config priors (low for demand decay, higher for ranking decay) and is re-fitted from `update_outcomes`. Apply `decay.min_potential_clicks` filter (default ~20 monthly visits) unless the page has strategic value. Prefer page types that decay fastest and gain most (best-of, comparisons, pricing, stats-heavy).
- **Update Report (UI/API object):** `{page, last_updated, diagnosis(type, confidence), problems[], opportunities[], ai_visibility(rate, interval), recommendation, change_count, estimated_effort, impact_range}`; every number derives from stored findings.

### S11. SERP research and brief
- **Inputs:** plan item, business profile, style profile, S5/S6/S7 outputs.
- **Procedure:** SERP call for the primary keyword (top-10, features, PAA, related, AIO sources). Fetch top pages (robots-aware; **analysis only, never copying**) and extract H-tree, word count, entities, cited stats, media types, schema types. Gap analysis: table-stakes entities/subtopics (on most pages), differentiators (on few), unanswered questions. **Fan-out coverage:** LLM lists likely sub-questions an answer engine would research; brief must cover each. Insert the unique angle from S12. Choose article **blueprint** (S20 table). Record target answer surfaces per question.
- **Update runs (diff mode):** compare the existing page's document model to the new brief; output required additions/changes, not a new outline.
- **Output (`Brief`):** intent, reader, blueprint, required sections, required entities, answer-first questions with target surface/format, claims needing sources, internal-link candidates, schema plan, length *range*, visuals plan (candidate figures with justification).
- **Config:** `brief.max_competitor_pages=10`, `brief.length_range_policy`.
- **Tests:** brief schema validity; fan-out coverage check; no competitor text reproduced (similarity check).

### S12. Research sources and evidence pack
- **Procedure:** (a) **Original input collection** (G1): first-party data, customer example, expert quote/interview, screenshots/results; user uploads or connects a document store. If none → `NeedsHuman` (pause and ask) unless `evidence.waive_original=true` for refresh runs that add no new claims. (b) **Source research:** per planned claim/topic, search (Tavily/Exa/Brave) for primary sources first (government, standards bodies, peer-reviewed, official docs), then reputable media, then vendor blogs (tiers in config). Store `evidence(url, retrieved_at, excerpt≤25 words, passage_hash, tier, claim_ref)`. Do not store full copied pages.
- **Output (`EvidencePack`):** original inputs + sourced facts + source tiers.
- **Gate G1:** no drafting without original input (new articles).
- **Tests:** G1 blocks correctly; tier ordering respected; excerpt length limit enforced.

### S13. Generate the article (or the change set)
- **New article:** section-by-section drafting. Each section receives: its brief slice, its evidence, the style profile, and a running summary of prior sections (prevents repetition). Output is **structured** (`DocumentModel` blocks with flagged claim sentences and citation refs), never a raw blob.
- **Writer rules (enforced in the prompt and by lint):**
  - Use only facts present in the evidence pack. If a needed fact is missing, emit a `needs_source` marker, not a guess.
  - Evidence-forward style: sourced statistics, attributed quotations, and citations **where real facts exist** (E14). Never invent statistics or quotes to satisfy a rule.
  - Answer-first: each major section opens with a direct, self-contained answer.
  - Voice from the versioned `style_profile` (built from ≥10 approved articles plus 3-5 retrieved exemplars). Style updates require human approval.
  - No keyword stuffing; length is a range, not a target.
- **Critique loop:** critic checks brief coverage, repetition, vagueness, tone, fan-out coverage; revise; **max `loops.critique` (default 2)**.
- **Update runs:** generate a **ChangeSet**: list of `{id, type, location, before, after, sources[], claims[], reason}`. **Protect what works:** do not alter the URL, headings/passages that map to ranking queries, internal-link anchors, or the title unless the change is evidence-justified. Prefer small change sets.
- **Model roles:** writer = fast/cheap model; critic and verifier = a *different*, stronger model.
- **Tests:** schema validity; "no unsupported fact" lint on fixtures; protected-passage rule (update runs never delete a protected passage without an explicit justification).

### S14. Fact verification (claim-level)
Implemented as a LangGraph sub-graph. **It assists a human reviewer; it never replaces the human check (E2).**

1. **Claim extraction (Claimify-style):** *selection* (keep verifiable statements) → *disambiguation* → *decomposition* into atomic claims → *decontextualisation* (each claim stands alone). Output `Claim{text, kind(stat|date|quote|spec|causal|regulated|metadata|price), span, risk}`. **Titles, meta descriptions, schema values, captions and alt text are claim sources too.**
2. **Independent evidence retrieval:** query by claim, **not by the draft's wording**; ≥2 independent sources where possible; prefer primary sources; store `evidence` rows (URL, time, ≤25-word excerpt, passage hash).
3. **Deterministic checks first:** numbers, dates, names, units, currencies are string/number-matched against the cited passage in code *before* any LLM verdict.
4. **Verdict:** a different, stronger model returns `supported | contradicted | unsubstantiated | outdated` (`outdated` = once true, superseded) with confidence and the exact supporting span. **A verdict without a span is rejected.**
5. **Policy engine (plain code, config-driven):**
   - unsupported stat/quote/date/price → rewrite or remove;
   - `contradicted` → revise (max `loops.verify_revise`, default 2) then `NeedsHuman`;
   - `regulated` or `risk=high` → always requires a named qualified human approver (S21);
   - source trust by tier; two weak sources ≠ one strong source.
6. **VerificationReport** (append-only): claims, evidence, verdicts, residual risk, reviewer tasks. Shown in S21, exportable.
- **Security:** retrieved text is wrapped as untrusted data; web-reading nodes have no credentials or publish tools (section 11).
- **Metrics (eval-only):** precision/recall on the golden claim set (section 13).
- **Tests:** golden claims including numeric/date traps and "evidence silent" cases; a verdict without a span must fail validation.

### S15. SEO optimisation
- **Metadata:** title, meta description, slug, canonical from the brief (configurable length checks); all pass S14.
- **On-page lint (config):** one H1; heading depth ≤3; keyword in H1/intro naturally (no density targets); byline and updated date present; every statistic has a source; no unsourced superlatives; reading level within site target; banned "AI-sounding" phrase list (config).
- **Quality rubric:** score effort, originality, skill, accuracy (E4) with LLM + human; store; display only as an editorial aid.
- **Technical:** indexability (no accidental noindex), canonical correctness, `max-image-preview:large` directive for large previews, sitemap inclusion.

### S16. AEO / GEO optimisation
**AEO (answer surfaces)**
1. **Eligibility gate:** pursue a snippet only if the page already ranks near the top 10 (`aeo.min_position`, default 10) or can plausibly get there; otherwise action = SEO first.
2. **Format matching:** read the SERP's current snippet type; write the same: definition paragraph, `<ol>` steps, real `<table>`, or video with chapters.
3. **Answer block:** question-form heading → one **self-contained** direct answer → optional depth. Length targets (e.g. ~40-60 words paragraphs, 5-8 list items, small tables) are **config lint warnings**, not hard rules. Each answer block is verified in S14.
4. **FAQ module:** visible Q&A (2-4 sentences) from PAA + panel prompts. FAQPage markup is optional and tested (E5).
5. **Click-worthiness:** "answer + reason to click": include what a snippet cannot carry (data table, calculator, template, worked example, original data).
6. **Entity layer:** Organization and Person schema with `sameAs`; Google Business Profile for local; Wikidata only where notability genuinely exists; **never self-edit Wikipedia against conflict-of-interest rules**.
7. Voice-specific features: not built (thin evidence).

**GEO (citations)**
1. Evidence-rich content: real, sourced statistics, quotations, citations (E14).
2. **Crawler policy** (config per tenant; names verified in vendor docs): training bots, AI search bots, user-triggered fetchers, Googlebot. Build a **robots.txt auditor** (fetch, parse, per-bot verdict with matched rule); weekly alert on regressions; also check CDN/WAF rules and that main content is server-rendered.
3. **Citation-readiness checklist** (transparent, **not a predictor**): original fact present, sourced stats/quotes, answer-first blocks, valid schema, byline/dates, search bots allowed, ≥2 internal inbound links, third-party mention count.
4. Entity clarity: consistent brand/product/author names; About and "grounding" pages with dated, one-fact-per-sentence definitions; third-party corroboration plan (S23 improvement).
- **Hypotheses to test, not facts:** FAQ schema, answer-block length, list vs table, question-form headings, `llms.txt`.

### S17. Internal linking
- **Procedure:** embed the draft; match against the site's existing pages; propose 3-5 contextual outbound internal links with descriptive anchors (never "click here"); also propose inbound links *from* related posts to the new page (queued as suggested edits, human-approved). Avoid linking to pages with `noindex`/redirects; avoid cannibalising anchors.
- **External links ("where needed"):** link the **primary source** of each statistic/claim; the evidence URL from S14 *is* the link target (claim and link cannot drift). Heuristic volume ~3-8 outbound links per ~1,500 words (config). Attributes: `rel="sponsored"` for paid/affiliate, `ugc`/`nofollow` where untrusted; affiliate disclosure text; competitor sales pages only for genuine informational need. Pre- and post-publish checks: status 200, short redirects, no paywall mismatch; weekly link-rot monitor.
- **Tests:** anchors are descriptive; link target equals stored evidence URL; no self-links.

### S18. Schema (structured data)
- **Generate from typed builders** (never free-form LLM JSON): `Article`, `Person`, `Organization` (+`sameAs`), `BreadcrumbList`, `Product` where applicable; `ImageObject`; optional `FAQPage`/`HowTo` only if the visible page contains real FAQs/steps (E5).
- **Rules:** values MUST match visible content (including dates and authors). Validate with schema.org type checks and round-trip extraction (e.g. `extruct`); re-validate on the live URL post-publish.
- **Gate G4.**

### S19. Visuals: tables, diagrams, charts, screenshots, images
**Visual decision engine.** A planner proposes visuals per section and MUST justify each with "what this shows that text cannot." Defaults (all config):

| Situation | Component | Method |
|---|---|---|
| Compare ≥2 items on ≥2 attributes | HTML **table** | caption, `<thead>`, `scope`, source + "as of" date; never an image |
| ≥3 sequential steps | Numbered list | flow diagram only if branching/multi-actor |
| Architecture, relationships, hierarchy, timeline | **Diagram** | LLM writes Mermaid/D2/Graphviz source → validate → headless render → inline SVG with brand tokens, `<title>`/`<desc>`, `role="img"`; PNG copy for social |
| Numbers over time/categories **with real sourced data** | **Chart** | data table stored with source → Vega-Lite/Altair or Plotly → SVG/PNG; caption, source line, accessible data table in `<details>`; chart type chosen by rules (time→line, categories→bar, parts of whole only if few parts). **Reject if data cannot be sourced** |
| Software UI / on-screen procedure | **Real screenshot** | Playwright at fixed viewport, annotate (Pillow), redact personal data, store capture date + source URL |
| Concept/mood hero | Brand asset, stock, or **AI image** (optional, disclosed) | provider router (config); prompt from brand style guide; generate several candidates; vision rubric + human choice; record prompt/model/version; no baked-in text unless verified |
| Quote | Pull quote | only a real, attributed quote |
| Social/OG card | Templated HTML→PNG 1200×630 | deterministic, on-brand, no generative model |

- **Density guideline** (config, e.g. ~1 visual per 300-400 words); **no decorative filler**.
- **Hard prohibitions:** invented data/charts, fake screenshots/testimonials/people, real companies' logos or trademarks without permission, unverified text inside AI images (text in an image is a claim → S14).
- **Image delivery:** AVIF/WebP with fallback; `srcset`/`sizes`; explicit `width`/`height`; LCP image **never** lazy-loaded (eager, `fetchpriority="high"`); others lazy; descriptive file names; **alt text describes function/context, not keywords** (≈≤125 chars; `alt=""` if decorative); visible captions; `ImageObject` in schema. Alt text goes through S14/S21.
- **Provenance:** keep the **original** AI-image file (re-encoding can drop C2PA manifests), write IPTC `DigitalSourceType`, set a disclosure flag.
- **Gate G5:** deterministic checks (min font size, overflow, contrast) + vision-model critique; the human sees renders in S21.

### S20. Assemble, render, quality gates
- **Document model** (single source of truth): blocks `heading, paragraph, answer_block, key_takeaways, list, table, figure(diagram|chart|image|screenshot), callout, quote, code, faq, references, cta, author_box`; each block has `claims[]`, `sources[]`; figures have `alt`, `caption`, `credit`, `provenance`. Verification and lint run on the model; **renderers** output semantic HTML, Markdown/MDX, WordPress blocks, or CMS-specific fields.
- **Blueprints (config per site):**

| Type | Required | Typical extras |
|---|---|---|
| How-to | answer-first intro, key takeaways, numbered steps, screenshots for software, FAQ | flow diagram, troubleshooting table |
| Comparison | verdict first, comparison table, criteria, sources | pros/cons callouts, pricing table with "last checked" |
| Definition | definition answer block, why it matters, example | concept diagram, glossary links |
| Roundup | selection criteria, consistent per-item structure, summary table | affiliate disclosure |
| Data study | methodology, real-data charts, downloadable dataset, limitations | embeddable chart |
| Case study | real customer, real numbers (permission), timeline | before/after chart |
| Pillar guide | TOC, section answer blocks, link hub | diagrams, glossary, FAQ |

- **Professional layout checklist:** H1; byline with photo → author page; optional "reviewed by"; published and **updated** dates; reading time; key takeaways near top; TOC with jump links for long posts; answer-first intro; question-form H2/H3 where the query is a question; captions; callouts; FAQ; references; one relevant CTA; related reading.
- **Gate G6 (pre-human):** `axe-core` via Playwright (WCAG 2.2 AA target); table header/scope; contrast; Lighthouse CI lab run (CLS/LCP regressions); schema validation; link check; spelling; render at 3 viewports → screenshots → vision-model layout review (overflow, overlap, empty images). Any failure blocks and creates a task.

### S21. Human review (the central control point)
- **Review screen:** rendered preview at 3 viewports; diff (for updates, per-change accept/reject); claim list with evidence passages; metadata/alt-text panel; schema preview; citation-readiness checklist; visual QA results.
- **Forced confirmation:** the reviewer MUST tick every `risk=high` claim and every statistic/price/date before the Approve button enables. Regulated topics need a named qualified expert. 
- **Sampled re-audit:** a second person re-checks a random `review.audit_sample_pct` (default 10%); disagreement rate is a tracked quality metric.
- **Attestation (append-only):** `{reviewer_id, role, time, document_version_hash, checklist_state, disclosure_choice}`. Optional public "reviewed by" byline (also supports the EU Art. 50 editorial-responsibility exemption; E25).
- **Channels:** web UI primary; Slack optional for notifications and low-risk approvals (Slack interactions are poorly auditable).
- **Gate G7.** Rejection → revise (returns to S13 with reasons) or abandon with reason.

### S22. Publish (mode-controlled) and post-publish checks
- **Pipeline:** stage in CMS as draft → upload media (dedupe by hash; set alt, caption, credit) → set metadata (title, meta, slug, canonical, OG/Twitter, JSON-LD, categories/tags, author, scheduled time) → preview URL → publish/schedule → **post-publish checks** → register tracking. All steps idempotent (dedupe key) and reversible (unpublish/revert; keep revisions).
- **CMS adapters** (verify current API versions): WordPress REST (`/wp/v2/media`, `/wp/v2/posts` with `draft`/`future`; SEO-plugin fields via their REST support or a small companion plugin); Webflow Data API v2; Shopify Admin API (blog articles); Ghost Admin API; headless option = Git PR with Markdown/MDX + images.
- **Publish modes (per site config `publish.mode`):**

| Mode | Unattended work | Conditions | Default |
|---|---|---|---|
| **1. Automated publish after approval** | stage, upload, schedule, publish, checks | all gates pass and an attestation exists | **ON** |
| **2. Low-risk refresh autopilot** | small updates to approved pages | no new/changed factual claims, or every changed claim `supported` by ≥2 sources; no regulated topics; edit size < threshold; prior version human-approved; random sample audited | OFF |
| **3. Unattended new-article autopilot** | whole lifecycle | tenant opt-in, counsel sign-off, topic allow-list excluding regulated/YMYL, strict velocity caps, disclosure settings, human audit within 24-48h with auto-unpublish on failure | **OFF, not recommended** |

Mode 3 stays off by default because of E2/E3/E25. Never market it.
- **Dates (E6):** keep `datePublished`; change visible date and `dateModified` only for a **significant** update, and use the same value in the page, JSON-LD and sitemap `lastmod`. Optional visible "What changed" note.
- **Post-publish checks (Gate G8):** fetch the live URL; diff rendered DOM vs intended document (headings, images, alt, tables, links); validate JSON-LD live; confirm indexability and canonical; sitemap inclusion; IndexNow ping (Bing et al.); selective URL Inspection; re-run link and accessibility checks; register for rank/snippet/panel/GSC tracking; schedule 7/28/90-day reviews. Mismatch → rollback or task.
- **Safety controls:** per-site pause; **auto-pause** on anomalies (verification-failure spike, indexing failures, traffic drop beyond threshold, a flagged Google update window); per-site velocity caps with ramp-up; weekly sampled audit of live pages.
- **Consolidate flow:** choose winning URL → merge best content → 301 the others → update internal links → resubmit sitemap → monitor. **Prune** (410/noindex) only with explicit human approval.

### S23. Measure
- **GSC (nightly):** clicks, impressions, CTR, position by page/query/date into own tables (paginate `startRow`); enable BigQuery bulk export; maintain `metric_breakpoints`. **Generative AI report** into `gsc_ai_impressions` (API if available, else CSV import). **URL Inspection** selectively for new/changed URLs within quota.
- **GA4:** engaged sessions, key events, conversions by landing page and channel; custom channel group for AI referrers (chatgpt.com, perplexity.ai, gemini.google.com, copilot.microsoft.com, claude.ai; list in config).
- **Rank and SERP tracking (weekly):** DataForSEO SERP for tracked keywords with fixed location/device; record snippet owner, PAA presence, AIO sources → `answer_targets` history.
- **AI-citation panel** (below). **Server/CDN logs:** classify AI crawler user agents per URL (crawl ≠ citation).
- **Technical audit (weekly):** crawl; status, canonicals (raw vs rendered), accidental noindex, sitemap vs link graph (orphans), hreflang, broken links, main content without JS, schema validity, AI-bot access; **CWV via PageSpeed Insights + CrUX API** (field data first, lab as diagnostics).
- **Per-article scorecard:** indexed?, impressions, clicks, position trend, AI impressions (GSC), AI citation rate (interval), conversions, cost to produce, verification score, reviewer edit distance.

**AI-citation panel (design is mandatory, not optional):**
- **Tier 1 (own panel, official APIs):** one adapter per engine returning a normalised `PanelRecord{run_id, engine, model_version, country, prompt_id, cluster_id, paraphrase_id, sample_no, answer_text, cited_urls[], cited_domains[], fanout_queries[]?, mentions_brand, citation_position, sentiment, cost, ts}`. OpenAI Responses + `web_search` (`url_citation`); Perplexity Sonar; Gemini + Grounding with Google Search (**resolve redirect URIs to publisher URLs**); Claude Messages + web search tool. Each adapter has recorded-fixture contract tests.
- **Unit = intent cluster:** 5-10 human-approved paraphrases + a **held-out probe set** never used for optimisation.
- **Runs:** paraphrase × engine × `panel.reruns` (default 3), weekly, spread across days; ≥4 weeks before declaring a baseline.
- **Report:** branded vs unbranded separately (unbranded is the KPI); mention vs citation; domain-level and URL-level; **rates with bootstrap/Wilson 95% intervals**; estimate a **noise floor** from reruns; flag a change only if intervals separate across two consecutive cycles; track **citation half-life**.
- **Fixed conditions:** record country, language, model version, logged-out. **Calibrate** against DataForSEO LLM Scraper on 30 prompts; never claim the API panel equals consumer behaviour.
- **Tier 2:** DataForSEO LLM Responses (multi-engine), LLM Scraper, LLM Mentions (`search_mentions`, `target_metrics`, `top_mentioned_pages/domains`), AI Keyword Data. **Tier 3:** SERP AI Overview parsing, GSC Generative AI report, GA4 AI referrals, server logs.
- **Prompt set:** generated per site from keywords-as-questions, PAA, AI keyword data, customer/support questions, competitor comparisons; human-approved; 30-100 prompts per site; stored in `tracked_prompts` with tags.
- Do NOT scrape consumer chat UIs.

### S24. Improve / update (the loop)
1. **Triggers & cadence:** daily GSC sync; weekly broken-link/technical checks; weekly price checks on pages with prices; event triggers (clicks down beyond threshold for consecutive weeks, a Google update window, a new competitor page, a product change); full portfolio audit monthly/quarterly. Show an **update calendar**.
2. **Citation-gap loop:** weekly panel → low-rate clusters → who is cited instead (panel + DataForSEO) → analyse those pages (S11) → create a task: refresh page / publish original data / off-site asset → review → publish → re-measure with intervals.
3. **Off-site presence engine:** rank non-owned domains cited per cluster; generate an **earned-presence plan** (community threads to join, video scripts with chapters and transcripts, LinkedIn posts, review-profile updates, partner pages, original-data studies). **Hard rules:** no fake accounts, no astroturfing, no automated posting to communities, no self-editing Wikipedia against COI rules. The tool drafts and tracks; **humans publish**.
4. **Experiments:** every update is tagged with its change types; hold out matched similar pages when the portfolio is large enough; compare at 7/28/90 days using difference-in-differences with intervals; log in `experiments` and `update_outcomes`; if metrics fall beyond the noise floor, propose a revert. Say "inconclusive" when samples are small. Evaluate **update types** (stat refresh, new sections, title rewrite, schema fix, consolidation, image changes), **AEO tactics** (answer-block length, list vs paragraph vs table), **GEO tactics** (stats/quotes/citations, FAQ schema), and **visual components** (diagram/table vs none).
5. **Learning:** re-fit `recoverability`, CTR model, empirical reach, and change-type weights from outcomes; write learnings to per-site memory as **proposals a human approves**.
- **Update execution ([Update Article]):** load current document model → generate ChangeSet (S13) → verify (S14) → S15-S19 on the change set only → S20 render diff → S21 per-change accept/reject → publish as a revision (S22, keep history for rollback). Low-risk change types (link fixes, verified sources, alt text) MAY use Mode 2.
- **Expectations (E24):** default impact ranges are wide and conservative; marketing says "documented, measured lift per client against matched pages", never a headline percentage. **Never do date-only refreshes.**

---

## 7. Data model (logical; implement with SQLAlchemy + Alembic)

All tables include `id (ULID)`, `tenant_id`, `created_at`, `updated_at`; site-scoped tables include `site_id`. **Append-only** tables are marked (A).

| Group | Tables (key columns) |
|---|---|
| Tenancy/auth | `tenants`, `users`, `memberships(role: admin/editor/reviewer/viewer, site scope)`, `api_keys` |
| Sites/config | `sites(domain, locale, cms_type)`, `integrations(type, encrypted_token, status)`, `site_config(version, yaml)`, `authors`, `brand_kits`, `business_profiles(version)`, `style_profiles(version)`, `competitors(domain, type, confirmed)` |
| Inventory | `pages(url, status, canonical, indexable, content_type, current_version_id)`, `page_versions(raw_html_ref, document_json, hash)`, `page_links(from,to,anchor,rel)`, `page_images(url, alt, captured_at, source_url)`, `page_queries(page_id, query)` |
| Keywords/plan | `keyword_candidates(source, volume, kd, intent, cpc, serp_features)`, `keyword_metrics_snapshots(date)`, `clusters`, `cluster_members`, `answer_targets(keyword, surface, format, owner_domain, our_url, our_position, first_seen, lost_at)`, `content_plan_items(action, score_display, impact_low, impact_high, status, rejected_reason)`, `plan_evidence(item_id, type, value, source, as_of)`, `ctr_models(version, params)` |
| Runs | `runs(run_type, status, state_ref)`, `run_steps(stage, status, idem_key, started, ended, error)`, `cost_ledger(run_id, provider, endpoint, micro_cost, tokens)` (A) |
| Content | `articles`, `article_versions(document_json, hash, status)`, `briefs`, `evidence(url, retrieved_at, excerpt, passage_hash, tier)`, `claims(kind, risk, span, text)`, `verdicts(claim_id, label, confidence, span, model_version)` , `verification_reports` (A), `change_sets`, `change_items(status: pending/accepted/rejected)`, `visual_assets(kind, source_data_ref, alt, provenance, original_ref)` |
| Governance | `approvals` (A) `(reviewer_id, role, document_hash, checklist_state, time)`, `audit_log` (A), `publications(cms_id, url, mode, published_at, rollback_ref)`, `disclosure_settings` |
| Measurement | `page_metrics_daily(date, clicks, impressions, position, ctr, sessions, conversions)`, `metric_breakpoints(date, affected_metrics, scope, note, source)`, `gsc_ai_impressions`, `tracked_keywords`, `serp_snapshots`, `tracked_prompts(cluster_id, paraphrase, tags)`, `panel_runs` (A), `panel_records` (A), `crawler_hits(ua_class, url, ts)`, `cwv_snapshots` |
| Updates | `page_diagnoses`, `page_findings`, `update_plans`, `update_outcomes`, `experiments(hypothesis, change_types, treated[], controls[], window, result)`, `product_entities`, `price_observations(as_of)` (A), `screenshots(phash, captured_at)` |

**Rules:** large text/HTML/images go to object storage with references in tables; embeddings in pgvector columns; every table read goes through a repository that injects `tenant_id`.

---

## 8. Configuration schema (`config/defaults.yaml`; override per tenant/site)

```yaml
business:   {regulated_topics: [health, legal, financial], never_say: []}
crawl:      {max_pages: 5000, rate_per_host: 1.0, respect_robots: true, user_agent: "ContentAgentBot"}
keywords:   {location: US, language: en, question_words: [what, how, why, when, which, can, is, does]}
cluster:    {min_shared_urls: 3, shortlist_size: 300}
scoring:    {w_fit: 1.0, w_intent: 0.5, w_manual: 0.2, sigmoid_k: 12, min_business_fit: 0.35}
ctr_model:  {prior: default_public_curve, min_samples_to_fit: 500, features: [position, has_aio, has_snippet]}
decay:      {window_days: 28, yoy_days: 90, min_baseline_clicks: 100, sustained_weeks: 8,
             min_potential_clicks: 20, recoverability_priors: {ranking_decay: 0.5, query_drift: 0.4, ctr_decay: 0.2, demand_decay: 0.0}}
audit:      {question_match_threshold: 0.78, cannibalisation_overlap: 0.6, price_recheck_days: 7, screenshot_ssim_min: 0.92}
brief:      {max_competitor_pages: 10, length_range_policy: serp_median_pm_30pct}
loops:      {critique: 2, verify_revise: 2}
evidence:   {waive_original: false, source_tiers: {primary: 1, media: 2, vendor: 3}, max_excerpt_words: 25, min_sources_per_stat: 2}
aeo:        {min_position: 10, paragraph_words: [40, 60], list_items: [5, 8], faq_schema: false}
links:      {outbound_per_1500_words: [3, 8], rel_default: ""}
visuals:    {density_words_per_visual: 350, ai_images: optional, og_card: true, image_formats: [avif, webp]}
lint:       {banned_phrases: [], heading_max_depth: 3, reading_level_target: null}
review:     {audit_sample_pct: 10, require_named_expert_for: [regulated]}
publish:    {mode: 1, velocity: {per_day: 1, per_week: 5, ramp_up_weeks: 4}, auto_pause: {traffic_drop_pct: 25}}
panel:      {reruns: 3, paraphrases_per_cluster: [5, 10], engines: [openai, perplexity, gemini, claude], cadence: weekly}
bots:       {allow_search: true, allow_training: false, names: {}}   # names verified against vendor docs
disclosure: {label_enabled: false, text: "", placement: top}
budgets:    {monthly_micro: 0, per_run_micro: 0}
models:     {writer: {...}, critic: {...}, verifier: {...}, vision_qa: {...}, embed: {...}, image: {...}}
```
Values shown are shipped defaults only; code MUST read them from config (P2).

---

## 9. API surface (REST, versioned `/v1`; OpenAPI; webhooks for run events)

| Area | Endpoints (representative) |
|---|---|
| Auth/tenancy | `POST /auth/oidc/callback`, `GET /me`, `GET/POST /sites` |
| Integrations | `POST /sites/{id}/integrations/{gsc|ga4|cms}/connect`, `GET …/status` |
| Onboarding | `POST /sites/{id}/onboard`, `GET/PUT /sites/{id}/business-profile` |
| Inventory | `GET /sites/{id}/pages`, `GET /pages/{id}`, `GET /pages/{id}/metrics` |
| Competitors/gaps | `GET/PUT /sites/{id}/competitors`, `GET /sites/{id}/gaps` |
| Feed | `GET /sites/{id}/opportunities`, `POST /opportunities/{id}/accept|snooze|reject` |
| Decay/updates | `GET /sites/{id}/decay`, `GET /pages/{id}/update-report`, `POST /pages/{id}/update` |
| Runs | `POST /runs`, `GET /runs/{id}`, `POST /runs/{id}/resume`, `POST /runs/{id}/cancel` |
| Review | `GET /runs/{id}/review`, `POST /runs/{id}/review/confirm-claim`, `POST /runs/{id}/approve|reject`, `PATCH /change-items/{id}` |
| Publish | `GET /articles/{id}/preview`, `POST /articles/{id}/publish`, `POST /publications/{id}/rollback` |
| Measurement | `GET /sites/{id}/scorecards`, `GET /sites/{id}/visibility` (rankings, snippets, AI impressions, panel rates + intervals) |
| Prompts/panel | `GET/POST /sites/{id}/prompt-clusters`, `GET /sites/{id}/panel/results` |
| Experiments | `GET /sites/{id}/experiments` |
| Settings | `GET/PUT /sites/{id}/config`, `GET/PUT /sites/{id}/bot-policy`, `GET/PUT /sites/{id}/publish-mode` |
| Webhooks | `run.needs_human`, `run.approved`, `publication.created`, `finding.created`, `decay.detected` |

All endpoints enforce tenant/site authorisation and write `audit_log` for state changes.

---

## 10. Prompts and model routing

### 10.1 Prompt files
`prompts/<stage>/<name>.v<N>.jinja` plus `manifest.yaml` (id, version, input schema, output schema, model role, temperature, owner). Every run records the prompt versions it used. **Prompts MUST NOT embed thresholds, brand facts, or site data**: inject them from config/state.

### 10.2 Prompt contract (required in every prompt)
1. Role and single task. 2. Inputs wrapped in delimiters; **retrieved/web text labelled untrusted data**. 3. Output **JSON schema** (use provider structured-output). 4. Rules: use only provided evidence; emit `needs_source` instead of guessing; never fabricate quotes, numbers, URLs. 5. Refusal/escape: return `{"error":"insufficient_evidence"}` when needed.

### 10.3 Prompts to create (minimum set)
`s02/business_profile`, `s06/question_normalise`, `s07/ai_gap_explain` (phrasing only), `s09/outdated_claim_replace`, `s10/explain_phrase` (phrasing only), `s11/gap_analysis`, `s11/fanout_questions`, `s13/section_writer`, `s13/critic`, `s13/changeset_writer`, `s14/claim_extract`, `s14/verdict`, `s16/answer_block`, `s16/faq`, `s19/visual_planner`, `s19/diagram_source`, `s19/alt_text`, `s19/vision_qa`, `s20/block_classifier` (HTML→blocks), `s23/paraphrase_generator`, `s23/sentiment`, `s24/earned_presence_plan`.

### 10.4 Model routing
- Roles in config: `writer`, `critic`, `verifier` (**must differ from writer**), `vision_qa`, `embed`, `image`. Router provides fallbacks, timeouts, cost ledger writes, and budget enforcement.
- Cheap/fast models for drafting and classification are fine **only if they pass the eval gate** (section 13); verification and critique use a stronger model.
- Temperature: low for extraction/verification/schema; moderate for drafting; zero where determinism is required.
- Model names, prices, and provider behaviours change often: never hardcode; run quarterly bake-offs on your golden sets.

---

## 11. Security, privacy, compliance (cross-cutting)

- **Prompt injection:** all web/uploaded text is untrusted. Strip HTML scripts/hidden text; wrap in delimiters; instruct models to ignore embedded instructions; verification/research nodes have **no** publish tools or credentials; outputs are schema-validated.
- **SSRF:** every URL fetch passes an allow-check that blocks private/internal IP ranges, link-local, metadata endpoints, and non-HTTP schemes; follow redirects with re-check.
- **Secrets:** per-tenant OAuth and CMS tokens encrypted at rest (KMS/Fernet, rotation); never in logs, graph state, or prompts.
- **Output sanitisation** before CMS publish (strip scripts, unsafe attributes).
- **Copyright:** store URLs and ≤25-word excerpts, not copied pages; similarity check of drafts against sources and SERP competitors; never reproduce competitor text.
- **Privacy:** GSC/GA data is customer data; retention policy; export/delete per tenant; DPA template; GDPR-ready consent for OAuth.
- **Platform terms:** respect robots.txt and API ToS; no scraping consumer chat UIs; DataForSEO or official APIs for AI-result data.
- **EU AI Act Art. 50 and disclosures (E25):** per-tenant disclosure settings (label text, placement); topic classifier flags public-interest content; reviewer attestations evidence the editorial-responsibility exemption; counsel decides whether you are a "provider."
- **AI images:** provenance flag, IPTC `DigitalSourceType`, original retained.
- **Auditability:** immutable approvals/verification/audit tables.

---

## 12. Formulas and statistics (implement exactly; parameters from config)

### 12.1 CTR model
`CTR(position, has_aio, has_snippet, …)` fitted from the site's GSC data joined to dated SERP snapshots, with a hierarchical prior from public curves until `ctr_model.min_samples_to_fit`. Never hardcode a single AIO CTR number (studies disagree, E18). Expose model uncertainty for impact ranges.

### 12.2 Empirical reach (feasibility)
From the site's own `ranked_keywords`: median and 75th-percentile KD of keywords ranking 1-10 → `empirical_reach`. Recompute monthly. New sites: low-KD long-tail first.

### 12.3 Opportunity and priority
As in S10. Display score = percentile rank within the site's candidate set; always show components and confidence.

### 12.4 Decay and recoverability
As in S8/S10. `recoverability(diagnosis)` re-fitted from `update_outcomes` (e.g. mean matched-control-adjusted recovery by diagnosis × change type), with shrinkage toward the config prior when n is small.

### 12.5 Panel statistics
Rate = cited samples / total samples per (cluster × engine). Interval: Wilson for single proportions; **cluster bootstrap** (resample paraphrases, then runs) for cluster-level intervals. Noise floor = interval width from rerun variance on stable prompts. A change is "real" only if intervals separate for two consecutive cycles.

### 12.6 Update experiments
Matched pairs: nearest-neighbour matching on baseline clicks, page type, age, position band. Effect = difference-in-differences of log(clicks+1) between treated and matched controls over the window (7/28/90 days), with bootstrap intervals. Require a minimum number of pairs (config) to report an effect; otherwise "inconclusive."

---

## 13. Testing and evaluation

### 13.1 Test layers
| Layer | What | Rule |
|---|---|---|
| Unit | pure logic (scoring, decay rules, policy engine, formulas, linters) | no network |
| Contract | each external API adapter against recorded fixtures (VCR-style) | recordings refreshed on a schedule; failures flag API drift |
| Golden | labelled data (below) | run in CI on a small subset; full set nightly |
| Property | schema/renderer invariants (e.g. every figure has alt + caption; every stat has a source) | |
| E2E | fake CMS + mocked providers: onboard → feed → update → review → publish → measure | runs in CI |
| Security | SSRF blocklist, tenant isolation, injection fixtures | |

### 13.2 Golden sets (build early)
- ~200 labelled **claims** (supported/contradicted/unsubstantiated/outdated), incl. numeric/date traps and "evidence silent" cases.
- ~30 **pages** hand-labelled with decay diagnoses (include seasonality and breakpoint cases).
- ~50 **briefs** with human-rated drafts.
- ~30 **prompts** per engine with hand-checked citation parsing (catches Gemini redirect and annotation bugs).
- ~20 **articles** for visual acceptance (diagram/chart/table correctness).

### 13.3 Acceptance metrics (milestone gates)
Verifier precision/recall on contradicted/unsubstantiated/outdated claims **measured and recorded** (set targets via ADR after the first measurement; do not claim a number you haven't measured); diagnosis precision on the 30-page set ≥ agreed target; schema validity 100% on publish; zero publishes without attestation; reviewer edit distance and time-to-approve tracked; ≥80% of generated visuals accepted without redo on a 20-article sample; 20 consecutive publishes with no unnoticed rendering defects; panel rates reported only with intervals.

### 13.4 CI
`ruff` → `mypy` → unit/contract/property → eval-smoke (small golden subset) → build image → security scans (dependency, secret, image) → push. Prompt/model changes MUST run the eval subset and block on regression beyond thresholds.

---

## 14. Enterprise and deployment (build last, after features work)

Prerequisite: features run behind repository and scheduler interfaces (section 4.1).

1. **Data:** Postgres + Alembic; `AsyncPostgresSaver` for LangGraph (persistent checkpointer required for `interrupt()`); pgvector; row-level security or enforced repository filters; **tenant-isolation tests**; backups with tested restore.
2. **Queue/scheduler:** Redis + ARQ/Celery; scheduled tasks replace in-process APScheduler; idempotent jobs; separate **crawler/monitor workers** (links, prices, screenshots, robots/bot policy) from the writing queue; queue priorities so rendering never blocks publishing.
3. **Cache and cost control:** Redis cache with per-endpoint TTLs (keyword/KD: days-weeks; SERP: hours-days per location/device; page fetches: hours; **panel answers never cached**); cache key = normalised request hash; per-tenant monthly and per-run budgets; `cost_ledger` for every external call; hard stop + alert on breach; per-provider rate limits and backoff; circuit breakers and model fallbacks; bulk endpoints; shortlist before SERP calls; record/replay fixtures so tests never hit paid APIs.
4. **Containers and CI/CD:** multi-stage non-root Docker; compose for app, worker, scheduler, crawler, Postgres, Redis; lockfile; Dependabot; `pip-audit`; secret scanning; dev/staging/prod with separate keys; migrations as a release step; health/readiness endpoints. Skip Kubernetes until load requires it.
5. **Media/rendering infra:** sandboxed Playwright/Chromium workers (no internal-network access); pinned mermaid-cli/D2/Graphviz; S3-compatible object storage + CDN with signed uploads; image workers (AVIF/WebP, srcset); render and AI-image costs in the ledger.
6. **Auth/RBAC:** OIDC (Auth0/Clerk/Keycloak); roles Admin/Editor/Reviewer/Viewer scoped per site; immutable audit log.
7. **Observability:** OpenTelemetry traces per run step; structured JSON logs; Sentry; Langfuse/LangSmith; metrics (queue depth, failure/stuck rates, cost per run); alerts for stuck runs, verifier-failure spikes, GSC sync gaps, bot-policy regressions, budget breaches.
8. **Reliability:** timeouts, retries with backoff, typed `NeedsHuman` exits, graceful degradation (e.g., skip a visual, never skip verification).
9. **Compliance operations:** data export/delete, retention, DPA; SOC 2 later (your audit log and CI evidence are its raw material).

---

## 15. Build order (milestones with Definition of Done)

Do not start a milestone before its predecessor is done. Write an ADR for any deviation.

| M | Weeks (est.) | Build | Done when |
|---|---|---|---|
| **M0** | 1 | Repo audit (section 2), clean clone runs, lockfile, CI, repository layer, spikes (3.4) | CI green; `docs/repo_audit.md` and spike ADRs exist |
| **M1** | 2-4 | S1 onboarding, S2 profile, S3 crawler/inventory, GSC/GA4 sync + `metric_breakpoints`, HTML→document model | A real site shows full inventory with per-page metrics |
| **M2** | 4-7 | S8 decay diagnosis, S9 audit checks | Diagnosis precision measured on 30 labelled pages; seasonality and breakpoint tests pass |
| **M3** | 6-9 | S14 verification (incl. `outdated`), policy engine, S21 review UI with forced confirmations and attestations | Verifier precision/recall measured; attestations stored |
| **M4** | 8-10 | S4-S7 inputs, S10 feed with evidence explanations and impact ranges | Every feed item shows real evidence; users can accept/reject with reasons |
| **M5** | 10-14 | Update Agent: Update Report, ChangeSet diff, protected passages, date rules, revision publish, rollback | 10 real updates published; zero unreviewed changes |
| **M6** | 14-18 | Studio: document model renderers, tables/lists/answer blocks, links engine, S15-S19, G3-G6 | Staged drafts pass axe, Lighthouse, link checks on 3 viewports |
| **M7** | 18-19 | S22 CMS adapters (start with 1-2), Mode 1, live-page diff, rollback | 20 posts published, no unnoticed defects |
| **M8** | 19-21 | S11-S13 new-article pipeline, G1 | Reviewer edit distance measured on 10 articles |
| **M9** | 21-24 | S23 panel (4 adapters, clusters, intervals, DataForSEO tier), GA4 AI channel, logs, technical audit | Cluster citation rate with interval per engine |
| **M10** | 24-26 | S24 experiments, off-site plans, `recoverability` re-fit | ≥5 documented experiments with intervals |
| **M11** | 26-27 | Compliance (disclosures, attestations), UI polish | Counsel-reviewed terms; design partner approves in-app |
| **M12** | 27-30 | Section 14 enterprise/deployment | Staging deploy from CI; isolation tests pass |
| **M13** | 30+ | Beta with 3-5 design partners; 60-90 day measurement | Publish real, matched-control before/after numbers |

Design partners can be onboarded after M5 (about week 14) because M1-M5 depend only on existing client content.

---

## 16. Behavioural rules for the coding agent (checklist)

**DO**
- Audit the repo first and map it to this flow; keep what works.
- Build typed contracts, config-driven behaviour, tests, and cost logging.
- Prefer deterministic code for decisions (diagnosis, policy, gates); use LLMs for extraction, drafting, phrasing, and critique within schema.
- Keep humans in the loop at S21; keep modes 2-3 off unless configured.
- Record unknowns as spikes and ADRs.
- Show intervals and `as_of` dates in the UI.

**DO NOT**
- Hardcode thresholds, prompts, model names, bot lists, or prices.
- Fabricate data, sources, quotes, screenshots, testimonials, logos, or statistics, even as placeholders in production paths.
- Let an LLM decide a gate outcome or a decay diagnosis by itself.
- Publish, or mark content approved, without an attestation.
- Change dates without a significant update; do date-only refreshes.
- Scrape consumer chat UIs, create fake accounts, or automate community posting.
- Reproduce competitor text; store full copied pages.
- Report single-run AI-citation outcomes or uplift without controls and intervals.
- Weaken a gate to make a test pass.
- Promise rankings, citations, or "zero hallucinations" in any copy.

**WHEN UNSURE:** choose more human review and less automation, log the question in `docs/open_questions.md`, continue with the safest default.

---

## 17. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Scaled-content penalties (E1-E3) | G1 evidence pack, velocity caps, similarity checks, human attestation, refresh-first strategy, auto-pause |
| Verifier errors | Different stronger model; deterministic checks; measured accuracy; forced human confirmation |
| Noisy AI-citation data (E15) | Intent clusters, paraphrases, reruns, intervals, calibration vs scraper data |
| Decay false positives | YoY validation, diagnosis rules, "leave alone" outcome, breakpoints |
| Updates that lose rankings | Protected passages, small change sets, human diff review, rollback, outcome tracking |
| Fake freshness | Significance rule; consistent dates |
| Wrong product/price claims | Official sources, deterministic parsing, human confirmation, `as_of` |
| Visual defects | Deterministic checks, vision QA, human preview, ban on unsourced data |
| Shifting platform behaviour | Adapters with contract tests, config-driven bot lists, quarterly re-verification |
| Regulatory change (E25) | Counsel, disclosure settings, attestation records |
| API cost growth | Shortlisting, cache, budgets, ledger |
| Pressure to run unattended | Mode 3 off; sell automated mechanics with human-approved content |
| Over-promising | Claims policy in section 1 |

---

## Appendix A: Environment variables (names only; never commit values)
`DATABASE_URL`, `REDIS_URL`, `OBJECT_STORE_URL`, `OBJECT_STORE_KEY`, `ENCRYPTION_KEY`, `GOOGLE_OAUTH_CLIENT_ID`, `GOOGLE_OAUTH_CLIENT_SECRET`, `DATAFORSEO_LOGIN`, `DATAFORSEO_PASSWORD`, `TAVILY_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `PERPLEXITY_API_KEY`, `IMAGE_PROVIDER_KEYS` (per provider), `SLACK_BOT_TOKEN` (optional), `SENTRY_DSN`, `LANGFUSE_KEYS` (optional), `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`.

## Appendix B: Core contract examples (shapes, not exhaustive)

```json
// Claim
{"id":"c_01","text":"Plan pricing starts at $24 per seat as of 2026-10-03.","kind":"price",
 "span":[1280,1334],"risk":"high","source_block":"b_17"}

// Verdict
{"claim_id":"c_01","label":"supported","confidence":0.93,
 "evidence":[{"url":"https://vendor.example/pricing","retrieved_at":"2026-10-03T09:12:00Z",
   "excerpt":"From $24 per seat per month","passage_hash":"sha256:…","tier":"primary"}],
 "model_version":"verifier@2026-09","deterministic_checks":{"number_match":true}}

// OpportunityItem
{"id":"o_91","action":"update","target":"best-crm-software-small-business","display_score":87,
 "impact":{"low":120,"high":410,"unit":"clicks/month","confidence":"low"},
 "evidence":[{"type":"gsc_position","value":17,"source":"gsc","as_of":"2026-10-01"},
             {"type":"serp_competitors_above","value":4,"source":"serp_snapshot","as_of":"2026-10-02"}],
 "flags":{"seo":true,"aeo":true,"geo":true}}

// ChangeItem
{"id":"ch_07","type":"replace_stat","location":"b_12","before":"Market grew 8% in 2022",
 "after":"Market grew 12% in 2025","sources":["ev_88"],"claims":["c_22"],
 "reason":"claim outdated; newer source","protected":false,"status":"pending"}

// UpdateReport
{"page":"/best-crm-software-small-business","last_updated":"2025-08-12",
 "diagnosis":{"type":"ranking_decay","confidence":"medium"},
 "problems":[{"type":"outdated_stats","count":7},{"type":"price_changes","count":3}],
 "opportunities":[{"type":"new_competitors","count":4},{"type":"unanswered_questions","count":11}],
 "ai_visibility":{"rate":0.07,"interval":[0.01,0.30],"samples":15},
 "recommendation":"update","change_count":18}

// DocumentModel (excerpt)
{"blocks":[
 {"type":"heading","level":2,"text":"How much does X cost?","id":"b_03"},
 {"type":"answer_block","text":"…","claims":["c_01"],"sources":["ev_12"]},
 {"type":"table","caption":"Pricing as of 3 Oct 2026","header":["Plan","Price"],"rows":[["Starter","$24"]],"claims":["c_01"]},
 {"type":"figure","kind":"diagram","svg_ref":"obj://…","alt":"…","caption":"…","provenance":"generated_from_source"}]}
```

## Appendix C: Pull-request checklist
- [ ] Maps to a stage/milestone in this spec; ADR added if deviating.
- [ ] No hardcoded thresholds/prompts/model names (P2).
- [ ] Typed I/O; schema validation at boundaries (P8).
- [ ] Tests: unit + contract/fixture (+ golden where relevant).
- [ ] Cost ledger and structured logs present.
- [ ] Idempotent and retry-safe (P7); rollback path for publish/update changes.
- [ ] No secrets in code, logs, or prompts.
- [ ] Gates unchanged or changed via ADR.
- [ ] Docs updated in `docs/modules/`.

## Appendix D: Glossary
**AEO** answer engine optimisation (extracted answers in snippets/PAA/AIO). **GEO** generative engine optimisation (citations in chat answers). **Decay** sustained, non-seasonal loss of search performance. **ChangeSet** reviewable list of discrete edits to an existing page. **Evidence pack** original inputs plus sourced facts for a piece. **Attestation** immutable record that a named human reviewed a document version. **Breakpoint** a date where a data source's definition changed. **Intent cluster** a set of paraphrased prompts expressing one user need. **Citation-first SERP** a results page where an AI answer or snippet dominates, so the goal is to be cited.

*End of specification.*
