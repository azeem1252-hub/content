"""
Slack Socket Mode Interaction Listener for Autonomous Content Pipeline.
Listens for Approve, Request Changes, and Reject button clicks in Slack,
opens feedback modals, and triggers pipeline state machine transitions.
"""

import os
import sys
import json
import logging
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import asyncio
from config import SLACK_BOT_TOKEN, SLACK_APP_TOKEN
from pipeline.adapters.slack_bot import build_feedback_modal, build_approval_banner
from pipeline.pipeline_manager import pipeline_manager
from pipeline.utils import resolve_full_published_url
from storage.db import get_pipeline_run

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("scripts.run_slack_listener")


def start_slack_listener():
    if not SLACK_BOT_TOKEN or not SLACK_APP_TOKEN:
        print("\n" + "=" * 65)
        print("  ⚠️ SLACK TOKENS NOT CONFIGURED")
        print("  To listen for live Slack button clicks and modals, provide:")
        print("    SLACK_BOT_TOKEN=xoxb-...")
        print("    SLACK_APP_TOKEN=xapp-...")
        print("  in your .env file.")
        print("=" * 65 + "\n")
        return

    from slack_bolt import App
    from slack_bolt.adapter.socket_mode import SocketModeHandler

    app = App(token=SLACK_BOT_TOKEN)
    logger.info("Slack listener attached to shared SQLite-checkpointed pipeline.")

    # 1. Handle Approve Button Click
    @app.action("action_approve")
    def handle_approve(ack, body, client):
        ack()
        user_name = body.get("user", {}).get("username", "editor")
        value_data = json.loads(body["actions"][0].get("value", "{}"))
        thread_id = value_data.get("thread_id", "default")
        slug = value_data.get("slug", "post")

        logger.info(f"User @{user_name} approved dispatch: thread_id={thread_id}, slug={slug}")

        try:
            loop = asyncio.new_event_loop()
            try:
                res = loop.run_until_complete(
                    pipeline_manager.review_run(thread_id=thread_id, action="approved")
                )
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error resuming pipeline on approval: {e}", exc_info=True)

        updated_run = get_pipeline_run(thread_id) or {}
        published_url = resolve_full_published_url(
            updated_run.get("published_url"),
            run_or_state=updated_run,
            slug=slug
        )
        title = updated_run.get("title") or "Published Dispatch"
        site_name = updated_run.get("website_name") or "Next.js Blog"

        channel_id = body["channel"]["id"]
        message_ts = body["message"]["ts"]
        new_blocks = build_approval_banner(title=title, user_name=user_name, published_url=published_url, site_name=site_name)

        client.chat_update(
            channel=channel_id,
            ts=message_ts,
            text=f"✅ Approved and published: {title}",
            blocks=new_blocks
        )

    # 2. Handle Request Changes Button Click (Opens Feedback Modal)
    @app.action("action_request_changes")
    def handle_request_changes(ack, body, client):
        ack()
        trigger_id = body["trigger_id"]
        value_data = json.loads(body["actions"][0].get("value", "{}"))
        thread_id = value_data.get("thread_id", "default")

        logger.info(f"Opening editorial feedback modal for thread_id={thread_id}")
        modal_view = build_feedback_modal(thread_id=thread_id, current_title="Current Dispatch")
        client.views_open(trigger_id=trigger_id, view=modal_view)

    # 3. Handle Feedback Modal Submission
    @app.view("modal_editorial_feedback")
    def handle_feedback_submission(ack, body, view):
        ack()
        user_name = body.get("user", {}).get("username", "editor")
        metadata = json.loads(view.get("private_metadata", "{}"))
        thread_id = metadata.get("thread_id", "default")
        
        values = view["state"]["values"]
        feedback_text = values["feedback_input_block"]["feedback_text"]["value"]

        logger.info(f"Editor @{user_name} submitted revision feedback: '{feedback_text}' (thread: {thread_id})")

        try:
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(
                    pipeline_manager.review_run(thread_id=thread_id, action="request_changes", feedback=feedback_text)
                )
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error resuming pipeline with changes: {e}", exc_info=True)

    # 4. Handle Reject Button Click
    @app.action("action_reject")
    def handle_reject(ack, body, client):
        ack()
        user_name = body.get("user", {}).get("username", "editor")
        value_data = json.loads(body["actions"][0].get("value", "{}"))
        thread_id = value_data.get("thread_id", "default")

        logger.info(f"Dispatch rejected by @{user_name}: thread_id={thread_id}")
        try:
            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(
                    pipeline_manager.review_run(thread_id=thread_id, action="rejected")
                )
            finally:
                loop.close()
        except Exception as e:
            logger.error(f"Error resuming pipeline with rejection: {e}", exc_info=True)

        channel_id = body["channel"]["id"]
        message_ts = body["message"]["ts"]
        client.chat_update(
            channel=channel_id,
            ts=message_ts,
            text=f"🚫 Dispatch archived by @{user_name}.",
            blocks=[{
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"🚫 *Dispatch Rejected & Archived* by @{user_name}."}
            }]
        )

    print("\n" + "=" * 65)
    print("  🟢 Slack Interactive Listener Running in Socket Mode")
    print("  Listening for editorial review actions...")
    print("=" * 65 + "\n")
    handler = SocketModeHandler(app, SLACK_APP_TOKEN)
    handler.start()


if __name__ == "__main__":
    start_slack_listener()
