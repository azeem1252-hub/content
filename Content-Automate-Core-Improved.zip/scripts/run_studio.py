"""
Launcher for Content Pipeline Agent — Mission Control Studio & Dashboard.
Starts the local Uvicorn server on http://localhost:8000.
"""

import os
import sys
import uvicorn
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def _check_frontend_bundle():
    """Warns when the bundle served at /dashboard is older than its source.

    The studio serves frontend/dist/index.html; without this check it is easy to
    keep looking at a UI that silently predates the current frontend/src code.
    """
    frontend = PROJECT_ROOT / "frontend"
    dist = frontend / "dist" / "index.html"
    src = frontend / "src"
    if not src.exists():
        return
    if not dist.exists():
        print("  [!] frontend/dist/index.html is missing. Build the dashboard first:")
        print("      cd frontend && npm run build\n")
        return

    try:
        newest_src = max(
            (p.stat().st_mtime for p in src.rglob("*") if p.is_file()),
            default=0.0,
        )
        for name in ("package.json", "vite.config.ts", "vite.config.js", "tsconfig.json", "index.html"):
            candidate = frontend / name
            if candidate.exists():
                newest_src = max(newest_src, candidate.stat().st_mtime)
        if newest_src > dist.stat().st_mtime + 2:
            print("  [!] frontend/dist/index.html is STALE (frontend/src is newer).")
            print("      Rebuild the dashboard: cd frontend && npm run build\n")
    except OSError:
        pass


def main():
    print("\n" + "=" * 70)
    print("  🚀 CONTENT PIPELINE AGENT — MISSION CONTROL STUDIO")
    print("  ============================================================")
    print("  ⭐ Mission Control Dashboard: http://localhost:8000/dashboard")
    print("  🌐 The Dispatch Public Blog:  http://localhost:8000")
    print("  📑 OpenAPI / Swagger Docs:    http://localhost:8000/docs")
    print("  📤 Publishing REST Endpoint:  POST http://localhost:8000/api/posts")
    print("=" * 70 + "\n")

    _check_frontend_bundle()

    uvicorn.run(
        "web.app:app",
        host="127.0.0.1",
        port=8000,
        reload=True
    )


if __name__ == "__main__":
    main()
