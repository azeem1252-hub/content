"""
Comprehensive in-process verification script for Content Pipeline Agent web platform.
Tests all routes, templates, static files, and database queries with clean recreation.
"""

import sys
from pathlib import Path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fastapi.testclient import TestClient
from web.app import app

endpoints = [
    ("GET", "/health", 200, "API Health Check"),
    ("GET", "/", 200, "Mission Control Studio Home"),
    ("GET", "/dashboard", 200, "Mission Control Dashboard HTML"),
    ("GET", "/docs", 200, "OpenAPI Documentation"),
    ("GET", "/static/css/dashboard.css", 200, "Dashboard CSS"),
    ("GET", "/static/js/dashboard.js", 200, "Dashboard JS"),
    ("GET", "/api/agent/kpis", 200, "Dashboard Live KPIs"),
    ("GET", "/api/agent/system-status", 200, "Agent System Status"),
    ("GET", "/api/agent/runs", 200, "Pipeline Execution Runs"),
    ("GET", "/api/websites", 200, "Connected Websites API"),
    ("GET", "/api/schedules", 200, "Automation Schedules API"),
    ("GET", "/api/posts", 200, "Published Articles API"),
]


def main():
    print("\n" + "=" * 70)
    print("  FULL APPLICATION ENDPOINT & ASSET VERIFICATION (FRESH DB)")
    print("=" * 70)

    all_ok = True
    with TestClient(app) as client:
        for method, path, expected, desc in endpoints:
            res = client.request(method, path)
            ok = (res.status_code == expected)
            if not ok:
                all_ok = False
            status = "PASS" if ok else "FAIL"
            print(f"  [{status}] {res.status_code} {path:<28} - {desc} ({len(res.content)} bytes)")

        # Verify post listing
        posts = client.get("/api/posts").json()
        print(f"\n  Fresh Posts in Database: {len(posts)}")

        # Verify KPIs with clean freshly recreated database
        kpis = client.get("/api/agent/kpis").json()
        print("  Recreated Clean Database KPIs:")
        print(f"    Total Websites:   {kpis.get('total_websites')}")
        print(f"    Active Schedules: {kpis.get('active_schedules')}")
        print(f"    Total Dispatches: {kpis.get('total_dispatches')}")

    print("=" * 70)
    if all_ok:
        print("  >>> ALL APPLICATION ENDPOINTS AND FRESH DATABASE INITIALIZED SUCCESSFULLY <<<")
    else:
        print("  >>> SOME CHECKS FAILED <<<")
    print("=" * 70 + "\n")
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
