import re

# 1. Update SchedulesPage.tsx
with open('frontend/src/components/pages/SchedulesPage.tsx', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.replace('<Sparkles size={15} />', '<Zap size={15} />')
text = text.replace('<Sparkles size={10} />', '<FileText size={10} />')
text = text.replace('<Sparkles size={13} className="text-[var(--color-accent)]" />', '<Sliders size={13} className="text-[var(--color-accent)]" />')

with open('frontend/src/components/pages/SchedulesPage.tsx', 'w', encoding='utf-8') as f:
    f.write(text)
print("Updated SchedulesPage.tsx")

# 2. Update ReviewsPage.tsx
with open('frontend/src/components/pages/ReviewsPage.tsx', 'r', encoding='utf-8') as f:
    rtext = f.read()

# Replace Sparkles icon
rtext = rtext.replace('<Sparkles size={13} className="mt-0.5 shrink-0 text-blue-400" />', '<ShieldCheck size={13} className="mt-0.5 shrink-0 text-blue-400" />')
# Ensure cleanMarkdown import
if 'cleanMarkdown' not in rtext:
    rtext = 'import { cleanMarkdown } from "../../utils/cleanMarkdown";\n' + rtext
# Clean title and excerpt in ReviewsPage
rtext = rtext.replace('{item.title}', '{cleanMarkdown(item.title)}')
rtext = rtext.replace(
    '{item.excerpt || item.metaDescription || "No excerpt generated."}',
    '{cleanMarkdown(item.excerpt || item.metaDescription) || "No excerpt generated."}'
)

with open('frontend/src/components/pages/ReviewsPage.tsx', 'w', encoding='utf-8') as f:
    f.write(rtext)
print("Updated ReviewsPage.tsx")

# 3. Update KeywordsPage.tsx
with open('frontend/src/components/pages/KeywordsPage.tsx', 'r', encoding='utf-8') as f:
    ktext = f.read()

# Replace sparkle button & icons
ktext = ktext.replace(
    'icon={generating ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}',
    'icon={generating ? <Loader2 size={13} className="animate-spin" /> : <Search size={13} />}'
)
ktext = ktext.replace('<Sparkles size={14} />', '<Sliders size={14} />')
ktext = ktext.replace('<Sparkles size={16} className="text-[var(--color-accent)]" />', '<Target size={16} className="text-[var(--color-accent)]" />')
ktext = ktext.replace('<Sparkles size={12} />', '<Zap size={12} />')

with open('frontend/src/components/pages/KeywordsPage.tsx', 'w', encoding='utf-8') as f:
    f.write(ktext)
print("Updated KeywordsPage.tsx")
