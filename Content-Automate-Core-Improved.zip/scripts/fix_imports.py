# 1. ArticleDrawer.tsx
with open('frontend/src/components/ArticleDrawer.tsx', 'r', encoding='utf-8') as f:
    dtext = f.read()
if 'Sliders,' not in dtext:
    dtext = dtext.replace('  Layers,', '  Layers,\n  Sliders,')
    with open('frontend/src/components/ArticleDrawer.tsx', 'w', encoding='utf-8') as f:
        f.write(dtext)
    print('Added Sliders to ArticleDrawer.tsx')

# 2. SettingsPage.tsx
with open('frontend/src/components/pages/SettingsPage.tsx', 'r', encoding='utf-8') as f:
    stext = f.read()
if 'Sliders,' not in stext:
    stext = stext.replace('} from "lucide-react";', '  Sliders,\n} from "lucide-react";')
    with open('frontend/src/components/pages/SettingsPage.tsx', 'w', encoding='utf-8') as f:
        f.write(stext)
    print('Added Sliders to SettingsPage.tsx')

# 3. ContentPage.tsx - ensure Zap is present
with open('frontend/src/components/pages/ContentPage.tsx', 'r', encoding='utf-8') as f:
    ctext = f.read()
if 'Zap,' not in ctext:
    ctext = ctext.replace('  Layers,', '  Layers,\n  Zap,')
    with open('frontend/src/components/pages/ContentPage.tsx', 'w', encoding='utf-8') as f:
        f.write(ctext)
    print('Added Zap to ContentPage.tsx')
