import re

# ==========================================
# 1. Standardize WebsitesPage.tsx
# ==========================================
with open("frontend/src/components/pages/WebsitesPage.tsx", "r", encoding="utf-8") as f:
    wtext = f.read()

# Replace Sparkles icons
wtext = wtext.replace(
    '<Sparkles size={14} className="text-[var(--color-accent)]" />',
    '<Zap size={14} className="text-[var(--color-accent)]" />'
)
wtext = wtext.replace(
    '<Sparkles size={13} className="text-amber-400" />',
    '<HelpCircle size={13} className="text-amber-400" />'
)

# Replace header and container
old_w_header = """  return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
  {/* Header section with action buttons */}
  <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
  <div>
  <div className="flex items-center gap-2">
  <h1 className="text-[26px] font-semibold tracking-tight text-[var(--color-text)] sm:text-[28px]">
  Next.js Websites
  </h1>
  <span className="rounded-full bg-[var(--color-bg-soft)] px-2.5 py-0.5 text-[11px] font-medium text-[var(--color-text)]">
  Edge Runtime Ready
  </span>
  </div>
  <p className="mt-1 text-sm text-[var(--color-text-muted)]">
  {websites.length} websites connected. Articles publish directly to your Next.js API routes with Bearer authentication.
  </p>
  </div>
  <div className="flex flex-wrap items-center gap-2">
  <Button
  variant="secondary"
  size="md"
  icon={pingingAll ? <Loader2 size={14} className="animate-spin text-emerald-400" /> : <Radio size={14} className="text-emerald-400" />}
  onClick={handlePingAllSites}
  disabled={pingingAll || websites.length === 0}
  >
  {pingingAll ? "Pinging Sites…" : "Ping All Sites"}
  </Button>
  <Button
  variant="secondary"
  size="md"
  icon={<Bot size={15} className="text-[var(--color-text)]" />}
  onClick={() => handleOpenSnippetModal("prompt")}
  >
  AI Agent Prompt
  </Button>
  <Button
  variant="secondary"
  size="md"
  icon={<Database size={14} className="text-[var(--color-accent)]" />}
  onClick={() => handleOpenSnippetModal("storage")}
  >
  Serverless Storage Setup
  </Button>
  <Button
  variant="secondary"
  size="md"
  icon={<Code2 size={14} />}
  onClick={() => handleOpenSnippetModal("code")}
  >
  Route Snippet
  </Button>
  <Button
  variant="primary"
  size="md"
  icon={<Plus size={14} />}
  onClick={openCreateModal}
  >
  Connect Website
  </Button>
  </div>
  </div>"""

new_w_header = """  return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
  {/* Standardized aligned header */}
  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
    <div>
      <div className="flex items-center gap-2.5">
        <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
          Connected Websites
        </h1>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-500">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          Edge Runtime Ready
        </span>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
        {websites.length} destinations connected. Direct HTTP /api/posts ingestion with timing-safe Bearer authentication.
      </p>
    </div>
    <div className="flex flex-wrap items-center gap-2">
      <Button
        variant="secondary"
        size="sm"
        icon={pingingAll ? <Loader2 size={13} className="animate-spin text-emerald-400" /> : <Radio size={13} className="text-emerald-400" />}
        onClick={handlePingAllSites}
        disabled={pingingAll || websites.length === 0}
        className="text-xs cursor-pointer"
      >
        {pingingAll ? "Pinging..." : "Ping All Sites"}
      </Button>
      <Button
        variant="secondary"
        size="sm"
        icon={<Database size={13} className="text-[var(--color-accent)]" />}
        onClick={() => handleOpenSnippetModal("storage")}
        className="text-xs cursor-pointer"
      >
        Storage Setup
      </Button>
      <Button
        variant="secondary"
        size="sm"
        icon={<Code2 size={13} />}
        onClick={() => handleOpenSnippetModal("code")}
        className="text-xs cursor-pointer"
      >
        Route Snippet
      </Button>
      <Button
        variant="primary"
        size="sm"
        icon={<Plus size={14} className="stroke-[2.5]" />}
        onClick={openCreateModal}
        className="text-xs font-semibold cursor-pointer"
      >
        Connect Website
      </Button>
    </div>
  </div>"""

if old_w_header in wtext:
    wtext = wtext.replace(old_w_header, new_w_header)
    print("WebsitesPage header updated")
else:
    print("Notice: WebsitesPage old header not matched exactly, checking regex...")
    wtext = re.sub(
        r'return \(\s*<div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">\s*\{/\* Header section with action buttons \*/\}[\s\S]*?Connect Website\s*</Button>\s*</div>\s*</div>',
        new_w_header,
        wtext
    )

with open("frontend/src/components/pages/WebsitesPage.tsx", "w", encoding="utf-8") as f:
    f.write(wtext)

# ==========================================
# 2. Standardize KeywordsPage.tsx
# ==========================================
with open("frontend/src/components/pages/KeywordsPage.tsx", "r", encoding="utf-8") as f:
    ktext = f.read()

# Update container
ktext = ktext.replace(
    '<div className="space-y-6 p-6">',
    '<div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">'
)

# Standardize header
old_k_header = """      {/* Header */}
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-[var(--color-accent-soft)] p-2 text-[var(--color-accent)]">
              <Target size={20} />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-[var(--color-text)]">
                SERP Keyword Intelligence &amp; Content Architecture
              </h1>
              <p className="text-xs text-[var(--color-text-muted)]">
                Pillars A1.1–A1.6: 4-Source Generation, Bulk Enrichment, Empirical Reach, Mathematical Scoring Formula, SERP Clustering &amp; Content Plan.
              </p>
            </div>
          </div>
        </div>"""

new_k_header = """      {/* Standardized aligned header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
              SERP Keyword Intelligence
            </h1>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--color-accent)]/30 bg-[var(--color-accent-soft)] px-2.5 py-0.5 text-[11px] font-semibold text-[var(--color-accent-text)]">
              Pillars A1.1–A1.6
            </span>
          </div>
          <p className="mt-1 text-xs text-[var(--color-text-muted)]">
            4-Source Discovery, Empirical Reach Calibration, Mathematical Scoring Formula &amp; SERP Clustering.
          </p>
        </div>"""

if old_k_header in ktext:
    ktext = ktext.replace(old_k_header, new_k_header)
    print("KeywordsPage header updated")
else:
    print("Regex replacement for KeywordsPage header...")
    ktext = re.sub(
        r'\{\/\* Header \*\/\}\s*<div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">[\s\S]*?SERP Clustering &amp; Content Plan\.\s*<\/p>\s*<\/div>\s*<\/div>\s*<\/div>',
        new_k_header,
        ktext
    )

with open("frontend/src/components/pages/KeywordsPage.tsx", "w", encoding="utf-8") as f:
    f.write(ktext)

# ==========================================
# 3. Standardize SchedulesPage.tsx
# ==========================================
with open("frontend/src/components/pages/SchedulesPage.tsx", "r", encoding="utf-8") as f:
    stext = f.read()

# Update container & header
old_s_top = """  return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
  <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
  <div>
  <div className="flex items-center gap-2">
  <h1 className="text-[26px] font-semibold tracking-tight text-[var(--color-text)] sm:text-[28px]">
  Automated Schedules
  </h1>
  <span className=" bg-[var(--color-bg-soft)] px-2.5 py-0.5 text-[11px] font-medium text-[var(--color-text)]">
  LangGraph Powered
  </span>
  </div>
  <p className="mt-1 text-sm text-[var(--color-text-muted)]">
  One-time or recurring. The agent researches, drafts, audits, and publishes on schedule — with or without a given topic.
  </p>
  </div>
  <Button variant="primary" size="md" icon={<Plus size={14} />} onClick={() => setOpen(true)}>
  New Schedule
  </Button>
  </div>"""

new_s_top = """  return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
  {/* Standardized aligned header */}
  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
    <div>
      <div className="flex items-center gap-2.5">
        <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
          Automated Schedules
        </h1>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-blue-500">
          <span className="h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
          Scheduler Active
        </span>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
        Recurring and event-driven publishing cadences. Researches, drafts, audits, and dispatches autonomously.
      </p>
    </div>
    <Button
      variant="primary"
      size="sm"
      icon={<Plus size={14} className="stroke-[2.5]" />}
      onClick={() => setOpen(true)}
      className="text-xs font-semibold cursor-pointer"
    >
      New Schedule
    </Button>
  </div>"""

if old_s_top in stext:
    stext = stext.replace(old_s_top, new_s_top)
    print("SchedulesPage header updated")
else:
    print("Regex replacement for SchedulesPage...")
    stext = re.sub(
        r'return \(\s*<div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">\s*<div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">[\s\S]*?New Schedule\s*<\/Button>\s*<\/div>',
        new_s_top,
        stext
    )

with open("frontend/src/components/pages/SchedulesPage.tsx", "w", encoding="utf-8") as f:
    f.write(stext)

# ==========================================
# 4. Standardize ReviewsPage.tsx
# ==========================================
with open("frontend/src/components/pages/ReviewsPage.tsx", "r", encoding="utf-8") as f:
    rtext = f.read()

# Update container
rtext = rtext.replace(
    '<div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">',
    '<div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">'
)

# Standardize header badge and typography
rtext = rtext.replace(
    '<h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)]">',
    '<h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">'
)
rtext = rtext.replace(
    '<span className="inline-flex items-center gap-1.5 border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-xs font-semibold text-amber-400">',
    '<span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-amber-500">'
)
rtext = rtext.replace(
    '<p className="mt-1.5 text-sm text-[var(--color-text-muted)]">',
    '<p className="mt-1 text-xs text-[var(--color-text-muted)]">'
)

# Modernize KPI cards to rounded-2xl
rtext = rtext.replace(
    'className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4"',
    'className="grid grid-cols-2 gap-3.5 lg:grid-cols-4"'
)
rtext = rtext.replace(
    'className="border bg-[var(--color-bg-elev)] p-3.5"',
    'className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]"'
)

# Modernize review cards to rounded-2xl
rtext = rtext.replace(
    'className={`relative border transition-all ${',
    'className={`relative rounded-2xl border transition-all overflow-hidden shadow-[var(--shadow-card)] ${'
)

# Modernize filter bar & search input
rtext = rtext.replace(
    'className="relative w-full sm:w-64"',
    'className="relative w-full sm:w-72"'
)
rtext = rtext.replace(
    'className="h-8 w-full border bg-[var(--color-bg-elev)] pl-8 pr-2.5 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none"',
    'className="h-9 w-full rounded-xl border bg-[var(--color-bg-elev)] pl-8 pr-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none"'
)

with open("frontend/src/components/pages/ReviewsPage.tsx", "w", encoding="utf-8") as f:
    f.write(rtext)

# ==========================================
# 5. Clean ArticleDrawer.tsx Sparkles & Titles
# ==========================================
with open("frontend/src/components/ArticleDrawer.tsx", "r", encoding="utf-8") as f:
    dtext = f.read()

# Import cleanMarkdown if not present
if "cleanMarkdown" not in dtext:
    dtext = 'import { cleanMarkdown } from "../utils/cleanMarkdown";\n' + dtext

# Wrap header title with cleanMarkdown
dtext = dtext.replace(
    '{article?.title || "Untitled run"}',
    '{cleanMarkdown(article?.title) || "Untitled run"}'
)
dtext = dtext.replace(
    '{article?.articleModel?.title || article?.title || "Article Document Model"}',
    '{cleanMarkdown(article?.articleModel?.title || article?.title) || "Article Document Model"}'
)

# Replace Sparkles icons
dtext = dtext.replace('<Sparkles size={13} className="text-[var(--color-accent)]" />', '<Sliders size={13} className="text-[var(--color-accent)]" />')
dtext = dtext.replace('<Sparkles size={16} className="text-amber-400" />', '<Layers size={16} className="text-amber-400" />')
dtext = dtext.replace('<Sparkles size={13} className="text-[var(--color-accent-text)] shrink-0" />', '<Zap size={13} className="text-[var(--color-accent-text)] shrink-0" />')
dtext = dtext.replace('<Sparkles size={14} className="text-[var(--color-accent-text)] shrink-0" />', '<Zap size={14} className="text-[var(--color-accent-text)] shrink-0" />')
dtext = dtext.replace('<Sparkles size={13} className="text-amber-400" />', '<CheckCircle2 size={13} className="text-amber-400" />')
dtext = dtext.replace('<Sparkles size={15} className="text-purple-400" />', '<FileText size={15} className="text-purple-400" />')
dtext = dtext.replace('<Sparkles size={16} className="text-[var(--color-accent)]" />', '<Cpu size={16} className="text-[var(--color-accent)]" />')
dtext = dtext.replace('<Sparkles size={14} className="shrink-0 mt-0.5" />', '<CheckCircle2 size={14} className="shrink-0 mt-0.5" />')

with open("frontend/src/components/ArticleDrawer.tsx", "w", encoding="utf-8") as f:
    f.write(dtext)

print("All pages standardized and aligned successfully!")
