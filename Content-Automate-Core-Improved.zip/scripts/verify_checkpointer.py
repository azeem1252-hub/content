"""
Smoke test: verify the durable checkpointer works for BOTH execution styles.

1. Async path: astream() a graph that interrupts at a gate, then resume — the
   FastAPI server flow.
2. Sync bridge path (separate process, like run_slack_listener.py): construct a
   fresh saver bound to its own checkpoint loop and drive the graph purely via
   sync invoke()/get_state(), then read the parent process' checkpoint thread
   from the shared pipeline_checkpoints.db to prove durability.

Uses the real GLOBAL_CHECKPOINTER singleton from pipeline_manager so the exact
production wiring is exercised.
"""
import asyncio
import os
import sys
import uuid
from pathlib import Path
from typing import TypedDict

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt
from pipeline.pipeline_manager import GLOBAL_CHECKPOINTER


class State(TypedDict):
    value: str
    reviewed: bool


def stage_one(state: State) -> dict:
    return {"value": state["value"] + "-one"}


def review_gate(state: State) -> dict:
    decision = interrupt("awaiting review")
    return {"reviewed": decision == "approved"}


def stage_two(state: State) -> dict:
    return {"value": state["value"] + "-two"}


def build_tiny_graph():
    b = StateGraph(State)
    b.add_node("one", stage_one)
    b.add_node("gate", review_gate)
    b.add_node("two", stage_two)
    b.add_edge(START, "one")
    b.add_edge("one", "gate")
    b.add_edge("gate", "two")
    b.add_edge("two", END)
    return b.compile(checkpointer=GLOBAL_CHECKPOINTER)


async def async_flow(run_id: str):
    g = build_tiny_graph()
    # Unique per run: pipeline_checkpoints.db persists across runs, so a fixed
    # id would resume a stale completed thread instead of starting fresh.
    cfg = {"configurable": {"thread_id": f"smoke-async-{run_id}"}}

    # --- Phase 1: run until interrupt, streaming async (server path) ---
    chunks = []
    async for chunk in g.astream({"value": "run"}, config=cfg, stream_mode="updates"):
        chunks.append(list(chunk.keys()))
    state = (await g.aget_state(cfg)).values
    assert state["value"] == "run-one", state
    assert not state.get("reviewed"), state
    print(f"[async] astream OK, chunks={chunks}, paused state={state}", flush=True)

    # --- Phase 2: resume async after interrupt ---
    async for _ in g.astream(Command(resume="approved"), config=cfg, stream_mode="updates"):
        pass
    state = (await g.aget_state(cfg)).values
    assert state["value"] == "run-one-two", state
    assert state["reviewed"] is True, state
    print(f"[async] resume OK, final state={state}", flush=True)


def _sync_subprocess(run_id: str):
    """Runs in a spawned child process (like the Slack Socket Mode listener):
    its own GLOBAL_CHECKPOINTER on its own checkpoint loop, purely sync API."""
    try:
        g = build_tiny_graph()

        # Read the parent process' completed thread from the shared SQLite
        # file — proves checkpoints were actually persisted to disk.
        cfg0 = {"configurable": {"thread_id": f"smoke-async-{run_id}"}}
        inherited = g.get_state(cfg0).values
        assert inherited.get("value") == "run-one-two", inherited
        print(f"[sync ] cross-process read of parent thread OK: {inherited}", flush=True)

        cfg = {"configurable": {"thread_id": f"smoke-sync-{run_id}"}}
        final = g.invoke({"value": "sync"}, config=cfg, interrupt_after=["one"])
        state = g.get_state(cfg).values
        assert state["value"] == "sync-one", state

        final = g.invoke(Command(resume="approved"), config=cfg)
        assert final["value"] == "sync-one-two", final
        assert final["reviewed"] is True, final
        print(f"[sync ] invoke + sync resume OK, final state={final}", flush=True)
    except BaseException as e:
        import traceback
        traceback.print_exc()
        sys.exit(1)


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "--child":
        _sync_subprocess(sys.argv[2])
        return
    print(
        "Checkpointer type: "
        + type(GLOBAL_CHECKPOINTER).__module__
        + "."
        + type(GLOBAL_CHECKPOINTER).__name__,
        flush=True,
    )
    run_id = uuid.uuid4().hex[:8]
    asyncio.run(async_flow(run_id))

    # Persisted before spawning: the parent's checkpoints are already durable,
    # so the child below must be able to read them from the shared db file.

    # Launch as an INDEPENDENT process (like `python run_slack_listener.py`),
    # not multiprocessing.spawn: on Windows spawn inherits the parent's open
    # SQLite/WAL handles, which corrupts the child's view of the database —
    # an artifact that does not exist in the real two-process topology.
    import subprocess
    proc = subprocess.run(
        [sys.executable, str(Path(__file__).resolve()), "--child", run_id],
        capture_output=True,
        text=True,
        timeout=120,
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},  # noqa: SIM112
    )
    sys.stdout.write(proc.stdout)
    sys.stderr.write(proc.stderr)
    if proc.returncode != 0:
        raise SystemExit(f"sync subprocess failed with exit code {proc.returncode}")

    print("\nAll checkpointer paths verified (async astream, aget_state, sync bridge in separate process).")


if __name__ == "__main__":
    main()
