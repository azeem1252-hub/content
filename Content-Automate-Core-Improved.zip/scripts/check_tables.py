import sys, os
sys.path.insert(0, os.path.abspath("."))
from storage.db import get_db_connection

with get_db_connection() as conn:
    c = conn.cursor()
    c.execute("SELECT name FROM sqlite_master WHERE type='table'")
    print("Tables:", [r[0] for r in c.fetchall()])
    c.execute("PRAGMA table_info(pipeline_runs)")
    cols = [r[1] for r in c.fetchall()]
    print("Columns:", cols)
    c.execute("SELECT * FROM pipeline_runs WHERE thread_id = 'dispatch-20261009-192626-b65201'")
    row = dict(c.fetchone())
    print("Row keys:", row.keys())
    state_json = row.get("state_json") or row.get("state")
    if state_json:
        import json
        st = json.loads(state_json) if isinstance(state_json, str) else state_json
        draft = st.get("draft") or ""
        import re
        from pipeline.adapters.article_model import validate_mermaid_syntax, render_mermaid_to_svg
        from config import BASE_DIR
        
        def test_prerender(content, slug):
            pattern = re.compile(r"```mermaid\s*([\s\S]*?)```", re.IGNORECASE)
            diagram_index = 0
            rendered_diagrams = []
            
            def _replacer(match):
                nonlocal diagram_index
                diagram_index += 1
                raw_code = match.group(1).strip()
                title = f"System Architecture Flowchart {diagram_index}"
                valid, err = validate_mermaid_syntax(raw_code)
                svg = render_mermaid_to_svg(raw_code, title=title)
                filename = f"{slug}-diagram-{diagram_index}.svg"
                
                static_dir = BASE_DIR / "web" / "static" / "uploads" / "diagrams"
                static_dir.mkdir(parents=True, exist_ok=True)
                (static_dir / filename).write_text(svg, encoding="utf-8")
                
                # Target sync
                g_dir = BASE_DIR / "gaming-editorial" / "public" / "uploads" / "diagrams"
                g_dir.mkdir(parents=True, exist_ok=True)
                (g_dir / filename).write_text(svg, encoding="utf-8")
                
                img_url = f"/uploads/diagrams/{filename}"
                rendered_diagrams.append({"url": img_url, "filename": filename, "title": title})
                return f'<figure class="article-diagram my-8">\n  <img src="{img_url}" alt="{title}" width="100%" height="auto" loading="lazy" />\n  <figcaption>{title}</figcaption>\n</figure>'
            
            new_content = pattern.sub(_replacer, content)
            return new_content, rendered_diagrams
        
        new_draft, diags = test_prerender(draft, "disco-elysium-systems-theory")
        print("Rendered diagrams count:", len(diags))
        print("Diagram info:", diags)
        print("Contains img src in new draft:", "/uploads/diagrams/" in new_draft)
        print("Contains raw ```mermaid in new draft:", "```mermaid" in new_draft)

