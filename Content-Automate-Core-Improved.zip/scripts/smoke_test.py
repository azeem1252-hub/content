"""
Offline smoke test: drives the real compiled LangGraph pipeline with mocked
LLM/image/publish dependencies through:
  1. outline -> draft -> image -> audit -> review interrupt
  2. request_changes resume -> revised draft -> second interrupt
  3. approve resume -> publish -> repurpose -> completed
  4. fail-closed handling of an unrecognized dict resume (separate thread)
Run: python scratch/smoke_test.py
"""
import os
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Isolate DB before project imports
_tmp_db = Path(tempfile.mkdtemp(prefix="smoke-")) / "pipeline.db"
os.environ["DATABASE_URL"] = str(_tmp_db)
# Keep the smoke test hermetic: never perform real git pushes / GitHub API
# commits from the publish node's local-repo sync path.
os.environ["GITHUB_TOKEN"] = ""
os.environ["GITHUB_REPO"] = ""

import json
from unittest.mock import patch

from storage.db import init_db
init_db()


def fake_llm(prompt, system_instruction=None, temperature=0.7, **kwargs):
    p = prompt.lower()
    if "repurpose" in p:
        return json.dumps({
            "linkedin_post": "LI post",
            "twitter_thread": ["1/2 hook", "2/2 link"],
        })
    if "seo metadata" in p or "produce seo" in p or "analyze this draft and produce" in p:
        return json.dumps({
            "slug": "smoke-test-article",
            "meta_title": "Smoke Test Article",
            "meta_description": "An offline smoke test article for the pipeline.",
            "tags": ["smoke", "test"],
            "seo_score": 99,
            "audit_notes": "ok",
        })
    if "high_ranking_keywords" in p or "content brief" in p or "brief" in p:
        return json.dumps({
            "high_ranking_keywords": ["Next.js", "Server Actions"],
            "target_audience": "Engineers",
            "audience_pain_points": ["State recovery"],
            "competitor_gaps": "Determinism",
            "title": "Smoke Test Article",
            "working_title": "Smoke Test Article",
            "primary_keyword": "Next.js",
            "intent": "informational",
            "unique_angle": "Empirical analysis",
            "outline": [{"h2": "Introduction", "key_points": ["Overview"]}],
        })
    if "video" in p or "shorts" in p or "scriptwriter" in p:
        return json.dumps({
            "title": "Smoke Test Article",
            "target_duration_seconds": 50,
            "hook_3s": "Next.js 15 completely changes how Server Actions behave.",
            "full_narration_text": "Next.js 15 completely changes how Server Actions behave.",
            "scenes": [
                {
                    "scene_number": 1,
                    "spoken_script": "Next.js 15 completely changes how Server Actions behave.",
                    "kinetic_overlay": "NEXTJS 15",
                    "visual_directive": "Fast terminal code scrolling"
                }
            ]
        })
    if "visual prompt" in p:
        return "Minimalist editorial art"
    if "claims" in p or "claim" in p:
        return json.dumps({
            "claims": [
                {
                    "claim_id": "c1",
                    "statement": "Next.js 15 supports React 19.",
                    "search_query": "Next.js 15 React 19 support",
                    "verdict": "Supported",
                    "confidence": 0.99,
                    "evidence": "Official Next.js documentation verifies React 19 support.",
                }
            ]
        })
    if "critique" in p or "self-critique" in p:
        return json.dumps({
            "score": 9.5,
            "passed": True,
            "critique": "Comprehensive technical architecture with strong grounding.",
            "weaknesses": [],
            "actionable_fixes": []
        })
    if "section" in p or "draft" in p:
        return json.dumps({
            "heading": "Architectural Analysis",
            "level": 2,
            "markdown_content": "Body of the smoke test article with empirical benchmarks and technical architecture.",
            "direct_answer": "Next.js 15 provides native support for React 19 Server Actions.",
            "claims": []
        })
    return "# Smoke Test Article\n\nBody of the smoke test article with empirical benchmarks and technical architecture."


# Image generation: patch network fetchers so the fallback saves a tiny "image"
FAKE_JPEG = b"\xff\xd8\xff\xe0" + b"\x00" * 2048
FAKE_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 2048


class FakeImgResponse:
    status_code = 200
    headers = {"content-type": "application/json"}
    content = FAKE_JPEG

    @property
    def text(self):
        return json.dumps(self.json())

    def json(self):
        # Gemini generateContent shape: primary engine gets a real inline image;
        # other endpoints (Codex/Pollinations/publish) tolerate the empty payload.
        import base64 as _b64
        return {
            "status": "success",
            "ok": True,
            "post_url": "http://localhost:3000/posts/smoke-test-article",
            "slug": "smoke-test-article",
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {
                                "inlineData": {
                                    "mimeType": "image/png",
                                    "data": _b64.b64encode(FAKE_PNG).decode(),
                                }
                            }
                        ]
                    }
                }
            ]
        }


class FakeHttpxClient:
    def __init__(self, *a, **kw):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def post(self, *a, **kw):
        return FakeImgResponse()

    def get(self, *a, **kw):
        return FakeImgResponse()

    def put(self, *a, **kw):
        return FakeImgResponse()


def run():
    from pipeline.graph import build_content_pipeline
    from langgraph.types import Command
    from storage.db import create_website

    site = create_website(
        name="Smoke Test Site",
        url="http://localhost:3000",
        secret_token="smoke-token",
        storage_type="database"
    )

    graph = build_content_pipeline()
    thread_id = "smoke-thread-001"
    config = {"configurable": {"thread_id": thread_id}}
    initial = {
        "topic": "Smoke Test Article",
        "title": "Smoke Test Article",
        "slug": "smoke-test-article",
        "keywords": ["smoke"],
        "target_audience": "Engineers",
        "revision_count": 0,
        "review_status": "pending",
        "thread_id": thread_id,
        "status": "queued",
        "slack_dispatch": False,
        "website_id": site["id"],
        "evidence_pack": [{
            "id": "evi_smoke_01",
            "title": "Smoke Test Telemetry",
            "evidence_type": "first_party_data",
            "content": "Production benchmarks demonstrating sub-tick latency and zero memory leaks.",
            "source_url": "https://test.example.com",
            "author_or_expert": "Lead Systems Architect",
        }],
    }

    routed_patch = lambda role, prompt, **kw: (fake_llm(prompt), {"role": role, "provider": "mock", "model": "mock"})

    with patch("pipeline.llm_client.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.model_router.routed_call_llm", side_effect=routed_patch), \
         patch("pipeline.adapters.model_router.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.humanizer.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.fact_check_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.outline_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.draft_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.brief_builder.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.audit_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.repurpose_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.codex_image.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.outline_node.fetch_tavily_intelligence", return_value={"results": [], "answer": None}), \
         patch("pipeline.nodes.outline_node.fetch_tavily_extract", return_value={"results": []}), \
         patch("pipeline.adapters.codex_image.httpx.Client", FakeHttpxClient), \
         patch("pipeline.adapters.gemini_image.httpx.Client", FakeHttpxClient), \
         patch("pipeline.adapters.website_client.httpx.Client", FakeHttpxClient):

        # Phase 1: run to review interrupt
        state1 = graph.invoke(initial, config=config)
        assert state1["review_status"] == "pending", state1["review_status"]
        assert state1["slug"] == "smoke-test-article"
        assert state1["title"] == "Smoke Test Article"
        assert state1["revision_count"] == 1
        print("[1/4] Phase 1 interrupted at review gate: OK")

        # Phase 2: request changes -> redraft -> second interrupt
        state2 = graph.invoke(Command(resume={
            "action": "request_changes",
            "feedback": "Make it better",
        }), config=config)
        assert state2["revision_count"] == 2, state2["revision_count"]
        assert state2["reviewer_feedback"] is None  # cleared after redraft
        assert state2["review_status"] == "pending"
        print("[2/4] Phase 2 revision loop: OK")

        # Phase 3: approve -> publish -> repurpose
        state3 = graph.invoke(Command(resume="approved"), config=config)
        assert state3["review_status"] == "approved"
        assert state3["status"] == "completed", state3["status"]
        assert state3["published_url"], "missing published_url"
        assert state3["linkedin_post"] == "LI post"
        assert len(state3["twitter_thread"]) == 2
        print(f"[3/4] Phase 3 publish + repurpose: OK (published_url={state3['published_url']})")

        # Phase 3b: idempotency - resuming a completed thread must not corrupt it
        state3b = graph.invoke(Command(resume="approved"), config=config)
        assert state3b["status"] == "completed"
        print("[3b]  Re-resume of completed thread is stable: OK")

    # Phase 4: fail-closed unrecognized dict resume (fresh thread)
    with patch("pipeline.llm_client.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.model_router.routed_call_llm", side_effect=routed_patch), \
         patch("pipeline.adapters.model_router.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.humanizer.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.fact_check_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.outline_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.brief_builder.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.draft_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.audit_node.call_llm", side_effect=fake_llm), \
         patch("pipeline.adapters.codex_image.call_llm", side_effect=fake_llm), \
         patch("pipeline.nodes.outline_node.fetch_tavily_intelligence", return_value={"results": [], "answer": None}), \
         patch("pipeline.nodes.outline_node.fetch_tavily_extract", return_value={"results": []}), \
         patch("pipeline.adapters.codex_image.httpx.Client", FakeHttpxClient), \
         patch("pipeline.adapters.gemini_image.httpx.Client", FakeHttpxClient):

        thread_id2 = "smoke-thread-002"
        config2 = {"configurable": {"thread_id": thread_id2}}
        initial2 = dict(initial, thread_id=thread_id2)
        graph.invoke(initial2, config2)
        state4 = graph.invoke(Command(resume={"weird": "payload"}), config2)
        assert state4["review_status"] == "rejected", state4["review_status"]
        print("[4/4] Phase 4 fail-closed unknown dict resume -> rejected: OK")

    print("\nSMOKE TEST PASSED")


if __name__ == "__main__":
    run()
