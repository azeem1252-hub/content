"""
Autonomous Content Publishing Pipeline — CLI Runner
Triggers the full LangGraph pipeline from topic input through research, drafting,
image synthesis, SEO audit, Slack review gate, live website publishing, and social distribution.
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.graph import build_content_pipeline
from pipeline.pipeline_manager import GLOBAL_CHECKPOINTER
from storage.db import init_db, resolve_run_website

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("scripts.run_pipeline")


def run(topic: str, keywords: list, target_audience: str = None, website_id: str = None, auto_approve: bool = False):
    init_db()

    # Resolve target website. A --website id that no longer exists is a hard
    # error: silently using the default website would publish to the wrong site.
    target_site = resolve_run_website(website_id)
    site_name = target_site["name"] if target_site else "Next.js Production Blog"
    resolved_site_id = target_site["id"] if target_site else None
    destination_url = target_site["url"] if target_site else None

    print("\n" + "=" * 70)
    print("  [>] AUTONOMOUS CONTENT PUBLISHING PIPELINE")
    print(f"  Target Website: {site_name} ({destination_url or 'Local Archive'})")
    print(f"  Topic:          '{topic}'")
    print(f"  Keywords:       {', '.join(keywords) if keywords else 'Auto-discovered'}")
    print(f"  Auto-Approve:   {auto_approve}")
    print("=" * 70 + "\n")

    pipeline = build_content_pipeline(checkpointer=GLOBAL_CHECKPOINTER)

    thread_id = f"dispatch-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    config = {"configurable": {"thread_id": thread_id}}

    initial_state = {
        "topic": topic,
        "keywords": keywords,
        "target_audience": target_audience or "Software Engineers & Technology Leaders",
        "website_id": resolved_site_id,
        "destination_name": site_name,
        "destination_url": destination_url,
        "revision_count": 0,
        "review_status": "approved" if auto_approve else "pending",
        "thread_id": thread_id,
        "status": "queued",
        "slack_dispatch": True
    }

    print(f"[1/3] Executing pipeline run (Thread: {thread_id})...")
    try:
        state = pipeline.invoke(initial_state, config=config)
    except Exception as e:
        logger.info(f"Graph execution paused or interrupted: {e}")
        state = pipeline.get_state(config).values or {}

    if not state:
        state = pipeline.get_state(config).values or {}

    print("\n" + "-" * 70)
    print("  RUN SUMMARY & RESULTS")
    print("-" * 70)
    print(f"  Thread ID:       {thread_id}")
    print(f"  Title:           {state.get('title', topic)}")
    print(f"  Slug:            {state.get('slug', '—')}")
    print(f"  Status:          {state.get('status', 'running')}")
    print(f"  SEO Score:       {state.get('seo_score', '—')}/100")
    print(f"  Word Count:      {state.get('word_count', 0)} words (~{state.get('read_time', 1)} min read)")
    print(f"  Hero Image:      {state.get('hero_image_url', '—')}")

    if state.get("review_status") == "pending" and not auto_approve:
        print("\n" + "!" * 70)
        print("  ⏸️  PIPELINE PAUSED AT HUMAN EDITORIAL REVIEW GATE")
        print(f"  Review card dispatched to Slack. Or review in Mission Control Studio:")
        print(f"  👉 http://localhost:8000/dashboard?review={thread_id}")
        print("!" * 70 + "\n")

    if state.get("published_url"):
        print(f"\n  [OK] Live Article URL: {state.get('published_url')}")

    if state.get("linkedin_post"):
        print(f"\n  [LinkedIn] Post Ready:\n{state.get('linkedin_post')[:250]}...\n")

    if state.get("twitter_thread"):
        print(f"  [X / Twitter] Thread Ready ({len(state.get('twitter_thread'))} tweets)")

    print("=" * 70 + "\n")
    return state


def main():
    parser = argparse.ArgumentParser(description="Trigger Autonomous AI Content Publishing Pipeline")
    parser.add_argument("--topic", type=str, default="Autonomous Multi-Agent Pipelines in 2026", help="Article topic")
    parser.add_argument("--keywords", type=str, default="LangGraph, Groq, Autonomous Agents, AI", help="Comma-separated keywords")
    parser.add_argument("--audience", type=str, default="Technical Leaders & Developers", help="Target audience")
    parser.add_argument("--website", type=str, default=None, help="Target Next.js website ID (defaults to primary website)")
    parser.add_argument("--auto-approve", action="store_true", help="Auto-approve without pausing for Slack interactive gate")

    args = parser.parse_args()
    kws = [k.strip() for k in args.keywords.split(",") if k.strip()]
    try:
        run(
            topic=args.topic,
            keywords=kws,
            target_audience=args.audience,
            website_id=args.website,
            auto_approve=args.auto_approve
        )
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
