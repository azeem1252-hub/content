import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Button } from "./ui";
import { Close, LogoMark, Menu } from "./icons";

const LINKS = [
  { label: "Product", href: "#signal" },
  { label: "Intelligence", href: "#investigation" },
  { label: "Workflow", href: "#loop" },
  { label: "Evidence", href: "#evidence" },
  { label: "Pricing", href: "#pricing" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b border-line transition-[background-color,backdrop-filter] duration-300",
        scrolled ? "bg-white/80 backdrop-blur-md" : "bg-white",
      )}
    >
      <div
        className={cn(
          "mx-auto flex w-full max-w-[1280px] items-center justify-between px-5 transition-[height] duration-300 sm:px-8 lg:px-10",
          scrolled ? "h-14" : "h-16",
        )}
      >
        <div className="flex items-center gap-10">
          <a href="#top" className="flex items-center gap-2.5" aria-label="Lede — home">
            <LogoMark />
            <span className="font-serif text-[26px] leading-none tracking-[-0.01em]">Lede</span>
          </a>
          <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="rounded-[4px] px-3 py-2 text-sm text-ink-2 transition-colors hover:bg-paper hover:text-ink"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="#cta"
            className="hidden rounded-[4px] px-3 py-2 text-sm text-ink-2 transition-colors hover:text-ink sm:block"
          >
            Sign in
          </a>
          <Button href="#cta" arrow className="hidden sm:inline-flex">
            Get started
          </Button>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center rounded-[4px] border border-line-strong md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <Close size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-line bg-white md:hidden">
          <ul className="mx-auto max-w-[1280px] px-5 py-2">
            {LINKS.map((l) => (
              <li key={l.href} className="border-b border-line last:border-0">
                <a href={l.href} onClick={() => setOpen(false)} className="flex items-center justify-between py-3.5 text-[15px]">
                  {l.label}
                </a>
              </li>
            ))}
            <li className="flex items-center gap-3 py-4">
              <Button href="#cta" arrow onClick={() => setOpen(false)} className="flex-1">
                Get started
              </Button>
              <a href="#cta" className="px-3 text-sm text-ink-2">
                Sign in
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
