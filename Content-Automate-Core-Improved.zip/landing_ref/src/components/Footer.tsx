import { Container } from "./ui";
import { LogoMark } from "./icons";

const COLS = [
  {
    h: "Product",
    l: [
      ["Product", "#signal"],
      ["Intelligence", "#investigation"],
      ["Workflow", "#loop"],
      ["Evidence", "#evidence"],
      ["Integrations", "#integrations"],
      ["Pricing", "#pricing"],
    ],
  },
  {
    h: "Resources",
    l: [
      ["Documentation", "#"],
      ["Blog", "#"],
      ["Guides", "#"],
      ["Changelog", "#"],
    ],
  },
  {
    h: "Company",
    l: [
      ["About", "#"],
      ["Contact", "#cta"],
      ["Privacy", "#"],
      ["Terms", "#"],
    ],
  },
  {
    h: "Social",
    l: [
      ["GitHub", "#"],
      ["LinkedIn", "#"],
      ["X", "#"],
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-paper">
      <Container className="py-14 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <a href="#top" className="inline-flex items-center gap-2.5" aria-label="Lede — back to top">
              <LogoMark />
              <span className="font-serif text-[26px] leading-none">Lede</span>
            </a>
            <p className="mt-4 max-w-[300px] text-[14px] leading-snug text-ink-2">
              Content intelligence for teams that want to know what to fix, why, and whether it worked.
            </p>
          </div>
          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-4 lg:col-span-8">
            {COLS.map((c) => (
              <div key={c.h}>
                <h3 className="label text-ink">{c.h}</h3>
                <ul className="mt-4 space-y-2.5">
                  {c.l.map(([t, href]) => (
                    <li key={t}>
                      <a href={href} className="text-[14px] text-ink-2 transition-colors hover:text-ink">
                        {t}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>
        <div className="mt-14 flex flex-col gap-2 border-t border-line pt-6 text-[12px] text-ink-3 sm:flex-row sm:items-center sm:justify-between">
          <span>© 2026 Lede. All rights reserved.</span>
          <span>All product data on this page is sample or illustrative data.</span>
        </div>
      </Container>
    </footer>
  );
}
