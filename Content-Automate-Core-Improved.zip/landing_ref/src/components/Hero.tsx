import { Button, Container, Eyebrow } from "./ui";
import { SignalMonitor } from "./SignalMonitor";

export function Hero() {
  return (
    <section id="top" aria-labelledby="hero-title" className="relative bg-paper pb-14 pt-6 sm:pt-8 lg:pb-20">
      <Container>
        <div className="mb-8 flex items-center justify-between gap-4 border-b border-line pb-3 sm:mb-10">
          <span className="label text-ink">The Content Intelligence Desk</span>
          <span className="label hidden sm:inline">Live product demo · sample data</span>
        </div>
        <div className="grid items-end gap-8 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-8">
            <Eyebrow>Content intelligence platform</Eyebrow>
            <h1
              id="hero-title"
              className="mt-5 font-serif text-[clamp(3rem,7.2vw,5.9rem)] font-normal leading-[0.97] tracking-[-0.025em] text-balance"
            >
              Some of your content is quietly <em className="text-decline">losing.</em>
            </h1>
          </div>
          <div className="lg:col-span-4 lg:pb-3">
            <p className="text-[17px] leading-[1.6] text-ink-2 text-pretty">
              Find the pages that are declining, understand why, decide what deserves attention, and measure what
              happens after you change it.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button href="#cta" arrow size="lg">
                Analyze your content
              </Button>
              <Button href="#signal" variant="secondary" size="lg">
                See how it works
              </Button>
            </div>
            <p className="mt-4 text-[13px] text-ink-2">Connect Search Console, Analytics, and your CMS.</p>
          </div>
        </div>

        <div className="mt-10 lg:mt-12">
          <SignalMonitor />
        </div>
      </Container>
    </section>
  );
}
