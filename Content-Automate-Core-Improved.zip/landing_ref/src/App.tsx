import { useEffect } from "react";
import { initSmoothScroll } from "./lib/scroll";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { IntegrationStrip } from "./components/IntegrationStrip";
import { SignalSection } from "./components/SignalSection";
import { InvestigationSection } from "./components/InvestigationSection";
import { SeasonalitySection } from "./components/SeasonalitySection";
import { ContentAutopsy } from "./components/ContentAutopsy";
import { EvidenceDesk } from "./components/EvidenceDesk";
import { PriorityBoard } from "./components/PriorityBoard";
import { OpportunityExplorer } from "./components/OpportunityExplorer";
import { ResearchWorkspace } from "./components/ResearchWorkspace";
import { EditorialWorkbench } from "./components/EditorialWorkbench";
import { ClaimVerification } from "./components/ClaimVerification";
import { HumanApproval } from "./components/HumanApproval";
import { VisibilitySection } from "./components/VisibilitySection";
import { PublishingFlow } from "./components/PublishingFlow";
import { MeasurementExperiment } from "./components/MeasurementExperiment";
import { OperatingLoop } from "./components/OperatingLoop";
import { UseCases } from "./components/UseCases";
import { Integrations } from "./components/Integrations";
import { SocialProof } from "./components/SocialProof";
import { Pricing } from "./components/Pricing";
import { FAQ } from "./components/FAQ";
import { FinalCTA } from "./components/FinalCTA";
import { Footer } from "./components/Footer";
import { StoryRail } from "./components/StoryRail";

export default function App() {
  useEffect(() => initSmoothScroll(), []);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-[4px] focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <Hero />
        <IntegrationStrip />
        <SignalSection />
        <InvestigationSection />
        <SeasonalitySection />
        <ContentAutopsy />
        <EvidenceDesk />
        <PriorityBoard />
        <OpportunityExplorer />
        <ResearchWorkspace />
        <EditorialWorkbench />
        <ClaimVerification />
        <HumanApproval />
        <VisibilitySection />
        <PublishingFlow />
        <MeasurementExperiment />
        <OperatingLoop />
        <UseCases />
        <Integrations />
        <SocialProof />
        <Pricing />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
      <StoryRail />
    </>
  );
}
