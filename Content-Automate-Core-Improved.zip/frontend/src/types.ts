export type ContentStatus =
  | "Idea"
  | "Drafting"
  | "SEO Check"
  | "Awaiting Approval"
  | "Scheduled"
  | "Published"
  | "Failed";

export type PipelineStage =
  | "Ideas"
  | "Drafting"
  | "SEO Check"
  | "Review"
  | "Published";

export interface Website {
  id: string;
  name: string;
  url: string;
  status: "Connected" | "Syncing" | "Disconnected";
  schedule: "Daily" | "Weekly" | "Biweekly" | "Monthly";
  lastPublished: string; // relative
  lastPublishedAt: Date;
  articles: number;
  avatarColor: string;
  secret_token?: string;
  slack_channel_id?: string;
  slack_webhook_url?: string;
  slack_enabled?: boolean;
  is_default?: boolean;
  last_status?: string;
  type?: string;
  github_repo?: string;
  github_branch?: string;
  has_github_token?: boolean;
  has_secret_token?: boolean;
  storage_type?: "database" | "git" | "auto" | string;
}

export interface Schedule {
  id: string;
  name: string;
  websiteId: string;
  frequency: "Daily" | "Weekly" | "Biweekly" | "Monthly" | "Custom";
  dayOfWeek?: string;
  time: string; // "08:00"
  nextRun: string; // human readable
  active: boolean;
  topic: string;
  lastRun?: string;
  interval_hours?: number;
  slack_review_required?: boolean;
  keywords?: string[];
  target_audience?: string;
  schedule_type?: "recurring" | "once" | "completed";
  publish_time?: string;
  content_format?: string;
  content_options?: Record<string, boolean>;
}

export interface ContentItem {
  id: string;
  threadId?: string;
  title: string;
  excerpt: string;
  websiteId: string;
  status: ContentStatus;
  createdAt: string; // relative
  createdAtDate: Date;
  seoScore: number;
  targetKeyword: string;
  metaDescription: string;
  aiNotes?: string;
  scheduledFor?: string;
  draft?: string;
  heroImageUrl?: string;
  publishedUrl?: string;
  slug?: string;
  revisionCount?: number;
  rawStatus?: string;
  keywords?: string[];
  targetAudience?: string;
  author?: string;
  readingTime?: string;
  outline?: string;
  imagePrompt?: string;
  linkedinPost?: string;
  twitterThread?: string[];
  postizStatus?: string;
  searchSources?: Array<{ title?: string; url?: string; snippet?: string }>;
  discoveredKeywords?: string[];
  audienceInsights?: string;
  citableScore?: number;
  citableEvaluation?: {
    citable_score?: number;
    status?: string;
    dimension_scores?: Record<string, number>;
    recommendations?: string[];
    has_comparison_table?: boolean;
    has_canonical_passage?: boolean;
    diagnostic_details?: string[];
    canonical_passages_count?: number;
    entity_count?: number;
  };

  // Fact Verification & Grounding (Pillar A4 / Pillar I)
  factCheckScore?: number;
  factCheckVerdict?: string;
  factCheckClaims?: Array<any>;
  requiresHumanApproval?: boolean;
  namedHumanApprover?: string;
  verificationReport?: {
    promise?: string;
    disclaimer?: string;
    total_claims?: number;
    supported_count?: number;
    contradicted_count?: number;
    unsubstantiated_count?: number;
    regulated_or_high_risk_count?: number;
    fact_check_score?: number;
    overall_verdict?: string;
    requires_human_approval?: boolean;
    named_human_approver?: string;
    audited_metadata?: {
      title?: string;
      meta_description?: string;
      schema_snippet_audited?: boolean;
      alt_text?: string;
      google_oct_2026_guidance_compliant?: boolean;
    };
    claims_audit?: Array<any>;
    policy_actions?: Array<any>;
  };
  verifiedClaims?: Array<{
    claim_id: string;
    statement: string;
    kind?: "stat" | "date" | "quote" | "spec" | "causal" | "regulated" | string;
    risk?: "low" | "medium" | "high" | "critical" | string;
    context_source?: "body" | "title" | "meta_description" | "schema" | "alt_text" | string;
    span?: string;
    verdict: "Supported" | "Contradicted" | "Unsubstantiated" | string;
    confidence_score: number;
    supporting_span?: string;
    source_url?: string;
    sources?: Array<{
      url?: string;
      domain?: string;
      retrieval_time?: string;
      excerpt?: string;
      passage_hash?: string;
      is_primary_source?: boolean;
      trust_tier?: number;
    }>;
    policy_action?: string;
    requires_human_approval?: boolean;
    assigned_human_approver?: string;
    reasoning?: string;
    correction?: string;
  }>;
  verificationLayers?: {
    hallucination_score: number;
    grounding_score: number;
    source_trust_score: number;
    decision_risk_level: "Low" | "Moderate" | "High" | string;
    routing_action: string;
    reasoning?: string;
  };
  sourceCitations?: Array<{ statement?: string; url?: string; supporting_span?: string }>;
  citationReadiness?: {
    passed_count?: number;
    total_count?: number;
    readiness_percentage?: number;
    readiness_tier?: string;
    promise?: string;
    disclaimer?: string;
    evidence_matrix?: Array<{
      rank: number;
      lever: string;
      evidence_level: string;
      implementation: string;
      verdict?: string;
      passed?: boolean;
    }>;
    items?: Array<{
      lever_name: string;
      passed: boolean;
      title: string;
      description: string;
      evidence_order: number;
      evidence_level?: string;
      implementation_ref?: string;
      details?: Record<string, any>;
      remediation_hint?: string;
    }>;
    detected_facts_summary?: Record<string, number>;
    crawler_policy_summary?: Record<string, any>;
    third_party_corroboration_summary?: Record<string, any>;
  };
  // SERP-Grounded NLP Engine (Surfer NLP Paradigm)
  serpCoverage?: {
    serp_coverage_score: number;
    matched_bigrams?: string[];
    matched_trigrams?: string[];
    matched_entities?: string[];
    missing_salient_phrases?: string[];
    missing_entities?: string[];
    unresolved_questions?: string[];
    recommendations?: string[];
  };
  // Topic Cluster & Autonomous Internal Linking
  topicCluster?: {
    cluster_role?: string;
    is_pillar?: boolean;
    outbound_internal_links?: Array<{ anchor: string; url: string; slug: string }>;
    outbound_count?: number;
    inbound_recommendations?: Array<{ title: string; slug: string; url: string; similarity?: number }>;
    cluster_health_score?: number;
  };
  // Pillar A5: On-Page SEO, Schema, and Contextual Links
  onPageSeo?: {
    passed: boolean;
    meta_validation?: {
      passed: boolean;
      title_length: number;
      description_length: number;
      slug_length: number;
      issues: Array<{ field: string; issue: string; severity: string }>;
      warnings: Array<{ field: string; issue: string; current_length?: number; target_range?: string; severity: string }>;
      checked_in_a4?: boolean;
    };
    answer_first_lint?: {
      passed: boolean;
      sections_audited: number;
      answer_first_count: number;
      warnings: Array<{ heading?: string; type: string; message: string; severity: string }>;
      guidance?: string;
    };
    quality_lint?: {
      passed: boolean;
      readability?: {
        flesch_reading_ease: number;
        flesch_kincaid_grade: number;
        avg_sentence_length: number;
        reading_ease_label: string;
      };
      banned_phrases_detected?: Array<{ phrase: string; count: number }>;
      total_statistics_count: number;
      unsourced_statistics_count: number;
      unsourced_statistics?: Array<{ statistic: string; sentence_snippet: string }>;
      has_author_byline: boolean;
      has_dates: boolean;
      unsourced_superlatives?: string[];
      warnings?: Array<{ type: string; message: string; severity: string }>;
    };
    issue_count?: number;
    warning_count?: number;
  };
  schemaMarkup?: Array<Record<string, any>>;
  internalLinkProposals?: Array<{
    id: string;
    type: string;
    source_slug: string;
    source_title: string;
    target_slug: string;
    target_title: string;
    target_url: string;
    anchor_text: string;
    context_sentence: string;
    relevance_score: number;
    status: "proposed" | "approved" | "rejected";
    review_comment?: string;
  }>;
  inboundLinkProposals?: Array<{
    id: string;
    type: string;
    source_slug: string;
    source_title: string;
    target_slug: string;
    target_title: string;
    target_url: string;
    anchor_text: string;
    suggested_placement: string;
    relevance_score: number;
    status: "proposed" | "approved" | "rejected";
  }>;
  imageProvenance?: {
    image_url: string;
    image_type: "user_asset" | "screenshot" | "data_chart" | "ai_generated";
    is_ai_generated: boolean;
    ai_engine?: string;
    model_name?: string;
    generation_prompt?: string;
    created_at?: string;
    iptc_metadata?: Record<string, string>;
    provenance_notes?: string;
  };
  engineErrors?: Record<string, any>;
  // A5b: Answer Engine Optimization (AEO)
  aeoReport?: {
    answer_targets?: Array<any>;
    answer_blocks?: Array<any>;
    faq_module?: Array<any>;
    faq_items?: Array<any>;
    entity_layer?: Record<string, any>;
    click_worthiness?: Array<any>;
    measurement_snapshot?: Record<string, any>;
    limits_warning?: string;
    honest_limits?: string;
    eligible_count?: number;
    near_miss_count?: number;
    not_eligible_count?: number;
    config?: Record<string, any>;
    [key: string]: any;
  };
  answerBlocks?: Array<any>;
  aeoFaqItems?: Array<any>;
  aeoEntityLayer?: Record<string, any>;
  // A5c: Article Production Studio
  articleModel?: {
    doc_id?: string;
    article_type?: string;
    title?: string;
    slug?: string;
    author?: string;
    total_word_count?: number;
    blocks?: Array<{
      block_id: string;
      block_type: string;
      claims?: Array<{ claim_text: string; source_url?: string; verified?: boolean; confidence?: number }>;
      sources?: Array<{ url: string; title?: string }>;
      lint_warnings?: string[];
      verified?: boolean;
      [key: string]: any;
    }>;
    blueprint_id?: string;
    blueprint_compliance?: {
      blueprint_id?: string;
      article_type?: string;
      required_met?: string[];
      required_missing?: string[];
      optional_present?: string[];
      warnings?: string[];
      word_count?: number;
      is_compliant?: boolean;
    };
    lint_summary?: {
      is_valid?: boolean;
      warnings?: string[];
      errors?: string[];
      block_lints?: Record<string, string[]>;
      claim_summary?: Record<string, any>;
    };
  };
  articleHtml?: string;
  articleMarkdown?: string;
  articleWpBlocks?: Array<any>;
  articleWpHtml?: string;
  articleCmsPayload?: Record<string, any>;
  blueprintCompliance?: {
    blueprint_id?: string;
    article_type?: string;
    required_met?: string[];
    required_missing?: string[];
    optional_present?: string[];
    warnings?: string[];
    word_count?: number;
    is_compliant?: boolean;
  };
  lintSummary?: Record<string, any>;
  visualPlan?: Record<string, any>;
  visualDensity?: Record<string, any>;
  prohibitionsReport?: Record<string, any>;
  layoutAudit?: Record<string, any>;
  prePublishQualityReport?: Record<string, any>;
  previewUrl?: string;
  dedupeKey?: string;
  postPublishChecks?: Record<string, any>;
  pipeline: {
    draft: boolean;
    seo: boolean;
    review: boolean;
    published: boolean;
  };
}

export interface GroundingPage {
  slug: string;
  filename: string;
  html_path: string;
  url_path: string;
  modified_at: string;
  preview?: string;
}

export interface ActionOpportunity {
  id: string;
  type: string;
  post_slug: string;
  post_title: string;
  post_id?: number | null;
  severity: "critical" | "high" | "medium";
  score?: number;
  title: string;
  issue_summary: string;
  recommendation: string;
  projected_impact: string;
  action_label: string;
  evidence?: Record<string, any>;
}


export interface ActionCenterData {
  opportunities: ActionOpportunity[];
  summary: {
    total_opportunities: number;
    critical_count: number;
    high_count: number;
    potential_traffic_multiplier: string;
    evaluated_posts_count: number;
    timestamp: string;
  };
}

export interface ActivityEvent {
  id: string;
  type: "approved" | "published" | "draft" | "schedule" | "rejected" | "connected";
  title: string;
  meta?: string;
  when: string; // relative
  whenDate: Date;
}

export interface UpcomingItem {
  id: string;
  when: string; // "Tomorrow"
  time: string; // "8:00 AM"
  title: string;
  websiteId: string;
  type: "AI-generated draft" | "Scheduled" | "Manual review";
}

export interface SystemStatus {
  preferred_provider?: string;
  env_file_exists?: boolean;
  env_file_path?: string;
  groq?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  mistral?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  openai?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  claude?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  qwen?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  glm?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  kimi?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  deepseek?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  custom_llm?: { configured: boolean; has_key: boolean; base_url?: string; model?: string; masked_key?: string };
  tavily?: { configured: boolean; has_key: boolean; masked_key?: string };
  gemini?: { configured: boolean; has_key: boolean; masked_key?: string; model?: string; mode?: string };
  cloudflare?: {
    configured: boolean;
    has_account_id?: boolean;
    has_token?: boolean;
    account_id?: string;
    masked_token?: string;
    model?: string;
  };
  openai_image?: { configured: boolean; has_key: boolean; model?: string; masked_key?: string };
  custom_image?: { configured: boolean; has_key: boolean; endpoint_url?: string; model?: string; masked_key?: string };
  codex?: { configured: boolean; has_key: boolean; masked_key?: string; mode?: string };
  slack?: {
    configured: boolean;
    has_key: boolean;
    masked_key?: string;
    channel_id?: string;
    signing_secret_configured?: boolean;
    masked_signing_secret?: string;
    app_token_configured?: boolean;
    masked_app_token?: string;
  };
  github?: {
    configured: boolean;
    has_token?: boolean;
    masked_token?: string;
    repo?: string;
    branch?: string;
    nextjs_public_dir?: string;
  };
  publishing?: {

    auto_publish_approved?: boolean;
    require_human_gate?: boolean;
    generate_social_assets?: boolean;
  };
  notifications?: {
    notify_review_needed?: boolean;
    notify_published?: boolean;
    notify_slack_sync?: boolean;
  };
  database?: { status: string; type: string };
  dataforseo?: {
    configured: boolean;
    has_login?: boolean;
    login?: string;
    has_password?: boolean;
    masked_password?: string;
  };
  serper?: {
    configured: boolean;
    has_key?: boolean;
    masked_key?: string;
  };
  openpagerank?: {
    configured: boolean;
    has_key?: boolean;
    masked_key?: string;
  };
  embeddings?: {
    configured?: boolean;
    provider?: string;
    model?: string;
    has_key?: boolean;
    masked_key?: string;
    dimension?: number;
  };
  measurement?: any;
  image?: {
    engine_order: string;
    engines: Array<{ id: string; label: string; configured: boolean }>;
  };
}

export interface DashboardKpis {
  total_websites?: number;
  connected_websites?: number;
  active_schedules?: number;
  total_dispatches?: number;
  total_runs?: number;
  completed_dispatches?: number;
  published_count?: number;
  pending_reviews?: number;
  in_review_count?: number;
  queued_count?: number;
  success_rate?: number;
  avg_seo_score?: number;
}

export interface TopicDiscovery {
  topic: string;
  reasoning?: string;
  keywords?: string[];
  target_audience?: string;
  site_niche?: string;
  existing_articles_count?: number;
  content_format?: string;
  angle_or_hook?: string;
  information_gain_score?: number;
}

export interface AiRoiAnalyticsData {
  summary: {
    total_published_articles: number;
    average_citable_score: number;
    total_ai_citations_estimated: number;
    ai_inclusion_rate_percent: number;
    citation_share_percent?: number;
    generative_ctr_lift_percent?: number;
    average_share_voice?: number;
    visibility_tier: string;
    standard_organic_value_usd: number;
    ai_attributed_pipeline_value_usd: number;
    monthly_value_lift_usd: number;
    multiplier_applied: number;
    projected_annual_lift_usd: number;
  };
  platform_distribution: Array<{
    platform: string;
    share_percent: number;
    color: string;
  }>;
  top_cited_articles: Array<{
    title: string;
    slug: string;
    citable_score: number;
    estimated_citations: number;
    monthly_value_usd: number;
  }>;
}

export interface GeoAuditPrompt {
  query: string;
  engines: string[];
  mentioned: boolean;
  status: string;
}

export interface GeoAuditBrandMention {
  brand: string;
  mentions: number;
}

export interface GeoAuditSource {
  source: string;
  share_percent: number;
  mentions: number;
}

export interface GeoAuditRankingKeyword {
  keyword: string;
  domain_url?: string;
  intent: string;
  position: number;
  monthly_volume: number;
  difficulty: number;
}

export interface GeoAuditSearchPerformance {
  domain: string;
  organic_keywords: number;
  est_monthly_traffic: number;
  keywords_in_top_10: number;
  google_ai_overview_references: number;
  top_ranking_keywords: GeoAuditRankingKeyword[];
}

export interface GeoAuditReport {
  status: string;
  domain: string;
  brand: string;
  visibility_score: number;
  visibility_tier: string;
  score_explanation: string;
  tested_engines: string[];
  prompts: GeoAuditPrompt[];
  brands_mentioned: GeoAuditBrandMention[];
  top_sources: GeoAuditSource[];
  search_performance: GeoAuditSearchPerformance;
  action_plan?: {
    recommended_topics: string[];
    suggested_pipeline_action: string;
  };
}

export interface SocialOpportunity {
  id: string;
  platform: "reddit" | "quora" | "meta" | "google_business";
  subreddit?: string;
  title: string;
  author?: string;
  upvotes?: number;
  comments?: number;
  views?: string;
  answers_count?: number;
  posted_at: string;
  url: string;
  target_keyword: string;
  llm_impact: string;
  ai_engines?: string[];
  recommended_angle: string;
  status: "new" | "active" | "drafted";
}

export interface SocialPresenceData {
  status: string;
  monitored_keywords_count: number;
  daily_opportunities_count: number;
  ai_citation_lift_potential: string;
  opportunities: SocialOpportunity[];
  platforms_breakdown: Record<string, number>;
}


export interface KeywordCandidate {
  id: string;
  website_id: string;
  keyword: string;
  source: "own_site_gsc" | "competitor_gap" | "seed_expansion" | "paa_question" | string;
  opportunity_type: "striking_distance" | "competitor_gap" | "seed_expansion" | "paa_question" | "cannibalization" | string;
  search_volume: number;
  cpc: number;
  keyword_difficulty: number;
  search_intent: "informational" | "commercial" | "transactional" | "navigational" | string;
  ai_search_volume: number;
  serp_features: string[];
  avg_position?: number;
  impressions?: number;
  ctr?: number;
  cannibalizing_urls?: string[];
  opportunity_score: number;
  attainability_status?: "attainable" | "stretch" | "out_of_reach" | string;
  kd_delta_from_reach?: number;
  expected_clicks?: number;
  feasibility?: number;
  business_fit?: number;
  freshness_factor?: number;
  cluster_id?: string;
  status: "candidate" | "approved" | "scheduled" | "published" | "ignored" | string;
  created_at: string;
  updated_at?: string;
}

export interface KeywordSeed {
  id: string;
  website_id: string;
  seed_text: string;
  source: "brand_profile" | "gsc" | "competitor" | "llm_suggested" | string;
  approved: boolean;
  created_at: string;
}

export interface EmpiricalReach {
  website_id: string;
  median_kd: number;
  p75_kd: number;
  top10_keywords_count: number;
  sample_keywords: string[];
  is_new_site: boolean;
  calibrated_at?: string;
}

export interface KeywordCluster {
  id: string;
  website_id: string;
  cluster_name: string;
  primary_keyword: string;
  supporting_keywords: string[];
  shared_urls_count: number;
  intent: string;
  aggregate_volume: number;
  cluster_score: number;
  action: "new" | "refresh" | "consolidate" | string;
  target_url?: string;
  cannibalizing_urls?: string[];
  reason?: string;
  candidates_count?: number;
  created_at?: string;
  updated_at?: string;
}

export interface ContentPlanItem {
  id: string;
  website_id: string;
  cluster_id?: string;
  action: "new" | "refresh" | "consolidate" | string;
  target_keyword: string;
  supporting_keywords: string[];
  intent: string;
  score: number;
  expected_clicks: number;
  business_fit: number;
  feasibility: number;
  reason: string;
  target_url?: string;
  cannibalizing_urls?: string[];
  status: "planned" | "scheduled" | "drafting" | "published" | "rejected" | string;
  scheduled_date?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BriefSection {
  heading: string;
  level: number;
  intent_goal: string;
  answer_first_guidance?: string;
  required_entities: string[];
  required_statistics_or_claims: string[];
  notes?: string;
}

export interface ContentBrief {
  primary_keyword: string;
  intent: string;
  target_reader: string;
  unique_angle: string;
  required_sections: BriefSection[];
  required_entities: string[];
  questions_to_answer: Array<{
    question: string;
    answer_first_form: string;
    opportunity_type?: string;
  }>;
  claims_needing_sources: string[];
  internal_link_candidates: Array<{
    title: string;
    slug: string;
    target_url?: string;
    context?: string;
  }>;
  schema_plan: string[];
  word_count_range: {
    min: number;
    max: number;
    target_median: number;
    guidance?: string;
  };
  serp_summary?: Record<string, any>;
}

export interface StyleProfile {
  website_id: string;
  version: number;
  sentence_length_avg: number;
  sentence_length_median: number;
  person_distribution: {
    first_person: number;
    second_person: number;
    third_person: number;
  };
  banned_phrases: string[];
  preferred_phrases: string[];
  formatting_habits: {
    bullets_per_1k_words?: number;
    uses_tables?: boolean;
    uses_code_blocks?: boolean;
    uses_callouts?: boolean;
    preferred_section_depth?: string;
  };
  few_shot_exemplars: Array<{
    title?: string;
    heading: string;
    text: string;
  }>;
  status: "approved" | "pending_review" | string;
  sample_article_count: number;
  created_at?: string;
  updated_at?: string;
}

export interface EvidenceItem {
  id: string;
  website_id: string;
  title: string;
  evidence_type: "first_party_data" | "customer_example" | "expert_quote" | "original_results" | string;
  content: string;
  source_url?: string;
  author_or_expert?: string;
  status?: string;
  metadata?: Record<string, any>;
  created_at?: string;
}

export interface StructuredDraftSection {
  heading: string;
  level: number;
  markdown_content: string;
  word_count: number;
  direct_answer?: string;
  claims: Array<{
    claim_text: string;
    source_url?: string;
    anchor_text?: string;
    citation_type: string;
  }>;
  citations: Array<{ url: string; title?: string }>;
  key_entities_covered: string[];
  evidence_used: string[];
}

export interface StructuredDraft {
  title: string;
  slug: string;
  meta_description: string;
  sections: StructuredDraftSection[];
  total_word_count: number;
  evidence_items_used: string[];
  prompt_versions: Record<string, string>;
  model_used: string;
  critique_score?: number;
}

export interface ModelRouterConfig {
  drafting_model: { role: string; provider: string; model: string };
  critic_model: { role: string; provider: string; model: string };
  verification_model: { role: string; provider: string; model: string };
  require_evidence_pack: boolean;
  max_critique_loops: number;
}

export interface PublishModeInfo {
  id: string;
  name: string;
  default: string;
  is_default: boolean;
  unattended_stages: string[];
  conditions: string;
  status: string;
  recommended: boolean;
}

export interface PublishModesResponse {
  success: boolean;
  active_mode: string;
  active_config: Record<string, any>;
  modes: PublishModeInfo[];
  regulatory_governance: {
    google_oct_2026: string;
    google_sept_2026_spam: string;
    eu_ai_act_art_50: string;
    editorial_positioning: string;
    marketing_rule: string;
  };
}

export interface PublishExecutionResult {
  success: boolean;
  cms_item_id: string;
  cms_type: string;
  published_url: string;
  preview_url?: string;
  status: string;
  dedupe_key?: string;
  post_publish_checks?: Record<string, any>;
  error?: string;
}



