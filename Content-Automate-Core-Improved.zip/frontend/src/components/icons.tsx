import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

const base = (size: number, props: SVGProps<SVGSVGElement>) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  ...props,
});

export const IconLogo = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M4 7h6l2 10h6" />
    <path d="M8 7v0" />
    <circle cx="6" cy="7" r="2" />
    <circle cx="18" cy="17" r="2" />
  </svg>
);

export const IconHome = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M3 11.5 12 4l9 7.5" />
    <path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9" />
  </svg>
);

export const IconGlobe = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18" />
    <path d="M12 3a14 14 0 0 1 0 18" />
    <path d="M12 3a14 14 0 0 0 0 18" />
  </svg>
);

export const IconDoc = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M7 3h7l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" />
    <path d="M14 3v5h5" />
    <path d="M9 13h6" />
    <path d="M9 17h4" />
  </svg>
);

export const IconList = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M8 6h13" />
    <path d="M8 12h13" />
    <path d="M8 18h13" />
    <circle cx="4" cy="6" r="1" />
    <circle cx="4" cy="12" r="1" />
    <circle cx="4" cy="18" r="1" />
  </svg>
);

export const IconDraft = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M14 3h-9v18h14V8z" />
    <path d="M14 3v5h5" />
    <path d="M9 13h6" />
    <path d="M9 17h4" />
  </svg>
);

export const IconCheckCircle = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="9" />
    <path d="m8.5 12.5 2.5 2.5 4.5-5.5" />
  </svg>
);

export const IconClock = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </svg>
);

export const IconInbox = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M3 13h4l2 3h6l2-3h4" />
    <path d="M3 13V6a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v7" />
    <path d="M3 13v6a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-6" />
  </svg>
);

export const IconChart = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M4 20V10" />
    <path d="M10 20V4" />
    <path d="M16 20v-7" />
    <path d="M22 20H2" />
  </svg>
);

export const IconSettings = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" />
  </svg>
);

export const IconSearch = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

export const IconBell = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8" />
    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
  </svg>
);

export const IconSun = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
  </svg>
);

export const IconMoon = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
  </svg>
);

export const IconChevronDown = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="m6 9 6 6 6-6" />
  </svg>
);

export const IconChevronRight = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="m9 6 6 6-6 6" />
  </svg>
);

export const IconChevronLeft = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="m15 6-6 6 6 6" />
  </svg>
);

export const IconPlus = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconClose = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M18 6 6 18M6 6l12 12" />
  </svg>
);

export const IconCalendar = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <path d="M16 3v4M8 3v4M3 10h18" />
  </svg>
);

export const IconSparkle = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" />
  </svg>
);

export const IconArrowUp = ({ size = 14, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="m6 14 6-6 6 6" />
  </svg>
);

export const IconArrowRight = ({ size = 14, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

export const IconMenu = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

export const IconRefresh = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M21 12a9 9 0 1 1-3-6.7L21 8" />
    <path d="M21 3v5h-5" />
  </svg>
);

export const IconPause = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <rect x="6" y="5" width="4" height="14" rx="1" />
    <rect x="14" y="5" width="4" height="14" rx="1" />
  </svg>
);

export const IconPlay = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M7 5v14l12-7Z" />
  </svg>
);

export const IconEdit = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4Z" />
  </svg>
);

export const IconTrash = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M3 6h18" />
    <path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2" />
    <path d="M19 6 18 20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1L5 6" />
  </svg>
);

export const IconExternalLink = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M15 3h6v6" />
    <path d="M10 14 21 3" />
    <path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5" />
  </svg>
);

export const IconCircle = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="12" cy="12" r="9" />
  </svg>
);

export const IconCheck = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="m5 12 5 5L20 7" />
  </svg>
);

export const IconX = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M18 6 6 18M6 6l12 12" />
  </svg>
);

export const IconDots = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <circle cx="5" cy="12" r="1" />
    <circle cx="12" cy="12" r="1" />
    <circle cx="19" cy="12" r="1" />
  </svg>
);

export const IconFilter = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M3 5h18l-7 9v6l-4-2v-4Z" />
  </svg>
);

export const IconSlack = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <rect x="3" y="9" width="6" height="2" rx="1" />
    <rect x="9" y="3" width="2" height="6" rx="1" />
    <rect x="15" y="13" width="6" height="2" rx="1" />
    <rect x="13" y="15" width="2" height="6" rx="1" />
    <rect x="9" y="9" width="6" height="6" rx="1.5" />
  </svg>
);

export const IconBolt = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M13 2 4 14h7l-1 8 9-12h-7Z" />
  </svg>
);

export const IconLink = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1" />
    <path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1" />
  </svg>
);

export const IconShield = ({ size = 18, ...rest }: IconProps) => (
  <svg {...base(size, rest)}>
    <path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6Z" />
  </svg>
);