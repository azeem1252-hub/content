import type { ReactNode } from "react";
import { Button } from "./ui";

interface Props {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
}

export function EmptyState({ icon, title, description, action }: Props) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      {icon && (
        <div
          className="flex h-11 w-11 items-center justify-center rounded-xl"
          style={{
            background: "var(--color-bg-soft)",
            color: "var(--color-text-muted)",
          }}
          aria-hidden="true"
        >
          {icon}
        </div>
      )}
      <div className="mt-1 text-sm font-semibold text-[var(--color-text)]">{title}</div>
      {description && (
        <div className="max-w-sm text-[13px] leading-relaxed text-[var(--color-text-muted)]">
          {description}
        </div>
      )}
      {action && (
        <Button variant="primary" size="sm" onClick={action.onClick} className="mt-2">
          {action.label}
        </Button>
      )}
    </div>
  );
}
