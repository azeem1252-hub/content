interface Props {
  name: string;
  size?: number;
  color?: string;
  src?: string;
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

function hashColor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
  const colors = [
    "#0F8A65",
    "#2F6FE0",
    "#B7791F",
    "#8E5BD8",
    "#C0392B",
    "#0E7C7B",
    "#475569",
  ];
  return colors[Math.abs(h) % colors.length];
}

export function Avatar({ name, size = 28, color, src }: Props) {
  const bg = color ?? hashColor(name);
  return (
    <div
      className="flex shrink-0 select-none items-center justify-center rounded-full font-semibold text-white shadow-[var(--shadow-soft)]"
      style={{
        width: size,
        height: size,
        background: bg,
        fontSize: size * 0.38,
      }}
      aria-hidden="true"
    >
      {src ? (
        <img src={src} alt={name} className="h-full w-full rounded-full object-cover" />
      ) : (
        initials(name)
      )}
    </div>
  );
}
