import type { ReactNode } from "react";

interface Props {
  icon: ReactNode;
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  iconBg?: string;
  iconColor?: string;
}

export function MetricCard({ icon, label, value, hint, iconBg, iconColor }: Props) {
  return (
    <div
      className="rounded-xl border bg-[var(--color-bg-elev)] p-5 shadow-[var(--shadow-card)] transition-all duration-200 hover:shadow-[var(--shadow-card-hover)]"
      style={{ borderColor: "var(--color-border)" }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-medium text-[var(--color-text-muted)]">{label}</div>
          <div className="tabular-numbers mt-2 text-[28px] font-bold leading-none tracking-tight text-[var(--color-text)]">
            {value}
          </div>
          {hint && (
            <div className="mt-2.5 flex items-center gap-1.5 text-[11px] text-[var(--color-text-subtle)]">
              {hint}
            </div>
          )}
        </div>
        <div
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
          style={{
            background: iconBg ?? "var(--color-accent-soft)",
            color: iconColor ?? "var(--color-accent-text)",
          }}
          aria-hidden="true"
        >
          {icon}
        </div>
      </div>
    </div>
  );
}
