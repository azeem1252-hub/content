import { getWebsiteById } from "../../lib/data";
import type { ContentItem } from "../../lib/types";
import { Button } from "../ui/Button";
import { Pill } from "../ui/Primitives";
import { cleanMarkdown } from "../../utils/cleanMarkdown";
import {
  IconArrowRight,
  IconDoc,
  IconX,
} from "../icons";

export function ReviewCard({
  item,
  onApprove,
  onReject,
  onOpen,
  compact,
}: {
  item: ContentItem;
  onApprove: () => void;
  onReject: () => void;
  onOpen: () => void;
  compact?: boolean;
}) {
  const website = getWebsiteById(item.websiteId);
  return (
    <div className="group rounded-2xl border border-app bg-surface shadow-card transition-all duration-200 hover:shadow-soft hover:border-strong">
      <button
        onClick={onOpen}
        className="block w-full text-left px-5 pt-5"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="text-[14.5px] font-semibold tracking-tight text-app truncate">
                {cleanMarkdown(item.title)}
              </h4>
            </div>
            <div className="mt-1 flex items-center gap-2 text-[12px] text-muted">
              {website && (
                <>
                  <span className="inline-flex h-4 w-4 items-center justify-center rounded bg-muted-soft text-[9px] font-semibold text-app">
                    {website.name.charAt(0)}
                  </span>
                  <span className="truncate">{website.name}</span>
                  <span>·</span>
                </>
              )}
              <span>Awaiting approval</span>
              <span>·</span>
              <span>{item.createdAt}</span>
            </div>
          </div>
          <Pill tone="brand">{item.seo} SEO</Pill>
        </div>
        {!compact && (
          <p className="mt-3 line-clamp-2 text-[12.5px] leading-relaxed text-muted">
            {cleanMarkdown(item.excerpt)}
          </p>
        )}
      </button>
      <div className="flex items-center justify-between gap-2 px-5 py-4">
        <div className="flex items-center gap-1.5 text-[11px] text-subtle font-mono">
          <IconDoc size={11} />
          <span>Pipeline draft</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onReject();
            }}
            iconLeft={<IconX size={12} />}
          >
            Reject
          </Button>
          <Button
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onApprove();
            }}
            iconRight={<IconArrowRight size={12} />}
          >
            Approve
          </Button>
        </div>
      </div>
    </div>
  );
}