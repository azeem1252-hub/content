import { Button } from "../ui/Button";
import { IconCheck, IconExternalLink, IconSparkle, IconX } from "../icons";

export function SlackPreview() {
  return (
    <div className="overflow-hidden rounded-2xl border border-app bg-surface shadow-card">
      <div className="flex items-center justify-between gap-3 border-b border-app px-5 py-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[color:var(--brand-soft)] text-[color:var(--brand-soft-text)]">
            <IconSparkle size={14} />
          </div>
          <div>
            <h3 className="text-[14.5px] font-semibold tracking-tight text-app">
              Slack Review
            </h3>
            <p className="text-[12px] text-muted">
              Approval requests arrive in Slack when content is ready.
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-md bg-brand-soft px-2 py-1 text-[11px] font-medium">
          <span className="h-1.5 w-1.5 rounded-full bg-[color:var(--brand)]" />
          Connected
        </span>
      </div>
      <div className="px-5 py-5">
        <p className="text-[12.5px] text-muted">
          When content needs approval, an interactive card is sent to your
          Slack channel. You can review and approve from anywhere — even your
          phone.
        </p>

        <div className="mt-4 rounded-xl border border-app bg-muted-soft/40 p-4">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-[color:var(--brand-soft)] text-[10px] font-semibold text-[color:var(--brand-soft-text)]">
              CP
            </div>
            <div className="text-[12px] font-semibold text-app">
              Content Pipeline
            </div>
            <span className="text-[11px] text-subtle">APP</span>
            <span className="text-[11px] text-subtle">· 9:42 AM</span>
          </div>
          <div className="mt-2 text-[12.5px] text-muted">
            <span className="font-medium text-app">Azeem Khan</span>, an article
            is ready for your review.
          </div>

          <div className="mt-3 rounded-lg border-l-4 border-[color:var(--brand)] bg-surface p-3.5 shadow-card">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[13px] font-semibold text-app">
                  Next.js Performance Guide
                </div>
                <div className="mt-0.5 text-[11.5px] text-muted">
                  Dev Agency · AI-generated draft
                </div>
              </div>
              <span className="shrink-0 rounded-md bg-brand-soft px-1.5 py-0.5 text-[10.5px] font-semibold text-[color:var(--brand-soft-text)]">
                SEO 96
              </span>
            </div>
            <div className="mt-2 text-[12px] text-muted line-clamp-2">
              A focused checklist of high-leverage Next.js performance
              optimizations — from caching strategy to image loading and edge
              rendering.
            </div>
            <div className="mt-3 flex items-center gap-2">
              <button className="inline-flex items-center gap-1 rounded-md bg-[color:var(--brand)] px-2.5 py-1 text-[11.5px] font-medium text-white hover:bg-[color:var(--brand-hover)] transition-colors">
                <IconCheck size={12} /> Approve
              </button>
              <button className="inline-flex items-center gap-1 rounded-md border border-app bg-surface px-2.5 py-1 text-[11.5px] font-medium text-app hover:bg-muted-soft transition-colors">
                <IconX size={12} /> Request changes
              </button>
              <button className="inline-flex items-center gap-1 text-[11.5px] text-muted hover:text-app transition-colors">
                <IconExternalLink size={12} /> Open in dashboard
              </button>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm">
            Configure Slack
          </Button>
          <Button variant="ghost" size="sm">
            Test approval
          </Button>
        </div>
      </div>
    </div>
  );
}