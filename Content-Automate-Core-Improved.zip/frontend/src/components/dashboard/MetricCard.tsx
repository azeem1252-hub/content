import type { ReactNode } from "react";
import { IconArrowUp } from "../icons";
import { cn } from "../../utils/cn";

type Tone = "brand" | "info" | "warn" | "neutral";

const tones: Record<Tone, string> = {
  brand: "bg-brand-soft text-[color:var(--brand-soft-text)]",
  info: "bg-info-soft text-[color:var(--info-soft-text)]",
  warn: "bg-warn-soft text-[color:var(--warn-soft-text)]",
  neutral: "bg-muted-soft text-muted",
};

export function MetricCard({
  label,
  value,
  description,
  icon,
  tone = "neutral",
  trend,
  onClick,
}: {
  label: string;
  value: string | number;
  description?: string;
  icon: ReactNode;
  tone?: Tone;
  trend?: { label: string; direction?: "up" | "down" | "flat" };
  onClick?: () => void;
}) {
  const Tag: any = onClick ? "button" : "div";
  return (
    <Tag
      onClick={onClick}
      className={cn(
        "w-full text-left rounded-2xl border bg-surface border-app p-5 shadow-card transition-all duration-200",
        onClick && "hover:-translate-y-0.5 hover:shadow-soft"
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[12px] font-medium text-muted">{label}</div>
          <div className="mt-2 text-[28px] font-semibold tracking-tight text-app">
            {value}
          </div>
          {description && (
            <div className="mt-1 text-[12px] text-muted">{description}</div>
          )}
        </div>
        <div
          className={cn(
            "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
            tones[tone]
          )}
        >
          {icon}
        </div>
      </div>
      {trend && (
        <div className="mt-3 flex items-center gap-1.5 text-[11.5px]">
          {trend.direction && trend.direction !== "flat" && (
            <span
              className={cn(
                "inline-flex items-center gap-0.5 rounded-md px-1.5 py-0.5 text-[10.5px] font-medium",
                trend.direction === "up"
                  ? "bg-brand-soft text-[color:var(--brand-soft-text)]"
                  : "bg-danger-soft text-[color:var(--danger-soft-text)]"
              )}
            >
              <IconArrowUp
                size={10}
                className={cn(
                  trend.direction === "down" && "rotate-180"
                )}
              />
              {trend.label}
            </span>
          )}
          {trend.direction === "flat" && (
            <span className="inline-flex items-center rounded-md bg-muted-soft px-1.5 py-0.5 text-[10.5px] font-medium text-muted">
              {trend.label}
            </span>
          )}
        </div>
      )}
    </Tag>
  );
}