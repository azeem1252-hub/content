import { activity, getWebsiteById } from "../../lib/data";
import { cn } from "../../utils/cn";
import { cleanMarkdown } from "../../utils/cleanMarkdown";
import {
  IconArrowRight,
  IconCheck,
  IconDoc,
  IconExternalLink,
  IconPlus,
  IconRefresh,
  IconX,
} from "../icons";

const iconFor: Record<string, { Icon: typeof IconCheck; cls: string }> = {
  approved: { Icon: IconCheck, cls: "bg-brand-soft text-[color:var(--brand-soft-text)]" },
  published: { Icon: IconExternalLink, cls: "bg-brand-soft text-[color:var(--brand-soft-text)]" },
  draft: { Icon: IconDoc, cls: "bg-info-soft text-[color:var(--info-soft-text)]" },
  rejected: { Icon: IconX, cls: "bg-danger-soft text-[color:var(--danger-soft-text)]" },
  schedule: { Icon: IconRefresh, cls: "bg-muted-soft text-muted" },
  connected: { Icon: IconPlus, cls: "bg-info-soft text-[color:var(--info-soft-text)]" },
};

const labelFor: Record<string, string> = {
  approved: "Approved",
  published: "Published",
  draft: "Draft generated",
  rejected: "Sent back",
  schedule: "Schedule",
  connected: "Connected",
};

export function ActivityFeed({ limit }: { limit?: number }) {
  const items = limit ? activity.slice(0, limit) : activity;
  return (
    <div className="rounded-2xl border border-app bg-surface shadow-card">
      <div className="flex items-center justify-between border-b border-app px-5 py-4">
        <div>
          <h3 className="text-[14.5px] font-semibold tracking-tight text-app">
            Recent Activity
          </h3>
          <p className="mt-0.5 text-[12px] text-muted">
            What's been happening across your pipeline.
          </p>
        </div>
        <button className="text-[12px] font-medium text-muted hover:text-app transition-colors inline-flex items-center gap-1">
          View all <IconArrowRight size={12} />
        </button>
      </div>
      <ul className="divide-y divide-[color:var(--border)]">
        {items.map((a) => {
          const { Icon, cls } = iconFor[a.type] || iconFor.schedule;
          const site = a.websiteId ? getWebsiteById(a.websiteId) : null;
          return (
            <li
              key={a.id}
              className="flex items-start gap-3 px-5 py-3.5 transition-colors hover:bg-muted-soft/40"
            >
              <div
                className={cn(
                  "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg",
                  cls
                )}
              >
                <Icon size={14} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-[12.5px] font-medium text-app">
                    {labelFor[a.type]}
                  </span>
                  <span className="text-[12.5px] text-app truncate">
                    {cleanMarkdown(a.title)}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center gap-2 text-[11.5px] text-muted">
                  {site && <span>{site.name}</span>}
                  {site && a.detail && <span>·</span>}
                  {a.detail && <span className="truncate">{a.detail}</span>}
                </div>
              </div>
              <div className="shrink-0 text-[11px] text-subtle whitespace-nowrap pt-0.5">
                {a.at}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}