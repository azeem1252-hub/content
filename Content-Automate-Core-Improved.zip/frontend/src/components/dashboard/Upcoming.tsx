import { getWebsiteById, upcoming } from "../../lib/data";
import { IconCalendar, IconClock } from "../icons";
import { Button } from "../ui/Button";

export function Upcoming({ limit }: { limit?: number }) {
  const items = limit ? upcoming.slice(0, limit) : upcoming;

  return (
    <div className="rounded-2xl border border-app bg-surface shadow-card">
      <div className="flex items-center justify-between border-b border-app px-5 py-4">
        <div>
          <h3 className="text-[14.5px] font-semibold tracking-tight text-app">
            Upcoming
          </h3>
          <p className="mt-0.5 text-[12px] text-muted">
            Articles that will publish next.
          </p>
        </div>
        <Button variant="ghost" size="sm">
          View schedule
        </Button>
      </div>
      <ol className="relative px-5 py-3">
        <div className="absolute left-[34px] top-5 bottom-5 w-px bg-[color:var(--border)]" />
        {items.map((it) => {
          const website = getWebsiteById(it.websiteId);
          return (
            <li
              key={it.id}
              className="relative flex gap-3 py-3 transition-colors hover:bg-muted-soft/40 -mx-2 px-2 rounded-lg"
            >
              <div className="relative flex flex-col items-center">
                <div className="z-10 mt-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-[color:var(--bg)] bg-[color:var(--brand)]">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                </div>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <div className="text-[13.5px] font-semibold text-app truncate">
                    {it.title}
                  </div>
                  <div className="shrink-0 text-[11px] text-subtle tabular-nums">
                    {it.when}, {it.time}
                  </div>
                </div>
                <div className="mt-1 flex items-center gap-2 text-[12px] text-muted">
                  {website && (
                    <>
                      <span>{website.name}</span>
                      <span>·</span>
                    </>
                  )}
                  <span className="inline-flex items-center gap-1">
                    {it.kind === "AI-generated draft" ? (
                      <IconClock size={11} />
                    ) : (
                      <IconCalendar size={11} />
                    )}
                    {it.kind}
                  </span>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}