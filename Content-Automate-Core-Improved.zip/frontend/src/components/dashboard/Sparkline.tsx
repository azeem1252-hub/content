import { cn } from "../../utils/cn";

export function Sparkline({
  data,
  height = 60,
  className,
  fillOpacity = 0.12,
}: {
  data: number[];
  height?: number;
  className?: string;
  fillOpacity?: number;
}) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 100;
  const step = w / (data.length - 1);

  const points = data
    .map((v, i) => {
      const x = i * step;
      const y = height - ((v - min) / range) * (height - 6) - 3;
      return `${x},${y}`;
    })
    .join(" ");

  const areaPath = `M0,${height} L${points.split(" ").join(" L")} L${w},${height} Z`;

  return (
    <svg
      viewBox={`0 0 ${w} ${height}`}
      preserveAspectRatio="none"
      className={cn("w-full", className)}
    >
      <defs>
        <linearGradient id="sparkFill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--brand)" stopOpacity={fillOpacity} />
          <stop offset="100%" stopColor="var(--brand)" stopOpacity={0} />
        </linearGradient>
      </defs>
      <path d={areaPath} fill="url(#sparkFill)" />
      <polyline
        points={points}
        fill="none"
        stroke="var(--brand)"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {data.map((v, i) => {
        const x = i * step;
        const y = height - ((v - min) / range) * (height - 6) - 3;
        return (
          <circle
            key={i}
            cx={x}
            cy={y}
            r="1.6"
            fill="var(--brand)"
            className="opacity-0 transition-opacity hover:opacity-100"
          />
        );
      })}
    </svg>
  );
}

export function BarSeries({
  data,
  height = 80,
  className,
}: {
  data: { label: string; value: number }[];
  height?: number;
  className?: string;
}) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <div className={cn("w-full", className)}>
      <div
        className="flex items-end gap-2"
        style={{ height }}
      >
        {data.map((d) => (
          <div
            key={d.label}
            className="flex-1 flex flex-col items-center gap-1.5 group"
          >
            <div className="relative w-full flex flex-col items-center justify-end h-full">
              <div
                className="w-full rounded-md bg-[color:var(--brand-soft)] relative overflow-hidden transition-all group-hover:bg-[color:var(--brand)]"
                style={{
                  height: `${(d.value / max) * 100}%`,
                  minHeight: 4,
                }}
              >
                <div className="absolute inset-x-0 top-0 h-1 bg-[color:var(--brand)] opacity-60" />
              </div>
            </div>
            <span className="text-[10.5px] text-subtle">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}