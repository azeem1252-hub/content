import { pipelineStats } from "../../lib/data";
import type { PipelineStat } from "../../lib/types";
import { cn } from "../../utils/cn";

const stageColors: Record<string, string> = {
  ideas: "bg-[color:var(--text-subtle)]",
  drafting: "bg-[color:var(--info)]",
  "seo-check": "bg-[color:var(--warn)]",
  review: "bg-[color:var(--brand)]",
  published: "bg-[color:var(--brand)]",
};

export function PipelineProgress({ stats = pipelineStats }: { stats?: PipelineStat[] }) {
  const total = stats.reduce((s, x) => s + x.count, 0) || 1;
  return (
    <div className="rounded-2xl border border-app bg-surface p-5 shadow-card">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h3 className="text-[15px] font-semibold tracking-tight text-app">
            Pipeline Activity
          </h3>
          <p className="mt-1 text-[12.5px] text-muted">
            Where every article currently sits in the pipeline.
          </p>
        </div>
        <div className="text-[12px] text-muted">
          {stats.reduce((s, x) => s + x.count, 0)} items total
        </div>
      </div>

      <div className="mt-5 flex items-center gap-1 overflow-x-auto pb-1">
        {stats.map((s, idx) => (
          <div key={s.stage} className="flex flex-1 min-w-0 items-center">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span
                  className={cn(
                    "h-2 w-2 rounded-full shrink-0",
                    stageColors[s.stage]
                  )}
                />
                <span className="text-[12px] font-medium text-app truncate">
                  {s.label}
                </span>
                <span className="ml-auto text-[12px] text-muted tabular-nums">
                  {s.count}
                </span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted-soft">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-500",
                    stageColors[s.stage]
                  )}
                  style={{ width: `${(s.count / total) * 100}%` }}
                />
              </div>
            </div>
            {idx < stats.length - 1 && (
              <span className="mx-2 text-subtle shrink-0">→</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}