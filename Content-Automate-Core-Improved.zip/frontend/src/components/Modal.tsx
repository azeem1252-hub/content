import { useEffect, type ReactNode } from "react";
import { X } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  footer?: ReactNode;
}

const sizes = {
  sm: "max-w-sm",
  md: "max-w-lg",
  lg: "max-w-2xl",
  xl: "max-w-4xl",
  "2xl": "max-w-5xl",
};

export function Modal({ open, onClose, title, description, children, size = "md", footer }: Props) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div
        className="fixed inset-0 animate-fadeIn"
        style={{ background: "var(--color-overlay)" }}
        onClick={onClose}
      />
      <div
        className={`relative z-10 w-full ${sizes[size]} max-h-[calc(100vh-1.5rem)] sm:max-h-[min(92vh,860px)] flex flex-col animate-scaleIn rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-pop)] overflow-hidden my-auto`}
        style={{ borderColor: "var(--color-border)" }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        {(title || description) && (
          <div
            className="shrink-0 flex items-start justify-between gap-4 border-b px-5 py-4"
            style={{ borderColor: "var(--color-border)" }}
          >
            <div className="min-w-0">
              {title && (
                <h2 className="text-base font-semibold tracking-tight text-[var(--color-text)]">
                  {title}
                </h2>
              )}
              {description && (
                <p className="mt-0.5 text-[13px] text-[var(--color-text-muted)]">
                  {description}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl p-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-bg-soft)] border border-[var(--color-border)] transition cursor-pointer shrink-0 shadow-xs"
              aria-label="Close modal"
              title="Close (Esc)"
            >
              <X size={18} className="stroke-[2.5]" />
            </button>
          </div>
        )}
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && (
          <div
            className="shrink-0 flex items-center justify-end gap-2 border-t bg-[var(--color-bg-soft)]/50 px-5 py-3"
            style={{ borderColor: "var(--color-border)" }}
          >
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
