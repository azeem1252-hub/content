import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Studio render error:", error, errorInfo);
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div
          style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            background: "#080C14",
            color: "#F8FAFC",
            fontFamily: "system-ui, -apple-system, sans-serif",
            padding: "24px",
            textAlign: "center",
          }}
        >
          <div
            style={{
              maxWidth: "520px",
              width: "100%",
              background: "#0E1420",
              border: "1px solid rgba(255, 255, 255, 0.1)",
              borderRadius: "16px",
              padding: "32px",
              boxShadow: "0 20px 50px rgba(0, 0, 0, 0.5)",
            }}
          >
            <div
              style={{
                width: "48px",
                height: "48px",
                borderRadius: "12px",
                background: "rgba(239, 68, 68, 0.15)",
                color: "#EF4444",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 16px auto",
                fontSize: "20px",
                fontWeight: "bold",
              }}
            >
              !
            </div>
            <h2 style={{ fontSize: "18px", fontWeight: "700", margin: "0 0 8px 0" }}>
              Studio Render Error
            </h2>
            <div
              style={{
                color: "#F87171",
                fontSize: "13px",
                lineHeight: "1.6",
                margin: "0 0 12px 0",
                fontWeight: "600",
                wordBreak: "break-word",
              }}
            >
              {this.state.error?.message || "An unexpected error occurred while rendering the page."}
            </div>
            {this.state.error?.stack && (
              <pre
                style={{
                  color: "#94A3B8",
                  fontSize: "11px",
                  lineHeight: "1.4",
                  maxHeight: "180px",
                  overflowY: "auto",
                  background: "#080C14",
                  padding: "12px",
                  borderRadius: "8px",
                  textAlign: "left",
                  margin: "0 0 20px 0",
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-all",
                }}
              >
                {this.state.error.stack}
              </pre>
            )}
            <button
              onClick={() => window.location.reload()}
              style={{
                background: "var(--color-accent)",
                color: "#F4F1E9",
                border: "none",
                borderRadius: "0px",
                padding: "10px 24px",
                fontSize: "13px",
                fontWeight: "600",
                cursor: "pointer",
                boxShadow: "0 2px 10px rgba(99, 102, 241, 0.3)",
              }}
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
