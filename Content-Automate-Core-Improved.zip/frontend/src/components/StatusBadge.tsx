import type { ReactNode } from "react";
import type { ContentStatus } from "../types";

interface Props {
  status: ContentStatus | "Idea" | "Active" | "Paused" | "Connected" | "Syncing" | "Disconnected";
  size?: "sm" | "md";
  dot?: boolean;
  children?: ReactNode;
}

const colorMap: Record<string, { bg: string; text: string; dot: string; live?: boolean }> = {
  Idea: { bg: "var(--color-bg-soft)", text: "var(--color-text-muted)", dot: "var(--color-text-subtle)" },
  Drafting: { bg: "var(--color-info-soft)", text: "var(--color-info)", dot: "var(--color-info)", live: true },
  "SEO Check": { bg: "var(--color-info-soft)", text: "var(--color-info)", dot: "var(--color-info)", live: true },
  "Awaiting Approval": { bg: "var(--color-warn-soft)", text: "var(--color-warn)", dot: "var(--color-warn)" },
  Scheduled: { bg: "var(--color-accent-soft)", text: "var(--color-accent-text)", dot: "var(--color-accent)" },
  Published: { bg: "var(--color-live-soft)", text: "var(--color-live)", dot: "var(--color-live)" },
  Failed: { bg: "var(--color-danger-soft)", text: "var(--color-danger)", dot: "var(--color-danger)" },
  Active: { bg: "var(--color-live-soft)", text: "var(--color-live)", dot: "var(--color-live)", live: true },
  Paused: { bg: "var(--color-bg-soft)", text: "var(--color-text-muted)", dot: "var(--color-text-subtle)" },
  Connected: { bg: "var(--color-live-soft)", text: "var(--color-live)", dot: "var(--color-live)" },
  Syncing: { bg: "var(--color-info-soft)", text: "var(--color-info)", dot: "var(--color-info)", live: true },
  Disconnected: { bg: "var(--color-danger-soft)", text: "var(--color-danger)", dot: "var(--color-danger)" },
};

export function StatusBadge({ status, size = "sm", dot = true, children }: Props) {
  const c = colorMap[status] ?? colorMap.Idea;
  const padding = size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-current/10 font-medium ${padding}`}
      style={{ background: c.bg, color: c.text }}
    >
      {dot && (
        <span
          className={`inline-block h-[7px] w-[7px] shrink-0 rounded-full ${c.live ? "animate-pulseDot" : ""}`}
          style={{ background: c.dot }}
          aria-hidden="true"
        />
      )}
      <span className="whitespace-nowrap">{children ?? status}</span>
    </span>
  );
}
