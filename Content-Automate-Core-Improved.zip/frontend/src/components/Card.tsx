import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";

interface Props extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  padded?: boolean;
  hoverable?: boolean;
}

export function Card({ children, className, padded = true, hoverable, ...rest }: Props) {
  return (
    <div
      className={cn(
        "rounded-xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)]",
        hoverable && "transition-all duration-200 hover:shadow-[var(--shadow-card-hover)] hover:border-[var(--color-border-strong)] hover:-translate-y-0.5",
        className
      )}
      style={{ borderColor: "var(--color-border)" }}
      {...rest}
    >
      {padded ? <div className="p-5 sm:p-6">{children}</div> : children}
    </div>
  );
}

export function CardHeader({
  title,
  subtitle,
  action,
  className,
}: {
  title: ReactNode;
  subtitle?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("mb-4 flex items-start justify-between gap-3", className)}>
      <div className="min-w-0">
        <h3 className="text-[15px] font-semibold tracking-tight text-[var(--color-text)]">
          {title}
        </h3>
        {subtitle && (
          <p className="mt-0.5 text-[13px] text-[var(--color-text-muted)]">
            {subtitle}
          </p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}
