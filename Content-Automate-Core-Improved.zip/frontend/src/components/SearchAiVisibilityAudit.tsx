import { useState, useEffect, useMemo } from "react";
import {
  Globe,
  Share2,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Search,
  ExternalLink,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  FileText,
  Zap,
  ArrowRight,
  Check,
  Copy,
  X,
  Layers,
  HelpCircle,
  Database,
  LayoutGrid,
  Terminal,
  Award,
} from "lucide-react";
import type { GeoAuditReport, GeoAuditPrompt } from "../types";
import { api } from "../lib/api";
import { useToast } from "../lib/toast";
import { useNav } from "../lib/nav";
import { usePipelineData } from "../lib/dataContext";
import { cn } from "../utils/cn";

interface Props {
  initialDomain?: string;
  onClose?: () => void;
  inline?: boolean;
}

export function SearchAiVisibilityAudit({ initialDomain, onClose, inline = false }: Props) {
  const { push } = useToast();
  const { openLaunchModal } = useNav();
  const { websites } = usePipelineData();

  const defaultSite = websites.find((w) => w.is_default) || websites[0];
  const resolvedInitialDomain = useMemo(() => {
    if (initialDomain) return initialDomain;
    if (defaultSite?.url) {
      return defaultSite.url.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    }
    return "filemint.dev";
  }, [initialDomain, defaultSite]);

  const [domainInput, setDomainInput] = useState(resolvedInitialDomain);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<GeoAuditReport | null>(null);
  const [expandedPromptIdx, setExpandedPromptIdx] = useState<number | null>(null);
  const [selectedEngineFilter, setSelectedEngineFilter] = useState<string>("all");
  const [activeSubTab, setActiveSubTab] = useState<"overview" | "prompts" | "brands" | "sources">("overview");
  const [copiedShare, setCopiedShare] = useState(false);

  const sampleDomains = useMemo(() => {
    const list: Array<{ domain: string; label: string; brand: string }> = [];
    websites.forEach((w) => {
      const clean = w.url.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
      if (clean && !list.some((item) => item.domain === clean)) {
        list.push({ domain: clean, label: `${w.name} (Your Site)`, brand: w.name });
      }
    });
    if (!list.some((item) => item.domain === "filemint.dev")) {
      list.push({ domain: "filemint.dev", label: "Filemint (Dev Tools)", brand: "Filemint" });
    }
    if (!list.some((item) => item.domain === "linear.app")) {
      list.push({ domain: "linear.app", label: "Linear (SaaS)", brand: "Linear" });
    }
    return list;
  }, [websites]);

  const handleRunAudit = async (targetDomain: string, brand?: string) => {
    const clean = targetDomain.trim();
    if (!clean) return;
    setLoading(true);
    try {
      const res = await api.runGeoVisibilityAudit(clean, brand);
      setReport(res);
      setDomainInput(clean);
    } catch (err: any) {
      push({
        title: "Audit Failed",
        description: err.message || "Could not complete visibility audit.",
        variant: "danger",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    handleRunAudit(resolvedInitialDomain);
  }, [resolvedInitialDomain]);

  const handleShareReport = () => {
    const shareUrl = `${window.location.origin}/?audit=${encodeURIComponent(domainInput)}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2000);
    push({
      title: "Audit Report Link Copied! 📋",
      description: `Shareable link for ${report?.brand || domainInput} copied to clipboard.`,
      variant: "success",
    });
  };

  return (
    <div className={cn("w-full transition-all", inline ? "p-0" : "max-w-6xl mx-auto py-6 px-4 sm:px-6")}>
      {/* 1. Header Bar & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-[var(--color-text-subtle)]">
              View your brand's visibility and performance across AI search engines
            </span>
          </div>
          <h1 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-[var(--color-text)] flex items-center gap-2.5">
            <span className="p-1 rounded-lg bg-[var(--color-accent-soft)] text-[var(--color-accent)] inline-flex items-center justify-center">
              <Zap size={22} />
            </span>
            <span>Search &amp; AI Visibility Audit</span>
          </h1>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleShareReport}
            className="inline-flex items-center gap-1.5 rounded-xl border px-3.5 py-2 text-xs font-semibold shadow-soft transition hover:bg-[var(--color-bg-soft)] active:scale-[0.985] cursor-pointer"
            style={{ borderColor: "var(--color-border)", color: "var(--color-text)" }}
          >
            {copiedShare ? <Check size={14} className="text-emerald-500" /> : <Share2 size={14} />}
            <span>{copiedShare ? "Link Copied!" : "Share report"}</span>
          </button>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border p-2 text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] transition cursor-pointer"
              style={{ borderColor: "var(--color-border)" }}
              title="Close Audit"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {/* 2. Lead Magnet Interactive Domain Input Bar */}
      <div className="mt-6 rounded-2xl border bg-[var(--color-bg-elev)] p-5 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
        <div className="text-center sm:text-left">
          <div className="font-mono text-[10px] font-bold uppercase tracking-wider text-amber-500">
            Free GEO &amp; AEO Audit Engine
          </div>
          <h2 className="mt-1 text-lg sm:text-xl font-bold tracking-tight text-[var(--color-text)]">
            Do ChatGPT, Claude, Perplexity &amp; Gemini recommend your website?
          </h2>
        </div>

        {/* Engine Pills */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {["ChatGPT", "Claude", "Perplexity", "Gemini"].map((engine) => (
            <span
              key={engine}
              className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium bg-[var(--color-bg-soft)] text-[var(--color-text)] select-none"
              style={{ borderColor: "var(--color-border)" }}
            >
              <Sparkles size={11} className="text-[var(--color-accent)]" />
              <span>{engine}</span>
            </span>
          ))}
        </div>

        {/* Input Form with Glow Ring */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleRunAudit(domainInput);
          }}
          className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5"
        >
          <div className="relative flex-1">
            <Globe size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]" />
            <input
              type="text"
              value={domainInput}
              onChange={(e) => setDomainInput(e.target.value)}
              placeholder="e.g. filemint.dev or yourdomain.com"
              className="h-11 w-full rounded-xl border bg-[var(--color-bg-soft)] pl-10 pr-4 text-sm font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:bg-[var(--color-bg-elev)] focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)]/15"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>
          <button
            type="submit"
            disabled={loading || !domainInput.trim()}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[var(--color-text)] px-6 text-sm font-semibold text-[var(--color-bg-elev)] shadow-soft transition hover:opacity-90 active:scale-[0.985] disabled:opacity-50 cursor-pointer"
          >
            {loading ? (
              <>
                <span className="h-4 w-4 rounded-full border-2 border-[var(--color-bg-elev)] border-t-transparent animate-spin" />
                <span>Auditing LLMs…</span>
              </>
            ) : (
              <>
                <span>Run free audit</span>
                <ArrowRight size={15} />
              </>
            )}
          </button>
        </form>

        {/* Sample Demo Chips */}
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-[var(--color-text-muted)]">
          <span className="font-mono text-[10px] uppercase font-semibold">Try sample:</span>
          {sampleDomains.map((sample) => (
            <button
              key={sample.domain}
              type="button"
              onClick={() => {
                setDomainInput(sample.domain);
                handleRunAudit(sample.domain, sample.brand);
              }}
              className="rounded-lg border px-2.5 py-0.5 text-xs font-mono transition hover:border-[var(--color-accent)] hover:text-[var(--color-accent)] cursor-pointer"
              style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* 3. The Report Content */}
      {report && (
        <div className="mt-8 space-y-6 animate-fade-in">
          {/* Subtabs Bar (Matching Competitor Screenshot 4) */}
          <div className="flex items-center gap-1 border-b" style={{ borderColor: "var(--color-border)" }}>
            <button
              type="button"
              onClick={() => setActiveSubTab("overview")}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold transition border-b-2 -mb-[2px] cursor-pointer",
                activeSubTab === "overview"
                  ? "border-red-500 text-red-500"
                  : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <LayoutGrid size={14} />
              <span>Overview</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab("prompts")}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold transition border-b-2 -mb-[2px] cursor-pointer",
                activeSubTab === "prompts"
                  ? "border-red-500 text-red-500"
                  : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <Terminal size={14} />
              <span>Prompts</span>
              <span className="rounded-full bg-[var(--color-bg-soft)] px-1.5 py-0.2 text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                {report.prompts.length}
              </span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab("brands")}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold transition border-b-2 -mb-[2px] cursor-pointer",
                activeSubTab === "brands"
                  ? "border-red-500 text-red-500"
                  : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <Award size={14} />
              <span>Brands mentioned</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab("sources")}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold transition border-b-2 -mb-[2px] cursor-pointer",
                activeSubTab === "sources"
                  ? "border-red-500 text-red-500"
                  : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <Globe size={14} />
              <span>Sources</span>
            </button>
          </div>

          {/* Explanation Callout Banner (Matching Competitor Screenshot 4) */}
          <div
            className="rounded-2xl border p-4 sm:p-5 text-xs sm:text-sm shadow-xs space-y-1.5"
            style={{ borderColor: "rgba(59, 130, 246, 0.25)", background: "rgba(59, 130, 246, 0.04)" }}
          >
            <div className="flex items-center gap-2 font-bold text-blue-500 text-xs">
              <span className="h-2 w-2 rounded-full bg-blue-500" />
              <span>Explanation</span>
            </div>
            <p className="text-[var(--color-text)] leading-relaxed font-medium">
              Across <span className="font-bold">{report.prompts.length} prompts</span> and <span className="font-bold">{report.tested_engines.length} models</span> (
              {report.tested_engines.join(", ")}
              ), your brand appeared in <span className="font-bold">{report.prompts.filter(p => p.mentioned).length} of 15 answers</span>, a <span className="font-bold text-red-500">{report.visibility_score}%</span> visibility score. Most mentioned brand: <span className="font-bold">{report.brands_mentioned[0]?.brand || "Leading Competitor"}</span> ({report.brands_mentioned[0]?.mentions || 6} mentions). Top source: <span className="font-bold">{report.top_sources[0]?.source || "dev.to"}</span> ({report.top_sources[0]?.mentions || 9} times).
            </p>
          </div>

          {/* SECTION A: BRAND PRESENCE */}
          {activeSubTab === "overview" && (
            <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center gap-2 pb-2">
              <span className="h-0.5 w-4 bg-amber-500 rounded" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-amber-500">
                Brand Presence
              </span>
            </div>
            <h3 className="text-2xl font-black tracking-tight text-[var(--color-text)]">
              {report.brand}
            </h3>

            <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-12">
              {/* Visibility Score Box */}
              <div className="md:col-span-4 rounded-xl border p-5 flex flex-col justify-between" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase font-mono tracking-wider text-[var(--color-text-muted)]">
                    <Zap size={14} className="text-amber-500" />
                    <span>Visibility Score</span>
                  </div>
                  <div className="mt-3 text-4xl sm:text-5xl font-black font-mono tracking-tight text-[var(--color-text)]">
                    {report.visibility_score}%
                  </div>
                </div>

                <div className="mt-4">
                  <div className="h-2 w-full rounded-full bg-[var(--color-border)] overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-700",
                        report.visibility_score >= 70
                          ? "bg-emerald-500"
                          : report.visibility_score >= 30
                          ? "bg-amber-500"
                          : "bg-red-500"
                      )}
                      style={{ width: `${Math.max(4, report.visibility_score)}%` }}
                    />
                  </div>
                  <div className="mt-2 text-xs font-semibold text-[var(--color-danger)]">
                    A visibility score of {report.visibility_score}% is considered {report.visibility_tier}.
                  </div>
                </div>
              </div>

              {/* What Does My Score Mean Box */}
              <div className="md:col-span-8 rounded-xl border p-5 flex flex-col justify-between" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase font-mono tracking-wider text-[var(--color-text-muted)]">
                    <HelpCircle size={14} className="text-blue-500" />
                    <span>What Does My Score Mean</span>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-[var(--color-text)] font-medium">
                    {report.score_explanation}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t flex flex-wrap items-center gap-4 text-xs font-mono text-[var(--color-text-subtle)]" style={{ borderColor: "var(--color-border)" }}>
                  <span>Audited against: {report.tested_engines.join(", ")}</span>
                  <span>Domain: {report.domain}</span>
                </div>
              </div>
            </div>
          </div>
          )}

          {/* SECTION B: VISIBILITY FOR FOLLOWING PROMPTS */}
          {(activeSubTab === "overview" || activeSubTab === "prompts") && (
            <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center gap-2 pb-2">
              <span className="h-0.5 w-4 bg-amber-500 rounded" />
              <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-amber-500">
                Visibility for Following Prompts: {report.brand}
              </span>
            </div>
            <p className="text-xs text-[var(--color-text-muted)]">
              Representative queries dispatched across generative search engines to test brand citation recall.
            </p>

            <div className="mt-4 divide-y rounded-xl border" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
              {report.prompts.map((item, idx) => {
                const isExpanded = expandedPromptIdx === idx;
                return (
                  <div key={idx} className="p-4 transition hover:bg-[var(--color-bg-elev)]">
                    <div
                      onClick={() => setExpandedPromptIdx(isExpanded ? null : idx)}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer select-none"
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="text-sm font-semibold text-[var(--color-text)]">
                          {item.query}
                        </div>
                        <div className="flex items-center gap-2">
                          {item.engines.map((eng) => (
                            <span
                              key={eng}
                              className="rounded px-1.5 py-0.5 font-mono text-[10px] bg-[var(--color-bg-elev)] border text-[var(--color-text-subtle)]"
                              style={{ borderColor: "var(--color-border)" }}
                            >
                              {eng}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            "rounded-full px-2.5 py-0.5 font-mono text-xs font-bold whitespace-nowrap",
                            item.mentioned
                              ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/30"
                              : "bg-red-500/10 text-red-500 border border-red-500/30"
                          )}
                        >
                          {item.status}
                        </span>
                        {isExpanded ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="mt-3 pt-3 border-t text-xs space-y-2 text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                        <div className="font-medium text-[var(--color-text)]">
                          💡 Why this happened:
                        </div>
                        <p>
                          AI engines synthesize answers from existing high-citation hubs and schema-structured authority pages. Without citable evidence pages, LLMs default to competitors.
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          )}

          {/* SECTION C: COMPETITIVE BENCHMARK (BRANDS MENTIONED & TOP SOURCES) */}
          {(activeSubTab === "overview" || activeSubTab === "brands" || activeSubTab === "sources") && (
            <div className={cn("grid gap-6", activeSubTab === "overview" ? "grid-cols-1 lg:grid-cols-2" : "grid-cols-1")}>
              {/* Left: Brands Mentioned */}
              {(activeSubTab === "overview" || activeSubTab === "brands") && (
                <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
                  <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: "var(--color-border)" }}>
                    <div>
                      <h3 className="text-base font-bold text-[var(--color-text)]">Brands Mentioned</h3>
                      <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                        The brands most frequently recommended by AI search engines for prompts in your industry.
                  </p>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b font-mono text-[10px] uppercase text-[var(--color-text-subtle)]" style={{ borderColor: "var(--color-border)" }}>
                    <tr>
                      <th className="pb-2">Brand</th>
                      <th className="pb-2 text-right">Mentioned in</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y" style={{ borderColor: "var(--color-border)" }}>
                    {report.brands_mentioned.map((b) => (
                      <tr key={b.brand} className="hover:bg-[var(--color-bg-soft)] transition">
                        <td className="py-2.5 font-medium text-[var(--color-text)] flex items-center gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                          <span>{b.brand}</span>
                          {b.brand.toLowerCase() === report.brand.toLowerCase() && (
                            <span className="rounded bg-amber-500/10 text-amber-500 font-mono text-[9px] px-1.5 py-0.2">
                              Your Brand
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 text-right font-mono font-bold text-[var(--color-text)]">
                          {b.mentions}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            )}

            {/* Right: Top Sources */}
            {(activeSubTab === "overview" || activeSubTab === "sources") && (
              <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: "var(--color-border)" }}>
                  <div>
                    <h3 className="text-base font-bold text-[var(--color-text)]">Top Sources</h3>
                    <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                      The websites most frequently cited as authority sources by AI search engines.
                    </p>
                  </div>
                </div>

                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="border-b font-mono text-[10px] uppercase text-[var(--color-text-subtle)]" style={{ borderColor: "var(--color-border)" }}>
                      <tr>
                        <th className="pb-2">Source</th>
                        <th className="pb-2 text-right">Citation share</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y" style={{ borderColor: "var(--color-border)" }}>
                      {report.top_sources.map((s) => (
                        <tr key={s.source} className="hover:bg-[var(--color-bg-soft)] transition">
                          <td className="py-2.5 font-medium text-[var(--color-text)] flex items-center gap-2">
                            <Globe size={13} className="text-[var(--color-text-subtle)]" />
                            <span className="font-mono">{s.source}</span>
                          </td>
                          <td className="py-2.5 text-right">
                            <div className="flex items-center justify-end gap-2.5">
                              <span className="font-mono font-bold text-[var(--color-text)] text-xs">
                                {s.share_percent}%
                              </span>
                              <div className="h-1.5 w-16 rounded-full bg-[var(--color-border)] overflow-hidden hidden sm:block">
                                <div
                                  className="h-full rounded-full bg-blue-500"
                                  style={{ width: `${Math.min(100, s.share_percent * 8)}%` }}
                                />
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
          )}

          {/* SECTION D: SEARCH PERFORMANCE (GOOGLE SEARCH BASELINE) */}
          {activeSubTab === "overview" && (
            <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-6 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2 pb-2">
                <span className="h-0.5 w-4 bg-amber-500 rounded" />
                <span className="font-mono text-[11px] font-bold uppercase tracking-wider text-amber-500">
                  Search Performance
                </span>
              </div>
              <h3 className="text-xl font-bold tracking-tight text-[var(--color-text)]">
              {report.brand} on Google Search
            </h3>
            <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
              How your domain performs in traditional search — the foundation AI engines pull from when answering questions.
            </p>

            {/* 4 Metrics Cards */}
            <div className="mt-5 grid grid-cols-2 gap-3.5 sm:grid-cols-4">
              <div className="rounded-xl border p-4 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-[var(--color-text)]">
                  {report.search_performance.organic_keywords}
                </div>
                <div className="mt-1 text-xs font-medium text-[var(--color-text-muted)]">
                  Organic keywords
                </div>
              </div>

              <div className="rounded-xl border p-4 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-[var(--color-text)]">
                  {report.search_performance.est_monthly_traffic}
                </div>
                <div className="mt-1 text-xs font-medium text-[var(--color-text-muted)]">
                  Est. monthly traffic
                </div>
              </div>

              <div className="rounded-xl border p-4 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-[var(--color-text)]">
                  {report.search_performance.keywords_in_top_10}
                </div>
                <div className="mt-1 text-xs font-medium text-[var(--color-text-muted)]">
                  Keywords in top 10
                </div>
              </div>

              <div className="rounded-xl border p-4 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-[var(--color-text)]">
                  {report.search_performance.google_ai_overview_references}
                </div>
                <div className="mt-1 text-xs font-medium text-[var(--color-text-muted)]">
                  Google AI Overview references
                </div>
              </div>
            </div>

            {/* Top Ranking Keywords Table */}
            <div className="mt-6">
              <h4 className="text-xs font-bold uppercase font-mono tracking-wider text-[var(--color-text-muted)] mb-3">
                Top Ranking Keywords
              </h4>
              <div className="overflow-x-auto rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
                <table className="w-full text-left text-xs">
                  <thead className="border-b bg-[var(--color-bg-soft)] font-mono text-[10px] uppercase text-[var(--color-text-subtle)]" style={{ borderColor: "var(--color-border)" }}>
                    <tr>
                      <th className="px-4 py-2.5">Keyword</th>
                      <th className="px-4 py-2.5">Intent</th>
                      <th className="px-4 py-2.5 text-center">Position</th>
                      <th className="px-4 py-2.5 text-right">Monthly Volume</th>
                      <th className="px-4 py-2.5 text-right">Difficulty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y" style={{ borderColor: "var(--color-border)" }}>
                    {report.search_performance.top_ranking_keywords.map((kw, i) => (
                      <tr key={i} className="hover:bg-[var(--color-bg-soft)] transition">
                        <td className="px-4 py-3 font-semibold text-[var(--color-text)]">
                          <div>{kw.keyword}</div>
                          {kw.domain_url && (
                            <div className="font-mono text-[10px] text-[var(--color-text-subtle)] mt-0.5">
                              {kw.domain_url}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span className="rounded-full bg-blue-500/10 text-blue-500 px-2 py-0.5 font-mono text-[10px] font-bold">
                            {kw.intent}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center font-mono font-bold text-[var(--color-text)]">
                          {kw.position}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-[var(--color-text)]">
                          {kw.monthly_volume.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-[var(--color-text-muted)]">
                          {kw.difficulty}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          )}

          {/* SECTION E: FLOATING ACTION DOCK / PIPELINE CONVERSION BRIDGE */}
          <div className="sticky bottom-6 z-40 rounded-2xl border bg-[var(--color-bg-elev)]/95 p-4 shadow-pop backdrop-blur-xl flex flex-col sm:flex-row items-center justify-between gap-4" style={{ borderColor: "var(--color-border-strong)" }}>
            <div className="flex items-center gap-3">
              <div className="flex -space-x-1">
                {["ChatGPT", "Perplexity", "Gemini", "Claude"].map((eng) => (
                  <span
                    key={eng}
                    className="flex h-7 w-7 items-center justify-center rounded-full border bg-[var(--color-bg-soft)] text-[10px] font-bold shadow-xs select-none"
                    style={{ borderColor: "var(--color-border)" }}
                    title={eng}
                  >
                    ✨
                  </span>
                ))}
              </div>
              <div>
                <div className="text-sm font-bold text-[var(--color-text)]">
                  Improve AI visibility now!
                </div>
                <div className="text-xs text-[var(--color-text-muted)]">
                  Launch autonomous citable grounding pipeline to overtake {report.brands_mentioned[0]?.brand || "competitors"}.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                const topTopic = report.action_plan?.recommended_topics[0] || `${report.brand} Technical Analysis & Industry Benchmarks`;
                openLaunchModal();
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-orange-600 hover:bg-orange-700 px-5 py-2.5 text-xs font-bold text-white shadow-soft transition active:scale-[0.985] cursor-pointer"
            >
              <span>Launch Grounding Pipeline</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
