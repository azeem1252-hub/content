import {
  LayoutDashboard,
  Globe,
  FileText,
  FilePlus2,
  CheckCircle2,
  Calendar,
  ClipboardCheck,
  BarChart3,
  Settings,
  Plus,
  Target,
  ExternalLink,
  Link2,
  ShieldCheck,
  MessageSquare,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import type { Page } from "../lib/nav";
import { useNav } from "../lib/nav";
import { cn } from "../utils/cn";
import { usePipelineData } from "../lib/dataContext";
import { Logo } from "./Logo";

interface Item {
  id: Page | { parent: Page; child: Page };
  label: string;
  icon: typeof LayoutDashboard;
  badge?: number;
  badgeType?: "warn" | "neutral" | "live";
}

const contentChildren: { id: Page; label: string; icon: typeof FileText; badge?: number }[] = [
  { id: "queue", label: "Queue", icon: FilePlus2 },
  { id: "drafts", label: "Drafts", icon: FileText },
  { id: "published", label: "Published", icon: CheckCircle2 },
];

function isActive(current: Page, item: Item): boolean {
  if (typeof item.id === "string") return current === item.id;
  return current === item.id.parent || current === item.id.child;
}

export function Sidebar() {
  const { page, setPage, sidebarOpen, setSidebarOpen, openLaunchModal, activeRunThreadId } = useNav();
  const { websites, contentItems } = usePipelineData();

  const reviewBadge = contentItems.filter((c) => c.status === "Awaiting Approval").length;
  const inFlightCount = contentItems.filter(
    (c) => c.status === "Drafting" || c.status === "SEO Check" || c.status === "Idea"
  ).length;
  const draftsCount = contentItems.filter(
    (c) => c.status === "Drafting" || c.status === "SEO Check"
  ).length;

  const coreItems: Item[] = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    {
      id: { parent: "content", child: "queue" },
      label: "Blog content",
      icon: FileText,
      badge: inFlightCount > 0 ? inFlightCount : undefined,
      badgeType: "live",
    },
    { id: "backlinks", label: "Backlinks", icon: Link2 },
    { id: "health", label: "Site health", icon: ShieldCheck },
    { id: "social", label: "Socials", icon: MessageSquare },
    { id: "schedules", label: "Schedules", icon: Calendar },
    { id: "reviews", label: "Reviews", icon: ClipboardCheck, badge: reviewBadge, badgeType: "warn" },
  ];

  const analyticsItems: Item[] = [
    { id: "analytics", label: "AI visibility", icon: Sparkles },
    { id: "keywords", label: "Keywords & Traffic", icon: Target },
  ];

  const handleSelect = (id: Page) => {
    setPage(id);
    if (sidebarOpen) {
      setSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 lg:hidden"
          style={{ background: "var(--color-overlay)" }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r bg-[var(--color-bg-elev)] transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 select-none",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
        style={{ borderColor: "var(--color-border)" }}
      >
        {/* Logo */}
        <div className="flex h-16 items-center justify-between px-5">
          <Logo size={30} />
          <span
            className="rounded-full px-2 py-0.5 font-mono text-[10px] font-semibold border"
            style={{
              background: "var(--color-bg-soft)",
              color: "var(--color-text-subtle)",
              borderColor: "var(--color-border)",
            }}
          >
            v2.4
          </span>
        </div>

        {/* Primary Action Button: Launch Pipeline */}
        <div className="px-3 pb-2 pt-1">
          <button
            type="button"
            onClick={openLaunchModal}
            className="group flex w-full cursor-pointer items-center justify-between rounded-lg bg-[var(--color-text)] px-3 py-2 text-xs font-semibold text-[var(--color-bg-elev)] shadow-[var(--shadow-soft)] transition-all hover:opacity-90 active:scale-[0.985]"
          >
            <span className="inline-flex items-center gap-2">
              <Plus size={14} className="transition-transform group-hover:rotate-90 duration-150" />
              <span>Launch Pipeline</span>
            </span>
            <kbd
              className="rounded px-1.5 py-0.5 font-mono text-[9px]"
              style={{
                background: "var(--color-bg-soft)",
                color: "var(--color-text-muted)",
              }}
            >
              ⌘N
            </kbd>
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 pb-3">
          <div className="mb-1.5 px-2.5 pt-1 text-[10px] font-medium uppercase tracking-wider text-[var(--color-text-subtle)]">
            Workspace
          </div>
          <ul className="flex flex-col gap-0.5">
            {coreItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(page, item);
              const id = typeof item.id === "string" ? item.id : item.id.parent;

              if (id === "content") {
                const contentActive =
                  page === "content" || page === "queue" || page === "drafts" || page === "published";
                return (
                  <li key="content-group">
                    <button
                      onClick={() => handleSelect("queue")}
                      className={cn(
                        "flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm font-medium transition",
                        contentActive
                          ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                          : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                      )}
                    >
                      <Icon size={16} className="shrink-0" />
                      <span className="flex-1 text-left">Content</span>
                      {inFlightCount > 0 && (
                        <span
                          className="rounded-full px-1.5 py-0.2 font-mono text-[10px] font-bold"
                          style={{
                            background: "var(--color-accent-soft)",
                            color: "var(--color-accent-text)",
                          }}
                        >
                          {inFlightCount}
                        </span>
                      )}
                    </button>
                    {contentActive && (
                      <ul
                        className="ml-3 mt-0.5 flex flex-col gap-0.5 border-l pl-3"
                        style={{ borderColor: "var(--color-border)" }}
                      >
                        {contentChildren.map((child) => {
                          const ChildIcon = child.icon;
                          const childActive = page === child.id;
                          const childBadge =
                            child.id === "drafts"
                              ? draftsCount > 0
                                ? draftsCount
                                : undefined
                              : undefined;
                          return (
                            <li key={child.id}>
                              <button
                                onClick={() => handleSelect(child.id)}
                                className={cn(
                                  "flex w-full cursor-pointer items-center gap-2 rounded-md px-2 py-1 text-[13px] transition",
                                  childActive
                                    ? "text-[var(--color-text)] font-semibold bg-[var(--color-bg-soft)]"
                                    : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                                )}
                              >
                                <ChildIcon size={13} className="shrink-0" />
                                <span className="flex-1 text-left">{child.label}</span>
                                {childBadge !== undefined && (
                                  <span
                                    className="ml-auto rounded-full px-1.5 py-0.5 text-[10px] font-semibold"
                                    style={{
                                      background: "var(--color-bg-soft)",
                                      color: "var(--color-text-muted)",
                                    }}
                                  >
                                    {childBadge}
                                  </span>
                                )}
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </li>
                );
              }

              return (
                <li key={id}>
                  <button
                    onClick={() => handleSelect(id as Page)}
                    className={cn(
                      "flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm font-medium transition",
                      active
                        ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                        : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                    )}
                  >
                    <Icon size={16} className="shrink-0" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className="rounded-full px-1.5 py-0.5 text-[10px] font-semibold tabular-nums"
                        style={{
                          background:
                            item.badgeType === "warn"
                              ? "var(--color-warn-soft)"
                              : item.badgeType === "live"
                              ? "var(--color-accent-soft)"
                              : "var(--color-bg-soft)",
                          color:
                            item.badgeType === "warn"
                              ? "var(--color-warn)"
                              : item.badgeType === "live"
                              ? "var(--color-accent-text)"
                              : "var(--color-text-muted)",
                        }}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>

          {/* Analytics Category */}
          <div className="mt-4">
            <div className="mb-1.5 px-2.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--color-text-subtle)]">
              Analytics &amp; GEO
            </div>
            <ul className="flex flex-col gap-0.5">
              {analyticsItems.map((item) => {
                const Icon = item.icon;
                const active = isActive(page, item);
                const id = typeof item.id === "string" ? item.id : item.id.parent;
                return (
                  <li key={id}>
                    <button
                      onClick={() => handleSelect(id as Page)}
                      className={cn(
                        "flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm font-medium transition",
                        active
                          ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                          : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                      )}
                    >
                      <Icon size={16} className="shrink-0 text-amber-500" />
                      <span className="flex-1 text-left">{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* Destinations & Admin Category */}
          <div className="mt-4">
            <div className="mb-1.5 px-2.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--color-text-subtle)]">
              Destinations &amp; Admin
            </div>
            <ul className="flex flex-col gap-0.5">
              <li>
                <button
                  onClick={() => handleSelect("websites")}
                  className={cn(
                    "flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm font-medium transition",
                    page === "websites"
                      ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                      : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                  )}
                >
                  <Globe size={16} className="shrink-0" />
                  <span className="flex-1 text-left">Websites</span>
                  <span className="rounded-full bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                    {websites.length}
                  </span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleSelect("settings")}
                  className={cn(
                    "flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-sm font-medium transition",
                    page === "settings"
                      ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                      : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                  )}
                >
                  <Settings size={16} className="shrink-0" />
                  <span className="flex-1 text-left">Settings</span>
                </button>
              </li>
            </ul>
          </div>
        </nav>

        {/* Workspace status */}
        <div className="border-t p-4" style={{ borderColor: "var(--color-border)" }}>
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <span className="flex h-2 w-2 rounded-full bg-[var(--color-accent)]" />
              <span className="absolute inset-0 animate-pulseSoft rounded-full bg-[var(--color-accent)] opacity-50" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-medium text-[var(--color-text)] truncate">
                {activeRunThreadId ? "Pipeline running" : "Pipeline operational"}
              </div>
              <div className="text-[11px] text-[var(--color-text-subtle)] truncate">
                {activeRunThreadId ? "Active LangGraph run" : "All systems normal"}
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
