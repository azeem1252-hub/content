import verlyticMark from "@/assets/verlytic-mark.png";
import { cn } from "@/utils/cn";

interface Props {
  size?: number;
  withText?: boolean;
  textSize?: "sm" | "md" | "lg";
  title?: string;
  subtitle?: string;
  variant?: "full" | "mark" | "auto";
  tone?: "light" | "dark" | "auto";
  className?: string;
}

export function Logo({
  size = 30,
  withText = true,
  textSize = "md",
  title = "Verlytic",
  subtitle = "Content Operations",
  variant = "auto",
  tone = "auto",
  className = "",
}: Props) {
  const isMarkOnly = !withText || variant === "mark";

  const sizes = {
    sm: { h1: "13px", h2: "8.5px", gap: "gap-2", markSize: Math.max(18, size) },
    md: { h1: "15px", h2: "9.5px", gap: "gap-2.5", markSize: size },
    lg: { h1: "18px", h2: "10.5px", gap: "gap-3", markSize: Math.max(30, size) },
  } as const;
  const s = sizes[textSize];

  // Explicit or auto-derived colors
  const titleColor =
    tone === "light"
      ? "text-[#1B1B1F]"
      : tone === "dark"
      ? "text-[#ECEEF2]"
      : "text-[var(--color-text)]";

  const subtitleColor =
    tone === "light"
      ? "text-[#6B6B72]"
      : tone === "dark"
      ? "text-[#9AA3B2]"
      : "text-[var(--color-text-muted)]";

  if (isMarkOnly) {
    return (
      <div className={cn("relative inline-flex items-center justify-center shrink-0", className)}>
        <img
          src={verlyticMark}
          alt={title}
          className="shrink-0 object-contain drop-shadow-xs"
          style={{ width: size, height: size }}
          loading="eager"
        />
      </div>
    );
  }

  return (
    <div className={cn("inline-flex items-center select-none leading-none", s.gap, className)}>
      <img
        src={verlyticMark}
        alt={title}
        className="shrink-0 object-contain drop-shadow-xs"
        style={{ width: s.markSize, height: s.markSize }}
        loading="eager"
      />
      <div className="flex flex-col justify-center leading-none min-w-0">
        <span
          className={cn("font-bold tracking-tight truncate", titleColor)}
          style={{ fontSize: s.h1, letterSpacing: "-0.018em" }}
        >
          {title}
        </span>
        {subtitle && (
          <span
            className={cn("font-mono uppercase font-semibold tracking-[0.14em] truncate mt-1", subtitleColor)}
            style={{ fontSize: s.h2 }}
          >
            {subtitle}
          </span>
        )}
      </div>
    </div>
  );
}
