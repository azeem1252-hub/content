import { Globe } from "lucide-react";
import type { Website } from "../types";

interface Props {
  website: Website;
  size?: number;
}

export function WebsiteIcon({ website, size = 36 }: Props) {
  const color = website.avatarColor || "var(--color-accent)";
  return (
    <div
      className="flex shrink-0 select-none items-center justify-center rounded-lg transition"
      style={{
        width: size,
        height: size,
        background: `${color}15`,
        color: color,
        border: `1px solid ${color}25`,
      }}
      title={`${website.name} (${website.url})`}
    >
      <Globe size={size * 0.45} strokeWidth={2} />
    </div>
  );
}
