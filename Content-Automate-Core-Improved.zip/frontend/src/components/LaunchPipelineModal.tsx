import { useState, useEffect } from "react";
import {
  Bot,
  Compass,
  Sliders,
  CheckCircle2,
  X,
  Loader2,
  Send,
  Workflow,
  Table as TableIcon,
  HelpCircle,
  Lightbulb,
  Target,
  BookOpen,
  Image as ImageIcon,
  Database,
  ShieldCheck,
  Cpu,
  Layers,
  FileText,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { useNav } from "../lib/nav";
import { usePipelineData } from "../lib/dataContext";
import { useToast } from "../lib/toast";
import { api } from "../lib/api";
import { Button } from "./ui";
import { cn } from "../utils/cn";

const BLUEPRINTS = [
  { id: "how_to", name: "How-to Guide", desc: "Step-by-step tutorial with answer-first intro & screenshots" },
  { id: "comparison", name: "Comparison (X vs Y)", desc: "Verdict up top, comparison & pricing tables, pros/cons" },
  { id: "definition", name: "Definition (What is)", desc: "Answer block definition, concept diagram, real examples" },
  { id: "roundup", name: "Roundup / Listicle", desc: "Selection criteria, consistent item structure, summary table" },
  { id: "data_study", name: "Data Study", desc: "Methodology, charts from empirical data, downloadable dataset" },
  { id: "case_study", name: "Case Study", desc: "Real customer, concrete numbers, before/after timeline" },
  { id: "pillar_guide", name: "Pillar Guide", desc: "TOC, section answer blocks, internal link hub" },
];

const DEPTH_PRESETS = [
  { id: "focused", name: "Focused Tactical Brief", words: "~800 – 1,200w", desc: "Fast, dense answers & steps for rapid reading" },
  { id: "standard", name: "Standard Authority Guide", words: "~1,500 – 2,200w", desc: "Balanced architectural overview with full practical context" },
  { id: "deep_dive", name: "Exhaustive Deep Dive", words: "~2,500 – 3,500+w", desc: "Definitive masterclass with benchmarks, diagrams & edge cases" },
];

const VOICE_PRESETS = [
  { id: "pragmatic_engineer", label: "Pragmatic Senior Engineer", desc: "Code-first, direct, zero marketing fluff, technical nuance" },
  { id: "technical_architect", label: "Authoritative Technical Architect", desc: "System design patterns, scalability tradeoffs, deep mechanics" },
  { id: "analytical_columnist", label: "Analytical Tech Columnist", desc: "Narrative-driven, punchy industry analysis, timely" },
  { id: "benchmark_analyst", label: "Data-Driven Benchmark Analyst", desc: "Empirical metrics, latency/throughput comparisons, graphs" },
  { id: "executive_leader", label: "Executive CTO Brief", desc: "Strategic ROI, architectural clarity, business implications" },
  { id: "custom", label: "Custom Persona / Voice...", desc: "Define your own bespoke editorial perspective" },
];

const NICHE_PRESETS = [
  { id: "game_engine", label: "Game Engine Architecture & Real-Time Simulation" },
  { id: "cloud_infra", label: "Cloud Infrastructure, Kubernetes & SRE" },
  { id: "ai_systems", label: "AI / ML Systems, LLMOps & Distributed Inference" },
  { id: "web_perf", label: "Full-Stack Web Performance & Serverless Architecture" },
  { id: "security", label: "Cybersecurity, Zero Trust & Infrastructure Hardening" },
  { id: "custom", label: "Custom Domain Niche..." },
];

const AUDIENCE_SUGGESTIONS = [
  "Senior Software Engineers",
  "Systems Architects",
  "CTOs & Technical Leads",
  "Indie Game Developers",
  "DevOps & SRE Practitioners",
];

export function LaunchPipelineModal() {
  const { isLaunchModalOpen, closeLaunchModal, openInspector, setActiveRunThreadId } = useNav();
  const { websites, triggerPipelineRun, refreshAll } = usePipelineData();
  const { push } = useToast();

  const [selectedSiteId, setSelectedSiteId] = useState<string>("");
  const [topic, setTopic] = useState("");
  const [keywords, setKeywords] = useState("");
  const [secondaryKeywords, setSecondaryKeywords] = useState("");
  const [targetAudience, setTargetAudience] = useState("");
  const [selectedBlueprint, setSelectedBlueprint] = useState<string>("how_to");
  const [selectedDepth, setSelectedDepth] = useState<string>("standard");
  const [selectedVoice, setSelectedVoice] = useState<string>("pragmatic_engineer");
  const [customVoice, setCustomVoice] = useState<string>("");
  const [selectedNiche, setSelectedNiche] = useState<string>("game_engine");
  const [customNiche, setCustomNiche] = useState<string>("");
  const [injectEvidence, setInjectEvidence] = useState<boolean>(true);
  const [autoApprove, setAutoApprove] = useState<boolean>(false);
  const [isDiscovering, setIsDiscovering] = useState<boolean>(false);
  const [isLaunching, setIsLaunching] = useState<boolean>(false);
  const [discoveryNote, setDiscoveryNote] = useState<string | null>(null);

  // Evidence vault status
  const [evidenceCount, setEvidenceCount] = useState<number>(0);
  const [isSeedingEvidence, setIsSeedingEvidence] = useState<boolean>(false);

  // Content Modules & Visual Enhancements Toggles (ON / OFF)
  const [enableDiagrams, setEnableDiagrams] = useState<boolean>(true);
  const [enableTables, setEnableTables] = useState<boolean>(true);
  const [enableFaqs, setEnableFaqs] = useState<boolean>(true);
  const [enableTakeaways, setEnableTakeaways] = useState<boolean>(true);
  const [enableAnswerBlocks, setEnableAnswerBlocks] = useState<boolean>(true);
  const [enableCitations, setEnableCitations] = useState<boolean>(true);
  const [enableHeroImage, setEnableHeroImage] = useState<boolean>(true);

  // Escape key handler & background body scroll lock
  useEffect(() => {
    if (!isLaunchModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLaunchModal();
    };
    window.addEventListener("keydown", handleKeyDown);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [isLaunchModalOpen, closeLaunchModal]);

  // Set default selected website
  useEffect(() => {
    if (!selectedSiteId && websites.length > 0) {
      const def = websites.find((w) => w.is_default) || websites[0];
      if (def) setSelectedSiteId(def.id);
    }
  }, [websites, selectedSiteId]);

  // Fetch evidence count for current website
  useEffect(() => {
    if (!isLaunchModalOpen || !selectedSiteId) return;
    api
      .getEvidencePacks(selectedSiteId)
      .then((res) => {
        setEvidenceCount((res.evidence_items || []).length);
      })
      .catch(() => setEvidenceCount(0));
  }, [isLaunchModalOpen, selectedSiteId]);

  if (!isLaunchModalOpen) return null;

  const selectedSite = websites.find((w) => w.id === selectedSiteId) || websites[0];

  const handleSeedEvidence = async () => {
    setIsSeedingEvidence(true);
    try {
      const res = await api.seedEvidencePacks(selectedSiteId);
      setEvidenceCount((res.evidence_items || []).length);
      push({
        title: "Evidence Vault Seeded",
        description: `Seeded ${res.seeded || 4} verified 1st-party benchmarks & quotes.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Seeding Failed",
        description: err.message || "Could not seed sample evidence.",
        variant: "danger",
      });
    } finally {
      setIsSeedingEvidence(false);
    }
  };

  const handleDiscover = async () => {
    setIsDiscovering(true);
    setDiscoveryNote(null);
    try {
      const disc = await api.discoverTopic(selectedSiteId || undefined);
      if (disc.topic) {
        setTopic(disc.topic);
        if (disc.keywords && disc.keywords.length > 0) {
          setKeywords(disc.keywords.join(", "));
        }
        if (disc.content_format) {
          const fmt = disc.content_format.toLowerCase();
          if (fmt.includes("vs") || fmt.includes("comparison")) setSelectedBlueprint("comparison");
          else if (fmt.includes("definition") || fmt.includes("what is")) setSelectedBlueprint("definition");
          else if (fmt.includes("roundup") || fmt.includes("best") || fmt.includes("list")) setSelectedBlueprint("roundup");
          else if (fmt.includes("study") || fmt.includes("data") || fmt.includes("benchmark")) setSelectedBlueprint("data_study");
          else if (fmt.includes("case")) setSelectedBlueprint("case_study");
          else if (fmt.includes("pillar") || fmt.includes("guide")) setSelectedBlueprint("pillar_guide");
          else setSelectedBlueprint("how_to");
        }
        setDiscoveryNote(`Discovered: “${disc.topic}” (${disc.reasoning || "High search demand & novelty"})`);
        push({
          title: "Topic Discovered",
          description: `Discovered “${disc.topic}” with verified novelty.`,
          variant: "success",
        });
      }
    } catch (err: any) {
      push({
        title: "Discovery Failed",
        description: err.message || "Could not auto-discover topic.",
        variant: "warn",
      });
    } finally {
      setIsDiscovering(false);
    }
  };

  const handleLaunch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLaunching(true);
    try {
      const kwList = keywords
        .split(",")
        .map((k) => k.trim())
        .filter(Boolean);

      const secKwList = secondaryKeywords
        .split(",")
        .map((k) => k.trim())
        .filter(Boolean);

      const effectiveVoice =
        selectedVoice === "custom"
          ? customVoice.trim()
          : VOICE_PRESETS.find((v) => v.id === selectedVoice)?.label;

      const effectiveNiche =
        selectedNiche === "custom"
          ? customNiche.trim()
          : NICHE_PRESETS.find((n) => n.id === selectedNiche)?.label;

      const res = await triggerPipelineRun({
        topic: topic.trim() || undefined,
        website_id: selectedSiteId || undefined,
        keywords: kwList,
        secondary_keywords: secKwList,
        target_audience: targetAudience.trim() || undefined,
        content_format: selectedBlueprint || undefined,
        brand_voice: effectiveVoice || undefined,
        article_depth: selectedDepth,
        niche: effectiveNiche || undefined,
        inject_evidence: injectEvidence,
        auto_approve: autoApprove,
        enable_diagrams: enableDiagrams,
        enable_tables: enableTables,
        enable_faqs: enableFaqs,
        enable_takeaways: enableTakeaways,
        enable_answer_blocks: enableAnswerBlocks,
        enable_citations: enableCitations,
        enable_hero_image: enableHeroImage,
      });

      const threadId = res?.thread_id;
      if (threadId) {
        setActiveRunThreadId(threadId);
      }

      push({
        title: "Pipeline Dispatched!",
        description: `Run queued for “${topic.trim() || selectedSite?.name || "Target Site"}”.`,
        variant: "success",
      });

      closeLaunchModal();
      await refreshAll();

      if (threadId) {
        openInspector(threadId);
      }
    } catch (err: any) {
      push({
        title: "Dispatch Failed",
        description: err.message || "Failed to start pipeline run.",
        variant: "danger",
      });
    } finally {
      setIsLaunching(false);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 z-50 bg-[var(--color-overlay)] backdrop-blur-sm transition-opacity animate-fadeIn"
        onClick={closeLaunchModal}
      />
      <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
        <div
          className="relative z-10 w-full max-w-3xl max-h-[calc(100vh-1.5rem)] sm:max-h-[min(92vh,920px)] flex flex-col rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-pop)] animate-scaleIn overflow-hidden my-auto"
          style={{ borderColor: "var(--color-border)" }}
          onClick={(e) => e.stopPropagation()}
          role="dialog"
          aria-modal="true"
        >
          {/* Fixed Top Header */}
          <div
            className="shrink-0 flex items-center justify-between border-b px-5 sm:px-6 py-4 bg-[var(--color-bg-elev)] z-20"
            style={{ borderColor: "var(--color-border)" }}
          >
            <div className="flex items-center gap-3">
              <div
                className="flex h-9 w-9 items-center justify-center rounded-xl shrink-0"
                style={{ background: "var(--color-accent-soft)", color: "var(--color-accent)" }}
              >
                <Bot size={18} />
              </div>
              <div>
                <h3 className="text-base font-bold text-[var(--color-text)]">
                  Launch Autonomous Pipeline
                </h3>
                <p className="text-xs text-[var(--color-text-muted)]">
                  Configure blueprints, brand voice, evidence proof, and rich modules for this run.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={closeLaunchModal}
              className="rounded-xl p-2 text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-bg-soft)] border border-[var(--color-border)] transition cursor-pointer shrink-0 shadow-xs"
              title="Close modal (Esc)"
              aria-label="Close modal"
            >
              <X size={18} className="stroke-[2.5]" />
            </button>
          </div>

          <form onSubmit={handleLaunch} className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
              {/* 1. Website Target Selector */}
              <div>
                <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                  Target Website &amp; Publishing Destination
                </label>
                <select
                  value={selectedSiteId}
                  onChange={(e) => setSelectedSiteId(e.target.value)}
                  className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2.5 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  {websites.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} — {w.url} ({w.storage_type === "upstash" ? "Upstash 0-sec Direct DB" : "Git-Backed"})
                    </option>
                  ))}
                </select>
                {selectedSite && (
                  <div className="mt-1.5 flex items-center gap-2 text-[11px] text-[var(--color-text-muted)] font-mono">
                    <span>Storage: {selectedSite.storage_type || "database"}</span>
                    <span>•</span>
                    <span>Webhook: {selectedSite.secret_token ? "Configured ✓" : "Default"}</span>
                  </div>
                )}
              </div>

              {/* 2. Topic Input with AI Discover */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-[var(--color-text)]">
                    Article Topic or Working Title
                  </label>
                  <button
                    type="button"
                    onClick={handleDiscover}
                    disabled={isDiscovering}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-[var(--color-accent-text)] hover:underline cursor-pointer disabled:opacity-50"
                  >
                    {isDiscovering ? (
                      <>
                        <Loader2 size={11} className="animate-spin" /> Discovering SERP Gaps...
                      </>
                    ) : (
                      <>
                        <Compass size={11} /> Auto-Discover SERP Topic
                      </>
                    )}
                  </button>
                </div>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Leave blank for autonomous discovery, or enter a specific topic..."
                  className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2.5 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                />
                {discoveryNote && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--color-live)]">
                    <CheckCircle2 size={12} className="shrink-0" />
                    <span>{discoveryNote}</span>
                  </div>
                )}
              </div>

              {/* 3. Editorial Blueprint (Structure & Components) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-[var(--color-text)]">
                    Editorial Blueprint (Article Structure)
                  </label>
                  <span className="text-[10px] text-[var(--color-text-muted)] font-mono">
                    {BLUEPRINTS.find((b) => b.id === selectedBlueprint)?.name}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                  {BLUEPRINTS.map((bp) => (
                    <button
                      key={bp.id}
                      type="button"
                      onClick={() => setSelectedBlueprint(bp.id)}
                      className={cn(
                        "rounded-xl border p-2.5 text-left transition-colors cursor-pointer",
                        selectedBlueprint === bp.id
                          ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                          : "border-[var(--color-border)] bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)]"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[var(--color-text)]">{bp.name}</span>
                        {selectedBlueprint === bp.id && (
                          <CheckCircle2 size={12} className="text-[var(--color-accent)]" />
                        )}
                      </div>
                      <div className="text-[10px] text-[var(--color-text-muted)] mt-0.5 line-clamp-1">
                        {bp.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 4. Article Depth & Target Word Count */}
              <div>
                <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                  Article Depth &amp; Word Target
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {DEPTH_PRESETS.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => setSelectedDepth(d.id)}
                      className={cn(
                        "rounded-xl border p-2.5 text-left transition-colors cursor-pointer",
                        selectedDepth === d.id
                          ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                          : "border-[var(--color-border)] bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)]"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[var(--color-text)]">{d.name}</span>
                        {selectedDepth === d.id && (
                          <CheckCircle2 size={12} className="text-[var(--color-accent)]" />
                        )}
                      </div>
                      <div className="text-[10px] font-mono font-semibold text-[var(--color-accent)] mt-0.5">
                        {d.words}
                      </div>
                      <div className="text-[10px] text-[var(--color-text-muted)] mt-0.5 line-clamp-1">
                        {d.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 5. Brand Voice & Writing Tone */}
              <div>
                <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                  Brand Voice &amp; Tone (Pillar A3.1)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {VOICE_PRESETS.map((v) => (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setSelectedVoice(v.id)}
                      className={cn(
                        "rounded-xl border p-2.5 text-left transition-colors cursor-pointer",
                        selectedVoice === v.id
                          ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                          : "border-[var(--color-border)] bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)]"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[var(--color-text)]">{v.label}</span>
                        {selectedVoice === v.id && (
                          <CheckCircle2 size={12} className="text-[var(--color-accent)]" />
                        )}
                      </div>
                      <div className="text-[10px] text-[var(--color-text-muted)] mt-0.5 line-clamp-1">
                        {v.desc}
                      </div>
                    </button>
                  ))}
                </div>
                {selectedVoice === "custom" && (
                  <input
                    type="text"
                    value={customVoice}
                    onChange={(e) => setCustomVoice(e.target.value)}
                    placeholder="e.g. Pragmatic Rust compiler contributor, sarcastic yet deeply knowledgeable..."
                    className="mt-2 w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                )}
              </div>

              {/* 6. Editorial Domain & Niche */}
              <div>
                <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                  Domain Niche &amp; Subject Matter
                </label>
                <select
                  value={selectedNiche}
                  onChange={(e) => setSelectedNiche(e.target.value)}
                  className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2.5 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  {NICHE_PRESETS.map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.label}
                    </option>
                  ))}
                </select>
                {selectedNiche === "custom" && (
                  <input
                    type="text"
                    value={customNiche}
                    onChange={(e) => setCustomNiche(e.target.value)}
                    placeholder="Enter custom domain niche (e.g. Autonomous Robotics & ROS 2)..."
                    className="mt-2 w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                )}
              </div>

              {/* 7. Target Primary & Secondary Keywords */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                    Primary Keywords (Main SERP Targets)
                  </label>
                  <input
                    type="text"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                    placeholder="e.g. Next.js 15, App Router, React Server Components"
                    className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3 py-2 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                    Secondary &amp; Semantic LSI Keywords
                  </label>
                  <input
                    type="text"
                    value={secondaryKeywords}
                    onChange={(e) => setSecondaryKeywords(e.target.value)}
                    placeholder="e.g. Hydration mismatch, static rendering, streaming"
                    className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3 py-2 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                </div>
              </div>

              {/* 8. Target Audience & Personas */}
              <div>
                <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5">
                  Target Readership Persona
                </label>
                <input
                  type="text"
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder="e.g. Senior frontend engineers, devops teams, platform architects"
                  className="w-full rounded-xl border bg-[var(--color-bg-soft)] px-3.5 py-2 text-xs text-[var(--color-text)] transition-colors focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                />
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] text-[var(--color-text-muted)] mr-1">Suggestions:</span>
                  {AUDIENCE_SUGGESTIONS.map((aud) => (
                    <button
                      key={aud}
                      type="button"
                      onClick={() => setTargetAudience(aud)}
                      className="rounded-lg bg-[var(--color-bg-soft)] hover:bg-[var(--color-accent-soft)] px-2 py-0.5 text-[10px] text-[var(--color-text-muted)] hover:text-[var(--color-accent-text)] border border-[var(--color-border)] transition"
                    >
                      + {aud}
                    </button>
                  ))}
                </div>
              </div>

              {/* 9. Evidence Vault & Originality Gating (Pillar A3.2) */}
              <div
                className="rounded-xl border p-3.5 bg-[var(--color-bg-soft)] space-y-2.5"
                style={{ borderColor: "var(--color-border)" }}
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Database size={15} className="text-[#10b981]" />
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Evidence Vault &amp; Proof Injection (Pillar A3.2)
                    </span>
                    {evidenceCount > 0 ? (
                      <span className="rounded-full bg-[#10b981]/15 px-2 py-0.5 text-[10px] text-[#10b981] font-semibold flex items-center gap-1">
                        <CheckCircle2 size={10} /> {evidenceCount} Verified Items
                      </span>
                    ) : (
                      <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] text-amber-500 font-semibold flex items-center gap-1">
                        <AlertTriangle size={10} /> Vault Empty
                      </span>
                    )}
                  </div>

                  {evidenceCount === 0 && (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={handleSeedEvidence}
                      disabled={isSeedingEvidence}
                      icon={isSeedingEvidence ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                    >
                      {isSeedingEvidence ? "Seeding..." : "Seed 4 Sample Evidence Items"}
                    </Button>
                  )}
                </div>

                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  {evidenceCount > 0
                    ? "Active first-party telemetry, benchmarks, and practitioner quotes will be automatically matched to relevant sections via semantic embeddings to satisfy Google's Scaled Content policy."
                    : "Under Google's Scaled Content guidelines, embedding empirical proof prevents algorithmic penalties. Click 'Seed 4 Sample Evidence Items' to populate realistic telemetry and benchmark datasets."}
                </p>

                <label className="flex items-center gap-2 text-xs text-[var(--color-text)] cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={injectEvidence}
                    onChange={(e) => setInjectEvidence(e.target.checked)}
                    className="rounded border-[var(--color-border)] text-[var(--color-accent)] focus:ring-0"
                  />
                  <span className="font-medium">
                    Auto-inject verified evidence items into drafted sections (Pillar A3.2)
                  </span>
                </label>
              </div>

              {/* 10. Content Modules & Visual Elements Toggles */}
              <div className="space-y-2 border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-[var(--color-text)] flex items-center gap-1.5">
                    <Sliders size={13} className="text-[var(--color-accent)]" />
                    Content Modules &amp; Rich Elements
                  </label>
                  <span className="text-[10px] text-[var(--color-text-muted)]">
                    Click to toggle elements ON / OFF
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* 1. Diagrams Toggle */}
                  <div
                    onClick={() => setEnableDiagrams(!enableDiagrams)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableDiagrams
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableDiagrams ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <Workflow size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate flex items-center gap-1">
                          Architecture Diagrams
                          <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-500 font-bold">SVG</span>
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          Pre-rendered standalone vector images
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableDiagrams ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableDiagrams ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 2. Comparison Tables Toggle */}
                  <div
                    onClick={() => setEnableTables(!enableTables)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableTables
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableTables ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <TableIcon size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          Comparison &amp; Data Tables
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          Side-by-side criteria &amp; benchmarks
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableTables ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableTables ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 3. FAQ Module Toggle */}
                  <div
                    onClick={() => setEnableFaqs(!enableFaqs)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableFaqs
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableFaqs ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <HelpCircle size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          FAQ &amp; People Also Ask
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          High-intent Q&amp;A accordion section
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableFaqs ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableFaqs ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 4. Key Takeaways Toggle */}
                  <div
                    onClick={() => setEnableTakeaways(!enableTakeaways)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableTakeaways
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableTakeaways ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <Lightbulb size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          Key Takeaways Box
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          Executive summary callout box
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableTakeaways ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableTakeaways ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 5. AEO Direct Answer Snippets */}
                  <div
                    onClick={() => setEnableAnswerBlocks(!enableAnswerBlocks)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableAnswerBlocks
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableAnswerBlocks ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <Target size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          AEO Direct Answer Snippets
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          40–60w answers for AI search engines
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableAnswerBlocks ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableAnswerBlocks ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 6. Citations & References */}
                  <div
                    onClick={() => setEnableCitations(!enableCitations)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableCitations
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableCitations ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <BookOpen size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          Verified References
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          Citations &amp; primary source URLs
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableCitations ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableCitations ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>

                  {/* 7. Visual Assets & Hero Image */}
                  <div
                    onClick={() => setEnableHeroImage(!enableHeroImage)}
                    className={cn(
                      "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
                      enableHeroImage
                        ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
                        : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className={cn(
                        "p-1.5 rounded-lg shrink-0",
                        enableHeroImage ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
                      )}>
                        <ImageIcon size={13} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                          Visual Assets &amp; Hero Image
                        </div>
                        <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
                          Generative AI diffusion banner image
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      className={cn(
                        "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
                        enableHeroImage ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                      )}
                    >
                      <span
                        className={cn(
                          "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
                          enableHeroImage ? "translate-x-4" : "translate-x-0"
                        )}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* 11. Publication Mode Toggle */}
              <div className="rounded-xl border p-3.5 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoApprove}
                    onChange={(e) => setAutoApprove(e.target.checked)}
                    className="mt-0.5 rounded border-[var(--color-border)] text-[var(--color-accent)] focus:ring-0 cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Autonomous Direct Publish (Bypass Human Review Gate)
                    </span>
                    <p className="text-[11px] text-[var(--color-text-muted)] mt-0.5">
                      {autoApprove
                        ? "The pipeline will automatically publish the article to the website as soon as fact-verification and SEO audit pass."
                        : "The pipeline will pause after generation, allowing you to review verified claims, inspect document blocks, and approve with 1 click."}
                    </p>
                  </div>
                </label>
              </div>

              {/* Pipeline Stage Preview */}
              <div className="flex items-center justify-between text-[10px] font-mono text-[var(--color-text-subtle)] border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
                <span>Flow: Outline ➔ Draft ➔ A4 Verification ➔ A5b AEO ➔ A5c Studio ➔ Publish</span>
                <span>LangGraph v2.4</span>
              </div>
            </div>

            {/* Fixed Sticky Docked Footer */}
            <div
              className="shrink-0 flex items-center justify-between border-t bg-[var(--color-bg-soft)] px-5 sm:px-6 py-3.5 z-20"
              style={{ borderColor: "var(--color-border)" }}
            >
              <div className="hidden sm:flex items-center gap-2 text-[10px] font-mono text-[var(--color-text-subtle)]">
                <span>{selectedDepth.toUpperCase()} Target</span>
                <span>•</span>
                <span>{VOICE_PRESETS.find((v) => v.id === selectedVoice)?.label || "Custom Voice"}</span>
                <span>•</span>
                <span>{evidenceCount} Evidence Item{evidenceCount === 1 ? "" : "s"}</span>
              </div>
              <div className="flex items-center gap-2.5 ml-auto">
                <Button variant="secondary" size="md" onClick={closeLaunchModal} type="button">
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="md"
                  type="submit"
                  disabled={isLaunching}
                  icon={isLaunching ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                >
                  {isLaunching ? "Queuing Pipeline..." : "Dispatch Autonomous Run"}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
