import { useState, useEffect } from "react";
import {
  Bot,
  X,
  Terminal,
  StopCircle,
  Database,
  GitBranch,
  ExternalLink,
  Loader2,
  CheckCircle2,
  Clock,
  ShieldCheck,
} from "lucide-react";
import { useNav } from "../lib/nav";
import { usePipelineData } from "../lib/dataContext";
import { useToast } from "../lib/toast";

export function ActiveRunHud() {
  const { activeRunThreadId, setActiveRunThreadId, openInspector, isInspectorOpen } = useNav();
  const { contentItems, getWebsite, deleteContentItem } = usePipelineData();
  const { push } = useToast();
  const [cancelling, setCancelling] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Live timer for active run
  useEffect(() => {
    if (!activeRunThreadId) {
      setElapsedSeconds(0);
      return;
    }
    const timer = setInterval(() => {
      setElapsedSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [activeRunThreadId]);

  if (!activeRunThreadId) return null;

  // Find this run in contentItems; poller keeps status current
  const matchingItem = contentItems.find((c) => c.id === activeRunThreadId);
  const website = matchingItem ? getWebsite(matchingItem.websiteId) : null;
  const isUpstash = website?.storage_type !== "git";

  const title = matchingItem?.title || "Autonomous Pipeline Run";
  const status = matchingItem?.status || "Running";
  const factScore = matchingItem?.factCheckScore;
  const isAwaitingApproval = status === "Awaiting Approval";
  const isPublished = status === "Published";

  const formatElapsed = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return mins > 0 ? `${mins}m ${s < 10 ? "0" : ""}${s}s` : `${s}s`;
  };

  // Stage mapping
  const stages = [
    { label: "Research", active: true },
    { label: "Drafting", active: status !== "Idea" },
    { label: "Verification", active: status === "SEO Check" || isAwaitingApproval || isPublished },
    { label: "Gate", active: isAwaitingApproval || isPublished },
  ];

  const handleStopRun = async () => {
    if (!confirm("Are you sure you want to stop and archive this active pipeline run?")) return;
    setCancelling(true);
    try {
      await deleteContentItem(activeRunThreadId);
      push({
        title: "Pipeline run stopped",
        description: `Run ${activeRunThreadId.slice(0, 8)}... was terminated and archived.`,
        variant: "warn",
      });
      setActiveRunThreadId(null);
    } catch (err: any) {
      push({
        title: "Failed to stop run",
        description: err.message || "Could not terminate run.",
        variant: "danger",
      });
    } finally {
      setCancelling(false);
    }
  };

  return (
    <aside
      aria-label="Active run status"
      className={`fixed bottom-5 right-5 z-40 w-96 max-w-[calc(100vw-2.5rem)] rounded-none border p-4 shadow-2xl backdrop-blur-xl transition-all duration-300 animate-slideUp ${
        isAwaitingApproval
          ? "border-emerald-500/50 bg-[#07130f]/95 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.8),0_0_25px_rgba(16,185,129,0.2)]"
          : "border-blue-500/40 bg-[#090d16]/95 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.8),0_0_20px_rgba(59,130,246,0.15)]"
      }`}
    >
      {/* Top Bar with Live Indicator and Controls */}
      <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2">
          {/* Luminous Pulsing Live Dot */}
          <span className="relative flex h-2.5 w-2.5 items-center justify-center">
            <span
              className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${
                isAwaitingApproval
                  ? "animate-ping bg-emerald-400"
                  : isPublished
                  ? "bg-emerald-500"
                  : "animate-ping bg-blue-400"
              }`}
            />
            <span
              className={`relative inline-flex h-2 w-2 rounded-full ${
                isAwaitingApproval
                  ? "bg-emerald-400"
                  : isPublished
                  ? "bg-emerald-500"
                  : "bg-blue-500"
              }`}
            />
          </span>
          <span
            className={`font-mono text-[11px] font-semibold uppercase tracking-wider ${
              isAwaitingApproval ? "text-emerald-400" : "text-blue-400"
            }`}
          >
            {isAwaitingApproval ? "Review Gate Ready" : isPublished ? "Run Completed" : "LangGraph Pipeline"}
          </span>
          <span className="font-mono text-[10px] text-zinc-400">
            #{activeRunThreadId.slice(0, 8)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 font-mono text-[10px] text-zinc-400">
            <Clock size={10} className="text-zinc-500" />
            {formatElapsed(elapsedSeconds)}
          </span>
          <button
            onClick={() => setActiveRunThreadId(null)}
            className="cursor-pointer p-1 text-zinc-400 transition hover:text-white"
            aria-label="Dismiss HUD"
            title="Dismiss HUD (run keeps executing in background)"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Main Title and Target Website */}
      <div className="mt-3">
        <div className="flex items-center justify-between gap-2">
          <h4 className="truncate text-sm font-semibold tracking-tight text-white" title={title}>
            {title}
          </h4>
        </div>

        <div className="mt-1 flex items-center gap-2 text-[11px] text-zinc-400">
          <span className="truncate text-zinc-300 font-medium">{website?.name || "Next.js Target"}</span>
          <span>·</span>
          <span className="inline-flex items-center gap-1 font-mono text-[10px] text-emerald-400">
            {isUpstash ? <Database size={10} /> : <GitBranch size={10} />}
            {isUpstash ? "Rule A: 0s" : "Git"}
          </span>
          {factScore !== undefined && (
            <>
              <span>·</span>
              <span className="font-mono text-emerald-400">Fact: {factScore}%</span>
            </>
          )}
        </div>
      </div>

      {/* Mini Stage Stepper */}
      <div className="mt-3 flex items-center gap-1 border-t border-white/5 pt-2.5">
        {stages.map((st, idx) => (
          <div key={st.label} className="flex flex-1 items-center gap-1">
            <div
              className={`h-1 flex-1 transition-all ${
                st.active
                  ? isAwaitingApproval && st.label === "Gate"
                    ? "bg-emerald-400 animate-pulse"
                    : "bg-blue-500"
                  : "bg-white/10"
              }`}
            />
            {idx === stages.length - 1 ? null : <div className="h-0.5 w-0.5 bg-white/20" />}
          </div>
        ))}
      </div>
      <div className="mt-1 flex justify-between text-[10px] font-mono text-zinc-500">
        <span>Research</span>
        <span>Drafting</span>
        <span>Fact-Check</span>
        <span className={isAwaitingApproval ? "text-emerald-400 font-bold" : ""}>Review Gate</span>
      </div>

      {/* Action Row */}
      <div className="mt-3.5 flex items-center justify-between gap-2 border-t border-white/10 pt-3">
        {isAwaitingApproval ? (
          <button
            onClick={() => openInspector(activeRunThreadId, "publish")}
            className="inline-flex flex-1 cursor-pointer items-center justify-center gap-1.5 border border-emerald-500/50 bg-emerald-500/20 px-3 py-1.5 text-xs font-semibold text-emerald-200 transition hover:bg-emerald-500/30 active:scale-[0.985] shadow-lg shadow-emerald-950/40"
          >
            <CheckCircle2 size={13} className="text-emerald-400" />
            <span>Review & Approve (Gate)</span>
          </button>
        ) : isPublished ? (
          <button
            onClick={() => openInspector(activeRunThreadId, "draft")}
            className="inline-flex flex-1 cursor-pointer items-center justify-center gap-1.5 border border-emerald-500/40 bg-emerald-500/20 px-3 py-1.5 text-xs font-semibold text-emerald-200 transition hover:bg-emerald-500/30 active:scale-[0.985]"
          >
            <ExternalLink size={12} />
            <span>View Published Post</span>
          </button>
        ) : (
          <button
            onClick={() => openInspector(activeRunThreadId, "terminal")}
            className="inline-flex flex-1 cursor-pointer items-center justify-center gap-1.5 border border-blue-500/40 bg-blue-500/20 px-3 py-1.5 text-xs font-semibold text-blue-200 transition hover:bg-blue-500/30 active:scale-[0.985]"
          >
            <Terminal size={12} />
            {isInspectorOpen ? "Viewing Live Stream" : "Watch Live Stream"}
          </button>
        )}

        {/* Secondary Terminal Button when Awaiting Approval */}
        {isAwaitingApproval && (
          <button
            onClick={() => openInspector(activeRunThreadId, "terminal")}
            className="inline-flex cursor-pointer items-center justify-center p-1.5 border border-white/10 bg-white/5 text-zinc-300 transition hover:bg-white/10 hover:text-white"
            title="Inspect stream execution logs"
          >
            <Terminal size={13} />
          </button>
        )}

        <button
          onClick={handleStopRun}
          disabled={cancelling}
          className="inline-flex cursor-pointer items-center justify-center gap-1 border border-rose-500/30 bg-rose-500/10 px-2.5 py-1.5 text-xs font-medium text-rose-300 transition hover:bg-rose-500/20 active:scale-[0.985]"
          title="Stop execution and archive this run"
        >
          {cancelling ? <Loader2 size={12} className="animate-spin" /> : <StopCircle size={12} />}
          <span>Stop</span>
        </button>
      </div>
    </aside>
  );
}
