import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../../utils/cn";

type Props = {
  trigger: ReactNode;
  children: ReactNode;
  align?: "left" | "right";
  className?: string;
};

export function Dropdown({ trigger, children, align = "right", className }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node))
        setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div ref={ref} className="relative inline-block">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="focus:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--brand)] rounded-lg"
      >
        {trigger}
      </button>
      <div
        className={cn(
          "absolute top-[calc(100%+6px)] z-50 min-w-[180px] origin-top-right rounded-xl border bg-surface border-app shadow-pop p-1 animate-scale-in",
          align === "right" ? "right-0" : "left-0",
          !open && "hidden",
          className
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function DropdownItem({
  children,
  onClick,
  iconLeft,
  destructive,
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  iconLeft?: ReactNode;
  destructive?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-left text-[13px] transition-colors",
        destructive
          ? "text-[color:var(--danger)] hover:bg-[color:var(--danger-soft)]"
          : "text-app hover:bg-muted-soft",
        className
      )}
    >
      {iconLeft}
      {children}
    </button>
  );
}

export function DropdownSeparator() {
  return <div className="my-1 h-px bg-[color:var(--border)]" />;
}