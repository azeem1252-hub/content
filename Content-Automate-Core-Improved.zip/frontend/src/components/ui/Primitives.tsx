import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

export function Card({
  children,
  className,
  padded = true,
  hover = false,
}: {
  children: ReactNode;
  className?: string;
  padded?: boolean;
  hover?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border bg-surface border-app shadow-card",
        padded && "p-5",
        hover &&
          "transition-all duration-200 hover:shadow-soft hover:-translate-y-0.5",
        className
      )}
    >
      {children}
    </div>
  );
}

export function SectionHeader({
  title,
  description,
  action,
  className,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-end justify-between gap-4 mb-4",
        className
      )}
    >
      <div className="min-w-0">
        <h2 className="text-[15px] font-semibold text-app tracking-tight">
          {title}
        </h2>
        {description && (
          <p className="mt-1 text-[12.5px] text-muted">{description}</p>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-app bg-muted-soft/40 px-6 py-12 text-center">
      {icon && (
        <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-surface border-app text-muted">
          {icon}
        </div>
      )}
      <div className="text-[13.5px] font-medium text-app">{title}</div>
      {description && (
        <div className="mt-1 max-w-sm text-[12.5px] text-muted">
          {description}
        </div>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  size = "md",
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  size?: "sm" | "md";
  label?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative inline-flex shrink-0 cursor-pointer items-center rounded-full transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[color:var(--brand)] focus-visible:ring-offset-2 focus-visible:ring-offset-[color:var(--bg)]",
        size === "sm" ? "h-5 w-9" : "h-6 w-11",
        checked
          ? "bg-[color:var(--brand)]"
          : "bg-[color:var(--border-strong)]"
      )}
    >
      <span
        className={cn(
          "inline-block rounded-full bg-white shadow-sm transition-transform duration-200",
          size === "sm"
            ? "h-4 w-4"
            : "h-5 w-5",
          checked
            ? size === "sm"
              ? "translate-x-4"
              : "translate-x-5"
            : "translate-x-0.5"
        )}
      />
      {label && <span className="sr-only">{label}</span>}
    </button>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn("skeleton rounded-md", className)}
      aria-hidden="true"
    />
  );
}

export function Pill({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "brand" | "info" | "warn" | "danger";
  className?: string;
}) {
  const tones = {
    neutral: "bg-neutral-soft",
    brand: "bg-brand-soft",
    info: "bg-info-soft",
    warn: "bg-warn-soft",
    danger: "bg-danger-soft",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11.5px] font-medium",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}