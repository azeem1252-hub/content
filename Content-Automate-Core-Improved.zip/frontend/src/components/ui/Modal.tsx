import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { IconClose } from "../icons";
import { Button } from "./Button";
import { cn } from "../../utils/cn";
import type { ReactNode } from "react";

type Props = {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg";
};

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = "md",
}: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center p-4 animate-fade-in"
      aria-modal="true"
      role="dialog"
    >
      <div
        className="absolute inset-0 bg-[color:var(--bg)]/60 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div
        ref={ref}
        className={cn(
          "relative w-full rounded-2xl border bg-surface border-app shadow-pop animate-scale-in",
          size === "sm" && "max-w-sm",
          size === "md" && "max-w-md",
          size === "lg" && "max-w-2xl"
        )}
      >
        {(title || description) && (
          <div className="flex items-start justify-between gap-4 border-b border-app px-5 py-4">
            <div className="min-w-0">
              {title && (
                <div className="text-[15px] font-semibold text-app">
                  {title}
                </div>
              )}
              {description && (
                <div className="mt-1 text-[12.5px] text-muted">
                  {description}
                </div>
              )}
            </div>
            <button
              onClick={onClose}
              className="rounded-md p-1.5 text-subtle transition-colors hover:bg-muted-soft hover:text-app"
              aria-label="Close"
            >
              <IconClose size={16} />
            </button>
          </div>
        )}
        <div className="px-5 py-4">{children}</div>
        {footer && (
          <div className="flex items-center justify-end gap-2 border-t border-app px-5 py-3">
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title = "Are you sure?",
  description = "This action cannot be undone.",
  confirmLabel = "Confirm",
  destructive,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  description?: string;
  confirmLabel?: string;
  destructive?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      description={description}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant={destructive ? "danger" : "primary"}
            onClick={() => {
              onConfirm();
              onClose();
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div />
    </Modal>
  );
}