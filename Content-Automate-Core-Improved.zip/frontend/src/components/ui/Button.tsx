import { cn } from "../../utils/cn";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "outline";
type Size = "sm" | "md" | "lg";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  full?: boolean;
};

export function Button({
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  full,
  className,
  children,
  ...rest
}: Props) {
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[color:var(--brand)] focus-visible:ring-offset-[color:var(--bg)] disabled:opacity-50 disabled:pointer-events-none select-none cursor-pointer active:scale-[0.985]",
        size === "sm" && "h-8 px-3 text-[12.5px]",
        size === "md" && "h-9 px-3.5 text-[13px]",
        size === "lg" && "h-10 px-4 text-[13.5px]",
        full && "w-full",
        variant === "primary" &&
          "bg-[color:var(--brand)] text-white hover:bg-[color:var(--brand-hover)] shadow-soft hover:shadow-card",
        variant === "secondary" &&
          "bg-muted-soft text-app hover:bg-[var(--color-bg-soft)] border border-transparent hover:border-[var(--color-border)]",
        variant === "ghost" &&
          "bg-transparent text-app hover:bg-muted-soft hover:text-[var(--color-text)]",
        variant === "outline" &&
          "bg-transparent text-app border border-app hover:bg-muted-soft hover:border-[var(--color-border-strong)]",
        variant === "danger" &&
          "bg-[color:var(--danger)] text-white hover:opacity-90 shadow-soft",
        className
      )}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}