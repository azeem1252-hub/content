import { cn } from "../../utils/cn";
import type { StatusKind } from "../../lib/types";

const map: Record<
  StatusKind,
  { label: string; bg: string; dot: string }
> = {
  draft: {
    label: "Draft",
    bg: "bg-neutral-soft",
    dot: "bg-[color:var(--text-subtle)]",
  },
  "seo-review": {
    label: "SEO Review",
    bg: "bg-info-soft",
    dot: "bg-[color:var(--info)]",
  },
  "awaiting-approval": {
    label: "Awaiting Approval",
    bg: "bg-warn-soft",
    dot: "bg-[color:var(--warn)]",
  },
  scheduled: {
    label: "Scheduled",
    bg: "bg-info-soft",
    dot: "bg-[color:var(--info)]",
  },
  published: {
    label: "Published",
    bg: "bg-brand-soft",
    dot: "bg-[color:var(--brand)]",
  },
  failed: {
    label: "Failed",
    bg: "bg-danger-soft",
    dot: "bg-[color:var(--danger)]",
  },
  rejected: {
    label: "Rejected",
    bg: "bg-danger-soft",
    dot: "bg-[color:var(--danger)]",
  },
  paused: {
    label: "Paused",
    bg: "bg-neutral-soft",
    dot: "bg-[color:var(--text-subtle)]",
  },
};

export function StatusBadge({
  status,
  size = "md",
  className,
}: {
  status: StatusKind;
  size?: "sm" | "md";
  className?: string;
}) {
  const s = map[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md font-medium",
        s.bg,
        size === "sm" ? "px-1.5 py-0.5 text-[11px]" : "px-2 py-1 text-[12px]",
        className
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {s.label}
    </span>
  );
}

export function DotStatus({
  status,
  className,
}: {
  status: "ok" | "warn" | "error" | "muted";
  className?: string;
}) {
  const map2 = {
    ok: "bg-[color:var(--brand)]",
    warn: "bg-[color:var(--warn)]",
    error: "bg-[color:var(--danger)]",
    muted: "bg-[color:var(--text-subtle)]",
  };
  return (
    <span
      className={cn(
        "inline-block h-2 w-2 rounded-full",
        map2[status],
        className
      )}
    />
  );
}