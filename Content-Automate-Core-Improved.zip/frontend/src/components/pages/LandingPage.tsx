import { useEffect } from "react";
import { initSmoothScroll } from "../../lib/scroll";
import { Navbar } from "../landing/Navbar";
import { Hero } from "../landing/Hero";
import { IntegrationStrip } from "../landing/IntegrationStrip";
import { SignalSection } from "../landing/SignalSection";
import { InvestigationSection } from "../landing/InvestigationSection";
import { SeasonalitySection } from "../landing/SeasonalitySection";
import { ContentAutopsy } from "../landing/ContentAutopsy";
import { EvidenceDesk } from "../landing/EvidenceDesk";
import { PriorityBoard } from "../landing/PriorityBoard";
import { OpportunityExplorer } from "../landing/OpportunityExplorer";
import { ResearchWorkspace } from "../landing/ResearchWorkspace";
import { EditorialWorkbench } from "../landing/EditorialWorkbench";
import { ClaimVerification } from "../landing/ClaimVerification";
import { HumanApproval } from "../landing/HumanApproval";
import { VisibilitySection } from "../landing/VisibilitySection";
import { SearchAiVisibilityAudit } from "../SearchAiVisibilityAudit";
import { PublishingFlow } from "../landing/PublishingFlow";
import { MeasurementExperiment } from "../landing/MeasurementExperiment";
import { OperatingLoop } from "../landing/OperatingLoop";
import { UseCases } from "../landing/UseCases";
import { Integrations } from "../landing/Integrations";
import { SocialProof } from "../landing/SocialProof";
import { Pricing } from "../landing/Pricing";
import { FAQ } from "../landing/FAQ";
import { FinalCTA } from "../landing/FinalCTA";
import { Footer } from "../landing/Footer";
import { StoryRail } from "../landing/StoryRail";

export function LandingPage() {
  useEffect(() => {
    const destroy = initSmoothScroll();
    return () => {
      if (typeof destroy === "function") {
        destroy();
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#F7F6F2] text-[#161719] font-sans selection:bg-[#3157D5]/20 selection:text-[#161719]">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-[4px] focus:bg-[#161719] focus:px-4 focus:py-2 focus:text-sm focus:text-white"
      >
        Skip to content
      </a>

      {/* Primary Brand Navigation with Verlytic Brandmark & Studio Jump */}
      <Navbar />

      <main id="main">
        {/* 01. Hero & Signal Monitor */}
        <Hero />

        {/* 02. Search Console & CMS Integrations Bar */}
        <IntegrationStrip />

        {/* 03. Decay & Signal Detection */}
        <SignalSection />

        {/* 04. Deep Intelligence Investigation */}
        <InvestigationSection />

        {/* 05. Structural vs Seasonality Analysis */}
        <SeasonalitySection />

        {/* 06. Content Autopsy Diagnostic */}
        <ContentAutopsy />

        {/* 07. Grounded Evidence Desk */}
        <EvidenceDesk />

        {/* 08. Priority Matrix & Queue */}
        <PriorityBoard />

        {/* 09. Content Opportunity Explorer */}
        <OpportunityExplorer />

        {/* 10. Research Workspace */}
        <ResearchWorkspace />

        {/* 11. Editorial Workbench */}
        <EditorialWorkbench />

        {/* 12. Claim Verification & Source Citations */}
        <ClaimVerification />

        {/* 13. Human Approval Gate */}
        <HumanApproval />

        {/* 14. Search & AI Answer Visibility */}
        <VisibilitySection />

        {/* 14b. Interactive Live Search & AI Visibility Audit (GEO/AEO Audit) */}
        <section id="geo-audit" className="border-t border-line bg-white py-14 sm:py-20">
          <div className="mx-auto max-w-[1280px] px-5 sm:px-8 lg:px-10">
            <SearchAiVisibilityAudit initialDomain="filemint.dev" />
          </div>
        </section>

        {/* 15. Zero-Lag Multi-Site Publishing */}
        <PublishingFlow />

        {/* 16. Matched Controlled Experiments */}
        <MeasurementExperiment />

        {/* 17. Autonomous Operating Loop */}
        <OperatingLoop />

        {/* 18. Editorial Use Cases */}
        <UseCases />

        {/* 19. Integration Ecosystem */}
        <Integrations />

        {/* 20. Social Proof & Case Studies */}
        <SocialProof />

        {/* 21. Scalable Library Pricing */}
        <Pricing />

        {/* 22. Frequently Asked Questions */}
        <FAQ />

        {/* 23. Final Studio Action Desk */}
        <FinalCTA />
      </main>

      {/* Global Brand Footer */}
      <Footer />

      {/* Sticky Interactive Progress / Chapter Rail */}
      <StoryRail />
    </div>
  );
}