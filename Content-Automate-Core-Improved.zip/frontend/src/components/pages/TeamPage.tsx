import { useState } from "react";
import {
  Users,
  UserPlus,
  ShieldCheck,
  CheckCircle2,
  MoreHorizontal,
  Mail,
  Trash2,
  Edit2,
  Lock,
  Check,
  X,
} from "lucide-react";
import { Button } from "../ui";
import { Modal } from "../Modal";
import { useToast } from "../../lib/toast";

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: "Owner" | "Editorial Director" | "Fact-Check Reviewer" | "Content Author";
  status: "Active" | "Pending";
  lastActive: string;
  avatarColor: string;
}

export function TeamPage() {
  const { push } = useToast();

  const [members, setMembers] = useState<TeamMember[]>([
    {
      id: "u-1",
      name: "Azeem (Workspace Owner)",
      email: "azeem@dispatch.io",
      role: "Owner",
      status: "Active",
      lastActive: "Just now",
      avatarColor: "#3B82F6",
    },
    {
      id: "u-2",
      name: "Elena Rostova",
      email: "elena.r@editorial.co",
      role: "Editorial Director",
      status: "Active",
      lastActive: "2 hours ago",
      avatarColor: "#10B981",
    },
    {
      id: "u-3",
      name: "Marcus Vance",
      email: "m.vance@factcheck.org",
      role: "Fact-Check Reviewer",
      status: "Active",
      lastActive: "Yesterday",
      avatarColor: "#F59E0B",
    },
    {
      id: "u-4",
      name: "Devon Chen",
      email: "devon@systems.ai",
      role: "Content Author",
      status: "Pending",
      lastActive: "Invited 3d ago",
      avatarColor: "#8B5CF6",
    },
  ]);

  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteName, setInviteName] = useState("");
  const [inviteRole, setInviteRole] = useState<TeamMember["role"]>("Editorial Director");

  const handleSendInvite = () => {
    if (!inviteEmail.trim()) {
      push({ title: "Email required", description: "Please enter a valid member email address.", variant: "warn" });
      return;
    }
    const newMember: TeamMember = {
      id: `u-${Date.now()}`,
      name: inviteName.trim() || inviteEmail.split("@")[0],
      email: inviteEmail.trim(),
      role: inviteRole,
      status: "Pending",
      lastActive: "Invitation sent",
      avatarColor: "#60A5FA",
    };
    setMembers((prev) => [...prev, newMember]);
    setInviteOpen(false);
    setInviteEmail("");
    setInviteName("");
    push({
      title: "Invitation Dispatched",
      description: `Sent invite to ${newMember.email} as ${newMember.role}.`,
      variant: "success",
    });
  };

  const handleRemoveMember = (id: string, name: string) => {
    if (!confirm(`Revoke workspace access for ${name}?`)) return;
    setMembers((prev) => prev.filter((m) => m.id !== id));
    push({
      title: "Member Removed",
      description: `Revoked access for ${name}.`,
      variant: "info",
    });
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* SaaS Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)]">
              Team &amp; Permissions
            </h1>
            <span className="border border-blue-500/30 bg-blue-500/10 px-2.5 py-0.5 text-xs font-semibold text-blue-400 font-mono">
              {members.length} of 10 Seats Active
            </span>
          </div>
          <p className="mt-1.5 text-sm text-[var(--color-text-muted)]">
            Configure multi-user access control, assign editorial review gates, and manage workspace seats.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            icon={<UserPlus size={14} />}
            onClick={() => setInviteOpen(true)}
          >
            Invite Team Member
          </Button>
        </div>
      </div>

      {/* Members Table */}
      <div className="border bg-[var(--color-bg-elev)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
        <div className="px-5 py-4 border-b flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <Users size={16} className="text-blue-400" />
            Active Workspace Members
          </h3>
          <span className="text-xs text-[var(--color-text-muted)] font-mono">Role-Based Access Control</span>
        </div>

        <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
          {members.map((member) => (
            <div key={member.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:bg-[var(--color-bg-soft)] transition">
              <div className="flex items-center gap-3.5">
                <div
                  className="flex h-10 w-10 shrink-0 items-center justify-center font-bold text-sm text-white"
                  style={{ background: member.avatarColor }}
                >
                  {member.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[var(--color-text)]">{member.name}</span>
                    <span
                      className={`border px-2 py-0.2 font-mono text-[10px] font-bold ${
                        member.role === "Owner"
                          ? "border-purple-500/30 bg-purple-500/10 text-purple-400"
                          : member.role === "Editorial Director"
                          ? "border-blue-500/30 bg-blue-500/10 text-blue-400"
                          : member.role === "Fact-Check Reviewer"
                          ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400"
                          : "border-zinc-500/30 bg-zinc-500/10 text-zinc-300"
                      }`}
                    >
                      {member.role}
                    </span>
                    {member.status === "Pending" && (
                      <span className="border border-amber-500/30 bg-amber-500/10 px-1.5 py-0.2 font-mono text-[9px] text-amber-400">
                        Pending Invite
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 text-xs text-[var(--color-text-muted)] font-mono">
                    {member.email} · Last active: {member.lastActive}
                  </div>
                </div>
              </div>

              {member.role !== "Owner" && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleRemoveMember(member.id, member.name)}
                    className="p-1.5 text-zinc-400 hover:text-rose-400 cursor-pointer transition"
                    title="Remove member"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Permissions Matrix */}
      <div className="border bg-[var(--color-bg-elev)] p-5 overflow-x-auto" style={{ borderColor: "var(--color-border)" }}>
        <h3 className="text-sm font-bold text-[var(--color-text)] mb-3 flex items-center gap-2">
          <ShieldCheck size={16} className="text-emerald-400" />
          Role Capability Matrix
        </h3>
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b text-[var(--color-text-muted)] font-mono uppercase text-[10px]" style={{ borderColor: "var(--color-border)" }}>
              <th className="py-2.5 pr-4 font-semibold">Capability / Permission</th>
              <th className="py-2.5 px-3 font-semibold text-purple-400">Owner</th>
              <th className="py-2.5 px-3 font-semibold text-blue-400">Editorial Director</th>
              <th className="py-2.5 px-3 font-semibold text-emerald-400">Fact-Check Reviewer</th>
              <th className="py-2.5 px-3 font-semibold text-zinc-400">Content Author</th>
            </tr>
          </thead>
          <tbody className="divide-y text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
            <tr>
              <td className="py-2.5 pr-4 font-medium">Trigger Pipeline Runs (⌘N)</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
            </tr>
            <tr>
              <td className="py-2.5 pr-4 font-medium">Sign Off at Review Gate (Pillar A4)</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
            </tr>
            <tr>
              <td className="py-2.5 pr-4 font-medium">0-Second Publish to Next.js (Rule A)</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
            </tr>
            <tr>
              <td className="py-2.5 pr-4 font-medium">Manage Target Websites &amp; API Keys</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
            </tr>
            <tr>
              <td className="py-2.5 pr-4 font-medium">Billing &amp; Subscription Management</td>
              <td className="py-2.5 px-3 text-emerald-400 font-bold">✓</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
              <td className="py-2.5 px-3 text-zinc-600">—</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Invite Modal */}
      <Modal
        open={inviteOpen}
        onClose={() => setInviteOpen(false)}
        title="Invite New Team Member"
        description="Add a collaborator to this workspace. They will receive an invitation link via email."
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setInviteOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" icon={<UserPlus size={14} />} onClick={handleSendInvite}>
              Send Invitation
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
              Full Name
            </label>
            <input
              type="text"
              value={inviteName}
              onChange={(e) => setInviteName(e.target.value)}
              placeholder="e.g. Sarah Connor"
              className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
              Email Address
            </label>
            <input
              type="email"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              placeholder="sarah@enterprise.com"
              className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
              Assigned Role
            </label>
            <select
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as any)}
              className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            >
              <option value="Editorial Director">Editorial Director (Full Review &amp; Publishing)</option>
              <option value="Fact-Check Reviewer">Fact-Check Reviewer (Pillar A4 Claim Sign-off)</option>
              <option value="Content Author">Content Author (Drafting &amp; Topic Discovery)</option>
            </select>
          </div>
        </div>
      </Modal>
    </div>
  );
}
