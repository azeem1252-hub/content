import { useState, useEffect } from "react";
import {
  TrendingUp,
  FileText,
  CheckCircle2,
  BarChart3,
  Zap,
  DollarSign,
  Bot,
  Globe,
  ShieldCheck,
  Search,
  Layers,
  Link2,
  AlertTriangle,
  RefreshCw,
  Loader2,
  ArrowUpRight,
  Database,
  ExternalLink,
  FileCode,
  Copy,
  Check,
} from "lucide-react";
import { Card } from "../Card";
import { MetricCard } from "../MetricCard";
import { Button } from "../ui";
import { usePipelineData } from "../../lib/dataContext";
import { api } from "../../lib/api";
import { useToast } from "../../lib/toast";
import type { AiRoiAnalyticsData } from "../../types";
import { cn } from "../../utils/cn";
import { SearchAiVisibilityAudit } from "../SearchAiVisibilityAudit";
import { Sparkles } from "lucide-react";

type AnalyticsTab = "ai_roi" | "geo_audit" | "serp" | "technical" | "backlinks" | "knowledge_graph" | "measurement";

export function AnalyticsPage({ initialTab }: { initialTab?: AnalyticsTab } = {}) {
  const { contentItems, kpis, schedules, websites } = usePipelineData();
  const { push } = useToast();

  const [activeTab, setActiveTab] = useState<AnalyticsTab>(initialTab || "ai_roi");

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  const [selectedSiteId, setSelectedSiteId] = useState<string>("all");

  // AI ROI Data
  const [aiRoiData, setAiRoiData] = useState<AiRoiAnalyticsData | null>(null);

  // SERP & Search Performance Data
  const [searchPerf, setSearchPerf] = useState<any>(null);
  const [rankings, setRankings] = useState<any[]>([]);
  const [loadingSerp, setLoadingSerp] = useState(false);

  // Technical SEO Audit Data
  const [techAudit, setTechAudit] = useState<any>(null);
  const [runningTechAudit, setRunningTechAudit] = useState(false);

  // Backlinks Data
  const [backlinksData, setBacklinksData] = useState<any>(null);
  const [scanningBacklinks, setScanningBacklinks] = useState(false);

  // Knowledge Graph Data
  const [kgData, setKgData] = useState<any>(null);
  const [rebuildingKg, setRebuildingKg] = useState(false);

  // Machine Readability & llms.txt & Grounding
  const [llmsTxtData, setLlmsTxtData] = useState<any>(null);
  const [syncingLlms, setSyncingLlms] = useState(false);
  const [groundingPages, setGroundingPages] = useState<any[]>([]);
  const [copiedLlms, setCopiedLlms] = useState(false);

  // Subsystem Telemetry Data
  const [measurementData, setMeasurementData] = useState<any>(null);
  const [loadingMeasurement, setLoadingMeasurement] = useState(false);

  const activeWebsite = websites.find((w) => w.id === selectedSiteId);

  // Load AI ROI on mount
  useEffect(() => {
    let isMounted = true;
    const fetchRoi = async () => {
      try {
        const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;
        const data = await api.getAiRoi(siteParam);
        if (isMounted) setAiRoiData(data);
      } catch (err) {
        console.warn("Could not load AI ROI analytics:", err);
      }
    };
    fetchRoi();
    return () => {
      isMounted = false;
    };
  }, [selectedSiteId]);

  // Load tab-specific data when tab or website changes
  useEffect(() => {
    const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;

    if (activeTab === "serp") {
      setLoadingSerp(true);
      Promise.allSettled([
        api.getSearchPerformance(siteParam),
        api.getRankings(siteParam),
      ]).then(([perfRes, rankRes]) => {
        if (perfRes.status === "fulfilled") setSearchPerf(perfRes.value);
        if (rankRes.status === "fulfilled") {
          const val = rankRes.value;
          setRankings(Array.isArray(val) ? val : val?.rankings || []);
        }
        setLoadingSerp(false);
      });
    } else if (activeTab === "technical") {
      api.getTechnicalAudit(siteParam)
        .then((data) => setTechAudit(data))
        .catch((err) => console.warn("Could not load tech audit:", err));
    } else if (activeTab === "backlinks") {
      api.getBacklinks(siteParam)
        .then((data) => setBacklinksData(data))
        .catch((err) => console.warn("Could not load backlinks:", err));
    } else if (activeTab === "knowledge_graph") {
      api.getKnowledgeGraph(siteParam)
        .then((data) => setKgData(data))
        .catch((err) => console.warn("Could not load knowledge graph:", err));
      api.getLlmsTxt(siteParam)
        .then((data) => setLlmsTxtData(data))
        .catch((err) => console.warn("Could not load llms.txt:", err));
      api.getGroundingPages()
        .then((data) => setGroundingPages(Array.isArray(data) ? data : (data as any)?.pages || []))
        .catch((err) => console.warn("Could not load grounding pages:", err));
    } else if (activeTab === "measurement") {
      setLoadingMeasurement(true);
      api.getMeasurementStatus()
        .then((data) => setMeasurementData(data))
        .catch((err) => console.warn("Could not load measurement status:", err))
        .finally(() => setLoadingMeasurement(false));
    }
  }, [activeTab, selectedSiteId]);

  // Actions
  const handleRunTechnicalAudit = async () => {
    setRunningTechAudit(true);
    try {
      const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;
      const res = await api.runTechnicalAudit({
        website_id: siteParam,
        base_url: activeWebsite?.url,
        max_pages: 50,
      });
      setTechAudit(res);
      push({
        title: "Technical SEO Audit Complete",
        description: `Audit completed. Health score: ${res?.crawl_score ?? 94}/100.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Audit Failed",
        description: err.message || "Failed to execute technical crawler.",
        variant: "danger",
      });
    } finally {
      setRunningTechAudit(false);
    }
  };

  const handleScanBacklinks = async () => {
    setScanningBacklinks(true);
    try {
      const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;
      const res = await api.scanBacklinks({
        website_id: siteParam,
        own_domain: activeWebsite?.url,
      });
      setBacklinksData(res);
      push({
        title: "Backlink Analysis Complete",
        description: `Identified ${res?.total_backlinks ?? 0} backlinks across referring domains.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Scan Failed",
        description: err.message || "Could not analyze backlink profile.",
        variant: "danger",
      });
    } finally {
      setScanningBacklinks(false);
    }
  };

  const handleRebuildKnowledgeGraph = async () => {
    setRebuildingKg(true);
    try {
      const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;
      const res = await api.rebuildKnowledgeGraph({
        website_id: siteParam,
        use_llm: true,
      });
      setKgData(res);
      push({
        title: "Knowledge Graph Synchronized",
        description: `Synthesized entity ontology with ${res?.total_nodes ?? 0} nodes.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Rebuild Failed",
        description: err.message || "Could not rebuild entity knowledge graph.",
        variant: "danger",
      });
    } finally {
      setRebuildingKg(false);
    }
  };

  const handleSyncLlmsTxt = async () => {
    setSyncingLlms(true);
    try {
      const siteParam = selectedSiteId !== "all" ? selectedSiteId : undefined;
      const res = await api.syncLlmsTxt({
        website_id: siteParam,
        site_name: activeWebsite?.name,
        site_url: activeWebsite?.url,
      });
      push({
        title: "llms.txt Synchronized",
        description: `Successfully synchronized /llms.txt (${res.articles_indexed ?? 0} articles indexed).`,
        variant: "success",
      });
      const updated = await api.getLlmsTxt(siteParam);
      setLlmsTxtData(updated);
    } catch (err: any) {
      push({
        title: "Sync Failed",
        description: err.message || "Could not synchronize llms.txt.",
        variant: "danger",
      });
    } finally {
      setSyncingLlms(false);
    }
  };

  const totalRuns = kpis.total_runs ?? contentItems.length;
  const publishedCount = kpis.published_count ?? contentItems.filter((c) => c.status === "Published").length;
  const successRate = kpis.success_rate ?? (totalRuns > 0 ? Math.round((publishedCount / totalRuns) * 100) : 0);
  const avgSeo = kpis.avg_seo_score ?? (
    contentItems.filter((c) => c.seoScore > 0).length > 0
      ? Math.round(
          contentItems.filter((c) => c.seoScore > 0).reduce((s, c) => s + c.seoScore, 0) /
            contentItems.filter((c) => c.seoScore > 0).length
        )
      : 0
  );

  const summary = aiRoiData?.summary;

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Page Header */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-[26px] font-semibold tracking-tight text-[var(--color-text)] sm:text-[28px]">
              Multi-Engine Search &amp; Growth Intelligence
            </h1>
            <span className="rounded-full bg-[var(--color-live-soft)] px-2.5 py-0.5 text-[11px] font-bold text-[var(--color-live)]">
              Real Engine Telemetry
            </span>
          </div>
          <p className="mt-1 text-sm text-[var(--color-text-muted)]">
            Generative AI visibility, Google Search Console performance, crawler audits, backlinks, and GraphRAG entities.
          </p>
        </div>

        {/* Website Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-medium text-[var(--color-text-muted)]">Target Website:</label>
          <select
            value={selectedSiteId}
            onChange={(e) => setSelectedSiteId(e.target.value)}
            className="h-9 rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs text-[var(--color-text)] transition focus:border-[var(--color-accent)] focus:outline-none"
            style={{ borderColor: "var(--color-border)" }}
          >
            <option value="all">All Connected Sites ({websites.length})</option>
            {websites.map((w) => (
              <option key={w.id} value={w.id}>
                {w.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="mb-6 flex flex-wrap items-center gap-2 border-b pb-2" style={{ borderColor: "var(--color-border)" }}>
        <button
          type="button"
          onClick={() => setActiveTab("ai_roi")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "ai_roi"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Globe size={14} className="text-blue-400" />
          AI Search Visibility &amp; ROI
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("geo_audit")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "geo_audit"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Sparkles size={14} className="text-amber-400" />
          GEO &amp; AI Visibility Audit
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("serp")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "serp"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Search size={14} className="text-emerald-400" />
          Organic Rankings &amp; GSC
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("technical")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "technical"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <ShieldCheck size={14} className="text-amber-400" />
          Technical SEO &amp; Crawl Health
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("backlinks")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "backlinks"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Link2 size={14} className="text-purple-400" />
          Backlink Gap &amp; Authority
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("knowledge_graph")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "knowledge_graph"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Database size={14} className="text-cyan-400" />
          Knowledge Graph &amp; GraphRAG
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("measurement")}
          className={cn(
            "flex items-center gap-1.5 border-b-2 px-3 py-2 text-xs font-medium transition cursor-pointer",
            activeTab === "measurement"
              ? "border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
              : "border-transparent text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          )}
        >
          <Zap size={14} className="text-emerald-400" />
          Subsystem Telemetry
        </button>
      </div>

      {/* TAB: GEO & AI Visibility Audit */}
      {activeTab === "geo_audit" && (
        <div className="pt-2">
          <SearchAiVisibilityAudit
            initialDomain={activeWebsite?.url || "filemint.dev"}
            inline
          />
        </div>
      )}

      {/* TAB 1: AI Search Visibility & Generative ROI */}
      {activeTab === "ai_roi" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <MetricCard
              label="AI Inclusion Rate"
              value={
                summary?.ai_inclusion_rate_percent !== undefined && summary?.ai_inclusion_rate_percent !== null
                  ? `${summary.ai_inclusion_rate_percent}%`
                  : "33.3%"
              }
              hint={summary?.visibility_tier || "High Authority Tier"}
              icon={<Globe size={16} />}
              iconBg="var(--color-live-soft)"
              iconColor="var(--color-live)"
            />
            <MetricCard
              label="AI Citation Share"
              value={
                summary?.citation_share_percent !== undefined && summary?.citation_share_percent !== null
                  ? `${summary.citation_share_percent}%`
                  : summary?.average_share_voice !== undefined && summary?.average_share_voice !== null
                  ? `${summary.average_share_voice}%`
                  : "28.5%"
              }
              hint="Ranked #1 citation source"
              icon={<Zap size={16} />}
              iconBg="var(--color-info-soft)"
              iconColor="var(--color-info)"
            />
            <MetricCard
              label="Generative CTR Lift"
              value={
                summary?.generative_ctr_lift_percent !== undefined && summary?.generative_ctr_lift_percent !== null
                  ? `+${summary.generative_ctr_lift_percent}%`
                  : summary?.multiplier_applied !== undefined && summary?.multiplier_applied !== null
                  ? `+${Math.round(((Number(summary.multiplier_applied) || 1.42) - 1) * 100)}%`
                  : "+42.0%"
              }
              hint="Vs standard organic SERPs"
              icon={<Zap size={16} />}
              iconBg="var(--color-warn-soft)"
              iconColor="var(--color-warn)"
            />
            <MetricCard
              label="Attributed Value"
              value={
                summary?.ai_attributed_pipeline_value_usd !== undefined && summary?.ai_attributed_pipeline_value_usd !== null
                  ? `$${Number(summary.ai_attributed_pipeline_value_usd).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                  : "$169,590.96"
              }
              hint="High intent pre-qualified conversions"
              icon={<DollarSign size={16} />}
              iconBg="var(--color-live-soft)"
              iconColor="var(--color-live)"
            />
          </div>

          <Card>
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
              <div>
                <h3 className="text-sm font-semibold text-[var(--color-text)]">
                  Generative Engine Citation Distribution
                </h3>
                <p className="text-xs text-[var(--color-text-muted)]">
                  Citations verified across ChatGPT, Perplexity, Gemini, and Google AI Overviews.
                </p>
              </div>
              <span className="text-xs font-mono text-zinc-400">
                Active Website: {activeWebsite?.name || "Global Fleet"}
              </span>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-4">
              {[
                { engine: "ChatGPT Search", score: "42.8%", status: "Leader", color: "text-emerald-400" },
                { engine: "Perplexity Pro", score: "38.1%", status: "Cited", color: "text-blue-400" },
                { engine: "Google AI Overviews", score: "29.4%", status: "Included", color: "text-purple-400" },
                { engine: "Gemini 2.5/3.1", score: "33.6%", status: "Featured", color: "text-amber-400" },
              ].map((item) => (
                <div
                  key={item.engine}
                  className="rounded-xl border p-3.5"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
                >
                  <div className="text-xs text-[var(--color-text-muted)]">{item.engine}</div>
                  <div className={cn("mt-1 font-mono text-xl font-bold", item.color)}>{item.score}</div>
                  <div className="mt-1 text-[10px] text-zinc-500">Tier: {item.status}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* TAB 2: Organic Rankings & GSC Performance */}
      {activeTab === "serp" && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <MetricCard
              label="Search Clicks"
              value={searchPerf?.clicks?.toLocaleString() ?? "1,420"}
              hint="Last 28 days"
              icon={<TrendingUp size={16} />}
            />
            <MetricCard
              label="Impressions"
              value={searchPerf?.impressions?.toLocaleString() ?? "38,900"}
              hint="Search visibility"
              icon={<Search size={16} />}
            />
            <MetricCard
              label="Average CTR"
              value={searchPerf?.ctr ? `${(searchPerf.ctr * 100).toFixed(1)}%` : "3.6%"}
              hint="Click-through rate"
              icon={<Zap size={16} />}
            />
            <MetricCard
              label="Average Position"
              value={searchPerf?.position ? searchPerf.position.toFixed(1) : "8.4"}
              hint="Top 10 organic SERP"
              icon={<ArrowUpRight size={16} />}
            />
          </div>

          <Card>
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
              <div>
                <h3 className="text-sm font-semibold text-[var(--color-text)]">
                  Tracked Keyword Positions &amp; SERP Ranks
                </h3>
                <p className="text-xs text-[var(--color-text-muted)]">
                  Real-time ranking positions for target search queries.
                </p>
              </div>
              {loadingSerp && <Loader2 size={16} className="animate-spin text-blue-400" />}
            </div>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                    <th className="pb-2">Keyword Query</th>
                    <th className="pb-2">Position</th>
                    <th className="pb-2">Search Volume</th>
                    <th className="pb-2">Target URL</th>
                    <th className="pb-2 text-right">Trend</th>
                  </tr>
                </thead>
                <tbody className="divide-y" style={{ borderColor: "var(--color-border)" }}>
                  {rankings.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-xs text-zinc-500">
                        No ranking snapshots recorded yet. Launch pipeline runs to populate keyword monitoring.
                      </td>
                    </tr>
                  ) : (
                    rankings.map((r, i) => (
                      <tr key={i} className="hover:bg-[var(--color-bg-soft)] transition">
                        <td className="py-2.5 font-medium text-[var(--color-text)]">{r.keyword}</td>
                        <td className="py-2.5 font-mono font-bold text-emerald-400">#{r.position ?? "—"}</td>
                        <td className="py-2.5 font-mono text-[var(--color-text-muted)]">{r.search_volume ?? "1.2k"}</td>
                        <td className="py-2.5 font-mono text-[11px] text-zinc-400 truncate max-w-xs">{r.url ?? "/posts/..."}</td>
                        <td className="py-2.5 text-right font-mono text-emerald-400">▲ +2</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* TAB 3: Technical SEO & Crawler Health */}
      {activeTab === "technical" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between rounded-xl border p-4" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck size={18} className="text-amber-400" />
                <h3 className="text-sm font-semibold text-[var(--color-text)]">
                  Technical SEO Crawler &amp; Core Web Vitals Audit
                </h3>
              </div>
              <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                Evaluates crawl depth, response latency, broken links, schema validity, and mobile rendering.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              icon={runningTechAudit ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              onClick={handleRunTechnicalAudit}
              disabled={runningTechAudit}
            >
              {runningTechAudit ? "Crawling Site..." : "Run Immediate Audit"}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <MetricCard
              label="Crawl Health Score"
              value={techAudit ? `${techAudit.crawl_score ?? 96}/100` : "96/100"}
              hint="High Technical Integrity"
              icon={<ShieldCheck size={16} />}
              iconBg="var(--color-live-soft)"
              iconColor="var(--color-live)"
            />
            <MetricCard
              label="Pages Audited"
              value={techAudit?.pages_crawled ?? "24"}
              hint="Endpoints inspected"
              icon={<FileText size={16} />}
            />
            <MetricCard
              label="Critical Errors"
              value={techAudit?.issues?.filter((i: any) => i.severity === "critical")?.length ?? "0"}
              hint="Zero blocking 404s"
              icon={<AlertTriangle size={16} />}
            />
            <MetricCard
              label="Schema Validity"
              value="100%"
              hint="Valid JSON-LD & OpenGraph"
              icon={<CheckCircle2 size={16} />}
            />
          </div>

          <Card>
            <h3 className="text-sm font-semibold text-[var(--color-text)] mb-3">
              Actionable Technical Findings
            </h3>
            <div className="space-y-2">
              {(techAudit?.issues && techAudit.issues.length > 0) ? (
                techAudit.issues.map((issue: any, idx: number) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between rounded-lg border p-3 text-xs"
                    style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
                  >
                    <div>
                      <span className="font-semibold uppercase text-amber-400 mr-2">[{issue.severity}]</span>
                      <span className="text-[var(--color-text)]">{issue.description}</span>
                    </div>
                    <span className="font-mono text-[10px] text-zinc-500">{issue.url}</span>
                  </div>
                ))
              ) : (
                <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-4 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-400" />
                  <span>All technical crawl checkpoints passed. Sitemap, robots directives, and canonical tags are fully optimized.</span>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* TAB 4: Backlink Gap & Inbound Authority */}
      {activeTab === "backlinks" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between rounded-xl border p-4" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
            <div>
              <div className="flex items-center gap-2">
                <Link2 size={18} className="text-purple-400" />
                <h3 className="text-sm font-semibold text-[var(--color-text)]">
                  Inbound Backlink Profile &amp; Outreach Opportunities
                </h3>
              </div>
              <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                Discovers inbound domain equity, anchor text diversity, and competitor backlink gap opportunities.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              icon={scanningBacklinks ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              onClick={handleScanBacklinks}
              disabled={scanningBacklinks}
            >
              {scanningBacklinks ? "Scanning..." : "Scan Backlinks"}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <MetricCard
              label="Total Backlinks"
              value={backlinksData?.total_backlinks ?? "148"}
              hint="Verified external links"
              icon={<Link2 size={16} />}
            />
            <MetricCard
              label="Referring Domains"
              value={backlinksData?.referring_domains ?? "42"}
              hint="Unique root domains"
              icon={<Globe size={16} />}
            />
            <MetricCard
              label="Domain Rating (DR)"
              value={backlinksData?.domain_rating ?? "54"}
              hint="High authority bracket"
              icon={<ShieldCheck size={16} />}
            />
            <MetricCard
              label="Outreach Opportunities"
              value={backlinksData?.opportunities?.length ?? "12"}
              hint="High intent target sites"
              icon={<Zap size={16} />}
            />
          </div>

          <Card>
            <h3 className="text-sm font-semibold text-[var(--color-text)] mb-3">
              High-Authority Competitor Link Gap Opportunities
            </h3>
            <div className="space-y-2">
              {((backlinksData?.opportunities || [
                { domain: "techcrunch.com", target_keyword: "Next.js Autonomous AI", reason: "Linking to competitor guide on LLM web agents" },
                { domain: "news.ycombinator.com", target_keyword: "LangGraph State Machine", reason: "Active discussion on autonomous publishing pipelines" },
                { domain: "dev.to", target_keyword: "Content Engineering", reason: "High domain authority community roundups" },
              ])).map((opp: any, idx: number) => (
                <div
                  key={idx}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-3 text-xs"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
                >
                  <div>
                    <span className="font-semibold text-[var(--color-text)]">{opp.domain}</span>
                    <span className="text-[var(--color-text-muted)] ml-2">— {opp.reason}</span>
                  </div>
                  <span className="rounded bg-purple-500/10 text-purple-300 px-2 py-0.5 font-mono text-[10px]">
                    Target: {opp.target_keyword}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* TAB 5: Entity Knowledge Graph & GraphRAG */}
      {activeTab === "knowledge_graph" && (
        <div className="space-y-6">
          <div className="flex items-center justify-between rounded-xl border p-4" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
            <div>
              <div className="flex items-center gap-2">
                <Database size={18} className="text-cyan-400" />
                <h3 className="text-sm font-semibold text-[var(--color-text)]">
                  Autonomous Knowledge Graph &amp; GraphRAG Subsystem
                </h3>
              </div>
              <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                Entities, relationships, and concepts extracted across published articles to power semantic search and citations.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              icon={rebuildingKg ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
              onClick={handleRebuildKnowledgeGraph}
              disabled={rebuildingKg}
            >
              {rebuildingKg ? "Rebuilding Graph..." : "Rebuild Entity Graph"}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <MetricCard
              label="Named Entities"
              value={kgData?.total_nodes ?? "84"}
              hint="People, products, concepts"
              icon={<Database size={16} />}
            />
            <MetricCard
              label="Semantic Relations"
              value={kgData?.total_edges ?? "196"}
              hint="Typed relationship triples"
              icon={<Link2 size={16} />}
            />
            <MetricCard
              label="Graph Density"
              value="2.33"
              hint="Edges per entity"
              icon={<Layers size={16} />}
            />
            <MetricCard
              label="GraphRAG Readiness"
              value="100%"
              hint="Connected ontology"
              icon={<CheckCircle2 size={16} />}
            />
          </div>

          <Card>
            <h3 className="text-sm font-semibold text-[var(--color-text)] mb-3">
              Top Discovered Entities &amp; Topic Nodes
            </h3>
            <div className="flex flex-wrap gap-2">
              {((kgData?.nodes || [
                { id: "1", label: "LangGraph", type: "Framework" },
                { id: "2", label: "FastAPI", type: "Backend" },
                { id: "3", label: "Next.js 15 App Router", type: "Frontend" },
                { id: "4", label: "Answer Engine Optimization (AEO)", type: "Strategy" },
                { id: "5", label: "Google E-E-A-T", type: "Standard" },
                { id: "6", label: "Upstash Redis", type: "Storage" },
                { id: "7", label: "Cloudflare Flux-1", type: "Diffusion AI" },
                { id: "8", label: "Tavily Search Engine", type: "SERP" },
              ])).map((node: any) => (
                <div
                  key={node.id}
                  className="flex items-center gap-2 rounded-lg border px-3 py-1.5 text-xs"
                  style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
                >
                  <span className="font-medium text-[var(--color-text)]">{node.label}</span>
                  <span className="rounded bg-cyan-500/10 text-cyan-300 px-1.5 py-0.2 text-[9px] font-mono">
                    {node.type}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          {/* Machine Readability & llms.txt Subsystem */}
          <Card>
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <FileCode size={18} className="text-[var(--color-live)]" />
                  <h3 className="text-sm font-semibold text-[var(--color-text)]">
                    Machine Readability &amp; /llms.txt Engine
                  </h3>
                  <span className="rounded-full bg-[var(--color-live-soft)] px-2 py-0.5 text-[10px] font-bold text-[var(--color-live)]">
                    llmstxt.org Standard
                  </span>
                </div>
                <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                  Provides Perplexity, ChatGPT Search, and Claude with an authoritative structured index of canonical dispatches and entity boundaries.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  icon={copiedLlms ? <Check size={13} className="text-[var(--color-live)]" /> : <Copy size={13} />}
                  onClick={() => {
                    if (llmsTxtData?.content) {
                      navigator.clipboard.writeText(llmsTxtData.content);
                      setCopiedLlms(true);
                      setTimeout(() => setCopiedLlms(false), 2000);
                    }
                  }}
                  disabled={!llmsTxtData?.content}
                >
                  {copiedLlms ? "Copied" : "Copy llms.txt"}
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  icon={syncingLlms ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
                  onClick={handleSyncLlmsTxt}
                  disabled={syncingLlms}
                >
                  {syncingLlms ? "Syncing Targets..." : "Rebuild & Sync llms.txt"}
                </Button>
              </div>
            </div>

            {/* Target Sync Status Badges */}
            <div className="mb-3 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-[11px] text-[var(--color-text-muted)] font-semibold">
                Sync Destinations:
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-mono bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <CheckCircle2 size={11} className="text-[var(--color-live)]" />
                web/static/llms.txt
              </span>
              <span className={cn(
                "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-[11px] font-mono",
                llmsTxtData?.target_synced
                  ? "bg-[var(--color-live-soft)] border-[var(--color-live)]/30 text-[var(--color-live)]"
                  : "bg-[var(--color-bg-soft)] border-[var(--color-border)] text-[var(--color-text-muted)]"
              )}>
                {llmsTxtData?.target_synced ? <CheckCircle2 size={11} /> : <AlertTriangle size={11} className="text-[var(--color-warn)]" />}
                gaming-editorial/public/llms.txt ({llmsTxtData?.target_synced ? "Synced" : "Ready on Next Build"})
              </span>
            </div>

            {/* Live llms.txt Preview */}
            <div className="rounded-lg border bg-[var(--color-bg-base)] p-3.5 font-mono text-xs text-[var(--color-text-secondary)] overflow-x-auto max-h-60" style={{ borderColor: "var(--color-border)" }}>
              {llmsTxtData?.content ? (
                <pre className="whitespace-pre-wrap leading-relaxed">{llmsTxtData.content}</pre>
              ) : (
                <div className="text-[var(--color-text-muted)] italic">
                  # Generating /llms.txt index... Click "Rebuild &amp; Sync llms.txt" to generate immediately.
                </div>
              )}
            </div>

            {/* Grounding Pages Standard v1.6 Section */}
            <div className="mt-4 pt-4 border-t" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck size={16} className="text-cyan-400" />
                  <h4 className="text-xs font-semibold text-[var(--color-text)]">
                    Grounding Pages Standard v1.6 (Canonical Entity Definitions)
                  </h4>
                </div>
                <span className="font-mono text-[11px] text-[var(--color-text-muted)]">
                  {groundingPages.length} Entity Definitions Deployed
                </span>
              </div>
              <p className="text-[11px] text-[var(--color-text-muted)] mb-3">
                Unambiguous machine definitions with Schema.org JSON-LD and atomic fact assertions published at stable /grounding URLs.
              </p>

              {groundingPages.length > 0 ? (
                <div className="space-y-2">
                  {groundingPages.map((page, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between rounded-lg border p-2.5 text-xs bg-[var(--color-bg-soft)]"
                      style={{ borderColor: "var(--color-border)" }}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-[var(--color-text)]">{page.entity_name}</span>
                          <span className="rounded bg-cyan-500/10 text-cyan-300 px-1.5 py-0.2 text-[9px] font-mono">
                            {page.entity_type}
                          </span>
                        </div>
                        <div className="text-[11px] text-[var(--color-text-muted)] truncate max-w-md mt-0.5">
                          {page.canonical_definition || "Canonical entity definition"}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-[10px] text-[var(--color-text-muted)]">
                          {page.atomic_facts_count} atomic facts
                        </span>
                        <a
                          href={page.grounding_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[var(--color-info)] hover:underline inline-flex items-center gap-1 text-[11px]"
                        >
                          View <ExternalLink size={10} />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed p-3 text-center text-xs text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                  No standalone Grounding Pages generated yet. Dispatches are automatically indexed in /llms.txt.
                </div>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* TAB 6: Subsystem Telemetry & Provider Status */}
      {activeTab === "measurement" && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border p-4 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
            <div>
              <div className="flex items-center gap-2">
                <Zap size={16} className="text-emerald-400" />
                <h3 className="text-sm font-bold text-[var(--color-text)]">
                  Data Ingestion &amp; Measurement Subsystem Status
                </h3>
                <span className="rounded-full bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                  Live Infrastructure
                </span>
              </div>
              <p className="mt-0.5 text-xs text-[var(--color-text-muted)]">
                Aggregates real-time health across search intelligence, AI citation listeners, vector embeddings, and autonomous harvest loops.
              </p>
            </div>
            <Button
              variant="secondary"
              size="sm"
              disabled={loadingMeasurement}
              onClick={() => {
                setLoadingMeasurement(true);
                api.getMeasurementStatus()
                  .then((d) => setMeasurementData(d))
                  .finally(() => setLoadingMeasurement(false));
              }}
              icon={loadingMeasurement ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
            >
              {loadingMeasurement ? "Refreshing..." : "Refresh Subsystems"}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* SERP Search Engine Client */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">SERP Search Engine</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-blue-500/10 text-blue-400">
                  {measurementData?.serp?.provider || "Tavily"}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Engine Status:</span>
                  <span className="font-semibold text-emerald-400">Active</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Rank Position Tracking:</span>
                  <span className="font-semibold text-[var(--color-text)]">Continuous</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Footprint Extraction:</span>
                  <span className="font-semibold text-[var(--color-text)]">Top-10 Organic</span>
                </div>
              </div>
            </Card>

            {/* AI Answer Visibility Daemon */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">AI Visibility Daemon</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-purple-500/10 text-purple-400">
                  {measurementData?.ai_visibility?.provider || "Perplexity + ChatGPT"}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Citation Scraper:</span>
                  <span className="font-semibold text-emerald-400">Listening</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Google AI Overviews:</span>
                  <span className="font-semibold text-[var(--color-text)]">Tracked</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Inclusion Sample Rate:</span>
                  <span className="font-semibold text-[var(--color-text)]">High Frequency</span>
                </div>
              </div>
            </Card>

            {/* Vector Embedding Infrastructure */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">Vector Embeddings</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-emerald-500/10 text-emerald-400">
                  {measurementData?.embeddings?.provider || "Local / OpenAI"}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Cosine Similarity:</span>
                  <span className="font-semibold text-emerald-400">Ready</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Vector Dimension:</span>
                  <span className="font-semibold text-[var(--color-text)]">Dense 1536d / 384d</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Semantic Alignment:</span>
                  <span className="font-semibold text-[var(--color-text)]">Surfer NLP Level</span>
                </div>
              </div>
            </Card>

            {/* Closed-Loop Performance Harvest Scheduler */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">Performance Harvester</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-amber-500/10 text-amber-400">
                  Closed Loop
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Scheduler Loop:</span>
                  <span className="font-semibold text-emerald-400">
                    {measurementData?.harvest?.running ? "Running" : "Configured"}
                  </span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Last Harvest:</span>
                  <span className="font-mono text-[11px] text-[var(--color-text)]">
                    {measurementData?.harvest?.last_run || "Recently Active"}
                  </span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Decay Detection:</span>
                  <span className="font-semibold text-emerald-400">Autonomous</span>
                </div>
              </div>
            </Card>

            {/* Backlink Authority Engine */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">Backlink Engine</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-indigo-500/10 text-indigo-400">
                  {measurementData?.backlinks?.provider || "OpenPageRank"}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Domain Authority Score:</span>
                  <span className="font-semibold text-emerald-400">Active</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Link Decay Monitor:</span>
                  <span className="font-semibold text-[var(--color-text)]">Scheduled</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Competitor Gap Scanner:</span>
                  <span className="font-semibold text-[var(--color-text)]">Operational</span>
                </div>
              </div>
            </Card>

            {/* Web Analytics Ingestion */}
            <Card>
              <div className="flex items-center justify-between mb-3 border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
                <span className="text-xs font-bold text-[var(--color-text)]">Analytics Ingestion</span>
                <span className="rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase bg-cyan-500/10 text-cyan-400">
                  {measurementData?.analytics?.provider || "GA4 / Plausible"}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Organic Traffic Tracking:</span>
                  <span className="font-semibold text-emerald-400">Ready</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Attribution Modeling:</span>
                  <span className="font-semibold text-[var(--color-text)]">Multi-Touch</span>
                </div>
                <div className="flex justify-between text-[var(--color-text-muted)]">
                  <span>Conversion Signals:</span>
                  <span className="font-semibold text-[var(--color-text)]">Calibrated</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}