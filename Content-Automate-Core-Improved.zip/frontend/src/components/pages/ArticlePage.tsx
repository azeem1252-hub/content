import { ArticleDrawer } from "../ArticleDrawer";

export function ArticlePage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
      <ArticleDrawer inline />
    </div>
  );
}