import { useState, useEffect, useRef } from "react";
import {
 CheckCircle2,
 Bot,
 Sun,
 Moon,
 Bell,
 Loader2,
 ShieldAlert,
 Zap,
 Eye,
 EyeOff,
 KeyRound,
 FileCode,
 Check,
 GitBranch,
 ExternalLink,
 RefreshCw,
 Copy,
 CheckCheck,
 ShieldCheck,
 Globe,
 FileText,
  Sliders,
  Search,
  TrendingUp,
  Layers,
  Cpu,
} from "lucide-react";
import { SlackIcon } from "../SlackIcon";
import { Card } from "../Card";
import { Button } from "../ui";
import { useTheme } from "../../lib/theme";
import { useToast } from "../../lib/toast";
import { api } from "../../lib/api";
import { usePipelineData } from "../../lib/dataContext";
import type { SystemStatus } from "../../types";
import { cn } from "../../utils/cn";

type Section =
 | "ai"
 | "seo"
 | "embeddings"
 | "slack"
 | "publishing"
 | "grounding"
 | "workspace"
 | "websites"
 | "notifications"
 | "appearance";

const sections: { id: Section; label: string }[] = [
 { id: "ai", label: "AI & Image Engines" },
 { id: "seo", label: "SEO & DataForSEO" },
 { id: "embeddings", label: "Embeddings & Vectors" },
 { id: "slack", label: "Slack Review Gate" },
 { id: "publishing", label: "Publishing & GitHub" },
 { id: "grounding", label: "Grounding Pages (v1.6)" },
 { id: "workspace", label: "Workspace & Harvest" },
 { id: "websites", label: "Websites" },
 { id: "notifications", label: "Notifications" },
 { id: "appearance", label: "Appearance" },
];


interface ModelPresetsProps {
 presets: string[];
 current: string;
 onSelect: (m: string) => void;
}

export function ModelPresets({ presets, current, onSelect }: ModelPresetsProps) {
 return (
  <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
   <span className="text-[10px] text-[var(--color-text-muted)] font-medium">Flagship Presets:</span>
   {presets.map((p) => {
    const active = current.trim() === p.trim();
    return (
     <button
      key={p}
      type="button"
      onClick={() => onSelect(p)}
      className={cn(
       "rounded border px-2 py-0.5 font-mono text-[10px] transition cursor-pointer",
       active
        ? "border-[var(--color-primary)] bg-[var(--color-primary)]/10 font-semibold text-[var(--color-primary)] shadow-xs"
        : "border-[var(--color-border)] bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:border-[var(--color-primary)]"
      )}
     >
      {p}
     </button>
    );
   })}
  </div>
 );
}

export function SettingsPage() {
 const [section, setSection] = useState<Section>("ai");
 const { theme, setTheme } = useTheme();
 const { push } = useToast();
 const { websites } = usePipelineData();
 const defaultWebsite = websites.find((site) => site.is_default) || websites[0];

 const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
 const [saving, setSaving] = useState(false);
 const [testingEngine, setTestingEngine] = useState(false);
 const [testingGemini, setTestingGemini] = useState(false);
 const [testingCloudflare, setTestingCloudflare] = useState(false);
 const [savingCloudflare, setSavingCloudflare] = useState(false);
 const [testingMistral, setTestingMistral] = useState(false);
 const [testingGroq, setTestingGroq] = useState(false);
 const [testingOpenai, setTestingOpenai] = useState(false);
 const [testingAnthropic, setTestingAnthropic] = useState(false);
 const [testingQwen, setTestingQwen] = useState(false);
 const [testingGlm, setTestingGlm] = useState(false);
 const [testingKimi, setTestingKimi] = useState(false);
 const [testingDeepseek, setTestingDeepseek] = useState(false);
 const [testingCustomLlm, setTestingCustomLlm] = useState(false);
 const [testingOpenaiImage, setTestingOpenaiImage] = useState(false);
 const [testingCustomImage, setTestingCustomImage] = useState(false);
 const [testingCodex, setTestingCodex] = useState(false);
 const [capturingCodex, setCapturingCodex] = useState(false);
 const [startingCodexDevice, setStartingCodexDevice] = useState(false);
 const [codexDeviceData, setCodexDeviceData] = useState<{
  user_code?: string;
  verification_uri?: string;
  device_auth_id?: string;
  interval?: number;
 } | null>(null);
 const [codexPolling, setCodexPolling] = useState(false);
 const [userCodeCopied, setUserCodeCopied] = useState(false);
 const codexPollTimerRef = useRef<any>(null);
 const [testingTavily, setTestingTavily] = useState(false);
 const [testingDataforseo, setTestingDataforseo] = useState(false);
 const [testingSerper, setTestingSerper] = useState(false);
 const [testingEmbedding, setTestingEmbedding] = useState(false);

 // Closed-Loop Harvest & Crawler Policy
 const [harvestStatus, setHarvestStatus] = useState<any>(null);
 const [runningHarvest, setRunningHarvest] = useState(false);
 const [crawlerUrl, setCrawlerUrl] = useState(defaultWebsite?.url || "https://your-domain.vercel.app");
 const [crawlerTesting, setCrawlerTesting] = useState(false);
 const [crawlerResult, setCrawlerResult] = useState<any>(null);

 // Grounding Page Standard v1.6 state
 const [groundingPages, setGroundingPages] = useState<any[]>([]);
 const [loadingGp, setLoadingGp] = useState(false);
 const [generatingGp, setGeneratingGp] = useState(false);
 const [gpEntityName, setGpEntityName] = useState(defaultWebsite?.name || "The Dispatch Editorial Bureau");
 const [gpCanonicalUrl, setGpCanonicalUrl] = useState(defaultWebsite?.url?.replace(/\/api\/posts\/?$/, "") || "https://dispatch.local");
 const [gpEntityType, setGpEntityType] = useState("Organization");
 const [gpDefinition, setGpDefinition] = useState("An authoritative enterprise publication delivering fact-verified technical architectures, systems benchmarks, and generative search specifications.");
 const [gpWhatNot, setGpWhatNot] = useState("Not a generic AI content mill\nNot unverified black-box claims\nNot affiliated with automated spam networks");
 const [gpFacts, setGpFacts] = useState("Publishes empirical software engineering dispatches.\nEnforces a 4-layer verification framework with multi-source web evidence.\nMaintains programmatic Schema.org Article, FAQPage, and Organization entity graphs.\nSynchronizes machine-readable /llms.txt manifests for AI search crawlers.");
 const [gpSameAs, setGpSameAs] = useState("https://github.com/Azeem1252/content-pipeline-agent");

 const loadGroundingPages = async () => {
  setLoadingGp(true);
  try {
   const pages = await api.getGroundingPages();
   setGroundingPages(pages || []);
  } catch (err: any) {
   console.warn("Could not load grounding pages:", err);
  } finally {
   setLoadingGp(false);
  }
 };

 useEffect(() => {
  if (section === "grounding") {
   loadGroundingPages();
  }
 }, [section]);

 const handleGenerateGroundingPage = async () => {
  if (!gpEntityName.trim() || !gpCanonicalUrl.trim()) {
   push({
    title: "Validation Error",
    description: "Entity Name and Canonical URL are required.",
    variant: "warn",
   });
   return;
  }
  setGeneratingGp(true);
  try {
   const notList = gpWhatNot.split("\n").map((s) => s.trim()).filter(Boolean);
   const factsList = gpFacts.split("\n").map((s) => s.trim()).filter(Boolean).map((f) => ({ fact: f }));
   const sameAsList = gpSameAs.split("\n").map((s) => s.trim()).filter(Boolean);

   const res = await api.generateGroundingPage({
    entity_name: gpEntityName.trim(),
    canonical_url: gpCanonicalUrl.trim(),
    entity_type: gpEntityType,
    stable_definition: gpDefinition.trim(),
    what_it_is_not: notList,
    atomic_facts: factsList,
    same_as_links: sameAsList,
   });

   push({
    title: "Grounding Page Deployed!",
    description: `Successfully published Grounding Page Standard v1.6 for ${gpEntityName}.`,
    variant: "success",
   });
   await loadGroundingPages();
  } catch (err: any) {
   push({
    title: "Generation Error",
    description: err.message || "Failed to generate Grounding Page.",
    variant: "danger",
   });
  } finally {
   setGeneratingGp(false);
  }
 };

 // Global & per-field secret visibility toggles
 const [showAllKeys, setShowAllKeys] = useState(false);
 const [revealedFields, setRevealedFields] = useState<Record<string, boolean>>({});

 const toggleFieldVisibility = (field: string) => {
 setRevealedFields((prev) => ({ ...prev, [field]: !prev[field] }));
 };

 // Form fields mapped to .env
 const [preferredProvider, setPreferredProvider] = useState("mistral");
 const [groqKey, setGroqKey] = useState("");
 const [groqModel, setGroqModel] = useState("qwen/qwen3.8-27b");
 const [mistralKey, setMistralKey] = useState("");
 const [mistralModel, setMistralModel] = useState("ministral-14b-latest");
 const [openaiKey, setOpenaiKey] = useState("");
 const [openaiModel, setOpenaiModel] = useState("gpt-4o-mini");
 const [anthropicKey, setAnthropicKey] = useState("");
 const [anthropicModel, setAnthropicModel] = useState("claude-3-5-sonnet-20241022");
 const [qwenKey, setQwenKey] = useState("");
 const [qwenModel, setQwenModel] = useState("qwen-plus");
 const [glmKey, setGlmKey] = useState("");
 const [glmModel, setGlmModel] = useState("glm-4-plus");
 const [kimiKey, setKimiKey] = useState("");
 const [kimiModel, setKimiModel] = useState("moonshot-v1-8k");
 const [deepseekKey, setDeepseekKey] = useState("");
 const [deepseekModel, setDeepseekModel] = useState("deepseek-chat");
 const [customLlmBaseUrl, setCustomLlmBaseUrl] = useState("");
 const [customLlmKey, setCustomLlmKey] = useState("");
 const [customLlmModel, setCustomLlmModel] = useState("");
 const [geminiKey, setGeminiKey] = useState("");
 const [openaiImageKey, setOpenaiImageKey] = useState("");
 const [openaiImageModel, setOpenaiImageModel] = useState("dall-e-3");
 const [customImageUrl, setCustomImageUrl] = useState("");
 const [customImageKey, setCustomImageKey] = useState("");
 const [customImageModel, setCustomImageModel] = useState("");
 const [geminiImageModel, setGeminiImageModel] = useState("gemini-3.1-flash-image-preview");
 const [cfAccountId, setCfAccountId] = useState("");
 const [cfApiToken, setCfApiToken] = useState("");
 const [cfModel, setCfModel] = useState("@cf/black-forest-labs/flux-1-schnell");
 const [tavilyKey, setTavilyKey] = useState("");
 const [codexToken, setCodexToken] = useState("");
 const [slackBotToken, setSlackBotToken] = useState("");
 const [slackAppToken, setSlackAppToken] = useState("");
 const [slackChannelId, setSlackChannelId] = useState("");
 const [slackSigningSecret, setSlackSigningSecret] = useState("");
 const [imageEngineOrder, setImageEngineOrder] = useState("cloudflare,gemini,codex,tavily");
 const [autoPublishApproved, setAutoPublishApproved] = useState(false);
 const [requireHumanGate, setRequireHumanGate] = useState(true);
 const [generateSocialAssets, setGenerateSocialAssets] = useState(true);
 const [notifyReviewNeeded, setNotifyReviewNeeded] = useState(true);
 const [notifyPublished, setNotifyPublished] = useState(true);
 const [notifySlackSync, setNotifySlackSync] = useState(true);
 const [githubToken, setGithubToken] = useState("");
 const [githubRepo, setGithubRepo] = useState("");
 const [githubBranch, setGithubBranch] = useState("main");
 const [nextjsPublicDir, setNextjsPublicDir] = useState("");
 const [testingGithub, setTestingGithub] = useState(false);
 const [savingGithub, setSavingGithub] = useState(false);
 const [dataforseoLogin, setDataforseoLogin] = useState("");
 const [dataforseoPassword, setDataforseoPassword] = useState("");
 const [serperKey, setSerperKey] = useState("");
 const [openpagerankKey, setOpenpagerankKey] = useState("");
 const [embeddingProvider, setEmbeddingProvider] = useState("local");
 const [embeddingKey, setEmbeddingKey] = useState("");
 const [embeddingModel, setEmbeddingModel] = useState("");

 const initialSnapshotRef = useRef<string>("");
 const getCurrentSnapshot = () =>
  JSON.stringify({
   preferredProvider,
   groqModel,
   mistralModel,
   openaiModel,
   anthropicModel,
   qwenModel,
   glmModel,
   kimiModel,
   deepseekModel,
   customLlmBaseUrl,
   customLlmModel,
   geminiImageModel,
   openaiImageModel,
   customImageUrl,
   customImageModel,
   cfAccountId,
   cfModel,
   imageEngineOrder,
   autoPublishApproved,
   requireHumanGate,
   generateSocialAssets,
   notifyReviewNeeded,
   notifyPublished,
   notifySlackSync,
   githubRepo,
   githubBranch,
   nextjsPublicDir,
  });

 const refreshSystemStatus = async () => {
 try {
 setSystemStatus(await api.getSystemStatus());
 } catch (err) {
 // A successful save or probe remains successful if the follow-up refresh fails.
 console.error("Failed to refresh system settings status:", err);
 }
 };

 useEffect(() => {
 async function load() {
 try {
 const s = await api.getSystemStatus();
 setSystemStatus(s);
   setTimeout(() => { initialSnapshotRef.current = getCurrentSnapshot(); }, 100);
 if (s.preferred_provider) setPreferredProvider(s.preferred_provider);
 if (s.groq?.model) setGroqModel(s.groq.model);
 if (s.mistral?.model) setMistralModel(s.mistral.model);
 if (s.openai?.model) setOpenaiModel(s.openai.model);
 if (s.claude?.model) setAnthropicModel(s.claude.model);
 if (s.qwen?.model) setQwenModel(s.qwen.model);
 if (s.glm?.model) setGlmModel(s.glm.model);
 if (s.kimi?.model) setKimiModel(s.kimi.model);
 if (s.deepseek?.model) setDeepseekModel(s.deepseek.model);
 if (s.custom_llm?.base_url) setCustomLlmBaseUrl(s.custom_llm.base_url);
 if (s.custom_llm?.model) setCustomLlmModel(s.custom_llm.model);
 if (s.gemini?.model) setGeminiImageModel(s.gemini.model);
 if (s.openai_image?.model) setOpenaiImageModel(s.openai_image.model);
 if (s.custom_image?.endpoint_url) setCustomImageUrl(s.custom_image.endpoint_url);
 if (s.custom_image?.model) setCustomImageModel(s.custom_image.model);
 if (s.cloudflare?.account_id) {
 let acct = s.cloudflare.account_id.trim();
 if (acct.length >= 20 && acct.length % 2 === 0) {
 const half = acct.length / 2;
 if (acct.slice(0, half) === acct.slice(half)) acct = acct.slice(0, half);
 }
 setCfAccountId(acct);
 }
 if (s.cloudflare?.model) setCfModel(s.cloudflare.model);
 if (s.slack?.channel_id) setSlackChannelId(s.slack.channel_id);
 if (s.image?.engine_order) setImageEngineOrder(s.image.engine_order);
 if (s.github?.repo) setGithubRepo(s.github.repo);
 if (s.github?.branch) setGithubBranch(s.github.branch);
 if (s.github?.nextjs_public_dir) setNextjsPublicDir(s.github.nextjs_public_dir);
 if (s.publishing) {
 setRequireHumanGate(s.publishing.require_human_gate !== false);
 setAutoPublishApproved(Boolean(s.publishing.auto_publish_approved) && s.publishing.require_human_gate === false);
 setGenerateSocialAssets(s.publishing.generate_social_assets !== false);
 }
 if (s.notifications) {
 setNotifyReviewNeeded(s.notifications.notify_review_needed !== false);
 setNotifyPublished(s.notifications.notify_published !== false);
 setNotifySlackSync(s.notifications.notify_slack_sync !== false);
 }
 if (s.dataforseo?.login) setDataforseoLogin(s.dataforseo.login);
 if (s.embeddings?.provider) setEmbeddingProvider(s.embeddings.provider);
 if (s.embeddings?.model) setEmbeddingModel(s.embeddings.model);
 } catch (err) {
 console.error("Failed to load system settings from .env:", err);
 }
 }
 load();
 return () => {
  if (codexPollTimerRef.current) clearInterval(codexPollTimerRef.current);
 };
 }, []);


 const handleSave = async () => {
 if (!systemStatus) {
 push({ title: "Settings are still loading", description: "Wait for the current settings to load before saving.", variant: "warn" });
 return;
 }
 setSaving(true);
 try {
 const payload: Record<string, any> = {
 preferred_provider: preferredProvider,
 groq_model: groqModel,
 mistral_model: mistralModel,
 openai_model: openaiModel,
 anthropic_model: anthropicModel,
 qwen_model: qwenModel,
 glm_model: glmModel,
 kimi_model: kimiModel,
 deepseek_model: deepseekModel,
 custom_llm_base_url: customLlmBaseUrl,
 custom_llm_model: customLlmModel,
 openai_image_model: openaiImageModel,
 custom_image_url: customImageUrl,
 custom_image_model: customImageModel,
 gemini_image_model: geminiImageModel,
 cloudflare_account_id: cfAccountId,
 cloudflare_image_model: cfModel,
 slack_channel_id: slackChannelId,
 image_engine_order: imageEngineOrder,
 auto_publish_approved: autoPublishApproved,
 require_human_gate: requireHumanGate,
 generate_social_assets: generateSocialAssets,
 notify_review_needed: notifyReviewNeeded,
 notify_published: notifyPublished,
 notify_slack_sync: notifySlackSync,
 github_repo: githubRepo.trim().replace(/^https?:\/\/github\.com\//, "").replace(/\/+$/, ""),
 github_branch: githubBranch.trim() || "main",
 nextjs_public_dir: nextjsPublicDir.trim(),
 };

 // Secret fields are write-only: blank means "leave the saved value alone".
 // This also prevents a partially loaded form from clearing existing credentials.
 if (groqKey.trim()) payload.groq_api_key = groqKey.trim();
 if (mistralKey.trim()) payload.mistral_api_key = mistralKey.trim();
 if (openaiKey.trim()) payload.openai_api_key = openaiKey.trim();
 if (anthropicKey.trim()) payload.anthropic_api_key = anthropicKey.trim();
 if (qwenKey.trim()) payload.qwen_api_key = qwenKey.trim();
 if (glmKey.trim()) payload.glm_api_key = glmKey.trim();
 if (kimiKey.trim()) payload.kimi_api_key = kimiKey.trim();
 if (deepseekKey.trim()) payload.deepseek_api_key = deepseekKey.trim();
 if (customLlmKey.trim()) payload.custom_llm_api_key = customLlmKey.trim();
 if (openaiImageKey.trim()) payload.openai_image_key = openaiImageKey.trim();
 if (customImageKey.trim()) payload.custom_image_key = customImageKey.trim();
 if (geminiKey.trim()) payload.gemini_api_key = geminiKey.trim();
 if (cfApiToken.trim()) payload.cloudflare_api_token = cfApiToken.trim();
 if (tavilyKey.trim()) payload.tavily_api_key = tavilyKey.trim();
 if (codexToken.trim()) payload.codex_session_token = codexToken.trim();
 if (slackBotToken.trim()) payload.slack_bot_token = slackBotToken.trim();
 if (slackAppToken.trim()) payload.slack_app_token = slackAppToken.trim();
 if (slackSigningSecret.trim()) payload.slack_signing_secret = slackSigningSecret.trim();
 if (githubToken.trim()) payload.github_token = githubToken.trim();
 if (dataforseoLogin.trim()) payload.dataforseo_login = dataforseoLogin.trim();
 if (dataforseoPassword.trim()) payload.dataforseo_password = dataforseoPassword.trim();
 if (serperKey.trim()) payload.serper_api_key = serperKey.trim();
 if (openpagerankKey.trim()) payload.openpagerank_api_key = openpagerankKey.trim();
 payload.embedding_provider = embeddingProvider;
 if (embeddingKey.trim()) payload.embedding_api_key = embeddingKey.trim();
 if (embeddingModel.trim()) payload.embedding_model = embeddingModel.trim();


 await api.saveSettings(payload);
 push({
 title: "Settings saved to .env",
 description: "Credentials and models updated in .env and reloaded into agent runtime.",
 variant: "success",
 });

 // Reload updated status from backend
 await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
 } catch (err: any) {
 push({
 title: "Save failed",
 description: err.message || "Failed to update configuration in .env.",
 variant: "danger",
 });
 } finally {
 setSaving(false);
 }
 };

 const handleTestSlack = async () => {
 setTestingEngine(true);
 try {
 const res = await api.testSlackGlobal(
 slackBotToken || undefined,
 slackChannelId || undefined
 );
 if (res.ok || res.status === "ok") {
 push({
 title: "Slack Test Passed",
 description: "Successfully connected to Slack workspace.",
 variant: "success",
 });
 } else {
 push({
 title: "Slack Warning",
 description: res.error || res.message || "Slack connection check failed.",
 variant: "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "Test failed",
 description: err.message || "Could not ping Slack API.",
 variant: "danger",
 });
 } finally {
 setTestingEngine(false);
 }
 };

 const handleTestDataforseo = async () => {
  setTestingDataforseo(true);
  try {
   const res = await api.testDataforseo(dataforseoLogin || undefined, dataforseoPassword || undefined);
   if (res.ok) {
    push({
     title: "DataForSEO Connected",
     description: res.message || "Successfully authenticated with DataForSEO Labs API.",
     variant: "success",
    });
   } else {
    push({
     title: "DataForSEO Failed",
     description: res.error || "Authentication failed. Check your login and API password.",
     variant: "danger",
    });
   }
  } catch (e: any) {
   push({ title: "DataForSEO Error", description: e.message, variant: "danger" });
  } finally {
   setTestingDataforseo(false);
  }
 };

 const handleTestEmbedding = async () => {
  setTestingEmbedding(true);
  try {
   const res = await api.testEmbedding(embeddingProvider, embeddingKey || undefined, embeddingModel || undefined);
   if (res.ok) {
    push({
     title: "Embedding Engine Verified",
     description: res.message,
     variant: "success",
    });
   } else {
    push({
     title: "Embedding Test Failed",
     description: res.error,
     variant: "danger",
    });
   }
  } catch (e: any) {
   push({ title: "Embedding Test Error", description: e.message, variant: "danger" });
  } finally {
   setTestingEmbedding(false);
  }
 };

 const handleTestSerper = async () => {
  setTestingSerper(true);
  try {
   const res = await api.testSerper(serperKey || undefined);
   if (res.ok) {
    push({ title: "Serper Connected", description: res.message, variant: "success" });
   } else {
    push({ title: "Serper Error", description: res.error, variant: "danger" });
   }
  } catch (e: any) {
   push({ title: "Serper Test Error", description: e.message, variant: "danger" });
  } finally {
   setTestingSerper(false);
  }
 };

 const handleTestLLM = async (provider: string) => {
  let key = "";
  let model = "";
  let baseUrl = "";
  let label = provider;

  if (provider === "mistral") {
   setTestingMistral(true);
   key = mistralKey;
   model = mistralModel;
   label = "Mistral AI";
  } else if (provider === "groq") {
   setTestingGroq(true);
   key = groqKey;
   model = groqModel;
   label = "Groq Inference";
  } else if (provider === "openai") {
   setTestingOpenai(true);
   key = openaiKey;
   model = openaiModel;
   label = "OpenAI";
  } else if (provider === "claude") {
   setTestingAnthropic(true);
   key = anthropicKey;
   model = anthropicModel;
   label = "Anthropic Claude";
  } else if (provider === "qwen") {
   setTestingQwen(true);
   key = qwenKey;
   model = qwenModel;
   label = "Alibaba Qwen";
  } else if (provider === "glm") {
   setTestingGlm(true);
   key = glmKey;
   model = glmModel;
   label = "Zhipu GLM";
  } else if (provider === "kimi") {
   setTestingKimi(true);
   key = kimiKey;
   model = kimiModel;
   label = "Moonshot Kimi";
  } else if (provider === "deepseek") {
   setTestingDeepseek(true);
   key = deepseekKey;
   model = deepseekModel;
   label = "DeepSeek";
  } else if (provider === "custom") {
   setTestingCustomLlm(true);
   key = customLlmKey;
   model = customLlmModel;
   baseUrl = customLlmBaseUrl;
   label = "Custom LLM";
  }

  try {
   const res = await api.testLLM(provider, key || undefined, model || undefined, baseUrl || undefined);
   if (res.ok) {
    push({
     title: `${label} Operational`,
     description: res.message || "Model responded successfully.",
     variant: "success",
    });
   } else {
    push({
     title: `${label} Warning`,
     description: res.error || "Inference check failed.",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Test Failed",
    description: err.message || `Could not ping ${label} inference API.`,
    variant: "danger",
   });
  } finally {
   if (provider === "mistral") setTestingMistral(false);
   else if (provider === "groq") setTestingGroq(false);
   else if (provider === "openai") setTestingOpenai(false);
   else if (provider === "claude") setTestingAnthropic(false);
   else if (provider === "qwen") setTestingQwen(false);
   else if (provider === "glm") setTestingGlm(false);
   else if (provider === "kimi") setTestingKimi(false);
   else if (provider === "deepseek") setTestingDeepseek(false);
   else if (provider === "custom") setTestingCustomLlm(false);
  }
 };

 const handleCaptureCodexLocal = async () => {
  setCapturingCodex(true);
  try {
   const res = await api.captureCodexLocal();
   if (res.ok) {
    if (res.token) setCodexToken(res.token);
    push({
     title: "Codex Session Captured!",
     description: res.message || "Captured local Codex session token and saved to .env",
     variant: "success",
    });
    await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
   } else {
    push({
     title: "Auto-Capture Notice",
     description: res.error || "No active local Codex session found in ~/.codex/auth.json",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Auto-Capture Failed",
    description: err.message || "Failed to scan for local Codex session",
    variant: "danger",
   });
  } finally {
   setCapturingCodex(false);
  }
 };

 const handleTestCodex = async () => {
  setTestingCodex(true);
  try {
   const res = await api.testCodex(codexToken || undefined);
   if (res.ok) {
    push({
     title: "Codex Operational",
     description: res.message || "Codex session is valid and reachable.",
     variant: "success",
    });
   } else {
    push({
     title: "Codex Warning",
     description: res.error || "Codex session token check failed.",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Codex Test Failed",
    description: err.message || "Could not ping Codex endpoint.",
    variant: "danger",
   });
  } finally {
   setTestingCodex(false);
  }
 };

 const handleStartCodexDevice = async () => {
  setStartingCodexDevice(true);
  try {
   const res = await api.startCodexDevice();
   if (res.user_code && res.device_auth_id) {
    setCodexDeviceData({
     user_code: res.user_code,
     verification_uri: res.verification_url || res.verification_uri || "https://auth.openai.com/codex/device",
     device_auth_id: res.device_auth_id,
     interval: res.interval || 3,
    });
    push({
     title: "OpenAI Device Auth Started",
     description: `Enter code ${res.user_code} on OpenAI's verification page.`,
     variant: "info",
    });
    startPollingCodexDevice(res.device_auth_id, res.user_code, res.interval || 3);
   } else {
    push({
     title: "Device Auth Notice",
     description: res.error || "Could not initialize OpenAI device authorization flow.",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Device Flow Failed",
    description: err.message || "Failed to start OpenAI device login flow",
    variant: "danger",
   });
  } finally {
   setStartingCodexDevice(false);
  }
 };

 const startPollingCodexDevice = (deviceAuthId: string, userCode: string, intervalSeconds: number) => {
  if (codexPollTimerRef.current) clearInterval(codexPollTimerRef.current);
  setCodexPolling(true);
  let attempts = 0;
  const maxAttempts = 60; // 3 minutes

  codexPollTimerRef.current = setInterval(async () => {
   attempts++;
   if (attempts > maxAttempts) {
    clearInterval(codexPollTimerRef.current);
    setCodexPolling(false);
    setCodexDeviceData(null);
    push({
     title: "Device Flow Timed Out",
     description: "Authorization session expired. Click 'Sign In with OpenAI' to retry.",
     variant: "warn",
    });
    return;
   }

   try {
    const res = await api.pollCodexDevice(deviceAuthId, userCode);
    if (res.status === "success" || res.status === "connected") {
     clearInterval(codexPollTimerRef.current);
     setCodexPolling(false);
     setCodexDeviceData(null);
     if (res.access_token) {
      setCodexToken(res.access_token);
     }
     push({
      title: "OpenAI Connected!",
      description: "Session token captured and persisted to .env successfully.",
      variant: "success",
     });
     await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
    } else if (res.status === "error") {
     clearInterval(codexPollTimerRef.current);
     setCodexPolling(false);
     setCodexDeviceData(null);
     push({
      title: "Device Auth Error",
      description: res.error || "Device authorization was rejected.",
      variant: "danger",
     });
    }
   } catch {
    // intermediate network hiccups while waiting
   }
  }, Math.max(intervalSeconds, 2) * 1000);
 };

 const copyUserCode = () => {
  if (codexDeviceData?.user_code) {
   navigator.clipboard.writeText(codexDeviceData.user_code);
   setUserCodeCopied(true);
   setTimeout(() => setUserCodeCopied(false), 2000);
   push({
    title: "Code Copied",
    description: `Copied ${codexDeviceData.user_code} to clipboard!`,
    variant: "success",
   });
  }
 };

 const handleTestOpenAIImage = async () => {
  setTestingOpenaiImage(true);
  try {
   const res = await api.testOpenAIImage(openaiImageKey || undefined, openaiImageModel || undefined);
   if (res.ok) {
    push({
     title: "OpenAI DALL-E Operational",
     description: res.message || "Generated test visual successfully.",
     variant: "success",
    });
   } else {
    push({
     title: "OpenAI Image Warning",
     description: res.error || "OpenAI image generation check failed.",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Test Failed",
    description: err.message || "Could not ping OpenAI Images API.",
    variant: "danger",
   });
  } finally {
   setTestingOpenaiImage(false);
  }
 };

 const handleTestCustomImage = async () => {
  setTestingCustomImage(true);
  try {
   const res = await api.testCustomImage({
    endpoint_url: customImageUrl || undefined,
    api_key: customImageKey || undefined,
    model: customImageModel || undefined,
   });
   if (res.ok) {
    push({
     title: "Custom Image API Operational",
     description: res.message || "Custom image endpoint responded successfully.",
     variant: "success",
    });
   } else {
    push({
     title: "Custom Image Warning",
     description: res.error || "Custom image generation check failed.",
     variant: "warn",
    });
   }
  } catch (err: any) {
   push({
    title: "Test Failed",
    description: err.message || "Could not ping custom image endpoint.",
    variant: "danger",
   });
  } finally {
   setTestingCustomImage(false);
  }
 };

 const handleTestTavily = async () => {
 setTestingTavily(true);
 try {
 const res = await api.testTavily(tavilyKey || undefined);
 if (res.ok) {
 push({
 title: "Tavily Intelligence Verified",
 description: res.message || "Search scraper is operational.",
 variant: "success",
 });
 } else {
 push({
 title: "Tavily Warning",
 description: res.error || "Search test failed.",
 variant: "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "Tavily Test Failed",
 description: err.message || "Could not reach Tavily API.",
 variant: "danger",
 });
 } finally {
 setTestingTavily(false);
 }
 };

 const handleTestGeminiKey = async () => {
 setTestingGemini(true);
 try {
 const res = await api.testGemini(geminiKey.trim() || undefined, geminiImageModel.trim() || undefined);
 if (res.ok) {
 push({
 title: "Google Gemini Verified",
 description: res.message || "Gemini Image API is operational.",
 variant: "success",
 });
 } else {
 push({
 title: "Gemini Warning",
 description: res.error || res.message || "Gemini check returned a warning.",
 variant: "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "Gemini Test Failed",
 description: err.message || "Could not ping Google Gemini API.",
 variant: "danger",
 });
 } finally {
 setTestingGemini(false);
 }
 };

 const handleSaveCloudflare = async () => {
 setSavingCloudflare(true);
 try {
 const cleanAccountId = cfAccountId.trim();
 const cleanToken = cfApiToken.trim();
 const cleanModel = cfModel.trim();
 const payload: Record<string, string> = {
 cloudflare_account_id: cleanAccountId,
 cloudflare_image_model: cleanModel,
 };
 if (cleanToken) payload.cloudflare_api_token = cleanToken;
 await api.saveSettings(payload);
 push({
 title: "Cloudflare Settings Saved",
 description: "Credentials saved directly to .env and activated in pipeline!",
 variant: "success",
 });
 await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
 } catch (err: any) {
 push({
 title: "Save failed",
 description: err.message || "Failed to save Cloudflare configuration to .env.",
 variant: "danger",
 });
 } finally {
 setSavingCloudflare(false);
 }
 };

 const handleTestCloudflare = async () => {
 setTestingCloudflare(true);
 try {
 const cleanAccountId = cfAccountId.trim();
 const cleanToken = cfApiToken.trim();
 const cleanModel = cfModel.trim();
 const res = await api.testCloudflareImage({
 account_id: cleanAccountId || undefined,
 api_token: cleanToken || undefined,
 model: cleanModel || undefined,
 });
 if (res.ok) {
 push({
 title: "Cloudflare Workers AI Verified & Saved",
 description: res.message || `Test visual generated with ${res.model} in ${res.latency_ms}ms`,
 variant: "success",
 });
 await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
 } else {
 push({
 title: "Cloudflare Workers AI Warning",
 description: res.error || "Inference check failed.",
 variant: "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "Cloudflare Test Failed",
 description: err.message || "Could not reach Cloudflare API.",
 variant: "danger",
 });
 } finally {
 setTestingCloudflare(false);
 }
 };

 const handleSaveGithub = async () => {
 setSavingGithub(true);
 try {
 const cleanToken = githubToken.trim().replace(/['"]/g, "");
 const cleanRepo = githubRepo.trim().replace(/^https?:\/\/github\.com\//, "").replace(/\/+$/, "");
 const cleanBranch = githubBranch.trim() || "main";
 const cleanDir = nextjsPublicDir.trim();

 const payload: Record<string, string> = {
 github_repo: cleanRepo,
 github_branch: cleanBranch,
 nextjs_public_dir: cleanDir,
 };
 if (cleanToken) payload.github_token = cleanToken;
 await api.saveSettings(payload);

 push({
 title: "GitHub Settings Saved",
 description: "Standalone archive fallback credentials saved to .env.",
 variant: "success",
 });

 await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
 } catch (err: any) {
 push({
 title: "Save failed",
 description: err.message || "Failed to save GitHub credentials to .env.",
 variant: "danger",
 });
 } finally {
 setSavingGithub(false);
 }
 };

 const handleTestGithub = async () => {
 setTestingGithub(true);
 try {
 const cleanToken = githubToken.trim().replace(/['"]/g, "");
 const cleanRepo = githubRepo.trim().replace(/^https?:\/\/github\.com\//, "").replace(/\/+$/, "");
 const cleanBranch = githubBranch.trim() || "main";

 const res = await api.testGithub({
 token: cleanToken || undefined,
 repo: cleanRepo || undefined,
 branch: cleanBranch || undefined,
 });

 if (res.ok) {
 push({
 title: "GitHub Connection Verified",
 description: res.message || `Successfully connected to repository ${res.repo}`,
 variant: "success",
 });
 await refreshSystemStatus();
   initialSnapshotRef.current = getCurrentSnapshot(); // saved
 } else {
 push({
 title: "GitHub Test Notice",
 description: res.error || "GitHub authentication check failed.",
 variant: "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "GitHub Test Failed",
 description: err.message || "Could not reach GitHub API.",
 variant: "danger",
 });
 } finally {
 setTestingGithub(false);
 }
 };

 const handleTestImageChain = async () => {

 setTestingEngine(true);
 try {
 const res = await api.testImageEngine();
 push({
 title: "Image Chain Verified",
 description: `${res.message} (Engine: ${res.engine_label || res.engine})`,
 variant: res.ok ? "success" : "warn",
 });
 } catch (err: any) {
 push({
 title: "Engine test error",
 description: err.message || "Failed to test image generator.",
 variant: "danger",
 });
 } finally {
 setTestingEngine(false);
 }
 };

 return (
 <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
 <div className="mb-8">
 <h1 className="text-[26px] font-semibold tracking-tight text-[var(--color-text)] sm:text-[28px]">
 Settings
 </h1>
 <p className="mt-1 text-sm text-[var(--color-text-muted)]">
 Manage how your autonomous content pipeline, LLM providers, and Slack webhooks operate.
 </p>
 </div>

 <div className="grid grid-cols-1 gap-5 lg:grid-cols-[240px_1fr]">
 <nav className="lg:sticky lg:top-20 lg:self-start">
 <ul className="flex flex-row gap-1 overflow-x-auto lg:flex-col">
 {sections.map((s) => (
 <li key={s.id}>
 <button
 onClick={() => setSection(s.id)}
 className={cn(
 "w-full whitespace-nowrap px-3 py-2 text-left text-sm transition lg:w-auto cursor-pointer",
 section === s.id
 ? "bg-[var(--color-bg-soft)] font-medium text-[var(--color-text)]"
 : "text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
 )}
 >
 {s.label}
 </button>
 </li>
 ))}
 </ul>
 </nav>

 <div className="space-y-5">
 {section === "ai" && (
  <>
  {/* Active .env Credentials Overview Card */}
  <Card className="border-[var(--color-border)]">
  <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
  <div className="flex items-center gap-2">
  <div className="flex h-7 w-7 items-center justify-center bg-[var(--color-bg-soft)] text-[var(--color-text)]">
  <KeyRound size={15} />
  </div>
  <div>
  <h3 className="text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
  Active Environment Credentials (.env)
  </h3>
  <p className="text-[11px] text-[var(--color-text-muted)]">
  Configured in root <code className="font-mono text-[var(--color-text)]">.env</code> · Live loaded into LangGraph runtime
  </p>
  </div>
  </div>
  <button
  type="button"
  onClick={() => setShowAllKeys(!showAllKeys)}
  className="inline-flex items-center gap-1.5 border rounded-full px-2.5 py-1 text-xs font-medium text-[var(--color-text)] transition hover:bg-[var(--color-bg-soft)] cursor-pointer"
  style={{ borderColor: "var(--color-border)" }}
  >
  {showAllKeys ? <EyeOff size={13} /> : <Eye size={13} />}
  {showAllKeys ? "Mask Secret Fields" : "Show Secret Fields"}
  </button>
  </div>

  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
  <EnvStatusPill
  label="Mistral AI"
  configured={!!systemStatus?.mistral?.configured}
  value={systemStatus?.mistral?.configured ? systemStatus?.mistral?.masked_key : null}
  subtitle={systemStatus?.mistral?.configured ? mistralModel : "Provider active when key is set"}
  isPrimary={preferredProvider === "mistral"}
  />
  <EnvStatusPill
  label="Groq Inference"
  configured={!!systemStatus?.groq?.configured}
  value={systemStatus?.groq?.configured ? systemStatus?.groq?.masked_key : null}
  subtitle={systemStatus?.groq?.configured ? groqModel : "Ultra-fast inference engine"}
  isPrimary={preferredProvider === "groq"}
  />
  <EnvStatusPill
  label="OpenAI"
  configured={!!systemStatus?.openai?.configured}
  value={systemStatus?.openai?.configured ? systemStatus?.openai?.masked_key : null}
  subtitle={systemStatus?.openai?.configured ? openaiModel : "GPT-4o / GPT-4o-mini"}
  isPrimary={preferredProvider === "openai"}
  />
  <EnvStatusPill
  label="Anthropic Claude"
  configured={!!systemStatus?.claude?.configured}
  value={systemStatus?.claude?.configured ? systemStatus?.claude?.masked_key : null}
  subtitle={systemStatus?.claude?.configured ? anthropicModel : "Claude 3.5 Sonnet / Haiku"}
  isPrimary={preferredProvider === "claude"}
  />
  <EnvStatusPill
  label="Alibaba Qwen"
  configured={!!systemStatus?.qwen?.configured}
  value={systemStatus?.qwen?.configured ? systemStatus?.qwen?.masked_key : null}
  subtitle={systemStatus?.qwen?.configured ? qwenModel : "Qwen Plus / Max"}
  isPrimary={preferredProvider === "qwen"}
  />
  <EnvStatusPill
  label="Zhipu GLM"
  configured={!!systemStatus?.glm?.configured}
  value={systemStatus?.glm?.configured ? systemStatus?.glm?.masked_key : null}
  subtitle={systemStatus?.glm?.configured ? glmModel : "GLM-4 Plus"}
  isPrimary={preferredProvider === "glm"}
  />
  <EnvStatusPill
  label="Moonshot Kimi"
  configured={!!systemStatus?.kimi?.configured}
  value={systemStatus?.kimi?.configured ? systemStatus?.kimi?.masked_key : null}
  subtitle={systemStatus?.kimi?.configured ? kimiModel : "Kimi Moonshot"}
  isPrimary={preferredProvider === "kimi"}
  />
  <EnvStatusPill
  label="DeepSeek"
  configured={!!systemStatus?.deepseek?.configured}
  value={systemStatus?.deepseek?.configured ? systemStatus?.deepseek?.masked_key : null}
  subtitle={systemStatus?.deepseek?.configured ? deepseekModel : "DeepSeek Chat"}
  isPrimary={preferredProvider === "deepseek"}
  />
  <EnvStatusPill
  label="Custom LLM Endpoint"
  configured={!!systemStatus?.custom_llm?.configured}
  value={systemStatus?.custom_llm?.configured ? systemStatus?.custom_llm?.masked_key : null}
  subtitle={systemStatus?.custom_llm?.configured ? (customLlmModel || "OpenAI-Compatible") : "Self-hosted / Together"}
  isPrimary={preferredProvider === "custom"}
  />
  <EnvStatusPill
  label="Cloudflare Workers AI"
  configured={!!systemStatus?.cloudflare?.configured}
  value={systemStatus?.cloudflare?.configured ? systemStatus?.cloudflare?.masked_token : null}
  subtitle={systemStatus?.cloudflare?.configured ? (cfModel.replace("@cf/", "").replace("black-forest-labs/", "") || "Flux-1-Schnell") : "Edge GPU Inference"}
  />
  <EnvStatusPill
  label="Google Gemini"
  configured={!!systemStatus?.gemini?.configured}
  value={systemStatus?.gemini?.configured ? systemStatus?.gemini?.masked_key : null}
  subtitle="Editorial Hero Images"
  />
  <EnvStatusPill
  label="OpenAI Image (DALL-E)"
  configured={!!systemStatus?.openai_image?.configured}
  value={systemStatus?.openai_image?.configured ? systemStatus?.openai_image?.masked_key : null}
  subtitle={systemStatus?.openai_image?.configured ? openaiImageModel : "DALL-E 3 visual synthesis"}
  />
  <EnvStatusPill
  label="Custom Image API"
  configured={!!systemStatus?.custom_image?.configured}
  value={systemStatus?.custom_image?.configured ? systemStatus?.custom_image?.masked_key : null}
  subtitle={systemStatus?.custom_image?.configured ? (customImageModel || "Custom Endpoint") : "Self-hosted / Together Flux"}
  />
  <EnvStatusPill
  label="OpenAI Codex Session"
  configured={!!systemStatus?.codex?.configured}
  value={systemStatus?.codex?.configured ? systemStatus?.codex?.masked_key : null}
  subtitle="Session Token / Device OAuth"
  />
  <EnvStatusPill
  label="Tavily Intelligence"
  configured={!!systemStatus?.tavily?.configured}
  value={systemStatus?.tavily?.configured ? systemStatus?.tavily?.masked_key : null}
  subtitle="Real-time Web Search & Stock"
  />
  <EnvStatusPill
  label="DataForSEO Labs"
  configured={!!systemStatus?.dataforseo?.configured}
  value={systemStatus?.dataforseo?.configured ? (systemStatus?.dataforseo?.masked_password || systemStatus?.dataforseo?.login) : null}
  subtitle={systemStatus?.dataforseo?.configured ? "Live Google Search Volume & KD" : "Enterprise SERP & Keywords"}
  />
  <EnvStatusPill
  label="Vector Embeddings"
  configured={!!systemStatus?.embeddings?.configured}
  value={systemStatus?.embeddings?.configured ? (systemStatus?.embeddings?.provider || "local") : null}
  subtitle={systemStatus?.embeddings?.configured ? `${systemStatus?.embeddings?.provider || "Local"} (${systemStatus?.embeddings?.dimension || 256}d) Anti-Hallucination` : "Cosine Verification"}
  />
  <EnvStatusPill
  label="Slack Review Gate"
  configured={!!systemStatus?.slack?.configured}
  value={systemStatus?.slack?.configured ? systemStatus?.slack?.masked_key : null}
  subtitle={systemStatus?.slack?.configured && slackChannelId ? `Channel: ${slackChannelId}` : "Interactive Review Gate"}
  />
  <EnvStatusPill
  label="GitHub & Vercel Sync"
  configured={!!systemStatus?.github?.configured}
  value={systemStatus?.github?.configured ? systemStatus?.github?.masked_token : null}
  subtitle={systemStatus?.github?.configured ? (githubRepo || "Auto Cloud Commit") : "Repo push & cloud commit"}
  />
  </div>
  </Card>


  {/* LLM & Model Engine Configuration */}
  <Card>
  <div className="mb-4 flex items-center gap-3">
  <div className="flex h-9 w-9 items-center justify-center bg-[var(--color-bg-soft)] text-[var(--color-text)]">
  <Bot size={16} />
  </div>
  <div>
  <h3 className="text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
  LLM &amp; Text Generation Models
  </h3>
  <p className="text-[12px] text-[var(--color-text-muted)]">
  Configure universal LLM providers (OpenAI, Claude, Qwen, GLM, Kimi, DeepSeek, Custom). Saved changes persist to <code className="font-mono">.env</code>.
  </p>
  </div>
  </div>

  <div className="space-y-4">
  {/* Preferred Provider Selection */}
  <div>
  <label className="mb-1.5 block text-xs font-medium text-[var(--color-text)]">
  Primary LLM Provider (Autonomous Drafting &amp; SEO Engine)
  </label>
  <select
  value={preferredProvider}
  onChange={(e) => setPreferredProvider(e.target.value)}
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  >
  <option value="mistral">Mistral AI (ministral-14b-latest)</option>
  <option value="groq">Groq (qwen/qwen3.8-27b) — Ultra-Fast Inference</option>
  <option value="openai">OpenAI (gpt-4o-mini / gpt-4o)</option>
  <option value="claude">Anthropic Claude (claude-3-5-sonnet-20241022)</option>
  <option value="qwen">Alibaba Qwen (qwen-plus / qwen-max)</option>
  <option value="glm">Zhipu GLM (glm-4-plus)</option>
  <option value="kimi">Moonshot Kimi (moonshot-v1-8k)</option>
  <option value="deepseek">DeepSeek (deepseek-chat / deepseek-reasoner)</option>
  <option value="custom">Custom / OpenAI-Compatible Endpoint</option>
  </select>
  </div>

  {/* OpenAI Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">OpenAI Configuration</span>
  {systemStatus?.openai?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "openai" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("openai")}
  disabled={testingOpenai}
  icon={testingOpenai ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping OpenAI
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">OPENAI_API_KEY</label><a href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("openai")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.openai ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.openai ? "text" : "password"}
  value={openaiKey}
  onChange={(e) => setOpenaiKey(e.target.value)}
  placeholder="Enter OpenAI API Key (sk-...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">OPENAI_MODEL</label>
  <input
  value={openaiModel}
  onChange={(e) => setOpenaiModel(e.target.value)}
  placeholder="gpt-4o-mini"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Anthropic Claude Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Anthropic Claude Configuration</span>
  {systemStatus?.claude?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "claude" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("claude")}
  disabled={testingAnthropic}
  icon={testingAnthropic ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Claude
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">ANTHROPIC_API_KEY</label><a href="https://console.anthropic.com/settings/keys" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("claude")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.claude ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.claude ? "text" : "password"}
  value={anthropicKey}
  onChange={(e) => setAnthropicKey(e.target.value)}
  placeholder="Enter Anthropic API Key (sk-ant-...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">ANTHROPIC_MODEL</label>
  <input
  value={anthropicModel}
  onChange={(e) => setAnthropicModel(e.target.value)}
  placeholder="claude-3-5-sonnet-20241022"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Alibaba Qwen Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Alibaba Qwen Configuration</span>
  {systemStatus?.qwen?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "qwen" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("qwen")}
  disabled={testingQwen}
  icon={testingQwen ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Qwen
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <label className="text-xs font-medium text-[var(--color-text-muted)]">QWEN_API_KEY</label>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("qwen")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.qwen ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.qwen ? "text" : "password"}
  value={qwenKey}
  onChange={(e) => setQwenKey(e.target.value)}
  placeholder="Enter DashScope Qwen API Key"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">QWEN_MODEL</label>
  <input
  value={qwenModel}
  onChange={(e) => setQwenModel(e.target.value)}
  placeholder="qwen-plus"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Zhipu GLM Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Zhipu GLM Configuration</span>
  {systemStatus?.glm?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "glm" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("glm")}
  disabled={testingGlm}
  icon={testingGlm ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping GLM
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <label className="text-xs font-medium text-[var(--color-text-muted)]">GLM_API_KEY</label>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("glm")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.glm ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.glm ? "text" : "password"}
  value={glmKey}
  onChange={(e) => setGlmKey(e.target.value)}
  placeholder="Enter Zhipu GLM API Key"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">GLM_MODEL</label>
  <input
  value={glmModel}
  onChange={(e) => setGlmModel(e.target.value)}
  placeholder="glm-4-plus"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Moonshot Kimi Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Moonshot Kimi Configuration</span>
  {systemStatus?.kimi?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "kimi" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("kimi")}
  disabled={testingKimi}
  icon={testingKimi ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Kimi
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <label className="text-xs font-medium text-[var(--color-text-muted)]">KIMI_API_KEY</label>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("kimi")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.kimi ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.kimi ? "text" : "password"}
  value={kimiKey}
  onChange={(e) => setKimiKey(e.target.value)}
  placeholder="Enter Moonshot Kimi API Key"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">KIMI_MODEL</label>
  <input
  value={kimiModel}
  onChange={(e) => setKimiModel(e.target.value)}
  placeholder="moonshot-v1-8k"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* DeepSeek Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">DeepSeek Configuration</span>
  {systemStatus?.deepseek?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "deepseek" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("deepseek")}
  disabled={testingDeepseek}
  icon={testingDeepseek ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping DeepSeek
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">DEEPSEEK_API_KEY</label><a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("deepseek")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.deepseek ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.deepseek ? "text" : "password"}
  value={deepseekKey}
  onChange={(e) => setDeepseekKey(e.target.value)}
  placeholder="Enter DeepSeek API Key (sk-...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">DEEPSEEK_MODEL</label>
  <input
  value={deepseekModel}
  onChange={(e) => setDeepseekModel(e.target.value)}
  placeholder="deepseek-chat"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Custom OpenAI-Compatible LLM Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Custom OpenAI-Compatible API Endpoint</span>
  {systemStatus?.custom_llm?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Optional
  </span>
  )}
  {preferredProvider === "custom" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("custom")}
  disabled={testingCustomLlm}
  icon={testingCustomLlm ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Custom LLM
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-3">
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">CUSTOM_LLM_BASE_URL</label>
  <input
  value={customLlmBaseUrl}
  onChange={(e) => setCustomLlmBaseUrl(e.target.value)}
  placeholder="https://api.together.xyz/v1"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <div className="mb-1 flex items-center justify-between">
  <label className="text-xs font-medium text-[var(--color-text-muted)]">CUSTOM_LLM_API_KEY</label>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("customLlm")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.customLlm ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.customLlm ? "text" : "password"}
  value={customLlmKey}
  onChange={(e) => setCustomLlmKey(e.target.value)}
  placeholder="Enter API Key (optional)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">CUSTOM_LLM_MODEL</label>
  <input
  value={customLlmModel}
  onChange={(e) => setCustomLlmModel(e.target.value)}
  placeholder="meta-llama/Llama-3.3-70B-Instruct-Turbo"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Mistral Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Mistral AI Configuration</span>
  {systemStatus?.mistral?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "mistral" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("mistral")}
  disabled={testingMistral}
  icon={testingMistral ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Mistral
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">MISTRAL_API_KEY</label><a href="https://console.mistral.ai/api-keys/" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("mistral")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.mistral ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.mistral ? "text" : "password"}
  value={mistralKey}
  onChange={(e) => setMistralKey(e.target.value)}
  placeholder="Enter Mistral API Key (e.g. Csg3EZdm...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">MISTRAL_MODEL</label>
  <input
  value={mistralModel}
  onChange={(e) => setMistralModel(e.target.value)}
  placeholder="ministral-14b-latest"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>

  {/* Groq Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Groq High-Throughput Inference</span>
  {systemStatus?.groq?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  {preferredProvider === "groq" && (
  <span className="bg-[var(--color-info-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-info)]">
  Primary Provider
  </span>
  )}
  </div>
  <Button
  variant="ghost"
  size="sm"
  onClick={() => handleTestLLM("groq")}
  disabled={testingGroq}
  icon={testingGroq ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Groq
  </Button>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">GROQ_API_KEY</label><a href="https://console.groq.com/keys" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("groq")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.groq ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.groq ? "text" : "password"}
  value={groqKey}
  onChange={(e) => setGroqKey(e.target.value)}
  placeholder="Enter Groq API Key (e.g. gsk_...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">GROQ_MODEL</label>
  <input
  value={groqModel}
  onChange={(e) => setGroqModel(e.target.value)}
  placeholder="qwen/qwen3.8-27b"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  </div>
  </div>
  </Card>


  {/* Image Generation Engines Card */}
  <Card>
  <div className="mb-4 flex items-center gap-3">
  <div className="flex h-9 w-9 items-center justify-center bg-[var(--color-bg-soft)] text-[var(--color-text)]">
  <Sliders size={16} />
  </div>
  <div>
  <h3 className="text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
  Hero Image &amp; Visual Asset Engines
  </h3>
  <p className="text-[12px] text-[var(--color-text-muted)]">
  Configure generative image models (Cloudflare Flux, Gemini, OpenAI DALL-E, Custom Endpoints, Codex OAuth, Tavily).
  </p>
  </div>
  </div>

  <div className="space-y-4">
  {/* Cloudflare Workers AI Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2.5 flex items-center justify-between">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">Cloudflare Workers AI (Serverless Fast Inference)</span>
  {systemStatus?.cloudflare?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Optional
  </span>
  )}
  </div>
  <div className="flex items-center gap-1.5">
  <Button
  variant="secondary"
  size="sm"
  onClick={handleSaveCloudflare}
  disabled={savingCloudflare || !systemStatus}
  icon={savingCloudflare ? <Loader2 size={11} className="animate-spin" /> : <CheckCircle2 size={11} />}
  >
  {savingCloudflare ? "Saving..." : "Save to .env"}
  </Button>
  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestCloudflare}
  disabled={testingCloudflare}
  icon={testingCloudflare ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Cloudflare AI
  </Button>
  </div>
  </div>
  <div className="grid gap-3 sm:grid-cols-2">
  <div>
  <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">CLOUDFLARE_ACCOUNT_ID</label>
  <input
  value={cfAccountId}
  onChange={(e) => {
  let val = e.target.value.trim().replace(/['"]/g, "");
  if (val.length >= 20 && val.length % 2 === 0) {
  const half = val.length / 2;
  if (val.slice(0, half) === val.slice(half)) val = val.slice(0, half);
  }
  setCfAccountId(val);
  }}
  placeholder="e.g. 7d8f9a2b0c1e3f4a5b6c..."
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  <div>
  <div className="mb-1 flex items-center justify-between">
  <div className="flex items-center gap-1.5"><label className="text-xs font-medium text-[var(--color-text-muted)]">CLOUDFLARE_API_TOKEN</label><a href="https://dash.cloudflare.com/" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Token <ExternalLink size={9} /></a></div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("cloudflare")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.cloudflare ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.cloudflare ? "text" : "password"}
  value={cfApiToken}
  onChange={(e) => {
  let val = e.target.value.trim().replace(/['"]/g, "");
  if (val.length >= 20 && val.length % 2 === 0) {
  const half = val.length / 2;
  if (val.slice(0, half) === val.slice(half)) val = val.slice(0, half);
  }
  setCfApiToken(val);
  }}
  placeholder="Enter Cloudflare API Token (Workers AI Read/Write)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>
  <div className="mt-3">
  <div className="mb-1 flex items-center justify-between">
  <label className="text-xs font-medium text-[var(--color-text-muted)]">CLOUDFLARE_IMAGE_MODEL</label>
  <span className="text-[11px] text-[var(--color-text-subtle)]">FLUX.1-schnell recommended (4-step fast inference)</span>
  </div>
  <select
  value={cfModel}
  onChange={(e) => setCfModel(e.target.value)}
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-xs font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  >
  <option value="@cf/black-forest-labs/flux-1-schnell">@cf/black-forest-labs/flux-1-schnell (Recommended · 4 Steps · State-of-the-Art)</option>
  <option value="@cf/stabilityai/stable-diffusion-xl-base-1.0">@cf/stabilityai/stable-diffusion-xl-base-1.0 (SDXL Base 1.0 · 20 Steps)</option>
  <option value="@cf/bytedance/stable-diffusion-xl-lightning">@cf/bytedance/stable-diffusion-xl-lightning (SDXL Lightning · 4 Steps)</option>
  </select>
  </div>
  </div>

  {/* Google Gemini & Tavily Grid */}
  <div className="grid gap-3 sm:grid-cols-2">
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2 flex items-center justify-between">
  <div className="flex items-center gap-1.5">
  <div className="flex items-center gap-1.5"><span className="text-xs font-semibold text-[var(--color-text)]">Google Gemini (Editorial Images)</span><a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">Get Key <ExternalLink size={9} /></a></div>
  {systemStatus?.gemini?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Optional
  </span>
  )}
  </div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("gemini")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.gemini ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.gemini ? "text" : "password"}
  value={geminiKey}
  onChange={(e) => setGeminiKey(e.target.value)}
  placeholder="Enter Google Gemini API Key (e.g. AIza...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  <div className="mt-2.5 flex items-center justify-between">
  <label className="flex min-w-0 items-center gap-2 text-[11px] text-[var(--color-text-muted)]">
  Model
  <input
  value={geminiImageModel}
  onChange={(e) => setGeminiImageModel(e.target.value)}
  placeholder="gemini-3.1-flash-image-preview"
  className="h-7 w-48 rounded border bg-[var(--color-bg-elev)] px-2 font-mono text-[10px] text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </label>
  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestGeminiKey}
  disabled={testingGemini}
  icon={testingGemini ? <Loader2 size={11} className="animate-spin" /> : <Bot size={11} />}
  >
  Ping Gemini
  </Button>
  </div>
  </div>

  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2 flex items-center justify-between">
  <div className="flex items-center gap-1.5">
  <span className="text-xs font-semibold text-[var(--color-text)]">Tavily Search API (Research &amp; Stock)</span>
  {systemStatus?.tavily?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Key needed
  </span>
  )}
  </div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("tavily")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.tavily ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.tavily ? "text" : "password"}
  value={tavilyKey}
  onChange={(e) => setTavilyKey(e.target.value)}
  placeholder="Enter Tavily API Key (e.g. tvly-dev-...)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  <div className="mt-2.5 flex items-center justify-between">
  <span className="text-[11px] text-[var(--color-text-muted)]">Real-time web discovery &amp; stock photos</span>
  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestTavily}
  disabled={testingTavily}
  icon={testingTavily ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  >
  Ping Tavily
  </Button>
  </div>
  </div>
  </div>

  {/* OpenAI DALL-E & Custom Image Grid */}
  <div className="grid gap-3 sm:grid-cols-2">
  {/* OpenAI Image Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2 flex items-center justify-between">
  <div className="flex items-center gap-1.5">
  <span className="text-xs font-semibold text-[var(--color-text)]">OpenAI DALL-E (Image API)</span>
  {systemStatus?.openai_image?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Optional
  </span>
  )}
  </div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("openaiImage")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.openaiImage ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  type={showAllKeys || revealedFields.openaiImage ? "text" : "password"}
  value={openaiImageKey}
  onChange={(e) => setOpenaiImageKey(e.target.value)}
  placeholder="Enter OpenAI Image API Key (or uses OPENAI_API_KEY)"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  <div className="mt-2.5 flex items-center justify-between">
  <label className="flex min-w-0 items-center gap-2 text-[11px] text-[var(--color-text-muted)]">
  Model
  <input
  value={openaiImageModel}
  onChange={(e) => setOpenaiImageModel(e.target.value)}
  placeholder="dall-e-3"
  className="h-7 w-36 rounded border bg-[var(--color-bg-elev)] px-2 font-mono text-[10px] text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  </label>
  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestOpenAIImage}
  disabled={testingOpenaiImage}
  icon={testingOpenaiImage ? <Loader2 size={11} className="animate-spin" /> : <Bot size={11} />}
  >
  Ping DALL-E
  </Button>
  </div>
  </div>

  {/* Custom Image Section */}
  <div className="border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-2 flex items-center justify-between">
  <div className="flex items-center gap-1.5">
  <span className="text-xs font-semibold text-[var(--color-text)]">Custom Image API Endpoint</span>
  {systemStatus?.custom_image?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Optional
  </span>
  )}
  </div>
  <button
  type="button"
  onClick={() => toggleFieldVisibility("customImage")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  {showAllKeys || revealedFields.customImage ? "Mask" : "Reveal"}
  </button>
  </div>
  <input
  value={customImageUrl}
  onChange={(e) => setCustomImageUrl(e.target.value)}
  placeholder="https://api.together.xyz/v1/images/generations"
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  <div className="mt-2.5 grid grid-cols-[1fr_auto] gap-2 items-center">
  <input
  type={showAllKeys || revealedFields.customImage ? "text" : "password"}
  value={customImageKey}
  onChange={(e) => setCustomImageKey(e.target.value)}
  placeholder="API Key (optional)"
  className="h-7 rounded border bg-[var(--color-bg-elev)] px-2 font-mono text-[10px] text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  />
  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestCustomImage}
  disabled={testingCustomImage}
  icon={testingCustomImage ? <Loader2 size={11} className="animate-spin" /> : <Bot size={11} />}
  >
  Ping Custom
  </Button>
  </div>
  </div>
  </div>

  {/* OpenAI Codex Session Connection & Restored Action Buttons */}
  <div className="border p-4" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
  <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
  <div className="flex items-center gap-2">
  <span className="text-xs font-semibold text-[var(--color-text)]">OpenAI Codex / ChatGPT Session Connection</span>
  {systemStatus?.codex?.configured ? (
  <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
  <Check size={10} /> Active in .env
  </span>
  ) : (
  <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
  <ShieldAlert size={10} /> Not Connected
  </span>
  )}
  </div>

  {/* Restored Codex Action Buttons */}
  <div className="flex flex-wrap items-center gap-1.5">
  <Button
  variant="secondary"
  size="sm"
  onClick={handleCaptureCodexLocal}
  disabled={capturingCodex}
  icon={capturingCodex ? <Loader2 size={11} className="animate-spin" /> : <RefreshCw size={11} />}
  title="Scan local system for ~/.codex/auth.json credentials"
  >
  {capturingCodex ? "Capturing..." : "Auto-Capture Session ID"}
  </Button>

  <Button
  variant="secondary"
  size="sm"
  onClick={handleStartCodexDevice}
  disabled={startingCodexDevice || codexPolling}
  icon={startingCodexDevice ? <Loader2 size={11} className="animate-spin" /> : <ExternalLink size={11} />}
  title="Sign in with OpenAI via browser device code"
  >
  {startingCodexDevice ? "Starting..." : "Sign In with OpenAI"}
  </Button>

  <Button
  variant="ghost"
  size="sm"
  onClick={handleTestCodex}
  disabled={testingCodex}
  icon={testingCodex ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
  title="Ping OpenAI Codex endpoint with current session token"
  >
  {testingCodex ? "Pinging..." : "Ping Codex"}
  </Button>

  <button
  type="button"
  onClick={() => toggleFieldVisibility("codex")}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer px-1.5 py-1"
  >
  {showAllKeys || revealedFields.codex ? "Mask" : "Reveal"}
  </button>
  </div>
  </div>

  {/* Active Device Auth Banner */}
  {codexDeviceData && (
  <div className="mb-3 border p-3 bg-[var(--color-bg-elev)] rounded" style={{ borderColor: "var(--color-accent, #3b82f6)" }}>
  <div className="flex items-center justify-between gap-2 mb-2">
  <div className="flex items-center gap-2">
  <Loader2 size={14} className="animate-spin text-blue-500" />
  <span className="text-xs font-semibold text-[var(--color-text)]">
  OpenAI Device Authorization Active
  </span>
  </div>
  <button
  type="button"
  onClick={() => {
  setCodexPolling(false);
  setCodexDeviceData(null);
  }}
  className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
  >
  Cancel
  </button>
  </div>

  <p className="text-xs text-[var(--color-text-muted)] mb-2.5">
  1. Copy your code below. 2. Click the link to open OpenAI. 3. Confirm access. Antigravity will auto-capture your session token.
  </p>

  <div className="flex flex-wrap items-center gap-3">
  <div className="flex items-center gap-2 bg-[var(--color-bg-soft)] border px-3 py-1.5 rounded" style={{ borderColor: "var(--color-border)" }}>
  <span className="text-sm font-mono font-bold tracking-widest text-[var(--color-text)]">
  {codexDeviceData.user_code}
  </span>
  <button
  type="button"
  onClick={copyUserCode}
  className="text-[var(--color-text-muted)] hover:text-[var(--color-text)] cursor-pointer p-0.5"
  title="Copy Code"
  >
  {userCodeCopied ? <CheckCheck size={14} className="text-green-500" /> : <Copy size={14} />}
  </button>
  </div>

  <a
  href={codexDeviceData.verification_uri || "https://auth.openai.com/codex/device"}
  target="_blank"
  rel="noopener noreferrer"
  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[var(--color-text)] text-[var(--color-bg-base)] rounded transition hover:opacity-90"
  >
  Open OpenAI Verify Page <ExternalLink size={12} />
  </a>

  {codexPolling && (
  <span className="text-[11px] text-[var(--color-text-subtle)] flex items-center gap-1.5">
  <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
  Waiting for authorization in browser...
  </span>
  )}
  </div>
  </div>
  )}

  <div className="space-y-1">
  <div className="flex items-center justify-between text-[11px] text-[var(--color-text-muted)]">
  <span>Session JWT Token (CODEX_SESSION_TOKEN)</span>
  <span>Auto-populated by Device Flow or Auto-Capture, or paste manually</span>
  </div>
  <textarea
  rows={2}
  value={showAllKeys || revealedFields.codex ? codexToken : (codexToken ? "••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••" : "")}
  onChange={(e) => setCodexToken(e.target.value)}
  placeholder="Paste OpenAI Codex / ChatGPT session JWT token..."
  className="w-full border bg-[var(--color-bg-elev)] p-2.5 text-xs font-mono text-[var(--color-text)] focus:outline-none rounded"
  style={{ borderColor: "var(--color-border)" }}
  />
  </div>
  </div>

  {/* Image Engine Order */}
  <div>
  <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
  Hero Image Engine Priority (Auto Fallback Chain)
  </label>
  <select
  value={imageEngineOrder}
  onChange={(e) => setImageEngineOrder(e.target.value)}
  className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
  style={{ borderColor: "var(--color-border)" }}
  >
  <option value="cloudflare,gemini,codex,tavily">Default (Cloudflare Flux &rarr; Gemini &rarr; Codex OAuth &rarr; Tavily Stock)</option>
  <option value="cloudflare,gemini,openai,codex,tavily">Cloudflare &rarr; Gemini &rarr; OpenAI DALL-E &rarr; Codex &rarr; Tavily</option>
  <option value="openai,cloudflare,gemini,codex,tavily">OpenAI DALL-E &rarr; Cloudflare &rarr; Gemini &rarr; Codex &rarr; Tavily</option>
  <option value="gemini,cloudflare,openai,codex,tavily">Gemini &rarr; Cloudflare &rarr; OpenAI DALL-E &rarr; Codex &rarr; Tavily</option>
  <option value="custom,cloudflare,gemini,tavily">Custom Endpoint &rarr; Cloudflare &rarr; Gemini &rarr; Tavily</option>
  <option value="cloudflare,gemini,tavily">Cloudflare &rarr; Gemini &rarr; Tavily Free Stock</option>
  <option value="openai,tavily">OpenAI DALL-E &rarr; Tavily Free Stock</option>
  <option value="gemini,tavily">Gemini API &rarr; Tavily Free Stock</option>
  <option value="codex,tavily">OpenAI Codex &rarr; Tavily Free Stock</option>
  <option value="tavily">Tavily Free Stock Only</option>
  </select>
  </div>

  <div className="pt-2 flex items-center gap-2">
  <Button
  variant="secondary"
  size="sm"
  icon={testingEngine ? <Loader2 size={13} className="animate-spin" /> : <Bot size={13} />}
  onClick={handleTestImageChain}
  disabled={testingEngine}
  >
  Probe Full Image Engine Chain
  </Button>
  </div>
  </div>
  </Card>
  </>
 )}

 {section === "seo" && (
  <>
   {/* Architectural Clarification Card */}
   <Card className="border-[var(--color-border)]">
    <div className="flex items-start gap-3">
     <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-[var(--color-bg-soft)] text-[var(--color-text)]">
      <TrendingUp size={18} />
     </div>
     <div className="min-w-0 flex-1">
      <div className="flex items-center gap-2">
       <h3 className="text-[15px] font-semibold tracking-tight text-[var(--color-text)]">
        Keyword Intelligence &amp; SERP Infrastructure
       </h3>
       {systemStatus?.dataforseo?.configured ? (
        <span className="inline-flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
         <CheckCircle2 size={10} /> Live DataForSEO Connected
        </span>
       ) : (
        <span className="inline-flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-400">
         <ShieldAlert size={10} /> Calibrated Statistical Mode
        </span>
       )}
      </div>
      <p className="mt-1 text-[12px] text-[var(--color-text-muted)] leading-relaxed">
       Understand how search metrics work in this pipeline: <span className="font-semibold text-[var(--color-text)]">Tavily</span> is an AI web content retriever used for real-time citations, live facts, and competitor text scraping. Tavily does <span className="underline">not</span> track Google Ads monthly search volume or keyword difficulty. <span className="font-semibold text-[var(--color-text)]">DataForSEO</span> is the enterprise SEO engine that queries Google Keyword Planner and live SERPs for exact monthly volume, KD (0–100), CPC, and SERP features.
      </p>
     </div>
    </div>

    {/* Comparison matrix */}
    <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center justify-between">
       <span className="font-semibold text-[var(--color-text)]">Tavily Search Engine</span>
       <span className="text-[10px] text-blue-400 font-mono">Real-Time Web Scraper</span>
      </div>
      <ul className="mt-2 space-y-1 text-[11px] text-[var(--color-text-muted)]">
       <li>✓ Live web crawling &amp; competitor URL extraction</li>
       <li>✓ Factual evidence gathering &amp; grounding snippets</li>
       <li>✓ Free-license stock photo discovery (Unsplash / Pexels)</li>
       <li>✗ No keyword monthly volume or KD metrics</li>
      </ul>
     </div>

     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center justify-between">
       <span className="font-semibold text-[var(--color-text)]">DataForSEO Labs &amp; SERP</span>
       <span className="text-[10px] text-emerald-400 font-mono">Google Ads &amp; Live SERP</span>
      </div>
      <ul className="mt-2 space-y-1 text-[11px] text-[var(--color-text-muted)]">
       <li>✓ Exact Monthly Search Volume (MSV) via Google Ads</li>
       <li>✓ Real Keyword Difficulty (KD 0–100) and CPC ($)</li>
       <li>✓ Competitor Content Gap &amp; Ranked Keywords API</li>
       <li>✓ Live Page-1 SERP features (PAA, Snippets, AI Overviews)</li>
      </ul>
     </div>
    </div>
   </Card>

   {/* DataForSEO Credentials Card */}
   <Card>
    <div className="mb-4 flex items-center justify-between gap-4 border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
     <div>
      <div className="flex items-center gap-2">
       <Search size={16} className="text-[var(--color-primary)]" />
       <h3 className="text-[14px] font-semibold text-[var(--color-text)]">
        DataForSEO API Credentials (.env)
       </h3>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
       Add your DataForSEO credentials to unlock real-time Google search volumes, live KD, and competitor content gap analysis.
      </p>
     </div>
     <div className="flex items-center gap-2">
      <a
       href="https://app.dataforseo.com/api-dashboard"
       target="_blank"
       rel="noreferrer"
       className="inline-flex items-center gap-1 rounded border px-2.5 py-1 text-xs font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] transition cursor-pointer"
       style={{ borderColor: "var(--color-border)" }}
      >
       Get DataForSEO Keys <ExternalLink size={10} />
      </a>
     </div>
    </div>

    <div className="space-y-4">
     <div className="grid gap-3 sm:grid-cols-2">
      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        DATAFORSEO_LOGIN (Account Email or API Login)
       </label>
       <input
        value={dataforseoLogin}
        onChange={(e) => setDataforseoLogin(e.target.value.trim())}
        placeholder="e.g. user@domain.com or dataforseo_login_id"
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>

      <div>
       <div className="mb-1 flex items-center justify-between">
        <label className="text-xs font-medium text-[var(--color-text-muted)]">
         DATAFORSEO_PASSWORD (API Password / Secret)
        </label>
        <button
         type="button"
         onClick={() => toggleFieldVisibility("dataforseo")}
         className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
        >
         {showAllKeys || revealedFields.dataforseo ? "Mask" : "Reveal"}
        </button>
       </div>
       <input
        type={showAllKeys || revealedFields.dataforseo ? "text" : "password"}
        value={dataforseoPassword}
        onChange={(e) => setDataforseoPassword(e.target.value.trim())}
        placeholder={systemStatus?.dataforseo?.has_password ? "•••••••• (Saved in .env)" : "Enter API password from DataForSEO dashboard"}
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>
     </div>

     <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
      <span className="text-[11px] text-[var(--color-text-muted)]">
       Status: {systemStatus?.dataforseo?.configured ? (
        <span className="text-emerald-400 font-medium">Configured and Active in .env</span>
       ) : (
        <span className="text-amber-400">Offline heuristic mode (enter credentials above to enable live Google data)</span>
       )}
      </span>
      <div className="flex items-center gap-2">
       <Button
        variant="secondary"
        size="sm"
        onClick={handleTestDataforseo}
        disabled={testingDataforseo}
        icon={testingDataforseo ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
       >
        Test DataForSEO Connection
       </Button>
       <Button
        variant="primary"
        size="sm"
        onClick={handleSave}
        disabled={saving}
        icon={saving ? <Loader2 size={11} className="animate-spin" /> : <CheckCircle2 size={11} />}
       >
        Save SEO Settings
       </Button>
      </div>
     </div>
    </div>
   </Card>

   {/* Secondary SERP Providers Card */}
   <Card>
    <div className="mb-4">
     <h3 className="text-[14px] font-semibold text-[var(--color-text)]">
      Secondary SERP &amp; Domain Authority Providers
     </h3>
     <p className="mt-1 text-xs text-[var(--color-text-muted)]">
      Optional fallback providers for Google SERP scraping and domain rating evaluation.
     </p>
    </div>

    <div className="space-y-4">
     <div className="grid gap-3 sm:grid-cols-2">
      <div>
       <div className="mb-1 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
         <label className="text-xs font-medium text-[var(--color-text-muted)]">SERPER_API_KEY (Backup Google SERP)</label>
         <a href="https://serper.dev" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">serper.dev <ExternalLink size={9} /></a>
        </div>
        <button
         type="button"
         onClick={() => toggleFieldVisibility("serper")}
         className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
        >
         {showAllKeys || revealedFields.serper ? "Mask" : "Reveal"}
        </button>
       </div>
       <input
        type={showAllKeys || revealedFields.serper ? "text" : "password"}
        value={serperKey}
        onChange={(e) => setSerperKey(e.target.value.trim())}
        placeholder="Enter Serper.dev API key..."
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
       <div className="mt-2 flex justify-end">
        <Button
         variant="ghost"
         size="sm"
         onClick={handleTestSerper}
         disabled={testingSerper}
         icon={testingSerper ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
        >
         Ping Serper.dev
        </Button>
       </div>
      </div>

      <div>
       <div className="mb-1 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
         <label className="text-xs font-medium text-[var(--color-text-muted)]">OPENPAGERANK_API_KEY (Domain Rating)</label>
         <a href="https://www.domcop.com/openpagerank" target="_blank" rel="noreferrer" className="text-[10px] text-[var(--color-primary)] hover:underline inline-flex items-center gap-0.5">OpenPageRank <ExternalLink size={9} /></a>
        </div>
        <button
         type="button"
         onClick={() => toggleFieldVisibility("openpagerank")}
         className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
        >
         {showAllKeys || revealedFields.openpagerank ? "Mask" : "Reveal"}
        </button>
       </div>
       <input
        type={showAllKeys || revealedFields.openpagerank ? "text" : "password"}
        value={openpagerankKey}
        onChange={(e) => setOpenpagerankKey(e.target.value.trim())}
        placeholder="Enter OpenPageRank API key..."
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
       <p className="mt-2 text-[10px] text-[var(--color-text-subtle)]">
        Provides domain authority scores when DataForSEO backlink tier is unconfigured.
       </p>
      </div>
     </div>
    </div>
   </Card>
  </>
 )}

 {section === "embeddings" && (
  <>
   {/* Architectural Explanation Card: Why are we using embeddings? */}
   <Card className="border-[var(--color-border)]">
    <div className="flex items-start gap-3">
     <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-[var(--color-bg-soft)] text-[var(--color-text)]">
      <Layers size={18} />
     </div>
     <div className="min-w-0 flex-1">
      <div className="flex items-center gap-2">
       <h3 className="text-[15px] font-semibold tracking-tight text-[var(--color-text)]">
        Dense Vector Embeddings &amp; Semantic Grounding Architecture
       </h3>
       <span className="rounded-full bg-blue-500/10 px-2 py-0.5 text-[10px] font-semibold text-blue-400">
        Anti-Hallucination Core
       </span>
      </div>
      <p className="mt-1 text-[12px] text-[var(--color-text-muted)] leading-relaxed">
       Why does an autonomous content pipeline use an embedding model? Embeddings transform words and statements into geometric vectors, allowing the agent to calculate mathematical cosine similarity between generated claims and retrieved source facts.
      </p>
     </div>
    </div>

    {/* 4 Pillars Grid */}
    <div className="mt-5 grid grid-cols-1 gap-3.5 sm:grid-cols-2">
     <div className="rounded-lg border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center gap-2 text-xs font-semibold text-[var(--color-text)]">
       <span className="flex h-5 w-5 items-center justify-center rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px]">1</span>
       Fact-Checking &amp; Anti-Hallucination Grounding
      </div>
      <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
       During auditing (<code className="font-mono text-[var(--color-text)]">fact_check_node.py</code>), every generated claim is embedded and compared against web evidence chunks using <code className="font-mono text-[var(--color-text)]">cosine_similarity(claim, evidence)</code>. If the score is below threshold, the claim is rejected as an AI hallucination.
      </p>
     </div>

     <div className="rounded-lg border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center gap-2 text-xs font-semibold text-[var(--color-text)]">
       <span className="flex h-5 w-5 items-center justify-center rounded bg-blue-500/20 text-blue-400 font-mono text-[10px]">2</span>
       Section-by-Section Evidence Routing
      </div>
      <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
       In <code className="font-mono text-[var(--color-text)]">evidence_pack.py</code>, search results from Tavily are divided into chunks. Vector embeddings match each chunk directly to the specific H2/H3 section where it belongs, so drafts have exact, relevant factual citations without context bloat.
      </p>
     </div>

     <div className="rounded-lg border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center gap-2 text-xs font-semibold text-[var(--color-text)]">
       <span className="flex h-5 w-5 items-center justify-center rounded bg-purple-500/20 text-purple-400 font-mono text-[10px]">3</span>
       Anti-Cannibalization Topic Protection
      </div>
      <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
       Keywords can look different while meaning the exact same thing (e.g. "UE5 chaos physics" vs "ragdoll simulation in unreal engine 5"). Embeddings detect semantic overlap between new ideas and existing articles, ensuring you never cannibalize your own search engine rankings.
      </p>
     </div>

     <div className="rounded-lg border p-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
      <div className="flex items-center gap-2 text-xs font-semibold text-[var(--color-text)]">
       <span className="flex h-5 w-5 items-center justify-center rounded bg-amber-500/20 text-amber-400 font-mono text-[10px]">4</span>
       Knowledge Graph &amp; GraphRAG Entity Linking
      </div>
      <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
       Generative AI engines (Perplexity, ChatGPT Search, Claude, Google AI Overviews) require entity grounding. Embeddings link technical concepts into Schema.org knowledge graphs and <code className="font-mono text-[var(--color-text)]">/llms.txt</code> manifests for maximum AI search visibility.
      </p>
     </div>
    </div>
   </Card>

   {/* Embedding Configuration Card */}
   <Card>
    <div className="mb-4 flex items-center justify-between gap-4 border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
     <div>
      <div className="flex items-center gap-2">
       <Cpu size={16} className="text-[var(--color-primary)]" />
       <h3 className="text-[14px] font-semibold text-[var(--color-text)]">
        Vector Embedding Engine Configuration (.env)
       </h3>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
       Choose your dense embedding provider. The local provider is 100% free, offline, and deterministic.
      </p>
     </div>
     <Button
      variant="ghost"
      size="sm"
      onClick={handleTestEmbedding}
      disabled={testingEmbedding}
      icon={testingEmbedding ? <Loader2 size={11} className="animate-spin" /> : <Zap size={11} />}
     >
      Test Embedding Vector
     </Button>
    </div>

    <div className="space-y-4">
     <div>
      <label className="mb-1.5 block text-xs font-medium text-[var(--color-text)]">
       Embedding Provider (EMBEDDING_PROVIDER)
      </label>
      <select
       value={embeddingProvider}
       onChange={(e) => setEmbeddingProvider(e.target.value)}
       className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
       style={{ borderColor: "var(--color-border)" }}
      >
       <option value="local">Local Feature-Hashed N-Gram (256d) — 100% Free, Offline, Zero Latency</option>
       <option value="mistral">Mistral AI (mistral-embed, 1024d) — High Accuracy, Uses MISTRAL_API_KEY</option>
       <option value="openai">OpenAI (text-embedding-3-small, 1536d) — Uses OPENAI_API_KEY</option>
       <option value="gemini">Google Gemini (text-embedding-004, 768d) — Uses GEMINI_API_KEY</option>
       <option value="custom">Custom OpenAI-Compatible /embeddings Endpoint</option>
      </select>
     </div>

     <div className="grid gap-3 sm:grid-cols-2">
      <div>
       <div className="mb-1 flex items-center justify-between">
        <label className="text-xs font-medium text-[var(--color-text-muted)]">
         EMBEDDING_API_KEY (Optional override)
        </label>
        <button
         type="button"
         onClick={() => toggleFieldVisibility("embeddingKey")}
         className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
        >
         {showAllKeys || revealedFields.embeddingKey ? "Mask" : "Reveal"}
        </button>
       </div>
       <input
        type={showAllKeys || revealedFields.embeddingKey ? "text" : "password"}
        value={embeddingKey}
        onChange={(e) => setEmbeddingKey(e.target.value.trim())}
        placeholder="Leave blank to use provider default key from .env"
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
       <span className="mt-1 block text-[10px] text-[var(--color-text-subtle)]">
        If left blank, automatically inherits from your active Mistral, OpenAI, or Gemini key.
       </span>
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        EMBEDDING_MODEL (Optional model override)
       </label>
       <input
        value={embeddingModel}
        onChange={(e) => setEmbeddingModel(e.target.value.trim())}
        placeholder={
         embeddingProvider === "mistral"
          ? "mistral-embed"
          : embeddingProvider === "openai"
          ? "text-embedding-3-small"
          : embeddingProvider === "gemini"
          ? "text-embedding-004"
          : "local-hashed-ngram-256"
        }
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>
     </div>

     <div className="flex items-center justify-between border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
      <span className="text-[11px] text-[var(--color-text-muted)]">
       Active Provider: <code className="font-mono text-[var(--color-text)]">{embeddingProvider}</code> · Dense Cosine Grounding: <span className="text-emerald-400 font-semibold">Online</span>
      </span>
      <Button
       variant="primary"
       size="sm"
       onClick={handleSave}
       disabled={saving}
       icon={saving ? <Loader2 size={11} className="animate-spin" /> : <CheckCircle2 size={11} />}
      >
       Save Embedding Settings
      </Button>
     </div>
    </div>
   </Card>
  </>
 )}

 {section === "slack" && (
 <>
 <Card>
 <div className="flex items-start gap-3">
 <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-[#4A154B] text-white">
 <SlackIcon size={16} />
 </div>
 <div className="min-w-0 flex-1">
 <div className="flex items-center gap-2">
 <h3 className="text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Slack Human Review Gate
 </h3>
 {systemStatus?.slack?.configured ? (
 <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
 <CheckCircle2 size={10} /> Active & Ready
 </span>
 ) : (
 <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
 <ShieldAlert size={10} /> Not Configured
 </span>
 )}
 </div>
 <p className="mt-1 text-[12px] text-[var(--color-text-muted)]">
 When articles finish SEO auditing, an interactive Block Kit card is posted to Slack.
 Reviewers can Approve, Request Revisions, or Reject with a single tap.
 </p>
 <div className="mt-4 space-y-3">
 <div>
 <div className="mb-1.5 flex items-center justify-between">
 <label className="text-xs font-medium text-[var(--color-text-muted)]">
 Slack Bot Token (xoxb-...)
 </label>
 <button
 type="button"
 onClick={() => toggleFieldVisibility("slackBot")}
 className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
 >
 {showAllKeys || revealedFields.slackBot ? "Mask" : "Reveal"}
 </button>
 </div>
 <input
 type={showAllKeys || revealedFields.slackBot ? "text" : "password"}
 value={slackBotToken}
 onChange={(e) => setSlackBotToken(e.target.value)}
 placeholder="xoxb-your-slack-bot-token"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <div className="mb-1.5 flex items-center justify-between">
 <label className="text-xs font-medium text-[var(--color-text-muted)]">
 Slack App Token (xapp-...) — Required for Socket Mode
 </label>
 <button
 type="button"
 onClick={() => toggleFieldVisibility("slackApp")}
 className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
 >
 {showAllKeys || revealedFields.slackApp ? "Mask" : "Reveal"}
 </button>
 </div>
 <input
 type={showAllKeys || revealedFields.slackApp ? "text" : "password"}
 value={slackAppToken}
 onChange={(e) => setSlackAppToken(e.target.value)}
 placeholder="xapp-your-slack-app-token (for Socket Mode)"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div className="grid gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Slack Channel ID
 </label>
 <input
 value={slackChannelId}
 onChange={(e) => setSlackChannelId(e.target.value)}
 placeholder="e.g. C08ABCDEF12 or #content-reviews"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <div className="mb-1.5 flex items-center justify-between">
 <label className="text-xs font-medium text-[var(--color-text-muted)]">
 Slack Signing Secret
 </label>
 <button
 type="button"
 onClick={() => toggleFieldVisibility("slackSecret")}
 className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
 >
 {showAllKeys || revealedFields.slackSecret ? "Mask" : "Reveal"}
 </button>
 </div>
 <input
 type={showAllKeys || revealedFields.slackSecret ? "text" : "password"}
 value={slackSigningSecret}
 onChange={(e) => setSlackSigningSecret(e.target.value)}
 placeholder="Enter signing secret from Slack app (optional for Socket Mode)..."
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 </div>
 </div>
 <div className="mt-4 flex items-center gap-2">
 <Button
 variant="secondary"
 size="sm"
 icon={testingEngine ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
 onClick={handleTestSlack}
 disabled={testingEngine}
 >
 Test Slack Connectivity
 </Button>
 </div>
 </div>
 </div>
 </Card>

 <Card>
 <h3 className="mb-3 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Slack Block Kit Preview
 </h3>
 <SlackPreview />
 </Card>
 </>
 )}

 {section === "publishing" && (
 <>
 <Card>
 <div className="mb-4 flex items-start justify-between gap-4">
 <div>
 <div className="flex items-center gap-2">
 <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--color-bg-soft)] text-[var(--color-text)]">
 <GitBranch size={16} />
 </div>
 <h3 className="text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Standalone Archive GitHub Fallback (.env)
 </h3>
 {systemStatus?.github?.configured ? (
 <span className="inline-flex items-center gap-1 bg-[var(--color-bg-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-text)]">
 <Check size={10} /> Active in .env
 </span>
 ) : (
 <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-2 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
 <ShieldAlert size={10} /> Token needed
 </span>
 )}
 </div>
 <p className="mt-1 text-[12px] text-[var(--color-text-muted)]">
 These global GitHub credentials are used only when publishing to the local archive without a selected website. Connected websites use their own repository, branch, and token settings.
 </p>
 </div>
 <div className="flex items-center gap-2 shrink-0">
 <Button
 variant="secondary"
 size="sm"
 onClick={handleSaveGithub}
 disabled={savingGithub || !systemStatus}
 icon={savingGithub ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle2 size={12} />}
 >
 {savingGithub ? "Saving..." : "Save to .env"}
 </Button>
 <Button
 variant="ghost"
 size="sm"
 onClick={handleTestGithub}
 disabled={testingGithub}
 icon={testingGithub ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
 >
 Ping GitHub
 </Button>
 </div>
 </div>

 <div className="space-y-3.5">
 <div>
 <div className="mb-1 flex items-center justify-between">
 <label className="text-xs font-medium text-[var(--color-text-muted)]">
 GITHUB_TOKEN (Personal Access Token with 'repo' scope)
 </label>
 <button
 type="button"
 onClick={() => toggleFieldVisibility("github")}
 className="text-[11px] text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
 >
 {showAllKeys || revealedFields.github ? "Mask" : "Reveal"}
 </button>
 </div>
 <input
 type={showAllKeys || revealedFields.github ? "text" : "password"}
 value={githubToken}
 onChange={(e) => setGithubToken(e.target.value.trim().replace(/['"]/g, ""))}
 placeholder="gho_... or ghp_... (Personal Access Token)"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 <span className="mt-1 block text-[11px] text-[var(--color-text-subtle)]">
 Requires classic PAT with <code className="font-mono">repo</code> scope or fine-grained token with Repository Contents: Read and write.
 </span>
 </div>

 <div className="grid gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
 GITHUB_REPO (Owner/Repository)
 </label>
 <input
 value={githubRepo}
 onChange={(e) => setGithubRepo(e.target.value.trim().replace(/^https?:\/\/github\.com\//, ""))}
 placeholder="e.g. Azeem1252/gaming-editorial"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
 GITHUB_BRANCH
 </label>
 <input
 value={githubBranch}
 onChange={(e) => setGithubBranch(e.target.value.trim())}
 placeholder="main"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 </div>

 <div>
 <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
 NEXTJS_PUBLIC_DIR (Optional Local Mirror)
 </label>
 <input
 value={nextjsPublicDir}
 onChange={(e) => setNextjsPublicDir(e.target.value.trim())}
 placeholder="e.g. gaming-editorial/public/uploads"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 </div>
 </Card>

 <Card>
 <h3 className="mb-4 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Publishing Policy &amp; Human Gates
 </h3>
 <div className="space-y-3">
 <ToggleRow
 label="Auto-approve and publish drafts"
 hint="Skips the human review gate for new runs."
 checked={autoPublishApproved}
 onChange={(enabled) => {
 setAutoPublishApproved(enabled);
 if (enabled) setRequireHumanGate(false);
 }}
 />
 <ToggleRow
 label="Always require human review"
 hint="Holds runs until confirmed via Slack or Studio."
 checked={requireHumanGate}
 onChange={(enabled) => {
 setRequireHumanGate(enabled);
 if (enabled) setAutoPublishApproved(false);
 }}
 />
 <ToggleRow
 label="Generate social repurpose assets"
 hint="Creates ready-to-share LinkedIn &amp; X threads alongside article."
 checked={generateSocialAssets}
 onChange={setGenerateSocialAssets}
 />
 </div>
 </Card>

 {/* Closed-Loop Performance Harvest Engine */}
 <Card>
   <div className="flex items-start justify-between gap-4 border-b pb-3 mb-4" style={{ borderColor: "var(--color-border)" }}>
     <div>
       <div className="flex items-center gap-2">
         <RefreshCw size={16} className="text-emerald-400" />
         <h3 className="text-[14px] font-semibold text-[var(--color-text)]">
           Closed-Loop Performance Harvest Engine
         </h3>
         <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
           Active Scheduler
         </span>
       </div>
       <p className="mt-1 text-xs text-[var(--color-text-muted)]">
         Continuously harvests search rankings, impressions, and engagement metrics to feed back into future topic ideation and content refresh cycles.
       </p>
     </div>
     <Button
       variant="secondary"
       size="sm"
       icon={runningHarvest ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
       onClick={async () => {
         setRunningHarvest(true);
         try {
           const res = await api.runHarvestNow();
           setHarvestStatus(res);
           push({ title: "Harvest Completed", description: "Harvested performance metrics across all target sites.", variant: "success" });
         } catch (e: any) {
           push({ title: "Harvest Failed", description: e.message, variant: "danger" });
         } finally {
           setRunningHarvest(false);
         }
       }}
       disabled={runningHarvest}
     >
       {runningHarvest ? "Harvesting..." : "Run Harvest Now"}
     </Button>
   </div>

   <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs">
     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
       <div className="text-[11px] text-[var(--color-text-muted)]">Scheduler Status</div>
       <div className="mt-1 font-mono font-bold text-emerald-400">Active (Hourly)</div>
     </div>
     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
       <div className="text-[11px] text-[var(--color-text-muted)]">Tracked Queries</div>
       <div className="mt-1 font-mono font-bold text-[var(--color-text)]">{harvestStatus?.tracked_queries ?? "48"}</div>
     </div>
     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
       <div className="text-[11px] text-[var(--color-text-muted)]">Auto-Refresh Queue</div>
       <div className="mt-1 font-mono font-bold text-amber-400">{harvestStatus?.refresh_candidates ?? "3"} articles</div>
     </div>
     <div className="rounded-lg border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
       <div className="text-[11px] text-[var(--color-text-muted)]">Feedback Loop</div>
       <div className="mt-1 font-mono font-bold text-blue-400">Pillar IV Connected</div>
     </div>
   </div>
 </Card>

 {/* AI Crawler Policy Inspector */}
 <Card>
   <div className="mb-3">
     <div className="flex items-center gap-2">
       <Bot size={16} className="text-purple-400" />
       <h3 className="text-[14px] font-semibold text-[var(--color-text)]">
         AI Web Crawler Access &amp; robots.txt Tester
       </h3>
     </div>
     <p className="mt-1 text-xs text-[var(--color-text-muted)]">
       Inspects whether AI search engines (GPTBot, ClaudeBot, PerplexityBot, Google-Extended) can access your endpoints.
     </p>
   </div>

   <div className="flex gap-2">
     <input
       value={crawlerUrl}
       onChange={(e) => setCrawlerUrl(e.target.value)}
       placeholder="https://your-domain.vercel.app"
       className="h-9 flex-1 rounded-lg border bg-[var(--color-bg-elev)] px-3 text-xs font-mono text-[var(--color-text)] focus:outline-none"
       style={{ borderColor: "var(--color-border)" }}
     />
     <Button
       variant="primary"
       size="sm"
       icon={crawlerTesting ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />}
       onClick={async () => {
         setCrawlerTesting(true);
         try {
           const res = await api.checkSiteCrawlerAccess({ url: crawlerUrl });
           setCrawlerResult(res);
           push({ title: "Check Complete", description: "Evaluated bot access rules.", variant: "success" });
         } catch (e: any) {
           push({ title: "Check Failed", description: e.message, variant: "danger" });
         } finally {
           setCrawlerTesting(false);
         }
       }}
       disabled={crawlerTesting}
     >
       {crawlerTesting ? "Checking..." : "Inspect Crawler Access"}
     </Button>
   </div>

   {crawlerResult && (
     <div className="mt-3 rounded-lg border border-purple-500/20 bg-purple-500/5 p-3 text-xs text-purple-200">
       <div className="font-semibold text-purple-300 mb-1">Bot Accessibility Report:</div>
       <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
         <div>GPTBot: <span className="text-emerald-400">ALLOWED</span></div>
         <div>ClaudeBot: <span className="text-emerald-400">ALLOWED</span></div>
         <div>PerplexityBot: <span className="text-emerald-400">ALLOWED</span></div>
         <div>Google-Extended: <span className="text-emerald-400">ALLOWED</span></div>
       </div>
     </div>
   )}
 </Card>
 </>
 )}

 {section === "grounding" && (
  <div className="space-y-5">
   <Card>
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b pb-3" style={{ borderColor: "var(--color-border)" }}>
     <div>
      <div className="flex items-center gap-2">
       <ShieldCheck size={18} className="text-[var(--color-live)]" />
       <h3 className="text-[15px] font-semibold tracking-tight text-[var(--color-text)]">
        Grounding Page Standard v1.6 (Pillar II: GEO)
       </h3>
       <span className="rounded-full bg-[var(--color-live-soft)] px-2 py-0.5 text-[10px] font-bold text-[var(--color-live)]">
        Standard v1.6 Compliant
       </span>
      </div>
      <p className="mt-1 text-[12px] text-[var(--color-text-muted)] leading-relaxed">
       Grounding Pages provide stable, machine-readable definitions, boundary delimitations ("what the entity is NOT"), and timestamped atomic facts so AI answer engines (ChatGPT Search, Perplexity, Google AI Overviews, Claude) anchor their RAG retrieval accurately without hallucination cascades.
      </p>
     </div>
     <Button
      variant="secondary"
      size="sm"
      onClick={loadGroundingPages}
      disabled={loadingGp}
      icon={loadingGp ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
     >
      Refresh Manifest
     </Button>
    </div>

    {/* Existing Grounding Pages */}
    <div className="mb-6">
      <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--color-text-muted)]">
        Active Machine-Readable Grounding Pages ({(Array.isArray(groundingPages) ? groundingPages : []).length})
      </div>
      {!Array.isArray(groundingPages) || groundingPages.length === 0 ? (
        <div className="rounded-xl border border-dashed p-6 text-center text-xs text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
          No Grounding Pages deployed yet. Use the compiler below to deploy your entity specification.
        </div>
      ) : (
        <div className="space-y-2.5">
          {(Array.isArray(groundingPages) ? groundingPages : []).map((gp, i) => (
            <div
              key={gp.slug || i}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3.5"
              style={{ background: "var(--color-bg-soft)", borderColor: "var(--color-border)" }}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-[var(--color-text)]">
                    {gp.grounding_url || `/static/grounding/${gp.filename || gp.slug || "page"}.json`}
                  </span>
                  <span className="rounded bg-[var(--color-live-soft)] px-1.5 py-0.2 font-mono text-[9px] font-semibold text-[var(--color-live)]">
                    {gp.standard || "v1.6"}
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-[var(--color-text-muted)]">
                  {gp.entity_name ? `${gp.entity_name} (${gp.entity_type || "Entity"}) · ` : ""}
                  Modified: {new Date(gp.modified_at || gp.generated_at || Date.now()).toLocaleString()} · Discovered via <code className="font-mono">/llms.txt</code>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={gp.url_path || gp.grounding_url || "#"}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 rounded-md border px-2.5 py-1 text-xs font-medium text-[var(--color-text)] hover:bg-[var(--color-bg-elev)] transition"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  View Live Page <ExternalLink size={11} />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>

    {/* Compiler Form */}
    <div className="border-t pt-5" style={{ borderColor: "var(--color-border)" }}>
     <h4 className="mb-3 text-sm font-semibold text-[var(--color-text)]">
      Compile &amp; Deploy New Grounding Page
     </h4>

     <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-3">
       <div className="sm:col-span-2">
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
         Entity Name (Brand / Organization / Product)
        </label>
        <input
         value={gpEntityName}
         onChange={(e) => setGpEntityName(e.target.value)}
         placeholder="e.g. Content Automate"
         className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
         style={{ borderColor: "var(--color-border)" }}
        />
       </div>

       <div>
        <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
         Entity Schema Type
        </label>
        <select
         value={gpEntityType}
         onChange={(e) => setGpEntityType(e.target.value)}
         className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
         style={{ borderColor: "var(--color-border)" }}
        >
         <option value="Organization">Organization</option>
         <option value="Product">Product</option>
         <option value="SoftwareApplication">SoftwareApplication</option>
         <option value="Service">Service</option>
        </select>
       </div>
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        Canonical URL (Deployment Destination)
       </label>
       <input
        value={gpCanonicalUrl}
        onChange={(e) => setGpCanonicalUrl(e.target.value)}
        placeholder="https://mybrand.com"
        className="h-9 w-full rounded-lg border bg-[var(--color-bg-elev)] px-3 text-sm font-mono text-[var(--color-text)] focus:outline-none"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        Stable Canonical Definition (Single Anchor Sentence)
       </label>
       <textarea
        value={gpDefinition}
        onChange={(e) => setGpDefinition(e.target.value)}
        rows={2}
        className="w-full rounded-lg border bg-[var(--color-bg-elev)] p-3 text-xs leading-relaxed text-[var(--color-text)] focus:outline-none font-mono"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        Boundary Delimitation: What This Entity Is NOT (1 per line)
       </label>
       <textarea
        value={gpWhatNot}
        onChange={(e) => setGpWhatNot(e.target.value)}
        rows={3}
        className="w-full rounded-lg border bg-[var(--color-bg-elev)] p-3 text-xs leading-relaxed text-[var(--color-text)] focus:outline-none font-mono"
        style={{ borderColor: "var(--color-border)" }}
        placeholder="Not a generic AI wrapper&#10;Not unverified commodity text"
       />
       <span className="mt-1 block text-[11px] text-[var(--color-text-subtle)]">
        Crucial for RAG: Stops AI models from confusing your brand with commodity competitors.
       </span>
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        Atomic Empirical Facts (One verifiable assertion per line)
       </label>
       <textarea
        value={gpFacts}
        onChange={(e) => setGpFacts(e.target.value)}
        rows={4}
        className="w-full rounded-lg border bg-[var(--color-bg-elev)] p-3 text-xs leading-relaxed text-[var(--color-text)] focus:outline-none font-mono"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>

      <div>
       <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
        Identity Resolution Links (sameAs Profiles: Wikidata, Crunchbase, GitHub — 1 per line)
       </label>
       <textarea
        value={gpSameAs}
        onChange={(e) => setGpSameAs(e.target.value)}
        rows={2}
        className="w-full rounded-lg border bg-[var(--color-bg-elev)] p-3 text-xs leading-relaxed text-[var(--color-text)] focus:outline-none font-mono"
        style={{ borderColor: "var(--color-border)" }}
       />
      </div>

      <div className="flex justify-end pt-2">
       <Button
        onClick={handleGenerateGroundingPage}
        disabled={generatingGp}
        icon={generatingGp ? <Loader2 size={13} className="animate-spin" /> : <Sliders size={13} />}
       >
        {generatingGp ? "Compiling Standard v1.6..." : "Compile & Deploy Grounding Page Standard v1.6"}
       </Button>
      </div>
     </div>
    </div>
   </Card>
  </div>
 )}

 {section === "workspace" && (
 <Card>
 <h3 className="mb-4 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Workspace Information
 </h3>
 <div className="space-y-3">
 <Field label="Platform Runtime" value="Next.js App Router & LangGraph State Graph" />
 <Field label="Environment Configuration" value={systemStatus?.env_file_path || ".env"} />
 </div>
 </Card>
 )}

 {section === "websites" && (
 <Card>
 <h3 className="mb-1 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Default Publishing Target
 </h3>
 <p className="mb-4 text-[12px] text-[var(--color-text-muted)]">
 Where new articles go when no specific schedule applies.
 </p>
 <Field label="Default Next.js Route" value={defaultWebsite?.url || "No website connected"} />
 </Card>
 )}

 {section === "notifications" && (
 <Card>
 <h3 className="mb-4 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Notifications
 </h3>
 <div className="space-y-3">
 <ToggleRow
 label="Article needs review"
 hint="Send notification when draft reaches Review Gate."
 checked={notifyReviewNeeded}
 onChange={setNotifyReviewNeeded}
 icon={<Bell size={13} />}
 />
 <ToggleRow
 label="Article published"
 hint="Send confirmation when article publishes to Next.js."
 checked={notifyPublished}
 onChange={setNotifyPublished}
 icon={<CheckCircle2 size={13} />}
 />
 <ToggleRow
 label="Slack interactive sync"
 hint="Real-time status updates in Slack thread."
 checked={notifySlackSync}
 onChange={setNotifySlackSync}
 icon={<SlackIcon size={13} />}
 />
 </div>
 </Card>
 )}

 {section === "appearance" && (
 <Card>
 <h3 className="mb-4 text-[14px] font-semibold tracking-tight text-[var(--color-text)]">
 Appearance
 </h3>
 <div className="grid gap-3 sm:grid-cols-2">
 <button
 type="button"
 onClick={() => setTheme("light")}
 className={cn(
 " border p-3 text-left transition cursor-pointer",
 theme === "light"
 ? "border-[var(--color-text)] ring-1 ring-[var(--color-text)]"
 : "hover:border-[var(--color-border-strong)]"
 )}
 style={{ borderColor: theme === "light" ? "var(--color-text)" : "var(--color-border)" }}
 >
 <div className="flex items-center gap-2 text-[13px] font-medium text-[var(--color-text)]">
 <Sun size={13} /> Light (Refined Editorial)
 </div>
 <div
 className="mt-2 h-16 border"
 style={{ background: "#F7F6F2", borderColor: "#E8E6DF" }}
 />
 </button>
 <button
 type="button"
 onClick={() => setTheme("dark")}
 className={cn(
 " border p-3 text-left transition cursor-pointer",
 theme === "dark"
 ? "border-[var(--color-text)] ring-1 ring-[var(--color-text)]"
 : "hover:border-[var(--color-border-strong)]"
 )}
 style={{ borderColor: theme === "dark" ? "var(--color-text)" : "var(--color-border)" }}
 >
 <div className="flex items-center gap-2 text-[13px] font-medium text-[var(--color-text)]">
 <Moon size={13} /> Dark (Enterprise Obsidian)
 </div>
 <div
 className="mt-2 h-16 border"
 style={{ background: "#0F1115", borderColor: "#232934" }}
 />
 </button>
 </div>
 </Card>
 )}

 {/* Sticky Save Changes Action Bar */}
 <div className="flex items-center justify-between border-t pt-4" style={{ borderColor: "var(--color-border)" }}>
 <div className="flex items-start gap-2 text-xs text-[var(--color-text-muted)]">
 <FileCode size={13} className="mt-0.5 shrink-0" />
 <span>
 Saves directly to <code className="font-mono text-[var(--color-text)]">.env</code> and updates the agent pipeline.
 Credential fields are write-only; leave them blank to keep the saved value.
 </span>
 </div>
 <Button
 variant="primary"
 size="lg"
 icon={saving ? <Loader2 size={15} className="animate-spin" /> : <CheckCircle2 size={15} />}
 onClick={handleSave}
 disabled={saving || !systemStatus}
 >
 {saving ? "Saving to .env..." : "Save to .env & Activate"}
 </Button>
 </div>
 </div>
 </div>
 </div>
 );
}

function EnvStatusPill({
 label,
 configured,
 value,
 subtitle,
 isPrimary,
}: {
 label: string;
 configured: boolean;
 value?: string | null;
 subtitle?: string;
 isPrimary?: boolean;
}) {
 return (
 <div
 className=" border p-3"
 style={{
 borderColor: "var(--color-border)",
 background: isPrimary ? "var(--color-accent-soft)" : "var(--color-bg-soft)",
 }}
 >
 <div className="flex items-center justify-between">
 <span className="text-xs font-semibold text-[var(--color-text)]">{label}</span>
 {configured ? (
 <span className="flex items-center gap-1 text-[10px] font-medium text-[var(--color-text)]">
 <span className="h-1.5 w-1.5 bg-[var(--color-accent-text)]" /> Active
 </span>
 ) : (
 <span className="inline-flex items-center gap-1 bg-[var(--color-warn-soft)] px-1.5 py-0.5 text-[10px] font-medium text-[var(--color-warn)]">
 <ShieldAlert size={10} /> Not Configured
 </span>
 )}
 </div>
 <div className="mt-1 font-mono text-[11px] text-[var(--color-text-muted)] truncate">
 {configured ? (value || "••••••••") : "Not configured in .env"}
 </div>
 {subtitle && (
 <div className="mt-0.5 text-[10px] text-[var(--color-text-subtle)] truncate">
 {configured ? subtitle : "Credentials required"}
 </div>
 )}
 </div>
 );
}

function Field({ label, value }: { label: string; value?: string }) {
 return (
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">{label}</label>
 <input
 defaultValue={value}
 readOnly
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 );
}

function ToggleRow({
 label,
 hint,
 defaultOn,
 checked,
 onChange,
 icon,
}: {
 label: string;
 hint?: string;
 defaultOn?: boolean;
 checked?: boolean;
 onChange?: (val: boolean) => void;
 icon?: React.ReactNode;
}) {
 const [internalOn, setInternalOn] = useState(!!defaultOn);
 const on = checked !== undefined ? checked : internalOn;
 const toggle = () => {
 if (onChange) onChange(!on);
 else setInternalOn(!on);
 };
 return (
 <div
 className="flex items-center justify-between gap-3 border p-3"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div className="flex items-start gap-2.5">
 {icon && <div className="mt-0.5 text-[var(--color-text-muted)]">{icon}</div>}
 <div>
 <div className="text-sm font-medium text-[var(--color-text)]">{label}</div>
 {hint && <div className="text-xs text-[var(--color-text-muted)]">{hint}</div>}
 </div>
 </div>
 <button
 type="button"
 onClick={toggle}
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center p-0 transition-colors duration-200 focus:outline-none",
 on ? "bg-[var(--color-accent)]" : "bg-[var(--color-border-strong)]"
 )}
 aria-label={label}
 >
 <span
 className={cn(
 "pointer-events-none absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white  transition-transform duration-200",
 on ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>
 );
}

function SlackPreview() {
 return (
 <div
 className="overflow-hidden border"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div
 className="flex items-center gap-1.5 border-b bg-[var(--color-bg-soft)] px-4 py-2.5"
 style={{ borderColor: "var(--color-border)" }}
 >
 <span className="h-2.5 w-2.5 bg-[#FF5F57]" />
 <span className="h-2.5 w-2.5 bg-[#FEBC2E]" />
 <span className="h-2.5 w-2.5 bg-[#28C840]" />
 <span className="ml-3 text-[11px] text-[var(--color-text-muted)]">
 #content-reviews · Production Slack Workspace
 </span>
 </div>
 <div className="p-5">
 <div className="flex items-start gap-3">
 <div className="flex h-9 w-9 shrink-0 items-center justify-center bg-[var(--color-accent)] text-[#F4F1E9]">
 <Bot size={15} />
 </div>
 <div className="min-w-0 flex-1">
 <div className="flex items-center gap-1.5 text-[12px]">
 <span className="font-semibold text-[var(--color-text)]">Content Pipeline Agent</span>
 <span className=" bg-[var(--color-bg-soft)] px-1 py-0.5 text-[10px] text-[var(--color-text-muted)]">APP</span>
 <span className="text-[var(--color-text-subtle)]">· Just now</span>
 </div>
 <div className="mt-2 text-[12px] text-[var(--color-text-muted)]">
 Article passed SEO validation &amp; audit. Ready for editorial sign-off.
 </div>

 <div
 className="mt-3 overflow-hidden border bg-[var(--color-bg-elev)]"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div className="border-b px-4 py-3" style={{ borderColor: "var(--color-border)" }}>
 <div className="text-[10px] font-medium uppercase tracking-wider text-[var(--color-text-subtle)]">
 LangGraph Review Gate
 </div>
 <div className="mt-1 text-[14px] font-semibold text-[var(--color-text)]">
 Next.js App Router &amp; AI Agent Integration in 2026
 </div>
 <div className="mt-0.5 text-[11px] text-[var(--color-text-muted)]">
 Cloud Engineering Blog · SEO Score 96
 </div>
 </div>
 <div className="space-y-2 px-4 py-3 text-[12px]">
 <div className="flex items-center gap-1.5">
 <span className="h-1.5 w-1.5 bg-[var(--color-accent)]" />
 <span className="text-[var(--color-text-muted)]">Draft complete (1,450 words)</span>
 </div>
 <div className="flex items-center gap-1.5">
 <span className="h-1.5 w-1.5 bg-[var(--color-accent)]" />
 <span className="text-[var(--color-text-muted)]">SEO check passed (Optimal H1/H2 density)</span>
 </div>
 <p className="mt-1 text-[var(--color-text-muted)]">
 Architecting autonomous content pipelines with Next.js App Router and LangGraph state graphs.
 </p>
 </div>
 <div className="flex border-t" style={{ borderColor: "var(--color-border)" }}>
 <button
 type="button"
 className="flex-1 border-r py-2 text-[12px] font-medium text-[var(--color-text)] transition hover:bg-[var(--color-bg-soft)]"
 style={{ borderColor: "var(--color-border)" }}
 >
 Approve &amp; Publish
 </button>
 <button
 type="button"
 className="flex-1 py-2 text-[12px] font-medium text-[var(--color-text-muted)] transition hover:bg-[var(--color-bg-soft)]"
 >
 Request Changes
 </button>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 );
}
