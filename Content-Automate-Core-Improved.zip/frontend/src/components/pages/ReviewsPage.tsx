import { cleanMarkdown } from "../../utils/cleanMarkdown";
import { useState, useMemo } from "react";
import {
  CheckCircle2,
  Edit3,
  ExternalLink,
  XCircle,
  Loader2,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
  Database,
  GitBranch,
  Search,
  Filter,
  Eye,
  CheckCheck,
  ChevronRight,
  RefreshCw,
  ImageIcon
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { StatusBadge } from "../StatusBadge";
import { WebsiteIcon } from "../WebsiteIcon";
import { Modal } from "../Modal";
import { useToast } from "../../lib/toast";
import { useNav } from "../../lib/nav";
import { usePipelineData } from "../../lib/dataContext";
import type { ContentItem } from "../../types";

export function ReviewsPage() {
  const { push } = useToast();
  const { openInspector } = useNav();
  const { contentItems, websites, getWebsite, reviewArticle } = usePipelineData();

  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [pendingIds, setPendingIds] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedWebsiteId, setSelectedWebsiteId] = useState<string>("all");
  const [filterVerdict, setFilterVerdict] = useState<"all" | "high_confidence" | "flagged">("all");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBatchPublishing, setIsBatchPublishing] = useState(false);

  // Items awaiting human editorial gate
  const pendingItems = useMemo(
    () => contentItems.filter((c) => c.status === "Awaiting Approval"),
    [contentItems]
  );

  // Filtered items
  const filteredItems = useMemo(() => {
    return pendingItems.filter((item) => {
      if (selectedWebsiteId !== "all" && item.websiteId !== selectedWebsiteId) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchKeyword = item.targetKeyword?.toLowerCase().includes(q);
        const matchExcerpt = item.excerpt?.toLowerCase().includes(q);
        if (!matchTitle && !matchKeyword && !matchExcerpt) return false;
      }
      if (filterVerdict === "high_confidence") {
        const score = item.factCheckScore ?? item.seoScore;
        return score >= 85;
      }
      if (filterVerdict === "flagged") {
        const contradictions = item.verificationReport?.contradicted_count || 0;
        const score = item.factCheckScore ?? 100;
        return contradictions > 0 || score < 75;
      }
      return true;
    });
  }, [pendingItems, selectedWebsiteId, searchQuery, filterVerdict]);

  // Aggregate metrics
  const avgFactScore = useMemo(() => {
    if (pendingItems.length === 0) return 0;
    const scores = pendingItems.map((i) => i.factCheckScore ?? 88);
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  }, [pendingItems]);

  const avgSeoScore = useMemo(() => {
    if (pendingItems.length === 0) return 0;
    const scores = pendingItems.map((i) => i.seoScore || 85);
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  }, [pendingItems]);

  const setPending = (id: string, busy: boolean) => {
    setPendingIds((prev) => {
      const next = { ...prev };
      if (busy) next[id] = true;
      else delete next[id];
      return next;
    });
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAll = () => {
    if (selectedIds.size === filteredItems.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredItems.map((i) => i.id)));
    }
  };

  const approve = async (item: ContentItem) => {
    if (pendingIds[item.id]) return;
    setPending(item.id, true);
    try {
      await reviewArticle(item.id, "approve");
      push({
        title: "Article Approved & Published",
        description: `“${cleanMarkdown(item.title)}” successfully dispatched to Next.js webhook.`,
        variant: "success",
      });
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(item.id);
        return next;
      });
    } catch (err: any) {
      push({
        title: "Approval failed",
        description: err.message || "Could not approve article.",
        variant: "danger",
      });
    } finally {
      setPending(item.id, false);
    }
  };

  const batchApproveSelected = async () => {
    const idsToApprove = Array.from(selectedIds);
    if (idsToApprove.length === 0) return;
    setIsBatchPublishing(true);

    const results = await Promise.allSettled(
      idsToApprove.map(async (id) => {
        setPending(id, true);
        try {
          await reviewArticle(id, "approve");
          return true;
        } finally {
          setPending(id, false);
        }
      })
    );

    const successCount = results.filter((r) => r.status === "fulfilled" && r.value).length;
    setIsBatchPublishing(false);
    setSelectedIds(new Set());
    push({
      title: "Batch Publishing Complete",
      description: `Successfully published ${successCount} of ${idsToApprove.length} articles concurrently.`,
      variant: successCount > 0 ? "success" : "warn",
    });
  };

  const approveAllHighConfidence = async () => {
    const verified = pendingItems.filter((i) => (i.factCheckScore ?? i.seoScore) >= 85);
    if (verified.length === 0) {
      push({
        title: "No High-Confidence Articles",
        description: "No pending articles meet the >= 85 score threshold.",
        variant: "warn",
      });
      return;
    }
    if (!confirm(`Batch approve ${verified.length} articles with fact-check score >= 85?`)) return;
    setIsBatchPublishing(true);

    const results = await Promise.allSettled(
      verified.map(async (item) => {
        setPending(item.id, true);
        try {
          await reviewArticle(item.id, "approve");
          return true;
        } finally {
          setPending(item.id, false);
        }
      })
    );

    const count = results.filter((r) => r.status === "fulfilled" && r.value).length;
    setIsBatchPublishing(false);
    push({
      title: "Batch Approval Complete",
      description: `Dispatched ${count} verified articles concurrently to target websites.`,
      variant: "success",
    });
  };

  const handleRequestChanges = async () => {
    if (!selectedItem || pendingIds[selectedItem.id]) return;
    const item = selectedItem;
    const feedbackText = feedback.trim();
    if (!feedbackText) {
      push({
        title: "Feedback required",
        description: "Please specify what you would like the agent to change or add.",
        variant: "warn",
      });
      return;
    }

    setPending(item.id, true);
    setRejectOpen(false);
    setSelectedItem(null);
    setFeedback("");
    openInspector(item.id);
    try {
      await reviewArticle(item.id, "request_changes", feedbackText);
      push({
        title: "Revision request sent",
        description: `“${cleanMarkdown(item.title)}” is being redrafted with your feedback. Watch the live stream in the inspector.`,
        variant: "info",
      });
    } catch (err: any) {
      push({
        title: "Change request failed",
        description: err.message || "Failed to submit change request.",
        variant: "danger",
      });
    } finally {
      setPending(item.id, false);
    }
  };

  const handleReject = async (item: ContentItem) => {
    if (pendingIds[item.id]) return;
    if (!confirm(`Reject and archive run "${cleanMarkdown(item.title)}"?`)) return;
    setPending(item.id, true);
    try {
      await reviewArticle(item.id, "reject");
      push({
        title: "Run rejected",
        description: `“${cleanMarkdown(item.title)}” has been archived.`,
        variant: "warn",
      });
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(item.id);
        return next;
      });
    } catch (err: any) {
      push({
        title: "Error",
        description: err.message || "Failed to reject the run.",
        variant: "danger",
      });
    } finally {
      setPending(item.id, false);
    }
  };

  const applyPresetFeedback = (preset: string) => {
    setFeedback((prev) => (prev ? `${prev}\n${preset}` : preset));
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
      {/* SaaS Page Header */}
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
              Editorial Review Gate
            </h1>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-amber-500">
              <ShieldCheck size={12} />
              Human-in-the-Loop Active
            </span>
          </div>
          <p className="mt-1 text-xs text-[var(--color-text-muted)]">
            Audit empirical fact verification, AEO canonical citations, and structured document models before 0-second Next.js publication.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            icon={<CheckCheck size={14} className="text-emerald-400" />}
            onClick={approveAllHighConfidence}
            disabled={isBatchPublishing || pendingItems.length === 0}
          >
            Approve All Verified (≥85)
          </Button>
        </div>
      </div>

      {/* KPI Telemetry Banner */}
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
          <div className="text-[11px] font-medium uppercase tracking-wider text-[var(--color-text-muted)]">
            Awaiting Review
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-[var(--color-text)]">{pendingItems.length}</span>
            <span className="text-xs text-amber-400 font-medium">Pending Gate</span>
          </div>
        </div>

        <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
          <div className="text-[11px] font-medium uppercase tracking-wider text-[var(--color-text-muted)]">
            Avg Fact-Check Score
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400">{avgFactScore}%</span>
            <span className="text-xs text-[var(--color-text-muted)]">Empirical</span>
          </div>
        </div>

        <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
          <div className="text-[11px] font-medium uppercase tracking-wider text-[var(--color-text-muted)]">
            Avg SEO &amp; AEO Score
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-blue-400">{avgSeoScore}</span>
            <span className="text-xs text-[var(--color-text-muted)]">/ 100</span>
          </div>
        </div>

        <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
          <div className="text-[11px] font-medium uppercase tracking-wider text-[var(--color-text-muted)]">
            Publishing Engine
          </div>
          <div className="mt-1 flex items-baseline gap-1.5 text-xs text-[var(--color-text)]">
            <Database size={13} className="text-emerald-400" />
            <span className="font-semibold">Rule A (0s Upstash)</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {/* Target Website Filter */}
          <div className="relative">
            <select
              value={selectedWebsiteId}
              onChange={(e) => setSelectedWebsiteId(e.target.value)}
              className="h-8 border bg-[var(--color-bg-elev)] px-2.5 text-xs text-[var(--color-text)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            >
              <option value="all">All Target Websites ({pendingItems.length})</option>
              {websites.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </div>

          {/* Verdict Filter */}
          <div className="flex items-center border p-0.5" style={{ borderColor: "var(--color-border)", backgroundColor: "var(--color-bg-elev)" }}>
            <button
              onClick={() => setFilterVerdict("all")}
              className={`px-2.5 py-1 text-xs font-medium cursor-pointer transition ${
                filterVerdict === "all"
                  ? "bg-[var(--color-bg-soft)] text-[var(--color-text)] shadow-xs"
                  : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterVerdict("high_confidence")}
              className={`px-2.5 py-1 text-xs font-medium cursor-pointer transition ${
                filterVerdict === "high_confidence"
                  ? "bg-emerald-500/20 text-emerald-300 shadow-xs"
                  : "text-[var(--color-text-muted)] hover:text-emerald-400"
              }`}
            >
              High Confidence (≥85)
            </button>
            <button
              onClick={() => setFilterVerdict("flagged")}
              className={`px-2.5 py-1 text-xs font-medium cursor-pointer transition ${
                filterVerdict === "flagged"
                  ? "bg-rose-500/20 text-rose-300 shadow-xs"
                  : "text-[var(--color-text-muted)] hover:text-rose-400"
              }`}
            >
              Requires Caution (&lt;75)
            </button>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search topic or keywords..."
            className="h-9 w-full rounded-xl border bg-[var(--color-bg-elev)] pl-8 pr-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none"
            style={{ borderColor: "var(--color-border)" }}
          />
        </div>
      </div>

      {/* Floating Batch Selection Bar */}
      {selectedIds.size > 0 && (
        <div className="mb-4 flex items-center justify-between border border-blue-500/30 bg-blue-500/10 p-3 animate-fadeIn">
          <div className="flex items-center gap-2 text-xs font-medium text-blue-300">
            <CheckCheck size={14} />
            <span>{selectedIds.size} article(s) selected</span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="primary"
              size="sm"
              icon={isBatchPublishing ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle2 size={12} />}
              onClick={batchApproveSelected}
              disabled={isBatchPublishing}
            >
              {isBatchPublishing ? "Publishing..." : `Approve & Publish Selected (${selectedIds.size})`}
            </Button>
            <button
              onClick={() => setSelectedIds(new Set())}
              className="text-xs text-[var(--color-text-muted)] hover:text-[var(--color-text)] px-2 py-1"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Main Review Items List */}
      <div className="space-y-4">
        {filteredItems.length === 0 ? (
          <Card>
            <div className="py-14 text-center">
              <CheckCircle2 size={36} className="mx-auto text-emerald-400" />
              <h3 className="mt-3 text-base font-semibold text-[var(--color-text)]">
                Review Gate is Clear
              </h3>
              <p className="mt-1 text-xs text-[var(--color-text-muted)] max-w-sm mx-auto">
                {pendingItems.length === 0
                  ? "All generated articles have been reviewed and published. When new articles complete LangGraph drafting, they will appear here for verification."
                  : "No pending articles match your current search or verdict filters."}
              </p>
            </div>
          </Card>
        ) : (
          filteredItems.map((item) => {
            const w = getWebsite(item.websiteId);
            const isUpstash = w?.storage_type !== "git";
            const factScore = item.factCheckScore ?? 88;
            const factVerdict = item.factCheckVerdict || (factScore >= 80 ? "Supported" : "Unsubstantiated");
            const isSelected = selectedIds.has(item.id);
            const isItemPending = !!pendingIds[item.id];

            return (
              <div
                key={item.id}
                className={`relative rounded-2xl border transition-all overflow-hidden shadow-[var(--shadow-card)] ${
                  isSelected
                    ? "border-blue-500/50 bg-blue-500/5 shadow-md"
                    : "border-[var(--color-border)] bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)]"
                }`}
              >
                <div className="p-4 sm:p-5">
                  <div className="flex items-start gap-3.5">
                    {/* Checkbox */}
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelect(item.id)}
                      className="mt-1 h-4 w-4 cursor-pointer rounded border-[var(--color-border)] bg-[var(--color-bg-soft)] text-blue-500 focus:ring-0"
                    />

                    {/* Website Icon */}
                    {w && <div className="mt-0.5"><WebsiteIcon website={w} /></div>}

                    {/* Main Content Area */}
                    <div className="min-w-0 flex-1">
                      {/* Top Badges & Meta */}
                      <div className="flex flex-wrap items-center gap-2">
                        <button
                          onClick={() => openInspector(item.id)}
                          className="text-base font-semibold tracking-tight text-[var(--color-text)] hover:underline text-left cursor-pointer"
                        >
                          {cleanMarkdown(item.title)}
                        </button>

                        <StatusBadge status="Awaiting Approval" />

                        {item.revisionCount && item.revisionCount > 0 ? (
                          <span className="border border-[var(--color-border)] bg-[var(--color-bg-soft)] px-1.5 py-0.5 font-mono text-[10px] font-semibold text-[var(--color-text-muted)]">
                            Rev #{item.revisionCount}
                          </span>
                        ) : null}

                        {/* Storage Engine Badge */}
                        <span className="inline-flex items-center gap-1 border border-emerald-500/20 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-mono font-medium text-emerald-400">
                          {isUpstash ? <Database size={10} /> : <GitBranch size={10} />}
                          {isUpstash ? "Rule A: 0s Publish" : "Git Target"}
                        </span>
                      </div>

                      {/* Subtitle / Excerpt */}
                      <p className="mt-2 text-xs leading-relaxed text-[var(--color-text-muted)] line-clamp-2">
                        {cleanMarkdown(item.excerpt || item.metaDescription) || "No excerpt generated."}
                      </p>

                      {/* Empirical Fact-Check & Quality Telemetry Grid */}
                      <div className="mt-3.5 grid grid-cols-1 sm:grid-cols-3 gap-2.5 border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
                        {/* 1. Fact Verification (A4) */}
                        <div className="flex items-center gap-2.5 border bg-[var(--color-bg-soft)] p-2" style={{ borderColor: "var(--color-border)" }}>
                          <ShieldCheck size={16} className={factScore >= 80 ? "text-emerald-400" : "text-amber-400"} />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-medium text-[var(--color-text-muted)]">Fact Verification</span>
                              <span className={`font-mono font-bold ${factScore >= 80 ? "text-emerald-400" : "text-amber-400"}`}>
                                {factScore}%
                              </span>
                            </div>
                            <div className="text-[10px] text-[var(--color-text-muted)] truncate">
                              Verdict: <span className="font-semibold text-[var(--color-text)]">{factVerdict}</span>
                              {item.verificationReport?.contradicted_count ? ` · ${item.verificationReport.contradicted_count} flagged` : " · 0 contradictions"}
                            </div>
                          </div>
                        </div>

                        {/* 2. SEO & AEO Canonical Quality (A5b) */}
                        <div className="flex items-center gap-2.5 border bg-[var(--color-bg-soft)] p-2" style={{ borderColor: "var(--color-border)" }}>
                          <FileCheck2 size={16} className="text-blue-400" />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-medium text-[var(--color-text-muted)]">SEO &amp; AEO Score</span>
                              <span className="font-mono font-bold text-blue-400">{item.seoScore}/100</span>
                            </div>
                            <div className="text-[10px] text-[var(--color-text-muted)] truncate">
                              Target: <span className="font-mono text-[var(--color-text)]">{item.targetKeyword || "General"}</span>
                            </div>
                          </div>
                        </div>

                        {/* 3. Hero Asset Path Compliance (Rule 3) */}
                        <div className="flex items-center gap-2.5 border bg-[var(--color-bg-soft)] p-2" style={{ borderColor: "var(--color-border)" }}>
                          <ImageIcon size={16} className="text-purple-400" />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-medium text-[var(--color-text-muted)]">Next.js Asset Sync</span>
                              <span className="font-mono text-[10px] text-purple-400 font-semibold">Rule 3 Ready</span>
                            </div>
                            <div className="text-[10px] text-[var(--color-text-muted)] truncate">
                              Path: <span className="font-mono text-[var(--color-text)]">/uploads/{item.slug || "hero"}.webp</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* AI Agent Reasoning & Audit notes if present */}
                      {item.aiNotes && (
                        <div className="mt-3 flex items-start gap-2 border bg-blue-500/5 p-2.5 text-xs text-[var(--color-text-muted)]" style={{ borderColor: "rgba(59,130,246,0.15)" }}>
                          <ShieldCheck size={13} className="mt-0.5 shrink-0 text-blue-400" />
                          <div>
                            <span className="font-medium text-blue-300">LangGraph Verification Audit: </span>
                            <span>{item.aiNotes}</span>
                          </div>
                        </div>
                      )}

                      {/* Action Button Row */}
                      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="primary"
                            size="sm"
                            icon={isItemPending ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                            onClick={() => approve(item)}
                            disabled={isItemPending}
                          >
                            {isItemPending ? "Publishing to Next.js..." : "Approve & Publish"}
                          </Button>

                          <Button
                            variant="secondary"
                            size="sm"
                            icon={<Edit3 size={13} />}
                            onClick={() => {
                              setSelectedItem(item);
                              setRejectOpen(true);
                            }}
                            disabled={isItemPending}
                          >
                            Request Changes
                          </Button>

                          <Button
                            variant="secondary"
                            size="sm"
                            icon={<Eye size={13} />}
                            onClick={() => openInspector(item.id)}
                          >
                            Inspect Claims &amp; Model
                          </Button>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleReject(item)}
                            disabled={isItemPending}
                            className="inline-flex cursor-pointer items-center gap-1 px-2.5 py-1 text-xs text-rose-400 hover:bg-rose-500/10 transition"
                          >
                            <XCircle size={13} />
                            Reject Run
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Request Changes Modal */}
      <Modal
        open={rejectOpen}
        onClose={() => setRejectOpen(false)}
        title="Request Revisions from Agent"
        description={
          selectedItem
            ? `Inject human editorial steering into LangGraph drafting node for “${selectedItem.title}”.`
            : "Specify change instructions."
        }
        size="md"
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => setRejectOpen(false)}
              disabled={selectedItem ? pendingIds[selectedItem.id] : false}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              icon={
                selectedItem && pendingIds[selectedItem.id] ? (
                  <Loader2 size={13} className="animate-spin" />
                ) : (
                  <Edit3 size={13} />
                )
              }
              onClick={handleRequestChanges}
              disabled={selectedItem ? pendingIds[selectedItem.id] : false}
            >
              {selectedItem && pendingIds[selectedItem.id]
                ? "Dispatched to LangGraph..."
                : "Submit Revision Request"}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
              Editorial Instructions &amp; Prompt Adjustments
            </label>
            <textarea
              rows={4}
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="e.g. Include an enterprise comparison table comparing Next.js route handlers vs Express. Add technical benchmarks and citations."
              className="w-full border bg-[var(--color-bg-soft)] p-3 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-muted)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>

          {/* Quick Preset Feedback Chips */}
          <div>
            <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-[var(--color-text-muted)]">
              Quick Suggestions
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                "Add comparison benchmark table",
                "Tighten tone & remove passive voice",
                "Add concrete code examples",
                "Strengthen conclusion with clear action items",
                "Verify stats against primary sources",
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => applyPresetFeedback(suggestion)}
                  className="cursor-pointer border border-[var(--color-border)] bg-[var(--color-bg-elev)] px-2 py-1 text-[11px] text-[var(--color-text-muted)] hover:border-blue-500/40 hover:text-[var(--color-text)] transition"
                >
                  + {suggestion}
                </button>
              ))}
            </div>
          </div>

          <div
            className="border p-3 text-xs text-[var(--color-text-muted)]"
            style={{ borderColor: "var(--color-border)", backgroundColor: "var(--color-bg-soft)" }}
          >
            <span className="font-semibold text-[var(--color-text)]">LangGraph Loop:</span> The drafting node will re-run with this feedback injected, re-verify claims with the fact-checker, recalculate SEO scores, and place the revised article back into this gate.
          </div>
        </div>
      </Modal>
    </div>
  );
}