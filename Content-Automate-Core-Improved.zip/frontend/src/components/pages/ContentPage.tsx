import { useMemo, useState, useEffect } from "react";
import {
  Search,
  MoreHorizontal,
  Plus,
  ExternalLink,
  Eye,
  FileEdit,
  FileText,
  Send,
  ClipboardCheck,
  Bot,
  Globe,
  Clock,
  RefreshCw,
  Loader2,
  X,
  Compass,
  LayoutGrid,
  List,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Zap,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Languages,
  ArrowRight,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { StatusBadge } from "../StatusBadge";
import { MetricCard } from "../MetricCard";
import { Dropdown, DropdownItem } from "../Dropdown";
import { WebsiteIcon } from "../WebsiteIcon";
import { useNav } from "../../lib/nav";
import { usePipelineData } from "../../lib/dataContext";
import type { ContentStatus } from "../../types";
import { cn } from "../../utils/cn";
import { cleanMarkdown } from "../../utils/cleanMarkdown";

const statuses: ContentStatus[] = [
  "Idea",
  "Drafting",
  "SEO Check",
  "Awaiting Approval",
  "Published",
  "Failed",
];

export function ContentPage({ initialFilter }: { initialFilter?: ContentStatus[] }) {
  const { setPage, openInspector, setSelectedArticleId, openLaunchModal, page } = useNav();
  const { contentItems, websites, getWebsite, reviewArticle, refreshAll, isLoading } = usePipelineData();

  const [statusFilter, setStatusFilter] = useState<ContentStatus[]>(initialFilter ?? []);
  const [selectedSiteFilter, setSelectedSiteFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState<"calendar" | "table" | "kanban">("calendar");
  const [weekOffset, setWeekOffset] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Sync sub-routes if navigated via queue / drafts / published aliases
  useEffect(() => {
    if (page === "drafts") {
      setStatusFilter(["Drafting", "SEO Check"]);
    } else if (page === "queue") {
      setStatusFilter(["Idea", "Drafting"]);
    } else if (page === "published") {
      setStatusFilter(["Published"]);
    }
  }, [page]);

  const filtered = useMemo(() => {
    return contentItems.filter((c) => {
      if (selectedSiteFilter !== "all" && c.websiteId !== selectedSiteFilter) return false;
      if (statusFilter.length > 0 && !statusFilter.includes(c.status)) return false;
      if (
        search &&
        !c.title.toLowerCase().includes(search.toLowerCase()) &&
        !c.excerpt?.toLowerCase().includes(search.toLowerCase()) &&
        !c.targetKeyword?.toLowerCase().includes(search.toLowerCase())
      ) {
        return false;
      }
      return true;
    });
  }, [contentItems, statusFilter, selectedSiteFilter, search]);

  const toggleStatus = (s: ContentStatus) => {
    setStatusFilter((arr) =>
      arr.includes(s) ? arr.filter((x) => x !== s) : [...arr, s]
    );
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refreshAll();
    } finally {
      setIsRefreshing(false);
    }
  };

  // Metrics counts
  const publishedCount = contentItems.filter((c) => c.status === "Published").length;
  const reviewCount = contentItems.filter((c) => c.status === "Awaiting Approval").length;
  const inFlightCount = contentItems.filter(
    (c) => c.status === "Drafting" || c.status === "SEO Check" || c.status === "Idea"
  ).length;

  // Dynamic calendar week calculations
  const weekDays = useMemo(() => {
    const today = new Date();
    const target = new Date(today);
    target.setDate(today.getDate() + weekOffset * 7);

    // Compute Monday of the active week (Sunday = 0, Monday = 1)
    const day = target.getDay();
    const diffToMonday = (day === 0 ? -6 : 1) - day;
    const monday = new Date(target);
    monday.setDate(target.getDate() + diffToMonday);

    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return d;
    });
  }, [weekOffset]);

  const monthYearLabel = useMemo(() => {
    if (weekDays.length === 0) return "";
    return weekDays[0].toLocaleDateString("en-US", { month: "short", year: "numeric" });
  }, [weekDays]);

  const isCurrentWeek = weekOffset === 0;

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
              Content Pipeline Studio
            </h1>
            <span className="rounded-full bg-[var(--color-bg-soft)] px-2.5 py-0.5 font-mono text-xs font-semibold text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
              {contentItems.length} runs
            </span>
          </div>
          <p className="mt-1 text-xs sm:text-sm text-[var(--color-text-muted)]">
            Workbench for autonomous content authoring, fact-verification audits, and multi-CMS delivery.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* View mode toggle */}
          <div className="flex items-center rounded-xl border p-0.5 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
            <button
              type="button"
              onClick={() => setViewMode("calendar")}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition cursor-pointer",
                viewMode === "calendar"
                  ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-[var(--shadow-soft)]"
                  : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <Calendar size={13} /> Calendar
            </button>
            <button
              type="button"
              onClick={() => setViewMode("table")}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition cursor-pointer",
                viewMode === "table"
                  ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-[var(--shadow-soft)]"
                  : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <List size={13} /> Table
            </button>
            <button
              type="button"
              onClick={() => setViewMode("kanban")}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition cursor-pointer",
                viewMode === "kanban"
                  ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-[var(--shadow-soft)]"
                  : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
              )}
            >
              <LayoutGrid size={13} /> Kanban
            </button>
          </div>

          <Button
            variant="secondary"
            size="md"
            icon={<RefreshCw size={13} className={isRefreshing ? "animate-spin" : ""} />}
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            Refresh
          </Button>

          <Button
            variant="primary"
            size="md"
            icon={<Plus size={14} />}
            onClick={openLaunchModal}
          >
            New Pipeline Run
          </Button>
        </div>
      </div>

      {/* Sub-Header with Real Metrics and Dynamic Calendar Controls */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-[var(--color-text-muted)] font-medium">
              Editorial publishing schedule across connected sites:
            </span>
            <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-bold text-emerald-500 border border-emerald-500/20">
              ✓ {publishedCount} PUBLISHED
            </span>
            <span className="rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-bold text-amber-500 border border-amber-500/20">
              {inFlightCount} IN GENERATION
            </span>
            {reviewCount > 0 && (
              <span className="rounded-full bg-purple-500/10 px-2.5 py-0.5 text-[11px] font-bold text-purple-400 border border-purple-500/20">
                {reviewCount} REVIEW NEEDED
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPage("keywords")}
              className="flex items-center gap-1.5 rounded-xl border bg-[var(--color-bg-soft)] px-3 py-1.5 text-xs font-semibold text-[var(--color-text)] hover:border-[var(--color-border-strong)] transition cursor-pointer"
              style={{ borderColor: "var(--color-border)" }}
            >
              <Plus size={13} />
              <span>Keyword Strategy</span>
            </button>
            <div
              className="flex items-center gap-1.5 rounded-xl border bg-[var(--color-bg-soft)] px-3 py-1.5 text-xs font-semibold text-[var(--color-text)]"
              style={{ borderColor: "var(--color-border)" }}
            >
              <span>{monthYearLabel}</span>
              <div className="flex items-center gap-1 text-[var(--color-text-muted)]">
                <button
                  type="button"
                  onClick={() => setWeekOffset((o) => o - 1)}
                  className="hover:text-[var(--color-text)] p-0.5 cursor-pointer"
                  title="Previous week"
                >
                  <ChevronLeft size={13} />
                </button>
                {!isCurrentWeek && (
                  <button
                    type="button"
                    onClick={() => setWeekOffset(0)}
                    className="text-[10px] font-bold text-[var(--color-accent-text)] px-1 hover:underline cursor-pointer"
                    title="Jump to today"
                  >
                    Today
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setWeekOffset((o) => o + 1)}
                  className="hover:text-[var(--color-text)] p-0.5 cursor-pointer"
                  title="Next week"
                >
                  <ChevronRight size={13} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Telemetry Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <MetricCard
          label="Total Runs"
          value={contentItems.length}
          hint={contentItems.length > 0 ? "Articles in pipeline" : "No runs yet"}
          icon={<FileText size={16} />}
          iconBg="var(--color-bg-soft)"
          iconColor="var(--color-text)"
        />
        <MetricCard
          label="Published to Next.js"
          value={publishedCount}
          hint={publishedCount > 0 ? "Live across target sites" : "None published yet"}
          icon={<Send size={16} />}
          iconBg="var(--color-accent-soft)"
          iconColor="var(--color-accent-text)"
        />
        <MetricCard
          label="Awaiting Approval"
          value={reviewCount}
          hint={reviewCount > 0 ? "Action required to publish" : "Queue clear"}
          icon={<ClipboardCheck size={16} />}
          iconBg="var(--color-warn-soft)"
          iconColor="var(--color-warn)"
        />
        <MetricCard
          label="In Generation"
          value={inFlightCount}
          hint={inFlightCount > 0 ? "Pipeline engine active" : "Engine idle"}
          icon={<Zap size={16} />}
          iconBg="var(--color-info-soft)"
          iconColor="var(--color-info)"
        />
      </div>

      {/* Main Operations Card */}
      <Card padded={false} className="overflow-hidden">
        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
          <div className="flex flex-wrap items-center gap-2.5 flex-1 max-w-xl">
            {/* Search */}
            <div className="relative min-w-[200px] flex-1">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search runs, topics, keywords…"
                className="h-8.5 w-full rounded-xl border bg-[var(--color-bg-soft)] pl-8.5 pr-8 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
                style={{ borderColor: "var(--color-border)" }}
              />
              {search && (
                <button
                  onClick={() => setSearch("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-[var(--color-text-subtle)] hover:text-[var(--color-text)] cursor-pointer"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* Target Website filter */}
            <select
              value={selectedSiteFilter}
              onChange={(e) => setSelectedSiteFilter(e.target.value)}
              className="h-8.5 rounded-xl border bg-[var(--color-bg-soft)] px-3 text-xs text-[var(--color-text)] transition focus:border-[var(--color-accent)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            >
              <option value="all">All Target Websites</option>
              {websites.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status chips */}
          <div className="flex flex-wrap items-center gap-1.5">
            {statuses.map((s) => {
              const active = statusFilter.includes(s);
              const count = contentItems.filter((c) => c.status === s).length;
              return (
                <button
                  key={s}
                  onClick={() => toggleStatus(s)}
                  className={cn(
                    "flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-medium transition cursor-pointer",
                    active
                      ? "border-[var(--color-text)] bg-[var(--color-text)] text-[var(--color-bg)] font-semibold"
                      : "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)] hover:text-[var(--color-text)]"
                  )}
                >
                  <span>{s}</span>
                  {count > 0 && (
                    <span className={cn("rounded px-1 text-[9px] font-mono", active ? "bg-[var(--color-bg)] text-[var(--color-text)]" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]")}>
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
            {statusFilter.length > 0 && (
              <button
                onClick={() => setStatusFilter([])}
                className="text-[11px] font-semibold text-[var(--color-accent-text)] hover:underline cursor-pointer ml-1"
              >
                Reset
              </button>
            )}
          </div>
        </div>

        {/* Content View: Table or Kanban or Calendar */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center p-16 text-center">
            <Loader2 size={24} className="animate-spin text-[var(--color-text)]" />
            <p className="mt-3 text-sm font-semibold text-[var(--color-text)]">
              Syncing pipeline state...
            </p>
            <p className="mt-1 text-xs text-[var(--color-text-muted)]">
              Querying FastAPI state graph and LangGraph persistence threads.
            </p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-16 text-center">
            <Compass size={28} className="mx-auto mb-2 text-[var(--color-text-subtle)]" />
            <h3 className="text-sm font-semibold text-[var(--color-text)]">
              No runs match this filter
            </h3>
            <p className="mt-1 text-xs text-[var(--color-text-muted)] max-w-sm">
              Adjust your search keywords or status filter, or dispatch a new pipeline run.
            </p>
            <Button
              variant="secondary"
              size="sm"
              className="mt-4"
              onClick={() => {
                setStatusFilter([]);
                setSelectedSiteFilter("all");
                setSearch("");
              }}
            >
              Reset All Filters
            </Button>
          </div>
        ) : viewMode === "calendar" ? (
          /* Dynamic Calendar Grid View with Real Days & Real Runs */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-3 p-4">
            {weekDays.map((dayDate) => {
              const dayStr = dayDate.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
              const dateNum = dayDate.getDate();
              const isToday = (() => {
                const now = new Date();
                return (
                  now.getFullYear() === dayDate.getFullYear() &&
                  now.getMonth() === dayDate.getMonth() &&
                  now.getDate() === dayDate.getDate()
                );
              })();

              const itemsForDay = filtered.filter((item) => {
                const d = item.createdAtDate;
                return (
                  d.getFullYear() === dayDate.getFullYear() &&
                  d.getMonth() === dayDate.getMonth() &&
                  d.getDate() === dayDate.getDate()
                );
              });

              return (
                <div
                  key={dayDate.toISOString()}
                  className={cn(
                    "flex flex-col min-h-[340px] rounded-2xl border p-3 space-y-3 transition",
                    isToday
                      ? "border-[var(--color-accent)]/50 bg-[var(--color-accent)]/[0.03]"
                      : "bg-[var(--color-bg-soft)]/40 border-[var(--color-border)]"
                  )}
                >
                  <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: "var(--color-border)" }}>
                    <div className="flex items-center gap-1.5">
                      <span className={cn("text-xs font-bold font-mono", isToday ? "text-[var(--color-accent)]" : "text-[var(--color-text)]")}>
                        {dayStr} {dateNum}
                      </span>
                      {isToday && (
                        <span className="rounded-full bg-[var(--color-accent)]/15 px-1.5 py-0.2 text-[9px] font-bold text-[var(--color-accent)]">
                          Today
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">
                      {itemsForDay.length > 0 ? `${itemsForDay.length} post${itemsForDay.length > 1 ? "s" : ""}` : "Empty"}
                    </span>
                  </div>

                  <div className="space-y-2.5 flex-1">
                    {itemsForDay.length > 0 ? (
                      itemsForDay.map((item) => {
                        const site = getWebsite(item.websiteId);
                        return (
                          <div
                            key={item.id}
                            onClick={() => openInspector(item.id)}
                            className="group rounded-xl border bg-[var(--color-bg-elev)] p-3 shadow-xs hover:border-[var(--color-border-strong)] transition cursor-pointer space-y-2"
                            style={{ borderColor: "var(--color-border)" }}
                          >
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-[10px] font-semibold text-[var(--color-text-subtle)] truncate max-w-[80px]">
                                {site ? site.name : "Target"}
                              </span>
                              <StatusBadge status={item.status} />
                            </div>

                            <h4 className="text-xs font-bold text-[var(--color-text)] line-clamp-2 leading-snug group-hover:text-[var(--color-accent-text)]">
                              {cleanMarkdown(item.title)}
                            </h4>

                            <div className="flex items-center justify-between text-[10px] text-[var(--color-text-muted)] font-mono pt-1 border-t" style={{ borderColor: "var(--color-border)" }}>
                              <span className="truncate max-w-[70px]">{item.targetKeyword || "Editorial"}</span>
                              <span>{item.readingTime || (item.draft ? `${item.draft.split(/\s+/).length}w` : "1.8kw")}</span>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div
                        onClick={openLaunchModal}
                        className="flex h-32 flex-col items-center justify-center rounded-xl border border-dashed border-[var(--color-border)] p-3 text-center hover:border-[var(--color-border-strong)] transition cursor-pointer group"
                      >
                        <Plus size={14} className="text-[var(--color-text-subtle)] group-hover:scale-110 transition-transform mb-1" />
                        <span className="text-[10px] font-medium text-[var(--color-text-subtle)] group-hover:text-[var(--color-text)]">
                          + Schedule post
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : viewMode === "table" ? (
          /* Dense Table View */
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[var(--color-bg-soft)] border-b text-[10px] font-mono uppercase tracking-wider text-[var(--color-text-subtle)]" style={{ borderColor: "var(--color-border)" }}>
                <tr>
                  <th className="px-5 py-3">Title &amp; Target Keyword</th>
                  <th className="px-4 py-3">Website</th>
                  <th className="px-4 py-3">Stage / Status</th>
                  <th className="px-4 py-3">Blueprint</th>
                  <th className="px-4 py-3 text-center">Fact-Check</th>
                  <th className="px-4 py-3 text-center">SEO</th>
                  <th className="px-4 py-3">Created</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: "var(--color-border)" }}>
                {filtered.map((item) => {
                  const site = getWebsite(item.websiteId);
                  return (
                    <tr key={item.id} className="transition-colors hover:bg-[var(--color-bg-soft)]/60">
                      {/* Title */}
                      <td className="px-5 py-3.5 max-w-xs">
                        <button
                          type="button"
                          onClick={() => openInspector(item.id)}
                          className="font-bold text-xs text-[var(--color-text)] hover:underline text-left line-clamp-1 block cursor-pointer"
                        >
                          {cleanMarkdown(item.title)}
                        </button>
                        {item.targetKeyword && (
                          <span className="font-mono text-[10px] text-[var(--color-text-subtle)] mt-0.5 block truncate">
                            🎯 {item.targetKeyword}
                          </span>
                        )}
                      </td>

                      {/* Website */}
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span className="font-medium text-[var(--color-text)] flex items-center gap-1.5">
                          {site ? <WebsiteIcon website={site} size={16} /> : <Globe size={14} />}
                          <span>{site ? site.name : "Default"}</span>
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <StatusBadge status={item.status} />
                      </td>

                      {/* Blueprint */}
                      <td className="px-4 py-3.5 whitespace-nowrap">
                        <span className="rounded bg-[var(--color-bg-soft)] border px-2 py-0.5 font-mono text-[10px] text-[var(--color-text-muted)] capitalize" style={{ borderColor: "var(--color-border)" }}>
                          {item.articleModel?.article_type ? item.articleModel.article_type.replace(/_/g, " ") : "how to"}
                        </span>
                      </td>

                      {/* Fact-check Score */}
                      <td className="px-4 py-3.5 text-center font-mono">
                        {item.factCheckScore !== undefined ? (
                          <span
                            className={cn(
                              "rounded px-1.5 py-0.2 font-bold text-[10px]",
                              item.factCheckScore >= 80
                                ? "bg-[var(--color-live-soft)] text-[var(--color-live)]"
                                : item.factCheckScore >= 60
                                ? "bg-[var(--color-warn-soft)] text-[var(--color-warn)]"
                                : "bg-[rgba(239,68,68,0.15)] text-[var(--color-danger)]"
                            )}
                          >
                            {item.factCheckScore}%
                          </span>
                        ) : (
                          <span className="text-[var(--color-text-subtle)]">—</span>
                        )}
                      </td>

                      {/* SEO Score */}
                      <td className="px-4 py-3.5 text-center font-mono">
                        {item.seoScore > 0 ? (
                          <span
                            className={cn(
                              "rounded px-1.5 py-0.2 font-bold text-[10px]",
                              item.seoScore >= 90
                                ? "bg-[var(--color-live-soft)] text-[var(--color-live)]"
                                : item.seoScore >= 70
                                ? "bg-[var(--color-warn-soft)] text-[var(--color-warn)]"
                                : "bg-[rgba(239,68,68,0.15)] text-[var(--color-danger)]"
                            )}
                          >
                            {item.seoScore}
                          </span>
                        ) : (
                          <span className="text-[var(--color-text-subtle)]">—</span>
                        )}
                      </td>

                      {/* Created */}
                      <td className="px-4 py-3.5 whitespace-nowrap text-[var(--color-text-muted)] font-mono text-[11px]">
                        {item.createdAt}
                      </td>

                      {/* Actions */}
                      <td className="px-5 py-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => openInspector(item.id)}
                            icon={<Eye size={12} />}
                          >
                            Inspect
                          </Button>
                          {item.publishedUrl && (
                            <a
                              href={item.publishedUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="rounded-lg p-1.5 text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] inline-flex items-center"
                              title="View published article"
                            >
                              <ExternalLink size={13} />
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* Kanban Board View */
          <div className="p-5 grid grid-cols-1 md:grid-cols-5 gap-4 overflow-x-auto min-w-[900px]">
            {(
              [
                { title: "Queued & Idea", statusKey: "Idea", bg: "var(--color-bg-soft)" },
                { title: "Active Drafting", statusKey: "Drafting", bg: "var(--color-accent-soft)" },
                { title: "SEO & AEO Audit", statusKey: "SEO Check", bg: "var(--color-info-soft)" },
                { title: "Review Gate", statusKey: "Awaiting Approval", bg: "var(--color-warn-soft)" },
                { title: "Published", statusKey: "Published", bg: "var(--color-live-soft)" },
              ] as const
            ).map((col) => {
              const colItems = filtered.filter((c) => c.status === col.statusKey);
              return (
                <div key={col.title} className="rounded-xl border p-3 bg-[var(--color-bg-soft)]/50 flex flex-col space-y-3" style={{ borderColor: "var(--color-border)" }}>
                  <div className="flex items-center justify-between pb-2 border-b" style={{ borderColor: "var(--color-border)" }}>
                    <span className="text-xs font-bold text-[var(--color-text)]">{col.title}</span>
                    <span className="rounded-full bg-[var(--color-bg-elev)] px-1.5 py-0.2 font-mono text-[10px] font-bold text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                      {colItems.length}
                    </span>
                  </div>

                  <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[600px] pr-1">
                    {colItems.map((item) => {
                      const site = getWebsite(item.websiteId);
                      return (
                        <div
                          key={item.id}
                          onClick={() => openInspector(item.id)}
                          className="rounded-xl border p-3 bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)] transition shadow-[var(--shadow-soft)] cursor-pointer space-y-2"
                          style={{ borderColor: "var(--color-border)" }}
                        >
                          <div className="font-bold text-xs text-[var(--color-text)] line-clamp-2">
                            {cleanMarkdown(item.title)}
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-[var(--color-text-muted)] font-mono">
                            <span>{site ? site.name : "Default"}</span>
                            <span>{item.createdAt}</span>
                          </div>

                          <div className="flex items-center justify-between pt-1 border-t" style={{ borderColor: "var(--color-border)" }}>
                            <span className="text-[10px] font-mono text-[var(--color-text-subtle)]">
                              SEO: {item.seoScore || "—"}
                            </span>
                            {item.factCheckScore !== undefined && (
                              <span className="text-[10px] font-mono text-[var(--color-live)]">
                                FC: {item.factCheckScore}%
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}