import { useState } from "react";
import {
  Plus,
  Calendar,
  CalendarCheck,
  MoreHorizontal,
  Pause,
  Play,
  Clock,
  Zap,
  Loader2,
  CheckCircle2,
  Bot,
  Repeat,
  Edit3,
  Trash2,
  Layers,
  Sliders,
  FileText,
  ArrowRight,
  ShieldCheck,
  Radio,
  Terminal,
  Workflow,
  Table as TableIcon,
  HelpCircle,
  Lightbulb,
  Target,
  BookOpen,
  Image as ImageIcon,
  X,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { Dropdown, DropdownItem, DropdownSeparator } from "../Dropdown";
import { Modal } from "../Modal";
import { StatusBadge } from "../StatusBadge";
import { WebsiteIcon } from "../WebsiteIcon";
import { useToast } from "../../lib/toast";
import { usePipelineData } from "../../lib/dataContext";
import { useNav } from "../../lib/nav";
import { cn } from "../../utils/cn";

const BLUEPRINTS = [
  { id: "how_to", name: "How-to Guide", desc: "Step-by-step tutorial with answer-first intro & screenshots" },
  { id: "comparison", name: "Comparison (X vs Y)", desc: "Verdict up top, comparison & pricing tables, pros/cons" },
  { id: "definition", name: "Definition (What is)", desc: "Answer block definition, concept diagram, real examples" },
  { id: "roundup", name: "Roundup / Listicle", desc: "Selection criteria, consistent item structure, summary table" },
  { id: "data_study", name: "Data Study", desc: "Methodology, charts from empirical data, downloadable dataset" },
  { id: "case_study", name: "Case Study", desc: "Real customer, concrete numbers, before/after timeline" },
  { id: "pillar_guide", name: "Pillar Guide", desc: "TOC, section answer blocks, internal link hub" },
];

const FREQ_OPTIONS = [
  { value: "daily", label: "Daily (every 24h)", hours: 24 },
  { value: "weekly", label: "Weekly (every 7d)", hours: 168 },
  { value: "biweekly", label: "Biweekly (every 14d)", hours: 336 },
  { value: "monthly", label: "Monthly (every 30d)", hours: 720 },
];

export function SchedulesPage() {
 const { setActiveRunThreadId, openInspector } = useNav();
 const {
 schedules,
 websites,
 contentItems,
 getWebsite,
 toggleScheduleStatus,
 escalateScheduleNow,
 createScheduleItem,
 deleteScheduleItem,
 } = usePipelineData();

 const [open, setOpen] = useState(false);
 const [loadingActionId, setLoadingActionId] = useState<string | null>(null);
 const [showAutomationGuide, setShowAutomationGuide] = useState(true);

 // Form states
 const [name, setName] = useState("");
 const [selectedSiteId, setSelectedSiteId] = useState(websites[0]?.id || "");
 const [topicMode, setTopicMode] = useState<"manual" | "auto">("manual");
 const [topicPrompt, setTopicPrompt] = useState("");
 const [keywords, setKeywords] = useState("");
 const [targetAudience, setTargetAudience] = useState("Full-Stack Developers");
 const [scheduleType, setScheduleType] = useState<"once" | "recurring">("recurring");
 const [frequency, setFrequency] = useState("daily");
 const [publishTime, setPublishTime] = useState("08:00");
 const [slackReviewRequired, setSlackReviewRequired] = useState(true);
 const [selectedBlueprint, setSelectedBlueprint] = useState<string>("how_to");
 const [enableDiagrams, setEnableDiagrams] = useState<boolean>(true);
 const [enableTables, setEnableTables] = useState<boolean>(true);
 const [enableFaqs, setEnableFaqs] = useState<boolean>(true);
 const [enableTakeaways, setEnableTakeaways] = useState<boolean>(true);
 const [enableAnswerBlocks, setEnableAnswerBlocks] = useState<boolean>(true);
 const [enableCitations, setEnableCitations] = useState<boolean>(true);
 const [enableHeroImage, setEnableHeroImage] = useState<boolean>(true);
 const [submitting, setSubmitting] = useState(false);

 const { push } = useToast();

 const handleToggle = async (id: string, sName: string) => {
 try {
 await toggleScheduleStatus(id);
 push({
 title: "Schedule updated",
 description: `Toggled schedule status for ${sName}.`,
 variant: "info",
 });
 } catch (err: any) {
 push({
 title: "Error",
 description: err.message || "Failed to toggle schedule.",
 variant: "danger",
 });
 }
 };

 const handleEscalate = async (id: string, sName: string) => {
 setLoadingActionId(id);
 try {
 const res = await escalateScheduleNow(id);
 if (res?.thread_id) {
 setActiveRunThreadId(res.thread_id);
 }
 push({
 title: "Autonomous Run Dispatched! 🚀",
 description: res?.thread_id
   ? `Dispatched LangGraph run #${res.thread_id.slice(0, 8)} for “${sName}”. Live HUD active.`
   : `Pipeline run started for ${sName}.`,
 variant: "success",
 });
 } catch (err: any) {
 push({
 title: "Run failed",
 description: err.message || "Could not trigger immediate run.",
 variant: "danger",
 });
 } finally {
 setLoadingActionId(null);
 }
 };

 const formatNextRunCountdown = (nextRunStr?: string) => {
 if (!nextRunStr) return null;
 try {
 const target = new Date(nextRunStr).getTime();
 if (isNaN(target)) return null;
 const now = Date.now();
 const diff = target - now;
 if (diff <= 0) return "Due now";
 const hours = Math.floor(diff / (1000 * 60 * 60));
 const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
 if (hours < 1) return `in ${mins}m`;
 if (hours < 24) return `in ~${hours}h`;
 const days = Math.floor(hours / 24);
 return `in ~${days}d`;
 } catch {
 return null;
 }
 };

 const handleDelete = async (id: string, sName: string) => {
 if (!confirm(`Delete schedule "${sName}"?`)) return;
 try {
 await deleteScheduleItem(id);
 push({
 title: "Schedule deleted",
 description: `Removed ${sName}.`,
 variant: "info",
 });
 } catch (err: any) {
 push({
 title: "Error",
 description: err.message || "Failed to delete schedule.",
 variant: "danger",
 });
 }
 };

 const handleCreateSchedule = async () => {
 if (!name.trim()) {
 push({
 title: "Missing name",
 description: "Please give the schedule a name.",
 variant: "warn",
 });
 return;
 }
 if (topicMode === "manual" && !topicPrompt.trim()) {
 push({
 title: "Missing topic",
 description: "Pick a topic, or switch to “Agent finds a topic” mode.",
 variant: "warn",
 });
 return;
 }

 setSubmitting(true);
 try {
 const kwList = keywords
 .split(",")
 .map((k) => k.trim())
 .filter(Boolean);

 const targetSite = selectedSiteId || (websites[0]?.id ?? "default");
 const freqHours = FREQ_OPTIONS.find((f) => f.value === frequency)?.hours ?? 24;

 await createScheduleItem({
 name: name.trim(),
 website_id: targetSite,
 topic_prompt: topicMode === "manual" ? topicPrompt.trim() : "",
 keywords: kwList,
 target_audience: targetAudience.trim() || "Developers",
 frequency,
 interval_hours: freqHours,
 slack_review_required: slackReviewRequired,
 schedule_type: scheduleType,
 publish_time: publishTime.trim() || undefined,
 content_format: selectedBlueprint,
 enable_diagrams: enableDiagrams,
 enable_tables: enableTables,
 enable_faqs: enableFaqs,
 enable_takeaways: enableTakeaways,
 enable_answer_blocks: enableAnswerBlocks,
 enable_citations: enableCitations,
 enable_hero_image: enableHeroImage,
 });

 push({
 title: "Schedule created",
 description:
 scheduleType === "once"
 ? `“${name.trim()}” will fire once at ${publishTime} UTC.`
 : `“${name.trim()}” is active — ${FREQ_OPTIONS.find((f) => f.value === frequency)?.label ?? "Daily"} at ${publishTime} UTC.`,
 variant: "success",
 });
 setOpen(false);
 setName("");
 setTopicPrompt("");
 setKeywords("");
 setTopicMode("manual");
 } catch (err: any) {
 push({
 title: "Error",
 description: err.message || "Could not create schedule.",
 variant: "danger",
 });
 } finally {
 setSubmitting(false);
 }
 };

 const isCompleted = (t?: string) => t === "completed";

   return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
  {/* Standardized aligned header */}
  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
    <div>
      <div className="flex items-center gap-2.5">
        <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
          Automated Schedules
        </h1>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-blue-500">
          <span className="h-1.5 w-1.5 rounded-full bg-blue-500 animate-pulse" />
          Scheduler Active
        </span>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
        Recurring and event-driven publishing cadences. Researches, drafts, audits, and dispatches autonomously.
      </p>
    </div>
    <Button
      variant="primary"
      size="sm"
      icon={<Plus size={14} className="stroke-[2.5]" />}
      onClick={() => setOpen(true)}
      className="text-xs font-semibold cursor-pointer"
    >
      New Schedule
    </Button>
  </div>

 {/* Automation Masterclass Flow Banner */}
 <div
 className="mb-8 overflow-hidden rounded-xl border transition-all"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}
 >
 <div
 className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3.5"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center gap-2.5">
 <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[var(--color-accent)]/15 text-[var(--color-accent-text)]">
 <Zap size={15} />
 </div>
 <div>
 <h2 className="text-sm font-semibold text-[var(--color-text)]">
 How Autonomous Scheduled Publishing Works
 </h2>
 <p className="text-[11px] text-[var(--color-text-muted)]">
 Opportunity Feed discovery &rarr; 10-stage LangGraph pipeline &rarr; Human Review Gate &rarr; Next.js HTTP publish
 </p>
 </div>
 </div>
 <div className="flex items-center gap-2">
 <button
 type="button"
 onClick={() => setShowAutomationGuide(!showAutomationGuide)}
 className="text-xs font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] transition cursor-pointer"
 >
 {showAutomationGuide ? "Hide Flow Details" : "Show Flow Details"}
 </button>
 </div>
 </div>

 {showAutomationGuide && (
 <div className="p-5 space-y-4">
 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
 {/* Stage 1: Trigger & Schedule */}
 <div
 className="rounded-lg border p-3.5 space-y-2"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 1
 </span>
 <span className="font-mono text-[10px] text-[var(--color-text-muted)]">Cron / Trigger</span>
 </div>
 <div className="text-xs font-bold text-[var(--color-text)]">Autonomous Trigger</div>
 <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
 FastAPI in-memory scheduler checks active cron intervals (Daily, Weekly, Bi-weekly) or responds to 1-click &ldquo;Run Now&rdquo; escalations.
 </p>
 </div>

 {/* Stage 2: Opportunity Feed Discovery */}
 <div
 className="rounded-lg border p-3.5 space-y-2"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 2
 </span>
 <span className="font-mono text-[10px] text-[var(--color-text-muted)]">Discovery</span>
 </div>
 <div className="text-xs font-bold text-[var(--color-text)]">Opportunity Feed / Prompt</div>
 <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
 If a custom topic prompt is given, it starts immediately. If set to &ldquo;Agent finds a topic&rdquo;, it mines Google PAA and SERP competitor gaps.
 </p>
 </div>

 {/* Stage 3: LangGraph Pipeline */}
 <div
 className="rounded-lg border p-3.5 space-y-2"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 3
 </span>
 <span className="font-mono text-[10px] text-[var(--color-text-muted)]">LangGraph</span>
 </div>
 <div className="text-xs font-bold text-[var(--color-text)]">10-Stage Synthesis</div>
 <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
 Research &rarr; Outline &rarr; Section Draft &rarr; Parallel Fact-Check &rarr; Visual Density &rarr; AEO &rarr; On-Page Schema validation.
 </p>
 </div>

 {/* Stage 4: Publishing & Review */}
 <div
 className="rounded-lg border p-3.5 space-y-2"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 4
 </span>
 <span className="font-mono text-[10px] text-[var(--color-text-muted)]">Publish / Review</span>
 </div>
 <div className="text-xs font-bold text-[var(--color-text)]">Review Gate &rarr; Webhook</div>
 <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
 Mode 1 pauses for human approval in Studio / Slack. Mode 2/3 sends the post payload directly to target Next.js <code className="font-mono text-[var(--color-text)]">/api/posts</code>.
 </p>
 </div>
 </div>
 </div>
 )}
 </div>

 {schedules.length === 0 ? (
 <Card>
 <div className="py-12 text-center">
 <Calendar size={32} className="mx-auto text-[var(--color-text-subtle)]" />
 <h3 className="mt-3 text-[16px] font-semibold text-[var(--color-text)]">
 No automated schedules configured yet
 </h3>
 <p className="mx-auto mt-1 max-w-md text-sm text-[var(--color-text-muted)]">
 Schedule a one-time run or a recurring schedule. Leave the topic empty and the agent discovers one automatically when the time comes.
 </p>
 <div className="mt-4">
 <Button variant="primary" size="md" icon={<Plus size={14} />} onClick={() => setOpen(true)}>
 Create First Schedule
 </Button>
 </div>
 </div>
 </Card>
 ) : (
 <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
 {schedules.map((s) => {
 const site = getWebsite(s.websiteId);
 const completed = isCompleted(s.schedule_type);
 const countdown = s.active && !completed ? formatNextRunCountdown(s.nextRun) : null;
 const recentRun = contentItems.find((c) => c.websiteId === s.websiteId);
 return (
 <Card key={s.id} className="transition hover:border-[var(--color-border-strong)]">
 <div className="flex items-start gap-3">
 {site && <WebsiteIcon website={site} />}
 <div className="min-w-0 flex-1">
 <div className="flex items-start justify-between gap-2">
 <div className="min-w-0">
 <h3 className="truncate text-[14px] font-semibold text-[var(--color-text)]">
 {s.name}
 </h3>
 <div className="mt-0.5 text-[11px] text-[var(--color-text-muted)]">
 {site?.name || "Connected Site"}
 </div>
 </div>
 <Dropdown
 trigger={
 <button
 className=" p-1.5 text-[var(--color-text-muted)] transition hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
 aria-label="Actions"
 >
 {loadingActionId === s.id ? (
 <Loader2 size={15} className="animate-spin" />
 ) : (
 <MoreHorizontal size={15} />
 )}
 </button>
 }
 >
 <DropdownItem
 icon={<Zap size={13} className="text-[var(--color-text)]" />}
 onSelect={() => handleEscalate(s.id, s.name)}
 >
 Run immediately
 </DropdownItem>
 {!completed && (
 <DropdownItem
 icon={s.active ? <Pause size={13} /> : <Play size={13} />}
 onSelect={() => handleToggle(s.id, s.name)}
 >
 {s.active ? "Pause Schedule" : "Activate Schedule"}
 </DropdownItem>
 )}
 <DropdownSeparator />
 <DropdownItem
 icon={<Trash2 size={13} />}
 danger
 onSelect={() => handleDelete(s.id, s.name)}
 >
 Delete
 </DropdownItem>
 </Dropdown>
 </div>

 <p className="mt-3 line-clamp-2 text-[12px] leading-relaxed text-[var(--color-text-muted)]">
 {s.topic ? s.topic : "Autonomous topic discovery at fire time"}
 </p>

 <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
 {s.content_format && (
 <span className="inline-flex items-center gap-1 rounded-md border border-[var(--color-accent)]/30 bg-[var(--color-accent-soft)] px-2 py-0.5 text-[10px] font-semibold text-[var(--color-accent-text)]">
 <FileText size={10} />
 {BLUEPRINTS.find((b) => b.id === s.content_format)?.name || s.content_format}
 </span>
 )}
 {s.content_options && (
 <>
 {s.content_options.enable_diagrams !== false && (
 <span className="inline-flex items-center gap-1 rounded bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] text-[var(--color-text-muted)] border border-[var(--color-border)]" title="Architecture Diagrams (SVG)">
 <Workflow size={9} className="text-emerald-500" /> Diagrams
 </span>
 )}
 {s.content_options.enable_tables !== false && (
 <span className="inline-flex items-center gap-1 rounded bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] text-[var(--color-text-muted)] border border-[var(--color-border)]" title="Comparison Tables">
 <TableIcon size={9} /> Tables
 </span>
 )}
 {s.content_options.enable_faqs !== false && (
 <span className="inline-flex items-center gap-1 rounded bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] text-[var(--color-text-muted)] border border-[var(--color-border)]" title="FAQ Module">
 <HelpCircle size={9} /> FAQ
 </span>
 )}
 {s.content_options.enable_hero_image !== false && (
 <span className="inline-flex items-center gap-1 rounded bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] text-[var(--color-text-muted)] border border-[var(--color-border)]" title="Hero Image">
 <ImageIcon size={9} /> Hero
 </span>
 )}
 </>
 )}
 </div>

 <div className="mt-4 space-y-1.5 text-[12px]">
 <div className="flex items-center gap-1.5 text-[var(--color-text-muted)]">
 {completed ? (
 <CalendarCheck size={12} className="text-[var(--color-text)]" />
 ) : s.schedule_type === "once" ? (
 <Zap size={12} className="text-[var(--color-warn)]" />
 ) : (
 <Repeat size={12} className="text-[var(--color-text-subtle)]" />
 )}
 <span>
 {completed
 ? "Completed"
 : s.schedule_type === "once"
 ? "One-time run"
 : `${s.frequency} schedule`}
 {s.time ? ` · ${s.time} UTC` : ""}
 </span>
 </div>
 {!completed && (
 <div className="flex items-center justify-between gap-1.5 text-[var(--color-text-muted)]">
 <div className="flex items-center gap-1.5">
 <Clock size={12} className="text-[var(--color-text-subtle)]" />
 <span>
 Next run: <span className="font-medium text-[var(--color-text)]">{s.nextRun}</span>
 </span>
 </div>
 {countdown && (
 <span className="rounded bg-[var(--color-accent)]/15 px-1.5 py-0.2 font-mono text-[10px] font-semibold text-[var(--color-accent-text)]">
 {countdown}
 </span>
 )}
 </div>
 )}
 {s.lastRun && (
 <div className="flex items-center justify-between gap-1.5 text-[var(--color-text-muted)]">
 <div className="flex items-center gap-1.5">
 <CheckCircle2 size={12} className="text-emerald-400" />
 <span className="text-[var(--color-text-muted)]">Last run: {s.lastRun}</span>
 </div>
 {recentRun && (
 <button
 type="button"
 onClick={() => openInspector(recentRun.id)}
 className="inline-flex cursor-pointer items-center gap-1 font-mono text-[10px] text-blue-400 hover:text-blue-300 transition"
 title="Inspect run in drawer"
 >
 <Terminal size={10} />
 <span>Inspect</span>
 </button>
 )}
 </div>
 )}
 </div>

 <div
 className="mt-4 flex items-center justify-between border-t pt-3"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div className="flex items-center gap-2">
 <StatusBadge status={completed ? "Published" : s.active ? "Active" : "Paused"}>
 {completed ? "Completed" : s.active ? "Active" : "Paused"}
 </StatusBadge>
 <Button
 variant="ghost"
 size="sm"
 icon={<Zap size={11} className="text-[var(--color-text)]" />}
 onClick={() => handleEscalate(s.id, s.name)}
 className="h-6 px-1.5 text-[11px]"
 >
 Run now
 </Button>
 </div>
 {!completed && (
 <button
 type="button"
 onClick={() => handleToggle(s.id, s.name)}
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center p-0 transition-colors duration-200 focus:outline-none",
 s.active ? "bg-[var(--color-accent)]" : "bg-[var(--color-border-strong)]"
 )}
 aria-label="Toggle schedule"
 >
 <span
 className={cn(
 "pointer-events-none absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-white  transition-transform duration-200",
 s.active ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 )}
 </div>
 </div>
 </div>
 </Card>
 );
 })}
 </div>
 )}

 {/* New Schedule Modal */}
 <Modal
 open={open}
 onClose={() => setOpen(false)}
 title="Schedule a run"
 description="Recurring cadence or one-time dispatch — with blueprints, module controls & audience."
 size="lg"
 footer={
 <>
 <Button variant="ghost" onClick={() => setOpen(false)} disabled={submitting}>
 Cancel
 </Button>
 <Button
 variant="primary"
 icon={submitting ? <Loader2 size={14} className="animate-spin" /> : <Calendar size={14} />}
 onClick={handleCreateSchedule}
 disabled={submitting}
 >
 {submitting ? "Creating..." : "Save Schedule"}
 </Button>
 </>
 }
 >
 <div className="space-y-3.5">
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Schedule Name
 </label>
 <input
 value={name}
 onChange={(e) => setName(e.target.value)}
 placeholder="e.g. Weekly Next.js Edge Briefing"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>

 {/* Schedule type: one-time vs recurring */}
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Schedule Type
 </label>
 <div className="grid grid-cols-2 gap-2">
 <button
 type="button"
 onClick={() => setScheduleType("once")}
 className={cn(
 "flex flex-col items-start gap-1 border p-3 text-left transition",
 scheduleType === "once"
 ? "border-[var(--color-border)] bg-[var(--color-bg-soft)]"
 : "hover:border-[var(--color-border-strong)]"
 )}
 style={scheduleType === "once" ? undefined : { borderColor: "var(--color-border)" }}
 >
 <span className="flex items-center gap-1.5 text-[13px] font-medium text-[var(--color-text)]">
 <Zap size={13} className="text-[var(--color-warn)]" /> One-time
 </span>
 <span className="text-[11px] leading-snug text-[var(--color-text-muted)]">
 Publish once at the set time, then stop.
 </span>
 </button>
 <button
 type="button"
 onClick={() => setScheduleType("recurring")}
 className={cn(
 "flex flex-col items-start gap-1 border p-3 text-left transition",
 scheduleType === "recurring"
 ? "border-[var(--color-border)] bg-[var(--color-bg-soft)]"
 : "hover:border-[var(--color-border-strong)]"
 )}
 style={scheduleType === "recurring" ? undefined : { borderColor: "var(--color-border)" }}
 >
 <span className="flex items-center gap-1.5 text-[13px] font-medium text-[var(--color-text)]">
 <Repeat size={13} className="text-[var(--color-text)]" /> Recurring
 </span>
 <span className="text-[11px] leading-snug text-[var(--color-text-muted)]">
 Keep uploading at every interval.
 </span>
 </button>
 </div>
 </div>

 <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Publish Time (UTC)
 </label>
 <input
 type="time"
 value={publishTime}
 onChange={(e) => setPublishTime(e.target.value)}
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 {scheduleType === "once" ? "Fires In" : "Repeat Every"}
 </label>
 {scheduleType === "once" ? (
 <select
 value={frequency}
 onChange={(e) => setFrequency(e.target.value)}
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 >
 {FREQ_OPTIONS.map((f) => (
 <option key={f.value} value={f.value}>
 In {f.label.replace(" (", " · ").replace(")", "")}
 </option>
 ))}
 </select>
 ) : (
 <select
 value={frequency}
 onChange={e => setFrequency(e.target.value)}
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 >
 {FREQ_OPTIONS.map((f) => (
 <option key={f.value} value={f.value}>
 {f.label}
 </option>
 ))}
 </select>
 )}
 </div>
 </div>

 <p className="-mt-1 text-[11px] text-[var(--color-text-subtle)]">
 {scheduleType === "once"
 ? `Publishes once, around ${publishTime} UTC after the selected delay.`
 : `Publishes every cycle at ${publishTime} UTC (first run after the next matching time).`}
 </p>

 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Target Website
 </label>
 <select
 value={selectedSiteId}
 onChange={(e) => setSelectedSiteId(e.target.value)}
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 >
 {websites.map((w) => (
 <option key={w.id} value={w.id}>
 {w.name} ({w.storage_type || "database"})
 </option>
 ))}
 </select>
 </div>

 {/* Editorial Blueprint Selector */}
 <div>
 <label className="block text-xs font-semibold text-[var(--color-text)] mb-1.5 flex items-center justify-between">
 <span>Editorial Blueprint (Structure &amp; Components)</span>
 <span className="text-[10px] text-[var(--color-text-muted)] font-normal">Format &amp; schema architecture</span>
 </label>
 <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1">
 {BLUEPRINTS.map((bp) => (
 <button
 key={bp.id}
 type="button"
 onClick={() => setSelectedBlueprint(bp.id)}
 className={cn(
 "rounded-xl border p-2.5 text-left transition-colors cursor-pointer",
 selectedBlueprint === bp.id
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)]"
 )}
 >
 <div className="flex items-center justify-between">
 <span className="text-xs font-bold text-[var(--color-text)]">{bp.name}</span>
 {selectedBlueprint === bp.id && (
 <CheckCircle2 size={12} className="text-[var(--color-accent)]" />
 )}
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] mt-0.5 line-clamp-1">
 {bp.desc}
 </div>
 </button>
 ))}
 </div>
 </div>

 {/* Content Modules & Rich Elements Toggles */}
 <div className="space-y-2 border-t pt-3" style={{ borderColor: "var(--color-border)" }}>
 <div className="flex items-center justify-between">
 <label className="text-xs font-semibold text-[var(--color-text)] flex items-center gap-1.5">
 <Sliders size={13} className="text-[var(--color-accent)]" />
 Content Modules &amp; Rich Elements
 </label>
 <span className="text-[10px] text-[var(--color-text-muted)]">
 Toggle elements ON / OFF
 </span>
 </div>

 <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
 {/* 1. Diagrams Toggle */}
 <div
 onClick={() => setEnableDiagrams(!enableDiagrams)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableDiagrams
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableDiagrams ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <Workflow size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate flex items-center gap-1">
 Architecture Diagrams
 <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-emerald-500/10 text-emerald-500 font-bold">SVG</span>
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 Pre-rendered vector images
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableDiagrams ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableDiagrams ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 2. Comparison Tables */}
 <div
 onClick={() => setEnableTables(!enableTables)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableTables
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableTables ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <TableIcon size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 Comparison Tables
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 Side-by-side data &amp; benchmarks
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableTables ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableTables ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 3. FAQ Module */}
 <div
 onClick={() => setEnableFaqs(!enableFaqs)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableFaqs
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableFaqs ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <HelpCircle size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 FAQ &amp; People Also Ask
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 High-intent Q&amp;A accordion
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableFaqs ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableFaqs ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 4. Key Takeaways Box */}
 <div
 onClick={() => setEnableTakeaways(!enableTakeaways)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableTakeaways
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableTakeaways ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <Lightbulb size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 Key Takeaways Box
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 Executive summary callout
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableTakeaways ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableTakeaways ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 5. AEO Direct Answer Snippets */}
 <div
 onClick={() => setEnableAnswerBlocks(!enableAnswerBlocks)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableAnswerBlocks
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableAnswerBlocks ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <Target size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 AEO Answer Snippets
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 40–60w answers for AI engines
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableAnswerBlocks ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableAnswerBlocks ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 6. Citations & References */}
 <div
 onClick={() => setEnableCitations(!enableCitations)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none",
 enableCitations
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableCitations ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <BookOpen size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 Verified References
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 Citations &amp; source URLs
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableCitations ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableCitations ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>

 {/* 7. Visual Assets & Hero Image */}
 <div
 onClick={() => setEnableHeroImage(!enableHeroImage)}
 className={cn(
 "flex items-center justify-between rounded-xl border p-2.5 transition-all cursor-pointer select-none sm:col-span-2",
 enableHeroImage
 ? "border-[var(--color-accent)] bg-[var(--color-accent-soft)]"
 : "border-[var(--color-border)] bg-[var(--color-bg-soft)] opacity-70 hover:opacity-100"
 )}
 >
 <div className="flex items-center gap-2 min-w-0">
 <div className={cn(
 "p-1.5 rounded-lg shrink-0",
 enableHeroImage ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-bg-elev)] text-[var(--color-text-muted)]"
 )}>
 <ImageIcon size={13} />
 </div>
 <div className="min-w-0">
 <div className="text-xs font-semibold text-[var(--color-text)] truncate">
 Visual Assets &amp; Hero Image
 </div>
 <div className="text-[10px] text-[var(--color-text-muted)] line-clamp-1">
 Generative AI diffusion banner image
 </div>
 </div>
 </div>
 <button
 type="button"
 className={cn(
 "relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none",
 enableHeroImage ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
 )}
 >
 <span
 className={cn(
 "pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out",
 enableHeroImage ? "translate-x-4" : "translate-x-0"
 )}
 />
 </button>
 </div>
 </div>
 </div>

 {/* Topic: manual or agent-discovered */}
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Topic
 </label>
 <div className="mb-2 grid grid-cols-2 gap-2">
 <button
 type="button"
 onClick={() => setTopicMode("manual")}
 className={cn(
 "flex items-center gap-1.5 border px-3 py-2 text-[12px] font-medium transition",
 topicMode === "manual"
 ? "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text)]"
 : "text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
 )}
 style={topicMode === "manual" ? undefined : { borderColor: "var(--color-border)" }}
 >
 <Edit3 size={12} /> I'll give the topic
 </button>
 <button
 type="button"
 onClick={() => setTopicMode("auto")}
 className={cn(
 "flex items-center gap-1.5 border px-3 py-2 text-[12px] font-medium transition",
 topicMode === "auto"
 ? "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text)]"
 : "text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
 )}
 style={topicMode === "auto" ? undefined : { borderColor: "var(--color-border)" }}
 >
 <Bot size={12} /> Agent finds one
 </button>
 </div>
 {topicMode === "manual" ? (
 <input
 value={topicPrompt}
 onChange={(e) => setTopicPrompt(e.target.value)}
 placeholder="e.g. State of Serverless & Edge AI Runtime in 2026"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 ) : (
 <p className=" border p-2.5 text-[11px] leading-snug text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
 When the schedule fires, the agent researches your site's niche and search demand, then picks a unique topic that doesn't duplicate existing articles — exactly like a manual run without a topic.
 </p>
 )}
 </div>

 <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Target Audience
 </label>
 <input
 value={targetAudience}
 onChange={(e) => setTargetAudience(e.target.value)}
 placeholder="e.g. Principal Cloud Architects"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
 Target Keywords (comma-separated)
 </label>
 <input
 value={keywords}
 onChange={(e) => setKeywords(e.target.value)}
 placeholder="Serverless, Edge AI, Next.js"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 </div>

 <div
 className="flex items-center justify-between border p-3"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div>
 <div className="text-[13px] font-medium text-[var(--color-text)]">
 Require Review Before Publishing
 </div>
 <div className="text-[11px] text-[var(--color-text-muted)]">
 When enabled, generated drafts pause in the Review Inbox for approval before publishing.
 </div>
 </div>
 <input
 type="checkbox"
 checked={slackReviewRequired}
 onChange={(e) => setSlackReviewRequired(e.target.checked)}
 className="h-4 w-4 accent-[var(--color-accent)]"
 />
 </div>
 </div>
 </Modal>
 </div>
 );
}
