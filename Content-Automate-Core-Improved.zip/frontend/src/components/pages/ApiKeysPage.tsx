import { useState } from "react";
import {
  Key,
  Copy,
  Check,
  Plus,
  Trash2,
  RefreshCw,
  Terminal,
  Send,
  ShieldCheck,
  Code2,
  ExternalLink,
  Radio,
} from "lucide-react";
import { Button } from "../ui";
import { Modal } from "../Modal";
import { useToast } from "../../lib/toast";

export function ApiKeysPage() {
  const { push } = useToast();

  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"curl" | "python" | "typescript">("curl");
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [testingWebhook, setTestingWebhook] = useState(false);

  const [apiKeys, setApiKeys] = useState([
    {
      id: "key-1",
      name: "Production Pipeline CI/CD",
      prefix: "cp_live_9f81a...",
      fullKey: "cp_live_9f81a7b63c2e4091abef238910dcaef",
      created: "Oct 01, 2026",
      lastUsed: "5 mins ago",
    },
    {
      id: "key-2",
      name: "Staging Webhook Ingestion",
      prefix: "cp_live_4e22c...",
      fullKey: "cp_live_4e22c8190dca38910bcefa21890123f",
      created: "Sep 20, 2026",
      lastUsed: "2 days ago",
    },
  ]);

  const copyKey = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    setTimeout(() => setCopiedKeyId(null), 2000);
    push({
      title: "API Key Copied",
      description: "Secret bearer token copied to clipboard.",
      variant: "success",
    });
  };

  const handleCreateKey = () => {
    if (!newKeyName.trim()) {
      push({ title: "Name required", description: "Provide a descriptive label for this API key.", variant: "warn" });
      return;
    }
    const rand = Math.random().toString(36).slice(2, 12);
    const full = `cp_live_${rand}${Date.now().toString(36)}`;
    const newK = {
      id: `key-${Date.now()}`,
      name: newKeyName.trim(),
      prefix: `${full.slice(0, 14)}...`,
      fullKey: full,
      created: "Just now",
      lastUsed: "Never",
    };
    setApiKeys((prev) => [newK, ...prev]);
    setCreateModalOpen(false);
    setNewKeyName("");
    push({
      title: "API Key Created",
      description: `New key "${newK.name}" generated. Keep it safe.`,
      variant: "success",
    });
  };

  const handleRevokeKey = (id: string, name: string) => {
    if (!confirm(`Revoke API key "${name}"? Applications using it will immediately fail.`)) return;
    setApiKeys((prev) => prev.filter((k) => k.id !== id));
    push({
      title: "Key Revoked",
      description: `API key "${name}" has been invalidated.`,
      variant: "warn",
    });
  };

  const handleTestWebhook = () => {
    setTestingWebhook(true);
    setTimeout(() => {
      setTestingWebhook(false);
      push({
        title: "Webhook Delivered (200 OK)",
        description: "Payload delivered to target endpoint in 42ms.",
        variant: "success",
      });
    }, 800);
  };

  const codeSnippets = {
    curl: `curl -X POST "http://localhost:8000/api/agent/run" \\
  -H "Authorization: Bearer cp_live_9f81a7b63c2e..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "topic": "LangGraph Multi-Agent Architecture",
    "website_id": "site-666356ce",
    "keywords": ["LangGraph", "FastAPI", "Next.js"],
    "auto_approve": false
  }'`,
    python: `import httpx

client = httpx.Client(
    base_url="http://localhost:8000",
    headers={"Authorization": "Bearer cp_live_9f81a7b63c2e..."}
)

response = client.post("/api/agent/run", json={
    "topic": "LangGraph Multi-Agent Architecture",
    "website_id": "site-666356ce",
    "keywords": ["LangGraph", "FastAPI"],
    "auto_approve": False
})

thread_id = response.json()["thread_id"]
print(f"Dispatched pipeline run: {thread_id}")`,
    typescript: `import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8000",
  headers: {
    Authorization: "Bearer cp_live_9f81a7b63c2e...",
    "Content-Type": "application/json",
  },
});

const res = await api.post("/api/agent/run", {
  topic: "LangGraph Multi-Agent Architecture",
  website_id: "site-666356ce",
  keywords: ["LangGraph", "FastAPI"],
  auto_approve: false,
});

console.log("Run started:", res.data.thread_id);`,
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* SaaS Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)]">
              Developer API &amp; Webhooks
            </h1>
            <span className="border border-purple-500/30 bg-purple-500/10 px-2.5 py-0.5 text-xs font-semibold text-purple-400 font-mono">
              REST &amp; SSE Endpoints
            </span>
          </div>
          <p className="mt-1.5 text-sm text-[var(--color-text-muted)]">
            Programmatically trigger autonomous pipelines, stream live token generation, and subscribe to review events.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            icon={<Plus size={14} />}
            onClick={() => setCreateModalOpen(true)}
          >
            Create API Key
          </Button>
        </div>
      </div>

      {/* API Keys Table */}
      <div className="border bg-[var(--color-bg-elev)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
        <div className="px-5 py-4 border-b flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <Key size={16} className="text-purple-400" />
            Active Secret Tokens
          </h3>
          <span className="text-xs text-[var(--color-text-muted)] font-mono">Bearer Authentication</span>
        </div>

        <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
          {apiKeys.map((key) => (
            <div key={key.id} className="p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 hover:bg-[var(--color-bg-soft)] transition">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-[var(--color-text)]">{key.name}</span>
                  <span className="font-mono text-xs text-blue-400 border border-blue-500/30 bg-blue-500/10 px-2 py-0.2">
                    {key.prefix}
                  </span>
                </div>
                <div className="mt-1 text-xs text-[var(--color-text-muted)] font-mono">
                  Created {key.created} · Last used: {key.lastUsed}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  icon={copiedKeyId === key.id ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                  onClick={() => copyKey(key.id, key.fullKey)}
                >
                  {copiedKeyId === key.id ? "Copied" : "Copy Token"}
                </Button>
                <button
                  onClick={() => handleRevokeKey(key.id, key.name)}
                  className="p-1.5 text-zinc-400 hover:text-rose-400 cursor-pointer transition"
                  title="Revoke API key"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Webhooks Subscription Card */}
      <div className="border bg-[var(--color-bg-elev)] p-5" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b pb-4 mb-4" style={{ borderColor: "var(--color-border)" }}>
          <div>
            <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
              <Radio size={16} className="text-emerald-400" />
              Outbound Webhook Dispatcher
            </h3>
            <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
              Receive instant JSON payloads when an article completes drafting, passes review, or gets published.
            </p>
          </div>

          <Button
            variant="secondary"
            size="sm"
            onClick={handleTestWebhook}
            disabled={testingWebhook}
            icon={<Send size={12} />}
          >
            {testingWebhook ? "Sending Ping..." : "Send Test Ping"}
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
              Webhook Target URL
            </label>
            <input
              type="text"
              defaultValue="https://gaming-editorial.vercel.app/api/webhooks/content"
              className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-xs font-mono text-[var(--color-text)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-[var(--color-text-muted)]">
              Signing Secret (HMAC-SHA256)
            </label>
            <input
              type="password"
              defaultValue="whsec_984102948190284091823901"
              readOnly
              className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-xs font-mono text-[var(--color-text-muted)] focus:outline-none"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t" style={{ borderColor: "var(--color-border)" }}>
          <span className="border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] text-emerald-400">
            ✓ article.published
          </span>
          <span className="border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 font-mono text-[10px] text-amber-400">
            ✓ review.required
          </span>
          <span className="border border-purple-500/30 bg-purple-500/10 px-2 py-0.5 font-mono text-[10px] text-purple-400">
            ✓ factcheck.completed
          </span>
        </div>
      </div>

      {/* Interactive Code Snippets */}
      <div className="border bg-[var(--color-bg-elev)] p-5" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex items-center justify-between border-b pb-3 mb-4" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <Code2 size={16} className="text-blue-400" />
            Quickstart Implementation Code
          </h3>

          <div className="flex items-center border p-0.5 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
            <button
              onClick={() => setActiveTab("curl")}
              className={`px-3 py-1 text-xs font-medium cursor-pointer transition ${
                activeTab === "curl" ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs" : "text-[var(--color-text-muted)]"
              }`}
            >
              cURL
            </button>
            <button
              onClick={() => setActiveTab("python")}
              className={`px-3 py-1 text-xs font-medium cursor-pointer transition ${
                activeTab === "python" ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs" : "text-[var(--color-text-muted)]"
              }`}
            >
              Python
            </button>
            <button
              onClick={() => setActiveTab("typescript")}
              className={`px-3 py-1 text-xs font-medium cursor-pointer transition ${
                activeTab === "typescript" ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs" : "text-[var(--color-text-muted)]"
              }`}
            >
              TypeScript
            </button>
          </div>
        </div>

        <pre
          className="border bg-[#080C14] p-4 text-xs font-mono text-zinc-300 overflow-x-auto leading-relaxed"
          style={{ borderColor: "var(--color-border)" }}
        >
          {codeSnippets[activeTab]}
        </pre>
      </div>

      {/* Create Key Modal */}
      <Modal
        open={createModalOpen}
        onClose={() => setCreateModalOpen(false)}
        title="Generate New API Key"
        description="Create a bearer token for automated pipeline dispatch from CI/CD, Slack bots, or CMS webhooks."
        size="md"
        footer={
          <>
            <Button variant="ghost" onClick={() => setCreateModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" icon={<Key size={14} />} onClick={handleCreateKey}>
              Create Key
            </Button>
          </>
        }
      >
        <div>
          <label className="mb-1.5 block text-xs font-medium text-[var(--color-text-muted)]">
            Key Description / Purpose
          </label>
          <input
            type="text"
            value={newKeyName}
            onChange={(e) => setNewKeyName(e.target.value)}
            placeholder="e.g. GitHub Actions Autopublisher"
            className="h-9 w-full border bg-[var(--color-bg-soft)] px-3 text-sm text-[var(--color-text)] focus:outline-none"
            style={{ borderColor: "var(--color-border)" }}
          />
        </div>
      </Modal>
    </div>
  );
}
