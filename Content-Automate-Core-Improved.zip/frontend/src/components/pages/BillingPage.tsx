import { useState } from "react";
import {
  CreditCard,
  CheckCircle2,
  Zap,
  ArrowUpRight,
  Download,
  AlertCircle,
  ShieldCheck,
  Check,
  Clock,
  Layers,
  FileText,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { useToast } from "../../lib/toast";
import { useNav } from "../../lib/nav";
import { usePipelineData } from "../../lib/dataContext";

export function BillingPage() {
  const { push } = useToast();
  const { setPage } = useNav();
  const { contentItems, websites } = usePipelineData();

  const [activePlan, setActivePlan] = useState<"starter" | "pro" | "enterprise">("pro");
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("annual");

  const publishedCount = contentItems.filter((c) => c.status === "Published").length;
  const articlesLimit = activePlan === "starter" ? 15 : activePlan === "pro" ? 60 : 500;
  const sitesLimit = activePlan === "starter" ? 1 : activePlan === "pro" ? 5 : 50;

  const invoices = [
    { id: "INV-2026-009", date: "Oct 01, 2026", amount: "$119.00", status: "Paid", pdf: "invoice-009.pdf" },
    { id: "INV-2026-008", date: "Sep 01, 2026", amount: "$119.00", status: "Paid", pdf: "invoice-008.pdf" },
    { id: "INV-2026-007", date: "Aug 01, 2026", amount: "$119.00", status: "Paid", pdf: "invoice-007.pdf" },
    { id: "INV-2026-006", date: "Jul 01, 2026", amount: "$119.00", status: "Paid", pdf: "invoice-006.pdf" },
  ];

  const handlePlanChange = (newPlan: "starter" | "pro" | "enterprise") => {
    setActivePlan(newPlan);
    push({
      title: "Plan Updated",
      description: `Your workspace subscription has been switched to ${newPlan.toUpperCase()}.`,
      variant: "success",
    });
  };

  const handleDownloadInvoice = (invId: string) => {
    push({
      title: "Downloading Invoice",
      description: `Receipt for ${invId} generated.`,
      variant: "info",
    });
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      {/* SaaS Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)]">
              Subscription &amp; Usage
            </h1>
            <span className="border border-blue-500/30 bg-blue-500/10 px-2.5 py-0.5 text-xs font-semibold text-blue-400 font-mono">
              Pro Growth Tier
            </span>
          </div>
          <p className="mt-1.5 text-sm text-[var(--color-text-muted)]">
            Manage your autonomous publishing quota, multi-website targets, and enterprise billing invoices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setPage("landing")}
          >
            View Public Pricing
          </Button>
        </div>
      </div>

      {/* Active Subscription Summary Card */}
      <div className="border bg-[var(--color-bg-elev)] p-5 sm:p-6" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b pb-5 mb-5" style={{ borderColor: "var(--color-border)" }}>
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center border border-blue-500/30 bg-blue-500/10 text-blue-400">
              <Zap size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-[var(--color-text)]">
                  {activePlan === "starter" ? "Starter Plan" : activePlan === "pro" ? "Pro Growth Plan" : "Enterprise Bureau"}
                </h3>
                <span className="border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.2 font-mono text-[10px] font-bold text-emerald-400">
                  Active Subscription
                </span>
              </div>
              <div className="mt-1 text-xs text-[var(--color-text-muted)] font-mono">
                Renews automatically on <span className="text-[var(--color-text)] font-semibold">November 1, 2026</span> via Visa ending in 4242.
              </div>
            </div>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono text-[var(--color-text)]">
              {billingCycle === "annual" ? (activePlan === "starter" ? "$39" : activePlan === "pro" ? "$119" : "$399") : (activePlan === "starter" ? "$49" : activePlan === "pro" ? "$149" : "$499")}
            </span>
            <span className="text-xs text-[var(--color-text-muted)] font-mono">/ month</span>
          </div>
        </div>

        {/* Real-Time Quota Usage Gauges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Articles Published */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Articles Published</span>
              <span className="font-mono font-bold text-[var(--color-text)]">
                {publishedCount} / {articlesLimit}
              </span>
            </div>
            <div className="h-1.5 w-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-blue-500 transition-all duration-300"
                style={{ width: `${Math.min(Math.round((publishedCount / articlesLimit) * 100), 100)}%` }}
              />
            </div>
            <div className="mt-2 text-[10px] text-[var(--color-text-subtle)] font-mono">
              {Math.max(articlesLimit - publishedCount, 0)} articles remaining this billing cycle
            </div>
          </div>

          {/* 2. Fact Check Queries */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Fact-Check NLI Queries</span>
              <span className="font-mono font-bold text-emerald-400">
                412 / 1,000
              </span>
            </div>
            <div className="h-1.5 w-full bg-white/10 overflow-hidden">
              <div className="h-full bg-emerald-500" style={{ width: "41.2%" }} />
            </div>
            <div className="mt-2 text-[10px] text-[var(--color-text-subtle)] font-mono">
              588 empirical queries remaining
            </div>
          </div>

          {/* 3. AI Image Diffusion */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Diffusion Image Tensors</span>
              <span className="font-mono font-bold text-purple-400">
                32 / 100
              </span>
            </div>
            <div className="h-1.5 w-full bg-white/10 overflow-hidden">
              <div className="h-full bg-purple-500" style={{ width: "32%" }} />
            </div>
            <div className="mt-2 text-[10px] text-[var(--color-text-subtle)] font-mono">
              Cloudflare Flux + Gemini REST
            </div>
          </div>

          {/* 4. Target Websites */}
          <div className="border bg-[var(--color-bg-soft)] p-3.5" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-medium text-[var(--color-text-muted)]">Connected Websites</span>
              <span className="font-mono font-bold text-[var(--color-text)]">
                {websites.length} / {sitesLimit}
              </span>
            </div>
            <div className="h-1.5 w-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-blue-400"
                style={{ width: `${Math.min(Math.round((websites.length / sitesLimit) * 100), 100)}%` }}
              />
            </div>
            <div className="mt-2 text-[10px] text-[var(--color-text-subtle)] font-mono">
              Rule A 0s Upstash / DB active
            </div>
          </div>
        </div>
      </div>

      {/* Plan Switcher Grid */}
      <div className="border bg-[var(--color-bg-elev)] p-5 sm:p-6" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b pb-4 mb-6" style={{ borderColor: "var(--color-border)" }}>
          <div>
            <h3 className="text-base font-bold text-[var(--color-text)]">
              Available SaaS Subscription Tiers
            </h3>
            <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
              Upgrade or downgrade instantly. All changes prorated automatically.
            </p>
          </div>

          <div className="flex items-center gap-1 border p-1 bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-3 py-1 text-xs font-medium cursor-pointer transition ${
                billingCycle === "monthly" ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs" : "text-[var(--color-text-muted)]"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle("annual")}
              className={`px-3 py-1 text-xs font-medium cursor-pointer transition flex items-center gap-1 ${
                billingCycle === "annual" ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs" : "text-[var(--color-text-muted)]"
              }`}
            >
              <span>Annual</span>
              <span className="text-[9px] font-mono text-emerald-400 font-bold">20% off</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Starter */}
          <div className={`border p-5 flex flex-col justify-between ${activePlan === "starter" ? "border-blue-500 bg-blue-500/5" : "border-[var(--color-border)] bg-[var(--color-bg-soft)]"}`}>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[var(--color-text)]">Starter</span>
                {activePlan === "starter" && <span className="text-[10px] font-mono text-blue-400 font-bold">CURRENT</span>}
              </div>
              <div className="mt-3 text-2xl font-mono font-bold text-[var(--color-text)]">
                {billingCycle === "annual" ? "$39" : "$49"}<span className="text-xs text-[var(--color-text-muted)] font-normal"> / mo</span>
              </div>
              <ul className="mt-4 space-y-2 text-xs text-[var(--color-text-muted)]">
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> 15 Articles / month</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> 1 Target Website</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> A4 Fact Verification</li>
              </ul>
            </div>
            <button
              onClick={() => handlePlanChange("starter")}
              disabled={activePlan === "starter"}
              className="mt-6 w-full border border-[var(--color-border)] py-2 text-xs font-semibold text-[var(--color-text)] hover:bg-[var(--color-bg-elev)] transition cursor-pointer disabled:opacity-50"
            >
              {activePlan === "starter" ? "Current Plan" : "Switch to Starter"}
            </button>
          </div>

          {/* Pro */}
          <div className={`border-2 p-5 flex flex-col justify-between ${activePlan === "pro" ? "border-blue-500 bg-blue-500/10 shadow-lg" : "border-[var(--color-border)] bg-[var(--color-bg-soft)]"}`}>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[var(--color-text)]">Pro Growth</span>
                {activePlan === "pro" && <span className="text-[10px] font-mono text-blue-400 font-bold">CURRENT PLAN</span>}
              </div>
              <div className="mt-3 text-2xl font-mono font-bold text-blue-400">
                {billingCycle === "annual" ? "$119" : "$149"}<span className="text-xs text-[var(--color-text-muted)] font-normal"> / mo</span>
              </div>
              <ul className="mt-4 space-y-2 text-xs text-[var(--color-text)]">
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> 60 Articles / month</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> 5 Target Websites</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> Deep NLI Entailment Subgraph</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> Multi-CMS Gutenberg Block Renderer</li>
              </ul>
            </div>
            <button
              onClick={() => handlePlanChange("pro")}
              disabled={activePlan === "pro"}
              className="mt-6 w-full border border-blue-400 bg-blue-600 py-2 text-xs font-semibold text-white hover:bg-blue-500 transition cursor-pointer disabled:opacity-50"
            >
              {activePlan === "pro" ? "Current Active Plan" : "Upgrade to Pro"}
            </button>
          </div>

          {/* Enterprise */}
          <div className={`border p-5 flex flex-col justify-between ${activePlan === "enterprise" ? "border-blue-500 bg-blue-500/5" : "border-[var(--color-border)] bg-[var(--color-bg-soft)]"}`}>
            <div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[var(--color-text)]">Enterprise Bureau</span>
                {activePlan === "enterprise" && <span className="text-[10px] font-mono text-blue-400 font-bold">CURRENT</span>}
              </div>
              <div className="mt-3 text-2xl font-mono font-bold text-[var(--color-text)]">
                {billingCycle === "annual" ? "$399" : "$499"}<span className="text-xs text-[var(--color-text-muted)] font-normal"> / mo</span>
              </div>
              <ul className="mt-4 space-y-2 text-xs text-[var(--color-text-muted)]">
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> Unlimited Articles</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> Unlimited Target Websites</li>
                <li className="flex items-center gap-2"><Check size={13} className="text-emerald-400" /> Developer API &amp; Webhooks</li>
              </ul>
            </div>
            <button
              onClick={() => handlePlanChange("enterprise")}
              disabled={activePlan === "enterprise"}
              className="mt-6 w-full border border-[var(--color-border)] py-2 text-xs font-semibold text-[var(--color-text)] hover:bg-[var(--color-bg-elev)] transition cursor-pointer disabled:opacity-50"
            >
              {activePlan === "enterprise" ? "Current Plan" : "Switch to Enterprise"}
            </button>
          </div>
        </div>
      </div>

      {/* Payment Method & Invoices Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payment Method */}
        <div className="border bg-[var(--color-bg-elev)] p-5" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <CreditCard size={15} className="text-blue-400" />
            Payment Method
          </h3>
          <div className="mt-4 border bg-[var(--color-bg-soft)] p-4 space-y-3" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-[var(--color-text)]">Visa ending in 4242</span>
              <span className="text-[10px] font-mono text-zinc-400">Expires 08/29</span>
            </div>
            <div className="text-xs text-[var(--color-text-muted)]">
              Invoiced to: <span className="text-[var(--color-text)] font-semibold">billing@contentops.io</span>
            </div>
          </div>
          <button
            onClick={() => push({ title: "Stripe Portal", description: "Redirecting to customer billing portal...", variant: "info" })}
            className="mt-4 w-full border border-[var(--color-border)] py-2 text-xs font-semibold text-[var(--color-text)] hover:bg-[var(--color-bg-soft)] transition cursor-pointer"
          >
            Update Payment Method
          </button>
        </div>

        {/* Invoice Download Table */}
        <div className="border bg-[var(--color-bg-elev)] p-5 lg:col-span-2 overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
          <h3 className="text-sm font-bold text-[var(--color-text)] flex items-center gap-2">
            <FileText size={15} className="text-emerald-400" />
            Billing Invoices &amp; Receipts
          </h3>
          <div className="mt-4 divide-y border" style={{ borderColor: "var(--color-border)" }}>
            {invoices.map((inv) => (
              <div key={inv.id} className="flex items-center justify-between p-3 text-xs">
                <div>
                  <span className="font-mono font-semibold text-[var(--color-text)]">{inv.id}</span>
                  <span className="text-[var(--color-text-muted)] ml-2">· {inv.date}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono font-bold text-[var(--color-text)]">{inv.amount}</span>
                  <span className="border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.2 font-mono text-[9px] font-bold text-emerald-400">
                    {inv.status}
                  </span>
                  <button
                    onClick={() => handleDownloadInvoice(inv.id)}
                    className="p-1 text-[var(--color-text-muted)] hover:text-white cursor-pointer"
                    title="Download invoice PDF"
                  >
                    <Download size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
