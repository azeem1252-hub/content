import { useState } from "react";
import {
  Plus,
  Globe,
  MoreHorizontal,
  ExternalLink,
  Search,
  CheckCircle2,
  Copy,
  Code2,
  Send,
  Loader2,
  Trash2,
  ShieldCheck,
  Bot,
  Terminal,
  Check,
  RefreshCw,
  ArrowRight,
  Key,
  Server,
  Radio,
  FileCode,
  Layers,
  Database,
  Cloud,
  AlertTriangle,
  Zap,
  HelpCircle,
  GitBranch,
} from "lucide-react";
import { Card } from "../Card";
import { Button } from "../ui";
import { StatusBadge } from "../StatusBadge";
import { Dropdown, DropdownItem, DropdownSeparator } from "../Dropdown";
import { Modal } from "../Modal";
import { WebsiteIcon } from "../WebsiteIcon";
import { useToast } from "../../lib/toast";
import { usePipelineData } from "../../lib/dataContext";
import { api } from "../../lib/api";

export function WebsitesPage() {
 const {
 websites,
 createWebsiteItem,
 updateWebsiteItem,
 deleteWebsiteItem,
 testWebsiteConnection,
 testWebsiteSlackCard,
 } = usePipelineData();

  const [connectOpen, setConnectOpen] = useState(false);
  const [editingWebsiteId, setEditingWebsiteId] = useState<string | null>(null);
  const [snippetOpen, setSnippetOpen] = useState(false);
  const [snippetTab, setSnippetTab] = useState<"storage" | "prompt" | "code" | "lib" | "troubleshoot" | "curl">("storage");
  const [activeArch, setActiveArch] = useState<"serverless" | "vps_nodb" | "static_frontend" | "database">("serverless");
  const [snippetData, setSnippetData] = useState<{
    app_router_path?: string;
    code?: string;
    snippet?: string;
    lib_posts?: string;
    agent_prompt?: string;
    curl_command?: string;
    architectures?: Record<string, any>;
  }>({});
  const [promptSecretToken, setPromptSecretToken] = useState("");
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);
  const [copiedGetCurl, setCopiedGetCurl] = useState(false);
  const [copiedPostCurl, setCopiedPostCurl] = useState(false);
  const [copiedEnv, setCopiedEnv] = useState(false);
  const [copiedLibCode, setCopiedLibCode] = useState(false);
  const [curlHost, setCurlHost] = useState("http://localhost:3000/api/posts");
  const [testingInForm, setTestingInForm] = useState(false);

  // Storage Engine states
  const [storageEngine, setStorageEngine] = useState<"upstash" | "github" | "disk">("upstash");
  const [upstashUrl, setUpstashUrl] = useState("");
  const [upstashToken, setUpstashToken] = useState("");
  const [githubToken, setGithubToken] = useState("");
  const [githubRepo, setGithubRepo] = useState("");
  const [githubBranch, setGithubBranch] = useState("main");
  const [testingStorage, setTestingStorage] = useState(false);
  const [storageTestResult, setStorageTestResult] = useState<{ success: boolean; message: string; latency_ms?: number } | null>(null);

  // Publishing Governance Modes (Mode 1 / Mode 2 / Mode 3)
  const [publishMode, setPublishMode] = useState<"mode_1" | "mode_2" | "mode_3">("mode_1");
  const [mode2Threshold, setMode2Threshold] = useState<number>(85);
  const [mode3Signoff, setMode3Signoff] = useState<boolean>(false);

  // Troubleshooting Diagnostics state
  const [troubleshootSearch, setTroubleshootSearch] = useState("");
  const [troubleshootFilter, setTroubleshootFilter] = useState<"all" | "serverless" | "multisite" | "images" | "auth">("all");
  const [copiedTroubleshootId, setCopiedTroubleshootId] = useState<string | null>(null);
  const [showArchitectureGuide, setShowArchitectureGuide] = useState(true);

  const copyTroubleshootSnippet = (id: string, text: string, title: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTroubleshootId(id);
    setTimeout(() => setCopiedTroubleshootId(null), 2000);
    push({
      title: `${title} copied`,
      description: "Code copied to clipboard ready to paste into your project.",
      variant: "success",
    });
  };

  const [search, setSearch] = useState("");
  const [loadingActionId, setLoadingActionId] = useState<string | null>(null);
  const [pingResults, setPingResults] = useState<Record<string, { success: boolean; latency_ms?: number; message?: string; status?: string }>>({});
  const [pingingAll, setPingingAll] = useState(false);

  // Form states for connect / edit website
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [secretToken, setSecretToken] = useState("");
  const [slackChannel, setSlackChannel] = useState("");
  const [slackWebhook, setSlackWebhook] = useState("");
  const [siteSlackEnabled, setSiteSlackEnabled] = useState(true);
  const [isDefault, setIsDefault] = useState(false);
  const [siteStorageType, setSiteStorageType] = useState<"auto" | "database" | "git">("auto");
  const [siteGithubRepo, setSiteGithubRepo] = useState("");
  const [siteGithubBranch, setSiteGithubBranch] = useState("main");
  const [siteGithubToken, setSiteGithubToken] = useState("");
  const [savedSiteGithubTokenConfigured, setSavedSiteGithubTokenConfigured] = useState(false);
  const [savedSiteSecretTokenConfigured, setSavedSiteSecretTokenConfigured] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const openCreateModal = () => {
    setEditingWebsiteId(null);
    setName("");
    setUrl("");
    setSecretToken("");
    setSlackChannel("");
    setSlackWebhook("");
    setSiteSlackEnabled(true);
    setIsDefault(websites.length === 0);
    setSiteStorageType("auto");
    setSiteGithubRepo("");
    setSiteGithubBranch("main");
    setSiteGithubToken("");
    setSavedSiteGithubTokenConfigured(false);
    setSavedSiteSecretTokenConfigured(false);
    setPublishMode("mode_1");
    setMode2Threshold(85);
    setMode3Signoff(false);
    setConnectOpen(true);
  };

  const openEditModal = (site: (typeof websites)[number]) => {
    setEditingWebsiteId(site.id);
    setName(site.name);
    setUrl(site.url);
    setSecretToken(site.secret_token || "");
    setSlackChannel(site.slack_channel_id || "");
    setSlackWebhook(site.slack_webhook_url || "");
    setSiteSlackEnabled(site.slack_enabled !== false);
    setIsDefault(Boolean(site.is_default));
    setSiteStorageType(site.storage_type === "database" || site.storage_type === "git" ? site.storage_type : "auto");
    setSiteGithubRepo(site.github_repo || "");
    setSiteGithubBranch(site.github_branch || "main");
    setSiteGithubToken("");
    setSavedSiteGithubTokenConfigured(Boolean(site.has_github_token));
    setSavedSiteSecretTokenConfigured(Boolean(site.has_secret_token));
    setPublishMode("mode_1");
    setMode2Threshold(85);
    setMode3Signoff(false);
    api.getPublishModes(site.id).then((res) => {
      if (res?.current_mode) setPublishMode(res.current_mode);
    }).catch(() => {});
    setConnectOpen(true);
  };

 const { push } = useToast();

 const filtered = websites.filter(
 (w) =>
 !search ||
 w.name.toLowerCase().includes(search.toLowerCase()) ||
 w.url.toLowerCase().includes(search.toLowerCase())
 );

 const handleConnect = async () => {
 if (!name.trim() || !url.trim()) {
 push({
 title: "Required fields",
 description: "Please provide both Website Name and URL.",
 variant: "warn",
 });
 return;
 }

 if (siteStorageType === "git" && (!siteGithubRepo.trim() || (!siteGithubToken.trim() && !savedSiteGithubTokenConfigured))) {
 push({
 title: "Git settings required",
 description: "Git-backed publishing needs this website's repository and GitHub token.",
 variant: "warn",
 });
 return;
 }

 setSubmitting(true);
 try {
 const payload = {
 name: name.trim(),
 url: url.trim(),
 secret_token: secretToken.trim() || undefined,
 slack_channel_id: slackChannel.trim() || undefined,
 slack_webhook_url: slackWebhook.trim() || undefined,
 slack_enabled: siteSlackEnabled,
 is_default: isDefault,
 github_repo: siteGithubRepo.trim() || undefined,
 github_branch: siteGithubBranch.trim() || "main",
 github_token: siteGithubToken.trim() || undefined,
 storage_type: siteStorageType,
 };
 let savedSite: any = null;
 if (editingWebsiteId) savedSite = await updateWebsiteItem(editingWebsiteId, payload);
 else savedSite = await createWebsiteItem(payload);

 const targetSiteId = editingWebsiteId || savedSite?.id;
 if (targetSiteId) {
   try {
     await api.configurePublishMode({
       website_id: targetSiteId,
       mode: publishMode,
       mode_2_settings: { min_fact_check_score: mode2Threshold },
       mode_3_settings: { signoff: mode3Signoff },
     });
   } catch (modeErr) {
     console.warn("Could not save publish mode:", modeErr);
   }
 }

 push({
 title: editingWebsiteId ? "Website updated" : "Website connected",
 description: `“${name}” is now ready for autonomous runs with ${publishMode.toUpperCase().replace("_", " ")}.`,
 variant: "success",
 });
 setConnectOpen(false);
 setName("");
 setUrl("");
 setSecretToken("");
 setSlackChannel("");
 setSlackWebhook("");
 setSiteSlackEnabled(true);
 setSiteStorageType("auto");
 setSiteGithubRepo("");
 setSiteGithubBranch("main");
 setSiteGithubToken("");
 setSavedSiteGithubTokenConfigured(false);
 setSavedSiteSecretTokenConfigured(false);
 setEditingWebsiteId(null);
 } catch (err: any) {
 push({
 title: "Connection failed",
 description: err.message || "Failed to register website.",
 variant: "danger",
 });
 } finally {
 setSubmitting(false);
 }
 };

 const handleTestConnection = async (id: string, siteName: string) => {
 setLoadingActionId(id);
 try {
 const res = await testWebsiteConnection(id);
 setPingResults((prev) => ({
   ...prev,
   [id]: {
     success: Boolean(res?.success),
     latency_ms: res?.latency_ms,
     message: res?.message,
     status: res?.status,
   },
 }));
 if (res?.success) {
 push({
 title: "Connection Healthy",
 description: res.message || `${siteName} responded in ${res.latency_ms}ms.`,
 variant: "success",
 });
 } else if (res?.status === "auth_error") {
 push({
 title: "Authentication failed",
 description: res.message || `${siteName} rejected the secret token.`,
 variant: "danger",
 });
 } else {
 push({
 title: "Connection problem",
 description: res?.message || `${siteName} returned status ${res?.status || "unknown"}.`,
 variant: "warn",
 });
 }
 } catch (err: any) {
 setPingResults((prev) => ({
   ...prev,
   [id]: {
     success: false,
     message: err.message || "Ping failed",
     status: "network_error",
   },
 }));
 push({
 title: "Ping failed",
 description: err.message || "Could not reach target route.",
 variant: "danger",
 });
 } finally {
 setLoadingActionId(null);
 }
 };

 const handlePingAllSites = async () => {
 if (websites.length === 0) return;
 setPingingAll(true);
 try {
 const results = await Promise.allSettled(
   websites.map(async (w) => {
     const res = await testWebsiteConnection(w.id);
     return { id: w.id, name: w.name, res };
   })
 );
 let successCount = 0;
 let totalLatency = 0;
 let latencyCount = 0;
 const nextMap: Record<string, any> = {};

 results.forEach((r) => {
   if (r.status === "fulfilled") {
     const { id, res } = r.value;
     const ok = Boolean(res?.success);
     nextMap[id] = {
       success: ok,
       latency_ms: res?.latency_ms,
       message: res?.message,
       status: res?.status,
     };
     if (ok) {
       successCount++;
       if (res?.latency_ms) {
         totalLatency += res.latency_ms;
         latencyCount++;
       }
     }
   }
 });

 setPingResults((prev) => ({ ...prev, ...nextMap }));
 const avgLatency = latencyCount > 0 ? Math.round(totalLatency / latencyCount) : 0;
 push({
   title: `Health Check: ${successCount}/${websites.length} Online`,
   description:
     successCount === websites.length
       ? `All targets responded healthy over HTTP. Average latency: ${avgLatency}ms.`
       : `${successCount} healthy, ${websites.length - successCount} had connection issues. Check tokens and endpoints.`,
   variant: successCount === websites.length ? "success" : "warn",
 });
 } catch (err: any) {
 push({
   title: "Ping All Error",
   description: err.message || "Failed to execute bulk health check.",
   variant: "danger",
 });
 } finally {
 setPingingAll(false);
 }
 };

 const handleTestSlack = async (id: string, siteName: string) => {
 setLoadingActionId(id);
 try {
 await testWebsiteSlackCard(id);
 push({
 title: "Slack Test Card Sent",
 description: `Test review card sent for ${siteName}.`,
 variant: "success",
 });
 } catch (err: any) {
 push({
 title: "Slack test failed",
 description: err.message || "Could not send Slack card.",
 variant: "danger",
 });
 } finally {
 setLoadingActionId(null);
 }
 };

 const handleTestCrawlerAccess = async (site: any) => {
 setLoadingActionId(site.id);
 try {
 const res = await api.checkSiteCrawlerAccess({ url: site.url });
 if (res?.evaluation) {
 const ev = res.evaluation;
 const passedCount = ev.retrieval_bots_allowed_count ?? 0;
 const totalCount = ev.retrieval_bots_total ?? 3;
 push({
 title: passedCount === totalCount ? "AI Crawlers Permitted ✓" : "Crawler Permissions Warning",
 description: `${passedCount}/${totalCount} AI answer engines (PerplexityBot, Googlebot, OAI-SearchBot) can access ${site.name}. SSR: ${ev.is_server_rendered ? "Verified" : "Client-Only"}.`,
 variant: passedCount > 0 ? "success" : "warn",
 });
 }
 } catch (err: any) {
 push({
 title: "Crawler Check Error",
 description: err.message || "Failed to inspect robots.txt.",
 variant: "danger",
 });
 } finally {
 setLoadingActionId(null);
 }
 };

 const generateRandomToken = () => {
 const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
 let token = "nxt_sec_";
 // Use the browser CSPRNG (Math.random is not cryptographically secure)
 const bytes = new Uint8Array(32);
 crypto.getRandomValues(bytes);
 for (let i = 0; i < 32; i++) {
 token += chars.charAt(bytes[i] % chars.length);
 }
 return token;
 };

 const getEffectiveToken = (overrideToken?: string) => {    // Never fall back to a hard-coded token: an empty token simply omits the auth header.
    return overrideToken || promptSecretToken || secretToken || "";
 };
  const getFormattedPrompt = (overrideToken?: string) => {
    const token = getEffectiveToken(overrideToken);
    const endpoint = (curlHost && curlHost.trim()) || "http://localhost:3000/api/posts";
    const siteUrl = endpoint.replace(/\/api\/posts\/?$/, "") || "http://localhost:3000";
    const raw = snippetData.agent_prompt || "";
    if (!raw) {
      return `You are an expert full-stack Next.js engineer working INSIDE this target repository.
Your mission is to connect this website to the autonomous Content Pipeline Agent so it can automatically receive, persist, and showcase published articles with high-resolution hero images.

Follow all phases IN STRICT NUMERICAL ORDER. Every step is mandatory.

================================================================================
PHASE 0 — CODEBASE RECONNAISSANCE & ARCHITECTURE AUDIT
================================================================================
Before modifying or creating any files, inspect the codebase:

1. Language & Type System:
   - Check if \`tsconfig.json\` exists.
   - If TypeScript is present: use \`.ts\` / \`.tsx\` extensions with types.
   - If JavaScript only (no TypeScript): omit type annotations (\`interface\`, \`: string\`, \`as any\`) and use \`.js\` / \`.jsx\` extensions, OR install \`typescript @types/node @types/react -D\` if preferred.

2. Next.js Routing Architecture:
   - App Router (\`app/\` or \`src/app/\`): Create routes in \`app/api/posts/route.ts\` (or \`.js\`).
   - Pages Router (\`pages/\` or \`src/pages/\`): Create API route in \`pages/api/posts.ts\` (or \`.js\`).

3. Existing UI & Display Components Audit (CRITICAL — DO NOT SKIP):
   - Locate the Homepage / Feed: e.g. \`app/page.tsx\`, \`components/BlogHomeClient.*\`, \`components/Feed.*\`, \`components/RecipeList.*\`.
   - Locate Card components: e.g. \`PostCard\`, \`RecipeCard\`, \`BlogCard\`, \`ArticleCard\`. Note what image property they use (\`coverImage\`, \`hero_image_url\`, \`image\`).
   - Locate Article Detail / Modal views: e.g. \`RecipeDetailModal\`, \`PostModal\`, \`ArticleView\`, \`[slug]/page.tsx\`.
   - Inspect how existing components render article text: If any component displays text via \`<p>{post.content}</p>\` or \`<p>{recipe.story}</p>\`, you MUST upgrade it to parse rich HTML/Markdown.

4. Existing Data Storage Audit:
   - Check \`package.json\` for Prisma, Drizzle, Supabase, Mongoose, or SQLite.
   - If a database is present, use OPTION A (direct DB upsert in 0 seconds with ZERO git dependencies).
   - If serverless without DB, use OPTION B (Upstash Redis REST) or OPTION C (Git-backed).
   - If local/VPS/Docker, use OPTION D (Local disk writes).

================================================================================
PHASE 1 — INGESTION API ROUTE HANDLER (DROP-IN)
================================================================================
Create or replace \`src/app/api/posts/route.ts\` (or \`app/api/posts/route.ts\` or \`.js\`):
- Timing-safe Bearer token authentication (\`AGENT_SECRET_TOKEN\`).
- Base64 hero image decoding directly into \`<project_root>/public/uploads/<filename>\`.
- Remote image download fallback (fetches and saves into \`public/uploads/\`).
- Auto-aliasing of \`coverImage\`, \`image\`, \`hero_image_url\`, \`featuredImage\`, \`thumbnail\`, \`story\`, \`content\`, \`tags\`, and \`category\`.
- Persistence across Local Disk (\`content/posts/*.json\`), Upstash Redis KV, GitHub API Cloud Commit, or custom database.
- Next.js cache revalidation (\`revalidatePath\`).
- CORS OPTIONS handler & GET diagnostic health check.

================================================================================
PHASE 2 — UNIVERSAL POSTS STORAGE READER
================================================================================
Create or replace \`src/lib/posts.ts\` (or \`lib/posts.js\`):
- Exports \`getAllPostsAsync()\` and \`getPostBySlugAsync(slug)\`.
- Normalizes posts so \`hero_image_url\`, \`coverImage\`, \`image\`, and \`story\` are never undefined.

================================================================================
PHASE 3 — ENVIRONMENT & STORAGE CONFIGURATION
================================================================================
Create or update \`.env.local\`:
AGENT_SECRET_TOKEN=${token}

Select ONE storage engine:
- OPTION A: Database (Prisma/Supabase/Drizzle/SQL) -> Direct DB upsert in /api/posts/route.ts (Zero Git dependency!).
- OPTION B: Serverless (Upstash Redis) -> Add \`UPSTASH_REDIS_REST_URL\` & \`TOKEN\` (Zero Git dependency!).
- OPTION C: Pure Serverless Git-Backed -> Add \`GITHUB_TOKEN\`, \`GITHUB_REPO\`, \`GITHUB_BRANCH\`.
- OPTION D: Local Disk / VPS / Docker -> Direct writes to \`content/posts/\` and \`public/uploads/\`.

================================================================================
PHASE 4 — HERO IMAGE ROUTING & NEXT.JS CONFIG (MANDATORY)
================================================================================
1. Directory Creation: Ensure \`public/uploads/\` directory exists.
2. In \`next.config.ts\` / \`next.config.mjs\` / \`next.config.js\`:
   Merge remotePatterns (allow http & https) and rewrites from \`/static/uploads/:path*\` to \`/uploads/:path*\`.

================================================================================
PHASE 5 — WIRE THE FRONTEND & EXISTING COMPONENTS (ANTI-SLOP PROSE RULE)
================================================================================
1. Integrate with the Existing Homepage / Feed (MANDATORY):
   - Open \`app/page.tsx\` (or homepage component). Call \`getAllPostsAsync()\` and merge published articles at the top of the feed!
   - In all card components: \`src={post.coverImage || post.hero_image_url || post.image || '/images/default.jpg'}\`.

2. STRICT PROSE & HEADING DEDUPLICATION RULE (Eliminate Mashed Text & Raw Syntax):
   - In ANY modal, drawer, card, or post detail view: NEVER dump raw Markdown inside \`<p>{post.content}</p>\`! Standard \`<p>\` tags print raw \`#\` and \`**\` symbols directly on screen.
   - TITLE DEDUPLICATION: If your template already renders \`{post.title}\` in a header (e.g. \`<h1>{post.title}</h1>\`), strip the leading \`# Heading\` or \`# **Heading**\` or \`<h1>...</h1>\` from the body so the title is not printed twice!
   - PARAGRAPH ARRAYS: If your data model uses \`paragraphs: string[]\`, do NOT do \`post.content.split("\\n\\n")\` directly without stripping the leading \`# Title\` line first.
   - Always render rich parsed HTML: \`dangerouslySetInnerHTML={{ __html: post.html || marked.parse(post.content) }}\` inside an element styled with \`.prose\`.

3. Ensure Typography Styles Exist in \`globals.css\` (.prose rules for headings, tables, blockquotes, lists).

4. Dedicated Post Route (\`src/app/posts/[slug]/page.tsx\`):
   Render hero image, single \`<h1>{title}</h1>\`, author, date, and rich \`.prose\` body.

================================================================================
PHASE 6 — 6-POINT END-TO-END VERIFICATION (MANDATORY CHECKS)
================================================================================
1. Build Check: \`npm run build\` exits with 0 errors.
2. Health Check: \`curl ${endpoint}\` returns \`{"status":"ready",...}\`.
3. Authenticated Publishing Test (with Hero Image):
   \`curl -X POST "${endpoint}" -H "Content-Type: application/json" -H "Authorization: Bearer ${token}" -d '{"title":"Pipeline Verification Article","slug":"pipeline-test","content":"# Setup Verified\\\\n\\\\nYour Next.js site is successfully connected to the autonomous Content Pipeline Agent with rich typography and image delivery.","hero_image_url":"/uploads/pipeline-test.jpg","hero_image_base64":"iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==","tags":["Verification"],"author":"Dispatch Bureau"}'\`
4. Image Verification: Confirm \`public/uploads/pipeline-test.jpg\` exists and returns HTTP 200 at \`${siteUrl}/uploads/pipeline-test.jpg\`.
5. Article Page: Open \`${siteUrl}/posts/pipeline-test\` — verify single title, hero image, rich typography, 0 raw markdown artifacts.
6. Homepage Feed: Open \`${siteUrl}\` — verify the test article appears in the feed/cards and opens properly in the modal/detail view.

================================================================================
PHASE 7 — CLEANUP VERIFICATION TEST ARTICLE (CLEAN PRODUCTION STATE)
================================================================================
MANDATORY FINAL STEP: Never leave dummy verification test articles lingering on a live website!
Once Phase 6 verification passes, immediately remove the \`pipeline-test\` article so the website is pristine:

1. Direct File Deletion (Local Disk / Git-backed):
   - Linux / macOS: rm -f content/posts/pipeline-test.json content/posts/pipeline-test.mdx public/uploads/pipeline-test.jpg
   - Windows PowerShell: Remove-Item -Path "content\\\\posts\\\\pipeline-test.json", "content\\\\posts\\\\pipeline-test.mdx", "public\\\\uploads\\\\pipeline-test.jpg" -ErrorAction SilentlyContinue
2. Authenticated DELETE API Route:
   curl -X DELETE "${endpoint}?slug=pipeline-test" -H "Authorization: Bearer ${token}"
3. Database / Upstash: Delete record where \`slug = 'pipeline-test'\`.
4. Verification: Refresh \${siteUrl} to confirm the test article is gone and the feed displays cleanly without test artifacts.`;
    }
    return raw
      .replace(/<GENERATED_TOKEN>/g, token)
      .replace(/<YOUR_SECRET_TOKEN>/g, token)
      .replace(/<ENDPOINT_URL>/g, endpoint)
      .replace(/<SITE_URL>/g, siteUrl);
  };
  const getEffectiveCurlHost = () => {
    if (curlHost && curlHost.trim()) return curlHost.trim();
    if (url && url.trim()) return url.trim();
    const defaultSite = websites.find((w) => w.is_default) || websites[0];
    if (defaultSite?.url) return defaultSite.url;
    return "http://localhost:3000/api/posts";
  };

  const getFormattedGetCurl = (overrideHost?: string) => {
    const host = overrideHost || getEffectiveCurlHost();
    return `curl -i "${host}"`;
  };

  const getFormattedPostCurl = (overrideToken?: string, overrideHost?: string) => {
    const token = getEffectiveToken(overrideToken);
    const host = overrideHost || getEffectiveCurlHost();
    const body = '{"title": "Autonomous Pipeline Verification", "slug": "pipeline-test", "content": "Autonomous content pipeline connected successfully!"}';
    const lines = [
      `curl -X POST "${host}"`,
      `  -H "Content-Type: application/json"`,
      token
        ? `  -H "Authorization: Bearer ${token}"`
        : `  -H "Authorization: Bearer YOUR_TOKEN_HERE"`,
      `  -d '${body}'`,
    ];
    return lines.join(" \\\n");
  };

  const handleOpenSnippetModal = async (
    initialTab: "storage" | "prompt" | "code" | "lib" | "curl" = "storage",
    siteUrl?: string,
    siteId?: string
  ) => {
    setSnippetTab(initialTab);
    // Bulk website responses never include secrets, so when a specific site is
    // selected fetch that site's own token on demand. Fabricating a random
    // token here would show a secret the target site would reject.
    let tokenToUse = promptSecretToken || secretToken;
    if (siteId) {
      try {
        const res = await api.getWebsiteSecretToken(siteId);
        if (res.secret_token) tokenToUse = res.secret_token;
      } catch {
        // Leave the field editable instead of inventing a wrong credential.
      }
    } else if (!tokenToUse) {
      tokenToUse = generateRandomToken();
    }
    if (tokenToUse) setPromptSecretToken(tokenToUse);
    if (siteUrl) {
      setCurlHost(siteUrl);
    } else {
      const defaultSite = websites.find((w) => w.is_default) || websites[0];
      if (defaultSite?.url) {
        setCurlHost(defaultSite.url);
      } else {
        setCurlHost("http://localhost:3000/api/posts");
      }
    }
    try {
      const res = await api.getNextJsSnippet();
      setSnippetData(res);
      setSnippetOpen(true);
    } catch {
      push({
        title: "Error",
        description: "Could not load Next.js integration template.",
        variant: "danger",
      });
      setSnippetOpen(true);
    }
  };

  const handleCopyTokenOnly = async () => {
    const token = getEffectiveToken();
    try {
      await navigator.clipboard.writeText(token);
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2000);
      push({
        title: "Secret Token Copied",
        description: `Add to .env.local as AGENT_SECRET_TOKEN=${token}`,
        variant: "info",
      });
    } catch {
      push({ title: "Copy Failed", description: "Could not copy token.", variant: "danger" });
    }
  };

  const handleCopyPromptWithToken = async (overrideToken?: string) => {
    let token = overrideToken || secretToken || promptSecretToken;
    if (!token) {
      token = generateRandomToken();
      setSecretToken(token);
      setPromptSecretToken(token);
    }
    let promptText = getFormattedPrompt(token);
    if (!snippetData.agent_prompt) {
      try {
        const res = await api.getNextJsSnippet();
        setSnippetData(res);
        if (res.agent_prompt) {
          promptText = res.agent_prompt
            .replace(/<GENERATED_TOKEN>/g, token)
            .replace(/<YOUR_SECRET_TOKEN>/g, token)
            .replace(/<ENDPOINT_URL>/g, (curlHost && curlHost.trim()) || "http://localhost:3000/api/posts")
            .replace(/<SITE_URL>/g, ((curlHost && curlHost.trim()) || "http://localhost:3000/api/posts").replace(/\/api\/posts\/?$/, ""));
        }
      } catch {
        // fallback
      }
    }
    try {
      await navigator.clipboard.writeText(promptText);
      setCopiedPrompt(true);
      setTimeout(() => setCopiedPrompt(false), 2500);
      push({
        title: "AI Agent Prompt Copied!",
        description: "Paste into Cursor Composer (Cmd+I) or Claude Code to build your Next.js route.",
        variant: "success",
      });
    } catch {
      push({
        title: "Copy Failed",
        description: "Please manually copy the text from the prompt viewer.",
        variant: "danger",
      });
    }
  };

  const handleCopyGetCurl = async () => {
    const cmd = getFormattedGetCurl();
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedGetCurl(true);
      setTimeout(() => setCopiedGetCurl(false), 2000);
      push({
        title: "GET Ping cURL Copied",
        description: "Run in your terminal to verify route responsiveness.",
        variant: "success",
      });
    } catch {
      push({ title: "Copy Failed", description: "Could not copy command.", variant: "danger" });
    }
  };

  const handleCopyPostCurl = async () => {
    const cmd = getFormattedPostCurl();
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedPostCurl(true);
      setTimeout(() => {
        setCopiedPostCurl(false);
      }, 2000);
      push({
        title: "POST Dispatch cURL Copied",
        description: "Run in your terminal to test authenticated publishing.",
        variant: "success",
      });
    } catch {
      push({ title: "Copy Failed", description: "Could not copy command.", variant: "danger" });
    }
  };

  const handleTestStorage = async () => {
    if (storageEngine === "upstash") {
      if (!upstashUrl.trim() || !upstashToken.trim()) {
        push({
          title: "Upstash Credentials Required",
          description: "Please enter both the REST URL and REST Token to test.",
          variant: "warn",
        });
        return;
      }
    } else if (storageEngine === "github") {
      if (!githubToken.trim() || !githubRepo.trim()) {
        push({
          title: "GitHub Credentials Required",
          description: "Please enter both the Personal Access Token and Repository (owner/repo).",
          variant: "warn",
        });
        return;
      }
    } else {
      push({
        title: "Local Disk Mode",
        description: "Local disk runs locally in dev and does not require cloud verification.",
        variant: "info",
      });
      return;
    }

    setTestingStorage(true);
    setStorageTestResult(null);
    try {
      const res = await api.testStorageConnection({
        engine: storageEngine,
        upstash_url: upstashUrl.trim(),
        upstash_token: upstashToken.trim(),
        github_token: githubToken.trim(),
        github_repo: githubRepo.trim(),
      });
      setStorageTestResult(res);
      if (res.success) {
        push({
          title: storageEngine === "upstash" ? "Upstash Redis Verified!" : "GitHub Access Verified!",
          description: res.message,
          variant: "success",
        });
      } else {
        push({
          title: "Storage Verification Issue",
          description: res.message,
          variant: "warn",
        });
      }
    } catch (err: any) {
      const msg = err.message || "Failed to reach verification endpoint.";
      setStorageTestResult({ success: false, message: msg });
      push({
        title: "Test Failed",
        description: msg,
        variant: "danger",
      });
    } finally {
      setTestingStorage(false);
    }
  };

  const getCompiledEnvBlock = () => {
    const token = getEffectiveToken();
    const lines = [
      "# Next.js Serverless Environment Variables (.env.local & Vercel Dashboard)",
      `AGENT_SECRET_TOKEN=${token}`,
      "",
    ];

    if (storageEngine === "upstash" || upstashUrl || upstashToken) {
      lines.push("# Engine 1: Upstash Redis REST (Recommended: Instant 0s Publishing, Zero Git Push)");
      lines.push(`UPSTASH_REDIS_REST_URL=${upstashUrl.trim() || "https://your-upstash-redis.upstash.io"}`);
      lines.push(`UPSTASH_REDIS_REST_TOKEN=${upstashToken.trim() || "your_upstash_rest_token"}`);
    }

    if (storageEngine === "github" || githubToken) {
      if (lines.length > 3) lines.push("");
      lines.push("# Engine 2: GitHub API Cloud Auto-Commit (Direct Serverless Git Push)");
      lines.push(`GITHUB_TOKEN=${githubToken.trim() || "your_github_token_here"}`);
      lines.push(`GITHUB_REPO=${githubRepo.trim() || "owner/repo"}`);
      lines.push(`GITHUB_BRANCH=${githubBranch.trim() || "main"}`);
    }

    return lines.join("\n");
  };

  const handleCopyEnvBlock = async () => {
    const text = getCompiledEnvBlock();
    try {
      await navigator.clipboard.writeText(text);
      setCopiedEnv(true);
      setTimeout(() => setCopiedEnv(false), 2000);
      push({
        title: "Environment Variables Copied!",
        description: "Add to .env.local and to Vercel Project Settings > Environment Variables.",
        variant: "success",
      });
    } catch {
      push({ title: "Copy Failed", description: "Could not copy to clipboard.", variant: "danger" });
    }
  };

  const handleCopyLibCode = async () => {
    const code = snippetData.lib_posts || "";
    try {
      await navigator.clipboard.writeText(code);
      setCopiedLibCode(true);
      setTimeout(() => setCopiedLibCode(false), 2000);
      push({
        title: "Reader Code Copied!",
        description: "Paste into src/lib/posts.ts",
        variant: "success",
      });
    } catch {
      push({ title: "Copy Failed", description: "Could not copy code.", variant: "danger" });
    }
  };

  const handleTestConnectionInForm = async () => {
    if (!url.trim()) {
      push({
        title: "URL Required",
        description: "Enter an endpoint URL to test.",
        variant: "warn",
      });
      return;
    }
    setTestingInForm(true);
    try {
      let testUrl = url.trim();
      const res = await fetch(testUrl, {
        method: "GET",
        headers: secretToken.trim() ? { Authorization: `Bearer ${secretToken.trim()}` } : {},
      });
      if (res.ok) {
        push({
          title: `Endpoint Responding (HTTP ${res.status})`,
          description: "Route handler is online and ready to accept dispatches!",
          variant: "success",
        });
      } else if (res.status === 401) {
        push({
          title: "Unauthorized (HTTP 401)",
          description: "Endpoint reached, but rejected secret token. Verify AGENT_SECRET_TOKEN.",
          variant: "warn",
        });
      } else {
        push({
          title: `HTTP ${res.status}`,
          description: `Endpoint responded with status ${res.status}.`,
          variant: "warn",
        });
      }
    } catch (err: any) {
      push({
        title: "Ping Failed",
        description: err.message || "Could not reach target route.",
        variant: "danger",
      });
    } finally {
      setTestingInForm(false);
    }
  };

  const handleApplyTokenToConnectForm = () => {
 setSecretToken(promptSecretToken);
 setSnippetOpen(false);
 setConnectOpen(true);
 push({
 title: "Token applied to Connect Form",
 description: `Token ${promptSecretToken.slice(0, 16)}... pre-filled.`,
 variant: "info",
 });
 };

 const handleDelete = async (id: string, siteName: string) => {
 if (!confirm(`Are you sure you want to disconnect "${siteName}"?`)) return;
 try {
 await deleteWebsiteItem(id);
 push({
 title: "Website disconnected",
 description: `${siteName} has been removed.`,
 variant: "info",
 });
 } catch (err: any) {
 push({
 title: "Error",
 description: err.message || "Failed to remove website.",
 variant: "danger",
 });
 }
 };

 const handleGenerateToken = () => {
 const token = generateRandomToken();
 setSecretToken(token);
 setPromptSecretToken(token);
 push({
 title: "Secret token generated",
 description: "Remember to save this token in your Next.js .env.local file.",
 variant: "info",
 });
 };

   return (
  <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
  {/* Standardized aligned header */}
  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
    <div>
      <div className="flex items-center gap-2.5">
        <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
          Connected Websites
        </h1>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-500">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          Edge Runtime Ready
        </span>
      </div>
      <p className="mt-1 text-xs text-[var(--color-text-muted)]">
        {websites.length} destinations connected. Direct HTTP /api/posts ingestion with timing-safe Bearer authentication.
      </p>
    </div>
    <div className="flex flex-wrap items-center gap-2">
      <Button
        variant="secondary"
        size="sm"
        icon={pingingAll ? <Loader2 size={13} className="animate-spin text-emerald-400" /> : <Radio size={13} className="text-emerald-400" />}
        onClick={handlePingAllSites}
        disabled={pingingAll || websites.length === 0}
        className="text-xs cursor-pointer"
      >
        {pingingAll ? "Pinging..." : "Ping All Sites"}
      </Button>
      <Button
        variant="secondary"
        size="sm"
        icon={<Database size={13} className="text-[var(--color-accent)]" />}
        onClick={() => handleOpenSnippetModal("storage")}
        className="text-xs cursor-pointer"
      >
        Storage Setup
      </Button>
      <Button
        variant="secondary"
        size="sm"
        icon={<Code2 size={13} />}
        onClick={() => handleOpenSnippetModal("code")}
        className="text-xs cursor-pointer"
      >
        Route Snippet
      </Button>
      <Button
        variant="primary"
        size="sm"
        icon={<Plus size={14} className="stroke-[2.5]" />}
        onClick={openCreateModal}
        className="text-xs font-semibold cursor-pointer"
      >
        Connect Website
      </Button>
    </div>
  </div>

 {/* Visual Connection & Architecture Masterclass Banner */}
 <div
 className="mb-8 overflow-hidden rounded-xl border transition-all"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}
 >
 <div
 className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3.5"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center gap-2.5">
 <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[var(--color-accent)]/15 text-[var(--color-accent-text)]">
 <Layers size={15} />
 </div>
 <div>
 <h2 className="text-sm font-semibold text-[var(--color-text)]">
 Target Website Connection &amp; Storage Architecture
 </h2>
 <p className="text-[11px] text-[var(--color-text-muted)]">
 Direct Next.js route ingestion, Zero-Git storage hierarchy, and autonomous publishing modes
 </p>
 </div>
 </div>
 <div className="flex items-center gap-2">
 <button
 type="button"
 onClick={() => setShowArchitectureGuide(!showArchitectureGuide)}
 className="text-xs font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] transition cursor-pointer"
 >
 {showArchitectureGuide ? "Hide Architecture Flow" : "Show Architecture Flow"}
 </button>
 </div>
 </div>

 {showArchitectureGuide && (
 <div className="p-5 space-y-5">
 {/* 3 Step Visual Pipeline Flow */}
 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
 {/* Step 1: Ingestion API */}
 <div
 className="rounded-lg border p-4 space-y-2.5"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 1
 </span>
 <span className="text-xs font-bold text-[var(--color-text)]">Direct HTTP Ingestion</span>
 </div>
 <span className="rounded bg-emerald-500/10 px-2 py-0.5 font-mono text-[10px] font-semibold text-emerald-400">
 0s Latency
 </span>
 </div>
 <p className="text-xs text-[var(--color-text-muted)] leading-relaxed">
 The studio dispatches published articles to your target site via <code className="font-mono text-[var(--color-text)]">POST /api/posts</code> with a timing-safe Bearer secret token.
 </p>
 <div className="rounded border bg-[var(--color-bg)] p-2 font-mono text-[11px] text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
 <div className="text-[10px] text-[var(--color-accent-text)] font-semibold mb-0.5">Payload Includes:</div>
 • Title, slug, and word count<br />
 • GFM Markdown &amp; Rich HTML<br />
 • Base64 Hero Image &amp; Alt text<br />
 • JSON-LD Article Schema
 </div>
 </div>

 {/* Step 2: Storage Strategy */}
 <div
 className="rounded-lg border p-4 space-y-2.5"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 2
 </span>
 <span className="text-xs font-bold text-[var(--color-text)]">Storage Hierarchy (Rule A/B)</span>
 </div>
 <span className="rounded bg-blue-500/10 px-2 py-0.5 font-mono text-[10px] font-semibold text-blue-400">
 Strict Rules
 </span>
 </div>
 <p className="text-xs text-[var(--color-text-muted)] leading-relaxed">
 <strong>Rule A (Database or Upstash):</strong> Sites with Postgres, Supabase, SQLite, or Upstash Redis persist immediately in memory/DB. <em>Zero Git dependency — never prompts for Git!</em>
 </p>
 <p className="text-xs text-[var(--color-text-muted)] leading-relaxed">
 <strong>Rule B (Pure Serverless Git):</strong> Only when a site has NO database, GitHub commits persist markdown into <code className="font-mono text-[var(--color-text)]">content/posts/</code>.
 </p>
 </div>

 {/* Step 3: Publish Modes & Images */}
 <div
 className="rounded-lg border p-4 space-y-2.5"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
 >
 <div className="flex items-center justify-between">
 <div className="flex items-center gap-2">
 <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--color-accent)] text-[10px] font-bold text-white">
 3
 </span>
 <span className="text-xs font-bold text-[var(--color-text)]">Publish Modes &amp; Images</span>
 </div>
 <span className="rounded bg-purple-500/10 px-2 py-0.5 font-mono text-[10px] font-semibold text-purple-400">
 Governance
 </span>
 </div>
 <p className="text-xs text-[var(--color-text-muted)] leading-relaxed">
 <strong>Mode 1 (Standard):</strong> Pauses at Studio Drawer / Slack Card for 1-click human editorial review.<br />
 <strong>Mode 2:</strong> Auto-publishes after grace period if fact-check score ≥ 85%.<br />
 <strong>Mode 3:</strong> Autonomous zero-touch publishing.
 </p>
 <div className="text-[11px] text-[var(--color-text-subtle)]">
 <strong>Hero Images:</strong> Decoded into <code className="font-mono text-[var(--color-text)]">public/uploads/</code> and served at <code className="font-mono text-[var(--color-text)]">/uploads/&lt;filename&gt;</code>.
 </div>
 </div>
 </div>

 {/* Quick Action Dock */}
 <div
 className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3"
 style={{ borderColor: "var(--color-border)", background: "var(--color-bg)" }}
 >
 <div className="flex items-center gap-2 text-xs text-[var(--color-text-muted)]">
 <Zap size={14} className="text-[var(--color-accent)]" />
 <span>Need to connect a new Next.js website in under 2 minutes?</span>
 </div>
 <div className="flex flex-wrap items-center gap-2">
 <Button
 variant="secondary"
 size="sm"
 icon={<Bot size={13} />}
 onClick={() => handleOpenSnippetModal("prompt")}
 >
 1-Click AI Agent Prompt
 </Button>
 <Button
 variant="secondary"
 size="sm"
 icon={<Code2 size={13} />}
 onClick={() => handleOpenSnippetModal("code")}
 >
 View Route Handler (route.ts)
 </Button>
 <Button
 variant="secondary"
 size="sm"
 icon={<Database size={13} />}
 onClick={() => handleOpenSnippetModal("storage")}
 >
 Serverless Storage Setup
 </Button>
 </div>
 </div>
 </div>
 )}
 </div>

 <Card padded={false}>
 <div className="flex items-center gap-2 border-b px-5 py-3.5" style={{ borderColor: "var(--color-border)" }}>
 <div className="relative max-w-xs flex-1">
 <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]" />
 <input
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 placeholder="Search websites…"
 className="h-8.5 w-full rounded-lg border bg-[var(--color-bg-soft)] pl-8.5 pr-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div className="ml-auto text-[12px] font-mono text-[var(--color-text-muted)]">
 {filtered.length} of {websites.length}
 </div>
 </div>

 {/* Table header (desktop) */}
 <div
 className="hidden border-b px-5 py-3 text-[10px] font-mono uppercase tracking-widest text-[var(--color-text-subtle)] lg:grid lg:grid-cols-[2fr_1.4fr_0.8fr_0.8fr_1fr_80px] lg:gap-4"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div>Website</div>
 <div>Endpoint URL</div>
 <div>Status</div>
 <div>Default</div>
 <div>Last Activity</div>
 <div></div>
 </div>

 <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
 {filtered.map((w) => (
 <div
 key={w.id}
 className="px-5 py-3.5 transition-colors duration-150 hover:bg-[var(--color-bg-soft)]/60"
 >
 {/* Desktop row */}
 <div className="hidden items-center gap-4 lg:grid lg:grid-cols-[2fr_1.4fr_0.8fr_0.8fr_1fr_80px]">
 <div className="flex min-w-0 items-center gap-3">
 <WebsiteIcon website={w} size={36} />
 <div className="min-w-0">
 <div className="flex items-center gap-2">
 <span className="truncate text-[13px] font-semibold text-[var(--color-text)]">
 {w.name}
 </span>
 {w.storage_type === "git" ? (
   <span className="inline-flex items-center gap-1 rounded border border-purple-500/30 bg-purple-500/10 px-1.5 py-0.2 font-mono text-[9px] text-purple-300" title="Rule B: Git commit based publishing">
     <GitBranch size={9} /> Rule B: Git
   </span>
 ) : (
   <span className="inline-flex items-center gap-1 rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.2 font-mono text-[9px] text-emerald-300" title="Rule A: Direct HTTP to /api/posts (0s instant persistence, zero Git)">
     <Database size={9} /> Rule A: Direct DB
   </span>
 )}
 </div>
 <div className="mt-0.5 flex items-center gap-2 text-[11px] text-[var(--color-text-subtle)]">
 <span>{w.articles === 1 ? "1 article published" : `${w.articles} articles published`}</span>
 {pingResults[w.id] && (
   <span className={`inline-flex items-center gap-1 rounded border px-1.5 py-0.2 font-mono text-[10px] ${
     pingResults[w.id].success ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400" : "border-rose-500/30 bg-rose-500/10 text-rose-400"
   }`} title={pingResults[w.id].message}>
     <Zap size={9} />
     {pingResults[w.id].latency_ms ? `${pingResults[w.id].latency_ms}ms` : pingResults[w.id].success ? "200 OK" : "Failed"}
   </span>
 )}
 </div>
 </div>
 </div>
 <div className="min-w-0">
 <span className="inline-block max-w-full truncate border border-white/5 bg-[var(--color-bg-soft)]/70 px-2 py-0.5 font-mono text-[11px] text-[var(--color-text-muted)]">
 {w.url}
 </span>
 </div>
 <div>
 <span title={w.last_status || undefined}>
                    <StatusBadge status={w.status} />
                  </span>
 </div>
 <div>
 {w.is_default ? (
 <span className="rounded-full border border-[var(--color-border)] bg-[var(--color-bg-soft)] px-2.5 py-0.5 text-[10px] font-semibold text-[var(--color-text)]">
 Default
 </span>
 ) : (
 <span className="text-[12px] text-[var(--color-text-subtle)]">—</span>
 )}
 </div>
 <div>
 <div className="tabular-numbers text-[12px] text-[var(--color-text)]">{w.lastPublished}</div>
 </div>
 <div className="flex items-center justify-end gap-1">
 <button
 onClick={() => handleTestConnection(w.id, w.name)}
 disabled={loadingActionId === w.id}
 className="rounded-lg p-1.5 text-[var(--color-text-muted)] transition hover:bg-[var(--color-bg-soft)] hover:text-emerald-400 cursor-pointer"
 title="Ping connection health"
 >
 {loadingActionId === w.id ? (
 <Loader2 size={14} className="animate-spin text-emerald-400" />
 ) : (
 <Radio size={14} />
 )}
 </button>
 <Dropdown
 trigger={
 <button
 className="rounded-lg p-1.5 text-[var(--color-text-muted)] transition hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] cursor-pointer"
 aria-label="Website actions"
 >
 {loadingActionId === w.id ? (
 <Loader2 size={15} className="animate-spin" />
 ) : (
 <MoreHorizontal size={15} />
 )}
 </button>
 }
 >
 <DropdownItem
 icon={<FileCode size={13} />}
 onSelect={() => openEditModal(w)}
 >
 Edit Website Settings
 </DropdownItem>
 <DropdownItem
 icon={<CheckCircle2 size={13} />}
 onSelect={() => handleTestConnection(w.id, w.name)}
 >
 Test Connection
 </DropdownItem>
 <DropdownItem
 icon={<Send size={13} />}
 onSelect={() => handleTestSlack(w.id, w.name)}
 >
 Test Slack Card
 </DropdownItem>
 <DropdownItem
 icon={<Globe size={13} />}
 onSelect={() => handleTestCrawlerAccess(w)}
 >
 Test AI Crawlers (robots.txt)
 </DropdownItem>
 <DropdownItem
                  icon={<Bot size={13} />}
                  onSelect={() => handleOpenSnippetModal("prompt", w.url, w.id)}
                >
                  AI Setup Prompt
                </DropdownItem>
                <DropdownItem
                  icon={<Code2 size={13} />}
                  onSelect={() => handleOpenSnippetModal("code", w.url, w.id)}
                >
                  View Route Snippet
                </DropdownItem>
                <DropdownItem
                  icon={<Terminal size={13} />}
                  onSelect={() => handleOpenSnippetModal("curl", w.url, w.id)}
                >
                  Diagnostic cURL
                </DropdownItem>
 <DropdownItem
 icon={<ExternalLink size={13} />}
 onSelect={() => window.open(w.url, "_blank")}
 >
 Visit endpoint
 </DropdownItem>
 <DropdownSeparator />
 <DropdownItem
 icon={<Trash2 size={13} />}
 danger
 onSelect={() => handleDelete(w.id, w.name)}
 >
 Disconnect
 </DropdownItem>
 </Dropdown>
 </div>
 </div>

 {/* Mobile card */}
 <div className="lg:hidden">
 <div className="flex items-start gap-3">
 <WebsiteIcon website={w} size={40} />
 <div className="min-w-0 flex-1">
 <div className="flex items-start justify-between gap-2">
 <div>
 <div className="flex items-center gap-1.5">
 <span className="text-[13px] font-semibold text-[var(--color-text)]">{w.name}</span>
 {w.storage_type === "git" ? (
   <span className="inline-flex items-center gap-1 rounded border border-purple-500/30 bg-purple-500/10 px-1.5 py-0.2 font-mono text-[9px] text-purple-300">
     <GitBranch size={9} /> Git
   </span>
 ) : (
   <span className="inline-flex items-center gap-1 rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.2 font-mono text-[9px] text-emerald-300">
     <Database size={9} /> DB
   </span>
 )}
 </div>
 <div className="font-mono text-[11px] text-[var(--color-text-muted)]">{w.url}</div>
 </div>
 <span title={w.last_status || undefined}>
                    <StatusBadge status={w.status} />
                  </span>
 </div>
 <div className="mt-3 flex flex-wrap gap-2">
 <Button
 variant="secondary"
 size="sm"
 icon={<CheckCircle2 size={12} />}
 onClick={() => handleTestConnection(w.id, w.name)}
 >
 Ping
 </Button>
 <Button
                  variant="secondary"
                  size="sm"
                  icon={<Bot size={12} />}
                  onClick={() => handleOpenSnippetModal("prompt", w.url, w.id)}
                >
                  AI Prompt
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  icon={<Terminal size={12} />}
                  onClick={() => handleOpenSnippetModal("curl", w.url, w.id)}
                >
                  cURL
                </Button>
 <Button
 variant="ghost"
 size="sm"
 icon={<Trash2 size={12} />}
 onClick={() => handleDelete(w.id, w.name)}
 >
 Remove
 </Button>
 </div>
 </div>
 </div>
 </div>
 </div>
 ))}
 {filtered.length === 0 && (
 <div className="px-5 py-12 text-center">
 <Globe size={28} className="mx-auto text-[var(--color-text-subtle)]" />
 <p className="mt-2 text-[14px] font-medium text-[var(--color-text)]">
 {websites.length === 0 ? "No Next.js websites connected yet" : "No websites match your search"}
 </p>
 <p className="mt-1 text-xs text-[var(--color-text-muted)]">
 {websites.length === 0
 ? "Connect your Next.js application by creating an endpoint route at src/app/api/posts/route.ts (or app/api/posts/route.ts)."
 : "Try a different search term or clear the search input."}
 </p>
 {websites.length === 0 && (
 <div className="mt-4 flex flex-wrap justify-center gap-2">
 <Button variant="primary" size="sm" icon={<Plus size={13} />} onClick={openCreateModal}>
 Connect Website
 </Button>
 <Button
 variant="secondary"
 size="sm"
 icon={<Bot size={13} className="text-[var(--color-text)]" />}
 onClick={() => handleOpenSnippetModal("prompt")}
 >
 AI Setup Prompt
 </Button>
 <Button
 variant="secondary"
 size="sm"
 icon={<Code2 size={13} />}
 onClick={() => handleOpenSnippetModal("code")}
 >
 View Route Snippet
 </Button>
 </div>
 )}
 </div>
 )}
 </div>
 </Card>

 {/* Connect Modal */}
 <Modal
 open={connectOpen}
 onClose={() => setConnectOpen(false)}
 title={editingWebsiteId ? "Edit Website Settings" : "Connect Next.js Production Website"}
 description={editingWebsiteId ? "Update this website's publishing, storage, and Slack configuration." : "Configure your Next.js endpoint to receive verified, automated publishing runs."}
 size="md"
 footer={
 <>
 <Button variant="ghost" onClick={() => setConnectOpen(false)} disabled={submitting}>
 Cancel
 </Button>
 <Button
 variant="primary"
 icon={submitting ? <Loader2 size={14} className="animate-spin" /> : <Globe size={14} />}
 onClick={handleConnect}
 disabled={submitting}
 >
 {submitting ? "Saving..." : editingWebsiteId ? "Save Changes" : "Save Website"}
 </Button>
 </>
 }
 >
 <div className="space-y-3">
 {/* AI Agent Quick Setup Banner */}
        <div
          className="rounded-xl border p-3.5"
          style={{
            borderColor: "var(--color-border)",
            background: "var(--color-bg-soft)",
          }}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
              <Bot size={14} className="text-[var(--color-accent)]" />
              <span>Need your Next.js route code?</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Button
                type="button"
                variant="outline"
                size="sm"
                icon={<Code2 size={12} />}
                onClick={() => {
                  setConnectOpen(false);
                  handleOpenSnippetModal("code");
                }}
              >
                View Code
              </Button>
              <Button
                type="button"
                variant="secondary"
                size="sm"
                icon={copiedPrompt ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                onClick={() => handleCopyPromptWithToken(secretToken)}
              >
                {copiedPrompt ? "Prompt Copied!" : "Copy Prompt"}
              </Button>
            </div>
          </div>
          <p className="mt-1.5 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
            Paste this prompt into <strong>Cursor Composer</strong> (<kbd className="rounded border bg-[var(--color-bg-elev)] px-1.5 py-0.5 text-[10px] font-mono">Cmd+I</kbd>) or <strong>Claude Code</strong> to generate <code className="font-mono text-[11px] text-[var(--color-text)]">src/app/api/posts/route.ts</code> with authentication & serverless storage.
          </p>
        </div>

        <div>
 <label className="mb-1.5 block text-[11px] font-medium text-[var(--color-text-muted)]">
 Website Name
 </label>
 <input
 value={name}
 onChange={(e) => setName(e.target.value)}
 placeholder="e.g. Production (Next.js)"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>

 <div>
            <div className="mb-1.5 flex items-center justify-between">
              <label className="text-[11px] font-medium text-[var(--color-text-muted)]">
                Next.js Endpoint URL
              </label>
              {url.trim() && (
                <button
                  type="button"
                  onClick={handleTestConnectionInForm}
                  disabled={testingInForm}
                  className="inline-flex items-center gap-1 text-[11px] font-medium text-[var(--color-accent)] hover:underline cursor-pointer"
                >
                  {testingInForm ? <Loader2 size={11} className="animate-spin" /> : <Radio size={11} />}
                  <span>{testingInForm ? "Testing..." : "Test Ping Endpoint"}</span>
                </button>
              )}
            </div>
            <input
              value={url}
 onChange={(e) => setUrl(e.target.value)}
 placeholder="https://your-domain.vercel.app/api/posts"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>

 <div>
 <div className="mb-1.5 flex items-center justify-between">
 <label className="text-[11px] font-medium text-[var(--color-text-muted)]">
 Bearer Secret Token
 </label>
 <button
 type="button"
 onClick={handleGenerateToken}
 className="inline-flex items-center gap-1 text-[11px] font-medium text-[var(--color-text)] hover:underline"
 >
 <ShieldCheck size={12} /> Auto-Generate
 </button>
 </div>
 <input                value={secretToken}
                onChange={(e) => setSecretToken(e.target.value)}
                placeholder={savedSiteSecretTokenConfigured ? "Stored — leave blank to keep the existing token" : "nxt_sec_..."}
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>

 <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
 <div>
 <label className="mb-1.5 block text-[11px] font-medium text-[var(--color-text-muted)]">
 Slack Channel (optional)
 </label>
 <input
 value={slackChannel}
 onChange={(e) => setSlackChannel(e.target.value)}
 placeholder="#content-reviews"
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 <div>
 <label className="mb-1.5 block text-[11px] font-medium text-[var(--color-text-muted)]">
 Slack Webhook URL (optional)
 </label>
 <input
 value={slackWebhook}
 onChange={(e) => setSlackWebhook(e.target.value)}
 placeholder="https://hooks.slack.com/..."
 className="h-9 w-full rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
 style={{ borderColor: "var(--color-border)" }}
 />
 </div>
 </div>

        {/* Storage Architecture Selector */}
        <div>
          <label className="mb-1.5 block text-[11px] font-medium text-[var(--color-text-muted)]">
            Storage Engine & Architecture
          </label>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            <button
              type="button"
              onClick={() => setSiteStorageType("database")}
              className={`flex flex-col items-start rounded-lg border p-2.5 text-left transition cursor-pointer ${
                siteStorageType === "database"
                  ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-300"
                  : "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
                <Database size={13} className={siteStorageType === "database" ? "text-emerald-400" : "text-[var(--color-text-subtle)]"} />
                <span>Database / Upstash</span>
              </div>
              <p className="mt-1 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Direct API save. <strong>No GitHub token or commit required.</strong>
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSiteStorageType("git")}
              className={`flex flex-col items-start rounded-lg border p-2.5 text-left transition cursor-pointer ${
                siteStorageType === "git"
                  ? "border-purple-500/50 bg-purple-500/10 text-purple-300"
                  : "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
                <Cloud size={13} className={siteStorageType === "git" ? "text-purple-400" : "text-[var(--color-text-subtle)]"} />
                <span>Serverless Git-Backed</span>
              </div>
              <p className="mt-1 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Commits to website GitHub repo for Vercel/Netlify/Cloudflare Pages auto-deployment.
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSiteStorageType("auto")}
              className={`flex flex-col items-start rounded-lg border p-2.5 text-left transition cursor-pointer ${
                siteStorageType === "auto"
                  ? "border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-accent)]"
                  : "border-[var(--color-border)] bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
                <Zap size={13} className={siteStorageType === "auto" ? "text-[var(--color-accent)]" : "text-[var(--color-text-subtle)]"} />
                <span>Auto-Detect</span>
              </div>
              <p className="mt-1 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Detects DB/Upstash or serverless automatically on publish.
              </p>
            </button>
          </div>
        </div>

        {/* GitHub Repository details for Git-Backed or Auto */}
        {siteStorageType !== "database" && (
          <div className="rounded-lg border border-[var(--color-border)] bg-[var(--color-bg-soft)] p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[var(--color-text)]">
                <Code2 size={13} className="text-purple-400" />
                <span>GitHub Repository for this Website</span>
              </div>
              <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">Multi-site isolated</span>
            </div>
            <p className="text-[10px] text-[var(--color-text-muted)] leading-relaxed">
              Target repository for this specific website (e.g. <code>Azeem1252/gaming-editorial</code> vs <code>Azeem1252/second-website</code>).
            </p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-[10px] font-medium text-[var(--color-text-muted)]">
                  GitHub Repository (owner/repo)
                </label>
                <input
                  value={siteGithubRepo}
                  onChange={(e) => setSiteGithubRepo(e.target.value)}
                  placeholder="e.g. Azeem1252/gaming-editorial"
                  className="h-8.5 w-full rounded-md border bg-[var(--color-bg)] px-2.5 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                />
              </div>
              <div>
                <label className="mb-1 block text-[10px] font-medium text-[var(--color-text-muted)]">
                  Target Branch
                </label>
                <input
                  value={siteGithubBranch}
                  onChange={(e) => setSiteGithubBranch(e.target.value)}
                  placeholder="main"
                  className="h-8.5 w-full rounded-md border bg-[var(--color-bg)] px-2.5 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
                  style={{ borderColor: "var(--color-border)" }}
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-[10px] font-medium text-[var(--color-text-muted)]">
                GitHub Token (Required for Git-backed publishing)
              </label>
              <input
                type="password"
                value={siteGithubToken}
                onChange={(e) => setSiteGithubToken(e.target.value)}
                placeholder="GitHub token for this website"
                className="h-8.5 w-full rounded-md border bg-[var(--color-bg)] px-2.5 text-xs font-mono text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition focus:border-[var(--color-accent)] focus:outline-none"
                style={{ borderColor: "var(--color-border)" }}
              />
            </div>
          </div>
        )}

        {/* Publishing Governance & Autopilot Modes */}
        <div className="rounded-xl border p-3" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
          <div className="flex items-center justify-between mb-2">
            <label className="text-[11px] font-semibold text-[var(--color-text)] flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-[var(--color-accent)]" />
              Publishing Governance & Autopilot Mode
            </label>
            <span className="text-[10px] font-mono uppercase text-zinc-400">
              {publishMode === "mode_1" ? "Approval Gate" : publishMode === "mode_2" ? "Refresh Autopilot" : "Unattended"}
            </span>
          </div>

          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 mb-2">
            <button
              type="button"
              onClick={() => setPublishMode("mode_1")}
              className={`flex flex-col items-start rounded-lg border p-2 text-left transition cursor-pointer ${
                publishMode === "mode_1"
                  ? "border-blue-500/50 bg-blue-500/10 text-blue-300"
                  : "border-[var(--color-border)] bg-[var(--color-bg)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="text-[11px] font-semibold text-[var(--color-text)]">Mode 1: Review Gate</div>
              <div className="mt-0.5 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Human sign-off required for all drafts before publishing.
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPublishMode("mode_2")}
              className={`flex flex-col items-start rounded-lg border p-2 text-left transition cursor-pointer ${
                publishMode === "mode_2"
                  ? "border-amber-500/50 bg-amber-500/10 text-amber-300"
                  : "border-[var(--color-border)] bg-[var(--color-bg)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="text-[11px] font-semibold text-[var(--color-text)]">Mode 2: Refresh Autopilot</div>
              <div className="mt-0.5 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Low-risk content refreshes auto-publish if verified; new posts gate.
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPublishMode("mode_3")}
              className={`flex flex-col items-start rounded-lg border p-2 text-left transition cursor-pointer ${
                publishMode === "mode_3"
                  ? "border-purple-500/50 bg-purple-500/10 text-purple-300"
                  : "border-[var(--color-border)] bg-[var(--color-bg)] text-[var(--color-text-muted)] hover:border-[var(--color-border-hover)]"
              }`}
            >
              <div className="text-[11px] font-semibold text-[var(--color-text)]">Mode 3: Autopilot</div>
              <div className="mt-0.5 text-[10px] leading-tight text-[var(--color-text-muted)]">
                Fully autonomous publishing with EU AI Act Art. 50 disclosure.
              </div>
            </button>
          </div>

          {publishMode === "mode_2" && (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-2.5 text-xs text-amber-200 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span>Minimum Fact-Check Integrity Score:</span>
                <span className="font-mono font-bold text-amber-300">{mode2Threshold}/100</span>
              </div>
              <input
                type="range"
                min="70"
                max="100"
                value={mode2Threshold}
                onChange={(e) => setMode2Threshold(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          )}

          {publishMode === "mode_3" && (
            <div className="rounded-lg border border-purple-500/30 bg-purple-500/5 p-2.5 text-xs text-purple-200 space-y-2">
              <p className="text-[10px] text-purple-300 leading-relaxed">
                Mode 3 adheres to Google October 2026 Quality Standards and auto-attaches EU AI Act Article 50 transparency disclosure to article metadata.
              </p>
              <label className="flex items-center gap-2 text-[11px] text-[var(--color-text)] cursor-pointer">
                <input
                  type="checkbox"
                  checked={mode3Signoff}
                  onChange={(e) => setMode3Signoff(e.target.checked)}
                  className="h-3.5 w-3.5 accent-purple-500"
                />
                <span>Editorial &amp; Compliance Sign-off Confirmed</span>
              </label>
            </div>
          )}
        </div>

 <div
 className="flex items-center justify-between border p-2.5"
 style={{ borderColor: "var(--color-border)" }}
 >
 <div>
 <div className="text-[12px] font-medium text-[var(--color-text)]">
 Set as Default Target
 </div>
 <div className="text-[11px] text-[var(--color-text-muted)]">
 Schedules and runs without an explicit destination will publish here.
 </div>
 </div>
 <input
 type="checkbox"
 checked={isDefault}
 onChange={(e) => setIsDefault(e.target.checked)}
 className="h-4 w-4 accent-[var(--color-accent)] cursor-pointer"
 />
 </div>
 </div>
 </Modal>

 {/* Integration Hub & Snippet Modal */}
  <Modal
    open={snippetOpen}
    onClose={() => setSnippetOpen(false)}
    title={
      <div className="flex items-center gap-2">
        <span>Next.js Integration Hub</span>
        <span className="rounded-full bg-[var(--color-bg-soft)] px-2.5 py-0.5 text-[11px] font-mono text-[var(--color-text-muted)]">
          App Router v13 - v15+
        </span>
      </div>
    }
    description="Connect your Next.js application using AI coding agents, ready-to-drop TypeScript code, or terminal verification."
    size="xl"
    footer={
      <div className="flex w-full flex-wrap items-center justify-between gap-3">
        <Button variant="ghost" onClick={() => setSnippetOpen(false)}>
          Close
        </Button>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<ArrowRight size={13} />}
            onClick={handleApplyTokenToConnectForm}
          >
            Use Token in Connect Form
          </Button>

          {snippetTab === "storage" && (
            <Button
              variant="primary"
              size="sm"
              icon={copiedEnv ? <Check size={13} className="text-[var(--color-live)]" /> : <Copy size={13} />}
              onClick={handleCopyEnvBlock}
            >
              {copiedEnv ? "Copied Variables!" : "Copy .env Block"}
            </Button>
          )}

          {snippetTab === "prompt" && (
            <Button
              variant="primary"
              size="sm"
              icon={copiedPrompt ? <Check size={13} className="text-[var(--color-live)]" /> : <Bot size={13} />}
              onClick={() => handleCopyPromptWithToken(promptSecretToken)}
            >
              {copiedPrompt ? "Copied to Clipboard!" : "Copy Agent Prompt"}
            </Button>
          )}

          {snippetTab === "code" && (
            <Button
              variant="primary"
              size="sm"
              icon={copiedCode ? <Check size={13} className="text-[var(--color-live)]" /> : <Copy size={13} />}
              onClick={() => {
                navigator.clipboard.writeText(snippetData.snippet || snippetData.code || "");
                setCopiedCode(true);
                setTimeout(() => setCopiedCode(false), 2000);
                push({
                  title: "Route code copied",
                  description: "Paste into src/app/api/posts/route.ts",
                  variant: "success",
                });
              }}
            >
              {copiedCode ? "Copied Code!" : "Copy Route Code"}
            </Button>
          )}

          {snippetTab === "lib" && (
            <Button
              variant="primary"
              size="sm"
              icon={copiedLibCode ? <Check size={13} className="text-[var(--color-live)]" /> : <Copy size={13} />}
              onClick={handleCopyLibCode}
            >
              {copiedLibCode ? "Copied Code!" : "Copy Reader Code"}
            </Button>
          )}

          {snippetTab === "curl" && (
            <Button
              variant="primary"
              size="sm"
              icon={copiedPostCurl ? <Check size={13} className="text-[var(--color-live)]" /> : <Terminal size={13} />}
              onClick={handleCopyPostCurl}
            >
              {copiedPostCurl ? "Copied cURL!" : "Copy POST cURL"}
            </Button>
          )}
        </div>
      </div>
    }
  >
    <div className="space-y-4">
      {/* Segmented Tab Navigation Bar */}
      <div
        className="flex items-center gap-1 overflow-x-auto rounded-xl border p-1"
        style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
      >
        <button
          type="button"
          onClick={() => setSnippetTab("storage")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "storage"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Database size={13} className={snippetTab === "storage" ? "text-[var(--color-accent)]" : ""} />
          <span className="truncate">Cloud Storage</span>
          <span className="rounded-full bg-amber-500/10 text-amber-400 px-1.5 py-0.2 text-[9px] font-bold border border-amber-500/20 shrink-0">
            Fix 404
          </span>
        </button>

        <button
          type="button"
          onClick={() => setSnippetTab("prompt")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "prompt"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Bot size={13} className={snippetTab === "prompt" ? "text-[var(--color-accent)]" : ""} />
          <span className="truncate">AI Prompt</span>
        </button>

        <button
          type="button"
          onClick={() => setSnippetTab("code")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "code"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Code2 size={13} className={snippetTab === "code" ? "text-[var(--color-accent)]" : ""} />
          <span className="truncate">Route Handler</span>
        </button>

        <button
          type="button"
          onClick={() => setSnippetTab("lib")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "lib"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <FileCode size={13} className={snippetTab === "lib" ? "text-[var(--color-accent)]" : ""} />
          <span className="truncate">Reader Helper</span>
        </button>

        <button
          type="button"
          onClick={() => setSnippetTab("curl")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "curl"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <Terminal size={13} className={snippetTab === "curl" ? "text-[var(--color-accent)]" : ""} />
          <span className="truncate">cURL Test</span>
        </button>

        <button
          type="button"
          onClick={() => setSnippetTab("troubleshoot")}
          className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 px-2.5 text-xs font-medium transition cursor-pointer ${
            snippetTab === "troubleshoot"
              ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] shadow-xs font-semibold"
              : "text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
          }`}
        >
          <HelpCircle size={13} className={snippetTab === "troubleshoot" ? "text-amber-400" : ""} />
          <span className="truncate">Troubleshoot</span>
          <span className="rounded-full bg-red-500/10 text-red-400 px-1.5 py-0.2 text-[9px] font-bold border border-red-500/20 shrink-0">
            Fix Issues
          </span>
        </button>
      </div>

      {/* Tab: Serverless Persistence & Cloud Storage Setup */}
      {snippetTab === "storage" && (
        <div className="space-y-4">
          {/* Architecture Archetype Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-semibold text-[var(--color-text-muted)] uppercase tracking-wider">
              Select Your Website Architecture:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setActiveArch("serverless")}
                className={`flex flex-col items-start gap-1 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  activeArch === "serverless"
                    ? "border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-text)] shadow-xs"
                    : "border-[var(--color-border)] bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs text-[var(--color-text)]">
                  <Cloud size={13} className={activeArch === "serverless" ? "text-[var(--color-accent)]" : ""} />
                  <span>Serverless</span>
                </div>
                <span className="text-[10px] text-[var(--color-text-subtle)] leading-tight">Vercel, Netlify, Cloudflare, AWS</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveArch("vps_nodb")}
                className={`flex flex-col items-start gap-1 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  activeArch === "vps_nodb"
                    ? "border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-text)] shadow-xs"
                    : "border-[var(--color-border)] bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs text-[var(--color-text)]">
                  <Server size={13} className={activeArch === "vps_nodb" ? "text-[var(--color-accent)]" : ""} />
                  <span>Server (No DB)</span>
                </div>
                <span className="text-[10px] text-[var(--color-text-subtle)] leading-tight">VPS, Docker, Render</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveArch("static_frontend")}
                className={`flex flex-col items-start gap-1 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  activeArch === "static_frontend"
                    ? "border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-text)] shadow-xs"
                    : "border-[var(--color-border)] bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs text-[var(--color-text)]">
                  <Globe size={13} className={activeArch === "static_frontend" ? "text-[var(--color-accent)]" : ""} />
                  <span>Static SPA</span>
                </div>
                <span className="text-[10px] text-[var(--color-text-subtle)] leading-tight">Vite, GitHub/Cloudflare Pages</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveArch("database")}
                className={`flex flex-col items-start gap-1 p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  activeArch === "database"
                    ? "border-[var(--color-accent)] bg-[var(--color-accent)]/10 text-[var(--color-text)] shadow-xs"
                    : "border-[var(--color-border)] bg-[var(--color-bg-elev)] text-[var(--color-text-muted)] hover:border-[var(--color-border-strong)]"
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold text-xs text-[var(--color-text)]">
                  <Database size={13} className={activeArch === "database" ? "text-[var(--color-accent)]" : ""} />
                  <span>Database</span>
                </div>
                <span className="text-[10px] text-[var(--color-text-subtle)] leading-tight">Prisma, Supabase, SQL</span>
              </button>
            </div>
          </div>

          {/* VIEW 1: SERVERLESS (Vercel / Netlify / AWS) */}
          {activeArch === "serverless" && (
            <div className="space-y-4">
              {/* Problem & Solution Explanation Card */}
              <div
                className="rounded-xl border p-4 space-y-2.5"
                style={{ borderColor: "rgba(245, 158, 11, 0.25)", background: "rgba(245, 158, 11, 0.04)" }}
              >
                <div className="flex items-start gap-3">
                  <div className="rounded-lg p-2 bg-amber-500/10 text-amber-400 shrink-0 mt-0.5">
                    <AlertTriangle size={18} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-semibold text-[var(--color-text)]">
                        Why Serverless Returns 404 Without Cloud Storage
                      </h3>
                      <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-mono text-amber-300">
                        Serverless EROFS Problem
                      </span>
                    </div>
                    <p className="text-xs text-[var(--color-text-muted)] leading-relaxed">
                      On <strong>Vercel, Cloudflare Workers &amp; AWS Lambda</strong>, the filesystem is strictly <strong>read-only</strong> (or wiped when the isolate spins down). Files written to local disk or <code className="text-amber-300 font-mono text-[11px]">/tmp/posts/</code> disappear when the container spins down. Subsequent visitors hit fresh containers where the file does not exist, causing <strong>404 Not Found</strong> unless cloud persistence is enabled below.
                    </p>
                  </div>
                </div>
              </div>

              {/* CRITICAL ALERT: The Stale Vercel Environment Variable Trap */}
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3.5 space-y-1.5 text-xs text-red-200">
                <div className="flex items-center gap-2 font-semibold text-red-300">
                  <AlertTriangle size={15} className="text-red-400 shrink-0" />
                  <span>Crucial: Adding Variables in Vercel Requires a Redeploy!</span>
                </div>
                <p className="text-[11px] leading-relaxed opacity-95">
                  When you add <code className="font-mono bg-red-950/60 px-1 py-0.2 rounded text-red-100">GITHUB_TOKEN</code> or <code className="font-mono bg-red-950/60 px-1 py-0.2 rounded text-red-100">UPSTASH_*</code> to Vercel Project Settings, it does <strong>NOT</strong> apply to existing active deployments. You <strong>MUST go to Vercel Deployments &gt; click &ldquo;...&rdquo; &gt; click Redeploy</strong>. Otherwise your endpoint will keep returning <code className="font-mono">&quot;github_api&quot;: false</code> and files won&apos;t persist!
                </p>
              </div>

              {/* Storage Engine Selector Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div
                  onClick={() => setStorageEngine("upstash")}
                  className={`rounded-xl border p-3.5 cursor-pointer transition-all ${
                    storageEngine === "upstash"
                      ? "border-[var(--color-accent)] bg-[var(--color-accent)]/5 shadow-sm"
                      : "border-[var(--color-border)] bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Database size={16} className={storageEngine === "upstash" ? "text-[var(--color-accent)]" : "text-[var(--color-text-muted)]"} />
                      <span className="text-xs font-semibold text-[var(--color-text)]">Upstash Redis REST</span>
                    </div>
                    <span className="rounded-full bg-[var(--color-live)]/10 text-[var(--color-live)] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                      Recommended
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                    Instant 0s live publishing. Zero git commits needed. 10,000 requests/day free with 0 credit card.
                  </p>
                </div>

                <div
                  onClick={() => setStorageEngine("github")}
                  className={`rounded-xl border p-3.5 cursor-pointer transition-all ${
                    storageEngine === "github"
                      ? "border-[var(--color-accent)] bg-[var(--color-accent)]/5 shadow-sm"
                      : "border-[var(--color-border)] bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Cloud size={16} className={storageEngine === "github" ? "text-[var(--color-accent)]" : "text-[var(--color-text-muted)]"} />
                      <span className="text-xs font-semibold text-[var(--color-text)]">GitHub Cloud Commit</span>
                    </div>
                    <span className="rounded-full bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] px-2 py-0.5 text-[9px] font-mono">
                      File-based
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                    Serverless route commits markdown/json directly to your repo via GitHub REST API. No local git push.
                  </p>
                </div>

                <div
                  onClick={() => setStorageEngine("disk")}
                  className={`rounded-xl border p-3.5 cursor-pointer transition-all ${
                    storageEngine === "disk"
                      ? "border-[var(--color-accent)] bg-[var(--color-accent)]/5 shadow-sm"
                      : "border-[var(--color-border)] bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Server size={16} className={storageEngine === "disk" ? "text-[var(--color-accent)]" : "text-[var(--color-text-muted)]"} />
                      <span className="text-xs font-semibold text-[var(--color-text)]">Local Disk</span>
                    </div>
                    <span className="rounded-full bg-[var(--color-bg-soft)] text-[var(--color-text-muted)] px-2 py-0.5 text-[9px] font-mono">
                      Dev Only
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                    Writes to <code className="font-mono text-[10px]">content/posts/</code>. Only suitable for <code className="font-mono text-[10px]">localhost:3000</code>.
                  </p>
                </div>
              </div>

              {/* Interactive Inputs for Upstash */}
              {storageEngine === "upstash" && (
                <div className="rounded-xl border p-4 space-y-3.5 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-semibold text-[var(--color-text)]">Upstash Redis REST Credentials</h4>
                      <p className="text-[11px] text-[var(--color-text-muted)] mt-0.5">
                        100% Free (10,000 commands/day). Get credentials in 30 seconds at console.upstash.com (Create Database &gt; REST API).
                      </p>
                    </div>
                    <a
                      href="https://console.upstash.com"
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-[var(--color-accent)] hover:underline font-medium"
                    >
                      <span>Open Upstash Console</span>
                      <ExternalLink size={11} />
                    </a>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono font-medium text-[var(--color-text-muted)]">
                        UPSTASH_REDIS_REST_URL
                      </label>
                      <input
                        value={upstashUrl}
                        onChange={(e) => setUpstashUrl(e.target.value)}
                        placeholder="https://flowing-sloth-12345.upstash.io"
                        className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition focus:border-[var(--color-accent)] focus:outline-none"
                        style={{ borderColor: "var(--color-border)" }}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono font-medium text-[var(--color-text-muted)]">
                        UPSTASH_REDIS_REST_TOKEN
                      </label>
                      <input
                        type="password"
                        value={upstashToken}
                        onChange={(e) => setUpstashToken(e.target.value)}
                        placeholder="AX..."
                        className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition focus:border-[var(--color-accent)] focus:outline-none"
                        style={{ borderColor: "var(--color-border)" }}
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      icon={testingStorage ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} className="text-[var(--color-accent)]" />}
                      disabled={testingStorage}
                      onClick={handleTestStorage}
                    >
                      {testingStorage ? "Testing Ping..." : "Test Upstash Connection"}
                    </Button>

                    <span className="text-[11px] text-[var(--color-text-muted)]">
                      Zero npm package needed · Uses native fetch REST API
                    </span>
                  </div>
                </div>
              )}

              {/* Interactive Inputs for GitHub */}
              {storageEngine === "github" && (
                <div className="rounded-xl border p-4 space-y-3.5 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-semibold text-[var(--color-text)]">GitHub Cloud Commit Credentials</h4>
                      <p className="text-[11px] text-[var(--color-text-muted)] mt-0.5">
                        Generate a Personal Access Token with <code className="font-mono text-[10px]">repo</code> or <code className="font-mono text-[10px]">contents:write</code> scope.
                      </p>
                    </div>
                    <a
                      href="https://github.com/settings/tokens"
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] text-[var(--color-accent)] hover:underline font-medium"
                    >
                      <span>Generate GitHub Token</span>
                      <ExternalLink size={11} />
                    </a>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1.5 sm:col-span-2">
                      <label className="text-[11px] font-mono font-medium text-[var(--color-text-muted)]">
                        GITHUB_TOKEN
                      </label>
                      <input
                        type="password"
                        value={githubToken}
                        onChange={(e) => setGithubToken(e.target.value)}
                        placeholder="ghp_... or github_pat_..."
                        className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition focus:border-[var(--color-accent)] focus:outline-none"
                        style={{ borderColor: "var(--color-border)" }}
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono font-medium text-[var(--color-text-muted)]">
                        GITHUB_BRANCH
                      </label>
                      <input
                        value={githubBranch}
                        onChange={(e) => setGithubBranch(e.target.value)}
                        placeholder="main"
                        className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition focus:border-[var(--color-accent)] focus:outline-none"
                        style={{ borderColor: "var(--color-border)" }}
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-mono font-medium text-[var(--color-text-muted)]">
                      GITHUB_REPO (owner/repo)
                    </label>
                    <input
                      value={githubRepo}
                      onChange={(e) => setGithubRepo(e.target.value)}
                      placeholder="Azeem1252/gaming-editorial"
                      className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition focus:border-[var(--color-accent)] focus:outline-none"
                      style={{ borderColor: "var(--color-border)" }}
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      icon={testingStorage ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} className="text-[var(--color-accent)]" />}
                      disabled={testingStorage}
                      onClick={handleTestStorage}
                    >
                      {testingStorage ? "Verifying..." : "Verify GitHub Write Permission"}
                    </Button>

                    <span className="text-[11px] text-[var(--color-text-muted)]">
                      Serverless route commits directly to GitHub repo
                    </span>
                  </div>
                </div>
              )}

              {/* Multi-Website Guidance Card */}
              <div className="rounded-xl border p-3.5 space-y-1.5 text-xs bg-[var(--color-bg-soft)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                  <Layers size={14} className="text-[var(--color-accent)]" />
                  <span>Connecting 2 or More Different Websites?</span>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  Each website has its own entry in the <strong>Websites</strong> tab. On Vercel, set each project&apos;s <code className="font-mono text-[10px]">GITHUB_REPO</code> to its own repository (e.g. <code className="font-mono text-[10px]">user/gaming-site</code> vs <code className="font-mono text-[10px]">user/tech-blog</code>). Your single <code className="font-mono text-[10px]">GITHUB_TOKEN</code> works across all repos! When publishing or scheduling, the agent directs articles to the selected website with zero cross-talk.
                </p>
              </div>

              {/* Test Result Banner */}
              {storageTestResult && (
                <div
                  className={`rounded-xl border p-3 flex items-start gap-2.5 text-xs ${
                    storageTestResult.success
                      ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                      : "border-amber-500/30 bg-amber-500/10 text-amber-300"
                  }`}
                >
                  {storageTestResult.success ? (
                    <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="font-semibold">{storageTestResult.success ? "Storage Connection Verified" : "Verification Notice"}</p>
                    <p className="text-[11px] opacity-90 mt-0.5">{storageTestResult.message}</p>
                  </div>
                </div>
              )}

              {/* Compiled Environment Variables Output */}
              <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
                <div
                  className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
                  style={{ borderColor: "var(--color-border)", background: "#161B22" }}
                >
                  <div className="flex items-center gap-2">
                    <span className="flex gap-1.5">
                      <span className="h-2.5 w-2.5 rounded-full bg-red-500/80 inline-block" />
                      <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/80 inline-block" />
                      <span className="h-2.5 w-2.5 rounded-full bg-green-500/80 inline-block" />
                    </span>
                    <span className="font-mono text-[11px] font-semibold text-[#C9D1D9]">
                      .env.local &amp; Vercel Environment Variables
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyEnvBlock}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
                  >
                    {copiedEnv ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                    <span>{copiedEnv ? "Copied!" : "Copy .env Block"}</span>
                  </button>
                </div>
                <pre className="max-h-56 overflow-x-auto whitespace-pre-wrap bg-[#0D1117] p-4 text-[12px] font-mono leading-relaxed text-[#C9D1D9]">
                  {getCompiledEnvBlock()}
                </pre>
              </div>

              {/* 3-Step Deployment Checklist */}
              <div className="rounded-xl border p-4 text-xs space-y-2.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}>
                <h4 className="font-semibold text-[var(--color-text)] flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-[var(--color-live)]" />
                  <span>3-Step Serverless Deployment Checklist (Do this once)</span>
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  <li>
                    <strong>Add the two route files — pick one way</strong>: Easiest: open the <button onClick={() => setSnippetTab("prompt")} className="text-[var(--color-accent)] underline cursor-pointer">AI Prompt</button> tab, copy the prompt into Cursor/Claude Code, and let the agent create both files and verify them. Manual: copy the <button onClick={() => setSnippetTab("code")} className="text-[var(--color-accent)] underline cursor-pointer">Route Snippet</button> (<code className="font-mono text-[10px]">src/app/api/posts/route.ts</code>) and <button onClick={() => setSnippetTab("lib")} className="text-[var(--color-accent)] underline cursor-pointer">Reader Helper</button> (<code className="font-mono text-[10px]">src/lib/posts.ts</code>) yourself.
                  </li>
                  <li>
                    <strong>Paste environment variables into Vercel</strong>: Go to <strong>Vercel Dashboard &gt; Your Project &gt; Settings &gt; Environment Variables</strong>, paste the block above, and click Save.
                  </li>
                  <li className="text-amber-300 font-semibold">
                    <strong>CRITICAL: Click Redeploy on Vercel</strong>: Go to <strong>Deployments &gt; ... &gt; Redeploy</strong>. Existing running Lambda containers will NOT see your new variables until redeployed!
                  </li>
                </ol>
              </div>
            </div>
          )}

          {/* VIEW 2: SERVER + FRONTEND WITHOUT DATABASE (VPS / DOCKER / RENDER) */}
          {activeArch === "vps_nodb" && (
            <div className="space-y-4">
              <div className="rounded-xl border p-4 text-xs space-y-2 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                  <Server size={16} className="text-[var(--color-accent)]" />
                  <span>Persistent Local Disk Writing IS Supported on Real Servers!</span>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  Unlike serverless Lambda containers, if your website runs on a persistent server (a VPS, DigitalOcean droplet, Docker container, or Node server on Railway/Render):
                </p>
                <div className="rounded-lg border p-3 bg-[var(--color-bg-soft)] space-y-1.5 font-mono text-[11px] text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
                  <p className="text-emerald-400 font-semibold">// 1. Save directly to disk in your /api/posts handler with zero cloud database:</p>
                  <p>const postsDir = path.join(process.cwd(), &quot;content&quot;, &quot;posts&quot;);</p>
                  <p>if (!fs.existsSync(postsDir)) fs.mkdirSync(postsDir, &#123; recursive: true &#125;);</p>
                  <p>fs.writeFileSync(path.join(postsDir, `$&#123;slug&#125;.json`), JSON.stringify(article, null, 2));</p>
                  <p className="text-emerald-400 pt-1">// 2. Or write directly to an embedded SQLite file (posts.db) with sqlite3.</p>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)]">
                  You only need to set <code className="font-mono text-amber-300">AGENT_SECRET_TOKEN</code> in your server&apos;s environment. No external Redis, Postgres, or GitHub token is required!
                </p>
              </div>
            </div>
          )}

          {/* VIEW 3: STATIC FRONTEND-ONLY / JAMSTACK (VITE / REACT / GITHUB PAGES) */}
          {activeArch === "static_frontend" && (
            <div className="space-y-4">
              <div className="rounded-xl border p-4 text-xs space-y-2.5 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                  <Globe size={16} className="text-[var(--color-accent)]" />
                  <span>How to Automate Publishing for Static Frontend-Only Sites</span>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  If your site has NO server (e.g. Vite SPA, React on GitHub Pages, Astro or Gatsby static export, Cloudflare Pages static build), there is no backend to host an <code className="font-mono text-[10px]">/api/posts</code> route. You can automate publishing via two proven methods:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="rounded-xl border p-3 bg-[var(--color-bg-soft)] space-y-1" style={{ borderColor: "var(--color-border)" }}>
                    <h5 className="font-semibold text-xs text-[var(--color-text)]">Option A: GitHub Actions Auto-Build</h5>
                    <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                      Use the agent&apos;s GitHub Cloud Commit engine to commit articles directly to <code className="font-mono text-[10px]">content/posts/*.json</code>. Set up a GitHub Action to rebuild and redeploy your static site on every push!
                    </p>
                  </div>
                  <div className="rounded-xl border p-3 bg-[var(--color-bg-soft)] space-y-1" style={{ borderColor: "var(--color-border)" }}>
                    <h5 className="font-semibold text-xs text-[var(--color-text)]">Option B: Client-Side Upstash / Supabase</h5>
                    <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                      The agent writes articles to Upstash Redis REST. Your React app fetches published articles directly from Upstash in the browser using public read-only keys.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW 4: DATABASE-BACKED (PRISMA / SUPABASE / SQL) */}
          {activeArch === "database" && (
            <div className="space-y-4">
              <div className="rounded-xl border p-4 text-xs space-y-2 bg-[var(--color-bg-elev)]" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                  <Database size={16} className="text-[var(--color-accent)]" />
                  <span>Integrating with Your Existing Database (Prisma / SQL)</span>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  If your project already uses Prisma, Drizzle, Supabase, or PostgreSQL, simply replace the file storage in <code className="font-mono text-[10px]">/api/posts/route.ts</code> with a database upsert:
                </p>
                <pre className="rounded-lg border p-3 bg-[#0D1117] font-mono text-[11px] text-[#C9D1D9] overflow-x-auto">
{`// Inside POST handler in src/app/api/posts/route.ts:
await prisma.post.upsert({
  where: { slug: cleanSlug },
  update: {
    title: article.title,
    content: article.content,
    html: article.html,
    excerpt: article.excerpt,
    heroImageUrl: article.hero_image_url,
    publishedAt: new Date(article.publishedAt),
  },
  create: {
    slug: cleanSlug,
    title: article.title,
    content: article.content,
    html: article.html,
    excerpt: article.excerpt,
    heroImageUrl: article.hero_image_url,
    publishedAt: new Date(article.publishedAt),
  }
});`}
                </pre>
                <p className="text-[11px] text-[var(--color-text-muted)]">
                  The article will immediately be saved into your database and rendered by your regular dynamic queries!
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 1: AI Coding Agent Setup Prompt */}
      {snippetTab === "prompt" && (
        <div className="space-y-3.5">
          {/* Workflow Guide */}
          <div
            className="rounded-xl border p-4 text-xs leading-relaxed text-[var(--color-text-muted)]"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
          >
            <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
              <Bot size={15} className="text-[var(--color-accent)]" />
              <span>One prompt does everything — no other tab required</span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed">
              This prompt <strong>already contains the exact, tested code</strong> for <code className="font-mono text-[10px]">route.ts</code> and <code className="font-mono text-[10px]">posts.ts</code> — you do <strong>not</strong> need to copy the Route Handler or Reader Helper tabs. Open your repo in <strong>Cursor Composer</strong> (<kbd className="rounded border bg-[var(--color-bg-elev)] px-1.5 py-0.5 text-[10px] font-mono">Cmd+I</kbd>), <strong>Claude Code</strong>, or <strong>GitHub Copilot Chat</strong>, paste the whole prompt, and the agent creates both files, wires authentication, adds storage, and verifies everything.
            </p>
            <div className="mt-2.5 grid grid-cols-1 gap-1.5 sm:grid-cols-4">
              {["1 · Paste prompt into your AI agent", "2 · Agent creates both files + .env.local", "3 · Add cloud storage vars (only if deploying to Vercel/Netlify)", "4 · Verify with the cURL Test tab"].map((s) => (
                <div key={s} className="rounded-md border bg-[var(--color-bg-elev)] px-2 py-1.5 text-[10px] font-medium text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>
                  {s}
                </div>
              ))}
            </div>
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              <span className="rounded-md border bg-[var(--color-bg-elev)] px-2 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>Cursor Composer (Cmd+I)</span>
              <span className="rounded-md border bg-[var(--color-bg-elev)] px-2 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>Claude Code</span>
              <span className="rounded-md border bg-[var(--color-bg-elev)] px-2 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>GitHub Copilot</span>
              <span className="rounded-md border bg-[var(--color-bg-elev)] px-2 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]" style={{ borderColor: "var(--color-border)" }}>ChatGPT / Claude Web</span>
            </div>
          </div>

          {/* Architectural Guarantees Grid */}
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <div className="flex items-center gap-1.5 rounded-lg border bg-[var(--color-bg)] px-2.5 py-2 text-[11px] text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
              <CheckCircle2 size={13} className="text-[var(--color-live)] shrink-0" />
              <span className="truncate">src/app & app Auto-Detect</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border bg-[var(--color-bg)] px-2.5 py-2 text-[11px] text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
              <CheckCircle2 size={13} className="text-[var(--color-live)] shrink-0" />
              <span className="truncate">Serverless EROFS Safe</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border bg-[var(--color-bg)] px-2.5 py-2 text-[11px] text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
              <CheckCircle2 size={13} className="text-[var(--color-live)] shrink-0" />
              <span className="truncate">revalidatePath Cache</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-lg border bg-[var(--color-bg)] px-2.5 py-2 text-[11px] text-[var(--color-text)]" style={{ borderColor: "var(--color-border)" }}>
              <CheckCircle2 size={13} className="text-[var(--color-live)] shrink-0" />
              <span className="truncate">Frontend Route Wires</span>
            </div>
          </div>

          {/* Dynamic Token Interpolation Control */}
          <div
            className="rounded-xl border p-3.5 space-y-2.5"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}
          >
            <div className="flex flex-wrap items-center justify-between gap-1.5">
              <div className="flex items-center gap-1.5">
                <Key size={13} className="text-[var(--color-accent)]" />
                <span className="text-xs font-semibold text-[var(--color-text)]">
                  Bearer Secret Token
                </span>
                <span
                  className="rounded-md border bg-[var(--color-bg-soft)] px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  AGENT_SECRET_TOKEN
                </span>
              </div>
              <span className="text-[11px] text-[var(--color-text-muted)]">
                Auto-injected into the prompt (token + endpoint placeholders)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative min-w-0 flex-1">
                <input
                  value={promptSecretToken}
                  onChange={(e) => setPromptSecretToken(e.target.value)}
                  placeholder="nxt_sec_..."
                  className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition-colors focus:border-[var(--color-accent)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                  style={{ borderColor: "var(--color-border)" }}
                />
              </div>
              <button
                type="button"
                onClick={handleCopyTokenOnly}
                className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs font-medium text-[var(--color-text)] shadow-xs transition hover:bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)] active:scale-95 cursor-pointer"
                style={{ borderColor: "var(--color-border)" }}
                title="Copy token to clipboard"
              >
                {copiedToken ? <Check size={12} className="text-[var(--color-live)]" /> : <Copy size={12} />}
                <span>{copiedToken ? "Copied!" : "Copy Token"}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  const t = generateRandomToken();
                  setPromptSecretToken(t);
                }}
                className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg border bg-[var(--color-bg-soft)] px-3 text-xs font-medium text-[var(--color-text)] shadow-xs transition hover:bg-[var(--color-bg-elev)] hover:border-[var(--color-border-strong)] active:scale-95 cursor-pointer"
                style={{ borderColor: "var(--color-border)" }}
                title="Generate a fresh random secret token"
              >
                <RefreshCw size={12} className="text-[var(--color-text-muted)]" />
                <span>Generate New</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <label className="shrink-0 text-[11px] font-medium text-[var(--color-text-muted)]">
                Endpoint URL
              </label>
              <input
                value={curlHost}
                onChange={(e) => setCurlHost(e.target.value)}
                placeholder="https://your-site.vercel.app/api/posts"
                className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition-colors focus:border-[var(--color-accent)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
                style={{ borderColor: "var(--color-border)" }}
              />
            </div>
            <p className="text-[10px] leading-relaxed text-[var(--color-text-muted)]">
              {"Used for the <ENDPOINT_URL> and <SITE_URL> verification commands inside the prompt — your production URL (e.g. https://my-site.vercel.app/api/posts), or http://localhost:3000/api/posts while developing."}
            </p>
          </div>

          {/* Prompt Code Viewer */}
          <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
            <div
              className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
              style={{ borderColor: "var(--color-border)", background: "#161B22" }}
            >
              <div className="flex items-center gap-2">
                <span className="flex gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-500/80 inline-block" />
                </span>
                <span className="font-mono text-[11px] font-medium text-[#C9D1D9]">
                  ai-agent-setup-prompt.md
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopyPromptWithToken(promptSecretToken)}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
              >
                {copiedPrompt ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                <span>{copiedPrompt ? "Copied!" : "Copy Prompt"}</span>
              </button>
            </div>
            <pre className="max-h-80 overflow-x-auto whitespace-pre-wrap bg-[#0D1117] p-4 text-[11px] font-mono leading-relaxed text-[#C9D1D9]">
              {getFormattedPrompt()}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 2: TypeScript Route Handler */}
      {snippetTab === "code" && (
        <div className="space-y-3.5">
          {/* Route Overview Banner */}
          <div
            className="rounded-xl border p-4 text-xs leading-relaxed text-[var(--color-text-muted)]"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                <Code2 size={15} className="text-[var(--color-accent)]" />
                <span>Drop-in Route Handler for Next.js App Router</span>
              </div>
              <span className="rounded-md bg-[var(--color-bg-elev)] px-2 py-0.5 font-mono text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                Zero External NPM Dependencies
              </span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed">
              Place this file at <code className="font-mono text-[11px] text-[var(--color-text)] font-semibold">src/app/api/posts/route.ts</code> (or <code className="font-mono text-[11px] text-[var(--color-text)]">app/api/posts/route.ts</code>). It handles GET health checks, authenticated POST publishing, serverless <code className="font-mono text-[10px]">os.tmpdir()</code> fallback, and on-demand cache revalidation.
            </p>
          </div>

          {/* TypeScript Code Box */}
          <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
            <div
              className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
              style={{ borderColor: "var(--color-border)", background: "#161B22" }}
            >
              <div className="flex items-center gap-2">
                <span className="flex gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-500/80 inline-block" />
                </span>
                <span className="font-mono text-[11px] font-semibold text-[#C9D1D9]">
                  src/app/api/posts/route.ts
                </span>
                <span className="rounded bg-white/10 px-1.5 py-0.2 text-[10px] font-mono text-white/80">
                  TypeScript
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(snippetData.snippet || snippetData.code || "");
                  setCopiedCode(true);
                  setTimeout(() => setCopiedCode(false), 2000);
                  push({
                    title: "Route code copied",
                    description: "Paste into src/app/api/posts/route.ts",
                    variant: "success",
                  });
                }}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
              >
                {copiedCode ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                <span>{copiedCode ? "Copied!" : "Copy Code"}</span>
              </button>
            </div>
            <pre className="max-h-96 overflow-x-auto bg-[#0D1117] p-4 text-[12px] font-mono leading-relaxed text-[#C9D1D9]">
              {snippetData.snippet || snippetData.code}
            </pre>
          </div>
        </div>
      )}

      {/* Tab: TypeScript Reader Helper (posts.ts) */}
      {snippetTab === "lib" && (
        <div className="space-y-3.5">
          {/* Reader Overview Banner */}
          <div
            className="rounded-xl border p-4 text-xs leading-relaxed text-[var(--color-text-muted)]"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-semibold text-[var(--color-text)]">
                <FileCode size={15} className="text-[var(--color-accent)]" />
                <span>Universal Reader Helper for Next.js App Router</span>
              </div>
              <span className="rounded-md bg-[var(--color-bg-elev)] px-2 py-0.5 font-mono text-[10px] text-[var(--color-text-muted)] border" style={{ borderColor: "var(--color-border)" }}>
                src/lib/posts.ts
              </span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed">
              Place this helper file at <code className="font-mono text-[11px] text-[var(--color-text)] font-semibold">src/lib/posts.ts</code>. It provides <code className="font-mono text-[10px]">getPostBySlugAsync(slug)</code> and <code className="font-mono text-[10px]">getAllPostsAsync()</code> which automatically check Upstash Redis REST, GitHub Raw CDN, and local disk, preventing 404 errors on serverless.
            </p>
          </div>

          {/* TypeScript Code Box */}
          <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
            <div
              className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
              style={{ borderColor: "var(--color-border)", background: "#161B22" }}
            >
              <div className="flex items-center gap-2">
                <span className="flex gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/80 inline-block" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-500/80 inline-block" />
                </span>
                <span className="font-mono text-[11px] font-semibold text-[#C9D1D9]">
                  src/lib/posts.ts
                </span>
                <span className="rounded bg-white/10 px-1.5 py-0.2 text-[10px] font-mono text-white/80">
                  TypeScript
                </span>
              </div>
              <button
                type="button"
                onClick={handleCopyLibCode}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
              >
                {copiedLibCode ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                <span>{copiedLibCode ? "Copied!" : "Copy Code"}</span>
              </button>
            </div>
            <pre className="max-h-96 overflow-x-auto bg-[#0D1117] p-4 text-[12px] font-mono leading-relaxed text-[#C9D1D9]">
              {snippetData.lib_posts || "// Loading reader helper..."}
            </pre>
          </div>
        </div>
      )}

      {/* Tab: Diagnostic cURL Test */}
      {snippetTab === "curl" && (
        <div className="space-y-4">
          {/* Target Host Selector */}
          <div
            className="rounded-xl border p-4 space-y-3"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}
          >
            <div className="flex flex-wrap items-center justify-between gap-1.5">
              <div className="flex items-center gap-1.5">
                <Server size={14} className="text-[var(--color-accent)]" />
                <span className="text-xs font-semibold text-[var(--color-text)]">
                  Target Endpoint URL
                </span>
              </div>
              <span className="text-[11px] text-[var(--color-text-muted)]">
                cURL commands below automatically update to target this endpoint
              </span>
            </div>

            {/* Quick URL presets */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setCurlHost("http://localhost:3000/api/posts")}
                className={`rounded-md border px-2.5 py-1 text-[11px] font-mono transition cursor-pointer ${
                  curlHost === "http://localhost:3000/api/posts"
                    ? "border-[var(--color-accent)] bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                    : "border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                }`}
              >
                localhost:3000/api/posts
              </button>

              {websites.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  onClick={async () => {
                    setCurlHost(w.url);
                    try {
                      const res = await api.getWebsiteSecretToken(w.id);
                      if (res.secret_token) setPromptSecretToken(res.secret_token);
                    } catch {
                      // Leave the token field for the user to fill manually.
                    }
                  }}
                  className={`rounded-md border px-2.5 py-1 text-[11px] font-mono transition cursor-pointer ${
                    curlHost === w.url
                      ? "border-[var(--color-accent)] bg-[var(--color-bg-soft)] text-[var(--color-text)] font-semibold"
                      : "border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                  }`}
                >
                  {w.name} ({w.url})
                </button>
              ))}
            </div>

            <input
              value={curlHost}
              onChange={(e) => setCurlHost(e.target.value)}
              placeholder="https://your-domain.vercel.app/api/posts"
              className="h-9 w-full rounded-lg border bg-[var(--color-bg)] px-3 text-xs font-mono text-[var(--color-text)] shadow-xs transition-colors focus:border-[var(--color-accent)] focus:outline-none focus:ring-1 focus:ring-[var(--color-accent)]"
              style={{ borderColor: "var(--color-border)" }}
            />
          </div>

          {/* Test 1: Health Ping (GET) */}
          <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
            <div
              className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
              style={{ borderColor: "var(--color-border)", background: "#161B22" }}
            >
              <div>
                <span className="font-semibold text-[#C9D1D9]">1. Endpoint Health Check (GET)</span>
                <span className="ml-2 text-[10px] text-[#8B949E]">Expects HTTP 200 {`{"status": "ready"}`}</span>
              </div>
              <button
                type="button"
                onClick={handleCopyGetCurl}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
              >
                {copiedGetCurl ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                <span>{copiedGetCurl ? "Copied!" : "Copy GET cURL"}</span>
              </button>
            </div>
            <pre className="overflow-x-auto bg-[#0D1117] p-4 text-[12px] font-mono leading-relaxed text-[#C9D1D9]">
              {getFormattedGetCurl()}
            </pre>
          </div>

          {/* Test 2: Authenticated Publishing Probe (POST) */}
          <div className="overflow-hidden rounded-xl border" style={{ borderColor: "var(--color-border)" }}>
            <div
              className="flex items-center justify-between border-b px-4 py-2.5 text-xs text-[var(--color-text-muted)]"
              style={{ borderColor: "var(--color-border)", background: "#161B22" }}
            >
              <div>
                <span className="font-semibold text-[#C9D1D9]">2. Authenticated Publish Probe (POST)</span>
                <span className="ml-2 text-[10px] text-[#8B949E]">Tests Bearer auth & article storage</span>
              </div>
              <button
                type="button"
                onClick={handleCopyPostCurl}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-[#58A6FF] hover:underline cursor-pointer"
              >
                {copiedPostCurl ? <Check size={11} className="text-[var(--color-live)]" /> : <Copy size={11} />}
                <span>{copiedPostCurl ? "Copied!" : "Copy POST cURL"}</span>
              </button>
            </div>
            <pre className="overflow-x-auto whitespace-pre-wrap bg-[#0D1117] p-4 text-[12px] font-mono leading-relaxed text-[#C9D1D9]">
              {getFormattedPostCurl()}
            </pre>
          </div>
        </div>
      )}

      {/* Tab: Troubleshooting & Automated Diagnostics */}
      {snippetTab === "troubleshoot" && (
        <div className="space-y-4">
          {/* Header Banner */}
          <div
            className="rounded-xl border p-4 space-y-2"
            style={{ borderColor: "var(--color-border)", background: "var(--color-bg-soft)" }}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <HelpCircle size={16} className="text-amber-400" />
                <span className="text-xs font-bold text-[var(--color-text)]">
                  Knowledge Base & Automated Diagnostics Center
                </span>
                <span className="rounded-full bg-amber-500/10 text-amber-400 px-2 py-0.5 text-[10px] font-semibold border border-amber-500/20">
                  8 Common Scenarios
                </span>
              </div>
              <span className="text-[11px] text-[var(--color-text-muted)]">
                Instant fixes for serverless, multi-site, auth, and image errors
              </span>
            </div>
            <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
              Every known obstacle when connecting websites—from Vercel read-only filesystem limits and stale environment variables to multi-website isolation and Next.js image domain configurations—is diagnosed below with verified solutions.
            </p>

            {/* Filter Chips & Search Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 pt-2 border-t" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: "all", label: "All Scenarios" },
                  { id: "serverless", label: "Serverless & Vercel" },
                  { id: "multisite", label: "2+ Websites" },
                  { id: "images", label: "Next.js Images" },
                  { id: "auth", label: "Auth & CORS" },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setTroubleshootFilter(f.id as any)}
                    className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition cursor-pointer border ${
                      troubleshootFilter === f.id
                        ? "bg-[var(--color-accent)]/15 border-[var(--color-accent)] text-[var(--color-text)] font-semibold"
                        : "bg-[var(--color-bg-elev)] border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text)]"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]" />
                <input
                  type="text"
                  placeholder="Filter problems..."
                  value={troubleshootSearch}
                  onChange={(e) => setTroubleshootSearch(e.target.value)}
                  className="rounded-lg border bg-[var(--color-bg-elev)] pl-8 pr-3 py-1 text-[11px] text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] focus:outline-none focus:border-[var(--color-accent)] w-full sm:w-44"
                  style={{ borderColor: "var(--color-border)" }}
                />
              </div>
            </div>
          </div>

          {/* Diagnostic Cards List */}
          <div className="space-y-3.5">
            {/* Card 1: 404 on Vercel After Publishing (EROFS / Ephemeral Disk + Stale Env Vars) */}
            {(troubleshootFilter === "all" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "404 vercel serverless erofs redeploy stale env".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(239, 68, 68, 0.3)", background: "rgba(239, 68, 68, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-red-500/15 text-red-400 px-1.5 py-0.5 text-[10px] font-bold border border-red-500/25">
                      CRITICAL #1
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      404 Not Found on Vercel / Netlify / Lambda After Publishing
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                      EROFS Ephemeral Disk
                    </span>
                    <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-mono text-amber-400">
                      Redeploy Required
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Symptom:</strong> The Content Pipeline Studio or cURL probe returns <code className="font-mono text-emerald-400">200 OK</code>, but opening <code className="font-mono text-[var(--color-text)]">/posts/your-slug</code> on your live Vercel domain displays a Next.js 404 page.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">Why it happens:</strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-[11px]">
                    <li>
                      <strong>Ephemeral Container:</strong> Vercel Lambda runs in an isolated read-only container. Writing to <code className="font-mono text-[10px]">/tmp</code> or disk disappears when the serverless container sleeps or scales down.
                    </li>
                    <li>
                      <strong>Stale Environment Variables:</strong> Adding <code className="font-mono text-[10px]">GITHUB_TOKEN</code> to Vercel Settings does <em>NOT</em> update already-running deployments. You must trigger a Redeploy.
                    </li>
                    <li>
                      <strong>App Router Static Fallback:</strong> If <code className="font-mono text-[10px]">dynamicParams = false</code>, Next.js blocks any slug not pre-generated at build time.
                    </li>
                  </ul>
                </div>

                {/* The 3-Step Fix */}
                <div className="rounded-lg border p-3 space-y-2" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                  <div className="text-[11px] font-semibold text-[var(--color-text)] flex items-center gap-1.5">
                    <CheckCircle2 size={13} className="text-emerald-400" />
                    <span>The Complete 3-Step Solution:</span>
                  </div>
                  <ol className="list-decimal pl-5 space-y-1.5 text-[11px] text-[var(--color-text-muted)]">
                    <li>
                      <strong>Add GITHUB_TOKEN & GITHUB_REPO to Vercel Settings:</strong> In your Vercel Dashboard, go to <em>Settings -&gt; Environment Variables</em>. Add <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_TOKEN</code> and <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_REPO=username/repo-name</code>.
                    </li>
                    <li>
                      <strong className="text-amber-400">CRITICAL - Trigger a Redeploy:</strong> In Vercel Dashboard, navigate to <strong>Deployments</strong> tab -&gt; click the three dots (<code className="font-mono">...</code>) on the active Production deployment -&gt; select <strong>Redeploy</strong>. (Without this step, Vercel will never see your new environment variables!).
                    </li>
                    <li>
                      <strong>Ensure Dynamic Routing in Next.js:</strong> In <code className="font-mono text-[10px] text-[var(--color-text)]">src/app/posts/[slug]/page.tsx</code>, export dynamic parameters:
                    </li>
                  </ol>

                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded bg-[#0D1117] p-2.5 text-[11px] font-mono text-[#C9D1D9]">
{`// src/app/posts/[slug]/page.tsx
export const dynamicParams = true; // Allows newly published articles to load dynamically
export const revalidate = 0;        // Or set to 60 for ISR`}
                    </pre>
                    <button
                      type="button"
                      onClick={() => copyTroubleshootSnippet("dynparams", "export const dynamicParams = true;\nexport const revalidate = 0;", "Dynamic params snippet")}
                      className="absolute right-2 top-2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white hover:bg-white/20 transition cursor-pointer"
                    >
                      {copiedTroubleshootId === "dynparams" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Card 2: Connecting 2+ Different Serverless Blog Websites (Multi-Site Architecture) */}
            {(troubleshootFilter === "all" || troubleshootFilter === "multisite" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "2 websites multiple multi site serverless separate collisions".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(59, 130, 246, 0.3)", background: "rgba(59, 130, 246, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-blue-500/15 text-blue-400 px-1.5 py-0.5 text-[10px] font-bold border border-blue-500/25">
                      ARCHITECTURE
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Connecting 2+ Different Serverless Blog Websites (Multi-Site Isolation)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="rounded bg-blue-500/15 px-1.5 py-0.5 text-[10px] font-mono text-blue-400">
                      Single GitHub PAT
                    </span>
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                      Zero Collisions
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Question:</strong> <em>"What if I add 2 different serverless blog websites? How will it be handled? Will articles overwrite or collide?"</em>
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">The Answer:</strong> Content Pipeline Agent provides <strong>complete isolation</strong> between multiple websites. Each website has its own independent database record, endpoint URL, secret key, and scheduling configuration.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {/* Website A Setup */}
                  <div className="rounded-lg border p-3 space-y-1.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
                      <Globe size={13} className="text-cyan-400" />
                      <span>Website 1: Gaming Editorial</span>
                    </div>
                    <ul className="text-[10px] space-y-1 text-[var(--color-text-muted)] font-mono">
                      <li>• Studio Endpoint: <span className="text-[var(--color-text)]">https://gaming.vercel.app/api/posts</span></li>
                      <li>• Vercel Repo: <span className="text-[var(--color-text)]">GITHUB_REPO=user/gaming-editorial</span></li>
                      <li>• Vercel Secret: <span className="text-[var(--color-text)]">ADMIN_API_KEY=secret_site_1</span></li>
                      <li>• GitHub Token: <span className="text-emerald-400">Your GitHub PAT</span></li>
                    </ul>
                  </div>

                  {/* Website B Setup */}
                  <div className="rounded-lg border p-3 space-y-1.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-[var(--color-text)]">
                      <Globe size={13} className="text-purple-400" />
                      <span>Website 2: Tech Reviews</span>
                    </div>
                    <ul className="text-[10px] space-y-1 text-[var(--color-text-muted)] font-mono">
                      <li>• Studio Endpoint: <span className="text-[var(--color-text)]">https://tech.vercel.app/api/posts</span></li>
                      <li>• Vercel Repo: <span className="text-[var(--color-text)]">GITHUB_REPO=user/tech-reviews</span></li>
                      <li>• Vercel Secret: <span className="text-[var(--color-text)]">ADMIN_API_KEY=secret_site_2</span></li>
                      <li>• GitHub Token: <span className="text-emerald-400">Same GitHub PAT!</span></li>
                    </ul>
                  </div>
                </div>

                <div className="rounded-lg border p-3 space-y-1.5 text-[11px] text-[var(--color-text-muted)] leading-relaxed" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                  <div className="font-semibold text-[var(--color-text)] flex items-center gap-1.5">
                    <HelpCircle size={13} className="text-amber-400" />
                    <span>Can you use 1 GitHub Token for both websites?</span>
                  </div>
                  <p>
                    <strong className="text-emerald-400">YES, absolutely!</strong> A single GitHub Personal Access Token (PAT) with <code className="font-mono text-[10px] text-[var(--color-text)]">repo</code> scope works for every repository owned by your GitHub account. You can paste the exact same <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_TOKEN</code> into Vercel Project 1 and Vercel Project 2. Because each Vercel project has its own <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_REPO</code> setting, commits go directly to their respective repositories with zero conflict.
                  </p>
                </div>
              </div>
            )}

            {/* Card 3: Server + Frontend with NO Database (VPS / Docker / Railway / Render) */}
            {(troubleshootFilter === "all" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "server frontend no database vps docker sqlite disk local".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(16, 185, 129, 0.3)", background: "rgba(16, 185, 129, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 text-[10px] font-bold border border-emerald-500/25">
                      ZERO DATABASE
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Server & Frontend with NO Database (VPS / Docker / Railway / Render)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-[10px] font-mono text-emerald-400">
                      Persistent Disk
                    </span>
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                      $0 Setup
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Scenario:</strong> You run Next.js, Node.js, Express, or Docker on a VPS (DigitalOcean, Hetzner, AWS EC2, Railway, Render) and <em>do not want to configure or pay for an external database</em>.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">The Solution:</strong> Unlike serverless Vercel lambdas, a dedicated server or VPS has a <strong>permanent filesystem</strong>. You can write articles directly to disk as JSON or Markdown, or use an embedded zero-config SQLite file:
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  <div className="rounded-lg border p-3 space-y-1.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                    <div className="text-xs font-semibold text-[var(--color-text)]">Approach A: Local JSON Files</div>
                    <p className="text-[11px] text-[var(--color-text-muted)]">
                      Save each article directly into <code className="font-mono text-[10px]">content/posts/[slug].json</code> with <code className="font-mono text-[10px]">fs.promises.writeFile</code>. Next.js can read them instantly via <code className="font-mono text-[10px]">fs.readFileSync</code>. Zero network requests, zero latency.
                    </p>
                  </div>
                  <div className="rounded-lg border p-3 space-y-1.5" style={{ borderColor: "var(--color-border)", background: "var(--color-bg-elev)" }}>
                    <div className="text-xs font-semibold text-[var(--color-text)]">Approach B: Embedded SQLite</div>
                    <p className="text-[11px] text-[var(--color-text-muted)]">
                      Install <code className="font-mono text-[10px]">better-sqlite3</code> or <code className="font-mono text-[10px]">sqlite3</code>. All posts reside in a single file (<code className="font-mono text-[10px]">posts.db</code>) on disk. Supports instant SQL queries, tags, and full-text search without hosting a database server.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Card 4: Static Frontend-Only Websites (Vite SPA / React / GitHub Pages / Astro Static) */}
            {(troubleshootFilter === "all" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "static frontend only vite spa github pages astro jamstack".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(168, 85, 247, 0.3)", background: "rgba(168, 85, 247, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-purple-500/15 text-purple-400 px-1.5 py-0.5 text-[10px] font-bold border border-purple-500/25">
                      STATIC SPA
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Static Frontend-Only Websites (Vite SPA, GitHub Pages, Astro Static)
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="rounded bg-purple-500/15 px-1.5 py-0.5 text-[10px] font-mono text-purple-400">
                      No Server Route
                    </span>
                    <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                      GitHub Actions
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Scenario:</strong> Your site is a pure static frontend (Vite React app, Astro static site, or GitHub Pages) with no Node.js runtime or backend server to host <code className="font-mono text-[10px]">/api/posts</code>.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">How to Automate:</strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-[11px]">
                    <li>
                      <strong>Path 1 (Git Push + GitHub Actions - Recommended):</strong> Push generated articles directly into your GitHub repository using GitHub's REST API. Configure a GitHub Actions workflow that automatically rebuilds and deploys your static site whenever a new article file is committed to <code className="font-mono text-[10px]">content/posts/*.json</code>.
                    </li>
                    <li>
                      <strong>Path 2 (Client-Side Fetch):</strong> Let the pipeline publish articles to Upstash Redis REST. In your Vite/React component, fetch the article directly in a <code className="font-mono text-[10px]">useEffect</code> hook:
                    </li>
                  </ul>

                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded bg-[#0D1117] p-2.5 text-[11px] font-mono text-[#C9D1D9]">
{`// In your Vite / React component:
const res = await fetch(\`\${UPSTASH_URL}/get/post:\${slug}\`, {
  headers: { Authorization: \`Bearer \${UPSTASH_READ_TOKEN}\` }
});
const post = JSON.parse((await res.json()).result);`}
                    </pre>
                    <button
                      type="button"
                      onClick={() => copyTroubleshootSnippet("vitefetch", "const res = await fetch(`${UPSTASH_URL}/get/post:${slug}`, {\n  headers: { Authorization: `Bearer ${UPSTASH_READ_TOKEN}` }\n});\nconst post = JSON.parse((await res.json()).result);", "Vite client fetch snippet")}
                      className="absolute right-2 top-2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white hover:bg-white/20 transition cursor-pointer"
                    >
                      {copiedTroubleshootId === "vitefetch" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Card 5: Route Handler Returns "github_api": false or HTTP 500 */}
            {(troubleshootFilter === "all" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "github_api false 500 error bad credentials permissions token".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(245, 158, 11, 0.3)", background: "rgba(245, 158, 11, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-amber-500/15 text-amber-400 px-1.5 py-0.5 text-[10px] font-bold border border-amber-500/25">
                      GIT ERROR
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Route Handler Returns "github_api": false or HTTP 500
                    </span>
                  </div>
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                    GitHub REST API Probe
                  </span>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Symptom:</strong> The POST response contains <code className="font-mono text-red-400">"github_api": false</code> or the route handler throws a 403 Forbidden error when trying to commit.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">Checklist to Resolve:</strong>
                  </p>
                  <ol className="list-decimal pl-5 space-y-1 text-[11px]">
                    <li>
                      <strong>Token Scope:</strong> Classic Personal Access Tokens (PAT) must have the <code className="font-mono text-[10px] text-[var(--color-text)]">repo</code> scope checked. Fine-grained tokens must have <strong>Repository permissions: Contents -&gt; Read and write</strong>.
                    </li>
                    <li>
                      <strong>Repository Name Format:</strong> Ensure <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_REPO</code> is strictly in <code className="font-mono text-[10px] text-[var(--color-text)]">owner/repo</code> format (e.g. <code className="font-mono text-[10px] text-emerald-400">Azeem1252/gaming-editorial</code>). Do <em>NOT</em> include <code className="font-mono text-[10px]">https://github.com/</code> or trailing slashes.
                    </li>
                    <li>
                      <strong>Default Branch:</strong> Verify your repository's default branch matches <code className="font-mono text-[10px] text-[var(--color-text)]">GITHUB_BRANCH</code> (typically <code className="font-mono text-[10px]">main</code>).
                    </li>
                    <li>
                      <strong>Redeploy Vercel:</strong> Remember that adding environment variables in Vercel requires a manual <strong>Redeploy</strong> of the active production build!
                    </li>
                  </ol>
                </div>
              </div>
            )}

            {/* Card 6: Next.js Image Error: Hostname Not Configured in next.config.js */}
            {(troubleshootFilter === "all" || troubleshootFilter === "images") &&
              (!troubleshootSearch || "image hostname invalid src next.config pollinations unsplash".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(99, 102, 241, 0.3)", background: "rgba(99, 102, 241, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-indigo-500/15 text-indigo-400 px-1.5 py-0.5 text-[10px] font-bold border border-indigo-500/25">
                      NEXT.JS IMAGES
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      Error: Invalid src prop on next/image (Hostname Not Configured)
                    </span>
                  </div>
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                    next.config.js
                  </span>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Symptom:</strong> When opening an article on your website, the page crashes with: <br />
                    <code className="font-mono text-[10px] text-red-400">
                      Error: Invalid src prop (https://image.pollinations.ai/...) on 'next/image', hostname "image.pollinations.ai" is not configured under images in your next.config.js
                    </code>
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">Fix:</strong> Open your <code className="font-mono text-[10px] text-[var(--color-text)]">next.config.js</code> or <code className="font-mono text-[10px] text-[var(--color-text)]">next.config.mjs</code> and configure <code className="font-mono text-[10px] text-[var(--color-text)]">remotePatterns</code>:
                  </p>

                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded bg-[#0D1117] p-2.5 text-[11px] font-mono text-[#C9D1D9]">
{`/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'image.pollinations.ai' },
      { protocol: 'https', hostname: 'images.unsplash.com' },
      { protocol: 'https', hostname: 'raw.githubusercontent.com' },
    ],
  },
};

module.exports = nextConfig;`}
                    </pre>
                    <button
                      type="button"
                      onClick={() => copyTroubleshootSnippet("nextimgconfig", `/** @type {import('next').NextConfig} */\nconst nextConfig = {\n  images: {\n    remotePatterns: [\n      { protocol: 'https', hostname: 'image.pollinations.ai' },\n      { protocol: 'https', hostname: 'images.unsplash.com' },\n      { protocol: 'https', hostname: 'raw.githubusercontent.com' },\n    ],\n  },\n};\n\nmodule.exports = nextConfig;`, "next.config.js snippet")}
                      className="absolute right-2 top-2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white hover:bg-white/20 transition cursor-pointer"
                    >
                      {copiedTroubleshootId === "nextimgconfig" ? "Copied!" : "Copy Config"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Card 7: HTTP 401 Unauthorized / Token Mismatch / Whitespace Issues */}
            {(troubleshootFilter === "all" || troubleshootFilter === "auth") &&
              (!troubleshootSearch || "401 unauthorized token secret whitespace auth trim".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(244, 63, 94, 0.3)", background: "rgba(244, 63, 94, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-rose-500/15 text-rose-400 px-1.5 py-0.5 text-[10px] font-bold border border-rose-500/25">
                      AUTH & SECURITY
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      HTTP 401 Unauthorized: Invalid Secret Token
                    </span>
                  </div>
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                    Bearer Token / Whitespace
                  </span>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Symptom:</strong> The Studio test probe or cURL request returns <code className="font-mono text-red-400">401 Unauthorized: Invalid Secret Token</code>.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">Root Causes & Quick Fixes:</strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-1 text-[11px]">
                    <li>
                      <strong>Trailing Whitespace / Newline:</strong> Copying tokens on Windows or between browser forms frequently introduces invisible newline (<code className="font-mono text-[10px]">\r\n</code>) or space characters.
                    </li>
                    <li>
                      <strong>Robust Trimming in Route Handler:</strong> Ensure your route handler checks tokens using <code className="font-mono text-[10px] text-emerald-400">.trim()</code>:
                    </li>
                  </ul>

                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded bg-[#0D1117] p-2.5 text-[11px] font-mono text-[#C9D1D9]">
{`const authHeader = req.headers.get("authorization") || "";
const clientToken = authHeader.replace(/^Bearer\\s+/i, "").trim() || req.headers.get("x-api-key")?.trim();
const serverToken = process.env.ADMIN_API_KEY?.trim();

if (!serverToken || clientToken !== serverToken) {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}`}
                    </pre>
                    <button
                      type="button"
                      onClick={() => copyTroubleshootSnippet("trimcheck", `const authHeader = req.headers.get("authorization") || "";\nconst clientToken = authHeader.replace(/^Bearer\\s+/i, "").trim() || req.headers.get("x-api-key")?.trim();\nconst serverToken = process.env.ADMIN_API_KEY?.trim();\n\nif (!serverToken || clientToken !== serverToken) {\n  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });\n}`, "Token trim check snippet")}
                      className="absolute right-2 top-2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white hover:bg-white/20 transition cursor-pointer"
                    >
                      {copiedTroubleshootId === "trimcheck" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Card 8: CORS Preflight & Vercel 10s Execution Timeout */}
            {(troubleshootFilter === "all" || troubleshootFilter === "auth" || troubleshootFilter === "serverless") &&
              (!troubleshootSearch || "cors options timeout 504 maxduration 30 preflight".includes(troubleshootSearch.toLowerCase())) && (
              <div
                className="rounded-xl border p-4 space-y-3"
                style={{ borderColor: "rgba(14, 165, 233, 0.3)", background: "rgba(14, 165, 233, 0.03)" }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-sky-500/15 text-sky-400 px-1.5 py-0.5 text-[10px] font-bold border border-sky-500/25">
                      CORS & TIMEOUT
                    </span>
                    <span className="text-xs font-bold text-[var(--color-text)]">
                      CORS Preflight (OPTIONS) & Vercel 10s Timeout (504 Gateway)
                    </span>
                  </div>
                  <span className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono text-[var(--color-text-muted)]">
                    OPTIONS 204 + maxDuration
                  </span>
                </div>

                <div className="text-[11px] text-[var(--color-text-muted)] leading-relaxed space-y-1.5">
                  <p>
                    <strong className="text-[var(--color-text)]">Issue A (CORS Preflight):</strong> If calling your API from a browser frontend, preflight OPTIONS requests fail if not explicitly handled.
                  </p>
                  <p>
                    <strong className="text-[var(--color-text)]">Issue B (Vercel 10s Timeout):</strong> Large articles with high-res hero images or GitHub commits can take 6-12 seconds. By default, Vercel free tier limits lambdas to 10 seconds.
                  </p>

                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded bg-[#0D1117] p-2.5 text-[11px] font-mono text-[#C9D1D9]">
{`// At the top of src/app/api/posts/route.ts:
export const maxDuration = 30; // Extends execution budget up to 30 seconds

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, x-api-key",
    },
  });
}`}
                    </pre>
                    <button
                      type="button"
                      onClick={() => copyTroubleshootSnippet("optionstimeout", `export const maxDuration = 30;\n\nexport async function OPTIONS() {\n  return new Response(null, {\n    status: 204,\n    headers: {\n      "Access-Control-Allow-Origin": "*",\n      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",\n      "Access-Control-Allow-Headers": "Content-Type, Authorization, x-api-key",\n    },\n  });\n}`, "OPTIONS & maxDuration snippet")}
                      className="absolute right-2 top-2 rounded bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white hover:bg-white/20 transition cursor-pointer"
                    >
                      {copiedTroubleshootId === "optionstimeout" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  </Modal>
</div>
);
}
