import { useState } from "react";
import {
  Globe,
  CalendarClock,
  ClipboardCheck,
  Send,
  ChevronRight,
  CheckCircle2,
  FileText,
  Plus,
  ArrowUpRight,
  Clock,
  Zap,
  Activity,
  Layers,
  ExternalLink,
  MessageSquare,
  AlertCircle,
  Play,
  RotateCw,
  Terminal,
  ShieldCheck,
  Check,
  Eye,
  Hash,
  ChevronDown,
  Sparkles,
  Link2,
} from "lucide-react";
import { useNav } from "../../lib/nav";
import { useToast } from "../../lib/toast";
import { usePipelineData } from "../../lib/dataContext";
import { Card, CardHeader } from "../Card";
import { Button } from "../ui";
import { MetricCard } from "../MetricCard";
import { StatusBadge } from "../StatusBadge";
import { WebsiteIcon } from "../WebsiteIcon";
import type { ContentItem } from "../../types";
import { cn } from "../../utils/cn";
import { cleanMarkdown } from "../../utils/cleanMarkdown";

export function OverviewPage() {
  const { setPage, openInspector, openLaunchModal, setActiveRunThreadId } = useNav();
  const { push } = useToast();
  const {
    websites,
    contentItems,
    schedules,
    activity,
    upcoming,
    pipelineCounts,
    getWebsite,
    reviewArticle,
    escalateScheduleNow,
    testWebsiteSlackCard,
  } = usePipelineData();

  const [escalatingId, setEscalatingId] = useState<string | null>(null);
  const [testingSlack, setTestingSlack] = useState(false);
  const [showActivityDropdown, setShowActivityDropdown] = useState(false);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  })();

  const connectedCount = websites.filter((w) => w.status === "Connected").length;
  const activeSchedules = schedules.filter((s) => s.active);
  const reviewCount = contentItems.filter((c) => c.status === "Awaiting Approval").length;
  const publishedCount = contentItems.filter((c) => c.status === "Published").length;

  const reviewItems = contentItems
    .filter((c) => c.status === "Awaiting Approval")
    .sort((a, b) => b.createdAtDate.getTime() - a.createdAtDate.getTime())
    .slice(0, 3);

  const publishedItems = contentItems
    .filter((c) => c.status === "Published")
    .sort((a, b) => b.createdAtDate.getTime() - a.createdAtDate.getTime())
    .slice(0, 4);

  const defaultSite = websites.find((w) => w.is_default) || websites[0];
  const counts = pipelineCounts;

  const handleApprove = async (item: ContentItem) => {
    try {
      await reviewArticle(item.id, "approve");
      push({
        title: "Article Approved & Dispatched",
        description: `“${cleanMarkdown(item.title)}” is published to destination endpoint.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Approval Failed",
        description: err.message || "Failed to approve article.",
        variant: "danger",
      });
    }
  };

  const handleRequestChanges = async (item: ContentItem) => {
    try {
      await reviewArticle(item.id, "request_changes", "Refine structure and deepen technical evidence.");
      push({
        title: "Changes Requested",
        description: `Feedback sent. Autonomous redraft pass initiated for “${cleanMarkdown(item.title)}”.`,
        variant: "info",
      });
    } catch (err: any) {
      push({
        title: "Revision Request Failed",
        description: err.message || "Failed to request changes.",
        variant: "danger",
      });
    }
  };

  const handleEscalate = async (schedId: string, sName: string) => {
    setEscalatingId(schedId);
    try {
      const res = await escalateScheduleNow(schedId);
      if (res?.thread_id) {
        setActiveRunThreadId(res.thread_id);
      }
      push({
        title: "Pipeline Dispatched! 🚀",
        description: `Executed on-demand pass for “${sName}”.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Run Failed",
        description: err.message || "Could not trigger immediate run.",
        variant: "danger",
      });
    } finally {
      setEscalatingId(null);
    }
  };

  const handleTestSlack = async () => {
    const siteWithSlack = websites.find((w) => w.slack_enabled && (w.slack_channel_id || w.slack_webhook_url)) || defaultSite;
    if (!siteWithSlack) {
      push({
        title: "No Slack Channel Configured",
        description: "Connect a Slack channel or webhook in Websites tab first.",
        variant: "warn",
      });
      return;
    }
    setTestingSlack(true);
    try {
      const res = await testWebsiteSlackCard(siteWithSlack.id);
      push({
        title: "Slack Review Card Sent! 💬",
        description: res?.message || `Dispatched test review payload for ${siteWithSlack.name}.`,
        variant: "success",
      });
    } catch (err: any) {
      push({
        title: "Slack Test Failed",
        description: err.message || "Could not deliver webhook card to Slack.",
        variant: "danger",
      });
    } finally {
      setTestingSlack(false);
    }
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-7">
      {/* 1. Header & Quick Controls (Matching Competitor Layout) */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between border-b pb-6" style={{ borderColor: "var(--color-border)" }}>
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--color-text)] sm:text-3xl">
            Welcome, Azeem
          </h1>
          <p className="mt-1 text-sm text-[var(--color-text-muted)] max-w-2xl">
            Your growth agents are working in the background to improve your visibility across Google and AI search.
          </p>
        </div>

        <div className="flex items-center gap-2.5 relative">
          {/* Agent Activity Telemetry Pill & Dropdown (Screenshot 1) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowActivityDropdown(!showActivityDropdown)}
              className="flex cursor-pointer items-center gap-2 rounded-full border bg-[var(--color-bg-elev)] px-3.5 py-1.5 text-xs font-semibold text-[var(--color-text)] shadow-xs transition hover:border-[var(--color-border-strong)]"
              style={{ borderColor: "var(--color-border)" }}
            >
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Everything is running</span>
              <ChevronDown
                size={13}
                className={cn("text-[var(--color-text-muted)] transition-transform duration-200", showActivityDropdown && "rotate-180")}
              />
            </button>

            {/* Dropdown Menu */}
            {showActivityDropdown && (
              <div
                className="absolute right-0 top-full mt-2 w-80 rounded-2xl border bg-[var(--color-bg-elev)] p-3.5 shadow-xl z-30 animate-scaleIn space-y-3"
                style={{ borderColor: "var(--color-border)" }}
              >
                {/* Section 1: Upcoming Automated Cadences */}
                <div>
                  <div className="flex items-center justify-between px-1 text-[10px] font-bold uppercase tracking-wider text-[var(--color-text-subtle)]">
                    <span>Upcoming Automation</span>
                    <span className="font-mono text-emerald-500 lowercase font-normal">{activeSchedules.length} active</span>
                  </div>
                  <div className="mt-1.5 space-y-1 text-xs">
                    {upcoming.length > 0 ? (
                      upcoming.slice(0, 3).map((item) => {
                        return (
                          <div
                            key={item.id}
                            className="flex items-center justify-between rounded-xl p-2 hover:bg-[var(--color-bg-soft)] transition"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="text-[10px] font-mono font-semibold text-[var(--color-text-subtle)] shrink-0">
                                {item.when}
                              </span>
                              <CalendarClock size={12} className="text-blue-500 shrink-0" />
                              <span className="font-medium text-[var(--color-text)] truncate text-xs">
                                {item.title}
                              </span>
                            </div>
                            <span className="text-[10px] font-mono text-[var(--color-text-subtle)] shrink-0 ml-1">
                              {item.time}
                            </span>
                          </div>
                        );
                      })
                    ) : (
                      <div className="rounded-xl p-2 text-center bg-[var(--color-bg-soft)]/50">
                        <p className="text-[11px] text-[var(--color-text-muted)]">No active schedule recurring.</p>
                        <button
                          type="button"
                          onClick={() => {
                            setShowActivityDropdown(false);
                            setPage("schedules");
                          }}
                          className="mt-0.5 text-[11px] font-semibold text-[var(--color-accent-text)] hover:underline cursor-pointer"
                        >
                          Set automated cadence →
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Section 2: Recent Pipeline Runs / Activity */}
                <div className="border-t pt-2" style={{ borderColor: "var(--color-border)" }}>
                  <div className="px-1 text-[10px] font-bold uppercase tracking-wider text-[var(--color-text-subtle)]">
                    Recent Pipeline Events
                  </div>
                  <div className="mt-1.5 space-y-1 text-xs">
                    {activity.length > 0 ? (
                      activity.slice(0, 3).map((act) => (
                        <div
                          key={act.id}
                          onClick={() => {
                            setShowActivityDropdown(false);
                            openInspector(act.id);
                          }}
                          className="flex items-center justify-between rounded-xl p-2 hover:bg-[var(--color-bg-soft)] transition cursor-pointer"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span
                              className={cn(
                                "h-1.5 w-1.5 rounded-full shrink-0",
                                act.type === "published"
                                  ? "bg-emerald-500"
                                  : act.type === "approved"
                                  ? "bg-blue-500"
                                  : "bg-amber-500"
                              )}
                            />
                            <span className="font-medium text-[var(--color-text)] truncate text-xs">
                              {cleanMarkdown(act.title)}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-[var(--color-text-subtle)] shrink-0 ml-1">
                            {act.when}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="p-2 text-center text-[11px] text-[var(--color-text-muted)]">
                        No recent runs logged yet.
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Navigation */}
                <div className="border-t pt-1.5 flex items-center justify-between text-[11px]" style={{ borderColor: "var(--color-border)" }}>
                  <button
                    type="button"
                    onClick={() => {
                      setShowActivityDropdown(false);
                      setPage("content");
                    }}
                    className="font-medium text-[var(--color-text-muted)] hover:text-[var(--color-text)] cursor-pointer"
                  >
                    View Pipeline
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowActivityDropdown(false);
                      setPage("analytics");
                    }}
                    className="font-semibold text-[var(--color-accent-text)] hover:underline cursor-pointer"
                  >
                    Analytics &amp; ROI →
                  </button>
                </div>
              </div>
            )}
          </div>

          <Button
            variant="primary"
            size="sm"
            icon={<Plus size={14} className="stroke-[2.5]" />}
            onClick={openLaunchModal}
            className="text-xs font-semibold shadow-xs cursor-pointer"
          >
            Launch Pipeline
          </Button>
        </div>
      </div>

      {/* Dual Hero Focus Cards (Screenshot 1: TODAY'S ARTICLE + WEBSITE AUDIT) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Card 1: TODAY'S ARTICLE */}
        <div
          className="rounded-2xl border bg-[var(--color-bg-elev)] p-5 shadow-[var(--shadow-card)] flex flex-col justify-between transition hover:border-[var(--color-border-strong)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-orange-500 font-mono">
              Today's Article
            </div>
            {reviewItems[0] ? (
              <div className="mt-2">
                <h3 className="text-base font-bold text-[var(--color-text)] line-clamp-2">
                  {cleanMarkdown(reviewItems[0].title)}
                </h3>
                <p className="mt-1 text-xs text-[var(--color-text-muted)] line-clamp-1">
                  Ready for sign-off. Passes fact-check and AEO grounding audits.
                </p>
              </div>
            ) : publishedItems[0] ? (
              <div className="mt-2">
                <h3 className="text-base font-bold text-[var(--color-text)] line-clamp-2">
                  {cleanMarkdown(publishedItems[0].title)}
                </h3>
                <p className="mt-1 text-xs text-[var(--color-text-muted)] line-clamp-1">
                  Published live to endpoint. Citable by ChatGPT, Gemini and Claude.
                </p>
              </div>
            ) : (
              <div className="mt-2">
                <h3 className="text-base font-bold text-[var(--color-text)]">
                  Scheduled article drafting in progress
                </h3>
                <p className="mt-1 text-xs text-[var(--color-text-muted)]">
                  Autonomous agents researching keywords and topic models.
                </p>
              </div>
            )}
          </div>
          <div className="mt-4 pt-3 border-t flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
            <span className="text-xs text-[var(--color-text-subtle)] font-medium">
              Target: {defaultSite?.name || "Production"}
            </span>
            <button
              onClick={() => {
                if (reviewItems[0]) openInspector(reviewItems[0].id);
                else if (publishedItems[0]) openInspector(publishedItems[0].id);
                else setPage("content");
              }}
              className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-semibold text-[var(--color-text)] hover:opacity-80 transition"
            >
              <span>Inspect Run</span>
              <ArrowUpRight size={13} />
            </button>
          </div>
        </div>

        {/* Card 2: WEBSITE AUDIT & BACKLINKS */}
        <div
          onClick={() => setPage("backlinks")}
          className="group cursor-pointer rounded-2xl border bg-[var(--color-bg-elev)] p-5 shadow-[var(--shadow-card)] flex flex-col justify-between transition hover:border-[var(--color-border-strong)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-blue-500 font-mono">
              Website Audit &amp; Authority
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <h3 className="text-base font-bold text-[var(--color-text)]">
                Backlinks &amp; Off-Site Grounding
              </h3>
              <span className="text-2xl font-extrabold text-[var(--color-text)] font-mono">
                6
              </span>
            </div>
            <p className="mt-1 text-xs text-[var(--color-text-muted)]">
              Authoritative external citations detected across dev.to, digitalfoundry, and Reddit.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-500 font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Domain Health 94/100
            </span>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-[var(--color-text)] group-hover:translate-x-0.5 transition-transform">
              <span>View Backlinks</span>
              <ChevronRight size={13} />
            </span>
          </div>
        </div>
      </div>

      {/* 2. Precision Telemetry Ribbon */}
      <div className="grid grid-cols-2 gap-3.5 lg:grid-cols-4">
        {/* Connected Destinations */}
        <div
          onClick={() => setPage("websites")}
          className="group cursor-pointer rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)] transition-all duration-200 hover:border-[var(--color-border-strong)] hover:shadow-[var(--shadow-card-hover)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-xs font-medium text-[var(--color-text-muted)]">Connected Destinations</div>
              <div className="mt-1 text-2xl font-bold tabular-nums tracking-tight text-[var(--color-text)]">
                {connectedCount}
              </div>
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--color-text-subtle)] font-mono">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                <span>{websites.length} total endpoints</span>
              </div>
            </div>
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--color-accent-soft)] text-[var(--color-accent-text)] transition group-hover:scale-105">
              <Globe size={16} />
            </div>
          </div>
        </div>

        {/* Scheduled Cadences */}
        <div
          onClick={() => setPage("schedules")}
          className="group cursor-pointer rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)] transition-all duration-200 hover:border-[var(--color-border-strong)] hover:shadow-[var(--shadow-card-hover)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-xs font-medium text-[var(--color-text-muted)]">Active Schedules</div>
              <div className="mt-1 text-2xl font-bold tabular-nums tracking-tight text-[var(--color-text)]">
                {activeSchedules.length}
              </div>
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--color-text-subtle)] font-mono">
                <Clock size={11} />
                <span>{schedules.length} configured</span>
              </div>
            </div>
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 text-blue-500 transition group-hover:scale-105">
              <CalendarClock size={16} />
            </div>
          </div>
        </div>

        {/* Review Gate */}
        <div
          onClick={() => setPage("reviews")}
          className={cn(
            "group cursor-pointer rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)] transition-all duration-200 hover:shadow-[var(--shadow-card-hover)]",
            reviewCount > 0
              ? "border-amber-500/40 bg-amber-500/5 hover:border-amber-500/70"
              : "border-[var(--color-border)] hover:border-[var(--color-border-strong)]"
          )}
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-xs font-medium text-[var(--color-text-muted)] flex items-center gap-1.5">
                <span>Needs Sign-Off</span>
                {reviewCount > 0 && (
                  <span className="inline-flex h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
                )}
              </div>
              <div className="mt-1 text-2xl font-bold tabular-nums tracking-tight text-[var(--color-text)]">
                {reviewCount}
              </div>
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--color-text-subtle)] font-mono">
                {reviewCount > 0 ? (
                  <span className="text-amber-500 font-semibold">Action required</span>
                ) : (
                  <span>Review inbox clear</span>
                )}
              </div>
            </div>
            <div className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition group-hover:scale-105",
              reviewCount > 0 ? "bg-amber-500/20 text-amber-500" : "bg-[var(--color-bg-soft)] text-[var(--color-text-muted)]"
            )}>
              <ClipboardCheck size={16} />
            </div>
          </div>
        </div>

        {/* Live Published */}
        <div
          onClick={() => setPage("content")}
          className="group cursor-pointer rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)] transition-all duration-200 hover:border-[var(--color-border-strong)] hover:shadow-[var(--shadow-card-hover)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="text-xs font-medium text-[var(--color-text-muted)]">Published Dispatches</div>
              <div className="mt-1 text-2xl font-bold tabular-nums tracking-tight text-[var(--color-text)]">
                {publishedCount}
              </div>
              <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[var(--color-text-subtle)] font-mono">
                <CheckCircle2 size={11} className="text-emerald-500" />
                <span>Across all sites</span>
              </div>
            </div>
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500 transition group-hover:scale-105">
              <Send size={16} />
            </div>
          </div>
        </div>
      </div>

      {/* 3. Workflow Throughput Track (Linear Pipeline Stage Rail) */}
      <div className="rounded-2xl border bg-[var(--color-bg-elev)] p-4 shadow-[var(--shadow-card)]" style={{ borderColor: "var(--color-border)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Layers size={14} className="text-[var(--color-accent)]" />
            <span className="text-xs font-semibold text-[var(--color-text)]">Pipeline Throughput &amp; State Distribution</span>
          </div>
          <span className="text-[11px] text-[var(--color-text-muted)] font-mono">
            Autonomous 7-Stage LangGraph Engine
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {[
            { label: "Ideas & Discovery", count: counts.Ideas ?? 0, desc: "Novelty Verified", filter: "Idea" },
            { label: "Drafting Engine", count: counts.Drafting ?? 0, desc: "AEO Structured", filter: "Drafting" },
            { label: "SEO Verification", count: counts["SEO Check"] ?? 0, desc: "Audit Pass", filter: "SEO Check" },
            { label: "Review Gate", count: counts.Review ?? 0, desc: "Human Sign-off", filter: "Awaiting Approval" },
            { label: "Live Published", count: counts.Published ?? 0, desc: "Synced to Next.js", filter: "Published" },
          ].map((stage) => (
            <div
              key={stage.label}
              onClick={() => {
                if (stage.filter === "Awaiting Approval") setPage("reviews");
                else if (stage.filter === "Drafting" || stage.filter === "SEO Check") setPage("drafts");
                else if (stage.filter === "Published") setPage("published");
                else if (stage.filter === "Idea") setPage("queue");
                else setPage("content");
              }}
              className={cn(
                "rounded-xl border p-2.5 transition cursor-pointer select-none active:scale-[0.985]",
                stage.count > 0 && stage.filter === "Awaiting Approval"
                  ? "border-amber-500/40 bg-amber-500/5 hover:border-amber-500"
                  : "border-[var(--color-border)] bg-[var(--color-bg-soft)]/60 hover:border-[var(--color-border-strong)]"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-[var(--color-text-muted)]">{stage.label}</span>
                <span className={cn(
                  "font-mono text-xs font-bold tabular-nums px-1.5 py-0.2 rounded",
                  stage.count > 0 ? "bg-[var(--color-bg-elev)] text-[var(--color-text)] border border-[var(--color-border)]" : "text-[var(--color-text-subtle)]"
                )}>
                  {stage.count}
                </span>
              </div>
              <div className="mt-1 text-[10px] text-[var(--color-text-subtle)] font-mono truncate">
                {stage.desc}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Two-Column Balanced Command Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Priority Review & Live Publications */}
        <div className="lg:col-span-7 space-y-6">
          {/* A. Editorial Review Desk */}
          <div className="rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between border-b px-5 py-3.5 bg-[var(--color-bg-soft)]/50" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2">
                <ClipboardCheck size={15} className="text-amber-500" />
                <h2 className="text-sm font-semibold tracking-tight text-[var(--color-text)]">
                  Needs Your Sign-Off
                </h2>
                {reviewCount > 0 && (
                  <span className="rounded-full bg-amber-500/20 text-amber-500 px-2 py-0.2 text-[10px] font-bold font-mono">
                    {reviewCount}
                  </span>
                )}
              </div>
              <button
                onClick={() => setPage("reviews")}
                className="flex items-center gap-1 text-xs font-semibold text-[var(--color-accent-text)] transition hover:underline cursor-pointer"
              >
                Review Inbox <ChevronRight size={13} />
              </button>
            </div>

            <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
              {reviewItems.length === 0 ? (
                <div className="px-5 py-10 text-center">
                  <div className="mx-auto mb-2.5 flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500">
                    <CheckCircle2 size={20} />
                  </div>
                  <p className="text-sm font-semibold text-[var(--color-text)]">Review Queue Clear</p>
                  <p className="mt-1 text-xs text-[var(--color-text-muted)] max-w-sm mx-auto">
                    All generated drafts have been approved and published. Incoming articles will appear here automatically.
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={openLaunchModal}
                    icon={<Plus size={13} />}
                    className="mt-3 border border-[var(--color-border)] text-xs cursor-pointer"
                  >
                    Generate an article now
                  </Button>
                </div>
              ) : (
                reviewItems.map((item) => {
                  const site = getWebsite(item.websiteId);
                  const cleanTitle = cleanMarkdown(item.title);
                  const cleanExcerpt = cleanMarkdown(item.excerpt);
                  return (
                    <div key={item.id} className="p-5 transition hover:bg-[var(--color-bg-soft)]/50">
                      <div className="flex items-start gap-3.5">
                        {site && <WebsiteIcon website={site} />}
                        <div className="min-w-0 flex-1">
                          {/* Metadata row */}
                          <div className="flex flex-wrap items-center gap-2 mb-1.5">
                            {site && (
                              <span className="text-[11px] font-semibold text-[var(--color-text)]">
                                {site.name}
                              </span>
                            )}
                            <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">•</span>
                            <span className="text-[11px] text-[var(--color-text-muted)] font-mono">{item.createdAt}</span>
                            <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">•</span>
                            <span className={cn(
                              "inline-flex items-center gap-1 font-mono text-[10px] font-bold px-1.5 py-0.2 rounded",
                              item.seoScore >= 90 ? "bg-emerald-500/15 text-emerald-500" : "bg-amber-500/15 text-amber-500"
                            )}>
                              SEO {item.seoScore}
                            </span>
                            {item.targetKeyword && (
                              <span className="text-[10px] font-mono text-[var(--color-text-subtle)] truncate max-w-[140px]">
                                key: {item.targetKeyword}
                              </span>
                            )}
                          </div>

                          {/* Clean Title */}
                          <h3
                            onClick={() => openInspector(item.id, "draft")}
                            className="text-[14px] font-semibold leading-snug tracking-tight text-[var(--color-text)] hover:text-[var(--color-accent-text)] cursor-pointer transition"
                          >
                            {cleanTitle}
                          </h3>

                          {/* Clean Excerpt */}
                          {cleanExcerpt && (
                            <p className="mt-1.5 text-xs text-[var(--color-text-muted)] line-clamp-2 leading-relaxed">
                              {cleanExcerpt}
                            </p>
                          )}

                          {/* Direct Action Bar */}
                          <div className="mt-3.5 flex flex-wrap items-center gap-2">
                            <Button
                              variant="primary"
                              size="sm"
                              icon={<Check size={13} className="stroke-[2.5]" />}
                              onClick={() => handleApprove(item)}
                              className="text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                            >
                              Approve &amp; Publish
                            </Button>
                            <Button
                              variant="secondary"
                              size="sm"
                              icon={<Eye size={13} />}
                              onClick={() => openInspector(item.id, "draft")}
                              className="text-xs border-[var(--color-border)] cursor-pointer"
                            >
                              Inspect Draft
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRequestChanges(item)}
                              className="text-xs text-[var(--color-text-muted)] hover:text-[var(--color-text)] cursor-pointer"
                            >
                              Request Changes
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* B. Recently Published & Dispatched (Eliminating the empty void!) */}
          <div className="rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between border-b px-5 py-3.5 bg-[var(--color-bg-soft)]/50" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2">
                <Send size={14} className="text-emerald-500" />
                <h2 className="text-sm font-semibold tracking-tight text-[var(--color-text)]">
                  Live Publications &amp; Dispatches
                </h2>
              </div>
              <button
                onClick={() => setPage("content")}
                className="flex items-center gap-1 text-xs font-semibold text-[var(--color-accent-text)] transition hover:underline cursor-pointer"
              >
                All Articles ({publishedCount}) <ChevronRight size={13} />
              </button>
            </div>

            <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
              {publishedItems.length === 0 ? (
                <div className="p-6 text-center text-xs text-[var(--color-text-muted)]">
                  No published articles yet. Once approved, live articles appear here with instant destination links.
                </div>
              ) : (
                publishedItems.map((pub) => {
                  const site = getWebsite(pub.websiteId);
                  const cleanTitle = cleanMarkdown(pub.title);
                  return (
                    <div key={pub.id} className="p-4 transition hover:bg-[var(--color-bg-soft)]/50 flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[11px] font-semibold text-[var(--color-text-muted)]">
                            {site?.name || "Connected Site"}
                          </span>
                          <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">•</span>
                          <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">{pub.createdAt}</span>
                          <span className="text-[10px] text-[var(--color-text-subtle)] font-mono">•</span>
                          <span className="font-mono text-[10px] font-bold text-emerald-500">
                            SEO {pub.seoScore}
                          </span>
                        </div>
                        <h4
                          onClick={() => openInspector(pub.id, "publish")}
                          className="text-xs font-semibold text-[var(--color-text)] hover:text-[var(--color-accent-text)] cursor-pointer truncate"
                        >
                          {cleanTitle}
                        </h4>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0 pt-1">
                        <button
                          type="button"
                          onClick={() => openInspector(pub.id, "publish")}
                          className="rounded-lg p-1.5 text-[var(--color-text-muted)] hover:text-[var(--color-text)] hover:bg-[var(--color-bg-soft)] border border-[var(--color-border)] cursor-pointer transition text-[11px] flex items-center gap-1 font-mono"
                          title="Inspect live preview"
                        >
                          <Eye size={12} />
                          <span>View</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Upcoming Cadence, Live Telemetry & Audit Feed */}
        <div className="lg:col-span-5 space-y-6">
          {/* A. Upcoming Scheduled Cadence */}
          <div className="rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between border-b px-5 py-3.5 bg-[var(--color-bg-soft)]/50" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2">
                <CalendarClock size={15} className="text-blue-500" />
                <h2 className="text-sm font-semibold tracking-tight text-[var(--color-text)]">
                  Upcoming Schedules
                </h2>
              </div>
              <button
                onClick={() => setPage("schedules")}
                className="flex items-center gap-1 text-xs font-semibold text-[var(--color-accent-text)] transition hover:underline cursor-pointer"
              >
                Cadences <ChevronRight size={13} />
              </button>
            </div>

            <div className="divide-y" style={{ borderColor: "var(--color-border)" }}>
              {activeSchedules.length === 0 ? (
                <div className="p-5 text-center text-xs text-[var(--color-text-muted)]">
                  <p>No active scheduled cadences.</p>
                  <p className="mt-1 text-[11px] text-[var(--color-text-subtle)]">
                    Schedule recurring dispatches on an hourly, daily, or weekly interval.
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPage("schedules")}
                    icon={<Plus size={12} />}
                    className="mt-3 border border-[var(--color-border)] text-xs cursor-pointer"
                  >
                    Create a schedule
                  </Button>
                </div>
              ) : (
                activeSchedules.slice(0, 3).map((s) => {
                  const site = getWebsite(s.websiteId);
                  const isEscalating = escalatingId === s.id;
                  return (
                    <div key={s.id} className="p-4 transition hover:bg-[var(--color-bg-soft)]/50">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 mb-1 text-[11px] text-[var(--color-text-muted)] font-mono">
                            <Clock size={11} />
                            <span>{s.time} UTC</span>
                            <span>•</span>
                            <span className="font-semibold text-[var(--color-accent-text)]">{s.nextRun}</span>
                          </div>
                          <div className="text-xs font-semibold text-[var(--color-text)] truncate">
                            {s.name}
                          </div>
                          <div className="mt-0.5 text-[11px] text-[var(--color-text-subtle)] truncate">
                            Target: {site?.name || "Connected Website"}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          disabled={isEscalating}
                          onClick={() => handleEscalate(s.id, s.name)}
                          icon={isEscalating ? <RotateCw size={11} className="animate-spin" /> : <Zap size={11} />}
                          className="h-7 px-2 text-[11px] shrink-0 border border-[var(--color-border)] cursor-pointer"
                          title="Trigger run immediately"
                        >
                          {isEscalating ? "Firing..." : "Run now"}
                        </Button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* B. Live Telemetry & Delivery Channels (Real status, zero fake slop) */}
          <div className="rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)] p-4 space-y-3" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between border-b pb-2.5" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2">
                <Activity size={14} className="text-emerald-500" />
                <h3 className="text-xs font-semibold text-[var(--color-text)]">Delivery Channels &amp; Automation Health</h3>
              </div>
              <span className="text-[10px] font-mono text-emerald-500 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded">
                Live
              </span>
            </div>

            <div className="space-y-2 text-xs">
              {/* Scheduler Engine Status */}
              <div className="flex items-center justify-between p-2 rounded-xl bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-medium text-[var(--color-text)]">Background Scheduler</span>
                </div>
                <span className="font-mono text-[11px] text-[var(--color-text-muted)]">30s evaluation loop</span>
              </div>

              {/* Connected Targets */}
              <div className="flex items-center justify-between p-2 rounded-xl bg-[var(--color-bg-soft)] border" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center gap-2">
                  <Globe size={13} className="text-[var(--color-accent)]" />
                  <span className="font-medium text-[var(--color-text)]">Destination Endpoints</span>
                </div>
                <span className="font-mono text-[11px] text-[var(--color-text-muted)]">{connectedCount} Active</span>
              </div>

              {/* Real Slack Status */}
              <div className="p-2.5 rounded-xl bg-[var(--color-bg-soft)] border space-y-2" style={{ borderColor: "var(--color-border)" }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare size={13} className="text-blue-400" />
                    <span className="font-medium text-[var(--color-text)]">Slack Review Gate</span>
                  </div>
                  <span className="font-mono text-[10px] text-blue-400 font-bold bg-blue-500/10 px-1.5 py-0.2 rounded">
                    {defaultSite?.slack_channel_id ? defaultSite.slack_channel_id : "Interactive Cards"}
                  </span>
                </div>
                <p className="text-[11px] text-[var(--color-text-muted)] leading-relaxed">
                  When a run pauses for human sign-off, interactive cards with instant Approve &amp; Reject buttons dispatch directly to Slack.
                </p>
                <div className="flex items-center gap-2 pt-0.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={testingSlack}
                    onClick={handleTestSlack}
                    icon={testingSlack ? <RotateCw size={11} className="animate-spin" /> : <Terminal size={11} />}
                    className="h-7 px-2.5 text-[11px] border border-[var(--color-border)] hover:bg-[var(--color-bg-elev)] cursor-pointer"
                  >
                    {testingSlack ? "Dispatching..." : "Test Slack Delivery"}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPage("websites")}
                    className="h-7 px-2 text-[11px] text-[var(--color-text-muted)] hover:text-[var(--color-text)] cursor-pointer"
                  >
                    Configure
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* C. Real Audit Trail & Activity Feed */}
          <div className="rounded-2xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-card)] overflow-hidden" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center justify-between border-b px-5 py-3.5 bg-[var(--color-bg-soft)]/50" style={{ borderColor: "var(--color-border)" }}>
              <div className="flex items-center gap-2">
                <Clock size={14} className="text-[var(--color-text-muted)]" />
                <h3 className="text-sm font-semibold tracking-tight text-[var(--color-text)]">
                  Audit Trail &amp; Activity
                </h3>
              </div>
              <span className="text-[10px] font-mono text-[var(--color-text-subtle)]">Realtime</span>
            </div>

            <div className="divide-y max-h-72 overflow-y-auto" style={{ borderColor: "var(--color-border)" }}>
              {activity.length === 0 ? (
                <div className="p-5 text-center text-xs text-[var(--color-text-muted)]">
                  No activity recorded yet.
                </div>
              ) : (
                activity.slice(0, 5).map((ev) => (
                  <div
                    key={ev.id}
                    onClick={() => openInspector(ev.id)}
                    className="p-3.5 transition hover:bg-[var(--color-bg-soft)]/50 cursor-pointer flex items-start gap-2.5"
                  >
                    <ActivityIcon type={ev.type} />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs text-[var(--color-text)] leading-snug">
                        <span className="font-semibold">{labelFor(ev.type)}:</span>{" "}
                        <span className="text-[var(--color-text-muted)]">{cleanMarkdown(ev.title)}</span>
                      </div>
                      <div className="mt-0.5 text-[10px] text-[var(--color-text-subtle)] font-mono">
                        {ev.when}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function labelFor(t: string) {
  switch (t) {
    case "approved":
      return "Approved";
    case "published":
      return "Published";
    case "draft":
      return "Draft generated";
    case "schedule":
      return "Schedule updated";
    case "rejected":
      return "Rejected";
    case "connected":
      return "Connected";
    default:
      return t;
  }
}

function ActivityIcon({ type }: { type: string }) {
  const map: Record<string, { icon: typeof CheckCircle2; bg: string; color: string }> = {
    approved: {
      icon: CheckCircle2,
      bg: "rgba(16, 185, 129, 0.15)",
      color: "#10b981",
    },
    published: {
      icon: Send,
      bg: "rgba(59, 130, 246, 0.15)",
      color: "#3b82f6",
    },
    draft: {
      icon: FileText,
      bg: "rgba(6, 182, 212, 0.15)",
      color: "#06b6d4",
    },
    schedule: {
      icon: CalendarClock,
      bg: "rgba(99, 102, 241, 0.15)",
      color: "#6366f1",
    },
    rejected: {
      icon: AlertCircle,
      bg: "rgba(239, 68, 68, 0.15)",
      color: "#ef4444",
    },
    connected: {
      icon: Globe,
      bg: "rgba(16, 185, 129, 0.15)",
      color: "#10b981",
    },
  };
  const { icon: Icon, bg, color } = map[type] ?? map.draft;
  return (
    <div
      className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg"
      style={{ background: bg, color }}
    >
      <Icon size={12} />
    </div>
  );
}
