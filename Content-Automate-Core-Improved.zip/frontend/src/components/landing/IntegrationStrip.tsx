import { Container } from "./ui";
import { INTEGRATIONS } from "./integrationData";

export function IntegrationStrip() {
  return (
    <section aria-label="Integrations" className="border-y border-line bg-white">
      <Container className="flex flex-col gap-5 py-7 lg:flex-row lg:items-center lg:justify-between lg:gap-12">
        <p className="max-w-[280px] text-sm leading-snug text-ink-2">Fits into the stack your content team already uses.</p>
        <ul className="flex flex-wrap items-center gap-x-8 gap-y-4 lg:justify-end">
          {INTEGRATIONS.map(({ name, Icon }) => (
            <li key={name} className="flex items-center gap-2 text-ink-2 transition-colors hover:text-ink">
              <Icon size={16} className="text-ink-3" />
              <span className="text-[13px] font-medium tracking-[-0.005em]">{name}</span>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
}
