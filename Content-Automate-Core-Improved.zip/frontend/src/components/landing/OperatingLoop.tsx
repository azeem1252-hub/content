import { useEffect, useState } from "react";
import { useReducedMotion } from "framer-motion";
import { cn } from "../utils/cn";
import { Check } from "./icons";
import { Container, Reveal, Section, SectionHeading } from "./ui";
import { useOnceInView } from "../lib/hooks";

const STAGES = [
  { k: "Discover", d: "Connect Search Console, Analytics, and your CMS. Find declines, anomalies, and opportunities." },
  { k: "Diagnose", d: "Separate seasonality from structural decline. Explain likely causes with a confidence level." },
  { k: "Prioritize", d: "Score impact and confidence. Decide what to do now, what to watch, and what to leave alone." },
  { k: "Research", d: "Map intent, questions, and sources before anything is written." },
  { k: "Create", d: "Draft updates and new content as tracked changes, with the context attached." },
  { k: "Verify", d: "Tie important claims to sources. Flag weak or conflicting evidence." },
  { k: "Approve", d: "A person reviews every change and decides what ships." },
  { k: "Publish", d: "Push approved content to your CMS, where supported." },
  { k: "Measure", d: "Compare updated pages with matched untouched pages." },
  { k: "Learn", d: "Feed what worked back into the next decision." },
];

const C = 220;
const R = 170;
const pos = (i: number) => {
  const a = ((-90 + i * 36) * Math.PI) / 180;
  return { x: C + R * Math.cos(a), y: C + R * Math.sin(a) };
};

export function OperatingLoop() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const reduce = useReducedMotion();
  const [active, setActive] = useState(0);
  const [auto, setAuto] = useState(true);

  useEffect(() => {
    if (!inView || !auto || reduce) return;
    const id = window.setInterval(() => setActive((a) => (a + 1) % STAGES.length), 2600);
    return () => window.clearInterval(id);
  }, [inView, auto, reduce]);

  const pick = (i: number) => {
    setActive(i);
    setAuto(false);
  };
  const cur = STAGES[active];

  return (
    <Section id="loop" chapter="12" chapterLabel="The loop" labelledBy="loop-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="loop-title"
            n="12"
            chapter="The loop"
            title="Content becomes a system, not a backlog."
            sub="Every cycle feeds the next decision. What worked gets repeated. What didn’t gets questioned."
            titleClassName="text-[clamp(2.75rem,6vw,5.25rem)]"
          />
        </Reveal>

        <div ref={ref} className="mt-12 grid items-center gap-10 lg:mt-16 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-6">
            <div className="relative mx-auto aspect-square w-full max-w-[460px]">
              <svg viewBox="0 0 440 440" className="absolute inset-0 h-full w-full" aria-hidden="true">
                <circle cx={C} cy={C} r={R} fill="none" stroke="#DFE0DA" strokeWidth={1.5} />
                <circle
                  cx={C}
                  cy={C}
                  r={R}
                  fill="none"
                  stroke="#161719"
                  strokeWidth={2}
                  pathLength={1}
                  strokeDasharray="1"
                  strokeDashoffset={1 - active / STAGES.length}
                  transform={`rotate(-90 ${C} ${C})`}
                  style={{ transition: "stroke-dashoffset .7s cubic-bezier(.4,0,.2,1)" }}
                />
              </svg>

              {STAGES.map((s, i) => {
                const p = pos(i);
                const past = i < active;
                const on = i === active;
                return (
                  <button
                    key={s.k}
                    type="button"
                    onClick={() => pick(i)}
                    aria-label={`Stage ${i + 1}: ${s.k}`}
                    aria-current={on ? "step" : undefined}
                    className={cn(
                      "absolute grid h-9 w-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border font-mono text-[11px] transition-all duration-500 sm:h-10 sm:w-10",
                      on
                        ? "scale-110 border-brand bg-brand text-white"
                        : past
                          ? "border-ink bg-ink text-white"
                          : "border-line-strong bg-white text-ink-2 hover:border-ink",
                    )}
                    style={{ left: `${(p.x / 440) * 100}%`, top: `${(p.y / 440) * 100}%` }}
                  >
                    {past ? <Check size={13} /> : String(i + 1).padStart(2, "0")}
                  </button>
                );
              })}

              <div className="absolute inset-0 grid place-items-center">
                <div key={active} className="fade-in max-w-[56%] text-center">
                  <div className="num text-[11px] uppercase tracking-[0.1em] text-brand">
                    {String(active + 1).padStart(2, "0")} / {STAGES.length}
                  </div>
                  <div className="mt-1 font-serif text-[clamp(1.9rem,4vw,2.75rem)] leading-none tracking-[-0.015em]">{cur.k}</div>
                  <p className="mt-3 hidden text-[13px] leading-snug text-ink-2 sm:block">{cur.d}</p>
                  {active === STAGES.length - 1 && <div className="mt-2 text-xl text-ink-2" aria-hidden="true">↺</div>}
                </div>
              </div>
            </div>
          </div>

          <ol className="lg:col-span-6">
            {STAGES.map((s, i) => (
              <li key={s.k} className="border-t border-line first:border-t-0">
                <button
                  type="button"
                  onClick={() => pick(i)}
                  aria-current={i === active ? "step" : undefined}
                  className={cn(
                    "group grid w-full grid-cols-[34px_1fr] items-baseline gap-2 py-3 text-left transition-colors",
                    i === active ? "text-ink" : "text-ink-3 hover:text-ink-2",
                  )}
                >
                  <span className="num text-[11px]">{String(i + 1).padStart(2, "0")}</span>
                  <span>
                    <span className={cn("font-mono text-[13px] uppercase tracking-[0.08em]", i === active && "font-medium")}>{s.k}</span>
                    <span
                      className={cn(
                        "grid transition-[grid-template-rows,opacity] duration-300",
                        i === active ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                      )}
                    >
                      <span className="overflow-hidden text-[14px] leading-snug text-ink-2">
                        <span className="block pt-1">{s.d}</span>
                      </span>
                    </span>
                  </span>
                </button>
              </li>
            ))}
            <li className="border-t border-line pt-3 font-mono text-[11px] uppercase tracking-[0.08em] text-ink-3">↺ Then it starts again, with more evidence</li>
          </ol>
        </div>
      </Container>
    </Section>
  );
}
