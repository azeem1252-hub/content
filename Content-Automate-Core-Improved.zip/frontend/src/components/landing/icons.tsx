import type { ReactNode } from "react";

interface IconProps {
  className?: string;
  size?: number;
}

function Svg({ size = 16, className, children, sw = 1.5 }: IconProps & { children: ReactNode; sw?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth={sw}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

export const Arrow = (p: IconProps) => (
  <Svg {...p}>
    <path d="M2.5 8h11M9 3.5 13.5 8 9 12.5" />
  </Svg>
);
export const ArrowDown = (p: IconProps) => (
  <Svg {...p}>
    <path d="M8 2.5v11M3.5 9 8 13.5 12.5 9" />
  </Svg>
);
export const ArrowRight = Arrow;
export const Check = (p: IconProps) => (
  <Svg {...p} sw={1.8}>
    <path d="m3 8.5 3.2 3.2L13 4.8" />
  </Svg>
);
export const Warn = (p: IconProps) => (
  <Svg {...p}>
    <path d="M8 2.2 14.2 13H1.8L8 2.2Z" />
    <path d="M8 6.5v3M8 11.3v.1" />
  </Svg>
);
export const Question = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="8" cy="8" r="6" />
    <path d="M6.2 6.3A1.9 1.9 0 0 1 8 5c1 0 1.9.7 1.9 1.7 0 1.3-1.9 1.4-1.9 2.6M8 11.2v.1" />
  </Svg>
);
export const Plus = (p: IconProps) => (
  <Svg {...p}>
    <path d="M8 3v10M3 8h10" />
  </Svg>
);
export const Minus = (p: IconProps) => (
  <Svg {...p}>
    <path d="M3 8h10" />
  </Svg>
);
export const Close = (p: IconProps) => (
  <Svg {...p}>
    <path d="m3.5 3.5 9 9M12.5 3.5l-9 9" />
  </Svg>
);
export const Chevron = (p: IconProps) => (
  <Svg {...p}>
    <path d="m4 6 4 4 4-4" />
  </Svg>
);
export const Lock = (p: IconProps) => (
  <Svg {...p}>
    <rect x="3" y="7" width="10" height="6.5" rx="1" />
    <path d="M5.2 7V5.2a2.8 2.8 0 0 1 5.6 0V7" />
  </Svg>
);
export const Pause = (p: IconProps) => (
  <Svg {...p}>
    <path d="M5.5 3.5v9M10.5 3.5v9" />
  </Svg>
);
export const Play = (p: IconProps) => (
  <Svg {...p}>
    <path d="M5 3.2v9.6L12.8 8 5 3.2Z" />
  </Svg>
);
export const Menu = (p: IconProps) => (
  <Svg {...p}>
    <path d="M2.5 5h11M2.5 11h11" />
  </Svg>
);
export const Loop = (p: IconProps) => (
  <Svg {...p}>
    <path d="M13 8a5 5 0 1 1-1.6-3.7M13 2.5v2.8h-2.8" />
  </Svg>
);
export const Cursor = (p: IconProps) => (
  <svg width={p.size ?? 16} height={p.size ?? 16} viewBox="0 0 16 16" className={p.className} aria-hidden="true">
    <path d="M3 2v11l3-2.7 2 4 2-.9-2-3.9H12L3 2Z" fill="#161719" stroke="#fff" strokeWidth="1" strokeLinejoin="round" />
  </svg>
);

export function LogoMark({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 22 22" aria-hidden="true">
      <rect width="22" height="22" rx="4" fill="#161719" />
      <rect x="5" y="5.5" width="12" height="3.2" rx="0.8" fill="#fff" />
      <rect x="5" y="11" width="9" height="1.7" fill="#fff" opacity="0.7" />
      <rect x="5" y="14.6" width="6" height="1.7" fill="#fff" opacity="0.7" />
      <rect x="15.2" y="11" width="1.8" height="5.3" fill="#C84A42" />
    </svg>
  );
}

/* Neutral, abstract glyphs standing in for integration marks (monochrome, no brand artwork). */
export const GlyphSearchConsole = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="7" cy="7" r="4.2" />
    <path d="m10.2 10.2 3.3 3.3M5.2 8.2V6.4M7 8.2V5M8.8 8.2V6.8" />
  </Svg>
);
export const GlyphAnalytics = (p: IconProps) => (
  <Svg {...p}>
    <path d="M3.5 13V8.5M8 13V3.5M12.5 13V6.5" strokeWidth={2.4} />
  </Svg>
);
export const GlyphWordPress = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="8" cy="8" r="6" />
    <path d="m4.6 5.6 2 5.6 1.4-3.6 1.4 3.6 2-5.6" />
  </Svg>
);
export const GlyphWebflow = (p: IconProps) => (
  <Svg {...p}>
    <path d="M1.8 5.2 4.6 11l2-4.4L8.6 11l2.8-5.8M11.4 5.2h2.8" />
  </Svg>
);
export const GlyphContentful = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="8" cy="3.8" r="1.7" />
    <circle cx="3.8" cy="10.8" r="1.7" />
    <circle cx="12.2" cy="10.8" r="1.7" />
    <path d="M7 5.3 4.8 9.2M9 5.3l2.2 3.9M5.5 10.8h5" />
  </Svg>
);
export const GlyphHubSpot = (p: IconProps) => (
  <Svg {...p}>
    <circle cx="9.5" cy="9" r="2.6" />
    <path d="M9.5 6.4V3.2M7.3 10.6 4.2 12.8M12 7.2l2-1.4" />
    <circle cx="9.5" cy="2.6" r="0.9" />
    <circle cx="3.6" cy="13.2" r="1" />
  </Svg>
);
export const GlyphGhost = (p: IconProps) => (
  <Svg {...p}>
    <path d="M3.2 14V7.2a4.8 4.8 0 0 1 9.6 0V14l-1.9-1.5L8 14l-2.9-1.5L3.2 14Z" />
    <path d="M6.2 7.2v.1M9.8 7.2v.1" />
  </Svg>
);
export const GlyphShopify = (p: IconProps) => (
  <Svg {...p}>
    <path d="M3 5.2h10l-.7 8.3H3.7L3 5.2Z" />
    <path d="M5.6 5.2V4.4a2.4 2.4 0 0 1 4.8 0v.8" />
  </Svg>
);
