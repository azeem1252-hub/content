import { useEffect, useRef, useState } from "react";
import { useInView, useReducedMotion } from "framer-motion";
import { cn } from "../utils/cn";
import { At, ChartSvg, DrawPath, FadePath } from "./charts";
import { Arrow, Check, Cursor, LogoMark, Pause, Play } from "./icons";
import { Label, Meter, Num, StatusDot, Tag, Window } from "./ui";
import { LiveMotion } from "../lib/motion";
import { areaBetween, decaySeries, experimentSeries, linePath, mapPts, scaleY, sparkPath } from "../lib/chart";

/* ------------------------------------------------------------------ script */

const STEPS = [
  "Overview",
  "Signal",
  "Decline",
  "Investigate",
  "Diagnose",
  "Recommend",
  "Draft",
  "Review",
  "Approve",
  "Publish",
  "Measure",
];
const DURATIONS = [2800, 2200, 3400, 3800, 3200, 2800, 3600, 3800, 2600, 2800, 5400];

const DESCRIPTION =
  "Animated product demonstration using sample data. The platform scans 247 articles and flags that /best-crm-software lost 37% of its organic visibility. It investigates search demand, SERP changes, content history and competitor coverage, then concludes with 91% confidence that a SERP intent shift is the likely cause and recommends updating the article. It drafts tracked changes, waits for a human to review and approve them, publishes to the CMS, and finally measures a 27% relative uplift against matched untouched pages. All numbers are illustrative.";

/* ------------------------------------------------------------------ chart data */

const W = 800;
const H = 180;
const PEAK_V = 80;
const PEAK_I = 29;
const CP = { min: 18, max: 92, l: 4, r: 4, t: 14, b: 14 };
const series = decaySeries(60, { seed: 11, peakAt: 0.5, drop: 0.37, noise: 1.5, start: 46, peak: PEAK_V });
const pts = mapPts(series, W, H, CP);
const healthyD = linePath(pts.slice(0, PEAK_I + 1));
const declineD = linePath(pts.slice(PEAK_I));
const expY = scaleY(PEAK_V, H, CP.min, CP.max, CP);
const gapD = areaBetween(
  [
    [pts[PEAK_I][0], expY],
    [pts[59][0], expY],
  ],
  pts.slice(PEAK_I),
);
const END = pts[59];

const ARTICLES = [
  { path: "/best-crm-software", delta: "−37%", tone: "red", drop: 0.37 },
  { path: "/ai-support-software", delta: "−21%", tone: "red", drop: 0.21 },
  { path: "/saas-pricing-guide", delta: "−12%", tone: "amber", drop: 0.12 },
  { path: "/helpdesk-vs-crm", delta: "+9%", tone: "green", drop: -0.09 },
  { path: "/onboarding-checklist", delta: "+18%", tone: "green", drop: -0.18 },
  { path: "/startup-tools", delta: "+4%", tone: "neutral", drop: -0.04 },
].map((a, i) => ({
  ...a,
  spark: sparkPath(decaySeries(24, { seed: 20 + i, peakAt: 0.5, drop: a.drop, noise: 1.2 }), 44, 14),
}));

const toneText = { red: "text-decline", amber: "text-warn", green: "text-grow", neutral: "text-ink-2" } as const;
const toneStroke = { red: "#C84A42", amber: "#A97828", green: "#3E805C", neutral: "#92958E" } as const;

const LANES = [
  ["Search demand", "Related queries +28%"],
  ["SERP changes", "Intent → comparison"],
  ["Content history", "Last edit 11 mo ago"],
  ["Competitor coverage", "3 added pricing data"],
] as const;

/* ------------------------------------------------------------------ view A: monitor */

function RowStatus({ step }: { step: number }) {
  if (step < 5) return <span className="num text-[11px] text-decline">−37%</span>;
  if (step < 6) return <Tag tone="amber">Update</Tag>;
  if (step < 8) return <Tag tone="blue">In review</Tag>;
  if (step < 9) return <Tag tone="green">Approved</Tag>;
  if (step < 10) return <Tag tone="green">Published</Tag>;
  return <span className="num text-[11px] text-grow">+27%</span>;
}

function Portfolio({ step, cycle, run }: { step: number; cycle: number; run: boolean }) {
  const stats = [
    { k: "Declining", s: "Declining", v: 18, c: "bg-decline" },
    { k: "Unusual", s: "Unusual", v: 7, c: "bg-warn" },
    { k: "Opportunities", s: "Opps", v: 31, c: "bg-brand" },
    { k: "Growing", s: "Growing", v: 42, c: "bg-grow" },
  ];
  return (
    <div className="flex h-full flex-col p-4 sm:p-5">
      <div className="flex items-end justify-between lg:block">
        <div>
          <Label>Content intelligence</Label>
          <div className="mt-2 flex items-baseline gap-2">
            <Num key={cycle} to={247} active={run} duration={1.6} className="text-[34px] leading-none text-ink lg:text-[46px]" />
            <span className="label text-ink">Articles</span>
          </div>
        </div>
        <span className="num text-[10px] text-ink-3 lg:mt-1.5 lg:block">Last updated 2h ago</span>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-1.5 lg:grid-cols-2 lg:gap-2">
        {stats.map((s) => (
          <div key={s.k} className="rounded-[4px] border border-line px-2 py-1.5 lg:px-3 lg:py-2.5">
            <div className="flex items-center gap-1.5">
              <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", s.c)} />
              <span className="truncate font-mono text-[9px] uppercase tracking-[0.02em] text-ink-2 sm:tracking-[0.05em] lg:text-[10px]">
                <span className="sm:hidden">{s.s}</span>
                <span className="hidden sm:inline">{s.k}</span>
              </span>
            </div>
            <Num key={cycle} to={s.v} pad={2} active={run} duration={1.4} className="mt-1 block text-[18px] leading-none text-ink lg:text-[22px]" />
          </div>
        ))}
      </div>

      <div className="mt-4 hidden min-h-0 flex-1 overflow-hidden lg:block">
        <div className="mb-1.5 flex items-center justify-between">
          <Label>Needs attention</Label>
          <Label className="text-ink-3">247 total</Label>
        </div>
        <ul>
          {ARTICLES.map((a, i) => {
            const active = i === 0 && step >= 1;
            return (
              <li
                key={a.path}
                className={cn(
                  "relative grid grid-cols-[1fr_44px_58px] items-center gap-2 border-t border-line py-[7px] pl-2.5 pr-1 transition-colors duration-500",
                  active && "bg-brand-soft",
                )}
              >
                <span
                  className={cn(
                    "absolute left-0 top-0 h-full w-[2px] bg-brand transition-opacity duration-500",
                    active ? "opacity-100" : "opacity-0",
                  )}
                />
                <span className={cn("truncate font-mono text-[11.5px]", active ? "text-ink" : "text-ink-2")}>{a.path}</span>
                <svg width="44" height="14" viewBox="0 0 44 14" aria-hidden="true">
                  <path d={a.spark} fill="none" stroke={toneStroke[a.tone as keyof typeof toneStroke]} strokeWidth="1.25" />
                </svg>
                <span className="flex justify-end">
                  {i === 0 ? (
                    <RowStatus step={step} />
                  ) : (
                    <span className={cn("num text-[11px]", toneText[a.tone as keyof typeof toneText])}>{a.delta}</span>
                  )}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}

function SignalHeader({ step }: { step: number }) {
  return (
    <div className="flex min-h-[52px] items-start justify-between gap-4">
      <div className="min-w-0">
        <div className="flex h-[18px] items-center gap-2">
          {step >= 1 ? (
            <>
              <Tag tone="blue" className="fade-in">
                New signal
              </Tag>
              <Label className="hidden sm:inline">Organic visibility · 90d</Label>
            </>
          ) : (
            <Label>All articles · organic visibility</Label>
          )}
        </div>
        <div key={step >= 1 ? "a" : "b"} className="fade-up mt-1.5 truncate font-mono text-[14px] text-ink sm:text-[15px]">
          {step >= 1 ? "/best-crm-software" : "Monitoring 247 articles"}
        </div>
      </div>
      <div className="shrink-0 text-right">
        <div className={cn("text-[26px] leading-none text-decline transition-opacity duration-500 sm:text-[30px]", step >= 2 ? "opacity-100" : "opacity-0")}>
          <Num to={37} prefix="↓ " suffix="%" active={step >= 2} duration={1.8} />
        </div>
        <div className={cn("mt-1.5 font-mono text-[10px] text-ink-2 transition-opacity duration-500", step >= 2 ? "opacity-100" : "opacity-0")} style={{ transitionDelay: step >= 2 ? "900ms" : "0ms" }}>
          Detected 2h ago · Confidence 91%
        </div>
      </div>
    </div>
  );
}

function Graph({ step }: { step: number }) {
  const declined = step >= 2;
  return (
    <div className="mt-3">
      <div className="relative h-[92px] border-y border-line sm:h-[140px] lg:h-[172px]">
        <ChartSvg w={W} h={H}>
          <FadePath d={gapD} fill="#FCEFED" active={declined} delay={1.5} />
          <FadePath d={`M${pts[PEAK_I][0]} ${expY} L${END[0]} ${expY}`} stroke="#92958E" dash="4 4" active={declined} delay={0.4} />
          <DrawPath d={healthyD} stroke="#161719" active duration={1.6} delay={0.2} />
          <DrawPath d={declineD} stroke="#C84A42" width={2} active={declined} duration={1.9} />
        </ChartSvg>
        <At x={pts[PEAK_I][0]} y={expY} w={W} h={H} className="-translate-x-1/2 -translate-y-[170%]">
          <span
            className="font-mono text-[9px] uppercase tracking-[0.06em] text-ink-2 transition-opacity duration-500"
            style={{ opacity: declined ? 1 : 0, transitionDelay: declined ? "500ms" : "0ms" }}
          >
            Expected
          </span>
        </At>
        <At x={END[0]} y={END[1]} w={W} h={H} className="-translate-x-1/2 -translate-y-1/2">
          <span
            className="block h-2.5 w-2.5 rounded-full border-2 border-white bg-decline transition-opacity duration-300"
            style={{ opacity: declined ? 1 : 0, transitionDelay: declined ? "1800ms" : "0ms" }}
          />
        </At>
      </div>
      <div className="mt-1.5 flex justify-between font-mono text-[9px] uppercase tracking-[0.06em] text-ink-3">
        <span>90d ago</span>
        <span>60d</span>
        <span>30d</span>
        <span>Today</span>
      </div>
    </div>
  );
}

function Investigation({ step }: { step: number }) {
  const running = step >= 3;
  const done = step >= 4;
  return (
    <div className="mt-3 grid gap-3 sm:grid-cols-[minmax(0,1fr)_232px] md:grid-cols-[minmax(0,1fr)_36px_232px] md:gap-0">
      <div className="min-w-0">
        <div className="flex h-[22px] items-start justify-between">
          <Label>Investigation</Label>
          <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">
            {step < 3 ? "Idle" : step < 4 ? "Running" : "Complete"}
          </span>
        </div>
        <ul>
          {LANES.map(([k, f], i) => {
            const delay = `${i * 550 + 900}ms`;
            return (
              <li key={k} className="relative grid h-7 grid-cols-[16px_minmax(0,1fr)_auto] items-center gap-2 border-t border-line sm:h-8">
                <span className="relative grid h-3.5 w-3.5 place-items-center rounded-full border border-line-strong">
                  <span
                    className="absolute inset-[-1px] grid place-items-center rounded-full bg-grow text-white transition-opacity duration-500"
                    style={{ opacity: running ? 1 : 0, transitionDelay: running ? delay : "0ms" }}
                  >
                    <Check size={9} />
                  </span>
                </span>
                <span className={cn("truncate font-mono text-[10px] uppercase tracking-[0.05em] transition-colors duration-500", running ? "text-ink" : "text-ink-3")}>
                  {k}
                </span>
                <span
                  className="truncate text-right text-[11px] text-ink-2 transition-opacity duration-500"
                  style={{ opacity: running ? 1 : 0, transitionDelay: running ? delay : "0ms" }}
                >
                  {f}
                </span>
                <span
                  className="absolute bottom-0 left-0 h-px bg-brand"
                  style={{ width: running ? "100%" : "0%", transition: running ? `width 1000ms ease ${i * 550}ms` : "none" }}
                />
              </li>
            );
          })}
        </ul>
      </div>

      <div className="relative mt-[22px] hidden h-[128px] md:block" aria-hidden="true">
        <ChartSvg w={36} h={128} grid={0}>
          {[16, 48, 80, 112].map((y, i) => (
            <DrawPath key={y} d={`M0 ${y} C18 ${y} 18 64 36 64`} stroke="#3157D5" width={1.25} active={done} delay={i * 0.12} duration={0.7} />
          ))}
        </ChartSvg>
      </div>

      <div className="sm:mt-[22px]">
        <div
          className={cn(
            "relative flex h-[128px] flex-col justify-between rounded-[4px] border p-3 transition-colors duration-500",
            done ? "border-ink bg-white" : "border-dashed border-line-strong bg-paper/60",
          )}
        >
          <div className="flex items-center justify-between">
            <Label className={done ? "text-ink" : ""}>Likely cause</Label>
            <span className={cn("transition-opacity duration-500", done ? "opacity-100" : "opacity-0")}>
              <Tag tone="green">High</Tag>
            </span>
          </div>
          <div className="relative">
            <p className={cn("absolute inset-0 text-xs text-ink-3 transition-opacity duration-300", done ? "opacity-0" : "opacity-100")}>
              Waiting for evidence…
            </p>
            <div className={cn("transition-opacity duration-500", done ? "opacity-100" : "opacity-0")}>
              <div className="font-serif text-[24px] leading-none text-ink">SERP intent shift</div>
              <div className="mt-2 flex items-center gap-2">
                <Meter value={91} tone="blue" active={done} delay={300} className="flex-1" />
                <span className="num whitespace-nowrap text-[10px] text-ink">91% CONFIDENCE</span>
              </div>
            </div>
          </div>
          <div
            className={cn(
              "flex h-7 items-center justify-between rounded-[3px] bg-ink px-2.5 text-[11px] font-medium uppercase tracking-[0.05em] text-white transition-all duration-500",
              step >= 5 ? "translate-y-0 opacity-100" : "translate-y-1 opacity-0",
            )}
          >
            Update article <Arrow size={12} />
          </div>
        </div>
      </div>
    </div>
  );
}

function ViewMonitor({ step, cycle, run }: { step: number; cycle: number; run: boolean }) {
  return (
    <div className="flex h-full flex-col overflow-hidden lg:flex-row">
      <aside className="shrink-0 border-b border-line lg:w-[272px] lg:border-b-0 lg:border-r">
        <Portfolio step={step} cycle={cycle} run={run} />
      </aside>
      <div className="flex min-w-0 flex-1 flex-col p-4 sm:p-5">
        <SignalHeader step={step} />
        <Graph step={step} />
        <Investigation step={step} />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ view B: workspace */

function Skeleton({ widths }: { widths: number[] }) {
  return (
    <div className="space-y-1.5" aria-hidden="true">
      {widths.map((w, i) => (
        <div key={i} className="h-[7px] rounded-[1px] bg-line" style={{ width: `${w}%` }} />
      ))}
    </div>
  );
}

function Change({ step, n, oldText, newText }: { step: number; n: number; oldText: string; newText: string }) {
  const shown = step >= 6;
  const reviewed = step >= 7;
  const done = step >= 8;
  return (
    <div className="relative pl-5">
      <span
        className={cn(
          "absolute bottom-0.5 left-0 top-0.5 w-[2px] rounded-[1px] transition-colors duration-500",
          done ? "bg-line-strong" : shown ? "bg-brand" : "bg-transparent",
        )}
      />
      {reviewed && (
        <span
          className="fade-up absolute -left-[7px] top-0.5 grid h-3.5 w-3.5 place-items-center rounded-full bg-grow text-white"
          style={{ animationDelay: `${n * 650}ms` }}
        >
          <Check size={9} />
        </span>
      )}
      <p className="text-[12.5px] leading-[1.7] text-ink sm:text-[13px]">
        <span
          className={cn(
            "transition-colors duration-500",
            shown && !done && "rounded-[2px] bg-decline-soft text-decline line-through decoration-decline/60",
            done && "hidden",
          )}
          style={{ transitionDelay: shown ? `${n * 250}ms` : "0ms" }}
        >
          {oldText}
        </span>
        {shown && (
          <ins
            className={cn(
              "no-underline",
              !done && "ml-1 rounded-[2px] bg-grow-soft px-0.5 underline decoration-grow/60 underline-offset-2",
            )}
            style={{ animation: "ins-in .6s ease both", animationDelay: `${n * 250 + 800}ms` }}
          >
            {newText}
          </ins>
        )}
      </p>
    </div>
  );
}

function Doc({ step }: { step: number }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-9 shrink-0 items-center justify-between gap-2 border-b border-line px-4">
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate text-xs font-medium">Best CRM Software for Growing Teams</span>
          <Tag>v15 draft</Tag>
        </div>
        {step >= 9 ? (
          <Tag tone="green" className="fade-in">
            Published
          </Tag>
        ) : (
          <span className="label hidden sm:inline">Suggesting</span>
        )}
      </div>
      <div className="min-h-0 flex-1 space-y-3 overflow-hidden p-4 sm:p-5">
        <h4 className="font-serif text-[22px] leading-tight">Pricing comparison</h4>
        <Skeleton widths={[100, 88]} />
        <Change
          step={step}
          n={1}
          oldText="Plans start at around $25 per seat per month."
          newText="Entry pricing now varies widely, and most vendors gate automation behind higher tiers. Compare plans by seats, automation limits, and support."
        />
        <Skeleton widths={[96, 72]} />
        <Change
          step={step}
          n={2}
          oldText="Last updated June 2024."
          newText="Pricing last verified May 2026."
        />
        <Skeleton widths={[90]} />
      </div>
    </div>
  );
}

const E = experimentSeries(60, 0.4, 0.27, 5);
const RW = 600;
const RH = 220;
const RP = { min: 76, max: 142, l: 4, r: 4, t: 12, b: 12 };
const ctrlPts = mapPts(E.control, RW, RH, RP);
const updPts = mapPts(E.updated, RW, RH, RP);
const PUB_I = Math.round(0.4 * 59);
const pubX = ctrlPts[PUB_I][0];
const DIP_I = 41;

function ResultChart({ show }: { show: boolean }) {
  const endMid = (ctrlPts[59][1] + updPts[59][1]) / 2;
  return (
    <div
      className={cn(
        "absolute inset-0 flex flex-col bg-white transition-opacity duration-700",
        show ? "opacity-100" : "pointer-events-none opacity-0",
      )}
    >
      <div className="flex h-9 shrink-0 items-center justify-between gap-2 border-b border-line px-4">
        <span className="truncate text-xs font-medium">Organic clicks · updated vs matched control</span>
        <Tag>Illustrative data</Tag>
      </div>
      <div className="relative min-h-0 flex-1 px-4 pb-4 pt-5 sm:px-5">
        <div className="relative h-full">
          <ChartSvg w={RW} h={RH}>
            <FadePath d={areaBetween(updPts.slice(PUB_I), ctrlPts.slice(PUB_I))} fill="#EEF2FF" active={show} delay={2.6} />
            <FadePath d={`M${pubX} 0 L${pubX} ${RH}`} stroke="#92958E" dash="3 4" active={show} delay={0.3} />
            <DrawPath d={linePath(ctrlPts)} stroke="#92958E" width={1.75} active={show} delay={0.3} duration={2.2} />
            <DrawPath d={linePath(updPts)} stroke="#3157D5" width={2} active={show} delay={0.5} duration={2.2} />
          </ChartSvg>
          <At x={pubX} y={0} w={RW} h={RH} className="-translate-y-full pb-1">
            <span className="block -translate-x-1/2 whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.06em] text-ink-2">
              Published
            </span>
          </At>
          <At x={ctrlPts[DIP_I][0]} y={ctrlPts[DIP_I][1]} w={RW} h={RH} className="translate-y-2.5">
            <span
              className="block -translate-x-1/2 whitespace-nowrap font-mono text-[9px] text-ink-2 transition-opacity duration-700"
              style={{ opacity: show ? 1 : 0, transitionDelay: show ? "2.8s" : "0s" }}
            >
              Both dip — market noise
            </span>
          </At>
          <At x={RW} y={endMid} w={RW} h={RH} className="-translate-x-full -translate-y-1/2 pr-2">
            <span
              className="rounded-[3px] bg-brand px-1.5 py-1 font-mono text-[11px] text-white transition-opacity duration-500"
              style={{ opacity: show ? 1 : 0, transitionDelay: show ? "3s" : "0s" }}
            >
              +27%
            </span>
          </At>
        </div>
        <div className="absolute bottom-1 left-4 flex gap-4 font-mono text-[9px] uppercase tracking-[0.06em] text-ink-2 sm:left-5">
          <span className="flex items-center gap-1.5">
            <span className="h-[2px] w-3 bg-brand" /> Updated
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-[2px] w-3 bg-ink-3" /> Control
          </span>
        </div>
      </div>
    </div>
  );
}

function Rail({ step }: { step: number }) {
  const [pressed, setPressed] = useState(false);
  useEffect(() => {
    if (step === 8) {
      const t = window.setTimeout(() => setPressed(true), 950);
      return () => window.clearTimeout(t);
    }
    setPressed(step > 8);
  }, [step]);

  const items = [
    { t: "Draft generated", s: <>v15</>, done: step >= 6 },
    { t: "Claims verified", s: <>11 / 11</>, done: step >= 6 },
    {
      t: "Changes reviewed",
      s: (
        <>
          <Num to={3} active={step >= 7} duration={2.2} /> / 3
        </>
      ),
      done: step >= 8,
    },
    { t: "Approved by reviewer", s: null, done: pressed },
    { t: "Published to CMS", s: null, done: step >= 9 },
    { t: "Outcome measured", s: <>28 days</>, done: step >= 10 },
  ];
  const cur = items.findIndex((i) => !i.done);

  return (
    <div className="relative flex h-full flex-col p-4 sm:p-5">
      <Label>{step >= 10 ? "Outcome" : "Human review"}</Label>
      <ol className="mt-3 space-y-2.5">
        {items.map((it, i) => (
          <li key={it.t} className="flex items-center gap-2.5 text-[12.5px]">
            <span
              className={cn(
                "grid h-4 w-4 shrink-0 place-items-center rounded-full border transition-colors duration-300",
                it.done ? "border-grow bg-grow text-white" : i === cur ? "border-brand" : "border-line-strong",
              )}
            >
              {it.done ? <Check size={10} /> : i === cur ? <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-brand" /> : null}
            </span>
            <span className={it.done || i === cur ? "text-ink" : "text-ink-3"}>{it.t}</span>
            <span className="num ml-auto text-[11px] text-ink-2">{it.s}</span>
          </li>
        ))}
      </ol>

      <div className="relative mt-auto pt-4">
        {step < 10 ? (
          <>
            <div
              className={cn(
                "flex h-10 items-center justify-center gap-2 rounded-[4px] border text-sm font-medium transition-colors duration-300",
                pressed
                  ? "border-grow bg-grow text-white"
                  : step >= 7
                    ? "border-ink bg-white text-ink"
                    : "border-line-strong bg-paper text-ink-3",
              )}
            >
              {pressed ? (
                <>
                  <Check size={14} /> Approved
                </>
              ) : (
                "Approve update"
              )}
            </div>
            <span
              className="pointer-events-none absolute right-[22%] top-[34px] z-10 transition-all duration-[900ms] ease-in-out"
              style={{
                opacity: step === 7 || step === 8 ? 1 : 0,
                transform: step >= 8 ? "translate(0,0)" : "translate(-48px,48px)",
              }}
            >
              <Cursor size={18} />
            </span>
            {step >= 9 && (
              <div className="fade-up mt-3 rounded-[4px] border border-grow/30 bg-grow-soft p-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] font-medium uppercase tracking-[0.08em] text-grow">Published</span>
                  <StatusDot tone="green" />
                </div>
                <p className="mt-1 font-mono text-[11px] text-ink-2">/best-crm-software · pushed to CMS · just now</p>
              </div>
            )}
          </>
        ) : (
          <div className="fade-up border-t border-line pt-4">
            <Label>Relative uplift</Label>
            <div className="mt-1 text-[40px] leading-none text-grow">
              <Num to={27} prefix="+" suffix="%" duration={1.6} />
            </div>
            <div className="mt-3 flex items-center justify-between">
              <Label>Confidence</Label>
              <span className="num text-sm">88%</span>
            </div>
            <div className="mt-1.5">
              <Meter value={88} tone="green" />
            </div>
            <p className="mt-3 text-[11px] leading-snug text-ink-2">vs. matched untouched pages, 28 days after publish.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ViewWorkspace({ step }: { step: number }) {
  return (
    <div className="flex h-full flex-col overflow-hidden md:flex-row">
      <div className="relative h-[300px] shrink-0 border-b border-line md:h-auto md:min-w-0 md:flex-1 md:border-b-0 md:border-r">
        <Doc step={step} />
        <ResultChart show={step >= 10} />
      </div>
      <aside className="min-h-0 flex-1 md:w-[270px] md:flex-none">
        <Rail step={step} />
      </aside>
    </div>
  );
}

/* ------------------------------------------------------------------ shell */

export function SignalMonitor() {
  const reduce = useReducedMotion();
  const wrapRef = useRef<HTMLDivElement>(null);
  const inView = useInView(wrapRef, { margin: "0px 0px -10% 0px" });
  const [step, setStep] = useState(reduce ? 5 : 0);
  const [playing, setPlaying] = useState(!reduce);
  const [cycle, setCycle] = useState(0);

  useEffect(() => {
    if (!playing || !inView) return;
    const t = window.setTimeout(() => {
      const next = (step + 1) % STEPS.length;
      setStep(next);
      if (next === 0) setCycle((c) => c + 1);
    }, DURATIONS[step]);
    return () => window.clearTimeout(t);
  }, [step, playing, inView]);

  const inWorkspace = step >= 6;

  return (
    <LiveMotion.Provider value={true}>
    <div ref={wrapRef}>
      <p id="monitor-desc" className="sr-only">
        {DESCRIPTION}
      </p>
      <Window
        className="mx-auto"
        title={
          <>
            <LogoMark size={16} />
            <span className="hidden font-medium text-ink sm:inline">Content Intelligence</span>
            <span className="hidden text-ink-3 sm:inline">/</span>
            <span className="truncate font-mono text-[11px] text-ink-2">acme-saas.com</span>
            {inWorkspace && (
              <>
                <span className="hidden text-ink-3 md:inline">/</span>
                <span className="fade-in hidden truncate font-mono text-[11px] text-ink-2 md:inline">
                  best-crm-software / {step >= 10 ? "results" : "update draft"}
                </span>
              </>
            )}
          </>
        }
        right={
          <>
            <span className="hidden items-center gap-1.5 md:flex">
              <StatusDot tone="green" pulse />
              <span className="font-mono text-[10px] text-ink-2">Synced 2h ago</span>
            </span>
            <Tag>Sample data</Tag>
          </>
        }
      >
        <div role="img" aria-label="Product demonstration: from detected decline to measured result" aria-describedby="monitor-desc" className="relative h-[660px] sm:h-[600px] lg:h-[480px]">
          <div className={cn("absolute inset-0 transition-opacity duration-500", inWorkspace ? "pointer-events-none opacity-0" : "opacity-100")}>
            <ViewMonitor step={step} cycle={cycle} run={inView} />
          </div>
          <div className={cn("absolute inset-0 transition-opacity duration-500", inWorkspace ? "opacity-100" : "pointer-events-none opacity-0")}>
            <ViewWorkspace step={step} />
          </div>
        </div>
      </Window>

      <div className="mt-3 flex items-center gap-3">
        <button
          type="button"
          onClick={() => setPlaying((p) => !p)}
          aria-label={playing ? "Pause product demo" : "Play product demo"}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-[4px] border border-line-strong bg-white text-ink transition-colors hover:border-ink"
        >
          {playing ? <Pause size={14} /> : <Play size={14} />}
        </button>
        <div className="flex flex-1 items-center gap-1" role="group" aria-label="Demo steps">
          {STEPS.map((label, i) => (
            <button
              key={label}
              type="button"
              onClick={() => {
                setStep(i);
                if (i === 0) setCycle((c) => c + 1);
              }}
              aria-label={`Step ${i + 1} of ${STEPS.length}: ${label}`}
              aria-current={i === step ? "step" : undefined}
              className="group relative h-7 flex-1"
            >
              <span className={cn("absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 overflow-hidden rounded-[1px] transition-colors", i < step ? "bg-ink" : "bg-line-strong group-hover:bg-ink-3")}>
                {i === step && (
                  <span
                    key={`${cycle}-${step}`}
                    className="seg-anim absolute inset-0 origin-left bg-brand"
                    style={{
                      animation: `seg-fill ${DURATIONS[i]}ms linear forwards`,
                      animationPlayState: playing && inView ? "running" : "paused",
                    }}
                  />
                )}
              </span>
            </button>
          ))}
        </div>
        <span className="w-[132px] shrink-0 whitespace-nowrap text-right font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2 sm:w-[156px] sm:text-[11px] sm:tracking-[0.08em]">
          <span className="text-ink">{String(step + 1).padStart(2, "0")}</span>/{STEPS.length} · {STEPS[step]}
        </span>
      </div>
    </div>
    </LiveMotion.Provider>
  );
}
