import { useState } from "react";
import { cn } from "../utils/cn";
import { ArrowDown, Check, Close, Lock } from "./icons";
import { Container, Reveal, Section } from "./ui";

type Decision = null | "approved" | "changes" | "rejected";

const PIPE = [
  { k: "Detect", d: "Finds declines and unusual changes.", who: "ai" },
  { k: "Analyze", d: "Explains likely causes with confidence.", who: "ai" },
  { k: "Research", d: "Gathers and rates sources.", who: "ai" },
  { k: "Draft", d: "Proposes tracked changes.", who: "ai" },
  { k: "Verify", d: "Ties claims to evidence.", who: "ai" },
  { k: "Review", d: "A person reads every change.", who: "human" },
  { k: "Approve", d: "A person decides what ships.", who: "human" },
  { k: "Publish", d: "Pushes to your CMS.", who: "gate" },
] as const;

const MESSAGES: Record<Exclude<Decision, null>, string> = {
  approved: "Approved. The update is queued for your CMS. This is the only way anything gets published.",
  changes: "Changes requested. The draft goes back to the editor with your notes. Nothing is published.",
  rejected: "Rejected. Nothing is published and the page stays exactly as it is.",
};

export function HumanApproval() {
  const [decision, setDecision] = useState<Decision>(null);

  return (
    <Section id="control" chapter="09" chapterLabel="Human control" labelledBy="human-title" tone="white" className="lg:py-40">
      <Container>
        <Reveal>
          <div className="flex items-center gap-3">
            <span className="h-px w-8 bg-ink" />
            <span className="font-mono text-[11px] uppercase tracking-[0.1em] text-ink-2">
              <span className="text-brand">09</span>
              <span className="mx-1.5 text-ink-3">/</span>Human control
            </span>
          </div>
          <h2
            id="human-title"
            className="mt-6 font-serif text-[clamp(3.25rem,10.5vw,9.5rem)] font-normal leading-[0.92] tracking-[-0.035em] text-balance"
          >
            AI doesn’t press <em className="text-brand">publish.</em>
          </h2>
          <p className="mt-6 text-[clamp(1.25rem,2.4vw,1.75rem)] leading-snug text-ink-2">Your team decides what ships.</p>
        </Reveal>

        <Reveal className="mt-16 lg:mt-24">
          {/* bracket labels (desktop) */}
          <div className="mb-3 hidden grid-cols-8 gap-0 lg:grid" aria-hidden="true">
            <div className="col-span-5 flex items-center gap-3">
              <span className="label whitespace-nowrap">AI does the analysis and heavy lifting</span>
              <span className="h-px flex-1 bg-line-strong" />
            </div>
            <div className="col-span-2 flex items-center gap-3 px-3">
              <span className="label whitespace-nowrap font-medium text-brand">Human review</span>
              <span className="h-px flex-1 bg-brand" />
            </div>
            <div className="col-span-1 flex items-center justify-end">
              <span className="label whitespace-nowrap">Gate</span>
            </div>
          </div>

          <ol className="grid lg:grid-cols-8">
            {PIPE.map((p, i) => {
              const human = p.who === "human";
              const gate = p.who === "gate";
              const unlocked = gate && decision === "approved";
              const returned = decision === "changes" && p.k === "Draft";
              const approvedNode = decision === "approved" && p.k === "Approve";
              return (
                <li
                  key={p.k}
                  className={cn(
                    "relative border-l-2 pb-6 pl-5 transition-colors duration-500 last:pb-0 lg:border-l-0 lg:border-t-2 lg:px-0 lg:pb-6 lg:pl-0 lg:pr-3 lg:pt-5",
                    p.who === "ai" && "border-ink",
                    human && "border-brand bg-brand-soft/60 lg:px-3",
                    gate && (unlocked ? "border-grow" : "border-dashed border-line-strong"),
                    returned && "border-warn",
                  )}
                >
                  <div className="flex items-center gap-2">
                    <span className="num text-[11px] text-ink-3">{String(i + 1).padStart(2, "0")}</span>
                    {i > 0 && <ArrowDown size={12} className="text-ink-3 lg:hidden" />}
                  </div>
                  <div className="mt-1.5 flex items-center gap-2">
                    <span
                      className={cn(
                        "font-mono text-[13px] font-medium uppercase tracking-[0.08em]",
                        human ? "text-brand" : "text-ink",
                        gate && !unlocked && "text-ink-3",
                      )}
                    >
                      {p.k}
                    </span>
                    {gate && !unlocked && <Lock size={13} className="text-ink-3" />}
                    {(unlocked || approvedNode) && <Check size={14} className="text-grow" />}
                  </div>
                  <p className="mt-2 text-[13px] leading-snug text-ink-2">{p.d}</p>
                  {gate && (
                    <p className={cn("mt-2 font-mono text-[10px] uppercase tracking-[0.06em]", unlocked ? "text-grow" : "text-ink-3")}>
                      {unlocked ? "Unlocked · queued" : decision ? "Not published" : "Locked until approved"}
                    </p>
                  )}
                  {returned && <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.06em] text-warn">Returned to draft</p>}
                </li>
              );
            })}
          </ol>
        </Reveal>

        <Reveal className="mt-14 lg:mt-20">
          <div className="grid items-start gap-8 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-5">
              <div className="rounded-[6px] border border-line-strong bg-paper p-5 sm:p-6">
                <div className="flex items-center justify-between">
                  <span className="label text-ink">Review queue</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">Sample data</span>
                </div>
                <p className="mt-4 font-serif text-[26px] leading-[1.1] tracking-[-0.01em]">Update pricing comparison section</p>
                <p className="mt-1 font-mono text-[11px] text-ink-2">/best-crm-software · 3 changes · 11 of 11 claims verified</p>
                <div className="mt-5 flex flex-col gap-2 sm:flex-row lg:flex-col xl:flex-row">
                  <button
                    type="button"
                    onClick={() => setDecision("approved")}
                    aria-pressed={decision === "approved"}
                    className={cn(
                      "flex h-11 flex-1 items-center justify-center gap-2 rounded-[4px] border text-sm font-medium transition-colors",
                      decision === "approved" ? "border-grow bg-grow text-white" : "border-ink bg-ink text-white hover:border-brand hover:bg-brand",
                    )}
                  >
                    <Check size={15} /> Approve update
                  </button>
                  <button
                    type="button"
                    onClick={() => setDecision("changes")}
                    aria-pressed={decision === "changes"}
                    className={cn(
                      "flex h-11 flex-1 items-center justify-center rounded-[4px] border text-sm font-medium transition-colors",
                      decision === "changes" ? "border-warn bg-warn-soft text-warn" : "border-line-strong bg-white text-ink hover:border-ink",
                    )}
                  >
                    Request changes
                  </button>
                  <button
                    type="button"
                    onClick={() => setDecision("rejected")}
                    aria-pressed={decision === "rejected"}
                    className={cn(
                      "flex h-11 flex-1 items-center justify-center gap-1.5 rounded-[4px] border text-sm font-medium transition-colors",
                      decision === "rejected" ? "border-decline bg-decline-soft text-decline" : "border-line-strong bg-white text-ink hover:border-decline hover:text-decline",
                    )}
                  >
                    <Close size={13} /> Reject
                  </button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 lg:pt-2">
              <div className="label">Result</div>
              <p aria-live="polite" className="mt-3 min-h-[5.5rem] max-w-[560px] font-serif text-[clamp(1.5rem,2.6vw,2.15rem)] leading-[1.15] tracking-[-0.01em]">
                {decision ? (
                  <span key={decision} className="fade-in block">
                    {MESSAGES[decision]}
                  </span>
                ) : (
                  <span className="text-ink-3">Waiting for a decision. Try one — nothing here is permanent.</span>
                )}
              </p>
              {decision && (
                <button type="button" onClick={() => setDecision(null)} className="mt-3 font-mono text-[11px] uppercase tracking-[0.08em] text-ink-2 underline underline-offset-4 hover:text-ink">
                  Reset demo
                </button>
              )}
            </div>
          </div>
        </Reveal>
      </Container>
    </Section>
  );
}
