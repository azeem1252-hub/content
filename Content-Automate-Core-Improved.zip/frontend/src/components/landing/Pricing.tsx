import { Check } from "./icons";
import { Button, Container, Reveal, Section, SectionHeading } from "./ui";

const TIERS = [
  {
    name: "Starter",
    who: "Small content teams",
    inherits: "",
    items: [
      "Connect Search Console and Analytics",
      "Decay and anomaly detection",
      "Seasonality vs. structural decline",
      "Evidence behind every recommendation",
      "One CMS connection",
      "Human approval on every change",
    ],
  },
  {
    name: "Growth",
    who: "SaaS marketing teams",
    inherits: "Everything in Starter, plus",
    items: [
      "Opportunity scoring for new content",
      "Research briefs with source quality",
      "Claim verification and source trails",
      "Measurement against matched controls",
      "Multiple CMS connections",
      "Roles and approval rules",
    ],
  },
  {
    name: "Agency",
    who: "Multiple client sites",
    inherits: "Everything in Growth, plus",
    items: [
      "Separate workspace per client library",
      "Client approval workflows",
      "Client-ready reporting",
      "Guided onboarding",
    ],
  },
];

export function Pricing() {
  return (
    <Section id="pricing" chapter="16" chapterLabel="Pricing" labelledBy="price-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="price-title"
            n="16"
            chapter="Pricing"
            title="Priced for the size of your library."
            sub="Three plans, shaped around how many sites and articles you run. We’d rather quote it properly than print a number that doesn’t fit."
          />
        </Reveal>

        <Reveal className="mt-12 grid gap-px overflow-hidden rounded-[6px] border border-line-strong bg-line-strong lg:mt-16 lg:grid-cols-3">
          {TIERS.map((t) => (
            <article key={t.name} className="flex flex-col bg-white p-6 sm:p-8">
              <div className="label text-ink">{t.name}</div>
              <p className="mt-2 font-serif text-[30px] leading-[1.05] tracking-[-0.01em]">{t.who}</p>
              <div className="mt-6 border-t border-line pt-5">
                <div className="font-serif text-[40px] leading-none tracking-[-0.02em]">Talk to us</div>
                <p className="mt-2 text-[13px] text-ink-2">Based on library size and number of sites.</p>
              </div>
              <div className="mt-6 min-h-[22px] font-mono text-[10.5px] uppercase tracking-[0.07em] text-ink-2">{t.inherits}</div>
              <ul className="mt-2 flex-1 space-y-2.5">
                {t.items.map((i) => (
                  <li key={i} className="flex items-start gap-2.5 text-[14px] leading-snug text-ink">
                    <Check size={14} className="mt-0.5 shrink-0 text-grow" />
                    {i}
                  </li>
                ))}
              </ul>
              <Button href="#cta" variant="secondary" arrow className="mt-8 w-full">
                Talk to us
              </Button>
            </article>
          ))}
        </Reveal>
        <p className="mt-4 text-[13px] text-ink-2">Every plan keeps a human approval step before anything is published.</p>
      </Container>
    </Section>
  );
}
