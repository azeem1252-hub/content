import type { ReactNode } from "react";
import { ChartSvg } from "./charts";
import { Check } from "./icons";
import { Container, Reveal, Section, SectionHeading, Tag } from "./ui";
import { experimentSeries, linePath, mapPts } from "../lib/chart";

const E = experimentSeries(40, 0.4, 0.27, 12);
const mp = { min: 76, max: 140, t: 6, b: 6 };
const ctrl = linePath(mapPts(E.control, 300, 90, mp));
const upd = linePath(mapPts(E.updated, 300, 90, mp));

function Case({ role, title, line, children }: { role: string; title: string; line: string; children: ReactNode }) {
  return (
    <article className="flex flex-col bg-white p-5 sm:p-8">
      <span className="label text-brand">{role}</span>
      <h3 className="mt-3 font-serif text-[34px] leading-[1.05] tracking-[-0.015em]">{title}</h3>
      <p className="mt-2 max-w-[360px] text-[15px] leading-snug text-ink-2">{line}</p>
      <div className="mt-6 flex-1 rounded-[4px] border border-line-strong bg-paper/60 p-3 sm:p-4">{children}</div>
    </article>
  );
}

const Head = ({ left, right }: { left: string; right?: ReactNode }) => (
  <div className="mb-2 flex items-center justify-between">
    <span className="label text-ink">{left}</span>
    {right ?? <Tag>Sample data</Tag>}
  </div>
);

export function UseCases() {
  return (
    <Section id="teams" chapter="13" chapterLabel="Who it’s for" labelledBy="uc-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="uc-title"
            n="13"
            chapter="Who it’s for"
            title="One platform. Four ways teams use it."
          />
        </Reveal>

        <Reveal className="mt-12 grid gap-px overflow-hidden rounded-[6px] border border-line-strong bg-line-strong md:grid-cols-2 lg:mt-16">
          <Case role="SEO teams" title="Find decay. Prioritize updates." line="See which pages are slipping, why, and which ones are worth the work.">
            <Head left="Decay queue" />
            <table className="w-full text-left text-[12.5px]">
              <caption className="sr-only">Pages ranked by decay and priority</caption>
              <tbody>
                {[
                  ["/best-crm-software", "−34%", "Do now", "red"],
                  ["/ai-support-software", "−21%", "Do now", "red"],
                  ["/saas-pricing-guide", "−12%", "Watch", "amber"],
                  ["/startup-tools", "−4%", "Leave", "neutral"],
                ].map(([p, d, t, tone]) => (
                  <tr key={p} className="border-t border-line">
                    <td className="truncate py-2.5 pr-2 font-mono text-[11.5px] text-ink">{p}</td>
                    <td className="num py-2.5 pr-2 text-decline">{d}</td>
                    <td className="py-2.5 text-right">
                      <Tag tone={tone as "red" | "amber" | "neutral"}>{t}</Tag>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Case>

          <Case role="Content teams" title="Turn research into verified content." line="Briefs arrive with sources, claims, and a clear list of what still needs a person.">
            <Head left="Brief · AI customer support software" />
            <ul className="text-[13px]">
              {[
                ["Intent", "Commercial investigation"],
                ["Questions", "6 of 6 covered"],
                ["Sources", "17 high-quality"],
                ["Claims", "11 of 11 verified"],
              ].map(([k, v]) => (
                <li key={k} className="flex items-center justify-between border-t border-line py-2.5">
                  <span className="flex items-center gap-2 text-ink">
                    <Check size={13} className="text-grow" /> {k}
                  </span>
                  <span className="font-mono text-[11.5px] text-ink-2">{v}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 flex items-center justify-between rounded-[3px] bg-ink px-3 py-2 text-[12px] font-medium text-white">
              Draft ready for human review <span aria-hidden="true">→</span>
            </div>
          </Case>

          <Case role="SaaS marketing teams" title="Connect content work to growth." line="Show leadership what changed, what it did, and how sure you are.">
            <Head left="Updated vs control" />
            <div className="relative mt-3 h-[90px] border-b border-line">
              <ChartSvg w={300} h={90} grid={2}>
                <path d={ctrl} fill="none" stroke="#92958E" strokeWidth={1.5} strokeLinejoin="round" />
                <path d={upd} fill="none" stroke="#3157D5" strokeWidth={2} strokeLinejoin="round" />
              </ChartSvg>
            </div>
            <div className="mt-3 flex items-end justify-between">
              <div>
                <div className="label">Relative uplift</div>
                <div className="num mt-1 text-[28px] leading-none text-grow">+27%</div>
              </div>
              <div className="text-right">
                <div className="label">Confidence</div>
                <div className="num mt-1 text-[18px] leading-none text-ink">88%</div>
              </div>
            </div>
          </Case>

          <Case role="Agencies" title="Run many libraries. Keep control." line="Separate workspaces and approval steps for every client site.">
            <Head left="Client libraries" />
            <ul className="text-[13px]">
              {[
                ["Library A", "142 articles", "2 awaiting approval", "amber"],
                ["Library B", "87 articles", "Up to date", "green"],
                ["Library C", "310 articles", "1 awaiting approval", "amber"],
              ].map(([n, a, s, tone]) => (
                <li key={n} className="flex items-center justify-between gap-2 border-t border-line py-2.5">
                  <span>
                    <span className="font-medium text-ink">{n}</span>
                    <span className="ml-2 font-mono text-[11px] text-ink-3">{a}</span>
                  </span>
                  <Tag tone={tone as "amber" | "green"}>{s}</Tag>
                </li>
              ))}
            </ul>
            <div className="mt-3 flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.06em] text-ink-2">
              <span className="rounded-[3px] border border-line-strong bg-white px-1.5 py-1">Editor</span>→
              <span className="rounded-[3px] border border-line-strong bg-white px-1.5 py-1">Client approver</span>→
              <span className="rounded-[3px] border border-line-strong bg-white px-1.5 py-1">Publish</span>
            </div>
          </Case>
        </Reveal>
      </Container>
    </Section>
  );
}
