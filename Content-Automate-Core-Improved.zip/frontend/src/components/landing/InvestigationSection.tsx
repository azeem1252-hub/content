import { useState } from "react";
import { cn } from "../utils/cn";
import { ChartSvg, DrawPath, FadePath } from "./charts";
import { Check } from "./icons";
import { Container, Meter, Num, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { decaySeries, linePath, mapPts, seasonalSeries } from "../lib/chart";
import { useOnceInView } from "../lib/hooks";

const W = 720;
const H = 300;
const N = 90;
const P = { min: 20, max: 92, t: 24, b: 16 };
const clicks = mapPts(decaySeries(N, { seed: 9, peakAt: 0.45, drop: 0.34, noise: 2, start: 48, peak: 80 }), W, H, P);
const lastYear = mapPts(seasonalSeries(N, { seed: 31, base: 62, amp: 2.5, cycles: 1.5, noise: 1.2 }), W, H, P);
const clicksD = linePath(clicks);

const CAUSES = [
  {
    id: "intent",
    label: "Search intent shifted",
    pct: 87,
    at: 55,
    marker: "Intent shift",
    note: "Top-ranking pages moved from buyer’s guides to side-by-side comparisons.",
  },
  {
    id: "coverage",
    label: "Competitor coverage",
    pct: 81,
    at: 47,
    marker: "Competitors add pricing",
    note: "Three competing pages added pricing tables for the same query set.",
  },
  {
    id: "fresh",
    label: "Content freshness",
    pct: 74,
    at: 18,
    marker: "Last update",
    note: "The last substantive edit was 11 months ago. Pricing was last verified 14 months ago.",
  },
  {
    id: "season",
    label: "Seasonality",
    pct: 18,
    at: -1,
    marker: "",
    note: "The same weeks last year were flat. Seasonality is unlikely to explain this drop.",
  },
];

export function InvestigationSection() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const [sel, setSel] = useState(0);
  const cause = CAUSES[sel];

  return (
    <Section id="investigation" chapter="02" chapterLabel="The investigation" labelledBy="inv-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="inv-title"
            n="02"
            chapter="The investigation"
            title="A traffic drop isn’t a diagnosis."
            sub="Understand what changed before deciding what to do."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Decay analysis</span>
                <span className="text-ink-3">/</span>
                <span className="truncate font-mono text-[11px] text-ink-2">/best-crm-software</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid lg:grid-cols-[1.4fr_1fr]">
              {/* graph */}
              <div className="border-b border-line p-4 sm:p-6 lg:border-b-0 lg:border-r">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="label">Organic clicks · last 180 days</span>
                  <div className="flex items-center gap-4 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
                    <span className="flex items-center gap-1.5">
                      <span className="h-[2px] w-3 bg-ink" /> This year
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="h-0 w-3 border-t border-dashed border-ink-3" /> Last year
                    </span>
                  </div>
                </div>

                <div className="relative mt-4 h-[230px] border-b border-line sm:h-[300px]">
                  <ChartSvg w={W} h={H}>
                    <FadePath d={linePath(lastYear)} stroke="#92958E" dash="4 4" active={inView && sel === 3} opacity={1} />
                    <DrawPath d={clicksD} stroke="#161719" width={2} active={inView} duration={2} />
                  </ChartSvg>

                  {CAUSES.filter((c) => c.at >= 0).map((c, i) => {
                    const on = sel === i;
                    const pt = clicks[c.at];
                    const left = `${(pt[0] / W) * 100}%`;
                    const top = `${(pt[1] / H) * 100}%`;
                    const delay = inView ? `${1200 + i * 250}ms` : "0ms";
                    return (
                      <div key={c.id} aria-hidden="true">
                        <span
                          className="absolute border-l border-dashed transition-all duration-500"
                          style={{
                            left,
                            top,
                            bottom: 0,
                            borderColor: on ? "#161719" : "#CACDC5",
                            opacity: inView ? 1 : 0,
                            transitionDelay: delay,
                          }}
                        />
                        <span
                          className={cn(
                            "absolute grid h-5 w-5 -translate-x-1/2 -translate-y-[28px] place-items-center rounded-full border font-mono text-[10px] transition-all duration-300",
                            on ? "border-ink bg-ink text-white" : "border-line-strong bg-white text-ink-2",
                          )}
                          style={{ left, top, opacity: inView ? 1 : 0, transitionDelay: delay }}
                        >
                          {i + 1}
                        </span>
                      </div>
                    );
                  })}
                  <div className="absolute bottom-2 left-2 hidden sm:block">
                    <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">180d ago</span>
                  </div>
                  <div className="absolute bottom-2 right-2">
                    <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">Today</span>
                  </div>
                </div>

                <div className="mt-4 flex min-h-[64px] items-start gap-3 rounded-[4px] border border-line bg-paper/60 p-3.5">
                  <span className="num mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-ink text-[10px] text-white">
                    {sel + 1}
                  </span>
                  <div key={cause.id} className="fade-in">
                    <div className="text-[13px] font-medium text-ink">
                      {cause.label}
                      {cause.marker && <span className="ml-2 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">{cause.marker}</span>}
                    </div>
                    <p className="mt-0.5 text-[13px] leading-snug text-ink-2">{cause.note}</p>
                  </div>
                </div>
              </div>

              {/* diagnosis */}
              <div className="flex flex-col p-4 sm:p-6">
                <div className="flex items-center justify-between">
                  <span className="label text-ink">Decay analysis</span>
                  <Tag tone="red">Declining</Tag>
                </div>
                <h3 className="mt-4 font-serif text-[32px] leading-none tracking-[-0.01em]">Best CRM Software</h3>
                <div className="mt-5 flex items-end justify-between border-b border-line pb-5">
                  <div>
                    <div className="label">Observed decline</div>
                    <div className="mt-1 font-mono text-[11px] text-ink-3">Organic clicks, vs. prior 90 days</div>
                  </div>
                  <div className="text-[40px] leading-none text-decline">
                    <Num to={34} prefix="−" suffix="%" active={inView} duration={1.6} />
                  </div>
                </div>

                <div className="mt-5">
                  <div className="label">Likely causes</div>
                  <ul className="mt-2">
                    {CAUSES.map((c, i) => (
                      <li key={c.id} className="border-t border-line first:border-t-0">
                        <button
                          type="button"
                          onMouseEnter={() => setSel(i)}
                          onFocus={() => setSel(i)}
                          onClick={() => setSel(i)}
                          aria-pressed={sel === i}
                          className={cn(
                            "-mx-2 grid w-[calc(100%+1rem)] grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1.5 rounded-[3px] px-2 py-2.5 text-left transition-colors",
                            sel === i ? "bg-paper" : "hover:bg-paper/60",
                          )}
                        >
                          <span className={cn("text-[14px]", sel === i ? "font-medium text-ink" : "text-ink")}>{c.label}</span>
                          <span className="num text-[13px] text-ink">{c.pct}%</span>
                          <span className="col-span-2">
                            <Meter
                              value={c.pct}
                              tone={c.pct < 30 ? "muted" : "ink"}
                              active={inView}
                              delay={300 + i * 250}
                              height="h-[3px]"
                            />
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-5 rounded-[4px] border border-line-strong p-4">
                  <div className="flex items-end justify-between">
                    <div>
                      <div className="label">Overall confidence</div>
                      <div className="mt-1 text-[44px] leading-none text-ink">
                        <Num to={91} suffix="%" active={inView} duration={1.8} />
                      </div>
                    </div>
                    <Tag tone="green" className="mb-1">
                      <Check size={10} /> High confidence
                    </Tag>
                  </div>
                </div>

                <div className="mt-auto pt-5">
                  <div className="flex items-start gap-3 border-t border-line pt-4">
                    <span className="mt-1.5 h-px w-4 shrink-0 bg-ink" />
                    <div>
                      <p className="font-serif text-[22px] italic leading-tight">Not enough evidence for a technical issue.</p>
                      <p className="mt-1.5 text-[12px] leading-snug text-ink-2">
                        When the data doesn’t support a cause, we say so instead of inventing one.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
