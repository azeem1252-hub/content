import { useEffect, useState } from "react";
import { useCalm } from "../lib/motion";
import { cn } from "../utils/cn";
import { Arrow, ArrowDown, Check, Loop } from "./icons";
import { INTEGRATIONS } from "./integrationData";
import { Container, Reveal, Section, SectionHeading, StatusDot, Tag } from "./ui";
import { useOnceInView } from "../lib/hooks";

const PACKAGE = ["SEO metadata", "Structured data", "Internal links", "Images", "Alt text", "Sources"];
const CMS = INTEGRATIONS.filter((i) => i.kind === "CMS");

function Connector() {
  return (
    <div className="flex items-center justify-center py-1 text-ink-3 lg:px-2 lg:py-0" aria-hidden="true">
      <ArrowDown size={16} className="lg:hidden" />
      <Arrow size={16} className="hidden lg:block" />
    </div>
  );
}

export function PublishingFlow() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const reduce = useCalm();
  const [phase, setPhase] = useState(0);
  const [pkg, setPkg] = useState(0);
  const [cms, setCms] = useState(0);
  const [run, setRun] = useState(0);

  useEffect(() => {
    if (!inView) return;
    if (reduce) {
      setPhase(4);
      setPkg(PACKAGE.length);
      return;
    }
    setPhase(0);
    setPkg(0);
    const timers: number[] = [];
    const at = (ms: number, fn: () => void) => timers.push(window.setTimeout(fn, ms));
    at(400, () => setPhase(1));
    at(1200, () => setPhase(2));
    PACKAGE.forEach((_, i) => at(1400 + i * 360, () => setPkg(i + 1)));
    at(3800, () => setPhase(3));
    at(5600, () => setPhase(4));
    return () => timers.forEach((t) => window.clearTimeout(t));
  }, [inView, run, reduce]);

  const dest = CMS[cms];

  return (
    <Section id="publishing" chapter="10b" chapterLabel="Publishing" labelledBy="pub-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="pub-title"
            n="10b"
            chapter="Publishing"
            title="Approved once. Published where it belongs."
            sub="After approval, the update is packaged with everything the page needs and pushed to your CMS, where supported. The previous version is saved first."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <div className="flex items-center justify-between pb-3">
            <span className="label">Publish run · sample data</span>
            <button
              type="button"
              onClick={() => setRun((r) => r + 1)}
              className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.08em] text-ink-2 transition-colors hover:text-ink"
            >
              <Loop size={13} /> Replay
            </button>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-stretch">
            {/* 1. approved */}
            <div className={cn("flex-1 rounded-[6px] border bg-paper p-5 transition-colors duration-500 lg:max-w-[230px]", phase >= 1 ? "border-ink" : "border-line-strong")}>
              <div className="flex items-center justify-between">
                <span className="label text-ink">Approved</span>
                <span className={cn("grid h-5 w-5 place-items-center rounded-full transition-all duration-500", phase >= 1 ? "bg-grow text-white" : "border border-line-strong")}>
                  {phase >= 1 && <Check size={11} />}
                </span>
              </div>
              <p className="mt-4 font-serif text-[26px] leading-[1.08] tracking-[-0.01em]">Update pricing comparison section</p>
              <p className="mt-2 font-mono text-[11px] leading-relaxed text-ink-2">
                /best-crm-software
                <br />
                Approved by a human reviewer
              </p>
            </div>
            <Connector />

            {/* 2. package */}
            <div className={cn("flex-1 rounded-[6px] border bg-paper p-5 transition-colors duration-500", phase >= 2 ? "border-ink" : "border-line-strong")}>
              <div className="flex items-center justify-between">
                <span className="label text-ink">Content package</span>
                <span className="num text-[11px] text-ink-2">
                  {pkg}/{PACKAGE.length}
                </span>
              </div>
              <ul className="mt-3">
                {PACKAGE.map((p, i) => (
                  <li key={p} className="flex items-center gap-2.5 border-t border-line py-2 text-[14px]">
                    <span
                      className={cn(
                        "grid h-4 w-4 place-items-center rounded-[3px] border transition-all duration-300",
                        pkg > i ? "border-grow bg-grow text-white" : "border-line-strong bg-white",
                      )}
                    >
                      {pkg > i && <Check size={10} />}
                    </span>
                    <span className={pkg > i ? "text-ink" : "text-ink-3"}>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
            <Connector />

            {/* 3. CMS */}
            <div className={cn("flex-[1.2] rounded-[6px] border bg-white p-5 transition-colors duration-500", phase >= 3 ? "border-ink" : "border-line-strong")}>
              <div className="flex items-center justify-between">
                <span className="label text-ink">CMS</span>
                <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
                  <StatusDot tone="green" /> Connected
                </span>
              </div>
              <div className="mt-3 flex flex-wrap gap-1" role="tablist" aria-label="Choose CMS">
                {CMS.map((c, i) => (
                  <button
                    key={c.name}
                    type="button"
                    role="tab"
                    aria-selected={cms === i}
                    onClick={() => setCms(i)}
                    className={cn(
                      "flex items-center gap-1.5 rounded-[3px] border px-2 py-1 text-[12px] transition-colors",
                      cms === i ? "border-ink bg-ink text-white" : "border-line-strong text-ink-2 hover:border-ink hover:text-ink",
                    )}
                  >
                    <c.Icon size={12} /> {c.name}
                  </button>
                ))}
              </div>
              <dl className="mt-4 space-y-2.5 text-[13px]">
                <div className="flex justify-between gap-3 border-t border-line pt-2.5">
                  <dt className="text-ink-2">Destination</dt>
                  <dd className="text-right font-medium text-ink">{dest.name}</dd>
                </div>
                <div className="flex justify-between gap-3 border-t border-line pt-2.5">
                  <dt className="text-ink-2">Action</dt>
                  <dd className="text-right text-ink">Update existing page</dd>
                </div>
                <div className="flex justify-between gap-3 border-t border-line pt-2.5">
                  <dt className="text-ink-2">Safety</dt>
                  <dd className="text-right text-ink">Previous version saved</dd>
                </div>
              </dl>
              <div className="mt-4">
                <div className="h-[3px] overflow-hidden rounded-[1px] bg-line">
                  <div
                    className="h-full bg-brand"
                    style={{
                      width: phase >= 4 ? "100%" : phase >= 3 ? "92%" : "0%",
                      transition: phase >= 3 ? "width 1.7s cubic-bezier(.4,0,.2,1)" : "none",
                    }}
                  />
                </div>
                <div className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
                  {phase >= 4 ? "Pushed" : phase >= 3 ? "Pushing to CMS…" : "Waiting for package"}
                </div>
              </div>
            </div>
            <Connector />

            {/* 4. published */}
            <div
              className={cn(
                "flex-1 rounded-[6px] border p-5 transition-colors duration-500 lg:max-w-[230px]",
                phase >= 4 ? "border-grow bg-grow-soft" : "border-dashed border-line-strong bg-paper",
              )}
            >
              <div className="flex items-center justify-between">
                <span className={cn("label", phase >= 4 ? "font-medium text-grow" : "")}>{phase >= 4 ? "Published" : "Not yet published"}</span>
                {phase >= 4 && <StatusDot tone="green" pulse />}
              </div>
              <div className={cn("mt-4 transition-opacity duration-500", phase >= 4 ? "opacity-100" : "opacity-30")}>
                <p className="font-serif text-[26px] leading-[1.08] tracking-[-0.01em]">Live on {dest.name}</p>
                <p className="mt-2 font-mono text-[11px] leading-relaxed text-ink-2">
                  /best-crm-software
                  <br />
                  Just now · rollback available
                </p>
              </div>
              {phase >= 4 && (
                <div className="fade-in mt-4">
                  <Tag tone="green">Measuring starts</Tag>
                </div>
              )}
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
