import { Container, Reveal, Section } from "./ui";

const BUILT_FOR = [
  ["50+", "article libraries", "Enough content that “what deserves attention?” is a real question."],
  ["SEO", "teams", "Who need evidence they can defend, not a score they have to trust."],
  ["SaaS", "marketing teams", "Who have to connect content work to measurable growth."],
  ["Content", "agencies", "Who run several libraries and need controlled approvals."],
];

export function SocialProof() {
  return (
    <Section id="built-for" chapter="15" chapterLabel="Built for" labelledBy="bf-title">
      <Container>
        <Reveal>
          <div className="flex items-end justify-between gap-6 border-b border-ink pb-4">
            <h2 id="bf-title" className="label text-ink">
              Built for
            </h2>
            <span className="font-mono text-[10px] uppercase tracking-[0.08em] text-ink-3">15 / Built for</span>
          </div>
        </Reveal>
        <Reveal>
          <ul className="grid md:grid-cols-4">
            {BUILT_FOR.map(([a, b, c], i) => (
              <li key={a} className={`border-b border-line-strong py-8 md:border-b-0 md:py-10 ${i > 0 ? "md:border-l md:pl-8" : ""} ${i < 3 ? "md:pr-8" : ""}`}>
                <div className="font-serif text-[clamp(2.75rem,5vw,4.25rem)] leading-[0.95] tracking-[-0.02em]">{a}</div>
                <div className="mt-1 font-serif text-[clamp(1.4rem,2.2vw,1.9rem)] italic leading-tight text-ink-2">{b}</div>
                <p className="mt-4 text-[14px] leading-snug text-ink-2">{c}</p>
              </li>
            ))}
          </ul>
        </Reveal>
        <Reveal>
          <p className="mt-4 max-w-[680px] border-t border-line-strong pt-5 text-[14px] leading-[1.6] text-ink-2">
            You won’t find invented logos, testimonials, or metrics here. When customers have results they’re happy to
            share, this is where the real quotes, numbers, and case studies will go.
          </p>
        </Reveal>
      </Container>
    </Section>
  );
}
