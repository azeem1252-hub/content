import { useState } from "react";
import { cn } from "../utils/cn";
import { Check, Question, Warn } from "./icons";
import { Container, Num, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView, useSequence } from "../lib/hooks";

type Status = "verified" | "needs" | "conflict";

interface Claim {
  id: number;
  status: Status;
  text: string;
  source: string;
  published: string;
  evidence: "Strong" | "Moderate" | "Weak" | "Conflicting";
  conf: number;
  trail: { t: string; s: "ok" | "warn" | "pending" | "block"; d: string }[];
  note?: string;
}

const CLAIMS: Claim[] = [
  {
    id: 1,
    status: "verified",
    text: "AI customer support can reduce support workload by 30%.",
    source: "Research paper",
    published: "May 2026",
    evidence: "Strong",
    conf: 94,
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 2" },
      { t: "Source located", s: "ok", d: "Research paper · May 2026" },
      { t: "Cross-checked with a second source", s: "ok", d: "Consistent range" },
      { t: "Verified", s: "ok", d: "Wording matches the evidence" },
    ],
  },
  {
    id: 2,
    status: "verified",
    text: "Most teams connect an AI assistant to their existing help desk instead of replacing it.",
    source: "Vendor documentation",
    published: "March 2026",
    evidence: "Moderate",
    conf: 86,
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 2" },
      { t: "Source located", s: "ok", d: "Vendor documentation · Mar 2026" },
      { t: "Cross-checked with a second source", s: "ok", d: "Two vendors agree" },
      { t: "Verified", s: "ok", d: "Wording softened to “most”" },
    ],
  },
  {
    id: 3,
    status: "needs",
    text: "Customers prefer self-service for simple questions.",
    source: "None found",
    published: "—",
    evidence: "Weak",
    conf: 41,
    note: "No qualifying source was found. This claim will not ship as written without one.",
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 3" },
      { t: "Source located", s: "warn", d: "No qualifying source found" },
      { t: "Cross-checked with a second source", s: "pending", d: "Waiting on a source" },
      { t: "Verified", s: "block", d: "Blocked until sourced" },
    ],
  },
  {
    id: 4,
    status: "verified",
    text: "Setup typically takes days, not months, for help-desk integrations.",
    source: "Product documentation",
    published: "February 2026",
    evidence: "Moderate",
    conf: 90,
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 3" },
      { t: "Source located", s: "ok", d: "Documentation · Feb 2026" },
      { t: "Cross-checked with a second source", s: "ok", d: "Consistent" },
      { t: "Verified", s: "ok", d: "Wording matches the evidence" },
    ],
  },
  {
    id: 5,
    status: "conflict",
    text: "Chat-first support lowers cost per ticket.",
    source: "Industry survey vs. analyst note",
    published: "2025 – 2026",
    evidence: "Conflicting",
    conf: 52,
    note: "One source reports lower cost per ticket; another reports no change once escalations are counted. A person decides how to word it.",
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 4" },
      { t: "Source located", s: "ok", d: "Two sources found" },
      { t: "Cross-checked with a second source", s: "warn", d: "Sources disagree" },
      { t: "Verified", s: "block", d: "Needs editor decision" },
    ],
  },
  {
    id: 6,
    status: "verified",
    text: "Response time is the metric most buyers compare first.",
    source: "Buyer survey",
    published: "January 2026",
    evidence: "Strong",
    conf: 88,
    trail: [
      { t: "Claim extracted from draft", s: "ok", d: "Paragraph 5" },
      { t: "Source located", s: "ok", d: "Buyer survey · Jan 2026" },
      { t: "Cross-checked with a second source", s: "ok", d: "Consistent" },
      { t: "Verified", s: "ok", d: "Wording matches the evidence" },
    ],
  },
];

const ST = {
  verified: { label: "Verified", tone: "green" as const, Icon: Check, text: "text-grow", bg: "bg-grow-soft", ring: "border-grow/40" },
  needs: { label: "Needs source", tone: "amber" as const, Icon: Warn, text: "text-warn", bg: "bg-warn-soft", ring: "border-warn/40" },
  conflict: { label: "Conflicting evidence", tone: "red" as const, Icon: Question, text: "text-decline", bg: "bg-decline-soft", ring: "border-decline/40" },
};

const ACTIONS: Record<Status, string[]> = {
  verified: [],
  needs: ["Add source", "Soften claim", "Remove claim"],
  conflict: ["Show both sources", "Reword claim"],
};

const EVID = { Strong: 4, Moderate: 3, Weak: 1, Conflicting: 2 } as const;

export function ClaimVerification() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const shown = useSequence(inView, CLAIMS.length, 380, 500);
  const [sel, setSel] = useState(0);
  const [done, setDone] = useState<Record<number, string>>({});
  const c = CLAIMS[sel];
  const st = ST[c.status];

  return (
    <Section id="verification" chapter="08" chapterLabel="Verification" labelledBy="ver-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="ver-title"
            n="08"
            chapter="Verification"
            title="Every important claim has a trail."
            sub="Claims are extracted from the draft, matched to sources, and flagged when the evidence is missing, weak, or in conflict."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Claim verification</span>
                <span className="hidden text-ink-3 sm:inline">/</span>
                <span className="hidden truncate text-ink-2 sm:inline">AI customer support software</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid grid-cols-2 border-b border-line sm:grid-cols-4">
              {[
                ["Claims", 42, "text-ink"],
                ["Verified", 35, "text-grow"],
                ["Needs review", 5, "text-warn"],
                ["Conflicting", 2, "text-decline"],
              ].map(([k, v, cls], i) => (
                <div key={k as string} className={cn("px-4 py-4 sm:px-6", i > 0 && "sm:border-l sm:border-line", i === 1 && "border-l border-line", i === 2 && "border-t border-line sm:border-t-0", i === 3 && "border-l border-t border-line sm:border-t-0")}>
                  <div className="label">{k}</div>
                  <div className={cn("mt-1 text-[30px] leading-none", cls as string)}>
                    <Num to={v as number} active={inView} duration={1.4} />
                  </div>
                </div>
              ))}
            </div>
            <div className="flex h-[3px] w-full bg-line" aria-hidden="true">
              {[
                [35, "bg-grow"],
                [5, "bg-warn"],
                [2, "bg-decline"],
              ].map(([w, c2]) => (
                <div
                  key={c2 as string}
                  className={cn("h-full transition-all duration-[1400ms] ease-out", c2 as string)}
                  style={{ width: inView ? `${((w as number) / 42) * 100}%` : "0%" }}
                />
              ))}
            </div>

            <div className="grid lg:grid-cols-[1.25fr_1fr]">
              <div className="border-b border-line p-4 sm:p-6 lg:border-b-0 lg:border-r">
                <div className="flex items-center justify-between">
                  <span className="label">Draft · 6 of 42 claims shown</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">Click a claim</span>
                </div>
                <ul className="mt-3">
                  {CLAIMS.map((cl, i) => {
                    const s = ST[cl.status];
                    const on = shown > i;
                    return (
                      <li key={cl.id} className="border-t border-line first:border-t-0">
                        <button
                          type="button"
                          onClick={() => setSel(i)}
                          aria-pressed={sel === i}
                          className={cn(
                            "-mx-2 grid w-[calc(100%+1rem)] grid-cols-[28px_1fr] items-start gap-3 rounded-[3px] px-2 py-3.5 text-left transition-colors",
                            sel === i ? "bg-paper" : "hover:bg-paper/60",
                          )}
                        >
                          <span
                            className={cn(
                              "mt-0.5 grid h-6 w-6 place-items-center rounded-full border transition-all duration-500",
                              on ? cn(s.bg, s.ring, s.text) : "border-line bg-white text-transparent",
                            )}
                          >
                            <s.Icon size={13} />
                          </span>
                          <span>
                            <span className={cn("block text-[15px] leading-[1.5] text-ink", sel === i && "underline decoration-ink/30 underline-offset-4")}>
                              {cl.text}
                            </span>
                            <span
                              className={cn(
                                "mt-1 block font-mono text-[10px] uppercase tracking-[0.07em] transition-opacity duration-500",
                                on ? "opacity-100" : "opacity-0",
                                s.text,
                              )}
                            >
                              {s.label}
                            </span>
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>

              <div className="bg-[#FBFBF8] p-4 sm:p-6">
                <div key={c.id} className="fade-in">
                  <div className="flex items-center justify-between">
                    <span className="label text-ink">Claim</span>
                    <Tag tone={st.tone}>{st.label}</Tag>
                  </div>
                  <p className="mt-3 font-serif text-[26px] leading-[1.12] tracking-[-0.01em]">{c.text}</p>

                  <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-4 border-y border-line-strong py-4">
                    <div>
                      <dt className="label">Source</dt>
                      <dd className="mt-1 text-[14px] text-ink">{c.source}</dd>
                    </div>
                    <div>
                      <dt className="label">Published</dt>
                      <dd className="mt-1 font-mono text-[13px] text-ink">{c.published}</dd>
                    </div>
                    <div>
                      <dt className="label">Evidence</dt>
                      <dd className="mt-1.5 flex items-center gap-2 text-[14px] text-ink">
                        <span className="flex gap-[3px]" aria-hidden="true">
                          {Array.from({ length: 4 }).map((_, i) => (
                            <span key={i} className={cn("h-2.5 w-[5px] rounded-[1px]", i < EVID[c.evidence] ? "bg-ink" : "bg-line-strong")} />
                          ))}
                        </span>
                        {c.evidence}
                      </dd>
                    </div>
                    <div>
                      <dt className="label">Confidence</dt>
                      <dd className="num mt-1 text-[20px] leading-none text-ink">{c.conf}%</dd>
                    </div>
                  </dl>

                  {c.note && <p className="mt-4 text-[13px] leading-[1.55] text-ink-2">{c.note}</p>}

                  <div className="mt-5">
                    <div className="label">Trail</div>
                    <ol className="mt-3 space-y-0">
                      {c.trail.map((t, i) => (
                        <li key={t.t} className="relative flex gap-3 pb-3.5 last:pb-0">
                          {i < c.trail.length - 1 && <span className="absolute left-[8px] top-5 h-[calc(100%-12px)] w-px bg-line-strong" />}
                          <span
                            className={cn(
                              "relative z-10 mt-0.5 grid h-[17px] w-[17px] shrink-0 place-items-center rounded-full border bg-white",
                              t.s === "ok" && "border-grow bg-grow text-white",
                              t.s === "warn" && "border-warn text-warn",
                              t.s === "block" && "border-decline text-decline",
                              t.s === "pending" && "border-line-strong",
                            )}
                          >
                            {t.s === "ok" && <Check size={10} />}
                            {t.s === "warn" && <span className="text-[10px] font-semibold leading-none">!</span>}
                            {t.s === "block" && <span className="h-[2px] w-2 bg-decline" />}
                          </span>
                          <div className="min-w-0">
                            <div className="text-[13px] leading-snug text-ink">{t.t}</div>
                            <div className="mt-0.5 font-mono text-[11px] text-ink-2">{t.d}</div>
                          </div>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {ACTIONS[c.status].length > 0 && (
                    <div className="mt-5 border-t border-line pt-4">
                      <div className="flex flex-wrap gap-2">
                        {ACTIONS[c.status].map((a) => (
                          <button
                            key={a}
                            type="button"
                            onClick={() => setDone((d) => ({ ...d, [c.id]: a }))}
                            className="rounded-[4px] border border-line-strong bg-white px-3 py-2 text-[13px] font-medium text-ink transition-colors hover:border-ink"
                          >
                            {a}
                          </button>
                        ))}
                      </div>
                      {done[c.id] && (
                        <p className="fade-in mt-3 font-mono text-[11px] text-ink-2" aria-live="polite">
                          Queued for human review: {done[c.id]}.
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
