import { useEffect, useState } from "react";
import { useCalm } from "../lib/motion";
import { cn } from "../utils/cn";
import { Loop } from "./icons";
import { Container, Meter, Num, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView } from "../lib/hooks";

const FACTORS = [
  { k: "Search demand", w: 0.25 },
  { k: "Related questions", w: 0.15 },
  { k: "Competitor gaps", w: 0.2 },
  { k: "Business relevance", w: 0.2 },
  { k: "Existing content", w: 0.1 },
  { k: "Internal links", w: 0.1 },
];

const TOPICS = [
  {
    id: "support",
    title: "AI Customer Support Software",
    vals: [96, 92, 95, 98, 90, 88],
    evid: [
      "2.4k monthly searches, trending up",
      "38 related questions found",
      "6 of 8 top pages lack a pricing section",
      "Core to your product category",
      "No page on your site targets this topic",
      "14 relevant pages could link in",
    ],
  },
  {
    id: "migration",
    title: "Helpdesk Migration Checklist",
    vals: [78, 84, 72, 81, 70, 90],
    evid: [
      "900 monthly searches, steady",
      "21 related questions found",
      "Competitors cover it, but thinly",
      "Adjacent to your product",
      "One older page partly covers it",
      "Strong internal link fit",
    ],
  },
  {
    id: "glossary",
    title: "Customer Support Metrics Glossary",
    vals: [62, 70, 58, 64, 45, 82],
    evid: [
      "Many low-volume definitions",
      "Few questions beyond definitions",
      "Well covered by established sites",
      "Weak link to buying intent",
      "Overlaps three existing posts",
      "Good internal link fit",
    ],
  },
].map((t) => ({
  ...t,
  contrib: t.vals.map((v, i) => v * FACTORS[i].w),
  score: Math.round(t.vals.reduce((a, v, i) => a + v * FACTORS[i].w, 0)),
}));

export function OpportunityExplorer() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const reduce = useCalm();
  const [sel, setSel] = useState(0);
  const [run, setRun] = useState(0);
  const [n, setN] = useState(0);
  const topic = TOPICS[sel];

  useEffect(() => {
    if (!inView) return;
    if (reduce) {
      setN(FACTORS.length);
      return;
    }
    setN(0);
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setN(i);
      if (i >= FACTORS.length) window.clearInterval(id);
    }, 560);
    return () => window.clearInterval(id);
  }, [inView, sel, run, reduce]);

  const partial = Math.round(topic.contrib.slice(0, n).reduce((a, b) => a + b, 0));
  const done = n >= FACTORS.length;

  return (
    <Section id="opportunities" chapter="06b" chapterLabel="New content" labelledBy="opp-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="opp-title"
            n="06b"
            chapter="New content"
            title="Sometimes the answer isn’t an update."
            sub="Find the topics where creating something new is more valuable than repairing something old."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Opportunity explorer</span>
                <span className="hidden text-ink-3 sm:inline">/</span>
                <span className="hidden font-mono text-[11px] text-ink-2 sm:inline">31 opportunities</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid lg:grid-cols-[320px_1fr]">
              <div className="border-b border-line bg-[#FBFBF8] p-4 sm:p-5 lg:border-b-0 lg:border-r">
                <span className="label">Ranked topics</span>
                <ul className="mt-3 space-y-2">
                  {TOPICS.map((t, i) => (
                    <li key={t.id}>
                      <button
                        type="button"
                        onClick={() => {
                          setN(0);
                          setSel(i);
                        }}
                        aria-pressed={sel === i}
                        className={cn(
                          "w-full rounded-[4px] border p-3.5 text-left transition-colors",
                          sel === i ? "border-ink bg-white" : "border-line-strong bg-white/60 hover:border-ink-3",
                        )}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <span className="text-[14px] font-medium leading-snug text-ink">{t.title}</span>
                          <span className="num text-[15px] text-ink">{t.score}</span>
                        </div>
                        <Meter value={t.score} tone={sel === i ? "blue" : "muted"} active={inView} delay={200 + i * 150} className="mt-3" height="h-[3px]" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-4 sm:p-6 lg:p-8">
                <div className="flex flex-wrap items-start justify-between gap-6">
                  <div className="min-w-0">
                    <Tag tone="blue">Opportunity</Tag>
                    <h3 key={topic.id} className="fade-in mt-3 font-serif text-[32px] leading-[1.05] tracking-[-0.01em] sm:text-[40px]">
                      {topic.title}
                    </h3>
                  </div>
                  <div className="text-right">
                    <div className="label">Opportunity score</div>
                    <div className="mt-1 flex items-baseline justify-end gap-1.5 leading-none">
                      <span className="text-[56px] text-ink sm:text-[72px]">
                        <Num key={`${sel}-${run}`} to={partial} active={inView} duration={0.55} />
                      </span>
                      <span className="num text-[18px] text-ink-3">/ 100</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5">
                  <Meter value={partial} tone="blue" height="h-[6px]" className="transition-all" />
                  <div className="mt-2 flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
                    <span aria-live="polite">{done ? "Calculated from 6 signals" : `Calculating… ${n}/${FACTORS.length} signals`}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setN(0);
                        setRun((r) => r + 1);
                      }}
                      className="flex items-center gap-1.5 text-ink-2 transition-colors hover:text-ink"
                    >
                      <Loop size={12} /> Recalculate
                    </button>
                  </div>
                </div>

                <ul className="mt-6 border-t border-line-strong">
                  {FACTORS.map((f, i) => {
                    const on = n > i;
                    return (
                      <li
                        key={f.k}
                        className={cn(
                          "grid grid-cols-[1fr_auto] items-center gap-x-4 gap-y-2 border-b border-line py-3.5 transition-opacity duration-500 sm:grid-cols-[170px_1fr_44px_56px]",
                          on ? "opacity-100" : "opacity-30",
                        )}
                      >
                        <span className="text-[14px] font-medium text-ink">{f.k}</span>
                        <span className="order-last col-span-2 text-[13px] text-ink-2 sm:order-none sm:col-span-1">{topic.evid[i]}</span>
                        <span className="num text-right text-[13px] text-ink">{on ? topic.vals[i] : "—"}</span>
                        <span className="num hidden text-right text-[12px] text-ink-3 sm:block">
                          {on ? `+${topic.contrib[i].toFixed(1)}` : ""}
                        </span>
                      </li>
                    );
                  })}
                </ul>
                <p className="mt-4 text-[12px] leading-snug text-ink-3">
                  Weights are shown so the score is inspectable: demand 25%, competitor gaps 20%, business relevance 20%,
                  related questions 15%, existing content 10%, internal links 10%.
                </p>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
