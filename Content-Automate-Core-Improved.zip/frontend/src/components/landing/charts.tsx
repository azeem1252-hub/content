import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import { useCalm } from "../lib/motion";

/** Stretchy SVG chart surface. Labels live in HTML overlays so text never distorts. */
export function ChartSvg({
  w,
  h,
  children,
  className,
  grid = 3,
  gridColor = "#E9EAE4",
}: {
  w: number;
  h: number;
  children?: ReactNode;
  className?: string;
  grid?: number;
  gridColor?: string;
}) {
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      className={cn("absolute inset-0 h-full w-full overflow-visible", className)}
      aria-hidden="true"
      focusable="false"
    >
      {Array.from({ length: grid }).map((_, i) => {
        const y = (h * (i + 1)) / (grid + 1);
        return <line key={i} x1={0} x2={w} y1={y} y2={y} stroke={gridColor} strokeWidth={1} />;
      })}
      {children}
    </svg>
  );
}

/** A line that draws itself. Retracts instantly when deactivated so loops reset cleanly. */
export function DrawPath({
  d,
  stroke,
  width = 1.75,
  active = true,
  delay = 0,
  duration = 1.4,
  opacity = 1,
}: {
  d: string;
  stroke: string;
  width?: number;
  active?: boolean;
  delay?: number;
  duration?: number;
  opacity?: number;
}) {
  const reduce = useCalm();
  return (
    <motion.path
      d={d}
      fill="none"
      stroke={stroke}
      strokeWidth={width}
      strokeLinecap="round"
      strokeLinejoin="round"
      initial={{ pathLength: reduce ? 1 : 0, opacity: 0 }}
      animate={{ pathLength: reduce ? 1 : active ? 1 : 0, opacity: active ? opacity : 0 }}
      transition={
        active
          ? { duration: reduce ? 0.4 : duration, delay: reduce ? 0 : delay, ease: [0.4, 0, 0.2, 1] }
          : { duration: 0 }
      }
    />
  );
}

/** Dashed or static path that fades in/out. */
export function FadePath({
  d,
  stroke,
  fill = "none",
  width = 1,
  dash,
  active = true,
  delay = 0,
  opacity = 1,
  duration = 0.8,
}: {
  d: string;
  stroke?: string;
  fill?: string;
  width?: number;
  dash?: string;
  active?: boolean;
  delay?: number;
  opacity?: number;
  duration?: number;
}) {
  return (
    <path
      d={d}
      fill={fill}
      stroke={stroke ?? "none"}
      strokeWidth={width}
      strokeDasharray={dash}
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{
        opacity: active ? opacity : 0,
        transition: active ? `opacity ${duration}s ease ${delay}s` : "none",
      }}
    />
  );
}

/** Positions an HTML overlay at SVG-space coordinates. */
export function At({
  x,
  y,
  w,
  h,
  className,
  children,
  style,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  className?: string;
  children?: ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={cn("absolute", className)}
      style={{ left: `${(x / w) * 100}%`, top: `${(y / h) * 100}%`, ...style }}
    >
      {children}
    </div>
  );
}
