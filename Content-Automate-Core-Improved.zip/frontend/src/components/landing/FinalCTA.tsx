import { Button, Container, Reveal, Section } from "./ui";
import { useNav } from "../../lib/nav";

export function FinalCTA() {
  const { setPage } = useNav();

  return (
    <Section id="cta" tone="white" labelledBy="cta-title" className="border-t-2 border-t-ink lg:py-40">
      <Container>
        <Reveal>
          <h2
            id="cta-title"
            className="max-w-[1000px] font-serif text-[clamp(3.25rem,9vw,8rem)] font-normal leading-[0.95] tracking-[-0.03em] text-balance"
          >
            Know what to fix <em>next.</em>
          </h2>
          <p className="mt-8 max-w-[600px] text-[clamp(1.05rem,1.6vw,1.25rem)] leading-[1.55] text-ink-2 text-pretty">
            Turn your content library into a measurable operating system for search, answers, and AI visibility.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Button onClick={() => setPage("overview")} arrow size="lg" className="cursor-pointer">
              Analyze your content
            </Button>
            <Button href="#top" variant="secondary" size="lg">
              See the product
            </Button>
          </div>
        </Reveal>

        <Reveal className="mt-16 grid gap-px overflow-hidden rounded-[6px] border border-line-strong bg-line-strong md:grid-cols-3">
          {[
            ["01", "Connect", "Read-only access to Search Console and Analytics."],
            ["02", "Review", "See what’s declining, why, and how sure we are."],
            ["03", "Decide", "Choose what gets worked on. Approve everything that ships."],
          ].map(([n, t, d]) => (
            <div key={n} className="bg-paper p-5 sm:p-6">
              <span className="num text-[11px] text-brand">{n}</span>
              <div className="mt-2 font-serif text-[26px] leading-none">{t}</div>
              <p className="mt-2 text-[14px] leading-snug text-ink-2">{d}</p>
            </div>
          ))}
        </Reveal>
      </Container>
    </Section>
  );
}
