import { useState } from "react";
import { cn } from "../utils/cn";
import { At, ChartSvg, DrawPath, FadePath } from "./charts";
import { Container, Meter, Num, Reveal, Section, SectionHeading, Tag } from "./ui";
import { areaBetween, experimentSeries, linePath, mapPts } from "../lib/chart";
import { useOnceInView } from "../lib/hooks";

const W = 900;
const H = 380;
const N = 70;
const PUBLISH_AT = 0.4;
const E = experimentSeries(N, PUBLISH_AT, 0.27, 8);
const P = { min: 72, max: 148, t: 24, b: 24 };
const ctrl = mapPts(E.control, W, H, P);
const upd = mapPts(E.updated, W, H, P);
const PUB_I = Math.round(PUBLISH_AT * (N - 1));
const pubX = ctrl[PUB_I][0];
const DIP_I = Math.round(0.7 * (N - 1));

export function MeasurementExperiment() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-25% 0px");
  const [withControl, setWithControl] = useState(true);
  const show = inView;

  return (
    <Section id="result" chapter="11" chapterLabel="The result" labelledBy="res2-title" className="border-t-2 border-t-ink lg:py-36">
      <Container>
        <Reveal>
          <SectionHeading
            id="res2-title"
            n="11"
            chapter="The result"
            title="Don’t stop at publishing. Prove it worked."
            sub="Compare updated pages with matched untouched pages to separate real impact from background noise."
            titleClassName="text-[clamp(2.75rem,6.2vw,5.5rem)]"
          />
        </Reveal>

        <div ref={ref} className="mt-12 grid gap-8 lg:mt-16 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-8">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink pb-3">
              <div className="flex items-center gap-3">
                <Tag tone="ink">Illustrative data</Tag>
                <span className="label hidden sm:inline">Organic clicks · indexed to 100</span>
              </div>
              <div className="flex rounded-[3px] border border-line-strong bg-white p-0.5 font-mono text-[10px] uppercase tracking-[0.06em]">
                {[
                  ["With control group", true],
                  ["Updated pages only", false],
                ].map(([l, v]) => (
                  <button
                    key={l as string}
                    type="button"
                    onClick={() => setWithControl(v as boolean)}
                    aria-pressed={withControl === v}
                    className={cn("rounded-[2px] px-2.5 py-1.5 transition-colors", withControl === v ? "bg-ink text-white" : "text-ink-2 hover:text-ink")}
                  >
                    {l as string}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative mt-8 h-[260px] sm:h-[340px] lg:h-[400px]">
              <ChartSvg w={W} h={H} grid={3}>
                <FadePath d={areaBetween(upd.slice(PUB_I), ctrl.slice(PUB_I))} fill="#EEF2FF" active={show && withControl} delay={withControl ? 3 : 0} />
                <FadePath d={`M${pubX} 0 L${pubX} ${H}`} stroke="#92958E" dash="3 5" active={show} delay={0.4} />
                <DrawPath d={linePath(ctrl)} stroke="#92958E" width={2} active={show && withControl} delay={0.3} duration={2.6} />
                <DrawPath d={linePath(upd)} stroke="#3157D5" width={2.5} active={show} delay={0.6} duration={2.6} />
              </ChartSvg>

              <At x={pubX} y={0} w={W} h={H} className="-translate-y-full pb-2">
                <span className="block -translate-x-1/2 whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.08em] text-ink">Published</span>
              </At>

              <At x={ctrl[DIP_I][0]} y={ctrl[DIP_I][1]} w={W} h={H} className="translate-y-3">
                <span
                  className="block -translate-x-1/2 whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.05em] text-ink-2 transition-opacity duration-700"
                  style={{ opacity: show && withControl ? 1 : 0, transitionDelay: show && withControl ? "3s" : "0s" }}
                >
                  Both groups dip: market noise
                </span>
              </At>

              <At x={W} y={upd[N - 1][1]} w={W} h={H} className="-translate-x-full -translate-y-[160%]">
                <span className="whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.06em] text-brand">Updated pages</span>
              </At>
              <At x={W} y={ctrl[N - 1][1]} w={W} h={H} className="-translate-x-full translate-y-3">
                <span
                  className="whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2 transition-opacity duration-500"
                  style={{ opacity: withControl ? 1 : 0 }}
                >
                  Control group
                </span>
              </At>

              <div className="absolute bottom-0 left-0 flex w-full -translate-y-1 justify-between px-1 font-mono text-[9px] uppercase tracking-[0.06em] text-ink-3">
                <span>Before</span>
                <span>After publishing</span>
              </div>
            </div>

            <p key={String(withControl)} className="fade-in mt-6 max-w-[640px] text-[15px] leading-[1.6] text-ink-2">
              {withControl
                ? "Both groups dipped in the same weeks. The control group absorbed the market noise, so what’s left is the effect of the update."
                : "Looking at updated pages alone, the mid-period dip reads like a failure, and the later rise can’t be separated from the market. That’s why we compare against untouched pages."}
            </p>
          </div>

          <aside className="lg:col-span-4">
            <div className="lg:sticky lg:top-24">
              <div className="border-t border-ink pt-4">
                <div className="label">Relative uplift</div>
                <div className="mt-2 text-[clamp(5rem,9vw,7.5rem)] leading-[0.9] tracking-[-0.04em] text-grow">
                  <Num to={27} prefix="+" suffix="%" active={show && withControl} duration={2.4} className="!font-serif tracking-[-0.03em]" />
                </div>
                {!withControl && <p className="fade-in mt-3 font-mono text-[11px] uppercase tracking-[0.06em] text-ink-3">Not measurable without a control</p>}
              </div>

              <div className="mt-8 border-t border-line-strong pt-4">
                <div className="flex items-end justify-between">
                  <div>
                    <div className="label">Confidence</div>
                    <div className="mt-1 text-[44px] leading-none text-ink">
                      <Num to={88} suffix="%" active={show && withControl} duration={2.2} />
                    </div>
                  </div>
                  <Tag tone="green">Strong</Tag>
                </div>
                <Meter value={88} tone="green" active={show && withControl} delay={400} className="mt-4" height="h-[3px]" />
              </div>

              <dl className="mt-8 space-y-2.5 border-t border-line-strong pt-4 text-[13px]">
                {[
                  ["Updated pages", "14"],
                  ["Matched untouched pages", "14"],
                  ["Matched on", "Traffic, age, topic"],
                  ["Window", "28 days after publish"],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4">
                    <dt className="text-ink-2">{k}</dt>
                    <dd className="text-right font-mono text-[12px] text-ink">{v}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-5 text-[12px] leading-snug text-ink-3">
                Illustrative data to show the method. Real results will always include the comparison and the confidence behind them.
              </p>
            </div>
          </aside>
        </div>
      </Container>
    </Section>
  );
}
