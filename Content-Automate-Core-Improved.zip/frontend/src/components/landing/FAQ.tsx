import { useState } from "react";
import { cn } from "../utils/cn";
import { Minus, Plus } from "./icons";
import { Chapter, Container, Reveal, Section } from "./ui";

const QA = [
  ["Does the AI publish automatically?", "No. Human approval is required before anything is published."],
  [
    "Can it distinguish seasonality from genuine decay?",
    "It evaluates historical patterns and provides a confidence level rather than treating every decline as a content problem.",
  ],
  ["Can I review every AI change?", "Yes. Every change arrives as a tracked suggestion that you can accept, reject, or send back."],
  [
    "Are claims sourced?",
    "Important claims can be tied to supporting evidence and flagged when evidence is weak or conflicting.",
  ],
  [
    "Does it replace an SEO team?",
    "No. It automates analysis and production work while leaving strategic decisions with humans.",
  ],
  ["Does it guarantee Google rankings?", "No. Nobody can. It helps you find what to fix and shows whether the fix worked."],
  ["Does it guarantee AI citations?", "No. It improves structure, evidence, and clarity so systems can better understand your content."],
  ["Can it publish directly to our CMS?", "Where supported, yes, after approval. The previous version is saved first."],
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section id="faq" chapter="17" chapterLabel="Questions" labelledBy="faq-title">
      <Container>
        <div className="grid gap-10 lg:grid-cols-12 lg:gap-16">
          <Reveal className="lg:col-span-4">
            <Chapter n="17" label="Questions" />
            <h2
              id="faq-title"
              className="mt-5 font-serif text-[clamp(2.5rem,5vw,4.25rem)] font-normal leading-[1.02] tracking-[-0.02em] text-balance"
            >
              Honest answers.
            </h2>
            <p className="mt-5 max-w-[320px] text-[16px] leading-[1.6] text-ink-2">
              The questions skeptical teams ask first. Including the ones where the answer is no.
            </p>
          </Reveal>

          <Reveal className="lg:col-span-8">
            <ul className="border-t border-ink">
              {QA.map(([q, a], i) => {
                const isOpen = open === i;
                return (
                  <li key={q} className="border-b border-line-strong">
                    <h3>
                      <button
                        type="button"
                        id={`faq-q-${i}`}
                        aria-expanded={isOpen}
                        aria-controls={`faq-a-${i}`}
                        onClick={() => setOpen(isOpen ? null : i)}
                        className="flex w-full items-center justify-between gap-6 py-5 text-left"
                      >
                        <span className="text-[17px] font-medium leading-snug text-ink sm:text-[18px]">{q}</span>
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-[4px] border border-line-strong text-ink-2">
                          {isOpen ? <Minus size={14} /> : <Plus size={14} />}
                        </span>
                      </button>
                    </h3>
                    <div
                      id={`faq-a-${i}`}
                      role="region"
                      aria-labelledby={`faq-q-${i}`}
                      className={cn("grid transition-[grid-template-rows] duration-300 ease-out", isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}
                    >
                      <div className="overflow-hidden">
                        <p className="max-w-[620px] pb-6 text-[16px] leading-[1.65] text-ink-2">{a}</p>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}
