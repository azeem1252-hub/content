import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { Button } from "./ui";
import { Close, Menu } from "./icons";
import { Logo } from "../Logo";
import { useNav } from "../../lib/nav";

const LINKS = [
  { label: "Product", href: "#signal" },
  { label: "Intelligence", href: "#investigation" },
  { label: "Workflow", href: "#loop" },
  { label: "Evidence", href: "#evidence" },
  { label: "Pricing", href: "#pricing" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { setPage } = useNav();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b border-line transition-[background-color,backdrop-filter] duration-300",
        scrolled ? "bg-white/90 backdrop-blur-md" : "bg-white",
      )}
    >
      <div
        className={cn(
          "mx-auto flex w-full max-w-[1280px] items-center justify-between px-5 transition-[height] duration-300 sm:px-8 lg:px-10",
          scrolled ? "h-14" : "h-16",
        )}
      >
        <div className="flex items-center gap-8 lg:gap-10">
          <a href="#top" className="flex items-center gap-2.5" aria-label="Verlytic — home">
            <Logo size={32} tone="light" title="Verlytic" subtitle="Content Operations" />
          </a>
          <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="rounded-[4px] px-3 py-2 text-sm text-ink-2 transition-colors hover:bg-paper hover:text-ink font-medium"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setPage("login")}
            className="hidden rounded-[4px] px-3 py-2 text-sm font-medium text-ink-2 transition-colors hover:text-ink sm:block cursor-pointer"
          >
            Sign in
          </button>
          <Button
            onClick={() => setPage("overview")}
            arrow
            className="hidden sm:inline-flex cursor-pointer"
          >
            Enter Studio
          </Button>
          <button
            type="button"
            className="grid h-10 w-10 place-items-center rounded-[4px] border border-line-strong md:hidden cursor-pointer"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <Close size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-line bg-white md:hidden">
          <ul className="mx-auto max-w-[1280px] px-5 py-2">
            {LINKS.map((l) => (
              <li key={l.href} className="border-b border-line last:border-0">
                <a href={l.href} onClick={() => setOpen(false)} className="flex items-center justify-between py-3.5 text-[15px]">
                  {l.label}
                </a>
              </li>
            ))}
            <li className="flex items-center gap-3 py-4">
              <Button
                onClick={() => {
                  setOpen(false);
                  setPage("overview");
                }}
                arrow
                className="flex-1 cursor-pointer"
              >
                Enter Studio
              </Button>
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  setPage("login");
                }}
                className="px-3 text-sm text-ink-2 font-medium cursor-pointer"
              >
                Sign in
              </button>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
