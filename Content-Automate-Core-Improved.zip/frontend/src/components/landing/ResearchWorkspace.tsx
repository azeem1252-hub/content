import { cn } from "../utils/cn";
import { Check } from "./icons";
import { Container, Num, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView, useSequence } from "../lib/hooks";

const QUESTIONS = [
  "What is it?",
  "Who needs it?",
  "How does it work?",
  "What does it cost?",
  "Which vendors exist?",
  "What should buyers consider?",
];

const SOURCES: { name: string; type: string; q: "High" | "Medium" | "Excluded"; claims: number }[] = [
  { name: "Industry benchmark report", type: "Report", q: "High", claims: 2 },
  { name: "Vendor documentation: integrations", type: "Docs", q: "High", claims: 1 },
  { name: "Study on support automation", type: "Paper", q: "High", claims: 2 },
  { name: "Buyer survey, 2026", type: "Survey", q: "High", claims: 1 },
  { name: "Analyst note on pricing models", type: "Analyst", q: "High", claims: 0 },
  { name: "Competitor pricing page", type: "Web", q: "Medium", claims: 1 },
  { name: "Anonymous forum thread", type: "Forum", q: "Excluded", claims: 0 },
  { name: "Undated listicle", type: "Web", q: "Excluded", claims: 1 },
];

const qTone = { High: "green", Medium: "amber", Excluded: "neutral" } as const;

export function ResearchWorkspace() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const qs = useSequence(inView, QUESTIONS.length, 480, 500);
  const src = useSequence(inView, SOURCES.length, 420, 700);
  const ready = qs >= QUESTIONS.length && src >= SOURCES.length;

  return (
    <Section id="research" chapter="07" chapterLabel="Research" labelledBy="res-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="res-title"
            n="07"
            chapter="Research"
            title="Research before generation."
            sub="Before a single sentence is drafted, the system maps the intent, the questions buyers ask, and the sources that can support the answers."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Research workspace</span>
                <span className="hidden text-ink-3 sm:inline">/</span>
                <span className="hidden font-mono text-[11px] text-ink-2 sm:inline">Brief draft</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid lg:grid-cols-[1fr_1.15fr]">
              <div className="border-b border-line lg:border-b-0 lg:border-r">
                <div className="grid border-b border-line sm:grid-cols-2">
                  <div className="border-b border-line p-5 sm:border-b-0 sm:border-r sm:p-6">
                    <div className="label">Topic</div>
                    <div className="mt-2 font-serif text-[28px] leading-[1.05] tracking-[-0.01em]">AI customer support software</div>
                  </div>
                  <div className="p-5 sm:p-6">
                    <div className="label">Search intent</div>
                    <div className="mt-2.5">
                      <Tag tone="blue">Commercial investigation</Tag>
                    </div>
                    <p className="mt-2 text-[12.5px] leading-snug text-ink-2">Buyers comparing options before they choose.</p>
                  </div>
                </div>
                <div className="p-5 sm:p-6">
                  <div className="flex items-center justify-between">
                    <span className="label">Questions</span>
                    <span className="num text-[11px] text-ink-2">
                      {Math.min(qs, QUESTIONS.length)} / {QUESTIONS.length} covered
                    </span>
                  </div>
                  <ul className="mt-3">
                    {QUESTIONS.map((q, i) => {
                      const on = qs > i;
                      return (
                        <li key={q} className="flex items-center gap-3 border-t border-line py-3">
                          <span
                            className={cn(
                              "grid h-[18px] w-[18px] shrink-0 place-items-center rounded-[3px] border transition-all duration-300",
                              on ? "border-grow bg-grow text-white" : "border-line-strong bg-white",
                            )}
                          >
                            {on && <Check size={11} />}
                          </span>
                          <span className={cn("text-[15px] transition-colors duration-300", on ? "text-ink" : "text-ink-3")}>{q}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              <div className="p-5 sm:p-6">
                <div className="flex items-center justify-between">
                  <span className="label">Sources</span>
                  <Tag tone={ready ? "green" : "neutral"}>{ready ? "Brief ready" : "Collecting"}</Tag>
                </div>
                <div className="mt-4 grid grid-cols-3 border-y border-line-strong">
                  {[
                    [23, "found"],
                    [17, "high-quality"],
                    [8, "claims need verification"],
                  ].map(([v, t], i) => (
                    <div key={t as string} className={cn("py-3.5", i > 0 && "border-l border-line pl-3 sm:pl-4")}>
                      <div className="text-[30px] leading-none text-ink">
                        <Num to={v as number} active={inView} duration={3} />
                      </div>
                      <div className="mt-1.5 text-[11px] leading-tight text-ink-2">{t}</div>
                    </div>
                  ))}
                </div>
                <ul className="mt-2">
                  {SOURCES.map((s, i) => {
                    const on = src > i;
                    return (
                      <li
                        key={s.name}
                        className={cn(
                          "grid grid-cols-[1fr_auto] items-center gap-x-3 border-b border-line py-2.5 transition-all duration-500",
                          on ? "translate-y-0 opacity-100" : "translate-y-1 opacity-0",
                        )}
                      >
                        <div className="min-w-0">
                          <div className={cn("truncate text-[13.5px]", s.q === "Excluded" ? "text-ink-3 line-through decoration-ink-3/50" : "text-ink")}>
                            {s.name}
                          </div>
                          <div className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">
                            {s.type}
                            {s.claims > 0 && ` · ${s.claims} claim${s.claims > 1 ? "s" : ""} to verify`}
                          </div>
                        </div>
                        <Tag tone={qTone[s.q]}>{s.q}</Tag>
                      </li>
                    );
                  })}
                </ul>
                <p className="mt-3 text-[12px] text-ink-3">Showing 8 of 23 sources. Low-quality sources are excluded, not silently used.</p>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
