import { useState } from "react";
import { cn } from "../utils/cn";
import { Chevron } from "./icons";
import { Container, Meter, Reveal, Section, SectionHeading, Tag } from "./ui";

const SOURCES = [
  {
    id: "gsc",
    name: "Google Search Console",
    date: "Pulled 2h ago · 90-day window",
    evidence:
      "Impressions held steady while clicks fell 34%. Queries containing “pricing” and “vs” grew 28% and the page does not answer them.",
    conf: 94,
    rel: "Shows demand moved toward comparison queries this page no longer satisfies.",
  },
  {
    id: "serp",
    name: "SERP analysis",
    date: "Snapshot · 3 days ago",
    evidence:
      "Eight of the top ten results are now comparison-style pages with plan tables. This article is structured as a buyer’s guide.",
    conf: 91,
    rel: "Confirms search intent shifted toward commercial comparison.",
  },
  {
    id: "comp",
    name: "Competitor pages",
    date: "Crawled · 5 days ago",
    evidence: "Three competing pages added pricing data in the last six months. None of them hide it behind a form.",
    conf: 88,
    rel: "Explains why competitors now win pricing-modified queries.",
  },
  {
    id: "trends",
    name: "Search trends",
    date: "Updated weekly",
    evidence:
      "Related queries rose 28% over the prior 90 days. The same weeks last year were flat, so seasonality is an unlikely explanation.",
    conf: 82,
    rel: "Quantifies the demand shift and rules out the seasonal explanation.",
  },
  {
    id: "hist",
    name: "Content history",
    date: "CMS revision log",
    evidence: "The last substantive edit was 11 months ago. The pricing section was last verified 14 months ago.",
    conf: 97,
    rel: "Shows the page has not kept pace with the market it describes.",
  },
];

const WHY = [
  { text: "3 competitors added pricing data.", src: ["comp"] },
  { text: "Search intent shifted toward commercial comparison.", src: ["serp"] },
  { text: "Your article hasn’t been updated in 11 months.", src: ["hist"] },
  { text: "Related queries increased 28%.", src: ["trends", "gsc"] },
];

export function EvidenceDesk() {
  const [open, setOpen] = useState<string | null>("serp");
  const [why, setWhy] = useState<number | null>(1);

  return (
    <Section id="evidence" chapter="05" chapterLabel="The receipts" labelledBy="ev-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="ev-title"
            n="05"
            chapter="The receipts"
            title="No black boxes."
            sub="Every important recommendation should be explainable."
          />
        </Reveal>

        <div className="mt-12 grid gap-8 lg:mt-16 lg:grid-cols-12 lg:gap-12">
          {/* recommendation */}
          <Reveal className="lg:col-span-5">
            <div className="rounded-[6px] border border-line-strong bg-paper">
              <div className="flex items-center justify-between border-b border-line px-5 py-3">
                <span className="label text-ink">Recommendation</span>
                <Tag tone="red">Do now</Tag>
              </div>
              <div className="p-5 sm:p-6">
                <h3 className="font-serif text-[34px] leading-[1.05] tracking-[-0.01em] sm:text-[40px]">
                  Update pricing comparison section.
                </h3>
                <p className="mt-3 font-mono text-[11px] text-ink-2">/best-crm-software · Confidence 91%</p>

                <div className="mt-7 flex items-center justify-between">
                  <span className="label text-ink">Why?</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">Select a reason</span>
                </div>
                <ol className="mt-2 border-t border-line-strong">
                  {WHY.map((w, i) => (
                    <li key={w.text} className="border-b border-line">
                      <button
                        type="button"
                        onClick={() => {
                          setWhy(i);
                          setOpen(w.src[0]);
                        }}
                        aria-pressed={why === i}
                        className={cn(
                          "group flex w-full items-start gap-3 py-3.5 text-left transition-colors",
                          why === i ? "text-ink" : "text-ink-2 hover:text-ink",
                        )}
                      >
                        <span
                          className={cn(
                            "num mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border text-[10px] transition-colors",
                            why === i ? "border-ink bg-ink text-white" : "border-line-strong",
                          )}
                        >
                          {i + 1}
                        </span>
                        <span className="text-[15px] leading-snug">{w.text}</span>
                      </button>
                    </li>
                  ))}
                </ol>
                <p className="mt-4 text-[12px] leading-snug text-ink-3">
                  Each reason links to the evidence behind it. Nothing here is a hunch.
                </p>
              </div>
            </div>
          </Reveal>

          {/* evidence */}
          <Reveal delay={0.1} className="lg:col-span-7">
            <div className="flex items-center justify-between">
              <span className="label text-ink">Evidence</span>
              <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">{SOURCES.length} sources · sample data</span>
            </div>
            <ul className="mt-3 border-t border-ink">
              {SOURCES.map((s) => {
                const isOpen = open === s.id;
                const linked = why !== null && WHY[why].src.includes(s.id);
                const n = why !== null ? why + 1 : 0;
                return (
                  <li key={s.id} className="relative border-b border-line-strong">
                    <span
                      className={cn(
                        "absolute left-0 top-0 h-full w-[2px] bg-brand transition-opacity duration-300",
                        linked ? "opacity-100" : "opacity-0",
                      )}
                    />
                    <h4>
                      <button
                        type="button"
                        id={`src-${s.id}`}
                        aria-expanded={isOpen}
                        aria-controls={`src-panel-${s.id}`}
                        onClick={() => setOpen(isOpen ? null : s.id)}
                        className="flex w-full items-center gap-3 py-4 pl-3 pr-1 text-left"
                      >
                        <span className="text-[16px] font-medium text-ink">{s.name}</span>
                        {linked && <Tag tone="blue">Supports #{n}</Tag>}
                        <span className="num ml-auto text-[12px] text-ink-2">{s.conf}%</span>
                        <Chevron className={cn("shrink-0 text-ink-2 transition-transform duration-300", isOpen && "rotate-180")} />
                      </button>
                    </h4>
                    <div
                      id={`src-panel-${s.id}`}
                      role="region"
                      aria-labelledby={`src-${s.id}`}
                      className={cn(
                        "grid transition-[grid-template-rows] duration-300 ease-out",
                        isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                      )}
                    >
                      <div className="overflow-hidden">
                        <dl className="grid gap-x-6 gap-y-3 pb-5 pl-3 text-[14px] sm:grid-cols-[130px_1fr]">
                          <dt className="label pt-0.5">Source</dt>
                          <dd className="text-ink">{s.name}</dd>
                          <dt className="label pt-0.5">Date</dt>
                          <dd className="font-mono text-[12.5px] text-ink">{s.date}</dd>
                          <dt className="label pt-0.5">Evidence</dt>
                          <dd className="leading-[1.55] text-ink">{s.evidence}</dd>
                          <dt className="label pt-0.5">Confidence</dt>
                          <dd className="flex items-center gap-3">
                            <Meter value={s.conf} active={isOpen} tone="blue" className="max-w-[220px]" height="h-[3px]" />
                            <span className="num text-[12.5px] text-ink">{s.conf}%</span>
                          </dd>
                          <dt className="label pt-0.5">Relationship</dt>
                          <dd className="leading-[1.55] text-ink-2">{s.rel}</dd>
                        </dl>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}
