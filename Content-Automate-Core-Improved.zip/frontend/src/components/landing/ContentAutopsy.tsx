import { useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { Container, Meter, Num, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView, useSequence } from "../lib/hooks";

type Kind = "outdated" | "missing" | "strong" | "unsupported";

const KIND: Record<Kind, { label: string; dot: string; hl: string; tone: "amber" | "blue" | "green" | "red" }> = {
  outdated: { label: "Outdated", dot: "bg-warn", hl: "bg-warn-soft shadow-[inset_0_-2px_0_#A97828]", tone: "amber" },
  missing: { label: "Missing", dot: "bg-brand", hl: "border-brand bg-brand-soft text-brand", tone: "blue" },
  strong: { label: "Strong", dot: "bg-grow", hl: "bg-grow-soft shadow-[inset_0_-2px_0_#3E805C]", tone: "green" },
  unsupported: { label: "Unsupported", dot: "bg-decline", hl: "bg-decline-soft shadow-[inset_0_-2px_0_#C84A42]", tone: "red" },
};

const ANN: Record<string, { kind: Kind; order: number; title: string; note: string; meta: string }> = {
  a1: {
    kind: "strong",
    order: 0,
    title: "Clear definition",
    note: "Answers “what is a CRM?” in the first sentence. Matches the informational part of the query.",
    meta: "Intent match · strong",
  },
  a2: {
    kind: "outdated",
    order: 1,
    title: "Outdated pricing",
    note: "These prices were last verified 14 months ago. Three competitors now publish different plan structures.",
    meta: "Last verified 14 months ago",
  },
  m1: {
    kind: "missing",
    order: 2,
    title: "Missing: pricing comparison table",
    note: "Four of the top five results answer “which CRM costs less?” with a comparison table. This page has none.",
    meta: "Competitor advantage",
  },
  a3: {
    kind: "unsupported",
    order: 3,
    title: "No source for this statistic",
    note: "No supporting source was found for this figure. Treat it as unverified until it is sourced or removed.",
    meta: "0 sources found",
  },
  a4: {
    kind: "outdated",
    order: 4,
    title: "Stale market reference",
    note: "Refers to last year’s market. Two of the vendors named have since changed their positioning.",
    meta: "Dated reference",
  },
  a5: {
    kind: "strong",
    order: 5,
    title: "Strong selection framework",
    note: "Specific, scannable criteria that competing pages lack. Keep it and build on it.",
    meta: "Coverage · strong",
  },
  m2: {
    kind: "missing",
    order: 6,
    title: "Missing: AI features section",
    note: "Related queries about AI features grew 28% over the last 90 days. The page does not cover them.",
    meta: "Content gap",
  },
};
const TOTAL = Object.keys(ANN).length;

const SCORES = [
  { k: "Freshness", v: 42 },
  { k: "Intent match", v: 48 },
  { k: "Coverage", v: 61 },
  { k: "Evidence", v: 73 },
];
const scoreTone = (v: number) => (v < 50 ? "red" : v < 70 ? "amber" : "green");

export function ContentAutopsy() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const revealed = useSequence(inView, TOTAL, 520, 400);
  const [filter, setFilter] = useState<Kind | "all">("all");
  const [sel, setSel] = useState("a2");
  const scanning = inView && revealed < TOTAL;
  const selected = ANN[sel];

  const hl = (id: string, children: ReactNode) => {
    const a = ANN[id];
    const on = revealed > a.order && (filter === "all" || filter === a.kind);
    return (
      <button
        key={id}
        type="button"
        onClick={() => setSel(id)}
        aria-label={`${KIND[a.kind].label}: ${a.title}`}
        className={cn(
          "inline rounded-[2px] px-0.5 text-left transition-colors duration-500",
          on ? KIND[a.kind].hl : "bg-transparent",
          sel === id && on && "outline outline-2 outline-offset-1 outline-ink/70",
        )}
      >
        {children}
      </button>
    );
  };

  const gap = (id: string) => {
    const a = ANN[id];
    const on = revealed > a.order && (filter === "all" || filter === a.kind);
    return (
      <button
        key={id}
        type="button"
        onClick={() => setSel(id)}
        aria-label={`${KIND[a.kind].label}: ${a.title}`}
        className={cn(
          "my-4 flex w-full items-center gap-3 rounded-[4px] border border-dashed px-4 py-3 text-left font-mono text-[11px] uppercase tracking-[0.06em] transition-all duration-500",
          on ? "border-brand bg-brand-soft text-brand" : "border-transparent bg-transparent text-transparent",
          sel === id && on && "outline outline-2 outline-offset-1 outline-ink/70",
        )}
      >
        <span className="text-base leading-none">+</span>
        {a.title}
      </button>
    );
  };

  return (
    <Section id="autopsy" chapter="04" chapterLabel="The content" labelledBy="autopsy-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="autopsy-title"
            n="04"
            chapter="The content"
            title="Let’s open the page."
            sub="The platform reads the article the way an editor would: passage by passage, against what the search results want now."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Content autopsy</span>
                <span className="text-ink-3">/</span>
                <span className="truncate font-mono text-[11px] text-ink-2">/best-crm-software</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid lg:grid-cols-[1.45fr_1fr]">
              {/* article */}
              <div className="border-b border-line lg:border-b-0 lg:border-r">
                <div className="flex flex-wrap items-center gap-1.5 border-b border-line px-4 py-3 sm:px-6">
                  <button
                    type="button"
                    onClick={() => setFilter("all")}
                    aria-pressed={filter === "all"}
                    className={cn(
                      "rounded-[3px] border px-2 py-1 font-mono text-[10px] uppercase tracking-[0.07em] transition-colors",
                      filter === "all" ? "border-ink bg-ink text-white" : "border-line-strong text-ink-2 hover:border-ink",
                    )}
                  >
                    All
                  </button>
                  {(Object.keys(KIND) as Kind[]).map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => setFilter(filter === k ? "all" : k)}
                      aria-pressed={filter === k}
                      className={cn(
                        "flex items-center gap-1.5 rounded-[3px] border px-2 py-1 font-mono text-[10px] uppercase tracking-[0.07em] transition-colors",
                        filter === k ? "border-ink bg-ink text-white" : "border-line-strong text-ink-2 hover:border-ink",
                      )}
                    >
                      <span className={cn("h-1.5 w-1.5 rounded-full", KIND[k].dot)} />
                      {KIND[k].label}
                    </button>
                  ))}
                </div>

                <article className="relative px-4 py-6 sm:px-8 sm:py-8">
                  {/* scan line */}
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 h-px bg-brand"
                    style={{
                      top: scanning || revealed >= TOTAL ? "100%" : "0%",
                      opacity: scanning ? 1 : 0,
                      transition: `top ${(TOTAL * 0.52).toFixed(1)}s linear 0.4s, opacity .5s ease`,
                    }}
                  />
                  <p className="font-mono text-[10px] uppercase tracking-[0.08em] text-ink-3">Article · 1,840 words · Published 2024</p>
                  <h4 className="mt-2 font-serif text-[30px] leading-[1.08] tracking-[-0.01em] sm:text-[38px]">
                    Best CRM software for growing teams
                  </h4>
                  <div className="mt-5 max-w-[620px] text-[15px] leading-[1.75] text-ink">
                    <p>
                      {hl("a1", "A CRM keeps customer data, conversations, and deals in one place.")} Most growing teams
                      outgrow spreadsheets within a year.
                    </p>
                    <h5 className="mt-5 text-[15px] font-semibold">How much does a CRM cost?</h5>
                    <p className="mt-1">
                      {hl("a2", "Plans start at $25 per seat per month, with full suites from $99.")} Check each vendor for
                      current rates.
                    </p>
                    {gap("m1")}
                    <p>
                      {hl("a3", "CRM adoption increases revenue by 41% for small businesses.")}{" "}
                      {hl("a4", "Last year, three vendors dominated the market.")}
                    </p>
                    <h5 className="mt-5 text-[15px] font-semibold">How to choose</h5>
                    <p className="mt-1">
                      {hl("a5", "Start with your sales process, then match integrations, reporting, and seat count to your team size.")}
                    </p>
                    {gap("m2")}
                  </div>
                </article>
              </div>

              {/* autopsy panel */}
              <div className="flex flex-col bg-[#FBFBF8] p-4 sm:p-6">
                <div className="flex items-center justify-between">
                  <span className="label text-ink">Content autopsy</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">
                    {Math.min(revealed, TOTAL)}/{TOTAL} passages inspected
                  </span>
                </div>

                <ul className="mt-5 space-y-4">
                  {SCORES.map((s, i) => (
                    <li key={s.k}>
                      <div className="flex items-baseline justify-between">
                        <span className="text-[14px] text-ink">{s.k}</span>
                        <span className="text-[22px] leading-none text-ink">
                          <Num to={s.v} active={inView} duration={1.4} />
                        </span>
                      </div>
                      <Meter value={s.v} tone={scoreTone(s.v)} active={inView} delay={300 + i * 200} className="mt-2" height="h-[3px]" />
                    </li>
                  ))}
                </ul>

                <div className="mt-6 grid grid-cols-3 border-y border-line-strong">
                  {[
                    [3, "gaps detected"],
                    [5, "claims outdated"],
                    [4, "competitor advantages"],
                  ].map(([n, t], i) => (
                    <div key={t} className={cn("py-3.5", i > 0 && "border-l border-line pl-3")}>
                      <div className="text-[26px] leading-none text-ink">
                        <Num to={n as number} active={inView} duration={1.2} />
                      </div>
                      <div className="mt-1.5 text-[11px] leading-tight text-ink-2">{t}</div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex-1">
                  <div className="label mb-2">Selected passage</div>
                  <div key={sel} className="fade-in rounded-[4px] border border-line-strong bg-white p-4">
                    <div className="flex items-center justify-between gap-2">
                      <Tag tone={KIND[selected.kind].tone}>{KIND[selected.kind].label}</Tag>
                      <span className="font-mono text-[10px] text-ink-3">{selected.meta}</span>
                    </div>
                    <div className="mt-3 text-[15px] font-medium text-ink">{selected.title}</div>
                    <p className="mt-1.5 text-[13px] leading-[1.55] text-ink-2">{selected.note}</p>
                  </div>
                  <p className="mt-3 text-[12px] leading-snug text-ink-3">
                    Click any highlight in the article, or filter by type above.
                  </p>
                </div>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
