import { useEffect, useRef, type ReactNode } from "react";
import { motion } from "framer-motion";
import gsap from "gsap";
import { cn } from "../utils/cn";
import { IS_AUTOMATED, useCalm } from "../lib/motion";
import { Arrow } from "./icons";

/* ------------------------------------------------------------------ layout */

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-10", className)}>{children}</div>;
}

export function Section({
  id,
  tone = "paper",
  className,
  children,
  chapter,
  chapterLabel,
  labelledBy,
}: {
  id?: string;
  tone?: "paper" | "white";
  className?: string;
  children: ReactNode;
  chapter?: string;
  chapterLabel?: string;
  labelledBy?: string;
}) {
  return (
    <section
      id={id}
      data-chapter={chapter}
      data-chapter-label={chapterLabel}
      aria-labelledby={labelledBy}
      className={cn(
        "relative scroll-mt-16 border-t border-line py-20 sm:py-24 lg:py-32",
        tone === "white" ? "bg-white" : "bg-paper",
        className,
      )}
    >
      {children}
    </section>
  );
}

/* ------------------------------------------------------------------ editorial */

export function Chapter({ n, label, className }: { n: string; label: string; className?: string }) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <span className="h-px w-8 bg-ink" />
      <span className="font-mono text-[11px] uppercase tracking-[0.1em] text-ink-2">
        <span className="text-brand">{n}</span>
        <span className="mx-1.5 text-ink-3">/</span>
        {label}
      </span>
    </div>
  );
}

export function SectionHeading({
  id,
  n,
  chapter,
  title,
  sub,
  className,
  titleClassName,
}: {
  id?: string;
  n?: string;
  chapter?: string;
  title: ReactNode;
  sub?: ReactNode;
  className?: string;
  titleClassName?: string;
}) {
  return (
    <header className={cn("max-w-[920px]", className)}>
      {n && chapter && <Chapter n={n} label={chapter} />}
      <h2
        id={id}
        className={cn(
          "mt-5 font-serif text-[clamp(2.5rem,5.4vw,4.75rem)] font-normal leading-[1.02] tracking-[-0.02em] text-balance text-ink",
          titleClassName,
        )}
      >
        {title}
      </h2>
      {sub && <p className="mt-5 max-w-[640px] text-[17px] leading-[1.6] text-ink-2 text-pretty">{sub}</p>}
    </header>
  );
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("label inline-flex items-center gap-2 text-ink", className)}>
      <span className="h-1.5 w-1.5 bg-decline" />
      {children}
    </span>
  );
}

export function Label({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn("label", className)}>{children}</span>;
}

/* ------------------------------------------------------------------ motion */

export function Reveal({
  children,
  delay = 0,
  y = 14,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  const reduce = useCalm();
  return (
    <motion.div
      className={className}
      initial={{ opacity: IS_AUTOMATED ? 1 : 0, y: reduce ? 0 : y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-8% 0px" }}
      transition={{ duration: reduce ? 0.3 : 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/** Number that tweens from its last displayed value to `to` (GSAP). */
export function Num({
  to,
  active = true,
  duration = 1.3,
  decimals = 0,
  prefix = "",
  suffix = "",
  pad = 0,
  from = 0,
  className,
}: {
  to: number;
  active?: boolean;
  duration?: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  pad?: number;
  from?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const cur = useRef(from);
  const reduce = useCalm();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const fmt = (v: number) =>
      prefix + (decimals ? v.toFixed(decimals) : String(Math.round(v)).padStart(pad, "0")) + suffix;
    if (!active) {
      cur.current = from;
      el.textContent = fmt(from);
      return;
    }
    if (reduce) {
      cur.current = to;
      el.textContent = fmt(to);
      return;
    }
    const o = { v: cur.current };
    const tween = gsap.to(o, {
      v: to,
      duration,
      ease: "power2.out",
      onUpdate: () => {
        cur.current = o.v;
        el.textContent = fmt(o.v);
      },
    });
    return () => {
      tween.kill();
    };
  }, [to, active, duration, decimals, prefix, suffix, pad, from, reduce]);

  return <span ref={ref} className={cn("num", className)} />;
}

/* ------------------------------------------------------------------ product UI atoms */

export function Window({
  title,
  right,
  children,
  className,
  bodyClassName,
}: {
  title: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-[6px] border border-line-strong bg-white shadow-[0_1px_0_rgba(22,23,25,0.04),0_18px_40px_-26px_rgba(22,23,25,0.28)]",
        className,
      )}
    >
      <div className="flex h-10 items-center justify-between gap-3 border-b border-line bg-[#FBFBF8] px-3.5">
        <div className="flex min-w-0 items-center gap-2 text-xs">{title}</div>
        <div className="flex shrink-0 items-center gap-2">{right}</div>
      </div>
      <div className={bodyClassName}>{children}</div>
    </div>
  );
}

const tagTones = {
  neutral: "border-line-strong bg-white text-ink-2",
  ink: "border-ink bg-ink text-white",
  blue: "border-brand/25 bg-brand-soft text-brand",
  red: "border-decline/25 bg-decline-soft text-decline",
  green: "border-grow/25 bg-grow-soft text-grow",
  amber: "border-warn/30 bg-warn-soft text-warn",
} as const;

export type Tone = keyof typeof tagTones;

export function Tag({
  tone = "neutral",
  children,
  className,
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-[3px] border px-1.5 py-[3px] font-mono text-[10px] uppercase leading-none tracking-[0.07em]",
        tagTones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function SampleTag({ children = "Sample data" }: { children?: ReactNode }) {
  return <Tag>{children}</Tag>;
}

const meterTones = {
  ink: "bg-ink",
  blue: "bg-brand",
  green: "bg-grow",
  red: "bg-decline",
  amber: "bg-warn",
  muted: "bg-ink-3",
} as const;

export function Meter({
  value,
  active = true,
  tone = "ink",
  delay = 0,
  className,
  height = "h-1",
}: {
  value: number;
  active?: boolean;
  tone?: keyof typeof meterTones;
  delay?: number;
  className?: string;
  height?: string;
}) {
  return (
    <div className={cn("w-full overflow-hidden rounded-[1px] bg-line", height, className)}>
      <div
        className={cn("h-full rounded-[1px] transition-[width] duration-[1100ms] ease-out", meterTones[tone])}
        style={{ width: active ? `${value}%` : "0%", transitionDelay: active ? `${delay}ms` : "0ms" }}
      />
    </div>
  );
}

export function StatusDot({ tone = "green", pulse = false }: { tone?: "green" | "red" | "amber" | "blue"; pulse?: boolean }) {
  const c = { green: "bg-grow", red: "bg-decline", amber: "bg-warn", blue: "bg-brand" }[tone];
  return <span className={cn("inline-block h-1.5 w-1.5 rounded-full", c, pulse && "pulse-dot")} />;
}

/* ------------------------------------------------------------------ buttons */

interface BtnProps {
  href?: string;
  variant?: "primary" | "secondary" | "ghost";
  arrow?: boolean;
  className?: string;
  children: ReactNode;
  onClick?: () => void;
  size?: "md" | "lg";
  disabled?: boolean;
  ariaLabel?: string;
}

export function Button({ href, variant = "primary", arrow, className, children, size = "md", onClick, disabled, ariaLabel }: BtnProps) {
  const cls = cn(
    "group inline-flex select-none items-center justify-center gap-2 whitespace-nowrap rounded-[4px] font-medium transition-all duration-150 cursor-pointer active:scale-[0.985]",
    size === "lg" ? "h-12 px-6 text-[15px]" : "h-10 px-4 text-sm",
    variant === "primary" && "bg-ink text-white hover:bg-brand shadow-sm",
    variant === "secondary" && "border border-line-strong bg-white text-ink hover:border-ink hover:bg-paper",
    variant === "ghost" && "px-0 text-ink hover:text-brand",
    disabled && "opacity-50 pointer-events-none",
    className,
  );
  const inner = (
    <>
      {children}
      {arrow && <Arrow className="transition-transform duration-200 group-hover:translate-x-0.5" />}
    </>
  );
  if (href)
    return (
      <a href={href} className={cls} aria-label={ariaLabel} onClick={onClick}>
        {inner}
      </a>
    );
  return (
    <button type="button" className={cls} onClick={onClick} disabled={disabled} aria-label={ariaLabel}>
      {inner}
    </button>
  );
}
