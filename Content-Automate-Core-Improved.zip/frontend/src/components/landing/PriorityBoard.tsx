import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { cn } from "../utils/cn";
import { Arrow } from "./icons";
import { Container, Reveal, Section, SectionHeading, Tag, Window } from "./ui";

type Col = "now" | "watch" | "leave";

const COLS: { id: Col; label: string; hint: string; dot: string }[] = [
  { id: "now", label: "Do now", hint: "Best return for the effort", dot: "bg-decline" },
  { id: "watch", label: "Watch", hint: "Not enough signal yet", dot: "bg-warn" },
  { id: "leave", label: "Leave alone", hint: "Not worth another hour", dot: "bg-ink-3" },
];

interface Item {
  id: string;
  title: string;
  path: string;
  impact: number;
  conf: number;
  delta: string;
  reason: string;
  col: Col;
}

const INITIAL: Item[] = [
  {
    id: "crm",
    title: "Best CRM Software",
    path: "/best-crm-software",
    impact: 4,
    conf: 91,
    delta: "−34%",
    reason: "Intent shift is fixable with one pricing section. Largest recoverable traffic in the library.",
    col: "now",
  },
  {
    id: "ai",
    title: "AI Support Software",
    path: "/ai-support-software",
    impact: 4,
    conf: 84,
    delta: "−21%",
    reason: "Competitors added comparison tables and the page is 14 months old.",
    col: "now",
  },
  {
    id: "pricing",
    title: "SaaS Pricing Guide",
    path: "/saas-pricing-guide",
    impact: 3,
    conf: 63,
    delta: "−12%",
    reason: "The decline overlaps last year’s seasonal dip. Re-check in three weeks before touching it.",
    col: "watch",
  },
  {
    id: "tools",
    title: "Startup Tools",
    path: "/startup-tools",
    impact: 1,
    conf: 78,
    delta: "−4%",
    reason: "Low, stable traffic and little relevance to the core product. Not worth an hour.",
    col: "leave",
  },
];

const ORDER: Col[] = ["now", "watch", "leave"];

function Pips({ n }: { n: number }) {
  return (
    <span className="flex items-center gap-[3px]" aria-label={`Impact ${n} of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} className={cn("h-2.5 w-[5px] rounded-[1px]", i < n ? "bg-ink" : "bg-line-strong")} />
      ))}
    </span>
  );
}

export function PriorityBoard() {
  const [items, setItems] = useState(INITIAL);
  const reduce = useReducedMotion();

  const move = (id: string, dir: -1 | 1) =>
    setItems((arr) =>
      arr.map((it) => {
        if (it.id !== id) return it;
        const next = ORDER[ORDER.indexOf(it.col) + dir];
        return next ? { ...it, col: next } : it;
      }),
    );

  return (
    <Section id="decision" chapter="06" chapterLabel="The decision" labelledBy="dec-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="dec-title"
            n="06"
            chapter="The decision"
            title="Not every page deserves another hour."
            sub="Every flagged page is scored on expected impact and confidence, then sorted into what to do now, what to watch, and what to leave alone."
          />
        </Reveal>

        <Reveal className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Decision board</span>
                <span className="hidden text-ink-3 sm:inline">/</span>
                <span className="hidden font-mono text-[11px] text-ink-2 sm:inline">Sorted by impact × confidence</span>
              </>
            }
            right={<Tag>Sample data</Tag>}
          >
            <div className="grid divide-y divide-line md:grid-cols-3 md:divide-x md:divide-y-0">
              {COLS.map((c) => {
                const list = items
                  .filter((i) => i.col === c.id)
                  .sort((a, b) => b.impact * b.conf - a.impact * a.conf);
                return (
                  <section key={c.id} aria-label={c.label} className="min-h-[260px] bg-[#FBFBF8] p-4 sm:p-5">
                    <div className="flex items-center justify-between">
                      <h3 className="flex items-center gap-2 font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-ink">
                        <span className={cn("h-2 w-2 rounded-[1px]", c.dot)} />
                        {c.label}
                      </h3>
                      <span className="num text-[11px] text-ink-2">{String(list.length).padStart(2, "0")}</span>
                    </div>
                    <p className="mt-1 text-[12px] text-ink-3">{c.hint}</p>

                    <div className="mt-4 space-y-3">
                      {list.map((it) => (
                        <motion.article
                          key={it.id}
                          layout={!reduce}
                          layoutId={reduce ? undefined : `card-${it.id}`}
                          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                          className="rounded-[4px] border border-line-strong bg-white p-4"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <h4 className="text-[15px] font-medium leading-tight text-ink">{it.title}</h4>
                              <div className="mt-0.5 truncate font-mono text-[11px] text-ink-3">{it.path}</div>
                            </div>
                            <span className="num text-[13px] text-decline">{it.delta}</span>
                          </div>
                          <dl className="mt-4 grid grid-cols-2 gap-3 border-t border-line pt-3">
                            <div>
                              <dt className="label">Impact</dt>
                              <dd className="mt-1.5">
                                <Pips n={it.impact} />
                              </dd>
                            </div>
                            <div>
                              <dt className="label">Confidence</dt>
                              <dd className="num mt-1 text-[15px] leading-none text-ink">{it.conf}%</dd>
                            </div>
                          </dl>
                          <p className="mt-3 text-[13px] leading-[1.5] text-ink-2">{it.reason}</p>
                          <div className="mt-3 flex items-center justify-between border-t border-line pt-2.5">
                            <span className="label">Move</span>
                            <div className="flex gap-1">
                              <button
                                type="button"
                                onClick={() => move(it.id, -1)}
                                disabled={it.col === "now"}
                                aria-label={`Move ${it.title} to the previous column`}
                                className="grid h-6 w-6 place-items-center rounded-[3px] border border-line-strong text-ink-2 transition-colors hover:border-ink hover:text-ink disabled:opacity-30 disabled:hover:border-line-strong"
                              >
                                <Arrow size={12} className="rotate-180" />
                              </button>
                              <button
                                type="button"
                                onClick={() => move(it.id, 1)}
                                disabled={it.col === "leave"}
                                aria-label={`Move ${it.title} to the next column`}
                                className="grid h-6 w-6 place-items-center rounded-[3px] border border-line-strong text-ink-2 transition-colors hover:border-ink hover:text-ink disabled:opacity-30 disabled:hover:border-line-strong"
                              >
                                <Arrow size={12} />
                              </button>
                            </div>
                          </div>
                        </motion.article>
                      ))}
                      {list.length === 0 && (
                        <div className="rounded-[4px] border border-dashed border-line-strong p-5 text-center text-[12px] text-ink-3">
                          Nothing here.
                        </div>
                      )}
                    </div>
                  </section>
                );
              })}
            </div>
          </Window>
          <p className="mt-3 text-[13px] text-ink-2">
            You make the final call. Move any page between columns to see how the board reads.
          </p>
        </Reveal>
      </Container>
    </Section>
  );
}
