import { cn } from "../utils/cn";
import { Arrow, ArrowDown } from "./icons";
import { INTEGRATIONS } from "./integrationData";
import { Container, Reveal, Section, SectionHeading } from "./ui";

const FLOW = [
  { k: "Data", d: "Search Console · Analytics" },
  { k: "Content intelligence", d: "Detect · diagnose · research · draft · verify", strong: true },
  { k: "CMS", d: "WordPress · Webflow · Contentful · HubSpot · Ghost · Shopify" },
  { k: "Published content", d: "Approved by a person" },
  { k: "Results", d: "Measured against matched controls" },
];

export function Integrations() {
  return (
    <Section id="integrations" chapter="14" chapterLabel="Integrations" labelledBy="int-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="int-title"
            n="14"
            chapter="Integrations"
            title="Fits the workflow you already have."
            sub="Connect the tools you already use. Data flows in read-only; content only flows out after a person approves it."
          />
        </Reveal>

        <Reveal className="mt-12 lg:mt-16">
          <ol className="flex flex-col items-stretch lg:flex-row">
            {FLOW.map((f, i) => (
              <li key={f.k} className="flex flex-1 flex-col items-stretch lg:flex-row">
                <div
                  className={cn(
                    "flex-1 rounded-[6px] border p-4",
                    f.strong ? "border-ink bg-paper" : "border-line-strong bg-white",
                  )}
                >
                  <div className="label text-ink">{f.k}</div>
                  <p className="mt-2 text-[13px] leading-snug text-ink-2">{f.d}</p>
                </div>
                {i < FLOW.length - 1 && (
                  <div className="grid place-items-center py-1.5 text-ink-3 lg:px-2 lg:py-0" aria-hidden="true">
                    <ArrowDown size={15} className="lg:hidden" />
                    <Arrow size={15} className="hidden lg:block" />
                  </div>
                )}
              </li>
            ))}
          </ol>
          <div className="mt-3 flex items-center gap-3" aria-hidden="true">
            <span className="text-lg leading-none text-ink-2">↺</span>
            <span className="h-px flex-1 border-t border-dashed border-ink-3" />
            <span className="font-mono text-[10px] uppercase tracking-[0.08em] text-ink-2">Results feed the next decision</span>
            <span className="h-px flex-1 border-t border-dashed border-ink-3" />
          </div>
        </Reveal>

        <Reveal className="mt-12">
          <ul className="grid border-t border-ink md:grid-cols-2 md:gap-x-12">
            {INTEGRATIONS.map(({ name, kind, access, Icon }) => (
              <li key={name} className="flex items-center gap-4 border-b border-line-strong py-4">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[4px] border border-line-strong bg-paper text-ink">
                  <Icon size={18} />
                </span>
                <div className="min-w-0">
                  <div className="text-[16px] font-medium text-ink">{name}</div>
                  <div className="mt-0.5 text-[13px] text-ink-2">{access}</div>
                </div>
                <span className="label ml-auto hidden sm:block">{kind}</span>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-[13px] text-ink-2">Publishing is available where supported. Need another CMS? Tell us.</p>
        </Reveal>
      </Container>
    </Section>
  );
}
