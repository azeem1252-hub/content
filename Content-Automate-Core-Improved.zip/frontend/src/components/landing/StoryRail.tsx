import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

interface Chap {
  id: string;
  n: string;
  label: string;
}

/** Thin chapter index on wide screens: where you are in the investigation. */
export function StoryRail() {
  const [chapters, setChapters] = useState<Chap[]>([]);
  const [active, setActive] = useState(-1);

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-chapter]"));
    setChapters(
      els.map((e) => ({ id: e.id, n: e.dataset.chapter ?? "", label: e.dataset.chapterLabel ?? "" })),
    );
    let raf = 0;
    const calc = () => {
      raf = 0;
      let idx = -1;
      els.forEach((e, i) => {
        if (e.getBoundingClientRect().top <= window.innerHeight * 0.45) idx = i;
      });
      setActive(idx);
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(calc);
    };
    calc();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  if (chapters.length === 0) return null;

  return (
    <nav
      aria-label="Chapters"
      className={cn(
        "fixed right-3 top-1/2 z-40 hidden -translate-y-1/2 transition-opacity duration-500 xl:block",
        active >= 0 ? "opacity-100" : "pointer-events-none opacity-0",
      )}
    >
      <ul className="flex flex-col items-end gap-[7px]">
        {chapters.map((c, i) => (
          <li key={c.id}>
            <a href={`#${c.id}`} className="group relative flex h-3 items-center justify-end" aria-label={`${c.n} ${c.label}`} aria-current={i === active ? "true" : undefined}>
              <span className="pointer-events-none absolute right-6 whitespace-nowrap rounded-[3px] border border-line-strong bg-white px-2 py-1 font-mono text-[10px] uppercase tracking-[0.07em] text-ink opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
                {c.n} / {c.label}
              </span>
              <span
                className={cn(
                  "block h-px transition-all duration-300",
                  i === active ? "w-6 bg-ink" : i < active ? "w-3 bg-ink-3" : "w-3 bg-line-strong",
                )}
              />
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
