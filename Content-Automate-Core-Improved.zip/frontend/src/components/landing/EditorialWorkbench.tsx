import { useState } from "react";
import { cn } from "../utils/cn";
import { Arrow, Check, Close } from "./icons";
import { Container, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView, useSequence } from "../lib/hooks";

type State = "pending" | "accepted" | "rejected";

const CHANGES = [
  {
    id: 1,
    line: 14,
    old: "CRM platforms help businesses manage customers.",
    next: "CRM platforms centralize customer data, workflows, and support operations, so sales, marketing, and support teams work from the same record.",
    why: ["Search intent", "Evidence", "Content gap"],
    detail: "Top-ranking pages define a CRM by what it centralizes. The old line was too vague to match the query.",
    source: "Industry survey, 2026 · 2 sources",
    conf: "High",
  },
  {
    id: 2,
    line: 22,
    old: "Plans start at $25 per seat per month.",
    next: "Entry pricing varies widely, and most vendors gate automation behind higher tiers. Compare plans by seats, automation limits, and support.",
    why: ["Content gap", "Evidence"],
    detail: "A single price was outdated and unsupported. Competitors answer with structure, not one number.",
    source: "Vendor pricing pages · checked May 2026",
    conf: "High",
  },
  {
    id: 3,
    line: 31,
    old: "CRM adoption increases revenue by 41%.",
    next: "Teams that adopt a CRM consistently report better pipeline visibility. Revenue impact varies by team and process.",
    why: ["Evidence"],
    detail: "No source supports the 41% figure. The replacement says only what the evidence supports.",
    source: "Replaces an unsupported statistic",
    conf: "Medium",
  },
];

const WHY_ALL = ["Search intent", "Evidence", "Content gap"];

export function EditorialWorkbench() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const shown = useSequence(inView, CHANGES.length, 1100, 600);
  const [states, setStates] = useState<State[]>(["pending", "pending", "pending"]);
  const [sel, setSel] = useState(0);
  const [clean, setClean] = useState(false);
  const cur = CHANGES[sel];
  const reviewed = states.filter((s) => s !== "pending").length;

  const set = (i: number, s: State) => setStates((arr) => arr.map((x, k) => (k === i ? (x === s ? "pending" : s) : x)));

  const block = (i: number) => {
    const c = CHANGES[i];
    const st = states[i];
    const tracked = shown > i && !clean;
    const showNew = (shown > i && st !== "rejected") || (clean && st !== "rejected");
    const showOld = st === "rejected" || (!showNew && true) || (tracked && st === "pending");
    return (
      <div
        key={c.id}
        role="button"
        tabIndex={0}
        aria-label={`Change ${c.id} of ${CHANGES.length}: ${st}`}
        onClick={() => setSel(i)}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            setSel(i);
          }
        }}
        className={cn(
          "group grid cursor-pointer grid-cols-[44px_1fr] gap-3 rounded-[3px] border-l-2 py-1.5 pr-2 transition-colors",
          sel === i ? "border-brand bg-brand-soft/50" : "border-transparent hover:bg-paper",
        )}
      >
        <div className="select-none pl-2 font-mono text-[11px] leading-[1.9] text-ink-3">
          <div>{c.line}</div>
          {tracked && st === "pending" && <div>{c.line + 1}</div>}
        </div>
        <div className="text-[14px] leading-[1.75] text-ink">
          {showOld && (
            <div className="flex gap-2">
              {tracked && st === "pending" && <span className="select-none font-mono text-decline">−</span>}
              <span
                className={cn(
                  "transition-colors duration-500",
                  tracked && st === "pending" && "rounded-[2px] bg-decline-soft text-decline line-through decoration-decline/50",
                )}
              >
                {c.old}
              </span>
            </div>
          )}
          {showNew && (
            <div className={cn("flex gap-2", tracked && st === "pending" && "mt-0.5")} style={{ animation: "ins-in .6s ease both" }}>
              {tracked && st === "pending" && <span className="select-none font-mono text-grow">+</span>}
              <span
                className={cn(
                  tracked && st === "pending" && "rounded-[2px] bg-grow-soft underline decoration-grow/50 underline-offset-2",
                )}
              >
                {c.next}
              </span>
            </div>
          )}
          {st !== "pending" && (
            <div className="mt-1">
              <Tag tone={st === "accepted" ? "green" : "red"}>{st === "accepted" ? "Accepted" : "Reverted"}</Tag>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <Section id="editor" chapter="07b" chapterLabel="The draft" labelledBy="ed-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="ed-title"
            n="07b"
            chapter="The draft"
            title="Let AI do the work. Keep the context."
            sub="Every change arrives as a tracked suggestion with its reason, its source, and its confidence. Accept it, reject it, or send it back."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          <Window
            title={
              <>
                <span className="font-medium text-ink">Editor</span>
                <span className="text-ink-3">/</span>
                <span className="truncate text-ink-2">Best CRM Software</span>
                <Tag className="hidden sm:inline-flex">v14 → v15</Tag>
              </>
            }
            right={
              <>
                <span className="num hidden text-[11px] text-ink-2 sm:inline">
                  {reviewed} of {CHANGES.length} reviewed
                </span>
                <Tag>Sample data</Tag>
              </>
            }
          >
            <div className="grid lg:grid-cols-[1.6fr_1fr]">
              <div className="border-b border-line bg-paper/70 lg:border-b-0 lg:border-r">
                <div className="flex items-center justify-between border-b border-line bg-white px-4 py-2 sm:px-6">
                  <span className="label">Suggesting</span>
                  <div className="flex rounded-[3px] border border-line-strong p-0.5 font-mono text-[10px] uppercase tracking-[0.06em]">
                    {[
                      ["Tracked", false],
                      ["Clean", true],
                    ].map(([l, v]) => (
                      <button
                        key={l as string}
                        type="button"
                        onClick={() => setClean(v as boolean)}
                        aria-pressed={clean === v}
                        className={cn("rounded-[2px] px-2.5 py-1 transition-colors", clean === v ? "bg-ink text-white" : "text-ink-2 hover:text-ink")}
                      >
                        {l as string}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="p-3 sm:p-6">
                  <div className="rounded-[4px] border border-line bg-white px-3 py-5 shadow-[0_1px_0_rgba(22,23,25,0.03)] sm:px-6 sm:py-7">
                    <h4 className="pl-[56px] font-serif text-[28px] leading-tight tracking-[-0.01em]">What is a CRM?</h4>
                    <div className="mt-4 space-y-2">
                      {block(0)}
                      <div className="grid grid-cols-[44px_1fr] gap-3 py-1.5 pr-2" aria-hidden="true">
                        <div className="select-none pl-2 font-mono text-[11px] leading-[1.9] text-ink-3">18</div>
                        <div className="space-y-1.5 pt-2">
                          <div className="h-[7px] rounded-[1px] bg-line" />
                          <div className="h-[7px] w-4/5 rounded-[1px] bg-line" />
                        </div>
                      </div>
                      <h5 className="pl-[56px] pt-1 text-[15px] font-semibold">Pricing</h5>
                      {block(1)}
                      <div className="grid grid-cols-[44px_1fr] gap-3 py-1.5 pr-2" aria-hidden="true">
                        <div className="select-none pl-2 font-mono text-[11px] leading-[1.9] text-ink-3">27</div>
                        <div className="space-y-1.5 pt-2">
                          <div className="h-[7px] w-11/12 rounded-[1px] bg-line" />
                          <div className="h-[7px] w-2/3 rounded-[1px] bg-line" />
                        </div>
                      </div>
                      {block(2)}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col p-4 sm:p-6">
                <div className="flex items-center justify-between">
                  <span className="label text-ink">Why this change?</span>
                  <span className="num text-[11px] text-ink-2">
                    {sel + 1} / {CHANGES.length}
                  </span>
                </div>
                <div key={cur.id} className="fade-in mt-4">
                  <div className="flex flex-wrap gap-1.5">
                    {WHY_ALL.map((w) => {
                      const on = cur.why.includes(w);
                      return (
                        <span
                          key={w}
                          className={cn(
                            "inline-flex items-center gap-1 rounded-[3px] border px-2 py-1 font-mono text-[10px] uppercase tracking-[0.06em]",
                            on ? "border-ink bg-white text-ink" : "border-line text-ink-3 line-through decoration-ink-3/40",
                          )}
                        >
                          {on && <Check size={10} />} {w}
                        </span>
                      );
                    })}
                  </div>
                  <p className="mt-4 text-[14px] leading-[1.6] text-ink">{cur.detail}</p>

                  <div className="mt-6">
                    <div className="label">Source</div>
                    <div className="mt-2 flex items-center justify-between gap-3 rounded-[4px] border border-line-strong bg-white px-3 py-2.5 font-mono text-[12px] text-ink">
                      <span className="truncate">[ {cur.source} ]</span>
                      <Arrow size={12} className="-rotate-45 shrink-0 text-ink-2" />
                    </div>
                  </div>
                  <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
                    <span className="label">Confidence</span>
                    <Tag tone={cur.conf === "High" ? "green" : "amber"}>{cur.conf}</Tag>
                  </div>
                </div>

                <div className="mt-auto pt-6">
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => set(sel, "accepted")}
                      aria-pressed={states[sel] === "accepted"}
                      className={cn(
                        "flex h-10 flex-1 items-center justify-center gap-2 rounded-[4px] border text-sm font-medium transition-colors",
                        states[sel] === "accepted" ? "border-grow bg-grow text-white" : "border-ink bg-ink text-white hover:bg-brand hover:border-brand",
                      )}
                    >
                      <Check size={14} /> Accept
                    </button>
                    <button
                      type="button"
                      onClick={() => set(sel, "rejected")}
                      aria-pressed={states[sel] === "rejected"}
                      className={cn(
                        "flex h-10 flex-1 items-center justify-center gap-2 rounded-[4px] border text-sm font-medium transition-colors",
                        states[sel] === "rejected" ? "border-decline bg-decline text-white" : "border-line-strong bg-white text-ink hover:border-ink",
                      )}
                    >
                      <Close size={14} /> Reject
                    </button>
                  </div>
                  <p className="mt-3 text-[12px] leading-snug text-ink-3">
                    Nothing is applied until a person accepts it. Rejected changes are reverted to the original text.
                  </p>
                </div>
              </div>
            </div>
          </Window>
        </div>
      </Container>
    </Section>
  );
}
