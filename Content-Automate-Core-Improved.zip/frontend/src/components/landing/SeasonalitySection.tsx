import type { ReactNode } from "react";
import { At, ChartSvg, DrawPath, FadePath } from "./charts";
import { Container, Reveal, Section, SectionHeading, Tag } from "./ui";
import { areaBetween, linePath, mapPts, seasonalSeries } from "../lib/chart";
import { useOnceInView } from "../lib/hooks";
import { cn } from "../utils/cn";

const W = 560;
const H = 260;
const N = 52;
const P = { min: 22, max: 90, t: 18, b: 18 };
const phase = -Math.PI / 2;

// A — seasonal: this year follows last year's up / down / up / down
const aLast = mapPts(seasonalSeries(N, { seed: 2, base: 56, amp: 22, cycles: 2, phase, noise: 1.2 }), W, H, P);
const aThis = mapPts(seasonalSeries(N, { seed: 3, base: 55, amp: 21, cycles: 2, phase, noise: 2 }), W, H, P);

// B — structural: stable, then declining while history stays flat
const bLast = mapPts(seasonalSeries(N, { seed: 5, base: 57, amp: 3, cycles: 2, phase, noise: 1.2 }), W, H, P);
const bVals = seasonalSeries(N, {
  seed: 6,
  base: 57,
  amp: 3,
  cycles: 2,
  phase,
  noise: 1.5,
  slope: (t) => (t < 0.34 ? 0 : -((t - 0.34) / 0.66) * 38),
});
const bThis = mapPts(bVals, W, H, P);
const SPLIT = 17;

function Panel({
  label,
  verdict,
  verdictClass,
  desc,
  conf,
  confLabel,
  legend,
  children,
}: {
  label: string;
  verdict: string;
  verdictClass: string;
  desc: string;
  conf: number;
  confLabel: string;
  legend: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-[6px] border border-line-strong bg-white">
      <div className="flex h-10 items-center justify-between border-b border-line px-4">
        <span className="label text-ink">{label}</span>
        <Tag>Sample data</Tag>
      </div>
      <div className="p-4 sm:p-5">
        <div className="relative h-[220px] border-b border-line sm:h-[270px]">{children}</div>
        <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
          {legend}
        </div>
      </div>
      <div className="flex items-end justify-between gap-4 border-t border-line p-4 sm:p-5">
        <div>
          <div className={cn("font-serif text-[40px] leading-none tracking-[-0.01em]", verdictClass)}>{verdict}</div>
          <p className="mt-2 max-w-[320px] text-[13px] leading-snug text-ink-2">{desc}</p>
        </div>
        <div className="shrink-0 text-right">
          <div className="label">{confLabel}</div>
          <div className="num mt-1 text-[26px] leading-none text-ink">{conf}%</div>
        </div>
      </div>
    </div>
  );
}

const Key = ({ dashed, color, children }: { dashed?: boolean; color: string; children: ReactNode }) => (
  <span className="flex items-center gap-1.5">
    <span className={cn("w-4", dashed ? "h-0 border-t border-dashed" : "h-[2px]")} style={dashed ? { borderColor: color } : { background: color }} />
    {children}
  </span>
);

export function SeasonalitySection() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");

  return (
    <Section id="context" chapter="03" chapterLabel="Context" labelledBy="ctx-title" tone="white">
      <Container>
        <Reveal>
          <SectionHeading
            id="ctx-title"
            n="03"
            chapter="Context"
            title="Not everything that falls is broken."
            sub="Compare historical patterns before labeling a page as content decay."
          />
        </Reveal>

        <div ref={ref} className="relative mt-12 grid gap-4 lg:mt-16 lg:grid-cols-2 lg:gap-10">
          <Panel
            label="Expected seasonality"
            verdict="Expected"
            verdictClass="text-grow"
            desc="This year follows last year’s shape. The dip is the calendar, not the content."
            conf={94}
            confLabel="Pattern match"
            legend={
              <>
                <Key color="#161719">This year</Key>
                <Key color="#92958E" dashed>
                  Last year
                </Key>
              </>
            }
          >
            <ChartSvg w={W} h={H}>
              <FadePath d={`M${aThis[19][0]} 0 L${aThis[33][0]} 0 L${aThis[33][0]} ${H} L${aThis[19][0]} ${H} Z`} fill="#EEF6F1" active={inView} delay={1.8} />
              <FadePath d={linePath(aLast)} stroke="#92958E" dash="4 4" active={inView} delay={0.2} />
              <DrawPath d={linePath(aThis)} stroke="#161719" width={2} active={inView} duration={2.2} delay={0.3} />
            </ChartSvg>
            <At x={(aThis[19][0] + aThis[33][0]) / 2} y={0} w={W} h={H} className="-translate-x-1/2 pt-1.5">
              <span
                className="whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.06em] text-grow transition-opacity duration-700"
                style={{ opacity: inView ? 1 : 0, transitionDelay: inView ? "2s" : "0s" }}
              >
                Same dip as last year
              </span>
            </At>
          </Panel>

          <Panel
            label="Structural decline"
            verdict="Investigate"
            verdictClass="text-decline"
            desc="History stayed flat while this year kept falling. Something changed."
            conf={89}
            confLabel="Deviation from history"
            legend={
              <>
                <Key color="#161719">This year</Key>
                <Key color="#C84A42">Decline</Key>
                <Key color="#92958E" dashed>
                  Last year
                </Key>
              </>
            }
          >
            <ChartSvg w={W} h={H}>
              <FadePath d={areaBetween(bLast.slice(SPLIT), bThis.slice(SPLIT))} fill="#FCEFED" active={inView} delay={2.4} />
              <FadePath d={linePath(bLast)} stroke="#92958E" dash="4 4" active={inView} delay={0.2} />
              <DrawPath d={linePath(bThis.slice(0, SPLIT + 1))} stroke="#161719" width={2} active={inView} duration={1} delay={0.3} />
              <DrawPath d={linePath(bThis.slice(SPLIT))} stroke="#C84A42" width={2} active={inView} duration={1.8} delay={1.2} />
            </ChartSvg>
            <At x={bThis[40][0]} y={0} w={W} h={H} className="-translate-x-1/2 pt-1.5">
              <span
                className="whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.06em] text-decline transition-opacity duration-700"
                style={{ opacity: inView ? 1 : 0, transitionDelay: inView ? "2.6s" : "0s" }}
              >
                Diverges from history
              </span>
            </At>
          </Panel>

          <div
            className="pointer-events-none absolute left-1/2 top-1/2 z-10 hidden h-11 w-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-line-strong bg-paper font-mono text-[11px] uppercase text-ink-2 lg:grid"
            aria-hidden="true"
          >
            vs
          </div>
        </div>

        <Reveal className="mt-12 grid gap-px overflow-hidden rounded-[6px] border border-line bg-line md:grid-cols-3">
          {[
            ["01", "Compare the same weeks in previous years."],
            ["02", "Check whether pages in the same topic cluster moved together."],
            ["03", "Report a confidence level, not a verdict."],
          ].map(([n, t]) => (
            <div key={n} className="bg-paper p-5">
              <span className="num text-[11px] text-brand">{n}</span>
              <p className="mt-2 text-[15px] leading-snug text-ink">{t}</p>
            </div>
          ))}
        </Reveal>
      </Container>
    </Section>
  );
}
