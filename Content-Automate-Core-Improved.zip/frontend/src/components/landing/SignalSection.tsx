import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { cn } from "../utils/cn";
import { Chapter, Container, Tag } from "./ui";
import { Check } from "./icons";
import { decaySeries, linePath, mapPts, polyLen } from "../lib/chart";
import { IS_AUTOMATED } from "../lib/motion";

gsap.registerPlugin(ScrollTrigger);

const W = 1200;
const H = 360;
const N = 120;
const PEAK_AT = 0.42;
const series = decaySeries(N, { seed: 4, peakAt: PEAK_AT, drop: 0.46, noise: 1.8, start: 36, peak: 82 });
const pts = mapPts(series, W, H, { min: 20, max: 92, t: 20, b: 20 });
const PEAK_I = Math.round(PEAK_AT * (N - 1));
const ANOM_I = 80;
const rise = pts.slice(0, PEAK_I + 1);
const fall = pts.slice(PEAK_I);
const L1 = polyLen(rise);
const L2 = polyLen(fall);
const LT = L1 + L2;
const FR_PEAK = L1 / LT;
const FR_FALL = FR_PEAK + 0.07;
const FR_ANOM = (L1 + polyLen(pts.slice(PEAK_I, ANOM_I + 1))) / LT;
const QX = W * 0.965;

const pct = (x: number, total: number) => `${(x / total) * 100}%`;

const STAGES = [
  "Traffic rises",
  "The search environment changes",
  "Traffic begins to fall",
  "The system detects the anomaly",
  "We noticed before the quarterly report did",
];

const EVENTS = [
  { i: 55, label: "Search demand shifts", h: 24 },
  { i: 62, label: "SERP layout changes", h: 42 },
  { i: 69, label: "Competitor publishes", h: 60 },
];

export function SignalSection() {
  const outerRef = useRef<HTMLDivElement>(null);
  const graphRef = useRef<HTMLDivElement>(null);
  const p1 = useRef<SVGPathElement>(null);
  const p2 = useRef<SVGPathElement>(null);
  const head = useRef<HTMLDivElement>(null);
  const [stage, setStage] = useState(-1);
  const last = useRef(-2);

  useEffect(() => {
    const update = (p: number) => {
      const f = Math.min(1, p / 0.88);
      const d = f * LT;
      const a = p1.current;
      const b = p2.current;
      const h = head.current;
      if (!a || !b || !h) return;
      a.style.strokeDashoffset = String(L1 - Math.min(d, L1));
      b.style.strokeDashoffset = String(L2 - Math.max(0, Math.min(d - L1, L2)));
      const onRise = d <= L1;
      const pt = (onRise ? a : b).getPointAtLength(onRise ? d : d - L1);
      h.style.left = `${(pt.x / W) * 100}%`;
      h.style.top = `${(pt.y / H) * 100}%`;
      h.style.opacity = f > 0.004 ? "1" : "0";
      h.style.backgroundColor = onRise ? "#161719" : "#C84A42";

      let s = -1;
      if (f >= 0.02) s = 0;
      if (f >= FR_PEAK) s = 1;
      if (f >= FR_FALL) s = 2;
      if (f >= FR_ANOM) s = 3;
      if (f >= 0.985) s = 4;
      if (s !== last.current) {
        last.current = s;
        setStage(s);
      }
    };

    if (IS_AUTOMATED || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      update(1);
      return;
    }
    update(0);
    const mm = gsap.matchMedia();
    mm.add("(min-width: 1024px)", () => {
      const st = ScrollTrigger.create({
        trigger: outerRef.current,
        start: "top top+=64",
        end: "bottom bottom",
        onUpdate: (self) => update(self.progress),
        onRefresh: (self) => update(self.progress),
      });
      return () => st.kill();
    });
    mm.add("(max-width: 1023px)", () => {
      const st = ScrollTrigger.create({
        trigger: graphRef.current,
        start: "top 85%",
        end: "bottom 45%",
        onUpdate: (self) => update(self.progress),
        onRefresh: (self) => update(self.progress),
      });
      return () => st.kill();
    });
    return () => mm.revert();
  }, []);

  const ax = pts[ANOM_I][0];
  const ay = pts[ANOM_I][1];

  return (
    <section
      id="signal"
      data-chapter="01"
      data-chapter-label="The signal"
      aria-labelledby="signal-title"
      className="relative scroll-mt-16 bg-paper"
    >
      <div ref={outerRef} className="lg:h-[270vh]">
        <div className="py-20 sm:py-24 lg:sticky lg:top-16 lg:flex lg:h-[calc(100vh-4rem)] lg:flex-col lg:justify-center lg:py-0">
          <Container className="w-full">
            <div className="grid gap-8 lg:grid-cols-12 lg:gap-12">
              <div className="lg:col-span-7">
                <Chapter n="01" label="The signal" />
                <h2
                  id="signal-title"
                  className="mt-5 font-serif text-[clamp(2.5rem,5.4vw,4.75rem)] font-normal leading-[1.02] tracking-[-0.02em] text-balance"
                >
                  Your traffic doesn’t disappear all at once.
                </h2>
                <p className="mt-5 max-w-[600px] text-[17px] leading-[1.6] text-ink-2 text-pretty">
                  Search demand changes. SERPs shift. Competitors publish. Content gets stale. Seasonality moves. The
                  warning signs usually appear before the traffic loss becomes obvious.
                </p>
              </div>
              <div className="lg:col-span-5 lg:pt-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="label">Investigation log</span>
                  <Tag>Sample data</Tag>
                </div>
                <ol className="border-t border-line-strong">
                  {STAGES.map((s, i) => {
                    const active = stage === i;
                    const past = stage > i;
                    return (
                      <li
                        key={s}
                        className={cn(
                          "flex items-center gap-3 border-b border-line py-2 transition-colors duration-500",
                          active ? "text-ink" : past ? "text-ink-2" : "text-ink-3",
                        )}
                      >
                        <span className="num w-5 text-[11px]">{String(i + 1).padStart(2, "0")}</span>
                        <span className={cn("text-[14px]", active && "font-medium")}>{s}</span>
                        <span className="ml-auto">
                          {past ? (
                            <Check size={13} className="text-grow" />
                          ) : active ? (
                            <span className="pulse-dot block h-1.5 w-1.5 rounded-full bg-brand" />
                          ) : null}
                        </span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            </div>

            {/* graph — sits directly on the page */}
            <div ref={graphRef} className="mt-10 lg:mt-8">
              <div className="relative h-[220px] w-full border-b border-line-strong sm:h-[280px] lg:h-[clamp(200px,32vh,330px)]">
                <svg
                  viewBox={`0 0 ${W} ${H}`}
                  preserveAspectRatio="none"
                  className="absolute inset-0 h-full w-full overflow-visible"
                  role="img"
                  aria-label="Chart: organic traffic rises to a peak, then falls after the search environment changes. The system flags the anomaly well before the quarterly report."
                >
                  {[0.25, 0.5, 0.75].map((g) => (
                    <line key={g} x1={0} x2={W} y1={H * g} y2={H * g} stroke="#E4E5DF" strokeWidth={1} />
                  ))}
                  <rect
                    x={ax}
                    y={0}
                    width={QX - ax}
                    height={H}
                    fill="#FCEFED"
                    style={{ opacity: stage >= 3 ? 0.9 : 0, transition: "opacity .8s ease" }}
                  />
                  <path
                    ref={p1}
                    d={linePath(rise)}
                    fill="none"
                    stroke="#161719"
                    strokeWidth={2.25}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                    strokeDasharray={L1}
                    strokeDashoffset={L1}
                  />
                  <path
                    ref={p2}
                    d={linePath(fall)}
                    fill="none"
                    stroke="#C84A42"
                    strokeWidth={2.25}
                    strokeLinejoin="round"
                    strokeLinecap="round"
                    strokeDasharray={L2}
                    strokeDashoffset={L2}
                  />
                </svg>

                {/* head */}
                <div
                  ref={head}
                  className="pointer-events-none absolute z-10 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white opacity-0"
                  style={{ left: 0, top: "100%" }}
                />

                {/* peak */}
                <div
                  className="absolute -translate-x-1/2 transition-opacity duration-500"
                  style={{ left: pct(pts[PEAK_I][0], W), top: pct(pts[PEAK_I][1], H), opacity: stage >= 1 ? 1 : 0 }}
                >
                  <span className="absolute -top-6 left-1/2 -translate-x-1/2 font-mono text-[10px] uppercase tracking-[0.06em] text-ink-2">
                    Peak
                  </span>
                </div>

                {/* environment events */}
                {EVENTS.map((e, k) => (
                  <div
                    key={e.i}
                    className="absolute bottom-0 border-l border-dashed border-ink-3 transition-all duration-700"
                    style={{
                      left: pct(pts[e.i][0], W),
                      height: `${e.h}%`,
                      opacity: stage >= 1 ? 1 : 0,
                      transitionDelay: stage >= 1 ? `${k * 350}ms` : "0ms",
                    }}
                  >
                    <span className="absolute left-1.5 top-0 -translate-y-1/2 whitespace-nowrap bg-paper px-1 font-mono text-[9px] uppercase tracking-[0.05em] text-ink-2 sm:text-[10px]">
                      {e.label}
                    </span>
                  </div>
                ))}

                {/* detection flag */}
                <div
                  className="absolute top-0 -translate-x-1/2 transition-opacity duration-500"
                  style={{ left: pct(ax, W), height: pct(ay, H), opacity: stage >= 3 ? 1 : 0 }}
                >
                  <span className="absolute -top-0.5 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-[3px] bg-ink px-2 py-1 font-mono text-[10px] uppercase tracking-[0.08em] text-white">
                    Signal detected
                  </span>
                  <span className="absolute bottom-0 left-1/2 top-6 w-px -translate-x-1/2 bg-ink" />
                  <span className="absolute -bottom-[7px] left-1/2 h-3.5 w-3.5 -translate-x-1/2 rounded-full border-2 border-ink bg-white" />
                </div>

                {/* quarterly report */}
                <div
                  className="absolute top-0 h-full border-l border-dashed border-ink-3 transition-opacity duration-700"
                  style={{ left: pct(QX, W), opacity: stage >= 1 ? 1 : 0 }}
                >
                  <span className="absolute right-1.5 top-1 whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.05em] text-ink-2 sm:text-[10px]">
                    Quarterly report
                  </span>
                </div>

                {/* lead-time bracket */}
                <div
                  className="absolute bottom-4 flex items-center transition-opacity duration-700"
                  style={{
                    left: pct(ax, W),
                    width: pct(QX - ax, W),
                    opacity: stage >= 4 ? 1 : 0,
                    transitionDelay: stage >= 4 ? "200ms" : "0ms",
                  }}
                >
                  <span className="h-2 w-px bg-ink" />
                  <span className="h-px flex-1 bg-ink" />
                  <span className="mx-2 whitespace-nowrap font-mono text-[9px] uppercase tracking-[0.06em] text-ink sm:text-[10px]">
                    Noticed earlier
                  </span>
                  <span className="h-px flex-1 bg-ink" />
                  <span className="h-2 w-px bg-ink" />
                </div>
              </div>
              <div className="mt-2 flex justify-between font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">
                <span>12 months ago</span>
                <span>Today</span>
              </div>

              <p
                className={cn(
                  "mt-5 min-h-[3rem] font-serif text-[clamp(1.75rem,3.2vw,2.9rem)] leading-[1.05] tracking-[-0.015em] transition-all duration-700 lg:mt-4",
                  stage >= 4 ? "translate-y-0 opacity-100" : "translate-y-2 opacity-0",
                )}
                aria-live="polite"
              >
                We noticed before the quarterly report did.
              </p>
            </div>
          </Container>
        </div>
      </div>
    </section>
  );
}
