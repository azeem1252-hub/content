import { useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { ChartSvg, DrawPath } from "./charts";
import { ArrowDown, Check } from "./icons";
import { Container, Reveal, Section, SectionHeading, Tag, Window } from "./ui";
import { useOnceInView } from "../lib/hooks";

type Lens = "search" | "answers" | "ai";

const LENSES: { id: Lens; label: string; out: string; fixes: string[] }[] = [
  {
    id: "search",
    label: "Search",
    out: "Google",
    fixes: ["Title and meta description matched to intent", "Clear heading hierarchy", "Internal links to related pages"],
  },
  {
    id: "answers",
    label: "Answers",
    out: "Answers",
    fixes: ["A direct answer near the top", "Question-style headings", "Concise lists and comparison tables"],
  },
  {
    id: "ai",
    label: "AI",
    out: "AI citations",
    fixes: ["Clear, unambiguous entities", "Claims tied to named sources", "Self-contained statements that quote well"],
  },
];

const ROWS: { lenses: Lens[]; tag: string; node: ReactNode }[] = [
  {
    lenses: ["search"],
    tag: "Title · Meta",
    node: <div className="text-[15px] font-medium text-ink">Best CRM Software for Growing Teams (2026)</div>,
  },
  {
    lenses: ["answers", "ai"],
    tag: "H2 · Direct answer",
    node: (
      <>
        <div className="text-[13px] font-semibold text-ink">What should I look for in a CRM?</div>
        <p className="mt-1 text-[13px] leading-snug text-ink-2">
          Match integrations, reporting, and seat limits to your sales process before comparing price.
        </p>
      </>
    ),
  },
  {
    lenses: ["answers"],
    tag: "List",
    node: (
      <ul className="space-y-1 text-[13px] text-ink-2">
        {["Integrations with your help desk", "Reporting you can export", "Automation limits by plan"].map((t) => (
          <li key={t} className="flex gap-2">
            <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-ink-3" />
            {t}
          </li>
        ))}
      </ul>
    ),
  },
  {
    lenses: ["ai"],
    tag: "Entities · Sources",
    node: (
      <div className="flex flex-wrap gap-1.5">
        {["CRM", "Sales pipeline", "Help desk", "Automation tiers"].map((t) => (
          <span key={t} className="rounded-[3px] border border-line-strong px-1.5 py-0.5 font-mono text-[10.5px] text-ink-2">
            {t}
          </span>
        ))}
        <span className="rounded-[3px] border border-grow/40 bg-grow-soft px-1.5 py-0.5 font-mono text-[10.5px] text-grow">3 sources cited</span>
      </div>
    ),
  },
  {
    lenses: ["search"],
    tag: "Internal links",
    node: <div className="font-mono text-[12px] text-brand underline underline-offset-2">→ /ai-support-software · /helpdesk-vs-crm</div>,
  },
];

function Output({ lens }: { lens: Lens }) {
  if (lens === "search")
    return (
      <div key="search" className="fade-in">
        <div className="flex items-center gap-2 rounded-full border border-line-strong px-4 py-2 text-[13px] text-ink-2">
          <span className="h-2.5 w-2.5 rounded-full border border-ink-3" /> best crm software for small teams
        </div>
        <div className="mt-5">
          <div className="font-mono text-[11px] text-ink-2">acme-saas.com › crm › best-crm-software</div>
          <div className="mt-1 text-[19px] leading-snug text-brand">Best CRM Software for Growing Teams (2026)</div>
          <p className="mt-1 text-[13px] leading-[1.55] text-ink-2">
            <span className="text-ink-3">May 2026 — </span>Compare CRM plans by seats, automation limits, and support. What to look for before you
            buy, with sources.
          </p>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-[13px] text-brand">
            <span>What is a CRM?</span>
            <span>How to choose</span>
            <span>Pricing comparison</span>
          </div>
        </div>
      </div>
    );
  if (lens === "answers")
    return (
      <div key="answers" className="fade-in">
        <div className="flex items-center gap-2 rounded-full border border-line-strong px-4 py-2 text-[13px] text-ink-2">
          <span className="h-2.5 w-2.5 rounded-full border border-ink-3" /> what should i look for in a crm
        </div>
        <div className="mt-5 rounded-[4px] border border-line-strong p-4">
          <div className="label">Extracted answer</div>
          <p className="mt-2 text-[14px] leading-[1.55] text-ink">
            Match integrations, reporting, and seat limits to your sales process before comparing price.
          </p>
          <ul className="mt-2 space-y-1 text-[13px] text-ink-2">
            {["Integrations with your help desk", "Reporting you can export", "Automation limits by plan"].map((t) => (
              <li key={t} className="flex gap-2">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-ink-3" />
                {t}
              </li>
            ))}
          </ul>
          <div className="mt-3 border-t border-line pt-2 font-mono text-[11px] text-ink-2">From: acme-saas.com › best-crm-software</div>
        </div>
      </div>
    );
  return (
    <div key="ai" className="fade-in">
      <div className="flex items-center justify-between">
        <span className="label text-ink">Synthesized answer</span>
        <span className="font-mono text-[10px] uppercase tracking-[0.06em] text-ink-3">Illustrative</span>
      </div>
      <p className="mt-3 text-[14px] leading-[1.7] text-ink">
        Buyers usually start by matching integrations, reporting, and seat limits to their sales process
        <sup className="mx-0.5 rounded-[2px] bg-brand-soft px-1 font-mono text-[10px] text-brand">1</sup>. Plan structure matters more than the
        headline price, because automation is often gated by higher tiers
        <sup className="mx-0.5 rounded-[2px] bg-brand-soft px-1 font-mono text-[10px] text-brand">2</sup>.
      </p>
      <ol className="mt-4 space-y-2 border-t border-line pt-3 text-[12.5px]">
        <li className="flex gap-2">
          <span className="num text-brand">1</span>
          <span className="text-ink">
            Best CRM Software for Growing Teams <span className="font-mono text-ink-2">· acme-saas.com</span>
          </span>
        </li>
        <li className="flex gap-2">
          <span className="num text-brand">2</span>
          <span className="text-ink">
            Vendor pricing documentation <span className="font-mono text-ink-2">· checked May 2026</span>
          </span>
        </li>
      </ol>
    </div>
  );
}

export function VisibilitySection() {
  const [ref, inView] = useOnceInView<HTMLDivElement>("-20% 0px");
  const [lens, setLens] = useState<Lens>("search");
  const cur = LENSES.find((l) => l.id === lens)!;

  return (
    <Section id="visibility" chapter="10" chapterLabel="Visibility" labelledBy="vis-title">
      <Container>
        <Reveal>
          <SectionHeading
            id="vis-title"
            n="10"
            chapter="Visibility"
            title="One piece of content. More ways to be discovered."
            sub="Optimize content structure, evidence, clarity, and entities so search and answer systems can better understand and reference it."
          />
        </Reveal>

        <div ref={ref} className="mt-12 lg:mt-16">
          {/* diagram */}
          <div className="mx-auto max-w-[760px]">
            <div className="flex justify-center">
              <div className="rounded-[4px] border border-ink bg-white px-6 py-2.5 font-mono text-[12px] uppercase tracking-[0.12em]">Article</div>
            </div>
            <div className="relative h-12 sm:h-14" aria-hidden="true">
              <ChartSvg w={760} h={56} grid={0}>
                <DrawPath d="M380 0 V24" stroke="#161719" width={1.25} active={inView} duration={0.5} />
                <DrawPath d="M127 24 H633" stroke="#161719" width={1.25} active={inView} duration={0.7} delay={0.4} />
                <DrawPath d="M127 24 V56" stroke="#161719" width={1.25} active={inView} duration={0.4} delay={1} />
                <DrawPath d="M380 24 V56" stroke="#161719" width={1.25} active={inView} duration={0.4} delay={1} />
                <DrawPath d="M633 24 V56" stroke="#161719" width={1.25} active={inView} duration={0.4} delay={1} />
              </ChartSvg>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:gap-4" role="tablist" aria-label="Discovery surface">
              {LENSES.map((l) => (
                <button
                  key={l.id}
                  type="button"
                  role="tab"
                  aria-selected={lens === l.id}
                  onClick={() => setLens(l.id)}
                  className={cn(
                    "rounded-[4px] border px-2 py-3 text-center transition-colors sm:px-4",
                    lens === l.id ? "border-ink bg-white" : "border-line-strong bg-paper hover:border-ink-3",
                  )}
                >
                  <div className={cn("font-mono text-[12px] font-medium uppercase tracking-[0.1em]", lens === l.id ? "text-ink" : "text-ink-2")}>{l.label}</div>
                  <ArrowDown size={12} className="mx-auto my-1.5 text-ink-3" />
                  <div className="text-[12px] text-ink-2 sm:text-[13px]">{l.out}</div>
                </button>
              ))}
            </div>
          </div>

          {/* transformation */}
          <Reveal className="mt-10">
            <Window
              title={
                <>
                  <span className="font-medium text-ink">How the same article is read</span>
                  <Tag tone="blue" className="ml-1">
                    {cur.label}
                  </Tag>
                </>
              }
              right={<Tag>Illustrative</Tag>}
            >
              <div className="grid lg:grid-cols-[1fr_1fr]" role="tabpanel">
                <div className="border-b border-line p-4 sm:p-6 lg:border-b-0 lg:border-r">
                  <div className="label">The article</div>
                  <ul className="mt-3 space-y-2">
                    {ROWS.map((r, i) => {
                      const on = r.lenses.includes(lens);
                      return (
                        <li
                          key={i}
                          className={cn(
                            "rounded-[4px] border-l-2 px-3 py-2.5 transition-all duration-500",
                            on ? "border-brand bg-brand-soft/60 opacity-100" : "border-line opacity-45",
                          )}
                        >
                          <div className="mb-1 font-mono text-[10px] uppercase tracking-[0.07em] text-ink-3">{r.tag}</div>
                          {r.node}
                        </li>
                      );
                    })}
                  </ul>
                </div>
                <div className="bg-[#FBFBF8] p-4 sm:p-6">
                  <div className="label mb-3">What the system sees</div>
                  <div className="min-h-[260px] rounded-[4px] border border-line bg-white p-4 sm:p-5">
                    <Output lens={lens} />
                  </div>
                  <ul className="mt-4 space-y-1.5">
                    {cur.fixes.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-[13px] text-ink">
                        <Check size={14} className="mt-0.5 shrink-0 text-grow" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Window>
            <p className="mt-3 max-w-[720px] text-[13px] leading-snug text-ink-2">
              Illustrative examples. Structure and evidence help systems understand your content; they don’t guarantee rankings or citations.
            </p>
          </Reveal>
        </div>
      </Container>
    </Section>
  );
}
