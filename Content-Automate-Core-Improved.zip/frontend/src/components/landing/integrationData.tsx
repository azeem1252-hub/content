import type { ComponentType } from "react";
import {
  GlyphAnalytics,
  GlyphContentful,
  GlyphGhost,
  GlyphHubSpot,
  GlyphSearchConsole,
  GlyphShopify,
  GlyphWebflow,
  GlyphWordPress,
} from "./icons";

export interface Integration {
  name: string;
  kind: "Data source" | "CMS";
  access: string;
  Icon: ComponentType<{ className?: string; size?: number }>;
}

export const INTEGRATIONS: Integration[] = [
  { name: "Google Search Console", kind: "Data source", access: "Read-only", Icon: GlyphSearchConsole },
  { name: "Google Analytics", kind: "Data source", access: "Read-only", Icon: GlyphAnalytics },
  { name: "WordPress", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphWordPress },
  { name: "Webflow", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphWebflow },
  { name: "Contentful", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphContentful },
  { name: "HubSpot", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphHubSpot },
  { name: "Ghost", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphGhost },
  { name: "Shopify", kind: "CMS", access: "Draft & publish after approval", Icon: GlyphShopify },
];
