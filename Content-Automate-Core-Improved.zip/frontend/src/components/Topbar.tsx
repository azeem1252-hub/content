import { useState, useRef, useEffect } from "react";
import {
  Menu,
  Search,
  Bell,
  Sun,
  Moon,
  ChevronDown,
  Check,
  Globe,
  FileText,
  Plus,
  Settings,
  Sliders,
  X,
  CreditCard,
  Users,
  Key,
  Zap,
  ExternalLink,
  LogOut,
} from "lucide-react";
import { useTheme } from "../lib/theme";
import { useNav } from "../lib/nav";
import { usePipelineData } from "../lib/dataContext";
import { Dropdown, DropdownItem, DropdownLabel, DropdownSeparator } from "./Dropdown";
import { Avatar } from "./Avatar";
import { StatusBadge } from "./StatusBadge";
import { Logo } from "./Logo";

export function Topbar() {
  const { theme, setTheme } = useTheme();
  const { setSidebarOpen, setPage, openInspector, activeRunThreadId, openLaunchModal } = useNav();
  const { websites, contentItems } = usePipelineData();
  const [notifOpen, setNotifOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [search, setSearch] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Global ⌘K / Ctrl+K search focus handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        searchInputRef.current?.focus();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const pendingReview = contentItems.filter((c) => c.status === "Awaiting Approval");
  const defaultSite = websites.find((w) => w.is_default) || websites[0];
  const activeWorkspaceName = defaultSite?.name || "ContentOps Studio";

  // Derive real notifications from pending reviews and recently published runs
  const notifications = [
    ...pendingReview.map((item) => ({
      id: item.id,
      title: `Review needed: “${item.title}”`,
      time: item.createdAt,
      color: "var(--color-warn)",
      onClick: () => openInspector(item.id),
    })),
    ...contentItems
      .filter((c) => c.status === "Published")
      .slice(0, 3)
      .map((item) => ({
        id: item.id,
        title: `Published: “${item.title}”`,
        time: item.createdAt,
        color: "var(--color-live)",
        onClick: () => openInspector(item.id),
      })),
  ];

  return (
    <header
      className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-[var(--color-bg-elev)]/85 px-4 backdrop-blur-xl lg:px-6"
      style={{ borderColor: "var(--color-border)" }}
    >
      {/* Mobile brand & menu */}
      <div className="flex items-center gap-2 lg:hidden">
        <button
          onClick={() => setSidebarOpen(true)}
          className="rounded-lg p-1.5 text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
          aria-label="Open menu"
        >
          <Menu size={18} />
        </button>
        <Logo size={24} withText={false} />
      </div>

      {/* Website selector */}
      <Dropdown
        align="start"
        trigger={
          <button className="group flex cursor-pointer items-center gap-2.5 rounded-xl border border-[var(--color-border)] bg-[var(--color-bg-soft)] px-2.5 py-1.5 text-sm font-medium text-[var(--color-text)] transition-colors hover:border-[var(--color-border-strong)]">
            <span
              className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg"
              style={{ background: "var(--color-accent-soft)", color: "var(--color-accent)" }}
            >
              <Globe size={13} />
            </span>
            <span className="hidden max-w-[180px] truncate text-[13px] font-semibold sm:inline">
              {activeWorkspaceName}
            </span>
            <span className="text-xs font-medium sm:hidden">Target</span>
            <ChevronDown
              size={13}
              className="ml-0.5 text-[var(--color-text-subtle)] transition-colors group-hover:text-[var(--color-text)]"
            />
          </button>
        }
      >
        <DropdownLabel>Websites</DropdownLabel>
        {websites.map((w) => (
          <DropdownItem
            key={w.id}
            icon={w.id === defaultSite?.id ? <Check size={14} className="text-[var(--color-live)]" /> : <Globe size={14} />}
            badge={w.is_default ? "Default" : undefined}
            onSelect={() => setPage("websites")}
          >
            {w.name}
          </DropdownItem>
        ))}
        {websites.length === 0 && (
          <DropdownItem icon={<Plus size={14} />} onSelect={() => setPage("websites")}>
            Connect a website
          </DropdownItem>
        )}
        <DropdownSeparator />
        <DropdownItem icon={<Settings size={14} />} onSelect={() => setPage("settings")}>
          Settings &amp; webhooks
        </DropdownItem>
      </Dropdown>

      {/* Search */}
      <div className="relative ml-2 hidden flex-1 md:block">
        <div className="relative max-w-md">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-subtle)]"
          />
          <input
            ref={searchInputRef}
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onFocus={() => setSearchOpen(true)}
            onBlur={() => window.setTimeout(() => setSearchOpen(false), 200)}
            placeholder="Search runs, websites…"
            className="h-9 w-full rounded-xl border bg-[var(--color-bg-soft)] pl-9 pr-16 text-xs text-[var(--color-text)] placeholder:text-[var(--color-text-subtle)] transition-colors focus:border-[var(--color-accent)] focus:bg-[var(--color-bg-elev)] focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)]/15"
            style={{ borderColor: "var(--color-border)" }}
          />
          {search.length > 0 && (
            <button
              onClick={() => {
                setSearch("");
                searchInputRef.current?.focus();
              }}
              className="absolute right-10 top-1/2 -translate-y-1/2 rounded-full p-0.5 text-[var(--color-text-subtle)] transition-colors hover:text-[var(--color-text)]"
              title="Clear search"
            >
              <X size={12} />
            </button>
          )}
          <kbd
            className="absolute right-2.5 top-1/2 hidden -translate-y-1/2 rounded-md border bg-[var(--color-bg-elev)] px-1.5 py-0.5 font-mono text-[10px] text-[var(--color-text-subtle)] select-none md:inline-block"
            style={{ borderColor: "var(--color-border)" }}
          >
            ⌘K
          </kbd>
        </div>

        {searchOpen && search.trim().length > 0 && (
          <div
            className="absolute z-40 mt-1.5 w-[26rem] animate-scaleIn rounded-xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-pop)]"
            style={{ borderColor: "var(--color-border)" }}
          >
            <div className="max-h-96 overflow-y-auto p-1.5">
              {(() => {
                const q = search.trim().toLowerCase();
                const matchedSites = websites.filter(
                  (w) => w.name.toLowerCase().includes(q) || w.url.toLowerCase().includes(q)
                );
                const matchedArticles = contentItems
                  .filter((c) => c.title.toLowerCase().includes(q))
                  .slice(0, 6);
                if (matchedSites.length === 0 && matchedArticles.length === 0) {
                  return (
                    <div className="py-6 text-center text-xs text-[var(--color-text-muted)]">
                      No matches for “{search.trim()}”.
                    </div>
                  );
                }
                return (
                  <>
                    {matchedArticles.length > 0 && (
                      <div className="px-2.5 pb-1 pt-1.5 text-[11px] font-semibold text-[var(--color-text-subtle)]">
                        Runs
                      </div>
                    )}
                    {matchedArticles.map((c) => (
                      <button
                        key={c.id}
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => {
                          openInspector(c.id);
                          setSearchOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-lg p-2 text-left transition-colors hover:bg-[var(--color-bg-soft)]"
                      >
                        <FileText size={13} className="shrink-0 text-[var(--color-info)]" />
                        <span className="min-w-0 flex-1 truncate text-[13px] text-[var(--color-text)]">
                          {c.title}
                        </span>
                        <StatusBadge status={c.status} />
                      </button>
                    ))}
                    {matchedSites.length > 0 && (
                      <div className="px-2.5 pb-1 pt-1.5 text-[11px] font-semibold text-[var(--color-text-subtle)]">
                        Websites
                      </div>
                    )}
                    {matchedSites.map((w) => (
                      <button
                        key={w.id}
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => {
                          setPage("websites");
                          setSearchOpen(false);
                        }}
                        className="flex w-full items-center gap-2 rounded-lg p-2 text-left transition-colors hover:bg-[var(--color-bg-soft)]"
                      >
                        <Globe size={13} className="shrink-0 text-[var(--color-accent)]" />
                        <span className="min-w-0 flex-1 truncate text-[13px] text-[var(--color-text)]">
                          {w.name}
                        </span>
                        <span className="font-mono text-[10px] text-[var(--color-text-subtle)]">
                          {w.url}
                        </span>
                      </button>
                    ))}
                  </>
                );
              })()}
            </div>
          </div>
        )}
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* Live run indicator */}
        {activeRunThreadId && (
          <button
            onClick={() => openInspector(activeRunThreadId)}
            className="flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold text-[var(--color-accent-text)] transition-colors hover:brightness-105"
            style={{
              borderColor: "var(--color-accent)/40",
              background: "var(--color-accent-soft)",
            }}
            title="Watch this run's live stream"
          >
            <span className="relative flex h-2 w-2">
              <span
                className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60"
                style={{ background: "var(--color-accent)" }}
              />
              <span
                className="relative inline-flex h-2 w-2 rounded-full"
                style={{ background: "var(--color-accent)" }}
              />
            </span>
            Live
          </button>
        )}

        {/* Mobile search */}
        <button
          onClick={() => setPage("content")}
          className="rounded-lg p-2 text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] md:hidden"
          aria-label="Search"
        >
          <Search size={16} />
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setNotifOpen((o) => !o)}
            className="relative rounded-lg p-2 text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
            aria-label={`Notifications${pendingReview.length > 0 ? `, ${pendingReview.length} awaiting review` : ""}`}
          >
            <Bell size={16} />
            {pendingReview.length > 0 && (
              <span
                className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full ring-2 ring-[var(--color-bg-elev)]"
                style={{ background: "var(--color-warn)" }}
                aria-hidden="true"
              />
            )}
          </button>
          {notifOpen && (
            <>
              <div className="fixed inset-0 z-20" onClick={() => setNotifOpen(false)} />
              <div
                className="absolute right-0 z-30 mt-1.5 w-80 animate-scaleIn rounded-xl border bg-[var(--color-bg-elev)] shadow-[var(--shadow-pop)]"
                style={{ borderColor: "var(--color-border)" }}
              >
                <div
                  className="flex items-center justify-between border-b px-4 py-3"
                  style={{ borderColor: "var(--color-border)" }}
                >
                  <div className="text-sm font-semibold text-[var(--color-text)]">Notifications</div>
                  <span className="text-[11px] text-[var(--color-text-muted)]">
                    {notifications.length} new
                  </span>
                </div>
                <div className="max-h-80 overflow-y-auto p-1.5">
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-[var(--color-text-muted)]">
                      You're all caught up.
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <button
                        key={n.id}
                        onClick={() => {
                          setNotifOpen(false);
                          n.onClick();
                        }}
                        className="flex w-full items-start gap-2.5 rounded-lg p-2 text-left transition-colors hover:bg-[var(--color-bg-soft)]"
                      >
                        <span
                          className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full"
                          style={{ background: n.color }}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="line-clamp-1 text-[13px] text-[var(--color-text)]">
                            {n.title}
                          </div>
                          <div className="mt-0.5 text-[11px] text-[var(--color-text-subtle)]">
                            {n.time}
                          </div>
                        </div>
                      </button>
                    ))
                  )}
                </div>
                <div className="border-t p-2" style={{ borderColor: "var(--color-border)" }}>
                  <button
                    onClick={() => {
                      setNotifOpen(false);
                      setPage("reviews");
                    }}
                    className="w-full rounded-lg py-1.5 text-center text-[12px] font-medium text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
                  >
                    View review queue
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* SaaS Plan Badge */}
        <button
          onClick={() => setPage("billing")}
          className="hidden md:inline-flex cursor-pointer items-center gap-1.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-2.5 py-1 text-[11px] font-semibold text-blue-400 transition-colors hover:bg-blue-500/20 hover:border-blue-500/50"
          title="Manage Subscription & Quotas"
        >
          <Zap size={12} className="text-blue-400" />
          <span>Pro Tier</span>
          <span className="text-blue-400/60">·</span>
          <span className="font-mono text-[10px]">28/60</span>
        </button>

        {/* Quick Launch Button */}
        <button
          onClick={openLaunchModal}
          className="hidden sm:inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-[var(--color-accent)] px-3 py-1.5 text-xs font-semibold text-white shadow-[var(--shadow-soft)] transition-colors hover:bg-[var(--color-accent-text)] active:scale-[0.985]"
        >
          <Plus size={13} />
          <span>Launch Run</span>
        </button>

        {/* Theme toggle */}
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="rounded-lg p-2 text-[var(--color-text-muted)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)]"
          aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
        >
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        {/* Profile */}
        <Dropdown
          trigger={
            <button className="ml-1 flex cursor-pointer items-center gap-2 rounded-lg border border-transparent p-1 pr-2 transition-colors hover:border-[var(--color-border)] hover:bg-[var(--color-bg-soft)]">
              <Avatar name="Azeem Karim" size={28} />
            </button>
          }
        >
          <div className="px-2.5 py-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-[var(--color-text)]">Azeem Karim</span>
              <span className="rounded bg-blue-500/15 px-1.5 py-0.2 font-mono text-[9px] font-bold text-blue-400 border border-blue-500/30">
                PRO
              </span>
            </div>
            <div className="text-[11px] text-[var(--color-text-muted)]">azeem@dispatch.io</div>
          </div>
          <DropdownSeparator />
          <DropdownItem icon={<CreditCard size={14} />} onSelect={() => setPage("billing")}>
            Billing & Plans
          </DropdownItem>
          <DropdownItem icon={<Users size={14} />} onSelect={() => setPage("team")}>
            Team & Members
          </DropdownItem>
          <DropdownItem icon={<Key size={14} />} onSelect={() => setPage("apikeys")}>
            Developer API & Webhooks
          </DropdownItem>
          <DropdownSeparator />
          <DropdownItem icon={<Sliders size={14} />} onSelect={() => setPage("settings")}>
            Agent settings
          </DropdownItem>
          <DropdownItem icon={<Globe size={14} />} onSelect={() => setPage("websites")}>
            Target Websites
          </DropdownItem>
          <DropdownItem icon={<ExternalLink size={14} />} onSelect={() => setPage("landing")}>
            Public Landing Page
          </DropdownItem>
          <DropdownSeparator />
          <DropdownItem icon={<LogOut size={14} />} onSelect={() => setPage("login")}>
            Sign Out
          </DropdownItem>
        </Dropdown>
      </div>
    </header>
  );
}
