import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";

interface DropdownProps {
  trigger: ReactNode;
  children: ReactNode;
  align?: "start" | "end" | "center";
  className?: string;
}

export function Dropdown({ trigger, children, align = "end", className }: DropdownProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  const alignmentClass =
    align === "end" ? "right-0" : align === "start" ? "left-0" : "left-1/2 -translate-x-1/2";

  return (
    <div className="relative inline-block" ref={ref}>
      <div
        onClick={() => setOpen((o) => !o)}
        className="cursor-pointer"
        role="button"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        {trigger}
      </div>
      {open && (
        <div
          role="menu"
          className={cn(
            "absolute z-40 mt-1.5 min-w-[220px] overflow-hidden rounded-xl border bg-[var(--color-bg-elev)] p-1.5 shadow-[var(--shadow-pop)] animate-scaleIn origin-top",
            alignmentClass,
            className
          )}
          style={{ borderColor: "var(--color-border)" }}
          onClick={() => setOpen(false)}
        >
          <div className="flex flex-col gap-0.5">{children}</div>
        </div>
      )}
    </div>
  );
}

export function DropdownItem({
  icon,
  children,
  onSelect,
  danger,
  shortcut,
  badge,
  className,
}: {
  icon?: ReactNode;
  children: ReactNode;
  onSelect?: () => void;
  danger?: boolean;
  shortcut?: string;
  badge?: ReactNode;
  className?: string;
}) {
  return (
    <button
      role="menuitem"
      onClick={onSelect}
      className={cn(
        "group relative flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left text-[13px] font-medium transition-colors duration-100 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-accent)]/40",
        danger
          ? "text-[var(--color-danger)] hover:bg-[var(--color-danger-soft)]"
          : "text-[var(--color-text)] hover:bg-[var(--color-bg-soft)]",
        className
      )}
    >
      {icon && (
        <span
          className={cn(
            "flex h-6 w-6 shrink-0 items-center justify-center rounded-md transition-colors duration-100",
            danger
              ? "text-[var(--color-danger)] group-hover:bg-[var(--color-danger-soft)]"
              : "text-[var(--color-text-muted)] group-hover:bg-[var(--color-accent-soft)] group-hover:text-[var(--color-accent-text)]"
          )}
        >
          {icon}
        </span>
      )}
      <span className="flex-1 truncate">{children}</span>
      {badge && (
        <span
          className="shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-semibold"
          style={{
            background: "var(--color-bg-soft)",
            color: "var(--color-text-muted)",
          }}
        >
          {badge}
        </span>
      )}
      {shortcut && (
        <kbd
          className="shrink-0 rounded border px-1.5 py-0.5 font-mono text-[10px] text-[var(--color-text-subtle)]"
          style={{ borderColor: "var(--color-border)" }}
        >
          {shortcut}
        </kbd>
      )}
    </button>
  );
}

export function DropdownSeparator() {
  return (
    <div
      className="my-1 h-px w-full"
      style={{ background: "var(--color-border)" }}
      role="separator"
    />
  );
}

export function DropdownLabel({ children }: { children: ReactNode }) {
  return (
    <div className="px-2.5 pb-1 pt-1.5 text-[11px] font-semibold text-[var(--color-text-subtle)]">
      {children}
    </div>
  );
}
