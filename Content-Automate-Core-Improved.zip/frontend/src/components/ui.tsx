import { type ButtonHTMLAttributes, type ReactNode, forwardRef } from "react";
import { cn } from "../utils/cn";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "outline";
type Size = "sm" | "md" | "lg";

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: ReactNode;
  iconRight?: ReactNode;
  loading?: boolean;
}

const base =
  "inline-flex items-center justify-center gap-1.5 font-medium rounded-lg transition-all duration-150 select-none whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-accent)]/40 focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--color-bg)] active:scale-[0.98] cursor-pointer disabled:opacity-50 disabled:pointer-events-none disabled:cursor-not-allowed";

const variants: Record<Variant, string> = {
  primary:
    "bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent-text)] shadow-[var(--shadow-soft)] border border-transparent",
  secondary:
    "bg-[var(--color-bg-elev)] text-[var(--color-text)] border border-[var(--color-border)] hover:bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)] shadow-[var(--shadow-soft)]",
  ghost:
    "bg-transparent text-[var(--color-text-muted)] hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] border border-transparent",
  danger:
    "bg-[var(--color-danger)] text-white hover:brightness-110 shadow-[var(--shadow-soft)] border border-transparent",
  outline:
    "bg-transparent text-[var(--color-text)] border border-[var(--color-border)] hover:bg-[var(--color-bg-soft)] hover:border-[var(--color-border-strong)]",
};

const sizes: Record<Size, string> = {
  sm: "h-8 px-3 text-xs",
  md: "h-9 px-3.5 text-sm",
  lg: "h-10 px-4 text-sm",
};

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = "secondary", size = "md", icon, iconRight, className, children, loading, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      className={cn(base, variants[variant], sizes[size], className)}
      {...rest}
    >
      {icon && <span className="inline-flex">{icon}</span>}
      {children}
      {iconRight && <span className="inline-flex">{iconRight}</span>}
    </button>
  );
});
