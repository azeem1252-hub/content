import { ThemeProvider } from "./lib/theme";
import { ToastProvider } from "./lib/toast";
import { NavProvider } from "./lib/nav";
import { DataProvider } from "./lib/dataContext";
import { AppShell } from "./AppShell";
import { ErrorBoundary } from "./components/ErrorBoundary";

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <NavProvider>
          <ToastProvider>
            <DataProvider>
              <AppShell />
            </DataProvider>
          </ToastProvider>
        </NavProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}