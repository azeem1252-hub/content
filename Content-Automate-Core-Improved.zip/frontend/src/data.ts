import type { Website, Schedule, ContentItem, ActivityEvent, UpcomingItem } from "./types";

// Clean schema definitions without any hardcoded mock data.
// All application state is sourced live from the FastAPI agent backend.
export const websites: Website[] = [];
export const schedules: Schedule[] = [];
export const contentItems: ContentItem[] = [];
export const activity: ActivityEvent[] = [];
export const upcoming: UpcomingItem[] = [];

export function getWebsite(_id: string): Website | undefined {
  return undefined;
}

export function pipelineCounts() {
  return {
    Ideas: 0,
    Drafting: 0,
    "SEO Check": 0,
    Review: 0,
    Published: 0,
  };
}