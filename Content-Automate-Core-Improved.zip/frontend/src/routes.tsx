export type RouteKey =
  | "overview"
  | "websites"
  | "content"
  | "drafts"
  | "published"
  | "schedules"
  | "reviews"
  | "article"
  | "analytics"
  | "settings";