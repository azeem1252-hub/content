/**
 * Strips raw markdown syntax tokens (asterisks, hashtags, code ticks, links, blockquotes)
 * so article titles, excerpts, and feed previews render clean, polished text.
 */
export function cleanMarkdown(str?: string): string {
  if (!str) return "";
  return str
    .replace(/^#+\s+/gm, "")
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\*{1,3}([^*]+)\*{1,3}/g, "$1")
    .replace(/_{1,3}([^_]+)_{1,3}/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/<[^>]+>/g, "")
    .replace(/^>\s+/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .trim();
}
