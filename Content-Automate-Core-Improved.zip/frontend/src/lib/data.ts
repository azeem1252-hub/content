import type {
  ActivityEvent,
  ContentItem,
  PipelineStat,
  ReviewItem,
  Schedule,
  Website,
} from "./types";

export const websites: Website[] = [
  {
    id: "w1",
    name: "CloudTech Blog",
    url: "cloudtech.example.com",
    status: "connected",
    schedule: "Weekly",
    lastPublished: "Today, 9:12 AM",
    articlesPublished: 42,
    niche: "Cloud & DevOps",
  },
  {
    id: "w2",
    name: "Dev Agency",
    url: "blog.dev-agency.io",
    status: "connected",
    schedule: "3x per week",
    lastPublished: "Yesterday, 4:30 PM",
    articlesPublished: 87,
    niche: "Web Development",
  },
  {
    id: "w3",
    name: "AI Notes Weekly",
    url: "ainotes.weekly",
    status: "connected",
    schedule: "Weekly",
    lastPublished: "2 days ago",
    articlesPublished: 21,
    niche: "Artificial Intelligence",
  },
  {
    id: "w4",
    name: "Startup Growth Co.",
    url: "growth.startupco.com",
    status: "connected",
    schedule: "Bi-weekly",
    lastPublished: "3 days ago",
    articlesPublished: 15,
    niche: "Growth & Marketing",
  },
  {
    id: "w5",
    name: "Fintech Insider",
    url: "fintechinsider.com",
    status: "connected",
    schedule: "2x per week",
    lastPublished: "Today, 6:00 AM",
    articlesPublished: 64,
    niche: "Fintech",
  },
  {
    id: "w6",
    name: "Healthy Stack",
    url: "health.stack.health",
    status: "connected",
    schedule: "Weekly",
    lastPublished: "4 days ago",
    articlesPublished: 33,
    niche: "Health Tech",
  },
  {
    id: "w7",
    name: "Remote Work Daily",
    url: "remotework.daily",
    status: "syncing",
    schedule: "Daily",
    lastPublished: "Yesterday",
    articlesPublished: 109,
    niche: "Future of Work",
  },
  {
    id: "w8",
    name: "Indie Hacker Journal",
    url: "journal.indiehacker.dev",
    status: "connected",
    schedule: "Weekly",
    lastPublished: "1 week ago",
    articlesPublished: 12,
    niche: "Bootstrapping",
  },
  {
    id: "w9",
    name: "Privacy Watch",
    url: "privacywatch.org",
    status: "disconnected",
    schedule: "Monthly",
    lastPublished: "3 weeks ago",
    articlesPublished: 6,
    niche: "Privacy & Security",
  },
];

export const schedules: Schedule[] = [
  {
    id: "s1",
    name: "Weekly Cloud Briefing",
    websiteId: "w1",
    frequency: "Every Monday",
    time: "8:00 AM",
    nextRun: "Monday, 8:00 AM",
    active: true,
    topics: ["Cloud", "DevOps", "Kubernetes"],
    cronAdvanced: "0 8 * * 1",
  },
  {
    id: "s2",
    name: "Web Dev Deep Dives",
    websiteId: "w2",
    frequency: "Tue, Thu, Sat",
    time: "10:00 AM",
    nextRun: "Tuesday, 10:00 AM",
    active: true,
    topics: ["Next.js", "Performance", "Architecture"],
    cronAdvanced: "0 10 * * 2,4,6",
  },
  {
    id: "s3",
    name: "AI Weekly Roundup",
    websiteId: "w3",
    frequency: "Every Wednesday",
    time: "9:00 AM",
    nextRun: "Wednesday, 9:00 AM",
    active: true,
    topics: ["LLMs", "Agents", "Tools"],
    cronAdvanced: "0 9 * * 3",
  },
  {
    id: "s4",
    name: "Growth Playbook",
    websiteId: "w4",
    frequency: "Every other Friday",
    time: "11:00 AM",
    nextRun: "Friday, 11:00 AM",
    active: true,
    topics: ["Growth", "Funnels", "PMF"],
    cronAdvanced: "0 11 * * 5/2",
  },
  {
    id: "s5",
    name: "Fintech Pulse",
    websiteId: "w5",
    frequency: "Mon & Thu",
    time: "6:00 AM",
    nextRun: "Tomorrow, 6:00 AM",
    active: true,
    topics: ["Payments", "Banking", "Crypto"],
    cronAdvanced: "0 6 * * 1,4",
  },
  {
    id: "s6",
    name: "Health Tech Mondays",
    websiteId: "w6",
    frequency: "Every Monday",
    time: "1:00 PM",
    nextRun: "Monday, 1:00 PM",
    active: true,
    topics: ["Digital Health", "Wearables"],
    cronAdvanced: "0 13 * * 1",
  },
  {
    id: "s7",
    name: "Daily Remote Digest",
    websiteId: "w7",
    frequency: "Daily",
    time: "7:00 AM",
    nextRun: "Tomorrow, 7:00 AM",
    active: true,
    topics: ["Remote", "Productivity", "Async"],
    cronAdvanced: "0 7 * * *",
  },
  {
    id: "s8",
    name: "Indie Build Logs",
    websiteId: "w8",
    frequency: "Every Sunday",
    time: "4:00 PM",
    nextRun: "Sunday, 4:00 PM",
    active: false,
    topics: ["Bootstrapping", "MRR", "Launches"],
    cronAdvanced: "0 16 * * 0",
  },
];

export const content: ContentItem[] = [
  {
    id: "c1",
    title: "10 Cloud Security Trends for 2026",
    websiteId: "w1",
    status: "awaiting-approval",
    createdAt: "2 hours ago",
    seo: 94,
    excerpt:
      "Cloud security is shifting toward zero-trust architectures, AI-driven threat detection, and confidential computing. Here's what teams should prepare for next year.",
    targetKeyword: "cloud security trends",
    metaDescription:
      "A practical look at the ten cloud security shifts that will define 2026, with examples and adoption tips for engineering teams.",
    aiNotes:
      "Draft emphasizes zero-trust adoption, post-quantum crypto readiness, and SaaS posture management. Suggested adding two original diagrams.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c2",
    title: "Next.js Performance Checklist for Production",
    websiteId: "w2",
    status: "awaiting-approval",
    createdAt: "5 hours ago",
    seo: 96,
    excerpt:
      "A focused checklist of high-leverage Next.js performance optimizations — from caching strategy to image loading and edge rendering.",
    targetKeyword: "next.js performance",
    metaDescription:
      "The Next.js performance checklist we use before every production deploy: caching, images, fonts, streaming and edge rendering.",
    aiNotes:
      "SEO score is high. Structure is scannable. Pull quote placed near the top for shareability.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c3",
    title: "How AI Agents Are Reshaping Developer Workflows",
    websiteId: "w3",
    status: "awaiting-approval",
    createdAt: "Yesterday",
    seo: 88,
    excerpt:
      "Developer workflows are quietly being rewritten by autonomous AI agents. We look at where they actually help — and where they don't.",
    targetKeyword: "ai agents developers",
    metaDescription:
      "An honest look at how AI agents are reshaping developer workflows in 2026, with concrete patterns and pitfalls.",
    aiNotes:
      "Consider tightening the section on code review agents. Currently 12% over target length.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c4",
    title: "Serverless Architecture Guide",
    websiteId: "w1",
    status: "scheduled",
    createdAt: "Today",
    seo: 91,
    scheduledAt: "Tomorrow, 8:00 AM",
    excerpt:
      "When serverless makes sense, when it doesn't, and how to design systems that survive the cold start.",
    targetKeyword: "serverless architecture",
    metaDescription:
      "A practitioner's guide to serverless architecture: tradeoffs, patterns and the mistakes we keep making.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c5",
    title: "Edge Computing Explained",
    websiteId: "w3",
    status: "draft",
    createdAt: "3 hours ago",
    seo: 72,
    excerpt:
      "Edge computing moves computation closer to users. We unpack what's hype, what's real, and where it actually wins.",
    targetKeyword: "edge computing",
    metaDescription:
      "What edge computing really is, where it helps, and where it's just marketing.",
    pipeline: ["ideas", "drafting"],
  },
  {
    id: "c6",
    title: "Building Resilient Payment Systems",
    websiteId: "w5",
    status: "seo-review",
    createdAt: "Today",
    seo: 86,
    excerpt:
      "Idempotency, retries and observability — the boring fundamentals that decide whether a payment system survives Black Friday.",
    targetKeyword: "resilient payments",
    metaDescription:
      "The fundamentals of building resilient payment systems, written for engineering teams.",
    pipeline: ["ideas", "drafting", "seo-check"],
  },
  {
    id: "c7",
    title: "Next.js Caching Guide",
    websiteId: "w2",
    status: "published",
    createdAt: "Yesterday",
    seo: 92,
    excerpt:
      "A complete walkthrough of caching in the Next.js App Router: request memoization, data cache, full route cache and router cache.",
    targetKeyword: "next.js caching",
    metaDescription:
      "Master every layer of caching in the Next.js App Router with this complete guide.",
    pipeline: ["ideas", "drafting", "seo-check", "review", "published"],
  },
  {
    id: "c8",
    title: "Cloud Security Trends 2026",
    websiteId: "w1",
    status: "published",
    createdAt: "1 hour ago",
    seo: 94,
    excerpt:
      "Cloud security is shifting toward zero-trust architectures, AI-driven threat detection and confidential computing.",
    targetKeyword: "cloud security trends",
    metaDescription:
      "Ten cloud security shifts that will define 2026 — with examples and adoption tips.",
    pipeline: ["ideas", "drafting", "seo-check", "review", "published"],
  },
  {
    id: "c9",
    title: "SaaS Pricing Page Teardown",
    websiteId: "w4",
    status: "scheduled",
    createdAt: "Today",
    seo: 83,
    scheduledAt: "Wednesday, 10:00 AM",
    excerpt:
      "We audited fifty SaaS pricing pages to find the patterns that actually convert.",
    targetKeyword: "saas pricing page",
    metaDescription:
      "What the highest-converting SaaS pricing pages have in common, with annotated examples.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c10",
    title: "Async Standups That Don't Waste Time",
    websiteId: "w7",
    status: "scheduled",
    createdAt: "Today",
    seo: 80,
    scheduledAt: "Tomorrow, 7:00 AM",
    excerpt:
      "A practical guide to async standups: formats, tools, and the failure modes we've seen.",
    targetKeyword: "async standups",
    metaDescription:
      "Async standups that don't waste time — formats, tools and pitfalls.",
    pipeline: ["ideas", "drafting", "seo-check", "review"],
  },
  {
    id: "c11",
    title: "Indie Founder Year One — Honest Numbers",
    websiteId: "w8",
    status: "draft",
    createdAt: "Yesterday",
    seo: 68,
    excerpt:
      "Real revenue, churn and time allocation from year one of bootstrapping a SaaS product.",
    targetKeyword: "indie founder year one",
    metaDescription:
      "Honest numbers from year one of bootstrapping — MRR, churn, time and lessons.",
    pipeline: ["ideas"],
  },
  {
    id: "c12",
    title: "Designing for Patient Trust",
    websiteId: "w6",
    status: "failed",
    createdAt: "Yesterday",
    seo: 71,
    excerpt:
      "How health-tech products earn — and lose — patient trust through interface design.",
    targetKeyword: "patient trust design",
    metaDescription:
      "How health-tech interfaces build or break patient trust, with practical patterns.",
    pipeline: ["ideas", "drafting", "seo-check"],
  },
];

export const reviewItems: ReviewItem[] = content
  .filter((c) => c.status === "awaiting-approval")
  .map((c) => ({
    id: `r-${c.id}`,
    contentId: c.id,
    title: c.title,
    websiteId: c.websiteId,
    excerpt: c.excerpt,
    seo: c.seo,
    summary: c.aiNotes ?? "Draft is ready for your review.",
    createdAt: c.createdAt,
    source: c.id === "c2" ? "slack" : "inbox",
  }));

export const activity: ActivityEvent[] = [
  {
    id: "a1",
    type: "approved",
    title: "Next.js Caching Guide",
    detail: "Approved via Slack",
    at: "2 min ago",
    websiteId: "w2",
  },
  {
    id: "a2",
    type: "published",
    title: "Cloud Security Trends",
    detail: "Published to CloudTech Blog",
    at: "1 hour ago",
    websiteId: "w1",
  },
  {
    id: "a3",
    type: "draft",
    title: "Edge Computing Explained",
    detail: "Draft generated",
    at: "3 hours ago",
    websiteId: "w3",
  },
  {
    id: "a4",
    type: "schedule",
    title: "Daily Remote Digest",
    detail: "Schedule resumed",
    at: "Yesterday",
    websiteId: "w7",
  },
  {
    id: "a5",
    type: "rejected",
    title: "5 Pricing Mistakes",
    detail: "Sent back for revision",
    at: "Yesterday",
    websiteId: "w4",
  },
  {
    id: "a6",
    type: "connected",
    title: "Privacy Watch",
    detail: "Website connected",
    at: "2 days ago",
    websiteId: "w9",
  },
];

export const pipelineStats: PipelineStat[] = [
  { stage: "ideas", label: "Ideas", count: 12 },
  { stage: "drafting", label: "Drafting", count: 5 },
  { stage: "seo-check", label: "SEO Check", count: 3 },
  { stage: "review", label: "Review", count: 2 },
  { stage: "published", label: "Published", count: 24 },
];

export const overviewMetrics = {
  connectedWebsites: 9,
  scheduled: 8,
  needsReview: 3,
  published: 24,
};

export const upcoming = [
  {
    id: "u1",
    title: "Serverless Architecture Guide",
    websiteId: "w1",
    when: "Tomorrow",
    time: "8:00 AM",
    kind: "AI-generated draft",
  },
  {
    id: "u2",
    title: "SaaS Pricing Page Teardown",
    websiteId: "w4",
    when: "Wednesday",
    time: "10:00 AM",
    kind: "Scheduled",
  },
  {
    id: "u3",
    title: "Async Standups That Don't Waste Time",
    websiteId: "w7",
    when: "Tomorrow",
    time: "7:00 AM",
    kind: "Scheduled",
  },
  {
    id: "u4",
    title: "Fintech Pulse Roundup",
    websiteId: "w5",
    when: "Thursday",
    time: "6:00 AM",
    kind: "Scheduled",
  },
];

export const analyticsSeries = {
  published: [
    { label: "Mon", value: 4 },
    { label: "Tue", value: 6 },
    { label: "Wed", value: 3 },
    { label: "Thu", value: 8 },
    { label: "Fri", value: 5 },
    { label: "Sat", value: 2 },
    { label: "Sun", value: 1 },
  ],
  approvalRate: [
    { label: "W1", value: 82 },
    { label: "W2", value: 88 },
    { label: "W3", value: 91 },
    { label: "W4", value: 94 },
    { label: "W5", value: 92 },
    { label: "W6", value: 96 },
    { label: "W7", value: 95 },
  ],
};

export const analyticsKpis = [
  { label: "Articles Published", value: "24", delta: "+8 vs last week" },
  { label: "Approval Rate", value: "95%", delta: "+3% vs last month" },
  { label: "Average SEO Score", value: "89", delta: "+2 vs last month" },
  { label: "Publishing Frequency", value: "3.4 / day", delta: "Steady" },
];

export const getWebsiteById = (id: string) => websites.find((w) => w.id === id);
export const getContentById = (id: string) => content.find((c) => c.id === id);
export const getScheduleById = (id: string) =>
  schedules.find((s) => s.id === id);