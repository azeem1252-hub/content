import { createContext, useContext } from "react";
import { useReducedMotion } from "framer-motion";

/** Automated browsers (screenshots, audits) never scroll the way people do. */
export const IS_AUTOMATED = typeof navigator !== "undefined" && navigator.webdriver === true;

/** Components inside this provider keep animating even in automated browsers (e.g. the hero demo). */
export const LiveMotion = createContext(false);

/**
 * True when motion should collapse to final states:
 * people who prefer reduced motion, and automated captures that would otherwise see empty charts.
 */
export function useCalm() {
  const reduce = useReducedMotion();
  const live = useContext(LiveMotion);
  return !!reduce || (IS_AUTOMATED && !live);
}
