import { ContentItem, Website } from "../types";

/**
 * Builds standard Google Rich Results Schema.org JSON-LD
 * with TechArticle, Author Entity, Publisher, and BreadcrumbList.
 */
export function generateArticleSchemaJson(
  article: ContentItem,
  website?: Website
): { jsonString: string; rawObject: Record<string, any> } {
  const baseUrl = (website?.url || "https://example.com").replace(/\/$/, "");
  const slug = article.slug || "article-slug";
  const postUrl = `${baseUrl}/posts/${slug}`;
  const heroUrl = article.heroImageUrl
    ? (article.heroImageUrl.startsWith("http") ? article.heroImageUrl : `${baseUrl}${article.heroImageUrl}`)
    : `${baseUrl}/uploads/default-hero.webp`;

  const publishDate = article.createdAtDate instanceof Date
    ? article.createdAtDate.toISOString()
    : new Date().toISOString();

  const words = article.draft ? article.draft.trim().split(/\s+/).filter(Boolean).length : 1200;

  const schemaGraph = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "TechArticle",
        "@id": `${postUrl}#article`,
        "isPartOf": {
          "@type": "WebSite",
          "@id": `${baseUrl}/#website`,
          "name": website?.name || "Editorial Authority",
          "url": baseUrl,
        },
        "headline": article.title,
        "description": article.metaDescription || article.excerpt,
        "inLanguage": "en-US",
        "mainEntityOfPage": postUrl,
        "datePublished": publishDate,
        "dateModified": publishDate,
        "wordCount": words,
        "keywords": [article.targetKeyword, ...(article.discoveredKeywords || [])].filter(Boolean),
        "author": {
          "@type": "Person",
          "name": "Staff Technology Writer & Systems Architect",
          "jobTitle": "Lead Systems Architect",
          "knowsAbout": [
            "Game Physics Engines",
            "Decima Engine",
            "Autonomous Agents",
            "Software Architecture",
          ],
        },
        "publisher": {
          "@type": "Organization",
          "name": website?.name || "Editorial Authority",
          "url": baseUrl,
        },
        "image": {
          "@type": "ImageObject",
          "url": heroUrl,
        },
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${postUrl}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": baseUrl,
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Articles",
            "item": `${baseUrl}/posts`,
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": article.title,
            "item": postUrl,
          },
        ],
      },
    ],
  };

  return {
    jsonString: JSON.stringify(schemaGraph, null, 2),
    rawObject: schemaGraph,
  };
}
