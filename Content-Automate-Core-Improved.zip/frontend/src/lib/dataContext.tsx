import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from "react";
import type { Website, Schedule, ContentItem, DashboardKpis, ContentStatus, ActivityEvent, UpcomingItem } from "../types";
import { api } from "./api";

// Fast structural comparison helper to avoid re-rendering entire app if payload didn't change
function hasChanged(prev: any, next: any): boolean {
  if (prev === next) return false;
  if (!prev || !next) return true;
  try {
    return JSON.stringify(prev) !== JSON.stringify(next);
  } catch {
    return true;
  }
}

interface DataContextType {
  websites: Website[];
  schedules: Schedule[];
  contentItems: ContentItem[];
  kpis: DashboardKpis;
  upcoming: UpcomingItem[];
  activity: ActivityEvent[];
  isLoading: boolean;
  refreshAll: () => Promise<void>;
  getWebsite: (id: string) => Website | undefined;
  pipelineCounts: Record<string, number>;
  // Actions
  triggerPipelineRun: (payload: {
    topic?: string;
    website_id?: string;
    keywords?: string[];
    secondary_keywords?: string[];
    target_audience?: string;
    content_format?: string;
    auto_approve?: boolean;
    brand_voice?: string;
    article_depth?: string;
    niche?: string;
    inject_evidence?: boolean;
    enable_diagrams?: boolean;
    enable_tables?: boolean;
    enable_faqs?: boolean;
    enable_takeaways?: boolean;
    enable_answer_blocks?: boolean;
    enable_citations?: boolean;
    enable_hero_image?: boolean;
  }) => Promise<any>;
  deleteContentItem: (threadId: string) => Promise<void>;
  reviewArticle: (
    threadId: string,
    action: "approve" | "request_changes" | "reject",
    feedback?: string
  ) => Promise<any>;
  saveArticleDraft: (threadId: string, draft: string, title?: string) => Promise<ContentItem>;
  toggleScheduleStatus: (id: string) => Promise<void>;
  escalateScheduleNow: (id: string) => Promise<any>;
  deleteScheduleItem: (id: string) => Promise<void>;
  createScheduleItem: (payload: any) => Promise<Schedule>;
  createWebsiteItem: (payload: any) => Promise<Website>;
  updateWebsiteItem: (id: string, payload: any) => Promise<Website>;
  deleteWebsiteItem: (id: string) => Promise<void>;
  testWebsiteConnection: (id: string) => Promise<any>;
  testWebsiteSlackCard: (id: string) => Promise<any>;
}

const DataContext = createContext<DataContextType | null>(null);

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [websites, setWebsites] = useState<Website[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [kpis, setKpis] = useState<DashboardKpis>({});
  const [isLoading, setIsLoading] = useState(true);

  const refreshAll = useCallback(async () => {
    try {
      const [sitesRes, schedsRes, runsRes, kpisRes] = await Promise.allSettled([
        api.getWebsites(),
        api.getSchedules(),
        api.getRuns(),
        api.getKpis(),
      ]);

      if (sitesRes.status === "fulfilled") {
        setWebsites((prev) => (hasChanged(prev, sitesRes.value) ? sitesRes.value : prev));
      }
      if (schedsRes.status === "fulfilled") {
        setSchedules((prev) => (hasChanged(prev, schedsRes.value) ? schedsRes.value : prev));
      }
      if (runsRes.status === "fulfilled") {
        setContentItems((prev) => (hasChanged(prev, runsRes.value) ? runsRes.value : prev));
      }
      if (kpisRes.status === "fulfilled") {
        setKpis((prev) => (hasChanged(prev, kpisRes.value) ? kpisRes.value : prev));
      }
    } catch (err) {
      console.error("Error refreshing agent data:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Visibility-aware smart polling: pauses when browser tab is inactive, resumes immediately when tab focuses
  useEffect(() => {
    refreshAll();
    const intervalMs = 6000;
    let timer: any = null;

    const startTimer = () => {
      if (timer) clearInterval(timer);
      timer = setInterval(() => {
        if (!document.hidden) {
          refreshAll();
        }
      }, intervalMs);
    };

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        refreshAll();
        startTimer();
      } else {
        if (timer) clearInterval(timer);
      }
    };

    startTimer();
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("focus", refreshAll);

    return () => {
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("focus", refreshAll);
    };
  }, [refreshAll]);

  const getWebsite = useCallback(
    (id: string): Website | undefined => {
      return websites.find((w) => w.id === id);
    },
    [websites]
  );

  const pipelineCounts = useMemo(
    () => ({
      Ideas: contentItems.filter((c) => c.status === "Idea").length,
      Drafting: contentItems.filter((c) => c.status === "Drafting").length,
      "SEO Check": contentItems.filter((c) => c.status === "SEO Check").length,
      Review: contentItems.filter((c) => c.status === "Awaiting Approval").length,
      Published: contentItems.filter((c) => c.status === "Published").length,
    }),
    [contentItems]
  );

  // Derive real upcoming events from active schedules
  const upcoming: UpcomingItem[] = useMemo(
    () =>
      schedules
        .filter((s) => s.active)
        .map((s) => ({
          id: s.id,
          when: s.nextRun || "Upcoming",
          time: s.time || "08:00",
          title: s.name,
          websiteId: s.websiteId,
          type: "Scheduled" as const,
        })),
    [schedules]
  );

  // Derive real activity log from recent runs
  const activity: ActivityEvent[] = useMemo(
    () =>
      contentItems.slice(0, 8).map((item) => {
        let type: ActivityEvent["type"] = "draft";
        if (item.status === "Published") type = "published";
        else if (item.status === "Awaiting Approval") type = "approved";
        else if (item.status === "Failed") type = "rejected";
        return {
          id: item.id,
          type,
          title: item.title,
          meta: item.targetKeyword,
          when: item.createdAt,
          whenDate: item.createdAtDate,
        };
      }),
    [contentItems]
  );

  const triggerPipelineRun = async (payload: any) => {
    const res = await api.startRun(payload);
    await refreshAll();
    return res;
  };

  const reviewArticle = async (
    threadId: string,
    action: "approve" | "request_changes" | "reject",
    feedback?: string
  ) => {
    const actionKey =
      action === "approve" ? "approved" : action === "request_changes" ? "request_changes" : "reject";
    const res = await api.reviewRun(threadId, actionKey, feedback);
    const resStatus = String(res?.status || "").toLowerCase();

    // The backend can legally answer 200 with a no-op (busy lock, terminal run,
    // revision cap). Surface those honestly instead of toasting fake success.
    if (resStatus === "busy") {
      throw new Error(res.message || "Another review action is already running for this article.");
    }
    if (resStatus === "revision_cap_reached") {
      await refreshAll();
      throw new Error("Revision cap reached: this run was closed without publishing.");
    }
    if ((resStatus === "completed" || resStatus === "rejected") && action !== "reject") {
      await refreshAll();
      throw new Error(res.message || `Run is already ${resStatus}; action ignored.`);
    }
    if (resStatus === "error") {
      await refreshAll();
      throw new Error(res.error || "Pipeline resume failed. The article stays in review for a retry.");
    }

    if (resStatus === "accepted" || resStatus === "approved" || resStatus === "changes_requested") {
      setContentItems((items) =>
        items.map((item) => {
          if (item.id === threadId) {
            // Optimistically reflect the in-flight transition; the poller and
            // live SSE stream settle the real final status.
            const newStatus: ContentStatus =
              action === "request_changes" ? "Drafting" : action === "reject" ? "Failed" : item.status;
            return {
              ...item,
              status: newStatus,
              pipeline: {
                ...item.pipeline,
                review: true,
              },
            };
          }
          return item;
        })
      );
    }
    await refreshAll();
    return res;
  };

  const saveArticleDraft = async (threadId: string, draft: string, title?: string) => {
    const updated = await api.saveDraft(threadId, draft, title);
    setContentItems((items) =>
      items.map((item) => (item.id === threadId ? updated : item))
    );
    await refreshAll();
    return updated;
  };

  const toggleScheduleStatus = async (id: string) => {
    await api.toggleSchedule(id);
    setSchedules((arr) =>
      arr.map((s) => (s.id === id ? { ...s, active: !s.active } : s))
    );
    await refreshAll();
  };

  const escalateScheduleNow = async (id: string) => {
    const res = await api.escalateSchedule(id);
    await refreshAll();
    return res;
  };

  const deleteScheduleItem = async (id: string) => {
    await api.deleteSchedule(id);
    setSchedules((arr) => arr.filter((s) => s.id !== id));
  };

  const createScheduleItem = async (payload: any) => {
    const created = await api.createSchedule(payload);
    await refreshAll();
    return created;
  };

  const createWebsiteItem = async (payload: any) => {
    const created = await api.createWebsite(payload);
    await refreshAll();
    return created;
  };

  const updateWebsiteItem = async (id: string, payload: any) => {
    const updated = await api.updateWebsite(id, payload);
    await refreshAll();
    return updated;
  };

  const deleteWebsiteItem = async (id: string) => {
    await api.deleteWebsite(id);
    setWebsites((arr) => arr.filter((w) => w.id !== id));
  };

  const testWebsiteConnection = async (id: string) => {
    return api.testWebsite(id);
  };

  const testWebsiteSlackCard = async (id: string) => {
    return api.testWebsiteSlack(id);
  };

  const deleteContentItem = async (threadId: string) => {
    await api.deleteRun(threadId);
    await refreshAll();
  };

  return (
    <DataContext.Provider
      value={{
        websites,
        schedules,
        contentItems,
        kpis,
        upcoming,
        activity,
        isLoading,
        refreshAll,
        getWebsite,
        pipelineCounts,
        triggerPipelineRun,
        reviewArticle,
        saveArticleDraft,
        toggleScheduleStatus,
        escalateScheduleNow,
        deleteScheduleItem,
        createScheduleItem,
        createWebsiteItem,
        updateWebsiteItem,
        deleteWebsiteItem,
        testWebsiteConnection,
        testWebsiteSlackCard,
        deleteContentItem,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function usePipelineData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("usePipelineData must be used within DataProvider");
  return ctx;
}
