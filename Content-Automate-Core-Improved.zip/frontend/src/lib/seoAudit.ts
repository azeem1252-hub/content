/**
 * Real-Time On-Page SEO Quality & Keyword Salience Engine
 * Analyzes keyword density, placement, heading hierarchy, readability,
 * and synchronizes with Pillar A5 quality linter standards:
 * - AI clichés / banned phrases detection
 * - Unsourced superlatives detection
 * - Preamble fluff detection
 * - Unsourced empirical statistics
 */

export interface BannedPhraseDetection {
  phrase: string;
  count: number;
}

export interface SeoAuditReport {
  keyword: string;
  wordCount: number;
  readingTimeMin: number;
  keywordCount: number;
  keywordDensity: number;
  keywordDensityStatus: "optimal" | "light" | "under" | "over";
  keywordInTitle: boolean;
  keywordInMeta: boolean;
  keywordInFirst100: boolean;
  keywordInH2: boolean;
  metaLength: number;
  metaLengthStatus: "optimal" | "short" | "long";
  h1Count: number;
  h2Count: number;
  h3Count: number;
  fleschScore: number;
  readingGradeLevel: string;
  overallHealthScore: number;
  recommendations: string[];
  // Synchronized Pillar A5 checks:
  bannedPhrasesDetected: BannedPhraseDetection[];
  unsourcedSuperlatives: string[];
  unsourcedStatsCount: number;
  preambleFluffCount: number;
}

export const DEFAULT_BANNED_PHRASES = [
  "delve into",
  "delving into",
  "in today's fast-paced world",
  "in today's digital world",
  "in the modern era",
  "tapestry",
  "testament to",
  "beacon",
  "game-changer",
  "game changer",
  "unlock the potential",
  "harness the power",
  "it is important to note that",
  "it's worth noting that",
  "dive deep",
  "dive in",
  "a myriad of",
  "in conclusion",
  "to sum up",
  "needless to say",
  "it goes without saying",
  "revolutionize the way",
  "at the end of the day",
];

export const UNSOURCED_SUPERLATIVES = [
  "the best",
  "the fastest",
  "the most powerful",
  "the most popular",
  "the #1",
  "number one",
  "unrivaled",
  "unmatched",
  "unparalleled",
  "industry-leading",
  "world's first",
  "revolutionary",
  "groundbreaking",
];

const PREAMBLE_FLUFF_REGEXES = [
  /^in\s+(?:today['’]s|the)\s+(?:[a-z-]+\s+)*digital\s+world/i,
  /^in\s+(?:today['’]s|the)\s+(?:[a-z-]+\s+)*(?:landscape|era|society)/i,
  /^it\s+is\s+(?:important|crucial|essential|worth\s+noting)\s+to\s+(?:note|understand|mention)/i,
  /\bdive\s+(?:deep|in)\b/i,
  /^when\s+it\s+comes\s+to\s+[a-z\s]+,\s+one\s+might\s+wonder/i,
  /^as\s+we\s+navigate\s+the\s+complexities\s+of/i,
];

function countSyllables(word: string): number {
  const clean = word.toLowerCase().replace(/[^a-z]/g, "");
  if (!clean || clean.length <= 3) return 1;
  const matches = clean.match(/[aeiouy]{1,2}/g);
  let count = matches ? matches.length : 1;
  if (clean.endsWith("e") && !clean.endsWith("le")) {
    count = Math.max(1, count - 1);
  }
  return Math.max(1, count);
}

export function auditOnPageSeo(
  draft: string = "",
  title: string = "",
  targetKeyword: string = "",
  metaDescription: string = ""
): SeoAuditReport {
  const cleanDraft = draft
    .replace(/^```[\s\S]*?```/gm, "")
    .replace(/^---[\s\S]*?---/m, "")
    .trim();

  const words = cleanDraft.split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const readingTimeMin = Math.max(1, Math.round(wordCount / 200));

  const kw = targetKeyword.trim().toLowerCase();
  const kwWords = kw.split(/\s+/).filter(Boolean).length || 1;

  // Occurrences in text
  let keywordCount = 0;
  if (kw) {
    const escapedKw = kw.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
    const matches = cleanDraft.match(new RegExp(`\\b${escapedKw}\\b`, "gi"));
    keywordCount = matches ? matches.length : 0;
  }

  // Keyword Density
  const keywordDensity = wordCount > 0 ? Number(((keywordCount * kwWords) / wordCount * 100).toFixed(1)) : 0;
  let keywordDensityStatus: "optimal" | "light" | "under" | "over" = "optimal";
  if (keywordDensity < 0.5) keywordDensityStatus = "under";
  else if (keywordDensity < 1.0) keywordDensityStatus = "light";
  else if (keywordDensity > 2.5) keywordDensityStatus = "over";
  else keywordDensityStatus = "optimal";

  // Placements
  const cleanTitle = title.toLowerCase();
  const keywordInTitle = kw ? cleanTitle.includes(kw) : false;

  const cleanMeta = metaDescription.toLowerCase();
  const keywordInMeta = kw ? cleanMeta.includes(kw) : false;
  const metaLength = metaDescription.length;
  let metaLengthStatus: "optimal" | "short" | "long" = "optimal";
  if (metaLength < 110) metaLengthStatus = "short";
  else if (metaLength > 165) metaLengthStatus = "long";
  else metaLengthStatus = "optimal";

  // First 100 words check
  const first100 = words.slice(0, 100).join(" ").toLowerCase();
  const keywordInFirst100 = kw ? first100.includes(kw) : false;

  // Headings analysis & Preamble fluff detection
  const lines = cleanDraft.split(/\r?\n/);
  let h1Count = 0;
  let h2Count = 0;
  let h3Count = 0;
  let keywordInH2 = false;
  let preambleFluffCount = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith("# ")) h1Count++;
    else if (line.startsWith("## ")) {
      h2Count++;
      if (kw && line.toLowerCase().includes(kw)) {
        keywordInH2 = true;
      }
      // Check first following non-empty paragraph for preamble fluff
      for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
        const nextLine = lines[j].trim();
        if (nextLine && !nextLine.startsWith("#")) {
          if (PREAMBLE_FLUFF_REGEXES.some((rx) => rx.test(nextLine))) {
            preambleFluffCount++;
          }
          break;
        }
      }
    } else if (line.startsWith("### ")) {
      h3Count++;
    }
  }

  // Banned Phrases / AI Clichés
  const lowerDraft = cleanDraft.toLowerCase();
  const bannedPhrasesDetected: BannedPhraseDetection[] = [];
  for (const phrase of DEFAULT_BANNED_PHRASES) {
    const escaped = phrase.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
    const m = lowerDraft.match(new RegExp(`\\b${escaped}\\b`, "gi"));
    if (m && m.length > 0) {
      bannedPhrasesDetected.push({ phrase, count: m.length });
    }
  }

  // Unsourced Superlatives
  const unsourcedSuperlatives: string[] = [];
  for (const sup of UNSOURCED_SUPERLATIVES) {
    const escaped = sup.replace(/[-[\]/{}()*+?.\\^$|]/g, "\\$&");
    const m = lowerDraft.match(new RegExp(`\\b${escaped}\\b`, "gi"));
    if (m && m.length > 0) {
      unsourcedSuperlatives.push(sup);
    }
  }

  // Sourced vs Unsourced Statistics
  const sentences = cleanDraft.split(/[.!?]+/).map((s) => s.trim()).filter((s) => s.length > 3);
  const statRegex = /(\b\d+(?:\.\d+)?%|\$\d+(?:\.\d+)?[kmb]?|\b\d+(?:\.\d+)?\s*(?:ms|seconds|minutes|hours|GB|TB|users|TPS|FPS|x)\b)/i;
  const attributionRegex = /(?:according\s+to|source:|cited\s+by|reported\s+by|study\s+by|data\s+from|per|benchmark|\[[^\]]+\]\(https?:\/\/|\(\s*https?:\/\/)/i;
  let unsourcedStatsCount = 0;

  for (const s of sentences) {
    if (statRegex.test(s) && !attributionRegex.test(s)) {
      unsourcedStatsCount++;
    }
  }

  // Flesch Reading Ease
  const sentenceCount = Math.max(1, sentences.length);
  const totalSyllables = words.reduce((acc, w) => acc + countSyllables(w), 0);

  const avgWordsPerSentence = wordCount / sentenceCount;
  const avgSyllablesPerWord = wordCount > 0 ? totalSyllables / wordCount : 1.4;
  const rawFlesch = 206.835 - 1.015 * avgWordsPerSentence - 84.6 * avgSyllablesPerWord;
  const fleschScore = Math.max(10, Math.min(100, Math.round(rawFlesch)));

  let readingGradeLevel = "Standard Editorial (8th-9th Grade)";
  if (fleschScore >= 70) readingGradeLevel = "Accessible & Engaging (7th Grade)";
  else if (fleschScore >= 60) readingGradeLevel = "Standard Editorial (8th-9th Grade)";
  else if (fleschScore >= 50) readingGradeLevel = "Authoritative Longform (10th-12th Grade)";
  else readingGradeLevel = "Technical & Academic (College Level)";

  // Compute overall health score
  let score = 50;
  if (keywordInTitle) score += 15;
  if (keywordInMeta) score += 10;
  if (keywordInFirst100) score += 10;
  if (keywordInH2) score += 8;
  if (keywordDensityStatus === "optimal") score += 7;
  else if (keywordDensityStatus === "light") score += 4;
  if (metaLengthStatus === "optimal") score += 5;
  if (h2Count >= 3) score += 5;

  // Penalties for AI clichés & fluff
  if (bannedPhrasesDetected.length > 0) {
    score -= Math.min(15, bannedPhrasesDetected.length * 3);
  }
  if (unsourcedSuperlatives.length > 0) {
    score -= Math.min(10, unsourcedSuperlatives.length * 2);
  }
  if (preambleFluffCount > 0) {
    score -= Math.min(10, preambleFluffCount * 3);
  }
  const overallHealthScore = Math.max(10, Math.min(100, score));

  // Recommendations
  const recommendations: string[] = [];
  if (!keywordInTitle) recommendations.push(`Include target keyword "${targetKeyword}" in the article H1/title.`);
  if (!keywordInMeta) recommendations.push(`Include "${targetKeyword}" in the Google meta description.`);
  if (metaLengthStatus === "short") recommendations.push(`Expand meta description to 120-160 characters (currently ${metaLength} chars).`);
  else if (metaLengthStatus === "long") recommendations.push(`Shorten meta description to avoid SERP truncation (currently ${metaLength} chars).`);
  if (!keywordInFirst100) recommendations.push(`Mention target keyword in the first 100 words of the opening hook.`);
  if (!keywordInH2) recommendations.push(`Include target keyword or an LSI variation in at least one H2 subheading.`);
  if (keywordDensityStatus === "under") recommendations.push(`Keyword density is low (${keywordDensity}%). Consider weaving "${targetKeyword}" naturally into 1-2 more paragraphs.`);
  if (keywordDensityStatus === "over") recommendations.push(`Keyword density (${keywordDensity}%) is elevated. Remove repeated mentions to prevent search penalty.`);

  if (bannedPhrasesDetected.length > 0) {
    const list = bannedPhrasesDetected.slice(0, 3).map((b) => `"${b.phrase}"`).join(", ");
    recommendations.push(`Eliminate AI clichés: ${list}. Replace with concrete empirical descriptions.`);
  }
  if (unsourcedSuperlatives.length > 0) {
    const list = unsourcedSuperlatives.slice(0, 2).map((s) => `"${s}"`).join(", ");
    recommendations.push(`Anchor unbacked superlatives (${list}) with benchmark figures or citation links.`);
  }
  if (preambleFluffCount > 0) {
    recommendations.push(`Remove preamble fluff ("In today's digital world...") in ${preambleFluffCount} section(s). Lead with direct answers.`);
  }

  return {
    keyword: targetKeyword,
    wordCount,
    readingTimeMin,
    keywordCount,
    keywordDensity,
    keywordDensityStatus,
    keywordInTitle,
    keywordInMeta,
    keywordInFirst100,
    keywordInH2,
    metaLength,
    metaLengthStatus,
    h1Count,
    h2Count,
    h3Count,
    fleschScore,
    readingGradeLevel,
    overallHealthScore,
    recommendations,
    bannedPhrasesDetected,
    unsourcedSuperlatives,
    unsourcedStatsCount,
    preambleFluffCount,
  };
}
