import type {
  Website,
  Schedule,
  ContentItem,
  ContentStatus,
  SystemStatus,
  DashboardKpis,
  TopicDiscovery,
  ActionCenterData,
  AiRoiAnalyticsData,
  GeoAuditReport,
  SocialPresenceData,
} from "../types";

const AVATAR_COLORS = [
  "#111111", // ink
  "#555552", // grey
  "#E30613", // Swiss red
  "#8C8C86", // light grey
  "#2C2C2A", // carbon
  "#C40511", // red, dark
  "#3E3E3B", // slate
  "#6E6E69", // mid grey
];

export function getAvatarColor(idOrName: string): string {
  let hash = 0;
  for (let i = 0; i < idOrName.length; i++) {
    hash = (hash << 5) - hash + idOrName.charCodeAt(i);
    hash |= 0;
  }
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export function parseUtcDate(dateInput: Date | string | number | null | undefined): Date {
  if (!dateInput) return new Date();
  if (dateInput instanceof Date) return dateInput;
  if (typeof dateInput === "number") return new Date(dateInput);

  let str = String(dateInput).trim();
  // SQLite format "YYYY-MM-DD HH:MM:SS" -> replace space with "T"
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/.test(str)) {
    str = str.replace(" ", "T");
  }
  // If the ISO string lacks a timezone offset, append 'Z' so it is parsed as UTC
  if (!str.endsWith("Z") && !/[+-]\d{2}(:?\d{2})?$/.test(str)) {
    str += "Z";
  }
  const parsed = new Date(str);
  return isNaN(parsed.getTime()) ? new Date(dateInput) : parsed;
}

export function formatTimeAgo(dateInput: Date | string | number | null | undefined): string {
  if (!dateInput) return "Recently";
  const d = parseUtcDate(dateInput);
  if (isNaN(d.getTime())) return "Recently";
  const now = new Date();
  const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (diffSec <= 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return "Yesterday";
  if (diffDays < 7) return `${diffDays} days ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function mapBackendRunToContentItem(run: any): ContentItem {
  const state = run.state || {};
  const statusStr = (run.status || "").toLowerCase();
  
  let status: ContentStatus = "Idea";
  if (statusStr === "completed") {
    status = "Published";
  } else if (statusStr === "review_pending") {
    status = "Awaiting Approval";
  } else if (statusStr === "running") {
    if (state.draft && state.seo_score) {
      status = "SEO Check";
    } else if (state.draft) {
      status = "Drafting";
    } else {
      status = "Idea";
    }
  } else if (statusStr === "rejected" || statusStr === "error") {
    status = "Failed";
  } else if (statusStr === "queued") {
    status = "Idea";
  }

  const hasDraft = Boolean(state.draft || run.title || statusStr === "review_pending" || statusStr === "completed");
  const hasSeo = Boolean(run.seo_score || state.seo_score || statusStr === "review_pending" || statusStr === "completed");
  const hasReview = Boolean(statusStr === "review_pending" || statusStr === "completed");
  const isPublished = Boolean(statusStr === "completed");

  const createdDate = parseUtcDate(run.created_at);

  return {
    id: run.thread_id,
    threadId: run.thread_id,
    title: run.title || state.title || run.topic || "Untitled run",
    excerpt: state.excerpt || (state.draft ? state.draft.replace(/^[#\s]+[^\n]+\n+/, "").slice(0, 180).trim() + "…" : run.topic || "Autonomous Next.js run."),
    websiteId: run.website_id || "default",
    status,
    createdAt: formatTimeAgo(createdDate),
    createdAtDate: createdDate,
    seoScore: Number(run.seo_score || state.seo_score || 0),
    targetKeyword: state.target_keyword || (Array.isArray(run.keywords) ? run.keywords[0] : (run.keywords || "Next.js")),
    metaDescription: state.meta_description || "Autonomous article sent to Next.js.",
    aiNotes: state.audit_notes || (state.competitor_gaps ? `Niche gap: ${state.competitor_gaps}` : undefined),
    scheduledFor: run.completed_at ? formatTimeAgo(run.completed_at) : undefined,
    draft: state.draft,
    heroImageUrl: run.hero_image_url || state.hero_image_url,
    publishedUrl: run.published_url || state.published_url,
    slug: run.slug || state.slug,
    revisionCount: run.revision_count ?? state.revision_count ?? 0,
    rawStatus: run.status,
    keywords: Array.isArray(run.keywords) ? run.keywords : (state.keywords || []),
    targetAudience: run.target_audience || state.target_audience,
    outline: state.outline,
    imagePrompt: state.image_prompt,
    linkedinPost: state.linkedin_post,
    twitterThread: Array.isArray(state.twitter_thread) ? state.twitter_thread : undefined,
    postizStatus: state.postiz_status,
    searchSources: state.search_sources,
    discoveredKeywords: state.discovered_keywords,
    audienceInsights: state.audience_insights,
    engineErrors: state.engine_errors,
    citableScore: Number(state.citable_score || 0),
    citableEvaluation: state.citable_evaluation,

    citationReadiness: state.citation_readiness || state.citable_evaluation?.citation_readiness,
    factCheckScore: state.fact_check_score !== undefined ? Number(state.fact_check_score) : undefined,
    factCheckVerdict: state.fact_check_verdict,
    requiresHumanApproval: Boolean(state.requires_human_approval),
    namedHumanApprover: state.named_human_approver,
    verificationReport: state.verification_report,
    verifiedClaims: Array.isArray(state.verified_claims) ? state.verified_claims : undefined,
    verificationLayers: state.verification_layers,
    sourceCitations: Array.isArray(state.source_citations) ? state.source_citations : undefined,
    serpCoverage: state.serp_coverage,
    topicCluster: state.topic_cluster,
    onPageSeo: state.on_page_seo,
    schemaMarkup: state.schema_markup,
    internalLinkProposals: state.internal_link_proposals,
    imageProvenance: state.image_provenance,
    aeoReport: state.aeo_report,
    answerBlocks: state.answer_blocks,
    aeoFaqItems: state.aeo_faq_items,
    aeoEntityLayer: state.aeo_entity_layer,
    articleModel: state.article_model,
    articleHtml: state.article_html,
    articleMarkdown: state.article_markdown,
    articleWpBlocks: state.article_wp_blocks,
    articleWpHtml: state.article_wp_html,
    articleCmsPayload: state.article_cms_payload,
    blueprintCompliance: state.blueprint_compliance,
    lintSummary: state.lint_summary,
    visualPlan: state.visual_plan || state.article_model?.visual_plan,
    visualDensity: state.visual_density || state.visual_plan?.density,
    prohibitionsReport: state.prohibitions_report || state.visual_plan?.prohibitions,
    layoutAudit: state.layout_audit,
    prePublishQualityReport: state.pre_publish_quality_report,
    previewUrl: state.preview_url,
    dedupeKey: state.dedupe_key,
    postPublishChecks: state.post_publish_checks,
    pipeline: {
      draft: hasDraft,
      seo: hasSeo,
      review: hasReview,
      published: isPublished,
    },
  };
}

export function mapBackendWebsite(site: any): Website {
  const createdDate = parseUtcDate(site.created_at);
  // Health is stored as a free-form message from the last connection test.
  // Flag any obvious failure (a probe that hit HTTP 4xx/5xx, DNS/refused errors)
  // so an endpoint that rejects every publish is not shown as healthy.
  const rawStatus = String(site.last_status || "");
  const healthFailed = /fail|refus|unreachable|timed out|timeout|http [45]\d\d|error|invalid/i.test(rawStatus);
  const isConnected = !healthFailed;
  return {
    id: site.id,
    name: site.name,
    url: site.url,
    status: isConnected ? "Connected" : "Disconnected",
    schedule: "Weekly",
    lastPublished: formatTimeAgo(site.last_tested_at || site.created_at),
    lastPublishedAt: createdDate,
    articles: site.articles_count ?? 0,
    avatarColor: getAvatarColor(site.name || site.id),
    secret_token: site.secret_token,
    slack_channel_id: site.slack_channel_id,
    slack_webhook_url: site.slack_webhook_url,
    slack_enabled: Boolean(site.slack_enabled),
    is_default: Boolean(site.is_default),
    last_status: site.last_status,
    type: site.type,
    github_repo: site.github_repo,
    github_branch: site.github_branch,
    has_github_token: Boolean(site.has_github_token),
    has_secret_token: Boolean(site.has_secret_token),
    storage_type: site.storage_type,
  };
}

export function mapBackendSchedule(s: any): Schedule {
  const freqMap: Record<string, "Daily" | "Weekly" | "Biweekly" | "Monthly"> = {
    daily: "Daily",
    weekly: "Weekly",
    biweekly: "Biweekly",
    monthly: "Monthly",
  };
  const hours = Number(s.interval_hours || 0);
  const freq = freqMap[(s.frequency || "").toLowerCase()] || (hours > 0 ? "Custom" : "Daily");
  const rawType = (s.schedule_type || "recurring").toLowerCase();
  const type: Schedule["schedule_type"] =
    s.status === "completed" ? "completed" : rawType === "once" ? "once" : "recurring";
  const publishTime = typeof s.publish_time === "string" && s.publish_time.trim() ? s.publish_time.trim() : undefined;
  return {
    id: s.id,
    name: s.name,
    websiteId: s.website_id,
    frequency: freq,
    time: publishTime || (s.next_run_at ? new Date(s.next_run_at).toTimeString().slice(0, 5) : "08:00"),
    nextRun: s.next_run_at ? formatTimeAgo(s.next_run_at) : type === "completed" ? "Done" : "Not scheduled",
    active: s.status === "active",
    topic: s.topic_prompt,
    lastRun: s.last_run_at ? formatTimeAgo(s.last_run_at) : undefined,
    interval_hours: s.interval_hours,
    slack_review_required: Boolean(s.slack_review_required),
    keywords: s.keywords,
    target_audience: s.target_audience,
    schedule_type: type,
    publish_time: publishTime,
    content_format: s.content_format,
    content_options: s.content_options || {},
  };
}

// -------------------------------------------------------------
// Real Fetch API Layer
// -------------------------------------------------------------

export const API_BASE =
  typeof window !== "undefined" && window.location.protocol === "file:"
    ? "http://127.0.0.1:8000"
    : "";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options?.headers || {}),
    },
    ...options,
  });
  if (!res.ok) {
    let errMessage = `Request to ${path} failed (${res.status})`;
    try {
      const body = await res.json();
      if (body.detail) errMessage = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
      else if (body.error) errMessage = body.error;
    } catch {
      // ignore
    }
    throw new Error(errMessage);
  }
  return res.json();
}

export const api = {
  // Websites
  async getWebsites(): Promise<Website[]> {
    const raw = await request<any[]>("/api/websites");
    return raw.map(mapBackendWebsite);
  },

  async createWebsite(payload: {
    name: string;
    url: string;
    secret_token?: string;
    slack_channel_id?: string;
    slack_webhook_url?: string;
    slack_enabled?: boolean;
    is_default?: boolean;
    github_repo?: string;
    github_branch?: string;
    github_token?: string;
    storage_type?: string;
  }): Promise<Website> {
    const raw = await request<any>("/api/websites", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    return mapBackendWebsite(raw);
  },

  async updateWebsite(id: string, payload: Partial<{
    name: string;
    url: string;
    secret_token: string;
    slack_channel_id: string;
    slack_webhook_url: string;
    slack_enabled: boolean;
    is_default: boolean;
    github_repo: string;
    github_branch: string;
    github_token: string;
    storage_type: string;
  }>): Promise<Website> {
    const raw = await request<any>(`/api/websites/${encodeURIComponent(id)}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
    return mapBackendWebsite(raw);
  },

  async deleteWebsite(id: string): Promise<{ status: string }> {
    return request<{ status: string }>(`/api/websites/${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
  },

  async getWebsiteSecretToken(id: string): Promise<{ website_id: string; secret_token: string }> {
    return request<{ website_id: string; secret_token: string }>(
      `/api/websites/${encodeURIComponent(id)}/secret-token`,
    );
  },

  async testWebsite(id: string): Promise<any> {
    return request<any>(`/api/websites/${encodeURIComponent(id)}/test`, {
      method: "POST",
    });
  },

  async testWebsiteSlack(id: string): Promise<any> {
    return request<any>(`/api/websites/${encodeURIComponent(id)}/test-slack`, {
      method: "POST",
    });
  },

  async getNextJsSnippet(): Promise<{ app_router_path: string; snippet: string; code: string; lib_posts?: string; agent_prompt?: string; curl_command?: string }> {
    return request<any>("/api/websites/nextjs-snippet");
  },

  async testStorageConnection(payload: {
    engine: "upstash" | "github";
    upstash_url?: string;
    upstash_token?: string;
    github_token?: string;
    github_repo?: string;
  }): Promise<{ success: boolean; message: string; latency_ms?: number }> {
    return request<any>("/api/websites/test-storage", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Schedules
  async getSchedules(): Promise<Schedule[]> {
    const raw = await request<any[]>("/api/schedules");
    return raw.map(mapBackendSchedule);
  },

  async createSchedule(payload: {
    name: string;
    website_id: string;
    topic_prompt?: string;
    keywords?: string[];
    target_audience?: string;
    frequency?: string;
    interval_hours?: number;
    slack_review_required?: boolean;
    schedule_type?: string;
    publish_time?: string;
    content_format?: string;
    enable_diagrams?: boolean;
    enable_tables?: boolean;
    enable_faqs?: boolean;
    enable_takeaways?: boolean;
    enable_answer_blocks?: boolean;
    enable_citations?: boolean;
    enable_hero_image?: boolean;
    content_options?: Record<string, boolean>;
  }): Promise<Schedule> {
    const raw = await request<any>("/api/schedules", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    return mapBackendSchedule(raw);
  },

  async updateSchedule(id: string, payload: Partial<{
    name: string;
    website_id: string;
    topic_prompt: string;
    keywords: string[];
    target_audience: string;
    frequency: string;
    interval_hours: number;
    slack_review_required: boolean;
    status: string;
    schedule_type: string;
    publish_time: string;
    content_format: string;
    enable_diagrams: boolean;
    enable_tables: boolean;
    enable_faqs: boolean;
    enable_takeaways: boolean;
    enable_answer_blocks: boolean;
    enable_citations: boolean;
    enable_hero_image: boolean;
    content_options: Record<string, boolean>;
  }>): Promise<Schedule> {
    const raw = await request<any>(`/api/schedules/${encodeURIComponent(id)}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
    return mapBackendSchedule(raw);
  },

  async toggleSchedule(id: string): Promise<{ status: string; schedule_id: string }> {
    return request<{ status: string; schedule_id: string }>(
      `/api/schedules/${encodeURIComponent(id)}/toggle`,
      { method: "POST" }
    );
  },

  async escalateSchedule(id: string): Promise<{ status: string; thread_id: string }> {
    return request<{ status: string; thread_id: string }>(
      `/api/schedules/${encodeURIComponent(id)}/escalate`,
      { method: "POST" }
    );
  },

  async deleteSchedule(id: string): Promise<{ status: string }> {
    return request<{ status: string }>(`/api/schedules/${encodeURIComponent(id)}`, {
      method: "DELETE",
    });
  },

  // Live SSE streaming listener
  subscribeToStream(threadId: string, onEvent: (data: any) => void, onError?: (err: any) => void): () => void {
    const source = new EventSource(`${API_BASE}/api/agent/stream/${encodeURIComponent(threadId)}`);
    const handle = (evt: MessageEvent) => {
      try {
        const parsed = JSON.parse(evt.data);
        onEvent({ event: evt.type, ...parsed });
      } catch {
        onEvent({ event: evt.type, message: evt.data });
      }
    };
    // The backend emits NAMED SSE events ("event: stage_start", "event: log", ...).
    // onmessage only fires for unnamed events, so register an explicit listener
    // for every event type the server sends.
    const NAMED_EVENTS = [
      "connected",
      "stage_start",
      "stage_complete",
      "log",
      "review_required",
      "pipeline_complete",
      "pipeline_error",
      "pipeline_rejected",
    ];
    NAMED_EVENTS.forEach((name) => source.addEventListener(name, handle as EventListener));
    // Catch-all for any unnamed/future events
    source.onmessage = handle;
    source.onerror = () => {
      // EventSource auto-reconnects on its own; just surface the hiccup.
      if (onError) onError(new Error("SSE connection error"));
    };
    return () => {
      NAMED_EVENTS.forEach((name) => source.removeEventListener(name, handle as EventListener));
      source.close();
    };
  },

  // KPIs
  async getKpis(): Promise<DashboardKpis> {
    return request<DashboardKpis>("/api/agent/kpis");
  },

  // Runs / Content
  async getRuns(): Promise<ContentItem[]> {
    const raw = await request<any[]>("/api/agent/runs");
    return raw.map(mapBackendRunToContentItem);
  },

  async getRun(threadId: string): Promise<ContentItem> {
    const raw = await request<any>(`/api/agent/runs/${encodeURIComponent(threadId)}`);
    return mapBackendRunToContentItem(raw);
  },

  async startRun(payload: {
    topic?: string;
    website_id?: string;
    keywords?: string[];
    target_audience?: string;
    content_format?: string;
    auto_approve?: boolean;
    brand_voice?: string;
    article_depth?: string;
    secondary_keywords?: string[];
    niche?: string;
    inject_evidence?: boolean;
    enable_diagrams?: boolean;
    enable_tables?: boolean;
    enable_faqs?: boolean;
    enable_takeaways?: boolean;
    enable_answer_blocks?: boolean;
    enable_citations?: boolean;
    enable_hero_image?: boolean;
  }): Promise<{ status: string; thread_id: string; message: string }> {
    return request<{ status: string; thread_id: string; message: string }>("/api/agent/run", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async reviewRun(
    threadId: string,
    action: "approve" | "approved" | "request_changes" | "changes_requested" | "reject" | "rejected",
    feedback?: string
  ): Promise<any> {
    return request<any>(`/api/agent/runs/${encodeURIComponent(threadId)}/review`, {
      method: "POST",
      body: JSON.stringify({ action, feedback }),
    });
  },

  async saveDraft(threadId: string, draft: string, title?: string): Promise<ContentItem> {
    const raw = await request<any>(`/api/agent/runs/${encodeURIComponent(threadId)}/draft`, {
      method: "PUT",
      body: JSON.stringify({ draft, title }),
    });
    return mapBackendRunToContentItem(raw);
  },

  async deleteRun(threadId: string): Promise<{ status: string }> {
    return request<{ status: string }>(`/api/agent/runs/${encodeURIComponent(threadId)}`, {
      method: "DELETE",
    });
  },

  // Topic Research
  async discoverTopic(websiteId?: string): Promise<TopicDiscovery> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<TopicDiscovery>(`/api/agent/discover-topic${q}`);
  },

  // System Diagnostics & Settings
  async getSystemStatus(): Promise<SystemStatus> {
    return request<SystemStatus>("/api/agent/system-status");
  },

  async saveSettings(payload: Record<string, any>): Promise<any> {
    return request<any>("/api/agent/settings", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Test Engine Hooks
  async testGemini(apiKey?: string, model?: string): Promise<any> {
    return request<any>("/api/agent/test-gemini", {
      method: "POST",
      body: JSON.stringify({ api_key: apiKey, model }),
    });
  },

  async testCloudflareImage(payload?: {
    account_id?: string;
    api_token?: string;
    model?: string;
    prompt?: string;
  }): Promise<any> {
    return request<any>("/api/agent/test-cloudflare-image", {
      method: "POST",
      body: JSON.stringify(payload || {}),
    });
  },

  async testOpenAIImage(apiKey?: string, model?: string, prompt?: string): Promise<any> {
    return request<any>("/api/agent/test-openai-image", {
      method: "POST",
      body: JSON.stringify({ api_key: apiKey, model, prompt }),
    });
  },

  async testCustomImage(payload?: {
    endpoint_url?: string;
    api_key?: string;
    model?: string;
    prompt?: string;
  }): Promise<any> {
    return request<any>("/api/agent/test-custom-image", {
      method: "POST",
      body: JSON.stringify(payload || {}),
    });
  },

  async testCodex(token?: string): Promise<any> {
    return request<any>("/api/agent/test-codex", {
      method: "POST",
      body: JSON.stringify({ token }),
    });
  },

  async captureCodexLocal(): Promise<any> {
    return request<any>("/api/agent/codex-capture-local", {
      method: "POST",
    });
  },

  async startCodexDevice(): Promise<any> {
    return request<any>("/api/agent/codex-device-start", {
      method: "POST",
    });
  },

  async pollCodexDevice(deviceAuthId: string, userCode: string): Promise<any> {
    return request<any>("/api/agent/codex-device-poll", {
      method: "POST",
      body: JSON.stringify({ device_auth_id: deviceAuthId, user_code: userCode }),
    });
  },

  async getCodexStatus(): Promise<any> {
    return request<any>("/api/agent/codex-status");
  },

  async testImageEngine(): Promise<any> {
    return request<any>("/api/agent/test-image-engine", { method: "POST" });
  },

  async testSlackGlobal(botToken?: string, channelId?: string): Promise<any> {
    return request<any>("/api/agent/test-slack-global", {
      method: "POST",
      body: JSON.stringify({ bot_token: botToken, channel_id: channelId }),
    });
  },

  async testLLM(provider: string, apiKey?: string, model?: string, baseUrl?: string): Promise<any> {
    return request<any>("/api/agent/test-llm", {
      method: "POST",
      body: JSON.stringify({ provider, api_key: apiKey, model, base_url: baseUrl }),
    });
  },

  async testTavily(apiKey?: string): Promise<any> {
    return request<any>("/api/agent/test-tavily", {
      method: "POST",
      body: JSON.stringify({ api_key: apiKey }),
    });
  },

  async testDataforseo(login?: string, password?: string): Promise<any> {
    return request<any>("/api/agent/test-dataforseo", {
      method: "POST",
      body: JSON.stringify({ login, password }),
    });
  },

  async testEmbedding(provider?: string, apiKey?: string, model?: string): Promise<any> {
    return request<any>("/api/agent/test-embedding", {
      method: "POST",
      body: JSON.stringify({ provider, api_key: apiKey, model }),
    });
  },

  async testSerper(apiKey?: string): Promise<any> {
    return request<any>("/api/agent/test-serper", {
      method: "POST",
      body: JSON.stringify({ api_key: apiKey }),
    });
  },

  async testGithub(payload?: { token?: string; repo?: string; branch?: string }): Promise<any> {
    return request<any>("/api/agent/test-github", {
      method: "POST",
      body: JSON.stringify(payload || {}),
    });
  },

  async getActionCenter(websiteId?: string): Promise<ActionCenterData> {
    const url = websiteId && websiteId !== "all"
      ? `/api/action-center/opportunities?website_id=${encodeURIComponent(websiteId)}`
      : "/api/action-center/opportunities";
    return request<ActionCenterData>(url);
  },


  async executeAction(payload: {
    opportunity_type: string;
    post_slug: string;
    website_id?: string;
    extra_params?: Record<string, any>;
  }): Promise<any> {
    return request<any>("/api/action-center/execute", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async getAiRoiAnalytics(): Promise<AiRoiAnalyticsData> {
    return request<AiRoiAnalyticsData>("/api/analytics/ai-roi");
  },

  async getGroundingPages(): Promise<any[]> {
    const raw = await request<any>("/api/grounding-pages");
    if (Array.isArray(raw)) return raw;
    if (raw && Array.isArray(raw.pages)) return raw.pages;
    return [];
  },

  async generateGroundingPage(payload: {
    entity_name: string;
    canonical_url: string;
    entity_type?: string;
    stable_definition?: string;
    what_it_is_not?: string[];
    atomic_facts?: Array<{ fact: string; timestamp?: string }>;
    key_specifications?: Record<string, string>;
    same_as_links?: string[];
    slug?: string;
  }): Promise<any> {
    return request<any>("/api/grounding-pages/generate", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Keyword Candidate Generation & Opportunity Calibrator (Pillars A1.1 & A1.2)
  async getKeywordCandidates(params?: {
    website_id?: string;
    source?: string;
    opportunity_type?: string;
    attainability_status?: string;
    min_score?: number;
    status?: string;
    limit?: number;
  }): Promise<{ candidates: any[]; total: number }> {
    const q = new URLSearchParams();
    if (params?.website_id) q.set("website_id", params.website_id);
    if (params?.source) q.set("source", params.source);
    if (params?.opportunity_type) q.set("opportunity_type", params.opportunity_type);
    if (params?.attainability_status) q.set("attainability_status", params.attainability_status);
    if (params?.min_score !== undefined) q.set("min_score", String(params.min_score));
    if (params?.status) q.set("status", params.status);
    if (params?.limit) q.set("limit", String(params.limit));
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ candidates: any[]; total: number }>(`/api/keywords/candidates${qs}`);
  },

  async getEmpiricalReach(website_id?: string): Promise<any> {
    const q = website_id ? `?website_id=${encodeURIComponent(website_id)}` : "";
    return request<any>(`/api/keywords/empirical-reach${q}`);
  },

  async calibrateEmpiricalReach(website_id?: string): Promise<any> {
    return request<any>("/api/keywords/empirical-reach/calibrate", {
      method: "POST",
      body: JSON.stringify({ website_id: website_id || "default" }),
    });
  },

  async generateKeywordCandidates(payload: {
    website_id: string;
    competitor_domains?: string[];
    seed_keywords?: string[];
    brand_profile?: any;
  }): Promise<any> {
    return request<any>("/api/keywords/generate-candidates", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async enrichKeywordCandidates(candidates: any[]): Promise<any> {
    return request<any>("/api/keywords/enrich", {
      method: "POST",
      body: JSON.stringify({ candidates }),
    });
  },

  async getKeywordSeeds(website_id?: string, approved_only?: boolean): Promise<{ seeds: any[]; total: number }> {
    const q = new URLSearchParams();
    if (website_id) q.set("website_id", website_id);
    if (approved_only) q.set("approved_only", "true");
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ seeds: any[]; total: number }>(`/api/keywords/seeds${qs}`);
  },

  async suggestKeywordSeeds(payload: {
    website_id: string;
    brand_profile?: any;
    niche?: string;
  }): Promise<any> {
    return request<any>("/api/keywords/seeds/suggest", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async approveKeywordSeed(seed_id: string, approved: boolean = true): Promise<any> {
    return request<any>("/api/keywords/seeds/approve", {
      method: "POST",
      body: JSON.stringify({ seed_id, approved }),
    });
  },

  async convertKeywordToArticle(payload: {
    website_id: string;
    keyword: string;
    candidate_id?: string;
    search_intent?: string;
    target_audience?: string;
  }): Promise<any> {
    return request<any>("/api/keywords/convert-to-article", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async getClusters(website_id?: string, limit?: number): Promise<{ clusters: any[]; total: number }> {
    const q = new URLSearchParams();
    if (website_id) q.set("website_id", website_id);
    if (limit) q.set("limit", String(limit));
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ clusters: any[]; total: number }>(`/api/keywords/clusters${qs}`);
  },

  async getContentPlan(params?: {
    website_id?: string;
    action?: string;
    status?: string;
    limit?: number;
  }): Promise<{ content_plan: any[]; total: number }> {
    const q = new URLSearchParams();
    if (params?.website_id) q.set("website_id", params.website_id);
    if (params?.action) q.set("action", params.action);
    if (params?.status) q.set("status", params.status);
    if (params?.limit) q.set("limit", String(params.limit));
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ content_plan: any[]; total: number }>(`/api/keywords/content-plan${qs}`);
  },

  async generateClusterPlan(payload: {
    website_id: string;
    brand_profile?: any;
    overlap_threshold?: number;
    max_shortlist?: number;
  }): Promise<any> {
    return request<any>("/api/keywords/cluster-and-plan", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async updateContentPlanStatus(payload: { item_id: string; status: string }): Promise<any> {
    return request<any>("/api/keywords/content-plan/update-status", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async executeContentPlanItem(payload: {
    item_id: string;
    website_id: string;
    target_keyword: string;
    supporting_keywords?: string[];
    action?: string;
    target_url?: string;
  }): Promise<any> {
    return request<any>("/api/keywords/content-plan/execute-item", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async fetchLiveBrief(payload: {
    keyword: string;
    topic?: string;
    website_id?: string;
    evidence_pack?: any;
    target_audience?: string;
    angle_or_hook?: string;
  }): Promise<{ brief: any; success: boolean }> {
    return request<{ brief: any; success: boolean }>("/api/serp/live-brief", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Brand Voice & Style Profile (Pillar A3.1)
  async getStyleProfile(website_id?: string, topic?: string): Promise<{ style_profile: any; website_id: string }> {
    const q = new URLSearchParams();
    if (website_id) q.set("website_id", website_id);
    if (topic) q.set("topic", topic);
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ style_profile: any; website_id: string }>(`/api/brand-voice/style-profile${qs}`);
  },

  async buildStyleProfile(website_id: string): Promise<any> {
    return request<any>("/api/brand-voice/build", {
      method: "POST",
      body: JSON.stringify({ website_id }),
    });
  },

  async approveStyleProfile(website_id: string): Promise<any> {
    return request<any>("/api/brand-voice/approve", {
      method: "POST",
      body: JSON.stringify({ website_id }),
    });
  },

  // Evidence Packs & Originality Gating (Pillar A3.2)
  async getEvidencePacks(website_id?: string, evidence_type?: string): Promise<{ evidence_items: any[]; total: number }> {
    const q = new URLSearchParams();
    if (website_id) q.set("website_id", website_id);
    if (evidence_type) q.set("evidence_type", evidence_type);
    const qs = q.toString() ? `?${q.toString()}` : "";
    return request<{ evidence_items: any[]; total: number }>(`/api/evidence-packs${qs}`);
  },

  async uploadEvidenceItem(payload: {
    website_id: string;
    title: string;
    evidence_type: string;
    content: string;
    source_url?: string;
    author_or_expert?: string;
  }): Promise<any> {
    return request<any>("/api/evidence-packs/upload", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async deleteEvidenceItem(item_id: string): Promise<any> {
    return request<any>(`/api/evidence-packs/${encodeURIComponent(item_id)}`, {
      method: "DELETE",
    });
  },

  async seedEvidencePacks(website_id?: string): Promise<{ evidence_items: any[]; seeded: number; success: boolean }> {
    const siteId = website_id || "default";
    try {
      const res = await request<any>("/api/evidence-packs/seed", {
        method: "POST",
        body: JSON.stringify({ website_id: siteId }),
      });
      if (res && res.success) return res;
    } catch {
      // Fallback for live server instances running without restarted seed route
    }

    const samples = [
      {
        title: "Production Netcode Telemetry & Sub-Tick Latency Benchmarks",
        evidence_type: "first_party_data",
        content: "Continuous telemetry across 1.4M simulated frames demonstrates sub-tick rollback reconciling in 1.82ms with zero packet desync on Linux x86_64 and ARM64 bare-metal clusters.",
        source_url: "https://internal-telemetry.example.com/netcode-q4",
        author_or_expert: "Staff Infrastructure Architect",
      },
      {
        title: "Enterprise Physics Engine Migration: Decoupled Simulation Loop",
        evidence_type: "customer_example",
        content: "Migrated 250k concurrent sessions to a tickless deterministic physics pipeline, reducing server desync reconciliations by 43% and slashing p99 memory usage by 18MB per match.",
        source_url: "https://customer-portal.example.com/case-studies/apex",
        author_or_expert: "VP of Engineering, Apex Interactive",
      },
      {
        title: "Practitioner Perspective: Hardware Cache Alignment & Zero-Copy Structs",
        evidence_type: "expert_quote",
        content: "\"Modern instruction pipelines bottleneck on pointer indirection far more than ALU cycles. Moving our core simulation states into contiguous ContiguousArray structs tripled throughput without any multithreading overhead.\" — David Vance, Lead Systems Engineer",
        source_url: "https://practitioners-symposium.org/transcripts/2026/cache-locality",
        author_or_expert: "David Vance, Lead Systems Engineer",
      },
      {
        title: "Lab Results: Binary Serialization Throughput (FlatBuffers vs Protobuf)",
        evidence_type: "original_results",
        content: "Empirical benchmark measuring 100,000 packet encode/decode cycles on 64-core AMD EPYC: FlatBuffers achieved zero-copy deserialization in 4.2 microseconds vs Protobuf's 38.6 microseconds under saturated network buffers.",
        source_url: "https://benchmarks.internal/binary-serialization-results",
        author_or_expert: "Core Architecture Lab",
      },
    ];

    for (const item of samples) {
      await api.uploadEvidenceItem({
        website_id: siteId,
        title: item.title,
        evidence_type: item.evidence_type,
        content: item.content,
        source_url: item.source_url,
        author_or_expert: item.author_or_expert,
      });
    }

    const updated = await api.getEvidencePacks(siteId);
    return { evidence_items: updated.evidence_items || [], seeded: samples.length, success: true };
  },

  // Model Router & Configuration (Pillar A3.1)
  async getModelRouterConfig(): Promise<any> {
    return request<any>("/api/model-router/config");
  },

  async resumePipelineWithEvidence(thread_id: string, evidence_pack: any): Promise<any> {
    return request<any>("/api/pipeline/resume-with-evidence", {
      method: "POST",
      body: JSON.stringify({ thread_id, evidence_pack }),
    });
  },

  // Pillar A5d: CMS Publishers & Publish Modes
  async stageDraftInCMS(payload: {
    website_id?: string;
    title: string;
    slug: string;
    markdown: string;
    html?: string;
    meta_description?: string;
    meta_title?: string;
    hero_image_url?: string;
    tags?: string[];
    author?: string;
    scheduled_time?: string;
  }): Promise<any> {
    return request<any>("/api/studio/publish/stage", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async executeCMSPublish(payload: {
    website_id?: string;
    thread_id?: string;
    title: string;
    slug: string;
    markdown: string;
    html?: string;
    meta_description?: string;
    meta_title?: string;
    hero_image_url?: string;
    tags?: string[];
    author?: string;
    scheduled_time?: string;
    reviewer_attestation?: any;
    quality_gates_passed?: boolean;
    quality_gate_blocking_count?: number;
    is_refresh?: boolean;
    previous_content?: string;
  }): Promise<any> {
    return request<any>("/api/studio/publish/execute", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async unpublishPost(dedupe_key: string, website_id?: string, slug?: string): Promise<any> {
    return request<any>("/api/studio/publish/unpublish", {
      method: "POST",
      body: JSON.stringify({ dedupe_key, website_id, slug }),
    });
  },

  async revertPost(dedupe_key: string, website_id?: string, slug?: string, revision_id?: string): Promise<any> {
    return request<any>("/api/studio/publish/revert", {
      method: "POST",
      body: JSON.stringify({ dedupe_key, website_id, slug, revision_id }),
    });
  },

  async getPublishModes(website_id?: string): Promise<any> {
    const q = website_id ? `?website_id=${encodeURIComponent(website_id)}` : "";
    return request<any>(`/api/studio/publish/modes${q}`);
  },

  async configurePublishMode(payload: {
    website_id: string;
    mode: string;
    mode_2_settings?: any;
    mode_3_settings?: any;
  }): Promise<any> {
    return request<any>("/api/studio/publish/configure-mode", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Technical SEO Audit Engine
  async getTechnicalAudit(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/audit/technical${q}`);
  },

  async runTechnicalAudit(payload: {
    website_id?: string;
    base_url?: string;
    max_pages?: number;
  }): Promise<any> {
    return request<any>("/api/audit/technical/run", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Backlink Analysis Engine
  async getBacklinks(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/backlinks${q}`);
  },

  async scanBacklinks(payload: {
    website_id?: string;
    own_domain?: string;
  }): Promise<any> {
    return request<any>("/api/backlinks/scan", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Knowledge Graph & GraphRAG Engine
  async getKnowledgeGraph(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/knowledge-graph${q}`);
  },

  async rebuildKnowledgeGraph(payload: {
    website_id?: string;
    use_llm?: boolean;
  }): Promise<any> {
    return request<any>("/api/knowledge-graph/rebuild", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async queryKnowledgeGraph(payload: {
    website_id?: string;
    entity: string;
    max_hops?: number;
  }): Promise<any> {
    return request<any>("/api/knowledge-graph/query", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Closed-Loop Performance Harvest Engine
  async getHarvestStatus(): Promise<any> {
    return request<any>("/api/harvest/status");
  },

  async runHarvestNow(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/harvest/run${q}`, {
      method: "POST",
    });
  },

  // AEO Snippets & Question Targets Engine
  async getAeoTargets(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/aeo/targets${q}`);
  },

  async upsertAeoTarget(payload: any): Promise<any> {
    return request<any>("/api/aeo/targets", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async deleteAeoTarget(targetId: string): Promise<any> {
    return request<any>(`/api/aeo/targets/${encodeURIComponent(targetId)}`, {
      method: "DELETE",
    });
  },

  async getAeoMeasurements(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/aeo/measurement${q}`);
  },

  async getAeoConfig(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/aeo/config${q}`);
  },

  async updateAeoConfig(payload: any): Promise<any> {
    return request<any>("/api/aeo/config", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async verifyAeoBlock(payload: any): Promise<any> {
    return request<any>("/api/aeo/verify-block", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Search Performance, Organic Rankings & Attribution
  async getSearchPerformance(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/analytics/search-performance${q}`);
  },

  async getRankings(websiteId?: string, keyword?: string): Promise<any> {
    const params = new URLSearchParams();
    if (websiteId) params.append("website_id", websiteId);
    if (keyword) params.append("keyword", keyword);
    const qs = params.toString() ? `?${params.toString()}` : "";
    return request<any>(`/api/analytics/rankings${qs}`);
  },

  async getAiRoi(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/analytics/ai-roi${q}`);
  },

  async getAiVisibility(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/analytics/ai-visibility${q}`);
  },

  async measureAiVisibility(payload: any): Promise<any> {
    return request<any>("/api/analytics/ai-visibility/measure", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async getAttribution(websiteId?: string): Promise<any> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/analytics/attribution${q}`);
  },

  // Search & AI Visibility Audit (GEO / AEO Engine)
  async runGeoVisibilityAudit(domain: string, brand?: string): Promise<GeoAuditReport> {
    return request<GeoAuditReport>("/api/audit/geo-visibility", {
      method: "POST",
      body: JSON.stringify({ domain, brand }),
    });
  },

  async getSampleGeoVisibilityDomains(): Promise<{ samples: Array<{ domain: string; brand: string; category: string }> }> {
    return request<{ samples: Array<{ domain: string; brand: string; category: string }> }>("/api/audit/geo-visibility/sample");
  },

  // Social & Reddit GEO Radar (Brand Presence Opportunities)
  async getSocialOpportunities(websiteId?: string): Promise<SocialPresenceData> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<SocialPresenceData>(`/api/social/opportunities${q}`);
  },

  // Crawler Access Policy
  async getCrawlerPolicyBots(): Promise<any> {
    return request<any>("/api/crawler-policy/bots");
  },

  async checkSiteCrawlerAccess(payload: { url: string; robots_txt?: string }): Promise<any> {
    return request<any>("/api/crawler-policy/check-site", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Citation Readiness & Verification Levers
  async getCitationChecklist(params: { slug?: string; thread_id?: string }): Promise<any> {
    const qs = new URLSearchParams();
    if (params.slug) qs.append("slug", params.slug);
    if (params.thread_id) qs.append("thread_id", params.thread_id);
    return request<any>(`/api/citation-readiness/checklist?${qs.toString()}`);
  },

  async getEvidenceMatrix(): Promise<any> {
    return request<any>("/api/citation-readiness/evidence-matrix");
  },

  async getCorroborationPlatforms(topic?: string): Promise<any> {
    const q = topic ? `?topic=${encodeURIComponent(topic)}` : "";
    return request<any>(`/api/citation-readiness/corroboration-platforms${q}`);
  },

  // Fact Verification Subgraph & Trust Tiers
  async getFactCheckReport(params: { thread_id?: string; slug?: string }): Promise<any> {
    const qs = new URLSearchParams();
    if (params.thread_id) qs.append("thread_id", params.thread_id);
    if (params.slug) qs.append("slug", params.slug);
    return request<any>(`/api/fact-check/report?${qs.toString()}`);
  },

  async getFactCheckReports(websiteId?: string, limit = 50): Promise<any[]> {
    const qs = new URLSearchParams();
    if (websiteId) qs.append("website_id", websiteId);
    qs.append("limit", String(limit));
    return request<any[]>(`/api/fact-check/reports?${qs.toString()}`);
  },

  async getFactCheckTrustTiers(tenantId?: string): Promise<any> {
    const q = tenantId ? `?tenant_id=${encodeURIComponent(tenantId)}` : "";
    return request<any>(`/api/fact-check/trust-tiers${q}`);
  },

  async verifyFactCheckClaim(payload: {
    text?: string;
    draft?: string;
    title?: string;
    meta_description?: string;
    schema_snippet?: string;
    alt_text?: string;
    tenant_id?: string;
  }): Promise<any> {
    return request<any>("/api/fact-check/verify", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Article Studio Multi-Modal Gates, Linting & Verification
  async getStudioToolingManifest(): Promise<any> {
    return request<any>("/api/studio/tooling-manifest");
  },

  async getStudioVisualRules(): Promise<any> {
    return request<any>("/api/studio/visual-rules");
  },

  async runStudioLint(payload: {
    markdown: string;
    title?: string;
    meta_description?: string;
    slug?: string;
  }): Promise<any> {
    return request<any>("/api/studio/lint", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async runLinkRotCheck(payload: { draft: string }): Promise<any> {
    return request<any>("/api/studio/link-rot-check", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async runLinksAudit(payload: { draft: string; domain?: string }): Promise<any> {
    return request<any>("/api/studio/audit-links", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async runImageDeliveryAudit(payload: { hero_image_url?: string; draft?: string }): Promise<any> {
    return request<any>("/api/studio/image-delivery-audit", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async runLayoutAudit(payload: { blocks: any[]; total_word_count?: number }): Promise<any> {
    return request<any>("/api/studio/layout-audit", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async runPrePublishGates(payload: {
    article_model?: any;
    article_type?: string;
    doc_id?: string;
    website_id?: string;
  }): Promise<any> {
    return request<any>("/api/studio/pre-publish-gates", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async renderStudioChart(payload: {
    chart_type?: string;
    title?: string;
    labels?: string[];
    datasets?: any[];
  }): Promise<any> {
    return request<any>("/api/studio/render-chart", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async renderStudioDiagram(payload: {
    diagram_code: string;
    diagram_type?: string;
    title?: string;
  }): Promise<any> {
    return request<any>("/api/studio/render-diagram", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async validateStudioDiagram(payload: { diagram_code: string }): Promise<any> {
    return request<any>("/api/studio/validate-diagram", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async generateOgCard(payload: {
    title: string;
    author?: string;
    date?: string;
    badge?: string;
  }): Promise<any> {
    return request<any>("/api/studio/generate-og-card", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // On-Page SEO Linter & Schema CI Validation
  async runOnPageSeoLint(payload: {
    draft: string;
    title?: string;
    meta_description?: string;
    slug?: string;
    author?: string;
    published_at?: string;
    updated_at?: string;
  }): Promise<any> {
    return request<any>("/api/seo/on-page-lint", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async validateSchemaCi(payload: { schema_markup: any; url?: string }): Promise<any> {
    return request<any>("/api/schema/validate-ci", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Contextual Internal Links Generator
  async generateInternalLinkProposals(payload: {
    draft: string;
    new_post_slug?: string;
    new_post_title?: string;
    website_id?: string;
  }): Promise<any> {
    return request<any>("/api/internal-links/proposals", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async applyApprovedInternalLinks(payload: {
    draft: string;
    proposals: any[];
  }): Promise<{ success: boolean; draft: string }> {
    return request<any>("/api/internal-links/apply", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async reviewInternalLinkProposal(payload: {
    proposals: any[];
    proposal_id: string;
    new_status: string;
    comment?: string;
  }): Promise<any> {
    return request<any>("/api/internal-links/review", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },


  // Image Provenance & Attribution
  async generateImageProvenance(payload: {
    image_url: string;
    generation_prompt?: string;
    ai_engine?: string;
    model_name?: string;
    article_slug?: string;
  }): Promise<any> {
    return request<any>("/api/images/provenance", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // Measurement Status & Telemetry
  async getMeasurementStatus(): Promise<any> {
    return request<any>("/api/measurement/status");
  },

  // Blueprints & Prompt Templates
  async getBlueprints(): Promise<Record<string, any>> {
    return request<Record<string, any>>("/api/agent/blueprints");
  },

  async getBlueprint(articleType: string): Promise<any> {
    return request<any>(`/api/agent/blueprints/${encodeURIComponent(articleType)}`);
  },

  async getTemplates(): Promise<any> {
    return request<any>("/api/agent/templates");
  },

  async getPromptTemplates(): Promise<any> {
    return request<any>("/api/prompts/templates");
  },

  // Machine Readability & llms.txt
  async getLlmsTxt(websiteId?: string): Promise<{
    site_name: string;
    site_url: string;
    content: string;
    static_path?: string;
    target_synced: boolean;
    destinations: Array<{ path: string; exists: boolean }>;
  }> {
    const q = websiteId ? `?website_id=${encodeURIComponent(websiteId)}` : "";
    return request<any>(`/api/llms-txt${q}`);
  },

  async syncLlmsTxt(payload?: {
    website_id?: string;
    site_name?: string;
    site_url?: string;
  }): Promise<any> {
    return request<any>("/api/llms-txt/sync", {
      method: "POST",
      body: JSON.stringify(payload || {}),
    });
  },

  // Grounding Pages Standard v1.6 Deployment
  async deployGroundingPage(payload: {
    entity_name: string;
    canonical_url?: string;
    entity_type?: string;
    stable_definition?: string;
    canonical_definition?: string;
    what_it_is_not?: string[];
    atomic_facts?: Array<{ statement: string; confidence?: number; source?: string }>;
    key_specifications?: Record<string, string>;
    same_as_urls?: string[];
    site_name?: string;
    slug?: string;
  }): Promise<any> {
    return request<any>("/api/grounding-pages/deploy", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  // v5 Pillar A0: Site Onboarding & Business Profile
  async getBusinessProfile(websiteId: string): Promise<any> {
    return request<any>(`/api/onboarding/business-profile/${encodeURIComponent(websiteId)}`);
  },
  async extractBusinessProfile(websiteId: string, payload: { home_html: string; about_text?: string; pricing_text?: string; product_text?: string }): Promise<any> {
    return request<any>(`/api/onboarding/business-profile/${encodeURIComponent(websiteId)}`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },
  async getInventory(websiteId: string, limit: number = 100): Promise<any> {
    return request<any>(`/api/onboarding/inventory/${encodeURIComponent(websiteId)}?limit=${limit}`);
  },
  async classifyCompetitors(websiteId: string, domains: string[]): Promise<any> {
    return request<any>(`/api/onboarding/competitors/${encodeURIComponent(websiteId)}`, {
      method: "POST",
      body: JSON.stringify({ domains }),
    });
  },

  // v5 Pillar A1b: Opportunity Feed
  async getOpportunityFeed(websiteId: string, status: string = "active", limit: number = 50): Promise<any> {
    return request<any>(`/api/opportunities/feed/${encodeURIComponent(websiteId)}?status=${status}&limit=${limit}`);
  },
  async generateOpportunityFeed(websiteId: string, limit: number = 50): Promise<any> {
    return request<any>(`/api/opportunities/generate/${encodeURIComponent(websiteId)}?limit=${limit}`, {
      method: "POST",
    });
  },
  async sendOpportunityFeedback(itemId: string, action: string, rejectReason?: string): Promise<any> {
    return request<any>(`/api/opportunities/${encodeURIComponent(itemId)}/feedback`, {
      method: "POST",
      body: JSON.stringify({ action, reject_reason: rejectReason }),
    });
  },

  // v5 Pillar A8b: Content Decay & Update Agent
  async getDecayPlans(websiteId: string, status?: string): Promise<any> {
    const q = status ? `?status=${encodeURIComponent(status)}` : "";
    return request<any>(`/api/decay/plans/${encodeURIComponent(websiteId)}${q}`);
  },
  async prioritizeDecay(websiteId: string, reviewerHoursBudget: number = 10.0): Promise<any> {
    return request<any>(`/api/decay/prioritize/${encodeURIComponent(websiteId)}`, {
      method: "POST",
      body: JSON.stringify({ reviewer_hours_budget: reviewerHoursBudget }),
    });
  },
  async getDecayPlanChanges(planId: string, websiteId: string = "default", url: string = ""): Promise<any> {
    return request<any>(`/api/decay/plans/${encodeURIComponent(planId)}/changes?website_id=${encodeURIComponent(websiteId)}&url=${encodeURIComponent(url)}`);
  },

  // v5 Pillar A9: Off-Site Presence Engine
  async getOffSiteSummary(websiteId: string): Promise<any> {
    return request<any>(`/api/off-site/summary/${encodeURIComponent(websiteId)}`);
  },
  async createOffSitePlan(websiteId: string, clusterId: string, topic: string): Promise<any> {
    return request<any>(`/api/off-site/plan/${encodeURIComponent(websiteId)}`, {
      method: "POST",
      body: JSON.stringify({ cluster_id: clusterId, topic }),
    });
  },

  // v5 Pillar A10: Compliance, Disclosures & Reviewer Attestation
  async getComplianceSettings(websiteId: string): Promise<any> {
    return request<any>(`/api/compliance/settings/${encodeURIComponent(websiteId)}`);
  },
  async saveComplianceSettings(websiteId: string, settings: any): Promise<any> {
    return request<any>(`/api/compliance/settings/${encodeURIComponent(websiteId)}`, {
      method: "POST",
      body: JSON.stringify(settings),
    });
  },
  async submitReviewerAttestation(payload: any): Promise<any> {
    return request<any>("/api/compliance/attest", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },
  async getReviewerAttestations(websiteId: string, postSlug?: string): Promise<any> {
    const q = postSlug ? `?post_slug=${encodeURIComponent(postSlug)}` : "";
    return request<any>(`/api/compliance/attestations/${encodeURIComponent(websiteId)}${q}`);
  },

  // v5 Pillar A12: Causal Experiments & Evaluation
  async getExperiments(websiteId: string): Promise<any> {
    return request<any>(`/api/experiments/${encodeURIComponent(websiteId)}`);
  },
  async launchExperiment(payload: any): Promise<any> {
    return request<any>("/api/experiments/launch", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },
  async evaluateDiD(payload: any): Promise<any> {
    return request<any>("/api/experiments/evaluate-did", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },
};




