import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { IS_AUTOMATED, useCalm } from "./motion";

/** Returns a ref and whether the element has entered the viewport (once). */
export function useOnceInView<T extends Element = HTMLDivElement>(margin = "-15% 0px") {
  const ref = useRef<T>(null);
  const seen = useInView(ref, { once: true, margin: margin as `${number}px` });
  return [ref, IS_AUTOMATED || seen] as const;
}

/** Counts 0..count at a fixed cadence once `active` is true. Used to stagger evidence arriving. */
export function useSequence(active: boolean, count: number, interval = 400, startDelay = 300) {
  const [n, setN] = useState(0);
  const reduce = useCalm();
  useEffect(() => {
    if (!active) {
      setN(0);
      return;
    }
    if (reduce) {
      setN(count);
      return;
    }
    let i = 0;
    let id: number | undefined;
    const start = window.setTimeout(() => {
      id = window.setInterval(() => {
        i += 1;
        setN(i);
        if (i >= count && id !== undefined) window.clearInterval(id);
      }, interval);
    }, startDelay);
    return () => {
      window.clearTimeout(start);
      if (id !== undefined) window.clearInterval(id);
    };
  }, [active, count, interval, startDelay, reduce]);
  return n;
}
