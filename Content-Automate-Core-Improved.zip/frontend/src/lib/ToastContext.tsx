import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import {
  IconCheckCircle,
  IconClose,
  IconX,
} from "../components/icons";
import { cn } from "../utils/cn";

export type ToastKind = "success" | "info" | "warn" | "error";

type ToastItem = {
  id: string;
  kind: ToastKind;
  title: string;
  description?: string;
};

type ToastCtx = {
  push: (t: Omit<ToastItem, "id">) => void;
};

const Ctx = createContext<ToastCtx | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const push = useCallback((t: Omit<ToastItem, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setItems((prev) => [...prev, { ...t, id }]);
    window.setTimeout(() => {
      setItems((prev) => prev.filter((x) => x.id !== id));
    }, 4200);
  }, []);

  const dismiss = (id: string) =>
    setItems((prev) => prev.filter((x) => x.id !== id));

  return (
    <Ctx.Provider value={{ push }}>
      {children}
      {typeof document !== "undefined" &&
        createPortal(
          <div className="pointer-events-none fixed bottom-6 right-6 z-[100] flex w-[360px] max-w-[calc(100vw-3rem)] flex-col gap-2">
            {items.map((t) => (
              <div
                key={t.id}
                className={cn(
                  "pointer-events-auto flex items-start gap-3 rounded-xl border p-3 shadow-pop animate-toast-in bg-surface border-app"
                )}
              >
                <div
                  className={cn(
                    "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg",
                    t.kind === "success" && "bg-brand-soft",
                    t.kind === "info" && "bg-info-soft",
                    t.kind === "warn" && "bg-warn-soft",
                    t.kind === "error" && "bg-danger-soft"
                  )}
                >
                  {t.kind === "success" && (
                    <IconCheckCircle size={16} className="text-brand" />
                  )}
                  {t.kind === "info" && (
                    <IconCheckCircle size={16} className="text-[color:var(--info)]" />
                  )}
                  {t.kind === "warn" && (
                    <IconCheckCircle size={16} className="text-[color:var(--warn)]" />
                  )}
                  {t.kind === "error" && (
                    <IconX size={16} className="text-[color:var(--danger)]" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-medium text-app">
                    {t.title}
                  </div>
                  {t.description && (
                    <div className="mt-0.5 text-[12.5px] text-muted">
                      {t.description}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => dismiss(t.id)}
                  className="rounded-md p-1 text-subtle transition-colors hover:bg-muted-soft hover:text-app"
                  aria-label="Dismiss"
                >
                  <IconClose size={14} />
                </button>
              </div>
            ))}
          </div>,
          document.body
        )}
    </Ctx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useToast must be used inside ToastProvider");
  return ctx;
}