import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { CheckCircle2, Info, AlertCircle, X } from "lucide-react";

export type ToastVariant = "success" | "info" | "error" | "warn" | "danger" | "warning";
interface Toast {
  id: number;
  title: string;
  description?: string;
  variant: ToastVariant;
}

interface Ctx {
  push: (t: Omit<Toast, "id">) => void;
}

const ToastContext = createContext<Ctx | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const push = useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((s) => [...s, { ...t, id }]);
    window.setTimeout(() => {
      setToasts((s) => s.filter((x) => x.id !== id));
    }, 4200);
  }, []);

  const dismiss = (id: number) =>
    setToasts((s) => s.filter((x) => x.id !== id));

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-6 right-6 z-50 flex w-full max-w-sm flex-col gap-2">
        {toasts.map((t) => {
          const isSuccess = t.variant === "success";
          const isWarn = t.variant === "warn" || t.variant === "warning";
          const isDanger = t.variant === "error" || t.variant === "danger";

          const indicatorColor = isSuccess
            ? "var(--color-live)"
            : isWarn
            ? "var(--color-warn)"
            : isDanger
            ? "var(--color-danger)"
            : "var(--color-info)";

          return (
            <div
              key={t.id}
              className="pointer-events-auto relative overflow-hidden animate-slideUp border-2 bg-[var(--color-bg-elev)] p-3.5 pl-4 shadow-[var(--shadow-pop)]"
              style={{ borderColor: "var(--color-border-strong)" }}
            >
              {/* Left Accent Stripe */}
              <div
                className="absolute left-0 top-0 bottom-0 w-1"
                style={{ background: indicatorColor }}
              />

              <div className="flex items-start gap-3">
                <div
                  className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center border"
                  style={{
                    background: "var(--color-bg-soft)",
                    borderColor: "var(--color-border)",
                    color: isSuccess
                      ? "var(--color-live)"
                      : isWarn
                      ? "var(--color-warn)"
                      : isDanger
                      ? "var(--color-danger)"
                      : "var(--color-info)",
                  }}
                >
                  {isSuccess ? (
                    <CheckCircle2 size={14} />
                  ) : isWarn || isDanger ? (
                    <AlertCircle size={14} />
                  ) : (
                    <Info size={14} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13px] font-semibold text-[var(--color-text)]">
                    {t.title}
                  </div>
                  {t.description && (
                    <div className="mt-0.5 text-xs text-[var(--color-text-muted)] leading-relaxed">
                      {t.description}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => dismiss(t.id)}
                  className="p-1 text-[var(--color-text-subtle)] transition-colors hover:bg-[var(--color-bg-soft)] hover:text-[var(--color-text)] cursor-pointer"
                  aria-label="Dismiss"
                >
                  <X size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside ToastProvider");
  return ctx;
}