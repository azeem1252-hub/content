import { marked } from "marked";

export interface TocHeading {
  id: string;
  text: string;
  level: number;
}

/**
 * Creates a URL-safe, slugified anchor ID for headings.
 */
export function slugifyHeading(text: string): string {
  return text
    .toLowerCase()
    .replace(/<[^>]+>/g, "")
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

/**
 * Transforms Mermaid diagram code into accessible, high-contrast, responsive inline vector SVG.
 */
export function renderMermaidToSvg(source: string, title?: string): string {
  const cleanSource = source.trim();
  const lines = cleanSource.split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.startsWith("%%"));
  if (lines.length === 0) return "";

  const header = lines[0].toLowerCase();
  const isSequence = header.includes("sequencediagram");

  const nodes: Record<string, string> = {};
  const edges: Array<{ src: string; dst: string; label?: string }> = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (isSequence) {
      const seqM = line.match(/^([A-Za-z0-9_-]+)\s*(?:->>|-->>|->)\s*([A-Za-z0-9_-]+)\s*:\s*(.+)$/);
      if (seqM) {
        const [, src, dst, msg] = seqM;
        if (!nodes[src]) nodes[src] = src;
        if (!nodes[dst]) nodes[dst] = dst;
        edges.push({ src, dst, label: msg.trim() });
      }
      continue;
    }

    const edgeM = line.match(/^([A-Za-z0-9_-]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})?\s*(-+>|==>|-.->)(?:\|(.*?)\|)?\s*([A-Za-z0-9_-]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})?$/);
    if (edgeM) {
      const srcId = edgeM[1];
      const srcLbl = edgeM[2] || edgeM[3] || edgeM[4] || srcId;
      const edgeLbl = edgeM[6];
      const dstId = edgeM[7];
      const dstLbl = edgeM[8] || edgeM[9] || edgeM[10] || dstId;

      if (!nodes[srcId] || (edgeM[2] || edgeM[3] || edgeM[4])) nodes[srcId] = srcLbl;
      if (!nodes[dstId] || (edgeM[8] || edgeM[9] || edgeM[10])) nodes[dstId] = dstLbl;
      edges.push({ src: srcId, dst: dstId, label: edgeLbl });
      continue;
    }

    const nodeM = line.match(/^([A-Za-z0-9_-]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})$/);
    if (nodeM) {
      const nId = nodeM[1];
      const nLbl = nodeM[2] || nodeM[3] || nodeM[4] || nId;
      nodes[nId] = nLbl;
    }
  }

  const nodeList = Object.keys(nodes);
  if (nodeList.length === 0) {
    nodes["A"] = "Player Intent";
    nodes["B"] = "System Feedback";
    nodes["C"] = "Emergent Narrative";
    edges.push({ src: "A", dst: "B", label: "action" }, { src: "B", dst: "C", label: "consequence" });
    nodeList.push("A", "B", "C");
  }

  const totalNodes = nodeList.length;
  const useGrid = totalNodes > 4;
  const cols = useGrid ? Math.min(3, Math.ceil(totalNodes / 2)) : totalNodes;
  const nodeW = 150;
  const nodeH = 50;
  const spacingX = 50;
  const spacingY = 60;
  const padX = 40;
  const padY = 55;

  const totalW = padX * 2 + cols * nodeW + Math.max(0, cols - 1) * spacingX;
  const rows = useGrid ? Math.ceil(totalNodes / cols) : 1;
  const totalH = padY + rows * (nodeH + spacingY) + 20;

  const coords: Record<string, { x: number; y: number }> = {};
  nodeList.forEach((nid, idx) => {
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    const x = padX + col * (nodeW + spacingX);
    const y = padY + row * (nodeH + spacingY);
    coords[nid] = { x, y };
  });

  const diagTitle = title || "Architectural System Diagram";
  const titleId = `diag-title-${Math.floor(Math.random() * 100000)}`;

  let svgElements = "";
  edges.forEach((e) => {
    if (coords[e.src] && coords[e.dst]) {
      const s = coords[e.src];
      const d = coords[e.dst];
      const sx = s.x + nodeW;
      const sy = s.y + nodeH / 2;
      const dx = d.x;
      const dy = d.y + nodeH / 2;

      if (dx < sx) {
        const midY = Math.max(sy, dy) + 40;
        svgElements += `<path d="M ${sx} ${sy} C ${sx + 30} ${midY}, ${dx - 30} ${midY}, ${dx} ${dy}" fill="none" stroke="#64748B" stroke-width="2" marker-end="url(#arrow)"/>`;
      } else {
        svgElements += `<line x1="${sx}" y1="${sy}" x2="${dx}" y2="${dy}" stroke="#64748B" stroke-width="2" marker-end="url(#arrow)"/>`;
      }

      if (e.label) {
        const mx = (sx + dx) / 2;
        const my = (sy + dy) / 2 - 8;
        svgElements += `<text x="${mx}" y="${my}" text-anchor="middle" font-family="system-ui, sans-serif" font-size="10" font-weight="500" fill="#64748B">${escapeHtml(e.label)}</text>`;
      }
    }
  });

  nodeList.forEach((nid) => {
    const pt = coords[nid];
    const lbl = escapeHtml(nodes[nid] || nid);
    svgElements += `
      <g class="diagram-node">
        <rect x="${pt.x}" y="${pt.y}" width="${nodeW}" height="${nodeH}" rx="8" fill="url(#nodeGrad)" stroke="#1E40AF" stroke-width="1.5"/>
        <text x="${pt.x + nodeW / 2}" y="${pt.y + nodeH / 2 + 5}" text-anchor="middle" font-family="system-ui, sans-serif" font-size="11" font-weight="600" fill="#FFFFFF">${lbl}</text>
      </g>
    `;
  });

  return `
<div class="article-diagram-card my-6 rounded-xl border border-[var(--color-border)] bg-[var(--color-bg-elev)] p-4 shadow-sm">
  <div class="flex items-center justify-between pb-3 border-b border-[var(--color-border)] mb-3">
    <div class="flex items-center gap-2">
      <span class="rounded bg-[var(--color-bg-soft)] px-2 py-0.5 font-mono text-[10px] font-bold text-[var(--color-accent-text)] uppercase tracking-wider">
        Vector Diagram
      </span>
      <span class="text-xs font-bold text-[var(--color-text)]">${escapeHtml(diagTitle)}</span>
    </div>
    <span class="rounded bg-[var(--color-live-soft)] px-2 py-0.5 font-mono text-[10px] font-bold text-[var(--color-live)]">
      Mermaid Valid
    </span>
  </div>
  <div class="overflow-x-auto rounded-lg bg-slate-50 dark:bg-slate-900/60 p-2 border border-[var(--color-border)] flex justify-center">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalW} ${totalH}" width="100%" height="${totalH}" role="img" aria-labelledby="${titleId}">
      <title id="${titleId}">${escapeHtml(diagTitle)}</title>
      <defs>
        <linearGradient id="nodeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#2563EB"/>
          <stop offset="100%" stop-color="#1D4ED8"/>
        </linearGradient>
        <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748B"/>
        </marker>
      </defs>
      <rect width="${totalW}" height="${totalH}" rx="10" fill="transparent"/>
      ${svgElements}
    </svg>
  </div>
  <details class="mt-3 text-xs text-[var(--color-text-muted)] cursor-pointer">
    <summary class="font-mono text-[10px] hover:text-[var(--color-text)] select-none">
      View Mermaid Source
    </summary>
    <pre class="mt-2 rounded bg-[var(--color-bg-soft)] p-2 font-mono text-[11px] overflow-x-auto border border-[var(--color-border)]"><code>${escapeHtml(cleanSource)}</code></pre>
  </details>
</div>
`;
}

/**
 * Transforms GitHub-style alerts (> [!NOTE], > [!TIP], etc.) into styled HTML callouts.
 */
function processCallouts(text: string): string {
  const alertTypes: Record<string, { label: string; class: string }> = {
    NOTE: { label: "Note", class: "callout-note" },
    TIP: { label: "Pro Tip", class: "callout-tip" },
    IMPORTANT: { label: "Important", class: "callout-important" },
    WARNING: { label: "Editorial Caution", class: "callout-warning" },
    CAUTION: { label: "Caution", class: "callout-caution" },
  };

  return text.replace(
    /^>\s*\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*\n((?:>.*(?:\n|$))*)/gim,
    (_match, type, content) => {
      const alert = alertTypes[type.toUpperCase()] || { label: type, class: "callout-note" };
      const cleaned = content.replace(/^>\s?/gm, "").trim();
      const bodyHtml = marked.parse(cleaned, { async: false, gfm: true }) as string;
      return `<div class="article-callout ${alert.class}"><div class="callout-header">${alert.label}</div><div class="callout-body">${bodyHtml}</div></div>\n\n`;
    }
  );
}

/**
 * Extracts structured headings (H2 & H3) from Markdown for the Table of Contents.
 */
export function extractHeadings(markdown: string): TocHeading[] {
  if (!markdown) return [];
  const lines = markdown.split(/\r?\n/);
  const headings: TocHeading[] = [];
  const seenSlugs = new Set<string>();

  for (const line of lines) {
    const match = line.match(/^(#{2,3})\s+(.+)$/);
    if (match) {
      const level = match[1].length;
      const rawText = match[2].trim().replace(/\*|_|`|\[|\]/g, "");
      let slug = slugifyHeading(rawText);
      if (seenSlugs.has(slug)) {
        let count = 2;
        while (seenSlugs.has(`${slug}-${count}`)) count++;
        slug = `${slug}-${count}`;
      }
      seenSlugs.add(slug);
      headings.push({ id: slug, text: rawText, level });
    }
  }
  return headings;
}

/**
 * Renders markdown safely with:
 * - Whole-document code fence stripping
 * - Frontmatter & orphan rule cleaning
 * - Alert callout parsing
 * - Mermaid diagram SVG parsing & rendering
 * - Heading anchor injection (id="heading-slug") for smooth TOC jumps
 * - Responsive table wrapping
 * - HTML neutralization against script injection
 */
export function renderMarkdownSafe(markdown: string): string {
  if (!markdown) return "";
  let text = markdown.trim();

  // 1. Strip whole-document code fences
  text = text
    .replace(/^```(?:markdown|md)?\s*[\r\n]+/i, "")
    .replace(/[\r\n]+```\s*$/i, "")
    .trim();

  // 2. Strip YAML frontmatter if present
  text = text.replace(/^---\s*[\r\n]+[\s\S]*?[\r\n]+---\s*/, "");

  // 3. Strip orphan horizontal rules directly following H1 title
  text = text.replace(/^(#[^\n]+)\s*\n+---\s*\n+/m, "$1\n\n");

  // 4. Transform GitHub-style alert callouts
  text = processCallouts(text);

  // 5. Transform Mermaid diagram code blocks into responsive vector SVGs
  text = text.replace(/```mermaid\s*([\s\S]*?)```/gi, (_match, code) => {
    return `\n\n${renderMermaidToSvg(code)}\n\n`;
  });

  // 6. Neutralize dangerous tags but keep safe markdown, image, & SVG constructs
  const escaped = text.replace(
    /<(?=[a-zA-Z/!?](?!figure|figcaption|img|picture|source|div|span|table|thead|tbody|tr|th|td|code|pre|svg|g|path|rect|line|text|defs|marker|linearGradient|stop|title|details|summary))/g,
    "&lt;"
  );

  try {
    const rawHtml = marked.parse(escaped, { async: false, gfm: true }) as string;

    // Inject unique anchor IDs on H2 and H3 elements
    const seenSlugs = new Set<string>();
    const withAnchors = rawHtml.replace(/<h([2-3])([^>]*)>(.*?)<\/h\1>/gi, (_match, level, attrs, headingText) => {
      let slug = slugifyHeading(headingText);
      if (seenSlugs.has(slug)) {
        let count = 2;
        while (seenSlugs.has(`${slug}-${count}`)) count++;
        slug = `${slug}-${count}`;
      }
      seenSlugs.add(slug);
      return `<h${level}${attrs} id="${slug}">${headingText}</h${level}>`;
    });

    // Wrap tables in responsive overflow wrappers
    return withAnchors
      .replace(/<table>/g, '<div class="article-table-wrap"><table>')
      .replace(/<\/table>/g, "</table></div>");
  } catch {
    return escaped;
  }
}
