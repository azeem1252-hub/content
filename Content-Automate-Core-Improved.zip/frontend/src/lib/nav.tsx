import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export type Page =
  | "overview"
  | "websites"
  | "keywords"
  | "content"
  | "queue"
  | "drafts"
  | "published"
  | "schedules"
  | "reviews"
  | "analytics"
  | "social"
  | "backlinks"
  | "health"
  | "settings"
  | "article"
  | "landing"
  | "billing"
  | "team"
  | "apikeys"
  | "login";

export type DrawerTab =
  | "draft"
  | "blocks"
  | "blueprint"
  | "social"
  | "research"
  | "factcheck"
  | "onpage"
  | "aeo"
  | "publish"
  | "terminal";

interface Ctx {
  page: Page;
  setPage: (p: Page) => void;
  selectedArticleId: string | null;
  setSelectedArticleId: (id: string | null) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
  // Slide-over Master-Detail Inspector
  inspectorArticleId: string | null;
  inspectorInitialTab: DrawerTab | null;
  isInspectorOpen: boolean;
  openInspector: (articleId: string, initialTab?: DrawerTab) => void;
  closeInspector: () => void;
  // Live Active Run Tracking
  activeRunThreadId: string | null;
  setActiveRunThreadId: (id: string | null) => void;
  // Global Pipeline Launch Modal
  isLaunchModalOpen: boolean;
  openLaunchModal: () => void;
  closeLaunchModal: () => void;
}

const NavContext = createContext<Ctx | null>(null);

function computeInitialState(): { page: Page; articleId: string | null; inspectorOpen: boolean } {
  try {
    const params = new URLSearchParams(window.location.search);
    const articleId = params.get("article") || params.get("id");
    const pageParam = params.get("page") as Page | null;
    if (articleId) {
      return { page: "overview", articleId, inspectorOpen: true };
    }
    if (pageParam) {
      return { page: pageParam, articleId: null, inspectorOpen: false };
    }
    const path = window.location.pathname.replace(/\/+$/, "") || "/";
    if (path === "/landing") {
      return { page: "landing", articleId: null, inspectorOpen: false };
    }
    if (path === "/login") {
      return { page: "login", articleId: null, inspectorOpen: false };
    }
    if (path === "/dashboard") {
      return { page: "overview", articleId: null, inspectorOpen: false };
    }
    // Root URL defaults to Studio Command Center (Overview), with /landing for Public Showcase
    return { page: "overview", articleId: null, inspectorOpen: false };
  } catch {
    return { page: "overview", articleId: null, inspectorOpen: false };
  }
}

export function NavProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(computeInitialState);
  const [page, setPageState] = useState<Page>(initial.page);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(initial.articleId);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [inspectorArticleId, setInspectorArticleId] = useState<string | null>(initial.articleId);
  const [inspectorInitialTab, setInspectorInitialTab] = useState<DrawerTab | null>(null);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(initial.inspectorOpen);
  const [activeRunThreadId, setActiveRunThreadId] = useState<string | null>(null);
  const [isLaunchModalOpen, setIsLaunchModalOpen] = useState<boolean>(false);

  const setPage = (newPage: Page) => {
    setPageState(newPage);
    try {
      const url = new URL(window.location.href);
      if (newPage === "landing") {
        url.pathname = "/";
        url.searchParams.delete("page");
      } else if (newPage === "overview") {
        url.pathname = "/dashboard";
        url.searchParams.delete("page");
      } else if (newPage === "login") {
        url.pathname = "/login";
        url.searchParams.delete("page");
      } else {
        url.pathname = "/dashboard";
        url.searchParams.set("page", newPage);
      }
      window.history.pushState({}, "", url.toString());
    } catch {
      // non-browser fallback
    }
  };

  useEffect(() => {
    const onPopState = () => {
      const st = computeInitialState();
      setPageState(st.page);
      if (st.articleId) {
        setSelectedArticleId(st.articleId);
        setInspectorArticleId(st.articleId);
        setIsInspectorOpen(st.inspectorOpen);
      }
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  const openInspector = (articleId: string, initialTab?: DrawerTab) => {
    setSelectedArticleId(articleId);
    setInspectorArticleId(articleId);
    if (initialTab) {
      setInspectorInitialTab(initialTab);
    }
    setIsInspectorOpen(true);
  };

  const closeInspector = () => {
    setIsInspectorOpen(false);
    setInspectorInitialTab(null);
  };

  const openLaunchModal = () => setIsLaunchModalOpen(true);
  const closeLaunchModal = () => setIsLaunchModalOpen(false);

  return (
    <NavContext.Provider
      value={{
        page,
        setPage,
        selectedArticleId,
        setSelectedArticleId,
        sidebarOpen,
        setSidebarOpen,
        inspectorArticleId,
        inspectorInitialTab,
        isInspectorOpen,
        openInspector,
        closeInspector,
        activeRunThreadId,
        setActiveRunThreadId,
        isLaunchModalOpen,
        openLaunchModal,
        closeLaunchModal,
      }}
    >
      {children}
    </NavContext.Provider>
  );
}

export function useNav() {
  const ctx = useContext(NavContext);
  if (!ctx) throw new Error("useNav must be used inside NavProvider");
  return ctx;
}