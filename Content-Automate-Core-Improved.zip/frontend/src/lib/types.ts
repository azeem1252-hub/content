export type StatusKind =
  | "draft"
  | "seo-review"
  | "awaiting-approval"
  | "scheduled"
  | "published"
  | "failed"
  | "rejected"
  | "paused";

export type PipelineStage =
  | "ideas"
  | "drafting"
  | "seo-check"
  | "review"
  | "published";

export interface Website {
  id: string;
  name: string;
  url: string;
  status: "connected" | "syncing" | "error" | "disconnected";
  schedule: string;          // human readable e.g. "Weekly"
  lastPublished: string;     // human readable e.g. "Today, 9:12 AM"
  articlesPublished: number;
  niche: string;
}

export interface ContentItem {
  id: string;
  title: string;
  websiteId: string;
  status: StatusKind;
  createdAt: string;          // relative or absolute human readable
  seo: number;                // 0..100
  scheduledAt?: string;       // absolute if scheduled
  excerpt: string;
  targetKeyword: string;
  metaDescription: string;
  aiNotes?: string;
  pipeline: PipelineStage[];
}

export interface Schedule {
  id: string;
  name: string;
  websiteId: string;
  frequency: string;          // "Every Monday"
  time: string;               // "8:00 AM"
  nextRun: string;            // "Monday, 8:00 AM"
  active: boolean;
  topics: string[];
  cronAdvanced?: string;
  content_format?: string;
  content_options?: Record<string, boolean>;
}

export interface ReviewItem {
  id: string;
  contentId: string;
  title: string;
  websiteId: string;
  excerpt: string;
  seo: number;
  summary: string;
  createdAt: string;
  source: "inbox" | "slack";
}

export interface ActivityEvent {
  id: string;
  type: "approved" | "published" | "draft" | "rejected" | "schedule" | "connected";
  title: string;
  detail?: string;
  at: string;                 // relative
  websiteId?: string;
}

export interface PipelineStat {
  stage: PipelineStage;
  label: string;
  count: number;
}