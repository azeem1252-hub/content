export type Pt = [number, number];

/** Deterministic PRNG so charts are stable between renders. */
export function mulberry(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface Pad {
  l?: number;
  r?: number;
  t?: number;
  b?: number;
}

export function scaleY(v: number, h: number, min: number, max: number, pad: Pad = {}) {
  const t = pad.t ?? 0;
  const b = pad.b ?? 0;
  return t + (1 - (v - min) / (max - min)) * (h - t - b);
}

export function mapPts(vals: number[], w: number, h: number, o: { min: number; max: number } & Pad): Pt[] {
  const l = o.l ?? 0;
  const r = o.r ?? 0;
  const n = vals.length;
  return vals.map((v, i) => [l + (i / (n - 1)) * (w - l - r), scaleY(v, h, o.min, o.max, o)] as Pt);
}

export const linePath = (pts: Pt[]) =>
  pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");

export const polyLen = (pts: Pt[]) =>
  pts.reduce((a, p, i) => (i ? a + Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]) : 0), 0);

/** Closed polygon between two lines (top forward, bottom reversed). */
export function areaBetween(top: Pt[], bottom: Pt[]) {
  return (
    linePath(top) +
    " " +
    [...bottom]
      .reverse()
      .map((p) => `L${p[0].toFixed(1)} ${p[1].toFixed(1)}`)
      .join(" ") +
    " Z"
  );
}

export function areaToBase(pts: Pt[], baseY: number) {
  const last = pts[pts.length - 1];
  return `${linePath(pts)} L${last[0].toFixed(1)} ${baseY} L${pts[0][0].toFixed(1)} ${baseY} Z`;
}

/** Rise to a peak, then decay. Negative `drop` keeps climbing. */
export function decaySeries(
  n: number,
  { seed = 7, peakAt = 0.5, drop = 0.37, noise = 1.8, start = 50, peak = 80 } = {},
) {
  const r = mulberry(seed);
  return Array.from({ length: n }, (_, i) => {
    const t = i / (n - 1);
    let base: number;
    if (t <= peakAt) {
      const u = t / peakAt;
      base = start + (peak - start) * (u * u * (3 - 2 * u));
    } else {
      const u = (t - peakAt) / (1 - peakAt);
      base = peak - peak * drop * Math.pow(u, 1.35);
    }
    const wk = Math.sin(i * 1.1) * 1.3;
    return base + wk + (r() - 0.5) * noise * 2;
  });
}

export function seasonalSeries(
  n: number,
  o: {
    seed: number;
    base?: number;
    amp?: number;
    cycles?: number;
    phase?: number;
    noise?: number;
    slope?: (t: number) => number;
  },
) {
  const r = mulberry(o.seed);
  return Array.from({ length: n }, (_, i) => {
    const t = i / (n - 1);
    return (
      (o.base ?? 50) +
      (o.amp ?? 0) * Math.sin(Math.PI * 2 * (o.cycles ?? 1) * t + (o.phase ?? 0)) +
      (o.slope ? o.slope(t) : 0) +
      (r() - 0.5) * (o.noise ?? 1) * 2
    );
  });
}

/** Updated vs matched-control series with a shared market dip. */
export function experimentSeries(n: number, publishAt: number, uplift: number, seed = 5) {
  const r = mulberry(seed);
  const r2 = mulberry(seed + 99);
  const control: number[] = [];
  const updated: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1);
    const dip = -13 * Math.exp(-Math.pow((t - 0.7) / 0.06, 2));
    const wave = 4 * Math.sin(t * 9) + 2 * Math.sin(t * 23);
    const c = 100 + wave + dip + (r() - 0.5) * 3.2;
    control.push(c);
    const u = t <= publishAt ? 0 : uplift * (1 - Math.pow(1 - (t - publishAt) / (1 - publishAt), 2.2));
    updated.push(c * (1 + u) + (r2() - 0.5) * 1.6 + (t <= publishAt ? 0.8 : 0));
  }
  return { control, updated };
}

/** Auto-scaled tiny sparkline path. */
export function sparkPath(vals: number[], w: number, h: number, pad = 1.5) {
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const pts = mapPts(vals, w, h, { min, max: max === min ? min + 1 : max, t: pad, b: pad });
  return linePath(pts);
}
