import { useEffect } from "react";
import { useNav, type Page } from "./lib/nav";
import { Sidebar } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import { OverviewPage } from "./components/pages/OverviewPage";
import { WebsitesPage } from "./components/pages/WebsitesPage";
import { ContentPage } from "./components/pages/ContentPage";
import { SchedulesPage } from "./components/pages/SchedulesPage";
import { ReviewsPage } from "./components/pages/ReviewsPage";
import { AnalyticsPage } from "./components/pages/AnalyticsPage";
import { SocialPresencePage } from "./components/pages/SocialPresencePage";
import { SettingsPage } from "./components/pages/SettingsPage";
import { ArticlePage } from "./components/pages/ArticlePage";
import { KeywordsPage } from "./components/pages/KeywordsPage";
import { LandingPage } from "./components/pages/LandingPage";
import { AuthPage } from "./components/pages/AuthPage";
import { BillingPage } from "./components/pages/BillingPage";
import { TeamPage } from "./components/pages/TeamPage";
import { ApiKeysPage } from "./components/pages/ApiKeysPage";
import { ArticleDrawer } from "./components/ArticleDrawer";
import { ActiveRunHud } from "./components/ActiveRunHud";
import { LaunchPipelineModal } from "./components/LaunchPipelineModal";

export function AppShell() {
  const { page, openLaunchModal } = useNav();

  // Global ⌘N / Ctrl+N shortcut to launch pipeline
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTag = document.activeElement?.tagName.toLowerCase();
      const isInput = activeTag === "input" || activeTag === "textarea" || (document.activeElement as HTMLElement)?.isContentEditable;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        openLaunchModal();
      } else if (e.key === "n" && !isInput && !e.metaKey && !e.ctrlKey && !e.altKey) {
        // Pressing 'n' in command-center view without inputs focused
        e.preventDefault();
        openLaunchModal();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [openLaunchModal]);

  // Standalone full-viewport SaaS pages (no dashboard sidebar/topbar)
  if (page === "landing") {
    return (
      <>
        <LandingPage />
        <LaunchPipelineModal />
      </>
    );
  }

  if (page === "login") {
    return <AuthPage />;
  }

  return (
    <div className="flex min-h-screen bg-[var(--color-bg)] text-[var(--color-text)]">
      <Sidebar />
      <div className="flex min-h-screen min-w-0 flex-1 flex-col">
        <Topbar />
        <main className="flex-1">
          {renderPage(page)}
        </main>
      </div>

      {/* Slide-over Master-Detail Inspector Drawer (viewable inside any page) */}
      <ArticleDrawer />

      {/* Floating Active Generation HUD (shows active stream/run with 1-click focus) */}
      <ActiveRunHud />

      {/* Global Autonomous Pipeline Dispatch Studio Modal */}
      <LaunchPipelineModal />
    </div>
  );
}

function renderPage(page: Page) {
  switch (page) {
    case "landing":
      return <LandingPage />;
    case "login":
      return <AuthPage />;
    case "overview":
      return <OverviewPage />;
    case "websites":
      return <WebsitesPage />;
    case "keywords":
      return <KeywordsPage />;
    case "content":
    case "queue":
    case "drafts":
    case "published":
      return <ContentPage />;
    case "schedules":
      return <SchedulesPage />;
    case "reviews":
      return <ReviewsPage />;
    case "social":
      return <SocialPresencePage />;
    case "backlinks":
      return <AnalyticsPage initialTab="backlinks" />;
    case "health":
      return <AnalyticsPage initialTab="technical" />;
    case "analytics":
      return <AnalyticsPage />;
    case "settings":
      return <SettingsPage />;
    case "article":
      return <ArticlePage />;
    case "billing":
      return <BillingPage />;
    case "team":
      return <TeamPage />;
    case "apikeys":
      return <ApiKeysPage />;
    default:
      return <OverviewPage />;
  }
}