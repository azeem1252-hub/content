# Audit Change Log

**Date:** 2026-10-11

## Security and request trust boundaries

- Hardened the FastAPI studio middleware with a fail-closed remote mode, configured HTTP Basic credentials, constant-time credential comparisons, same-origin checks, and explicit rejection of cross-site browser requests.
- Tightened local origin handling and CORS preflight validation; rejected opaque `Origin: null` and arbitrary `*.localhost` origins.
- Added `pipeline/adapters/url_safety.py` to validate crawler targets before requests and reject non-HTTP(S) schemes, embedded URL credentials, local/reserved names, and private/non-global IP destinations unless an operator explicitly opts in.
- Disabled automatic redirects in the audited crawler requests and restricted sitemap fetches (including nested sitemaps) to the target origin.
- Sanitized CMS verification failures so complete request URLs, query-string tokens, and exception text are not written to logs in the changed paths.

## Publishing and integrations

- Added a shared explicit test-runtime predicate; removed mock-success decisions based on broad `test`, `mock`, `example.com`, `localhost`, or site-name substrings.
- Changed CMS stage/publish/unpublish/revert outcomes to require supported HTTP confirmation or an explicit test runtime.
- Made unsupported Webflow, Shopify, Ghost, and Next.js local-media flows fail rather than inventing a destination URL; WordPress media upload requires the real returned ID and source URL.
- Added early staging failures when the configured adapter cannot confirm required hero media.
- Implemented GitHub headless article staging with validated repository/branch/slug/content paths, base-branch lookup, branch creation/reuse, Contents API article and local-media commits, safe size limits, and idempotent draft PR lookup/create. PR success is only reported after a valid URL and successful response.
- Updated publish-record/idempotency handling to preserve states such as `scheduled`, `draft_pr`, and `pull_request_open` rather than flattening them to `published`.

## Content-evidence integrity

- Marked generated questions as editorial suggestions when live SERP/PAA data is absent; only observed live questions feed SERP gap claims.
- Added `live_data_available`, `paa_questions_source`, and `observed_paa_count` to brief SERP summaries.
- Replaced an unsupported fallback performance guarantee with evidence-qualified editorial guidance.

## Project hygiene and documentation

- Replaced a token-shaped frontend placeholder with `your_github_token_here`.
- Documented studio remote-access variables and the opt-in policy for private/intranet crawler targets in `.env.example` and `README.md`.
- Added regression tests in `tests/test_publish_verification_hardening.py`, `tests/test_brief_builder_truthfulness.py`, `tests/test_url_safety.py`, and `tests/test_security_hardening_audit.py`.
- Added current audit, changelog, verification and research-reference reports.
- Excluded `.env`, local databases/harvest state, private `.agents` state, caches, and temporary helper scripts from the deliverable archive.

## Dependency changes and compatibility

- No application dependencies were added or upgraded.
- CMS responses now correctly surface failures instead of synthetic success. Callers that previously relied on the old optimistic behavior may now receive `failed`/`False`; they should display actionable configuration/API errors.
- The GitHub adapter expects a token with repository Contents write permission and Pull Requests permission. Article content path defaults to `content/posts/<slug>.mdx`; configure `github_content_dir` and `github_content_extension` if the target repository uses a different layout.
- GitHub pull requests are drafts by default. Set `github_draft_pr` explicitly to `false` only if opening a non-draft pull request is intended.
- For Webflow, Shopify and Ghost, supply a publicly reachable HTTPS asset URL unless the relevant adapter’s local-file upload implementation is added and verified.
- For private/intranet crawler destinations, `ALLOW_PRIVATE_AUDIT_TARGETS=true` is an explicit operator-only override and carries SSRF risk.
