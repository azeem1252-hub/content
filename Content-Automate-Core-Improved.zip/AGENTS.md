# Content Pipeline Agent — System Rules & Architecture

This document defines the essential architectural rules and operational standards for AI agents working in this repository. Follow these rules strictly to avoid setup errors, credential confusion, and image pathing failures.

---

## 1. Core Architecture & Services

- **FastAPI Studio Backend & LangGraph Pipeline**:
  - Run via: `python main.py studio`
  - Runs on `http://127.0.0.1:8000` (FastAPI backend + scheduler + LangGraph orchestration).
- **Next.js Editorial Target (`gaming-editorial/`)**:
  - Run via: `npm run dev` in `gaming-editorial/`
  - Runs on `http://localhost:3000` (Next.js 15 App Router).

---

## 2. Publishing & Storage Rules (Strict Hierarchy)

When publishing articles to websites, follow the **Storage Strategy**:

### Rule A: Database or Upstash Targets (Zero Git Dependency)
- If a website has an integrated database (Postgres, SQLite, Supabase) or Upstash Redis (`UPSTASH_REDIS_REST_URL`):
  - The pipeline submits the article payload directly via `POST /api/posts` with `Bearer <secret_token>`.
  - The website persists the post immediately in 0 seconds.
  - **CRITICAL: NEVER require, prompt for, or attempt a GitHub token or Git commit** when database or Upstash storage is present.

### Rule B: Pure Serverless Git-Backed Targets (No Database)
- ONLY when a website has **NO database and NO Upstash** (pure Git-backed Markdown/JSON hosting on Vercel/Netlify):
  - A Git commit is made to persist the article files and hero image.
  - Multi-site isolation: Use the website's specific `github_repo`, `github_branch`, and `github_token`.
  - **Git Staging Rule**: ONLY stage `content/posts/` and `public/uploads/` (`git add content/posts/ public/uploads/`). **NEVER** run `git add .` or stage unrelated directories like `.agents/`, `docs/`, or configuration files.

---

## 3. Hero Image Pathing & Next.js Standards

To prevent image 404 errors:

1. **Next.js URL Standard**:
   - Files stored in `<project>/public/uploads/<filename>` are served at `/uploads/<filename>`.
   - Next.js post frontmatter, JSON, and API payloads **MUST** use `/uploads/<filename>`, **NEVER** `/static/uploads/<filename>`.
2. **Next.js Rewrites**:
   - `gaming-editorial/next.config.ts` must maintain a rewrite rule from `/static/uploads/:path*` to `/uploads/:path*` for backwards compatibility.
3. **Publisher File Sync**:
   - When publishing an article with a local hero image, `publish_node.py` must copy the asset from `web/static/uploads/` into `<target_site>/public/uploads/`.
   - If Git-backed, both the post file and the image in `public/uploads/` must be staged and committed together.

---

## 4. AI Image Generation Engine Order

The pipeline prioritizes true generative AI models:
- **Config**: `IMAGE_ENGINE_ORDER=cloudflare,gemini,codex,tavily`
- **1. Cloudflare Workers AI**: Model `@cf/black-forest-labs/flux-1-schnell` (1024x1024 high-aesthetic diffusion tensor).
- **2. Google Gemini**: REST `generateContent` with `gemini-3.1-flash-image-preview` (falls back to `gemini-2.5-flash-image`).
- **3. OpenAI Codex**: Backend OAuth dispatch (`gpt-image-2`).
- **4. Tavily Stock Photos / SVG**: Only used if network or generative AI APIs fail.

---

## 5. Multi-Website Isolation

- The system supports multiple websites simultaneously (e.g. `gaming-editorial`, a tech blog, or custom clients).
- Each website is configured independently in the Studio UI (`Websites` tab) or SQLite database.
- Settings, URLs, tokens, repos, and storage engines are per-website. Never assume a single repository in `.env` applies to all sites.
