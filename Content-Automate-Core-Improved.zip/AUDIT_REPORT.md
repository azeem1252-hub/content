# Application Engineering Audit Report

**Project:** Content Pipeline Agent / Mission Control Studio  
**Audit date:** 2026-10-11  
**Scope:** Static source and configuration review, targeted security/reliability review, focused regression tests, and packaging hygiene.  
**Important limitation:** Full dependency installation and full-stack execution could not be completed in this environment. See `VERIFICATION_REPORT.md`; this is not a claim that the whole application is production-ready or vulnerability-free.

## Executive summary

The project is a content research, drafting, review, and publishing application. Its main components are a FastAPI studio, a LangGraph-based Python content pipeline, CMS adapters, SQLite-backed state, and a React/Vite frontend.

The audit found several cases where code could report success without external confirmation, a GitHub publishing adapter that could advertise a pull-request path without first committing article content, URL-crawling trust-boundary weaknesses, and generated search questions/brief copy that could be misrepresented as observed SERP evidence. These paths have been changed and covered with focused regression tests. A configured `.env` file and generated/private runtime artifacts were present in the supplied archive; they are excluded from the deliverable archive.

### Main outcomes

- Added a single, fail-closed remote-access gate for the studio: remote access requires configured Basic credentials, same-origin browser requests, and rejects explicit cross-site Fetch Metadata. Local mode validates loopback hosts and origins and no longer accepts `Origin: null` or arbitrary `*.localhost` origins.
- Added an SSRF-oriented target URL validator for competitor scraping and technical audits. It rejects private/non-global destinations by default, disallows URL-embedded credentials, and the affected crawler clients no longer automatically follow redirects. Technical-audit sitemap fetching is restricted to the target origin.
- Corrected CMS adapter result semantics so missing credentials, failed HTTP responses, and exceptions no longer turn into publish/unpublish success. Removed URL/site-name substring heuristics that could accidentally activate a mock-success path on a real target.
- Implemented actual GitHub headless staging: validate repository and article paths, create/reuse a version-specific branch, commit article content and local media through the GitHub Contents API, then look up/create a draft pull request after remote confirmation. No live repository was contacted during this audit; all verification used mocked HTTP clients.
- Removed guessed success for unsupported CMS media uploaders. Webflow, Shopify, Ghost, and Next.js adapters require a supported, explicit URL/reference or return a failure. WordPress uploads require a confirmed CMS response. Staging stops if its required hero-image reference fails.
- Separated observed live PAA questions from generated editorial suggestions in content briefs. The fallback angle no longer promises unmeasured “zero performance degradation.”
- Replaced a token-shaped frontend placeholder with a clearly inert placeholder string.
- Added four focused regression-test modules: CMS publishing, URL safety, brief truthfulness, and studio security. The three runnable focused modules currently pass; the studio-security module cannot be imported here because application dependencies are missing.

## Architecture inventory

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS 4; source under `frontend/`.
- **Backend/API:** FastAPI application under `web/`, run with Uvicorn.
- **Pipeline:** LangGraph nodes, research/brief/draft/audit/publish stages, provider clients and CMS adapters under `pipeline/`.
- **Persistence:** SQLite-oriented operations in `storage/` and `web/`.
- **Integrations:** LLM/search providers, CMS APIs, Slack review flow, GitHub repository publishing, and optional measurement/SEO services.
- **Tests:** Existing pytest suite plus targeted regression tests added during this audit.

This inventory is inferred from source structure and manifests. Production credentials, provider accounts, live CMS endpoints, and real integrations were not exercised.

## Findings and remediations

| ID | Severity | Finding | Remediation and verification |
|---|---|---|---|
| SEC-01 | P1 | When remote studio access was enabled, the access boundary did not require a separate configured credential pair. Origin checks were also too permissive for opaque/suffix-based origins and preflight handling reflected arbitrary origins. | Remote access now fails closed when `STUDIO_ACCESS_USERNAME`/`STUDIO_ACCESS_PASSWORD` are absent and requires Basic authentication; mutating remote browser requests need same-origin `Origin`, explicit cross-site Fetch Metadata is rejected, local origin checks reject opaque and suffix-based hosts, and CORS preflights validate methods/headers. Runtime test execution is **blocked** by missing `markdown` and `langgraph`; implementation was syntax-compiled and the regression tests were added. |
| SEC-02 | P1 | Audit crawlers accepted configurable/search-result URLs and could follow redirects; technical-audit sitemap discovery could fetch a sitemap on a different origin. This creates SSRF risk when targets or remote content are untrusted. | Added `pipeline/adapters/url_safety.py`; rejects embedded credentials, private/local/non-global IPs and non-global DNS results by default; disables redirect following in the relevant crawler requests; restricts sitemap fetches to the validated target origin. URL-safety and mocked cross-origin-sitemap regression tests pass. **Residual risk:** validation and HTTP connection resolution are separate, so a DNS-rebinding/time-of-check/time-of-use gap remains; high-assurance deployments should pin connections to the validated address or enforce outbound network controls. |
| REL-01 | P1 | Some CMS publishing, staging, post-publish verification, and unpublish/revert paths returned success without a successful remote response or credentials. Mock behavior could also be inferred from broad substrings in a URL or identifier. | Success now depends on the supported API response (or an explicit test runtime). Failed unpublish/revert paths return false; post-publish failures are not converted into success; test/mock detection no longer relies on common domain/site-id substrings. Focused CMS regression tests pass. Real CMS credentials and deployments were not tested. |
| REL-02 | P1 | The headless Git publishing path could return a generated branch/PR URL without committing the article first, and could claim a PR existed without confirmation. | Added path validation, branch lookup/create, Contents API commits, optional local media commits, idempotent draft-PR lookup/create and confirmation-based result states. Added mocked API tests for article/media commits, traversal rejection and draft PR confirmation. No live GitHub write was performed. |
| REL-03 | P2 | Several CMS media uploaders could manufacture predictable image URLs even when the integration had not uploaded the file. That could create a content record with broken images while appearing successful. | Unsupported local-upload paths now fail explicitly unless a supported uploader confirms the upload or the article supplies an allowed external URL. WordPress requires returned media ID/source URL. CMS staging aborts if required hero media fails. Regression tests cover unsupported uploaders, failed WordPress upload, and a Next.js path-traversal media URL. |
| DATA-01 | P2 | When live SERP data was absent, generated question suggestions could be counted and labelled as observed PAA/SERP gaps. | Briefs now distinguish `live_serp` from `generated_suggestions`, only use observed questions for SERP gap claims, and expose live-data/PAA-source metadata. Mocked fallback test passes. |
| DATA-02 | P2 | A fallback editorial angle asserted “empirical benchmark” and “zero performance degradation” without verified measurements. | The fallback copy now frames this as source-grounded analysis and says measured results should only be reported when verified. Regression test passes. |
| SEC-03 | P1 (delivery hygiene) | The supplied ZIP contained a populated `.env` file plus generated/private local runtime state. The source also contained a token-shaped example placeholder that could be mistaken for a real token. | `.env`, private agent state, local databases/harvest state, caches, and helper patch scripts are excluded from the deliverable. `.env.example` remains. The token-shaped frontend placeholder was replaced. The report does not reproduce secret values. If the original ZIP has been shared outside a trusted boundary and any values were real, rotate them. |

Severity describes potential impact if the behavior is reached in a deployed environment, not proof that a vulnerability was exploited. No P0 finding was confirmed in the reviewed paths. This table is not an exhaustive statement that no other issues exist.

## Additional engineering observations

### Performance

No comparative performance measurements were possible, and no performance improvement is claimed. The fixes focus on correctness and security. Network timeout policies, cache behavior, database query efficiency, provider costs, and frontend bundle size still deserve measurement after dependencies are installed and the application can run end-to-end.

### Frontend and user experience

The source tree was inspected for primary component/API wiring and the misleading token placeholder was cleaned up. A full interactive browser/accessibility review and production bundle validation were not possible because `frontend/node_modules` was unavailable and package installation could not complete. No broad visual redesign was imposed, to avoid altering product identity without runtime evidence.

### Dependencies

No project dependencies were added or upgraded as part of these changes. Lockfiles were preserved. A global-environment `pip check` reported an unrelated environment mismatch (`moviepy` requires `pillow<12`, while this execution environment has Pillow 12.3.0); this was not introduced by project dependency changes. Project requirements were not installable due network/DNS restrictions.

### Historical audit material

`docs/audit/AUDIT_REPORT_2026-10-10.md` is retained as a historical snapshot and is not the source of truth for this audit. Some findings recorded there were already resolved in the current code before this pass. The current evidence and limitations are recorded in this file and `VERIFICATION_REPORT.md`.

## Recommended operator follow-up

1. Install dependencies in a clean supported Python/Node environment, then run the full suite, frontend typecheck/build, and runtime verification commands from `VERIFICATION_REPORT.md`.
2. Keep `ALLOW_REMOTE_ACCESS=false` for local use. If remote access is necessary, use unique credentials behind HTTPS and a trusted reverse proxy/tunnel, and do not expose the unauthenticated internal port directly.
3. Keep `ALLOW_PRIVATE_AUDIT_TARGETS=false` for public-host audits. Use outbound egress policy/connection-time IP pinning for high-assurance SSRF protection.
4. Test every configured CMS integration against a staging account, including media paths, scheduling, rollback and PR review, before enabling production publishing.
