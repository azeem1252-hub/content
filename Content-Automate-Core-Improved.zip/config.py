import os
import shutil
import threading
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent

# Load environment variables immediately on module import from root .env
env_file = BASE_DIR / ".env"
if env_file.exists():
    load_dotenv(env_file, override=True)
else:
    load_dotenv(override=True)

# Core configuration variables (auto-loaded from .env on startup)
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o").strip()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-7-sonnet-20250219").strip()
QWEN_API_KEY = os.getenv("QWEN_API_KEY", "").strip() or os.getenv("DASHSCOPE_API_KEY", "").strip()
QWEN_MODEL = os.getenv("QWEN_MODEL", "qwen-plus").strip()
GLM_API_KEY = os.getenv("GLM_API_KEY", "").strip() or os.getenv("ZHIPU_API_KEY", "").strip()
GLM_MODEL = os.getenv("GLM_MODEL", "glm-4-flash").strip()
KIMI_API_KEY = os.getenv("KIMI_API_KEY", "").strip() or os.getenv("MOONSHOT_API_KEY", "").strip()
KIMI_MODEL = os.getenv("KIMI_MODEL", "moonshot-v1-8k").strip()
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat").strip()
CUSTOM_LLM_BASE_URL = os.getenv("CUSTOM_LLM_BASE_URL", "").strip()
CUSTOM_LLM_API_KEY = os.getenv("CUSTOM_LLM_API_KEY", "").strip()
CUSTOM_LLM_MODEL = os.getenv("CUSTOM_LLM_MODEL", "default").strip()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip().replace("\xa0", "")
GEMINI_IMAGE_MODEL = os.getenv("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image-preview").strip()
# Image engine priority for generate_and_save_image. "auto" follows the
# configured default order before falling back to the procedural SVG.
DEFAULT_IMAGE_ENGINE_ORDER = "cloudflare,gemini,codex,tavily"
IMAGE_ENGINE_ORDER = os.getenv("IMAGE_ENGINE_ORDER", DEFAULT_IMAGE_ENGINE_ORDER).strip().lower() or DEFAULT_IMAGE_ENGINE_ORDER
if IMAGE_ENGINE_ORDER in ("auto", "default"):
    IMAGE_ENGINE_ORDER = DEFAULT_IMAGE_ENGINE_ORDER
CLOUDFLARE_ACCOUNT_ID = os.getenv("CLOUDFLARE_ACCOUNT_ID", "").strip()
CLOUDFLARE_API_TOKEN = os.getenv("CLOUDFLARE_API_TOKEN", "").strip()
CLOUDFLARE_IMAGE_MODEL = os.getenv("CLOUDFLARE_IMAGE_MODEL", "@cf/black-forest-labs/flux-1-schnell").strip()
OPENAI_IMAGE_KEY = os.getenv("OPENAI_IMAGE_KEY", "").strip() or os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "dall-e-3").strip()
CUSTOM_IMAGE_URL = os.getenv("CUSTOM_IMAGE_URL", "").strip()
CUSTOM_IMAGE_KEY = os.getenv("CUSTOM_IMAGE_KEY", "").strip()
CUSTOM_IMAGE_MODEL = os.getenv("CUSTOM_IMAGE_MODEL", "default").strip()

PREFERRED_PROVIDER = os.getenv("PREFERRED_PROVIDER", "mistral").strip().lower()
GROQ_MODEL = os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b").strip()
MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "ministral-14b-latest").strip()
DRAFTING_MODEL = os.getenv("DRAFTING_MODEL", "").strip()
CRITIC_MODEL = os.getenv("CRITIC_MODEL", "").strip()
REQUIRE_EVIDENCE_PACK = os.getenv("REQUIRE_EVIDENCE_PACK", "false").strip().lower() in ("true", "1", "yes")
MAX_CRITIQUE_LOOPS = int(os.getenv("MAX_CRITIQUE_LOOPS", "2").strip() or 2)
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "").strip()
CODEX_AUTH_PATH = os.getenv("CODEX_AUTH_PATH", str(Path.home() / ".codex" / "auth.json")).strip()
CODEX_SESSION_TOKEN = os.getenv("CODEX_SESSION_TOKEN", "").strip()
DEMO_WEBSITE_URL = os.getenv("DEMO_WEBSITE_URL", "http://127.0.0.1:8000").strip()
SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN", "").strip()
SLACK_APP_TOKEN = os.getenv("SLACK_APP_TOKEN", "").strip()
SLACK_CHANNEL_ID = os.getenv("SLACK_CHANNEL_ID", "").strip()
SLACK_SIGNING_SECRET = os.getenv("SLACK_SIGNING_SECRET", "").strip()
_default_db_init = BASE_DIR / "data" / "pipeline.db"
if not _default_db_init.exists() and (BASE_DIR / "pipeline.db").exists():
    _default_db_init = BASE_DIR / "pipeline.db"
DATABASE_URL = os.getenv("DATABASE_URL", str(_default_db_init)).strip()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000").strip()
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "").strip()
GITHUB_REPO = os.getenv("GITHUB_REPO", "").strip()
GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main").strip()
NEXTJS_PUBLIC_DIR = os.getenv("NEXTJS_PUBLIC_DIR", "").strip()

# ==========================================================================
# Measurement, Data Ingestion & Verification Subsystems
#
# Every subsystem degrades gracefully: when the relevant credentials are
# absent the adapter reports "unconfigured" instead of fabricating numbers.
# See pipeline/adapters/{analytics_client,ai_visibility,serp_client,
# backlink_analyzer,technical_audit,embedding_client,knowledge_graph}.py
# ==========================================================================


def _env_str(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip().replace("\xa0", "")


def _env_bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("true", "1", "yes", "on")


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.getenv(name, str(default)).strip()))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        return default


# Canonical list of measurement settings: name -> (parser, default).
# Declared once so module globals and reload_config() can never drift apart.
_MEASUREMENT_KEYS = {
    # IndexNow (instant crawl notification)
    "INDEXNOW_KEY": (_env_str, ""),
    "INDEXNOW_KEY_LOCATION": (_env_str, ""),
    # Google Search Console / GA4 (OAuth refresh-token flow, httpx only)
    "GSC_SITE_URL": (_env_str, ""),
    "GA4_PROPERTY_ID": (_env_str, ""),
    "GOOGLE_OAUTH_CLIENT_ID": (_env_str, ""),
    "GOOGLE_OAUTH_CLIENT_SECRET": (_env_str, ""),
    "GOOGLE_OAUTH_REFRESH_TOKEN": (_env_str, ""),
    "GOOGLE_ACCESS_TOKEN": (_env_str, ""),
    "GOOGLE_SERVICE_ACCOUNT_JSON": (_env_str, ""),
    # Plausible / PostHog (single API key analytics)
    "PLAUSIBLE_API_KEY": (_env_str, ""),
    "PLAUSIBLE_SITE_ID": (_env_str, ""),
    "PLAUSIBLE_HOST": (_env_str, "https://plausible.io"),
    "POSTHOG_API_KEY": (_env_str, ""),
    "POSTHOG_PROJECT_ID": (_env_str, ""),
    "POSTHOG_HOST": (_env_str, "https://app.posthog.com"),
    # SERP providers (live competitor footprints + rank tracking)
    "SERPER_API_KEY": (_env_str, ""),
    "DATAFORSEO_LOGIN": (_env_str, ""),
    "DATAFORSEO_PASSWORD": (_env_str, ""),
    "SERP_DEPTH": (_env_int, 10),
    # Backlink intelligence
    "OPENPAGERANK_API_KEY": (_env_str, ""),
    # AI visibility measurement (generative engine citations)
    "PERPLEXITY_API_KEY": (_env_str, ""),
    "OPENROUTER_API_KEY": (_env_str, ""),
    "AI_VISIBILITY_PROVIDER": (_env_str, "auto"),
    "AI_VISIBILITY_QUERY_LIMIT": (_env_int, 25),
    # Embeddings for dense retrieval / GraphRAG
    "EMBEDDING_PROVIDER": (_env_str, "auto"),
    "EMBEDDING_API_KEY": (_env_str, ""),
    "EMBEDDING_MODEL": (_env_str, ""),
    "EMBEDDING_BASE_URL": (_env_str, ""),
    # Technical audit (Core Web Vitals via PageSpeed Insights)
    "PAGESPEED_API_KEY": (_env_str, ""),
    "TECHNICAL_AUDIT_MAX_PAGES": (_env_int, 25),
    # Scheduled performance harvesting (closed-loop auditing)
    "PERFORMANCE_HARVEST_ENABLED": (_env_bool, True),
    "PERFORMANCE_HARVEST_INTERVAL_HOURS": (_env_int, 24),
    # A1.4 Keyword Opportunity Scoring Formula Weights & Thresholds
    "KEYWORD_FEASIBILITY_K": (_env_float, 10.0),
    "KEYWORD_FIT_W1": (_env_float, 0.50),  # Cosine similarity weight
    "KEYWORD_FIT_W2": (_env_float, 0.35),  # Search intent weight
    "KEYWORD_FIT_W3": (_env_float, 0.15),  # Manual boost weight
    "KEYWORD_MIN_BUSINESS_FIT": (_env_float, 0.30),  # Minimum business fit threshold
    "KEYWORD_AI_OVERVIEW_PENALTY": (_env_float, 0.30),  # AI Overview CTR reduction
    "KEYWORD_FEATURED_SNIPPET_PENALTY": (_env_float, 0.15),  # Featured snippet CTR reduction
    # A1.5 SERP Overlap Clustering & Shortlisting
    "KEYWORD_SERP_OVERLAP_THRESHOLD": (_env_int, 3),  # Min shared top-10 URLs to cluster together
    "KEYWORD_CLUSTER_MAX_SHORTLIST": (_env_int, 300),  # Top candidates to fetch SERP top 10
}


def _load_measurement_settings() -> dict:
    """Reads all measurement settings from the environment into module globals."""
    values = {name: parser(name, default) for name, (parser, default) in _MEASUREMENT_KEYS.items()}
    globals().update(values)
    return values


_load_measurement_settings()

# Publishing & Human-in-the-Loop Gate Settings
AUTO_PUBLISH_APPROVED = os.getenv("AUTO_PUBLISH_APPROVED", "false").strip().lower() in ("true", "1", "yes")
REQUIRE_HUMAN_GATE = os.getenv("REQUIRE_HUMAN_GATE", "true").strip().lower() in ("true", "1", "yes")
AUTO_PUBLISH_APPROVED = AUTO_PUBLISH_APPROVED and not REQUIRE_HUMAN_GATE
GENERATE_SOCIAL_ASSETS = os.getenv("GENERATE_SOCIAL_ASSETS", "true").strip().lower() in ("true", "1", "yes")

# Notification Preferences
NOTIFY_REVIEW_NEEDED = os.getenv("NOTIFY_REVIEW_NEEDED", "true").strip().lower() in ("true", "1", "yes")
NOTIFY_PUBLISHED = os.getenv("NOTIFY_PUBLISHED", "true").strip().lower() in ("true", "1", "yes")
NOTIFY_SLACK_SYNC = os.getenv("NOTIFY_SLACK_SYNC", "true").strip().lower() in ("true", "1", "yes")



_config_lock = threading.RLock()


def reload_config():
    """
    Dynamically reloads environment variables from .env (overriding in-memory values)
    and updates global config variables.

    Serialized with a lock: the studio runs sync endpoints in a threadpool, so
    two concurrent reloads could otherwise interleave half-updated module state.
    """
    with _config_lock:
        return _reload_config_locked()


def _reload_config_locked():
    global GROQ_API_KEY, MISTRAL_API_KEY, PREFERRED_PROVIDER, GROQ_MODEL, MISTRAL_MODEL
    global OPENAI_API_KEY, OPENAI_MODEL, ANTHROPIC_API_KEY, ANTHROPIC_MODEL
    global QWEN_API_KEY, QWEN_MODEL, GLM_API_KEY, GLM_MODEL, KIMI_API_KEY, KIMI_MODEL
    global DEEPSEEK_API_KEY, DEEPSEEK_MODEL, CUSTOM_LLM_BASE_URL, CUSTOM_LLM_API_KEY, CUSTOM_LLM_MODEL
    global GEMINI_API_KEY, GEMINI_IMAGE_MODEL, IMAGE_ENGINE_ORDER
    global CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN, CLOUDFLARE_IMAGE_MODEL
    global OPENAI_IMAGE_KEY, OPENAI_IMAGE_MODEL, CUSTOM_IMAGE_URL, CUSTOM_IMAGE_KEY, CUSTOM_IMAGE_MODEL
    global TAVILY_API_KEY, CODEX_AUTH_PATH, CODEX_SESSION_TOKEN, DEMO_WEBSITE_URL
    global SLACK_BOT_TOKEN, SLACK_APP_TOKEN, SLACK_CHANNEL_ID, SLACK_SIGNING_SECRET, DATABASE_URL
    global PUBLIC_BASE_URL, GITHUB_TOKEN, GITHUB_REPO, GITHUB_BRANCH, NEXTJS_PUBLIC_DIR
    global AUTO_PUBLISH_APPROVED, REQUIRE_HUMAN_GATE, GENERATE_SOCIAL_ASSETS
    global INDEXNOW_KEY, INDEXNOW_KEY_LOCATION
    global NOTIFY_REVIEW_NEEDED, NOTIFY_PUBLISHED, NOTIFY_SLACK_SYNC


    env_path = BASE_DIR / ".env"
    if env_path.exists():
        load_dotenv(env_path, override=True)

    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()
    MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "").strip()
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o").strip()
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
    ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-7-sonnet-20250219").strip()
    QWEN_API_KEY = os.getenv("QWEN_API_KEY", "").strip() or os.getenv("DASHSCOPE_API_KEY", "").strip()
    QWEN_MODEL = os.getenv("QWEN_MODEL", "qwen-plus").strip()
    GLM_API_KEY = os.getenv("GLM_API_KEY", "").strip() or os.getenv("ZHIPU_API_KEY", "").strip()
    GLM_MODEL = os.getenv("GLM_MODEL", "glm-4-flash").strip()
    KIMI_API_KEY = os.getenv("KIMI_API_KEY", "").strip() or os.getenv("MOONSHOT_API_KEY", "").strip()
    KIMI_MODEL = os.getenv("KIMI_MODEL", "moonshot-v1-8k").strip()
    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()
    DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat").strip()
    CUSTOM_LLM_BASE_URL = os.getenv("CUSTOM_LLM_BASE_URL", "").strip()
    CUSTOM_LLM_API_KEY = os.getenv("CUSTOM_LLM_API_KEY", "").strip()
    CUSTOM_LLM_MODEL = os.getenv("CUSTOM_LLM_MODEL", "default").strip()

    valid_providers = [
        "mistral", "groq", "openai", "claude", "anthropic",
        "qwen", "glm", "kimi", "deepseek", "custom"
    ]
    pref = os.getenv("PREFERRED_PROVIDER", "").strip().lower()
    if pref in valid_providers:
        PREFERRED_PROVIDER = "claude" if pref == "anthropic" else pref
    elif MISTRAL_API_KEY:
        PREFERRED_PROVIDER = "mistral"
    elif GROQ_API_KEY:
        PREFERRED_PROVIDER = "groq"
    elif OPENAI_API_KEY:
        PREFERRED_PROVIDER = "openai"
    elif ANTHROPIC_API_KEY:
        PREFERRED_PROVIDER = "claude"
    elif QWEN_API_KEY:
        PREFERRED_PROVIDER = "qwen"
    elif GLM_API_KEY:
        PREFERRED_PROVIDER = "glm"
    elif KIMI_API_KEY:
        PREFERRED_PROVIDER = "kimi"
    elif DEEPSEEK_API_KEY:
        PREFERRED_PROVIDER = "deepseek"
    elif CUSTOM_LLM_BASE_URL:
        PREFERRED_PROVIDER = "custom"
    else:
        PREFERRED_PROVIDER = "mistral"

    GROQ_MODEL = os.getenv("GROQ_MODEL", "qwen/qwen3.8-27b").strip()
    MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "ministral-14b-latest").strip()
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip().replace("\xa0", "")
    GEMINI_IMAGE_MODEL = os.getenv("GEMINI_IMAGE_MODEL", "gemini-3.1-flash-image-preview").strip()
    IMAGE_ENGINE_ORDER = os.getenv("IMAGE_ENGINE_ORDER", DEFAULT_IMAGE_ENGINE_ORDER).strip().lower() or DEFAULT_IMAGE_ENGINE_ORDER
    if IMAGE_ENGINE_ORDER in ("auto", "default"):
        IMAGE_ENGINE_ORDER = DEFAULT_IMAGE_ENGINE_ORDER
    CLOUDFLARE_ACCOUNT_ID = os.getenv("CLOUDFLARE_ACCOUNT_ID", "").strip()
    CLOUDFLARE_API_TOKEN = os.getenv("CLOUDFLARE_API_TOKEN", "").strip()
    CLOUDFLARE_IMAGE_MODEL = os.getenv("CLOUDFLARE_IMAGE_MODEL", "@cf/black-forest-labs/flux-1-schnell").strip()
    OPENAI_IMAGE_KEY = os.getenv("OPENAI_IMAGE_KEY", "").strip() or os.getenv("OPENAI_API_KEY", "").strip()
    OPENAI_IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "dall-e-3").strip()
    CUSTOM_IMAGE_URL = os.getenv("CUSTOM_IMAGE_URL", "").strip()
    CUSTOM_IMAGE_KEY = os.getenv("CUSTOM_IMAGE_KEY", "").strip()
    CUSTOM_IMAGE_MODEL = os.getenv("CUSTOM_IMAGE_MODEL", "default").strip()

    TAVILY_API_KEY = os.getenv("TAVILY_API_KEY", "").strip()
    CODEX_AUTH_PATH = os.getenv("CODEX_AUTH_PATH", str(Path.home() / ".codex" / "auth.json")).strip()
    CODEX_SESSION_TOKEN = os.getenv("CODEX_SESSION_TOKEN", "").strip()
    DEMO_WEBSITE_URL = os.getenv("DEMO_WEBSITE_URL", "http://127.0.0.1:8000").strip()
    SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN", "").strip()
    SLACK_APP_TOKEN = os.getenv("SLACK_APP_TOKEN", "").strip()
    SLACK_CHANNEL_ID = os.getenv("SLACK_CHANNEL_ID", "").strip()
    SLACK_SIGNING_SECRET = os.getenv("SLACK_SIGNING_SECRET", "").strip()
    default_db = BASE_DIR / "data" / "pipeline.db"
    if not default_db.exists() and (BASE_DIR / "pipeline.db").exists():
        default_db = BASE_DIR / "pipeline.db"
    DATABASE_URL = os.getenv("DATABASE_URL", str(default_db)).strip()
    PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000").strip()
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "").strip()
    GITHUB_REPO = os.getenv("GITHUB_REPO", "").strip()
    GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main").strip()
    NEXTJS_PUBLIC_DIR = os.getenv("NEXTJS_PUBLIC_DIR", "").strip()

    measurement_values = _load_measurement_settings()

    # Publishing and Pipeline Policy
    auto_pub = os.getenv("AUTO_PUBLISH_APPROVED", "false").strip().lower()
    AUTO_PUBLISH_APPROVED = auto_pub in ("true", "1", "yes")

    req_gate = os.getenv("REQUIRE_HUMAN_GATE", "true").strip().lower()
    REQUIRE_HUMAN_GATE = req_gate in ("true", "1", "yes")
    AUTO_PUBLISH_APPROVED = AUTO_PUBLISH_APPROVED and not REQUIRE_HUMAN_GATE

    gen_soc = os.getenv("GENERATE_SOCIAL_ASSETS", "true").strip().lower()
    GENERATE_SOCIAL_ASSETS = gen_soc in ("true", "1", "yes")

    notif_rev = os.getenv("NOTIFY_REVIEW_NEEDED", "true").strip().lower()
    NOTIFY_REVIEW_NEEDED = notif_rev in ("true", "1", "yes")

    notif_pub = os.getenv("NOTIFY_PUBLISHED", "true").strip().lower()
    NOTIFY_PUBLISHED = notif_pub in ("true", "1", "yes")

    notif_slack = os.getenv("NOTIFY_SLACK_SYNC", "true").strip().lower()
    NOTIFY_SLACK_SYNC = notif_slack in ("true", "1", "yes")

    return {
        "GROQ_API_KEY": GROQ_API_KEY,
        "MISTRAL_API_KEY": MISTRAL_API_KEY,
        "OPENAI_API_KEY": OPENAI_API_KEY,
        "OPENAI_MODEL": OPENAI_MODEL,
        "ANTHROPIC_API_KEY": ANTHROPIC_API_KEY,
        "ANTHROPIC_MODEL": ANTHROPIC_MODEL,
        "QWEN_API_KEY": QWEN_API_KEY,
        "QWEN_MODEL": QWEN_MODEL,
        "GLM_API_KEY": GLM_API_KEY,
        "GLM_MODEL": GLM_MODEL,
        "KIMI_API_KEY": KIMI_API_KEY,
        "KIMI_MODEL": KIMI_MODEL,
        "DEEPSEEK_API_KEY": DEEPSEEK_API_KEY,
        "DEEPSEEK_MODEL": DEEPSEEK_MODEL,
        "CUSTOM_LLM_BASE_URL": CUSTOM_LLM_BASE_URL,
        "CUSTOM_LLM_API_KEY": CUSTOM_LLM_API_KEY,
        "CUSTOM_LLM_MODEL": CUSTOM_LLM_MODEL,
        "GEMINI_API_KEY": GEMINI_API_KEY,
        "GEMINI_IMAGE_MODEL": GEMINI_IMAGE_MODEL,
        "IMAGE_ENGINE_ORDER": IMAGE_ENGINE_ORDER,
        "CLOUDFLARE_ACCOUNT_ID": CLOUDFLARE_ACCOUNT_ID,
        "CLOUDFLARE_API_TOKEN": CLOUDFLARE_API_TOKEN,
        "CLOUDFLARE_IMAGE_MODEL": CLOUDFLARE_IMAGE_MODEL,
        "OPENAI_IMAGE_KEY": OPENAI_IMAGE_KEY,
        "OPENAI_IMAGE_MODEL": OPENAI_IMAGE_MODEL,
        "CUSTOM_IMAGE_URL": CUSTOM_IMAGE_URL,
        "CUSTOM_IMAGE_KEY": CUSTOM_IMAGE_KEY,
        "CUSTOM_IMAGE_MODEL": CUSTOM_IMAGE_MODEL,
        "PREFERRED_PROVIDER": PREFERRED_PROVIDER,
        "GROQ_MODEL": GROQ_MODEL,
        "MISTRAL_MODEL": MISTRAL_MODEL,
        "TAVILY_API_KEY": TAVILY_API_KEY,
        "CODEX_AUTH_PATH": CODEX_AUTH_PATH,
        "CODEX_SESSION_TOKEN": CODEX_SESSION_TOKEN,
        "DEMO_WEBSITE_URL": DEMO_WEBSITE_URL,
        "SLACK_BOT_TOKEN": SLACK_BOT_TOKEN,
        "SLACK_APP_TOKEN": SLACK_APP_TOKEN,
        "SLACK_CHANNEL_ID": SLACK_CHANNEL_ID,
        "SLACK_SIGNING_SECRET": SLACK_SIGNING_SECRET,
        "DATABASE_URL": DATABASE_URL,
        "PUBLIC_BASE_URL": PUBLIC_BASE_URL,
        "GITHUB_TOKEN": GITHUB_TOKEN,
        "GITHUB_REPO": GITHUB_REPO,
        "GITHUB_BRANCH": GITHUB_BRANCH,
        "NEXTJS_PUBLIC_DIR": NEXTJS_PUBLIC_DIR,
        "AUTO_PUBLISH_APPROVED": "true" if AUTO_PUBLISH_APPROVED else "false",
        "REQUIRE_HUMAN_GATE": "true" if REQUIRE_HUMAN_GATE else "false",
        "GENERATE_SOCIAL_ASSETS": "true" if GENERATE_SOCIAL_ASSETS else "false",
        "NOTIFY_REVIEW_NEEDED": "true" if NOTIFY_REVIEW_NEEDED else "false",
        "NOTIFY_PUBLISHED": "true" if NOTIFY_PUBLISHED else "false",
        "NOTIFY_SLACK_SYNC": "true" if NOTIFY_SLACK_SYNC else "false",
        **measurement_values
    }



def update_env_file(key_values: dict):
    """
    Updates or inserts keys in .env, immediately updates os.environ,
    and calls reload_config().
    """
    env_path = BASE_DIR / ".env"
    existing_lines = []
    if env_path.exists():
        with open(env_path, "r", encoding="utf-8") as f:
            existing_lines = f.readlines()

    clean_updates = {k: str(v).strip().replace("\xa0", "") for k, v in key_values.items() if v is not None}
    updated_keys = set()
    new_lines = []

    for line in existing_lines:
        trimmed = line.strip()
        if trimmed and not trimmed.startswith("#") and "=" in trimmed:
            k, _ = trimmed.split("=", 1)
            k = k.strip()
            if k in clean_updates:
                new_lines.append(f"{k}={clean_updates[k]}\n")
                updated_keys.add(k)
                continue
        new_lines.append(line)

    for k, v in clean_updates.items():
        if k not in updated_keys:
            new_lines.append(f"{k}={v}\n")

    # Safe rolling backup in .backups/ (retains last 10 snapshots)
    if env_path.exists() and env_path.stat().st_size > 0:
        try:
            backup_dir = BASE_DIR / ".backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            shutil.copy2(env_path, backup_dir / f"env_{ts}.bak")
            past_backups = sorted(backup_dir.glob("env_*.bak"), key=lambda p: p.stat().st_mtime)
            if len(past_backups) > 10:
                for old_b in past_backups[:-10]:
                    try:
                        old_b.unlink()
                    except Exception:
                        pass
        except Exception:
            pass

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

    # Immediately push into process environment so all running modules see it without restart
    for k, v in clean_updates.items():
        os.environ[k] = v

    return reload_config()


# Initial load at import time
reload_config()
