"""
Unit tests for Autonomous Internal Linking & Topic Cluster Engine.
"""

import pytest
from pipeline.adapters.internal_linker import (
    get_cluster_candidates,
    build_internal_linking_prompt,
    verify_and_inject_internal_links,
    extract_topic_cluster_summary,
)


def test_build_internal_linking_prompt():
    candidates = [
        {
            "title": "Retro Revival Crisis in Gaming",
            "slug": "retro-revival-crisis-gaming",
            "similarity": 0.75,
        },
        {
            "title": "AI Generated Characters in Unreal Engine",
            "slug": "ai-generated-characters-unreal-engine",
            "similarity": 0.62,
        },
    ]

    prompt = build_internal_linking_prompt(candidates)
    assert "TOPICAL CLUSTER & INTERNAL LINKING ARCHITECTURE" in prompt
    assert "[Retro Revival Crisis in Gaming](/posts/retro-revival-crisis-gaming)" in prompt
    assert "[AI Generated Characters in Unreal Engine](/posts/ai-generated-characters-unreal-engine)" in prompt
    assert "STRICT LINKING RULES" in prompt


def test_verify_and_inject_internal_links_validates_existing():
    candidates = [
        {
            "title": "AI Characters",
            "slug": "ai-characters-2026",
            "similarity": 0.8,
        }
    ]

    draft = """# The Next Frontier
This article connects with our previous work on [autonomous NPCs](/posts/ai-characters-2026).
"""

    cleaned_draft, links = verify_and_inject_internal_links(draft, candidates)
    assert len(links) == 1
    assert links[0]["slug"] == "ai-characters-2026"
    assert links[0]["verified"] is True
    assert "[autonomous NPCs](/posts/ai-characters-2026)" in cleaned_draft


def test_verify_and_inject_internal_links_cleans_broken_slugs():
    candidates = [
        {
            "title": "Valid Post",
            "slug": "valid-post-slug",
            "similarity": 0.8,
        }
    ]

    # LLM hallucinated a non-existent slug
    draft = """# Physics Breakdown
Learn more in this [broken guide](/posts/non-existent-hallucinated-slug-12345).
"""

    cleaned_draft, links = verify_and_inject_internal_links(draft, candidates)
    # Broken link should have been stripped to plain text to avoid 404
    assert "/posts/non-existent-hallucinated-slug-12345" not in cleaned_draft
    assert "broken guide" in cleaned_draft


def test_verify_and_inject_internal_links_fallback():
    candidates = [
        {
            "title": "Related Game Tech",
            "slug": "related-game-tech",
            "similarity": 0.7,
        }
    ]

    # Draft with NO internal links
    draft = """# Physics and Simulation
Games use rigid body simulations extensively.

## Conclusion
Physics will remain essential.
"""

    cleaned_draft, links = verify_and_inject_internal_links(draft, candidates, min_links=1)
    assert len(links) >= 1
    assert "Related Topic Cluster Analyses" in cleaned_draft
    assert "[Related Game Tech](/posts/related-game-tech)" in cleaned_draft


def test_extract_topic_cluster_summary():
    draft = """# Master Guide to Physics
Deep technical content here...
We explored this in [AI Characters](/posts/ai-characters-slug) and [Engine Architecture](/posts/engine-arch-slug).
""" + (" long paragraph content words " * 400)

    summary = extract_topic_cluster_summary(
        draft=draft,
        title="Master Guide to Physics",
        slug="master-guide-to-physics"
    )

    assert summary["outbound_count"] == 2
    assert summary["is_pillar"] is True
    assert summary["cluster_role"] == "Pillar Authority Guide"
    assert summary["cluster_health_score"] >= 80
