"""
Offline tests for the Gemini image generation adapter (no network access).

Verifies:
1. Engine selection: with a key present, generate_and_save_image uses Gemini
   first and stores its asset.
2. Response parsing: inlineData base64 payload is decoded and saved as .png.
3. Graceful degradation: a Gemini failure falls back to the next engine.
"""

import base64
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

FAKE_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 2048


class FakeGeminiResponse:
    status_code = 200
    text = ""

    def json(self):
        return {
            "candidates": [
                {
                    "content": {
                        "parts": [
                            {
                                "inlineData": {
                                    "mimeType": "image/png",
                                    "data": base64.b64encode(FAKE_PNG).decode(),
                                }
                            }
                        ]
                    }
                }
            ]
        }


class FakeFailResponse:
    status_code = 503
    text = "service unavailable"

    def json(self):
        return {}


@pytest.fixture
def gemini_key(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "test-key-offline")
    # Reload adapter config values that were cached at import time
    import config
    monkeypatch.setattr(config, "GEMINI_API_KEY", "test-key-offline", raising=False)
    return "test-key-offline"


def test_gemini_engine_selected_and_png_saved(gemini_key, tmp_path):
    from pipeline.adapters import codex_image, gemini_image

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def post(self, *a, **k):
            return FakeGeminiResponse()

    # Redirect uploads to a temp dir so tests don't write real assets
    monkey_tmp = tmp_path / "uploads"
    monkey_tmp.mkdir()
    with patch_uploads_dir(monkey_tmp):
        with patch_object(gemini_image.httpx, "Client", FakeClient):
            asset = codex_image.generate_and_save_image(prompt="editorial art", slug="pytest-gemini")

    assert asset["engine"] == "google_gemini"
    assert asset["model"] == "gemini-3.1-flash-image-preview"
    assert asset["hero_image_url"].startswith("/static/uploads/")
    assert asset["hero_image_url"].endswith(".png")


def test_gemini_failure_falls_back(gemini_key, tmp_path):
    from pipeline.adapters import codex_image, gemini_image

    class FakeClient:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def get(self, *a, **k):
            # Pollinations fallback returns a valid image
            resp = FakeGeminiResponse.__new__(FakeGeminiResponse)
            resp.status_code = 200
            resp.headers = {"content-type": "image/jpeg"}
            resp.content = b"\xff\xd8\xff\xe0" + b"\x00" * 2048
            resp.text = ""
            return resp

        def json(self):
            return {}

        def post(self, *a, **k):
            return FakeFailResponse()

    monkey_tmp = tmp_path / "uploads"
    monkey_tmp.mkdir()
    with patch_uploads_dir(monkey_tmp):
        with patch_object(gemini_image.httpx, "Client", FakeClient):
            with patch_object(__import__("pipeline.adapters.codex_image", fromlist=["httpx"]).httpx, "Client", FakeClient):
                asset = codex_image.generate_and_save_image(prompt="editorial art", slug="pytest-gemini-fb")

    # Gemini must fail; a fallback engine must still deliver an asset
    assert asset["engine"] != "google_gemini"
    assert Path(asset["hero_image_path"]).exists()


def test_tavily_free_stock_image_success(tmp_path):
    from pipeline.adapters import codex_image

    class FakeTavilyClient:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def post(self, url, **kwargs):
            class FakeTavilyResp:
                status_code = 200
                text = ""

                def json(self):
                    return {"images": ["https://images.unsplash.com/photo-123456?auto=format"]}

            return FakeTavilyResp()

        def get(self, url, **kwargs):
            class FakeImgResp:
                status_code = 200
                headers = {"content-type": "image/jpeg"}
                content = b"\xff\xd8\xff\xe0" + b"\x00" * 6000

            return FakeImgResp()

    with patch_object(codex_image.httpx, "Client", FakeTavilyClient):
        with patch_object(codex_image.config, "TAVILY_API_KEY", "tvly-test-valid-key"):
            res = codex_image.search_tavily_free_stock_image("modern game architecture", "game-arch")
            assert res is not None
            image_bytes, source_url, model = res
            assert len(image_bytes) > 5000
            assert "unsplash" in source_url
            assert model == "tavily-unsplash"


# --- helpers -------------------------------------------------------------

def patch_uploads_dir(target: Path):
    from pipeline.adapters import codex_image
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        old = codex_image.UPLOADS_DIR
        codex_image.UPLOADS_DIR = target
        try:
            yield
        finally:
            codex_image.UPLOADS_DIR = old

    return _ctx()


def patch_object(obj, name, value):
    import contextlib

    @contextlib.contextmanager
    def _ctx():
        old = getattr(obj, name)
        setattr(obj, name, value)
        try:
            yield
        finally:
            setattr(obj, name, old)

    return _ctx()
