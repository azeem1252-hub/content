"""
Unit tests for Semantic Entity Matcher & Anti-Cannibalization Engine.
Verifies the cosine similarity calculation and threshold branching (>= 0.82).
"""

import pytest
from pipeline.adapters.semantic_matcher import (
    cosine_similarity,
    build_term_vector,
    evaluate_anti_cannibalization,
    CANNIBALIZATION_THRESHOLD
)


def test_cosine_similarity_identical_vectors():
    vec_a = [0.5, 0.5, 0.5, 0.5]
    vec_b = [0.5, 0.5, 0.5, 0.5]
    sim = cosine_similarity(vec_a, vec_b)
    assert abs(sim - 1.0) < 1e-4


def test_cosine_similarity_orthogonal_vectors():
    vec_a = [1.0, 0.0]
    vec_b = [0.0, 1.0]
    sim = cosine_similarity(vec_a, vec_b)
    assert abs(sim - 0.0) < 1e-4


def test_anti_cannibalization_detects_entity_gap():
    existing_posts = [
        {
            "id": 1,
            "title": "Autonomous Fact-Verified Article Production with LangGraph",
            "slug": "autonomous-fact-verified-article-production-langgraph",
            "excerpt": "A deep architectural guide to compiling verified articles."
        },
        {
            "id": 2,
            "title": "Next.js 15 Server Components and Supabase Storage",
            "slug": "nextjs-15-server-components-supabase",
            "excerpt": "Zero-dependency static publishing with Next.js."
        }
    ]

    # Closely related candidate topic: should trigger Entity Gap (similarity >= 0.82)
    candidate = "Autonomous Fact-Verified Article Production with LangGraph and Tavily"
    result = evaluate_anti_cannibalization(candidate, existing_posts, threshold=CANNIBALIZATION_THRESHOLD)

    assert result["is_entity_gap"] is True
    assert result["recommendation"] == "refresh_existing"
    assert result["matched_post_id"] == 1
    assert result["max_similarity"] >= CANNIBALIZATION_THRESHOLD


def test_anti_cannibalization_permits_novel_topic():
    existing_posts = [
        {
            "id": 1,
            "title": "Autonomous Fact-Verified Article Production with LangGraph",
            "slug": "autonomous-fact-verified-article-production-langgraph",
            "excerpt": "Programmatic article compilation."
        }
    ]

    # Novel, unrelated topic: should trigger new article creation (similarity < 0.82)
    candidate = "Decoupled PostgreSQL Checkpointing in Distributed Temporal Workflows"
    result = evaluate_anti_cannibalization(candidate, existing_posts, threshold=CANNIBALIZATION_THRESHOLD)

    assert result["is_entity_gap"] is False
    assert result["recommendation"] == "create_new"
    assert result["max_similarity"] < CANNIBALIZATION_THRESHOLD
