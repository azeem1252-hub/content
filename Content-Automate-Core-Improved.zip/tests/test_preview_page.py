"""
Offline test for the pre-publish draft preview page (/preview/{thread_id}).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi.testclient import TestClient

from web.app import app
from storage.db import init_db, save_pipeline_run


def test_preview_page_renders_draft():
    init_db()
    thread_id = "pytest-preview-001"
    save_pipeline_run(
        thread_id=thread_id,
        topic="Preview Test Article",
        status="review_pending",
        state_json=None,
    )
    # Persist a realistic paused-at-review state
    from storage.db import update_pipeline_run_status
    update_pipeline_run_status(thread_id, "review_pending", {
        "title": "Preview Test Article",
        "draft": "# Preview Test Article\n\nHello draft body.",
        "slug": "preview-test-article",
        "meta_description": "A preview test.",
        "hero_image_url": "/static/uploads/preview-test.jpg",
        "tags": ["testing"],
        "seo_score": 88,
        "word_count": 12,
        "read_time": 1,
        "revision_count": 1,
        "audit_notes": "Looks solid.",
    })

    with TestClient(app) as client:
        res = client.get(f"/preview/{thread_id}")
        assert res.status_code == 200
        html = res.text
        assert "Preview Test Article" in html
        assert "Draft Preview" in html
        assert "88/100" in html
        assert "Hello draft body." in html

        # Unknown thread -> 404
        res_missing = client.get("/preview/does-not-exist")
        assert res_missing.status_code == 404


def test_preview_page_without_draft():
    init_db()
    thread_id = "pytest-preview-empty"
    save_pipeline_run(
        thread_id=thread_id,
        topic="Empty Draft Article",
        status="running",
        state_json=None,
    )

    with TestClient(app) as client:
        res = client.get(f"/preview/{thread_id}")
        assert res.status_code == 404
        assert "No draft available" in res.text
