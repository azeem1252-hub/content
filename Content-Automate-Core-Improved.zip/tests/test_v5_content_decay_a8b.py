"""
Tests for Pillar A8b: Content Decay & Update Agent.
"""

from datetime import datetime, timedelta
import pytest

from pipeline.adapters.content_decay import (
    check_metric_breakpoints,
    detect_page_decay,
    diagnose_decay_signature,
    run_page_audit,
    prioritize_update_portfolio,
    generate_update_change_set
)
import storage.db as db


def test_metric_breakpoint_checking():
    # September 12, 2025 Google num=100 deprecation breakpoint
    bps = check_metric_breakpoints("2025-09-01", "2025-09-30")
    assert len(bps) >= 1
    assert any("num=100" in bp["note"] for bp in bps)

    # Window outside breakpoint
    bps_none = check_metric_breakpoints("2026-01-01", "2026-01-31")
    assert len(bps_none) == 0


def test_diagnostic_classifier():
    # Ranking decay: position dropped from 5.0 to 9.5
    decay_rank = {
        "curr_clicks": 120, "prior_clicks": 280,
        "curr_impressions": 4000, "prior_impressions": 4200,
        "curr_avg_position": 9.5, "prior_avg_position": 5.0,
        "clicks_drop_pct": 57.1
    }
    diag, conf, expl = diagnose_decay_signature(decay_rank)
    assert diag == "ranking_decay"
    assert conf == "high"

    # CTR decay: impressions and position stable, clicks plunged
    decay_ctr = {
        "curr_clicks": 90, "prior_clicks": 250,
        "curr_impressions": 5000, "prior_impressions": 5200,
        "curr_avg_position": 4.1, "prior_avg_position": 4.0,
        "clicks_drop_pct": 64.0
    }
    diag_c, conf_c, expl_c = diagnose_decay_signature(decay_ctr)
    assert diag_c == "ctr_decay"

    # Demand decay: impressions and clicks fall together, position stable
    decay_dem = {
        "curr_clicks": 80, "prior_clicks": 200,
        "curr_impressions": 1800, "prior_impressions": 5000,
        "curr_avg_position": 3.8, "prior_avg_position": 3.7,
        "clicks_drop_pct": 60.0
    }
    diag_d, conf_d, expl_d = diagnose_decay_signature(decay_dem)
    assert diag_d == "demand_decay"


def test_run_page_audit():
    html_sample = """
    <h1>CRM Pricing in 2023</h1>
    <p>Salesforce costs $25/mo per user while HubSpot starts at $50/month.</p>
    <p>Over 45% of enterprise teams adopted this in 2022.</p>
    """
    findings = run_page_audit("site_decay_test", "https://example.com/crm", page_html=html_sample)
    types = [f["finding_type"] for f in findings]

    assert "outdated_dates" in types
    assert "outdated_pricing" in types
    assert "outdated_statistics" in types
    assert "missing_faq" in types
    assert "missing_schema" in types


def test_generate_update_change_set():
    site_id = "site_decay_test"
    url = "https://example.com/crm"
    # Ensure findings exist
    run_page_audit(site_id, url, page_html="<h1>CRM in 2022</h1><p>$49/mo</p>")

    res = generate_update_change_set(
        website_id=site_id,
        plan_id="plan_sample_1",
        url=url,
        current_content=""
    )
    assert res["total_changes"] >= 1
    assert res["date_recommendation"]["keep_date_published"] is True
    assert "date_recommendation" in res
