"""
Unit tests for Closed-Loop Performance Auditing & Self-Improving Feedback (Pillar VI).
"""

import pytest
from unittest.mock import patch
from pipeline.auditor import (
    triage_search_performance,
    triage_video_retention,
    optimize_low_ctr_headline
)


def test_triage_detects_page_two_plateau():
    # Position 14.2 (Page 2), high impressions (320)
    res = triage_search_performance(
        url="https://example.com/posts/ai-agent-guide",
        title="AI Agent Guide",
        impressions=320,
        clicks=8,
        average_position=14.2
    )
    assert res["workflow"] == "decay_reoptimization"
    assert res["action_required"] == "expand_entities"


def test_triage_detects_low_ctr():
    # Position 4.1 (Page 1), high impressions (800), only 4 clicks (CTR 0.5% < 1.5%)
    res = triage_search_performance(
        url="https://example.com/posts/ai-agent-guide",
        title="AI Agent Guide",
        impressions=800,
        clicks=4,
        average_position=4.1
    )
    assert res["workflow"] == "headline_optimization"
    assert res["action_required"] == "rewrite_metadata"


def test_triage_nominal_performance():
    # Good position (3.0), healthy CTR (4.0%)
    res = triage_search_performance(
        url="https://example.com/posts/ai-agent-guide",
        title="AI Agent Guide",
        impressions=1000,
        clicks=40,
        average_position=3.0
    )
    assert res["workflow"] == "nominal"


def test_triage_video_retention_alert():
    with patch("pipeline.auditor.append_memory_learning", return_value=True) as mock_append:
        res = triage_video_retention(
            video_title="Test Video",
            hook_3s="A boring opening phrase that nobody likes",
            views=150,
            three_second_retention_rate=0.22  # 22% < 30%
        )
        assert res["status"] == "calibrated"
        assert res["learning_recorded"] is True
        mock_append.assert_called_once()


def test_optimize_low_ctr_headline():
    mock_llm_json = """```json
    {
      "optimized_title": "AI Agents in 2026: Why 80% of Autonomous Pipelines Fail",
      "optimized_meta_description": "Architectural deconstruction of multi-agent workflows."
    }
    ```"""

    with patch("pipeline.auditor.call_llm", return_value=mock_llm_json):
        with patch("pipeline.auditor.append_memory_learning", return_value=True):
            res = optimize_low_ctr_headline(
                current_title="AI Agents Guide",
                topic="AI Agent Workflows",
                current_ctr=0.8
            )
            assert "Why 80% of Autonomous Pipelines Fail" in res["optimized_title"]
            assert "Architectural deconstruction" in res["optimized_meta_description"]
