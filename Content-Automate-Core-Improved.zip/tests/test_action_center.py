"""
Unit tests for the Action Center & Autonomous Execution Engine.
Validates the solutions to the 'Execution Gap' from:
'Anatomy of a Superior AI SEO Tool: A Blueprint for Closing the Execution Gap and Unifying Search Visibility'
"""

import pytest
from fastapi.testclient import TestClient
from storage.db import init_db, save_post, get_post_by_slug
from pipeline.adapters.action_center import scan_action_opportunities, execute_action_opportunity
from web.app import app


@pytest.fixture(autouse=True)
def setup_test_environment():
    init_db()


def test_scan_action_opportunities():
    # Insert a sample post with limited entity depth and no schema
    post_slug = "test-execution-gap-analysis"
    save_post(
        title="Test Execution Gap Analysis",
        content="This is a preliminary overview of why traditional SEO tools leave users with manual work.",
        slug=post_slug,
        excerpt="An analysis of the execution gap.",
        meta_title="Test Execution",
        status="published"
    )

    data = scan_action_opportunities()
    assert "opportunities" in data
    assert "summary" in data
    assert data["summary"]["potential_traffic_multiplier"] == "4.4x"
    assert data["summary"]["total_opportunities"] >= 1

    # Check that opportunities have all required operational fields
    opp_types = [o["type"] for o in data["opportunities"]]
    assert any(t in opp_types for t in ["citable_gap", "page2_plateau", "ctr_deficit", "llms_txt_sync"])


def test_execute_citable_alignment():
    post_slug = "test-citable-remediation"
    save_post(
        title="Autonomous Agent Systems in Enterprise",
        content="Initial short draft covering multi-agent architectures.",
        slug=post_slug,
        status="published"
    )

    res = execute_action_opportunity(
        opportunity_type="citable_gap",
        post_slug=post_slug
    )

    assert res["status"] == "success"
    assert res["opportunity_type"] == "citable_gap"
    assert res["new_citable_score"] >= 80

    # Verify database persistence
    updated = get_post_by_slug(post_slug)
    assert updated is not None
    assert "Canonical Architecture & Direct Answer" in updated["content"]
    assert "application/ld+json" in updated["content"]
    assert "Comparative Architectural Trade-offs" in updated["content"]


def test_execute_page2_plateau_expansion():
    post_slug = "test-plateau-expansion"
    save_post(
        title="High Scale Python Pipelines",
        content="Initial brief outline for python pipelines.",
        slug=post_slug,
        status="published"
    )

    res = execute_action_opportunity(
        opportunity_type="page2_plateau",
        post_slug=post_slug
    )

    assert res["status"] == "success"
    assert res["action"] == "entity_expansion_completed"

    updated = get_post_by_slug(post_slug)
    assert updated is not None
    assert "Advanced Technical Taxonomy & Entity Specifications" in updated["content"]
    assert "Deterministic Serialization" in updated["content"]


def test_execute_ctr_deficit_optimization():
    from unittest.mock import patch
    post_slug = "test-ctr-rewrite"
    save_post(
        title="SEO Guide",
        content="Detailed content about SEO best practices and technical optimizations.",
        slug=post_slug,
        meta_title="SEO Guide",
        status="published"
    )

    with patch("pipeline.auditor.call_llm", return_value='{"optimized_title": "SEO Guide: High-Performance Production Playbook (2026)", "optimized_meta_description": "Comprehensive guide to technical SEO."}'):
        res = execute_action_opportunity(
            opportunity_type="ctr_deficit",
            post_slug=post_slug
        )

    assert res["status"] == "success"
    assert res["action"] == "headline_optimized"
    assert "new_title" in res

    updated = get_post_by_slug(post_slug)
    assert updated is not None
    assert len(updated["meta_title"]) > len("SEO Guide")


def test_execute_llms_txt_sync():
    res = execute_action_opportunity(
        opportunity_type="llms_txt_sync",
        post_slug="_global_"
    )

    assert res["status"] == "success"
    assert res["action"] == "llms_txt_synced"
    assert len(res["synced_files"]) >= 1


def test_action_center_api_endpoints():
    client = TestClient(app)

    # 1. Opportunities endpoint
    resp = client.get("/api/action-center/opportunities")
    assert resp.status_code == 200
    data = resp.json()
    assert "opportunities" in data
    assert data["summary"]["potential_traffic_multiplier"] == "4.4x"

    # 2. 1-Click Execution endpoint for global llms.txt sync
    exec_resp = client.post("/api/action-center/execute", json={
        "opportunity_type": "llms_txt_sync",
        "post_slug": "_global_"
    })
    assert exec_resp.status_code == 200
    exec_data = exec_resp.json()
    assert exec_data["status"] == "success"
