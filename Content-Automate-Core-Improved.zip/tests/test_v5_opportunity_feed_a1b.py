"""
Tests for Pillar A1b: "What should I publish?" Opportunity Feed.
"""

import pytest
from pipeline.adapters.opportunity_feed import (
    _detect_template_type,
    _generate_title_from_template,
    _calculate_impact_range,
    _build_evidence_items_and_reason,
    generate_opportunity_feed,
    process_opportunity_feedback
)
import storage.db as db


def test_template_detection():
    assert _detect_template_type("hubspot vs salesforce") == "vs_comparison"
    assert _detect_template_type("how much does semrush cost") == "pricing_cost"
    assert _detect_template_type("top ahrefs alternatives") == "alternatives"
    assert _detect_template_type("is surfer seo worth it") == "worth_it"
    assert _detect_template_type("best crm software for small business") == "best_of"
    assert _detect_template_type("how to build an agent with langgraph") == "how_to"
    assert _detect_template_type("what is geo generative engine optimization") == "what_is"
    assert _detect_template_type("why do search engines use rag") == "ai_answer"


def test_title_formatting():
    profile = {"icp_descriptions": ["Developers"]}
    title_best = _generate_title_from_template("best_of", "best code editors", profile)
    assert "Best Code Editors for Developers" in title_best


    title_vs = _generate_title_from_template("vs_comparison", "claude vs gpt-4o")
    assert "Claude vs Gpt-4O: In-Depth Comparison & Benchmark" == title_vs

    title_cost = _generate_title_from_template("pricing_cost", "pricing cursor ai")
    assert "How Much Does Cursor Ai Cost?" in title_cost


def test_impact_range_uncertainty():
    min_clicks, max_clicks, conf = _calculate_impact_range(
        search_volume=1000,
        kd=25.0,
        serp_features=["people_also_ask"],
        has_aio=False
    )
    assert min_clicks > 0
    assert max_clicks > min_clicks
    assert conf == "high"

    # AI Overview drag drops clicks
    min_aio, max_aio, _ = _calculate_impact_range(
        search_volume=1000,
        kd=25.0,
        serp_features=["ai_overview"],
        has_aio=True
    )
    assert max_aio < max_clicks


def test_evidence_generation_and_reason():
    cand = {
        "search_intent": "commercial",
        "paa_questions": ["What is AEO?", "How does AEO work?"],
        "serp_features": ["ai_overview"],
        "search_volume": 800
    }
    existing_page = {"avg_position": 14.2}
    evidence, reason = _build_evidence_items_and_reason(
        keyword="best aeo tool",
        cand=cand,
        existing_page=existing_page,
        competitors_above=4
    )
    assert len(evidence) >= 5
    assert "Existing page already ranks #14.2" in reason
    assert "4 competitors rank above you" in reason
    assert "AI-answer opportunity detected" in reason


def test_generate_and_feedback_flow():
    site_id = "site_opp_test"
    db.upsert_website(site_id, "Test Site", "https://test.example.com", "token123")
    
    candidates = [
        {
            "keyword": "how to build rag agent",
            "search_volume": 900,
            "keyword_difficulty": 30.0,
            "search_intent": "informational",
            "opportunity_score": 85.0
        },
        {
            "keyword": "chatgpt vs claude for coding",
            "search_volume": 2500,
            "keyword_difficulty": 55.0,
            "search_intent": "commercial",
            "opportunity_score": 75.0
        }
    ]
    items = generate_opportunity_feed(site_id, candidate_pool=candidates)
    assert len(items) == 2
    
    # Ranks normalized 0-100
    ranks = [it["relative_rank"] for it in items]
    assert max(ranks) == 100.0
    assert min(ranks) == 0.0

    # Comparison item requires human approval
    vs_item = next(it for it in items if "vs" in it["target_keyword"])
    assert vs_item["is_comparison_or_pricing"] is True
    assert vs_item["human_approval_required"] is True

    # Test feedback loop
    item_id = items[0]["id"]
    res = process_opportunity_feedback(item_id, action="accepted")
    assert res["success"] is True
    assert res["new_status"] == "accepted"

    # Reject with reason
    res_rej = process_opportunity_feedback(items[1]["id"], action="rejected", reject_reason="Not our focus")
    assert res_rej["success"] is True
    assert res_rej["new_status"] == "rejected"
