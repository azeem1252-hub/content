from fastapi.testclient import TestClient
from web.app import app
import pytest

def test_nextjs_snippet_multi_engine():
    with TestClient(app) as client:
        res = client.get("/api/websites/nextjs-snippet")
        assert res.status_code == 200
        data = res.json()
        assert "snippet" in data
        assert "lib_posts" in data
        assert "agent_prompt" in data
        assert "curl_command" in data

        snippet = data["snippet"]
        assert "UPSTASH_REDIS_REST_URL" in snippet
        assert "GITHUB_TOKEN" in snippet
        assert "saveToUpstash" in snippet
        assert "saveToGitHub" in snippet

        lib_posts = data["lib_posts"]
        assert "getPostBySlugAsync" in lib_posts
        assert "getAllPostsAsync" in lib_posts
        assert "UPSTASH_REDIS_REST_URL" in lib_posts

        prompt = data["agent_prompt"]
        # Self-contained prompt: tested code is embedded, not just described
        assert "STEP 4" in prompt  # mandatory verification step
        assert "npm run build" in prompt
        assert "crypto.timingSafeEqual" in prompt  # route handler code embedded
        assert "getPostBySlugAsync" in prompt  # reader helper code embedded
        assert "UPSTASH_REDIS_REST_URL" in prompt
        assert "GITHUB_TOKEN" in prompt
        assert "<GENERATED_TOKEN>" in prompt  # UI injects the live token here
        assert "<ENDPOINT_URL>" in prompt  # UI injects the site endpoint here
        assert "Redeploy" in prompt  # serverless env-var warning

def test_test_storage_connection_upstash_invalid():
    with TestClient(app) as client:
        res = client.post("/api/websites/test-storage", json={
            "engine": "upstash",
            "upstash_url": "https://fake-db.upstash.io",
            "upstash_token": "fake_token_123"
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is False
        assert "message" in data

def test_test_storage_connection_github_invalid():
    with TestClient(app) as client:
        res = client.post("/api/websites/test-storage", json={
            "engine": "github",
            "github_repo": "invalid/nonexistent-repo-9999",
            "github_token": "ghp_fake1234567890"
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is False
        assert "message" in data

def test_test_storage_connection_bad_params():
    with TestClient(app) as client:
        res = client.post("/api/websites/test-storage", json={
            "engine": "unknown"
        })
        assert res.status_code == 400
