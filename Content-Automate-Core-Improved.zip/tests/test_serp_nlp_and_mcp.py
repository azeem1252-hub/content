"""
Unit tests for Proprietary SERP-Grounded NLP Engine, AI ROI Attribution API,
and the Content Pipeline Model Context Protocol (MCP) Server.
"""

import json
from unittest.mock import MagicMock, patch
import pytest
from fastapi.testclient import TestClient

from pipeline.adapters.serp_nlp import (
    extract_serp_semantic_footprint,
    evaluate_serp_coverage
)
from pipeline.mcp_server import ContentPipelineMCPServer, TOOLS_REGISTRY
from web.app import app


# =========================================================================
# 1. SERP NLP Engine Tests
# =========================================================================

def test_extract_serp_semantic_footprint_extraction():
    competitor_snippets = [
        "Kubernetes orchestration in multi-cloud environments provides resilient high-availability clusters. How to configure ingress controllers?",
        "Multi-cloud Kubernetes clusters scale microservices with zero downtime. What are the best practices for container security?",
        "Production Kubernetes deployments require automated ingress controllers and declarative state management."
    ]

    footprint = extract_serp_semantic_footprint(competitor_snippets, min_freq=1)

    assert footprint["total_competitor_words"] > 20
    assert len(footprint["salient_bigrams"]) > 0
    assert len(footprint["salient_entities"]) > 0
    assert len(footprint["question_patterns"]) >= 1

    # Check for extracted questions
    q_texts = " ".join(footprint["question_patterns"])
    assert "How to configure" in q_texts or "What are the best" in q_texts


def test_evaluate_serp_coverage_scoring():
    competitor_snippets = [
        "Serverless SQLite edge databases offer zero latency reads. How to handle replication across distributed edges?",
        "Distributed SQLite replication requires raft consensus and streaming WAL logs."
    ]
    footprint = extract_serp_semantic_footprint(competitor_snippets, min_freq=1)

    # Candidate draft with high overlap
    strong_draft = """
    # Building Distributed Serverless SQLite at the Edge
    Serverless SQLite edge databases offer zero latency reads for modern applications.
    In this guide, we explore how to handle replication across distributed edges using raft consensus.
    """
    strong_res = evaluate_serp_coverage(strong_draft, footprint)
    assert strong_res["serp_coverage_score"] >= 50
    assert len(strong_res["matched_bigrams"]) > 0

    # Weak candidate draft
    weak_draft = "Just a general post about programming with no edge architecture mention."
    weak_res = evaluate_serp_coverage(weak_draft, footprint)
    assert weak_res["serp_coverage_score"] < strong_res["serp_coverage_score"]
    assert len(weak_res["missing_salient_phrases"]) > 0
    assert len(weak_res["recommendations"]) > 0


# =========================================================================
# 2. AI ROI Attribution Endpoint Tests
# =========================================================================

def test_get_ai_roi_analytics_endpoint():
    client = TestClient(app)
    resp = client.get("/api/analytics/ai-roi")
    assert resp.status_code == 200
    data = resp.json()

    assert "summary" in data
    assert "platform_distribution" in data
    assert "top_cited_articles" in data

    summary = data["summary"]
    assert "ai_inclusion_rate_percent" in summary
    assert "multiplier_applied" in summary
    assert summary["multiplier_applied"] == 4.4
    assert "ai_attributed_pipeline_value_usd" in summary
    assert "standard_organic_value_usd" in summary

    # Verify platform distribution includes key engines
    platforms = [p["platform"] for p in data["platform_distribution"]]
    assert "Perplexity" in platforms
    assert "ChatGPT Search" in platforms
    assert "Google AI Overviews" in platforms


def test_get_llms_txt_and_sync_endpoints():
    client = TestClient(app)

    # 1. GET /api/llms-txt
    resp = client.get("/api/llms-txt")
    assert resp.status_code == 200
    data = resp.json()
    assert "site_name" in data
    assert "content" in data
    assert "destinations" in data
    assert "# " in data["content"]

    # 2. POST /api/llms-txt/sync
    sync_resp = client.post("/api/llms-txt/sync", json={"site_name": "Test Site"})
    assert sync_resp.status_code == 200
    sync_data = sync_resp.json()
    assert sync_data.get("success") is True
    assert "synced_files" in sync_data


def test_grounding_pages_endpoints():
    client = TestClient(app)

    # 1. GET /api/grounding-pages
    resp = client.get("/api/grounding-pages")
    assert resp.status_code == 200
    data = resp.json()
    assert "pages" in data
    assert "count" in data or "total" in data

    # 2. POST /api/grounding-pages/deploy
    deploy_payload = {
        "entity_name": "Test Autonomous Agent",
        "canonical_url": "https://example.com/agent",
        "entity_type": "SoftwareApplication",
        "stable_definition": "An autonomous AI software agent that drafts and deploys verified technical publications.",
        "atomic_facts": [
            {"statement": "Autonomous agent operates without user intervention.", "confidence": 0.98}
        ],
        "key_specifications": {
            "Runtime": "FastAPI + LangGraph",
            "Target": "Next.js App Router"
        }
    }
    deploy_resp = client.post("/api/grounding-pages/deploy", json=deploy_payload)
    assert deploy_resp.status_code == 200
    deploy_data = deploy_resp.json()
    assert deploy_data.get("status") == "deployed"
    assert "slug" in deploy_data


def test_internal_links_apply_endpoint():
    client = TestClient(app)

    draft = "Modern applications rely on distributed consensus to replicate WAL logs."
    proposals = [
        {
            "id": "outbound-1",
            "type": "outbound",
            "status": "approved",
            "anchor_text": "distributed consensus",
            "target_url": "/posts/raft-replication-guide",
        }
    ]

    resp = client.post("/api/internal-links/apply", json={"draft": draft, "proposals": proposals})
    assert resp.status_code == 200
    data = resp.json()
    assert data.get("success") is True
    assert "[distributed consensus](/posts/raft-replication-guide)" in data["draft"]



# =========================================================================
# 3. Model Context Protocol (MCP) Server Tests
# =========================================================================

def test_mcp_server_initialize_handshake():
    server = ContentPipelineMCPServer()
    init_req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "test-client", "version": "1.0"}
        }
    }
    resp = server.handle_request(init_req)
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 1
    assert "serverInfo" in resp["result"]
    assert resp["result"]["serverInfo"]["name"] == "content-pipeline-agent"


def test_mcp_server_tools_list():
    server = ContentPipelineMCPServer()
    list_req = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/list"
    }
    resp = server.handle_request(list_req)
    tools = resp["result"]["tools"]
    tool_names = [t["name"] for t in tools]

    assert "search_articles" in tool_names
    assert "scan_action_center" in tool_names
    assert "execute_action" in tool_names
    assert "evaluate_citable" in tool_names
    assert "trigger_pipeline_run" in tool_names


def test_mcp_server_tool_search_and_evaluate():
    server = ContentPipelineMCPServer()

    # 1. Test search_articles
    call_search = {
        "jsonrpc": "2.0",
        "id": 3,
        "method": "tools/call",
        "params": {
            "name": "search_articles",
            "arguments": {"query": "test", "limit": 5}
        }
    }
    resp_search = server.handle_request(call_search)
    assert resp_search["id"] == 3
    content_text = resp_search["result"]["content"][0]["text"]
    parsed_content = json.loads(content_text)
    assert "matches" in parsed_content

    # 2. Test evaluate_citable
    call_eval = {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "tools/call",
        "params": {
            "name": "evaluate_citable",
            "arguments": {
                "title": "Architecting High-Throughput Edge Pipelines",
                "draft": "According to official docs at https://example.com, this benchmark yields 4.4x speedup.",
                "keywords": ["edge pipelines", "benchmarks"]
            }
        }
    }
    resp_eval = server.handle_request(call_eval)
    assert resp_eval["id"] == 4
    eval_text = resp_eval["result"]["content"][0]["text"]
    parsed_eval = json.loads(eval_text)
    assert "citable_score" in parsed_eval
    assert parsed_eval["citable_score"] > 0


def test_mcp_server_tool_scan_and_execute():
    server = ContentPipelineMCPServer()

    # 1. Test scan_action_center
    call_scan = {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": {
            "name": "scan_action_center",
            "arguments": {}
        }
    }
    resp_scan = server.handle_request(call_scan)
    assert resp_scan["id"] == 5
    scan_data = json.loads(resp_scan["result"]["content"][0]["text"])
    assert "opportunities" in scan_data
    assert "summary" in scan_data

    # 2. Test execute_action for llms_txt_sync
    call_exec = {
        "jsonrpc": "2.0",
        "id": 6,
        "method": "tools/call",
        "params": {
            "name": "execute_action",
            "arguments": {
                "opportunity_type": "llms_txt_sync",
                "post_slug": "_global_"
            }
        }
    }
    resp_exec = server.handle_request(call_exec)
    assert resp_exec["id"] == 6
    exec_data = json.loads(resp_exec["result"]["content"][0]["text"])
    assert exec_data["status"] == "success"

    # 3. Test trigger_pipeline_run with mocked pipeline_manager
    with patch("pipeline.mcp_server.pipeline_manager.start_pipeline") as mock_start:
        mock_start.return_value = {"thread_id": "dispatch-test-123", "status": "queued"}
        call_trigger = {
            "jsonrpc": "2.0",
            "id": 7,
            "method": "tools/call",
            "params": {
                "name": "trigger_pipeline_run",
                "arguments": {
                    "topic": "Future of Autonomous Agents",
                    "keywords": ["agents", "autonomous"],
                    "auto_approve": True
                }
            }
        }
        resp_trigger = server.handle_request(call_trigger)
        assert resp_trigger["id"] == 7
        trigger_data = json.loads(resp_trigger["result"]["content"][0]["text"])
        assert trigger_data["thread_id"] == "dispatch-test-123"
        mock_start.assert_called_once()


def test_mcp_server_unknown_method():
    server = ContentPipelineMCPServer()
    bad_req = {
        "jsonrpc": "2.0",
        "id": 99,
        "method": "unknown_function_xyz"
    }
    resp = server.handle_request(bad_req)
    assert "error" in resp
    assert resp["error"]["code"] == -32601

