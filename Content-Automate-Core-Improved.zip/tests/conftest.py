"""
Shared pytest fixtures.

- Ensures the project root is on sys.path (replaces the sys.path.insert hacks
  previously copy-pasted into every test file).
- Isolates the SQLite database to a temp file per test session so tests never
  touch the developer's real pipeline.db.
"""

import os
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Point the app database at a temp file BEFORE any project module imports
# config.py / storage.db (they read DATABASE_URL at import time).
# Set unconditionally: config.reload_config() uses load_dotenv(override=True),
# so a pre-set env var alone would be clobbered by a .env DATABASE_URL entry.
_tmp_db = Path(tempfile.mkdtemp(prefix="pipeline-test-")) / "pipeline.db"
os.environ["DATABASE_URL"] = str(_tmp_db)
os.environ["EMBEDDING_PROVIDER"] = "local"

import pytest  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _isolated_db():
    """Guarantees every test session runs against an isolated temp database and offline local embeddings."""
    import config
    config.EMBEDDING_PROVIDER = "local"
    from storage.db import init_db
    init_db()
    yield
