"""
tests/test_cms_publishing_a5d.py

Unit and integration tests for Pillar A5d:
- A5d.1: Publish Pipeline, CMS Adapters (WordPress, Webflow, Shopify, Ghost, Headless Git, Next.js),
  Media SHA-256 Hash Deduplication, Preview URLs, Idempotency, and Reversibility (Unpublish/Revert).
- A5d.2: Three Publish Modes (Mode 1 After Approval, Mode 2 Refresh Autopilot, Mode 3 Unattended Autopilot),
  Regulatory Governance (Google 1 Oct 2026, September 2026 Spam Update, EU AI Act Art. 50),
  Tenant Opt-in, Legal Counsel Sign-off, and 24-48h Audit Expiry.
"""

import hashlib
import json
import os
import pytest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch
from fastapi.testclient import TestClient

from storage.db import (
    init_db,
    save_post,
    get_publish_record_by_dedupe,
    save_publish_record,
    get_media_dedupe_entry,
    save_media_dedupe_entry,
    create_website,
    get_website_by_id,
)
from pipeline.adapters.cms_publishers import (
    CMSMediaAsset,
    CMSMetadata,
    CMSArticlePayload,
    CMSPublishCoordinator,
    WordPressAdapter,
    WebflowAdapter,
    ShopifyAdapter,
    GhostAdapter,
    HeadlessGitPRAdapter,
    NextJsAdapter,
    get_cms_adapter,
)
from pipeline.adapters.publish_modes import (
    PublishMode,
    ReviewerAttestation,
    SitePublishConfig,
    Mode2RefreshConfig,
    Mode3AutopilotConfig,
    compute_dedupe_key,
    compute_content_diff_pct,
    is_regulated_or_ymyl_topic,
    evaluate_publish_eligibility,
    process_mode3_audit_timeouts,
    GOOGLE_OCT_2026_GUIDANCE,
    GOOGLE_SEPT_2026_SPAM_UPDATE,
    EU_AI_ACT_ART_50_EXEMPTION,
)
from web.app import app


@pytest.fixture(autouse=True)
def setup_test_db():
    init_db()


# =====================================================================
# 1. MEDIA HASH DEDUPLICATION (A5d.1)
# =====================================================================

def test_media_hash_deduplication():
    data = b"Simulated hero image payload bytes for testing"
    expected_hash = hashlib.sha256(data).hexdigest()

    asset1 = CMSMediaAsset(
        filename="hero-graphic.webp",
        file_bytes=data,
        alt="A diagram showing content automation workflow",
        caption="Figure 1: Pipeline orchestration overview",
        credit="Dispatch Editorial Bureau",
    )
    assert asset1.get_hash() == expected_hash

    adapter = WordPressAdapter({"id": "test-wp", "url": "https://wp.example.com", "secret_token": "mock"})
    res1 = adapter.upload_media(asset1)
    assert res1.success is True
    assert res1.content_hash == expected_hash
    assert res1.deduplicated is False

    # Second upload with identical bytes must be deduplicated
    asset2 = CMSMediaAsset(
        filename="hero-duplicate.webp",
        file_bytes=data,
        alt="Same graphic uploaded again",
    )
    res2 = adapter.upload_media(asset2)
    assert res2.success is True
    assert res2.deduplicated is True
    assert res2.cms_media_url == res1.cms_media_url


# =====================================================================
# 2. CMS ADAPTER SPECIFICATIONS (Current API Versions)
# =====================================================================

def test_wordpress_adapter_staging_and_seo_meta():
    site = {
        "id": "wp-site-1",
        "url": "https://gaming-dispatch.org",
        "secret_token": "app_password_mock",
        "type": "wordpress",
    }
    adapter = WordPressAdapter(site)

    payload = CMSArticlePayload(
        title="Modern Game Engine Paradigms in 2026",
        slug="modern-game-engines-2026",
        html_content="<p>Analysis of real-time rendering pipelines.</p>",
        markdown_content="Analysis of real-time rendering pipelines.",
        excerpt="Comprehensive breakdown of next-gen rendering tech.",
        metadata=CMSMetadata(
            title="Modern Game Engine Paradigms in 2026",
            meta_title="Modern Game Engine Paradigms | The Dispatch",
            meta_description="Comprehensive breakdown of next-gen rendering tech.",
            slug="modern-game-engines-2026",
            author="Lead Graphics Engineer",
            tags=["gaming", "graphics", "unreal"],
            seo_plugin_meta={"_yoast_wpseo_metadesc": "Custom Yoast Description"},
        ),
    )

    stage_res = adapter.stage_draft(payload)
    assert stage_res.success is True
    assert stage_res.status == "staged"
    assert "preview=true" in stage_res.preview_url

    # Publish transition
    pub_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload)
    assert pub_res.success is True
    assert pub_res.status == "published"
    assert "modern-game-engines-2026" in pub_res.published_url

    # Scheduling transition
    sched_time = (datetime.now(timezone.utc) + timedelta(days=2)).isoformat()
    sched_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload, scheduled_time=sched_time)
    assert sched_res.status == "scheduled"
    assert sched_res.scheduled_at == sched_time

    # Reversibility: unpublish back to draft
    unpub_ok = adapter.unpublish(stage_res.cms_item_id, payload.slug)
    assert unpub_ok is True


def test_webflow_adapter_data_api_v2():
    site = {
        "id": "wf-site-1",
        "url": "https://dispatch.webflow.io",
        "secret_token": "wf_token_mock",
        "type": "webflow",
        "webflow_collection_id": "col_12345",
    }
    adapter = WebflowAdapter(site)

    payload = CMSArticlePayload(
        title="Decentralized Storage Protocols",
        slug="decentralized-storage-protocols",
        html_content="<p>Evaluating IPFS and Arweave persistence.</p>",
        markdown_content="Evaluating IPFS and Arweave persistence.",
        excerpt="Storage protocol evaluation.",
        metadata=CMSMetadata(
            title="Decentralized Storage Protocols",
            meta_title="Decentralized Storage Protocols",
            meta_description="Storage protocol evaluation.",
            slug="decentralized-storage-protocols",
        ),
    )

    stage_res = adapter.stage_draft(payload)
    assert stage_res.success is True
    assert "preview=true" in stage_res.preview_url

    pub_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload)
    assert pub_res.success is True
    assert pub_res.status == "published"

    assert adapter.unpublish(stage_res.cms_item_id, payload.slug) is True
    assert adapter.revert(stage_res.cms_item_id, payload.slug, previous_payload={"title": "Prior Title", "markdown_content": "Prior Body"}) is True


def test_shopify_adapter_blog_articles_2024_10():
    site = {
        "id": "shp-site-1",
        "url": "https://store.myshopify.com",
        "secret_token": "shpat_mock_123",
        "type": "shopify",
        "shopify_blog_id": "blog_999",
    }
    adapter = ShopifyAdapter(site)

    payload = CMSArticlePayload(
        title="Mechanical Keyboard Switch Comparison",
        slug="keyboard-switch-comparison",
        html_content="<p>Linear vs tactile vs clicky actuation curves.</p>",
        markdown_content="Linear vs tactile vs clicky actuation curves.",
        excerpt="Key switch comparison.",
        metadata=CMSMetadata(
            title="Mechanical Keyboard Switch Comparison",
            meta_title="Keyboard Switch Guide",
            meta_description="Key switch comparison.",
            slug="keyboard-switch-comparison",
            tags=["hardware", "keyboards"],
        ),
    )

    stage_res = adapter.stage_draft(payload)
    assert stage_res.success is True
    assert "preview_theme_id" in stage_res.preview_url

    pub_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload)
    assert pub_res.success is True
    assert pub_res.status == "published"
    assert adapter.unpublish(stage_res.cms_item_id, payload.slug) is True
    assert adapter.revert(stage_res.cms_item_id, payload.slug, previous_payload={"title": "Prior Keyboard Guide", "markdown_content": "Prior Body"}) is True


def test_ghost_adapter_jwt_auth_and_staging():
    # Ghost API key format: {key_id}:{32-byte-hex-secret}
    secret_hex = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    site = {
        "id": "ghost-site-1",
        "url": "https://editorial.ghost.io",
        "secret_token": f"mock_key_1234567890abcdef:{secret_hex}",
        "type": "ghost",
    }
    adapter = GhostAdapter(site)

    # JWT generation test
    token = adapter._generate_jwt_token()
    assert token != "mock_ghost_jwt"
    assert len(token.split(".")) == 3  # Valid JWT tripartite

    payload = CMSArticlePayload(
        title="Independent Journalism in 2026",
        slug="independent-journalism-2026",
        html_content="<p>Reader-supported models vs algorithmic syndication.</p>",
        markdown_content="Reader-supported models vs algorithmic syndication.",
        excerpt="Journalism economics in 2026.",
        metadata=CMSMetadata(
            title="Independent Journalism in 2026",
            meta_title="Independent Journalism in 2026",
            meta_description="Journalism economics in 2026.",
            slug="independent-journalism-2026",
        ),
    )

    stage_res = adapter.stage_draft(payload)
    assert stage_res.success is True
    assert "ghost" in stage_res.cms_type
    pub_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload)
    assert pub_res.success is True
    assert adapter.unpublish(stage_res.cms_item_id, payload.slug) is True
    assert adapter.revert(stage_res.cms_item_id, payload.slug, previous_payload={"title": "Prior Journalism", "markdown_content": "Prior Body"}) is True


def test_headless_git_pr_adapter():
    site = {
        "id": "headless-site-1",
        "url": "https://content-dispatch.dev",
        "github_repo": "dispatch-media/editorial-nextjs",
        "github_branch": "main",
        "github_token": "ghp_mock_token",
        "type": "headless_git",
    }
    adapter = HeadlessGitPRAdapter(site)

    payload = CMSArticlePayload(
        title="Headless Architecture Benchmarks",
        slug="headless-architecture-benchmarks",
        html_content="<p>Edge rendering vs incremental static regeneration.</p>",
        markdown_content="Edge rendering vs incremental static regeneration.",
        excerpt="Benchmarking serverless content stacks.",
        metadata=CMSMetadata(
            title="Headless Architecture Benchmarks",
            meta_title="Headless Architecture Benchmarks",
            meta_description="Benchmarking serverless content stacks.",
            slug="headless-architecture-benchmarks",
        ),
    )

    stage_res = adapter.stage_draft(payload)
    assert stage_res.success is True
    assert "pull/new" in stage_res.preview_url

    pub_res = adapter.publish_or_schedule(stage_res.cms_item_id, payload)
    assert pub_res.success is True
    assert "pull" in pub_res.published_url

    assert adapter.unpublish(stage_res.cms_item_id, payload.slug) is True
    assert adapter.revert(stage_res.cms_item_id, payload.slug, previous_payload={"markdown_content": "# Prior Headless Benchmarks"}) is True


# =====================================================================
# 3. IDEMPOTENCY & REVERSIBILITY (A5d.1)
# =====================================================================

def test_idempotent_publishing_pipeline():
    site = {
        "id": "site-idempotent-test",
        "url": "https://test-blog.com",
        "type": "nextjs",
    }
    coordinator = CMSPublishCoordinator(site)

    content_text = "This is a deterministic article draft for testing idempotency."
    payload = CMSArticlePayload(
        title="Idempotency Test Post",
        slug="idempotency-test-post",
        html_content=f"<p>{content_text}</p>",
        markdown_content=content_text,
        excerpt="Test excerpt",
        metadata=CMSMetadata(
            title="Idempotency Test Post",
            meta_title="Idempotency Test Post",
            meta_description="Test excerpt",
            slug="idempotency-test-post",
        ),
    )

    attestation = ReviewerAttestation(
        reviewer_name="Jane Doe, Senior Editor",
        sign_off_notes="Full manual fact-check verified.",
    )
    site_cfg = SitePublishConfig(mode=PublishMode.MODE_1_AFTER_APPROVAL)

    # First execution: stages, publishes, and writes publish_records
    res1 = coordinator.execute_publish_pipeline(
        payload=payload,
        topic="Idempotency Test",
        reviewer_attestation=attestation,
        site_publish_config=site_cfg,
        quality_gates_passed=True,
    )
    assert res1.success is True
    dkey = res1.dedupe_key
    assert dkey is not None

    record = get_publish_record_by_dedupe(dkey)
    assert record is not None
    assert record["status"] == "published"

    # Second execution: EXACT duplicate payload must return cached result without duplicate publish
    res2 = coordinator.execute_publish_pipeline(
        payload=payload,
        topic="Idempotency Test",
        reviewer_attestation=attestation,
        site_publish_config=site_cfg,
        quality_gates_passed=True,
    )
    assert res2.success is True
    assert res2.dedupe_key == dkey
    assert res2.published_url == res1.published_url

    # Reversibility: unpublish
    unpub_success = coordinator.unpublish(dkey)
    assert unpub_success is True
    unpub_record = get_publish_record_by_dedupe(dkey)
    assert unpub_record["status"] == "unpublished"

    # Reversibility: revert
    rev_success = coordinator.revert(dkey)
    assert rev_success is True
    rev_record = get_publish_record_by_dedupe(dkey)
    assert rev_record["status"] == "reverted"


# =====================================================================
# 4. THREE PUBLISH MODES & POLICY EVALUATION (A5d.2)
# =====================================================================

def test_mode_1_policy_requires_reviewer_attestation_and_quality_gates():
    cfg = SitePublishConfig(mode=PublishMode.MODE_1_AFTER_APPROVAL)

    # Case A: Fails when no reviewer attestation is present
    eval_no_attest = evaluate_publish_eligibility(
        article_title="Robotics Breakthrough",
        slug="robotics-breakthrough",
        content="Robotics content.",
        topic="Robotics",
        quality_gates_passed=True,
        reviewer_attestation=None,
        site_config=cfg,
    )
    assert eval_no_attest.is_eligible is False
    assert any("reviewer attestation" in r.lower() for r in eval_no_attest.blocking_reasons)

    # Case B: Fails when quality gates failed
    attestation = ReviewerAttestation(reviewer_name="Alice Smith")
    eval_failed_gates = evaluate_publish_eligibility(
        article_title="Robotics Breakthrough",
        slug="robotics-breakthrough",
        content="Robotics content.",
        topic="Robotics",
        quality_gates_passed=False,
        quality_gate_blocking_count=2,
        reviewer_attestation=attestation,
        site_config=cfg,
    )
    assert eval_failed_gates.is_eligible is False
    assert any("quality gates failed" in r.lower() for r in eval_failed_gates.blocking_reasons)

    # Case C: Passes when all gates pass AND reviewer attestation exists
    eval_pass = evaluate_publish_eligibility(
        article_title="Robotics Breakthrough",
        slug="robotics-breakthrough",
        content="Robotics content.",
        topic="Robotics",
        quality_gates_passed=True,
        quality_gate_blocking_count=0,
        reviewer_attestation=attestation,
        site_config=cfg,
    )
    assert eval_pass.is_eligible is True
    assert eval_pass.can_proceed_unattended is True
    assert eval_pass.requires_human_review is False


def test_mode_2_low_risk_refresh_autopilot_conditions():
    cfg = SitePublishConfig(
        mode=PublishMode.MODE_2_REFRESH_AUTOPILOT,
        mode_2=Mode2RefreshConfig(enabled=True, max_char_diff_pct=20.0, min_sources_per_claim=2),
    )

    old_content = "This is the original published and human-approved guide on web performance optimization with comprehensive analysis of latency and bandwidth metrics across modern systems."

    # Case A: Fails if article is brand new (not a refresh)
    eval_new = evaluate_publish_eligibility(
        article_title="Web Perf",
        slug="web-perf",
        content=old_content,
        topic="Web Performance",
        is_refresh=False,
        site_config=cfg,
    )
    assert eval_new.is_eligible is False
    assert any("existing, already-approved articles" in r for r in eval_new.blocking_reasons)

    # Case B: Fails if topic touches regulated / YMYL domain
    eval_ymyl = evaluate_publish_eligibility(
        article_title="Financial Investment Strategies",
        slug="financial-investments",
        content=old_content,
        topic="Stock Market Investment and Tax Planning",
        is_refresh=True,
        previous_content=old_content,
        site_config=cfg,
    )
    assert eval_ymyl.is_eligible is False
    assert any("regulated/ymyl" in r.lower() for r in eval_ymyl.blocking_reasons)

    # Case C: Fails if content edit size exceeds 20% diff cap
    substantially_changed = old_content + " Adding thousands of words with completely rewritten paragraphs and novel claims." * 5
    eval_diff = evaluate_publish_eligibility(
        article_title="Web Perf",
        slug="web-perf",
        content=substantially_changed,
        topic="Web Performance",
        is_refresh=True,
        previous_content=old_content,
        site_config=cfg,
    )
    assert eval_diff.is_eligible is False
    assert any("edit size" in r.lower() for r in eval_diff.blocking_reasons)

    # Case D: Fails if changed claim lacks 2+ verified sources
    unsupported_claims = [
        {"claim": "Load time dropped by 80%", "sources": ["https://single-source.com"], "status": "unverified"}
    ]
    eval_claim = evaluate_publish_eligibility(
        article_title="Web Perf",
        slug="web-perf",
        content=old_content + " Updated minor stat.",
        topic="Web Performance",
        is_refresh=True,
        previous_content=old_content,
        verified_claims=unsupported_claims,
        site_config=cfg,
    )
    assert eval_claim.is_eligible is False
    assert any("requires at least 2 verified sources" in r for r in eval_claim.blocking_reasons)

    # Case E: Passes when edit is small, non-YMYL, and claims properly sourced
    well_sourced_claims = [
        {"claim": "HTTP/3 improves handshake latency", "sources": ["https://ietf.org", "https://cloudflare.com"], "status": "supported"}
    ]
    eval_valid_refresh = evaluate_publish_eligibility(
        article_title="Web Perf",
        slug="web-perf",
        content=old_content + " Updated with HTTP/3 note.",
        topic="Web Performance",
        is_refresh=True,
        previous_content=old_content,
        verified_claims=well_sourced_claims,
        site_config=cfg,
    )
    assert eval_valid_refresh.is_eligible is True


def test_mode_3_unattended_autopilot_guards_and_timeout():
    # Mode 3 must be strictly guarded
    cfg_base = SitePublishConfig(
        mode=PublishMode.MODE_3_UNATTENDED_AUTOPILOT,
        mode_3=Mode3AutopilotConfig(enabled=True, tenant_opt_in=False),
    )

    # Case A: Fails without tenant opt-in
    eval_optin = evaluate_publish_eligibility(
        article_title="AI Research Trends",
        slug="ai-research-trends",
        content="Content.",
        topic="Artificial Intelligence",
        site_config=cfg_base,
    )
    assert eval_optin.is_eligible is False
    assert any("tenant opt-in is required" in r for r in eval_optin.blocking_reasons)

    # Case B: Fails without documented legal counsel sign-off
    cfg_counsel_missing = SitePublishConfig(
        mode=PublishMode.MODE_3_UNATTENDED_AUTOPILOT,
        mode_3=Mode3AutopilotConfig(enabled=True, tenant_opt_in=True, counsel_sign_off=False),
    )
    eval_counsel = evaluate_publish_eligibility(
        article_title="AI Research Trends",
        slug="ai-research-trends",
        content="Content.",
        topic="Artificial Intelligence",
        site_config=cfg_counsel_missing,
    )
    assert eval_counsel.is_eligible is False
    assert any("legal counsel sign-off" in r for r in eval_counsel.blocking_reasons)

    # Case C: Valid Mode 3 configuration schedules 24-48h audit countdown
    cfg_valid_m3 = SitePublishConfig(
        mode=PublishMode.MODE_3_UNATTENDED_AUTOPILOT,
        mode_3=Mode3AutopilotConfig(
            enabled=True,
            tenant_opt_in=True,
            counsel_sign_off=True,
            counsel_officer_name="Robert Vance, General Counsel",
            topic_allow_list=["artificial intelligence", "data science"],
            audit_window_hours=24,
            daily_velocity_cap=5,
        ),
    )
    eval_valid = evaluate_publish_eligibility(
        article_title="AI Research Trends",
        slug="ai-research-trends",
        content="Content.",
        topic="Artificial Intelligence",
        site_config=cfg_valid_m3,
    )
    assert eval_valid.is_eligible is True
    assert eval_valid.audit_deadline_at is not None

    # Case D: Expired Mode 3 audit deadline automatically unpublishes
    past_deadline = (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
    save_publish_record(
        dedupe_key="test-expired-mode3-dedupe",
        slug="expired-mode3-post",
        cms_type="nextjs",
        publish_mode="mode_3_unattended_autopilot",
        status="published",
        audit_deadline_at=past_deadline,
        audit_status="pending_audit",
    )

    actioned = process_mode3_audit_timeouts()
    assert any(a["slug"] == "expired-mode3-post" for a in actioned)

    updated_rec = get_publish_record_by_dedupe("test-expired-mode3-dedupe")
    assert updated_rec["status"] == "unpublished"
    assert updated_rec["audit_status"] == "auto_unpublished_timeout"


def test_regulatory_rationale_constants():
    # Must enforce Google 1 Oct 2026 guidance, Sept 2026 spam update, and EU Art. 50
    assert "1 Oct 2026" in GOOGLE_OCT_2026_GUIDANCE
    assert "September 2026 spam update" in GOOGLE_SEPT_2026_SPAM_UPDATE
    assert "Article 50" in EU_AI_ACT_ART_50_EXEMPTION


# =====================================================================
# 5. FASTAPI REST ENDPOINTS (A5d.1, A5d.2)
# =====================================================================

def test_api_publish_stage():
    client = TestClient(app)
    resp = client.post("/api/studio/publish/stage", json={
        "title": "Quantum Computing Frontiers",
        "slug": "quantum-computing-frontiers",
        "markdown": "# Quantum Computing Frontiers\n\nQubit coherence times have increased.",
        "meta_description": "Analysis of quantum coherence scaling.",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["success"] is True
    assert data["status"] == "staged"
    assert data["preview_url"] is not None


def test_api_publish_execute_and_unpublish():
    client = TestClient(app)

    mock_result = {"status": "success", "post_url": "http://localhost:3000/posts/high-perf-compute-grids", "verified": True}
    with patch("pipeline.adapters.website_client.publish_to_nextjs", return_value=mock_result), \
         patch("pipeline.nodes.publish_node.publish_to_nextjs", return_value=mock_result):
        # 1. Execute publish with human attestation
        pub_resp = client.post("/api/studio/publish/execute", json={
            "title": "High-Performance Compute Grids",
            "slug": "high-perf-compute-grids",
            "markdown": "# High-Performance Compute Grids\n\nDistributed scheduling with RDMA.",
            "meta_description": "Compute grid benchmarks.",
            "reviewer_attestation": {
                "reviewer_name": "Dr. Sarah Chen",
                "role": "Principal Systems Architect",
                "sign_off_notes": "Technical accuracy confirmed.",
            },
            "quality_gates_passed": True,
            "quality_gate_blocking_count": 0,
        })
        assert pub_resp.status_code == 200
        pub_data = pub_resp.json()
        assert pub_data["success"] is True
        assert pub_data["status"] == "published"
        dkey = pub_data["dedupe_key"]
        assert dkey is not None

        # 2. Unpublish operation
        unpub_resp = client.post("/api/studio/publish/unpublish", json={
            "dedupe_key": dkey,
            "slug": "high-perf-compute-grids",
        })
        assert unpub_resp.status_code == 200
        assert unpub_resp.json()["action"] == "unpublished"

        # 3. Revert operation
        rev_resp = client.post("/api/studio/publish/revert", json={
            "dedupe_key": dkey,
            "slug": "high-perf-compute-grids",
        })
        assert rev_resp.status_code == 200
        assert rev_resp.json()["action"] == "reverted"


def test_api_publish_modes_and_governance():
    client = TestClient(app)
    resp = client.get("/api/studio/publish/modes")
    assert resp.status_code == 200
    data = resp.json()
    assert data["success"] is True
    assert len(data["modes"]) == 3

    # Check mode 1 default on
    m1 = next(m for m in data["modes"] if m["id"] == "mode_1_after_approval")
    assert m1["is_default"] is True
    assert m1["recommended"] is True

    # Check mode 3 not recommended
    m3 = next(m for m in data["modes"] if m["id"] == "mode_3_unattended_autopilot")
    assert m3["recommended"] is False

    # Check regulatory warnings
    reg = data["regulatory_governance"]
    assert "1 Oct 2026" in reg["google_oct_2026"]
    assert "Article 50" in reg["eu_ai_act_art_50"]
    assert "hands-off mechanics, human-approved content" in reg["marketing_rule"].lower()


def test_api_configure_publish_mode_guards():
    client = TestClient(app)
    # Create test website
    site = create_website(name="Test Gov Site", url="https://testgov.org")
    site_id = site["id"]

    # Trying to enable Mode 3 without counsel sign-off must fail with 400
    err_resp = client.post("/api/studio/publish/configure-mode", json={
        "website_id": site_id,
        "mode": "mode_3_unattended_autopilot",
        "mode_3_settings": {"tenant_opt_in": True, "counsel_sign_off": False},
    })
    assert err_resp.status_code == 400
    assert "counsel sign-off" in err_resp.json()["detail"].lower()

    # With proper counsel sign-off and officer name, configuration succeeds
    ok_resp = client.post("/api/studio/publish/configure-mode", json={
        "website_id": site_id,
        "mode": "mode_3_unattended_autopilot",
        "mode_3_settings": {
            "tenant_opt_in": True,
            "counsel_sign_off": True,
            "counsel_officer_name": "Jennifer Vance, Legal Counsel",
        },
    })
    assert ok_resp.status_code == 200
    assert ok_resp.json()["success"] is True


def test_real_link_health_check_http_probe():
    from pipeline.adapters.links_engine import check_link_health, simulate_link_health_check

    # 1. Internal link
    s, hops, ok, notes = check_link_health("/posts/sample")
    assert s == 200
    assert hops == 0
    assert ok is True

    # 2. Known dead link
    s, hops, ok, notes = check_link_health("https://example.com/missing", known_dead_urls={"https://example.com/missing"})
    assert s == 404
    assert ok is False

    # 3. Test domain probe
    s, hops, ok, notes = check_link_health("https://example.com")
    assert s == 200
    assert ok is True

    # 4. Backward-compatible alias
    s2, hops2, ok2, _ = simulate_link_health_check("/about")
    assert s2 == 200
    assert ok2 is True
