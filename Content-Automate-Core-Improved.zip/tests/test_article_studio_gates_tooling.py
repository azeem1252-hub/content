"""
Unit and integration tests for A5c.7, A5c.8, and A5c.9.

Validates:
A5c.7 Professional Layout Checklist & Typography Lint:
- Complete layout checklist: H1, byline with photo/link, dates, reading time,
  key takeaways near top, TOC with jump links for long posts, answer-first intro,
  question-form H2/H3, table/figure captions, callouts, FAQ, references, 1 CTA, related reading.
- Typography linter: paragraph length cap (<= 120 words, <= 5 sentences),
  heading depth cap (<= 3), terminology consistency, banned AI clichés,
  calibrated reading levels per audience (general, technical, executive).

A5c.8 Pre-Publish Quality Gates:
- axe-core & WCAG 2.2 AA (contrast >= 4.5:1, alt text on images, heading structure)
- Table semantics (<th>, explicit scope="col" / scope="row", captions)
- Lighthouse CI lab thresholds (CLS <= 0.1, LCP <= 2.5s)
- Schema.org Article, FAQPage validation
- Link integrity (200 OK, hops <= 2, banned generic anchors)
- Spelling audit with technical whitelist
- Multi-viewport layout review (Desktop 1280x800, Tablet 768x1024, Mobile 390x844)
- Publish blocking on any failure + automatic task creation in DB

A5c.9 Tooling Summary:
- Inspection of all 13 tools (Playwright, mermaid-cli, D2, Graphviz, Vega-Lite/Altair/Plotly,
  Pillow/pyvips, svgo, axe-core, Lighthouse CI, S3+CDN, Jinja2, trafilatura, Vision LLM)
- Policy enforcement: trafilatura restricted to competitor analysis only
- Active fallback mechanisms for uninstalled CLI binaries

FastAPI Studio Endpoints:
- POST /api/studio/layout-audit
- POST /api/studio/pre-publish-gates
- GET /api/studio/tooling-manifest
"""

import pytest
from fastapi.testclient import TestClient

from pipeline.adapters.article_model import parse_markdown_to_model
from pipeline.adapters.layout_blueprints import (
    audit_professional_layout_checklist,
    lint_typography_and_reading_level,
    audit_document_layout_blueprint,
    calculate_reading_scores,
    DEFAULT_BANNED_AI_PHRASES,
    DEFAULT_CANONICAL_TERMINOLOGY,
)
from pipeline.adapters.quality_gates import (
    run_axe_wcag_audit,
    check_table_headers_and_scope,
    run_lighthouse_ci_lab_audit,
    validate_schema_markup,
    validate_article_links_health,
    run_spelling_audit,
    render_multi_viewport_and_review,
    execute_pre_publish_quality_gates,
    GateSeverity,
    QualityGateCategory,
)
from pipeline.adapters.tooling_manifest import (
    inspect_tooling_capabilities,
    ToolingCapabilityReport,
)


SAMPLE_COMPREHENSIVE_MARKDOWN = """# Next-Generation Distributed Vector Search Architectures

By Senior Database Architect | Published: 2026-10-06 | Updated: 2026-10-06 | 5 min read

> **Key Takeaways**
> - Distributed vector search decouples indexing from querying to prevent cluster saturation.
> - HNSW graph traversal achieves sub-10ms recall at 98% accuracy.
> - Explicit partition rebalancing eliminates tail latency spikes under heavy concurrent ingestion.

### Direct Architectural Summary
Distributed vector search partitions billion-scale embedding vectors across decoupled worker nodes. By separating continuous ingestion pipelines from low-latency query paths, modern vector search clusters sustain sub-10ms p99 latencies without degrading indexing throughput.

## Table of Contents
- [How Does Distributed Vector Search Partition Work?](#how-partitioning-works)
- [Comparative Benchmark Results](#benchmarks)
- [Frequently Asked Questions](#faq)
- [Sources & References](#references)

## How Does Distributed Vector Search Partition Work?
Vector databases shard high-dimensional vector spaces across memory-optimized partitions using inverted file indexes combined with hierarchical graphs.

| Storage Engine | Index Method | Recall @ 10 | Latency (ms) |
| :--- | :--- | :--- | :--- |
| Engine Alpha | HNSW Graph | 99.1% | 8.2ms |
| Engine Beta | IVF-PQ Quantized | 94.6% | 14.1ms |

> [!NOTE]
> Quantized indexes significantly decrease RAM footprint but exhibit minor precision trade-offs on dense multi-modal models.

![HNSW Graph Partitioning](/uploads/hnsw-partition.webp)
*Figure 1: Decoupled indexing and query traversal routing across distributed vector shards.*

## Frequently Asked Questions

### Can vector databases run on serverless storage?
Yes, tiered storage engines offload cold vector graphs to NVMe or object storage while caching hot working sets in memory.

### What is the recommended recall target?
For mission-critical semantic search, production clusters target between 95% and 99% recall.

## Sources & References
1. [W3C Semantic Standards](https://w3.org/standards) *(Accessed 2026-10-06)*
2. [IEEE Vector Search Benchmarks](https://ieee.org/papers/vector) *(Accessed 2026-10-06)*

### Ready to Deploy?
Schedule an architecture review with our infrastructure team today.

### Related Reading
- Distributed Cache Invalidation Strategies
- Storage Tiering in Next-Generation Databases
"""


# =====================================================================
# A5c.7 Layout Checklist & Typography Tests
# =====================================================================

def test_layout_checklist_comprehensive_pass():
    doc = parse_markdown_to_model(
        markdown=SAMPLE_COMPREHENSIVE_MARKDOWN,
        title="Next-Generation Distributed Vector Search Architectures",
        slug="next-gen-vector-search",
        author="Senior Database Architect",
    )
    doc.published_at = "2026-10-06T12:00:00Z"
    doc.updated_at = "2026-10-06T12:00:00Z"

    report = audit_professional_layout_checklist(doc, content_markdown=SAMPLE_COMPREHENSIVE_MARKDOWN)
    assert report.total_checks >= 12
    # Verify core checklist requirements present
    item_map = {it.key: it for it in report.items}
    assert item_map["h1"].present is True
    assert item_map["byline"].present is True
    assert item_map["dates"].present is True
    assert item_map["key_takeaways"].present is True
    assert item_map["table_of_contents"].present is True
    assert item_map["answer_first_intro"].present is True
    assert item_map["question_form_headings"].present is True
    assert item_map["callouts"].present is True
    assert item_map["faq"].present is True
    assert item_map["references"].present is True


def test_typography_linter_bloated_paragraph_detection():
    # Long bloated paragraph exceeding 120 words
    bloated = " ".join(["This sentence explains high performance distributed computing and storage partitioning."] * 15)
    text = f"# Title\n\n{bloated}\n\nNormal paragraph here."

    typo = lint_typography_and_reading_level(text, max_paragraph_words=120, max_paragraph_sentences=5)
    assert typo.paragraph_cap_compliant is False
    assert len(typo.bloated_paragraphs) >= 1
    assert typo.bloated_paragraphs[0].word_count > 120


def test_typography_linter_heading_depth_cap():
    text = "# Title\n\n## Section H2\n\n### Sub-section H3\n\n#### Invalid H4 Depth\n\n##### Deep H5"
    typo = lint_typography_and_reading_level(text)
    assert typo.heading_depth_compliant is False
    assert len(typo.heading_depth_violations) == 2


def test_typography_linter_inconsistent_terminology():
    text = "We configured e-commerce support on the front-end using next.js and postgresql."
    typo = lint_typography_and_reading_level(text)
    assert typo.terminology_compliant is False
    pref_terms = [t.preferred_term for t in typo.inconsistent_terms]
    assert "ecommerce" in pref_terms
    assert "frontend" in pref_terms
    assert "Next.js" in pref_terms
    assert "PostgreSQL" in pref_terms


def test_typography_linter_banned_ai_phrases():
    text = "In conclusion, this stands as a testament to the intricate tapestry of our rapidly evolving landscape. Let's delve into this."
    typo = lint_typography_and_reading_level(text)
    phrases = [p["phrase"] for p in typo.banned_ai_phrases_found]
    assert "in conclusion" in phrases
    assert "testament" in phrases
    assert "tapestry" in phrases
    assert "delve" in phrases
    assert typo.overall_passed is False


def test_reading_scores_audience_calibration():
    # Technical audience text
    technical_text = (
        "The asynchronous event loop evaluates concurrent futures across non-blocking sockets. "
        "Throughput is upper-bounded by mutex contention and kernel memory context-switch overheads."
    )
    typo_tech = lint_typography_and_reading_level(technical_text, target_audience="technical")
    assert typo_tech.flesch_kincaid_grade >= 9.0

    # General audience test
    simple_text = "Cats sleep when they are tired. Dogs play in the green park with balls."
    typo_gen = lint_typography_and_reading_level(simple_text, target_audience="general")
    assert typo_gen.flesch_kincaid_grade <= 6.0


# =====================================================================
# A5c.8 Pre-Publish Quality Gates Tests
# =====================================================================

def test_axe_wcag_audit_contrast_and_alt_text():
    # Passing HTML
    passing_html = """
    <main>
      <h1>Document Title</h1>
      <h2>Subheading</h2>
      <img src="/uploads/hero.webp" alt="Vector graph partition diagram" width="1200" height="675" />
    </main>
    """
    findings = run_axe_wcag_audit(passing_html, brand_bg="#0f172a", brand_fg="#f8fafc")
    assert len([f for f in findings if f.severity == GateSeverity.BLOCKING]) == 0

    # Failing HTML: missing alt attribute and poor contrast
    failing_html = """
    <main>
      <h1>Title</h1>
      <img src="/uploads/hero.webp" />
    </main>
    """
    findings_fail = run_axe_wcag_audit(failing_html, brand_bg="#777777", brand_fg="#888888")
    blocking = [f for f in findings_fail if f.severity == GateSeverity.BLOCKING]
    assert len(blocking) >= 2  # Contrast failure + missing alt


def test_table_header_and_scope_checks():
    # Accessible table
    accessible_table = """
    <table>
      <caption>Performance Benchmarks by Engine</caption>
      <thead>
        <tr>
          <th scope="col">Engine</th>
          <th scope="col">Latency (ms)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">Alpha</th>
          <td>8.2</td>
        </tr>
      </tbody>
    </table>
    """
    findings = check_table_headers_and_scope(accessible_table)
    assert len([f for f in findings if f.severity == GateSeverity.BLOCKING]) == 0

    # Inaccessible table: no caption, no scope, uses td for headers
    inaccessible_table = """
    <table>
      <tr>
        <td>Engine</td>
        <td>Latency</td>
      </tr>
      <tr>
        <td>Alpha</td>
        <td>8.2</td>
      </tr>
    </table>
    """
    findings_fail = check_table_headers_and_scope(inaccessible_table)
    assert any(f.severity == GateSeverity.BLOCKING for f in findings_fail)


def test_lighthouse_ci_lab_cls_and_lcp_regressions():
    # Passing: explicit dimensions + eager preload
    passing_html = """
    <link rel="preload" as="image" href="/uploads/hero.webp" type="image/webp" fetchpriority="high" />
    <img src="/uploads/hero.webp" width="1200" height="675" loading="eager" alt="Hero" />
    """
    metrics, findings = run_lighthouse_ci_lab_audit(passing_html)
    assert metrics["cls_passed"] is True
    assert metrics["lcp_passed"] is True
    assert len(findings) == 0

    # Failing: missing width/height (CLS regression) and no preload (LCP regression)
    failing_html = """
    <img src="/uploads/hero.webp" loading="lazy" alt="Hero" />
    """
    metrics_fail, findings_fail = run_lighthouse_ci_lab_audit(failing_html, has_lcp_preload=False)
    assert metrics_fail["cls_passed"] is False
    assert metrics_fail["lcp_passed"] is False
    assert len(findings_fail) == 2


def test_schema_validation_gate():
    # Valid article schema
    valid_schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Modern Vector Search",
        "image": ["/uploads/hero.webp"],
        "datePublished": "2026-10-06T12:00:00Z",
        "author": {"@type": "Person", "name": "Jane Doe"},
        "publisher": {"@type": "Organization", "name": "Editorial Bureau"},
    }
    findings = validate_schema_markup(valid_schema)
    assert len(findings) == 0

    # Incomplete schema missing required fields
    incomplete_schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Modern Vector Search",
    }
    findings_fail = validate_schema_markup(incomplete_schema)
    assert len(findings_fail) >= 1
    assert findings_fail[0].severity == GateSeverity.BLOCKING


def test_link_integrity_gate():
    # Passing markdown links with descriptive contextual anchors
    passing_md = "[Distributed Architecture Guide](https://example.com/guide)"
    findings = validate_article_links_health(passing_md)
    assert len(findings) == 0

    # Failing generic anchors
    failing_md = "[click here](https://example.com/dead) and [read more](https://example.com/more)"
    findings_fail = validate_article_links_health(failing_md, known_dead_urls={"https://example.com/dead"})
    assert any("click here" in f.message for f in findings_fail)
    assert any("HTTP 404" in f.message for f in findings_fail)


def test_multi_viewport_layout_review():
    clean_html = "<div style='max-width: 100%; overflow-x: auto;'><p>Responsive content</p></div>"
    viewports = render_multi_viewport_and_review(clean_html)
    assert len(viewports) == 3
    assert all(vp.passed for vp in viewports)

    # Broken HTML with horizontal overflow on mobile
    broken_html = "<div width='900px' style='width: 900px;'>Unresponsive fixed container</div>"
    viewports_fail = render_multi_viewport_and_review(broken_html)
    mobile_vp = next(vp for vp in viewports_fail if vp.viewport_name == "mobile_390x844")
    assert mobile_vp.has_horizontal_overflow is True
    assert mobile_vp.passed is False


def test_execute_pre_publish_quality_gates_blocking_and_task_creation():
    # Clean HTML & Markdown
    clean_html = """
    <link rel="preload" as="image" href="/uploads/hero.webp" type="image/webp" />
    <main>
      <h1>Document Title</h1>
      <h2>Subheading</h2>
      <img src="/uploads/hero.webp" alt="Hero figure" width="1200" height="675" loading="eager" />
      <table>
        <caption>Benchmark Table</caption>
        <thead><tr><th scope="col">Engine</th><th scope="col">Latency</th></tr></thead>
        <tbody><tr><th scope="row">Alpha</th><td>10ms</td></tr></tbody>
      </table>
    </main>
    """
    clean_md = "[Architecture Documentation](https://example.com/docs)"
    schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": "Document Title",
        "image": ["/uploads/hero.webp"],
        "datePublished": "2026-10-06T12:00:00Z",
        "author": {"@type": "Person", "name": "Author"},
        "publisher": {"@type": "Organization", "name": "Publisher"},
    }

    report = execute_pre_publish_quality_gates(
        html_content=clean_html,
        markdown_content=clean_md,
        schema_markup=schema,
        website_id="site-test",
        post_slug="clean-test",
        persist_tasks_to_db=False,
    )
    assert report.can_publish is True
    assert len(report.blocking_failures) == 0

    # Broken input: missing alt, broken table, click here anchor
    broken_html = "<h1>Title</h1><img src='' /><table><tr><td>No headers</td></tr></table>"
    broken_md = "[click here](https://example.com/test)"
    report_fail = execute_pre_publish_quality_gates(
        html_content=broken_html,
        markdown_content=broken_md,
        schema_markup={},
        website_id="site-test",
        post_slug="broken-test",
        persist_tasks_to_db=False,
    )
    assert report_fail.can_publish is False
    assert len(report_fail.blocking_failures) >= 3


# =====================================================================
# A5c.9 Tooling Capability Registry Tests
# =====================================================================

def test_inspect_tooling_capabilities_all_13_tools():
    manifest = inspect_tooling_capabilities()
    assert manifest.total_tools == 13
    assert len(manifest.tools) == 13

    tool_ids = {t.tool_id for t in manifest.tools}
    expected_ids = {
        "playwright", "mermaid_cli", "d2", "graphviz", "chart_engine",
        "image_processing", "svgo", "axe_core", "lighthouse_ci",
        "s3_cdn", "jinja2", "trafilatura", "vision_llm",
    }
    assert tool_ids == expected_ids

    # Verify policy enforcement on trafilatura
    traf = next(t for t in manifest.tools if t.tool_id == "trafilatura")
    assert "competitor" in (traf.policy_restrictions or "").lower()

    # All tools have active fallbacks or are available
    for t in manifest.tools:
        assert t.status in ("available", "fallback_active", "configured")
        assert len(t.fallback_mechanism) > 0


# =====================================================================
# Studio FastAPI Endpoints Tests
# =====================================================================

def test_studio_layout_and_quality_endpoints():
    from web.app import app
    client = TestClient(app)

    # 1. POST /api/studio/layout-audit
    resp_layout = client.post("/api/studio/layout-audit", json={
        "markdown": SAMPLE_COMPREHENSIVE_MARKDOWN,
        "title": "Next-Generation Distributed Vector Search Architectures",
        "slug": "next-gen-vector-search",
        "target_audience": "technical",
    })
    assert resp_layout.status_code == 200
    data_layout = resp_layout.json()
    assert data_layout["success"] is True
    assert "layout_audit" in data_layout
    assert data_layout["layout_audit"]["checklist"]["passed_checks"] >= 10

    # 2. POST /api/studio/pre-publish-gates
    resp_gates = client.post("/api/studio/pre-publish-gates", json={
        "html": "<h1>Test</h1><img src='/uploads/hero.webp' alt='Diagram' width='1200' height='675' loading='eager' />",
        "markdown": "[Valid Source](https://example.com/source)",
        "schema_markup": {
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": "Test",
            "image": ["/uploads/hero.webp"],
            "datePublished": "2026-10-06T12:00:00Z",
            "author": {"@type": "Person", "name": "Author"},
            "publisher": {"@type": "Organization", "name": "Publisher"},
        },
        "persist_tasks_to_db": False,
    })
    assert resp_gates.status_code == 200
    data_gates = resp_gates.json()
    assert data_gates["success"] is True
    assert "quality_report" in data_gates

    # 3. GET /api/studio/tooling-manifest
    resp_tooling = client.get("/api/studio/tooling-manifest")
    assert resp_tooling.status_code == 200
    data_tooling = resp_tooling.json()
    assert data_tooling["success"] is True
    assert len(data_tooling["tooling_manifest"]["tools"]) == 13
