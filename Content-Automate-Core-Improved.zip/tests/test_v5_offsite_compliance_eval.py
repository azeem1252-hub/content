"""
Tests for Pillars A9 (Off-Site), A10 (Compliance & Attestation), and A12 (Causal Evaluation).
"""

import pytest

from pipeline.adapters.off_site_engine import (
    analyze_top_cited_offsite_sources,
    generate_earned_presence_plan,
    get_off_site_presence_summary
)
from pipeline.adapters.compliance_layer import (
    classify_ymyl_and_public_interest,
    compute_content_version_hash,
    generate_eu_ai_act_disclosure,
    validate_google_oct2026_checklist,
    submit_reviewer_attestation,
    get_image_iptc_provenance_metadata
)
from pipeline.adapters.eval_experiments import (
    calculate_difference_in_differences,
    launch_seo_experiment,
    evaluate_fact_verifier_accuracy
)
import storage.db as db


# ---------------------------------------------------------------------------
# A9 Off-Site Tests
# ---------------------------------------------------------------------------

def test_off_site_sources_and_plans():
    site_id = "site_offsite_test"
    sources = analyze_top_cited_offsite_sources(site_id)
    assert len(sources) >= 1
    assert any(s["platform"] in ("reddit", "youtube", "linkedin", "review_site") for s in sources)

    plans = generate_earned_presence_plan(site_id, "cluster_rag", "Retrieval-Augmented Generation")
    assert len(plans) == 4
    platforms = [p["platform"] for p in plans]
    assert "reddit" in platforms
    assert "youtube" in platforms
    assert "linkedin" in platforms

    summary = get_off_site_presence_summary(site_id)
    assert summary["total_targets"] >= 4
    assert any("Human-reviewed" in rule for rule in summary["compliance_rules"])


# ---------------------------------------------------------------------------
# A10 Compliance & Reviewer Attestation Tests
# ---------------------------------------------------------------------------

def test_ymyl_classification():
    # Non-sensitive topic
    res_tech = classify_ymyl_and_public_interest("Best Python web frameworks for APIs")
    assert res_tech["is_ymyl"] is False
    assert res_tech["requires_expert_reviewer"] is False

    # Financial / medical topic
    res_fin = classify_ymyl_and_public_interest("How to invest in crypto stocks for retirement mortgage")
    assert res_fin["is_ymyl"] is True
    assert res_fin["requires_expert_reviewer"] is True


def test_eu_ai_act_disclosure():
    site_id = "site_comp_test"
    # Unattested -> transparency notice
    d_raw = generate_eu_ai_act_disclosure(site_id, has_human_attestation=False)
    assert d_raw["disclosure_required"] is True
    assert d_raw["is_human_exempt"] is False
    assert "Transparency Notice" in d_raw["badge_html"]

    # Attested by human editor -> exemption badge
    d_exempt = generate_eu_ai_act_disclosure(site_id, has_human_attestation=True, reviewer_name="Dr. Jane Smith")
    assert d_exempt["is_human_exempt"] is True
    assert "Dr. Jane Smith" in d_exempt["label_text"]


def test_google_oct2026_checklist():
    incomplete = {
        "title_verified": True,
        "meta_description_verified": False,
        "schema_verified": True,
        "alt_text_verified": False,
        "claims_and_stats_verified": True
    }
    valid, missing = validate_google_oct2026_checklist(incomplete)
    assert valid is False
    assert len(missing) == 2

    complete = {
        "title_verified": True,
        "meta_description_verified": True,
        "schema_verified": True,
        "alt_text_verified": True,
        "claims_and_stats_verified": True
    }
    valid_c, missing_c = validate_google_oct2026_checklist(complete)
    assert valid_c is True
    assert len(missing_c) == 0


def test_submit_attestation_and_hashing():
    site_id = "site_comp_test"
    slug = "enterprise-rag-guide"
    title = "Enterprise RAG Architecture Guide"
    content = "Detailed architectural guide to retrieval-augmented generation systems."
    meta = {"author": "Editor", "pub_date": "2026-10-01"}

    hash_1 = compute_content_version_hash(title, content, meta)
    hash_2 = compute_content_version_hash(title, content, meta)
    assert hash_1 == hash_2
    assert len(hash_1) == 64

    complete_checklist = {
        "title_verified": True,
        "meta_description_verified": True,
        "schema_verified": True,
        "alt_text_verified": True,
        "claims_and_stats_verified": True
    }

    record = submit_reviewer_attestation(
        website_id=site_id,
        post_slug=slug,
        title=title,
        content=content,
        meta=meta,
        reviewer_name="Alex Mercer",
        reviewer_email="alex@editorial.internal",
        reviewer_role="Editor-in-Chief",
        is_qualified_expert=True,
        checklist=complete_checklist
    )
    assert record["version_hash"] == hash_1
    assert record["reviewer_name"] == "Alex Mercer"

    # Verify fetch from db
    saved_records = db.get_reviewer_attestations(site_id, slug)
    assert len(saved_records) >= 1
    assert saved_records[0]["version_hash"] == hash_1


def test_image_iptc_provenance():
    meta = get_image_iptc_provenance_metadata(is_ai_generated=True, generator_model="flux-1-schnell")
    assert meta["DigitalSourceType"] == "trainedAlgorithmicMedia"
    assert "flux-1-schnell" in meta["Credit"]

    meta_real = get_image_iptc_provenance_metadata(is_ai_generated=False)
    assert meta_real["DigitalSourceType"] == "originalDigitalCapture"


# ---------------------------------------------------------------------------
# A12 Difference-in-Differences & Evals Tests
# ---------------------------------------------------------------------------

def test_difference_in_differences():
    # Clear positive causal lift
    treat_pre = [100.0, 110.0, 95.0, 105.0]
    treat_post = [150.0, 160.0, 140.0, 155.0]  # +51.25 avg lift
    ctrl_pre = [100.0, 105.0, 98.0, 102.0]
    ctrl_post = [102.0, 106.0, 101.0, 103.0]  # +1.75 avg lift

    res = calculate_difference_in_differences(treat_pre, treat_post, ctrl_pre, ctrl_post, "clicks")
    assert res["treatment_delta"] > 45.0
    assert res["control_delta"] < 5.0
    assert res["did_causal_effect"] > 40.0
    assert res["verdict"] == "positive_lift"

    # Inconclusive when confidence interval straddles zero
    noisy_t_post = [102.0, 108.0, 97.0, 103.0]
    res_inconclusive = calculate_difference_in_differences(treat_pre, noisy_t_post, ctrl_pre, ctrl_post, "clicks")
    assert res_inconclusive["verdict"] == "inconclusive"


def test_fact_verifier_eval():
    labeled = [
        {"claim_id": "c1", "expected_verdict": "supported"},
        {"claim_id": "c2", "expected_verdict": "contradicted"},
        {"claim_id": "c3", "expected_verdict": "outdated"},
        {"claim_id": "c4", "expected_verdict": "unsubstantiated"},
    ]
    predictions = [
        {"claim_id": "c1", "verdict": "supported"},
        {"claim_id": "c2", "verdict": "contradicted"},
        {"claim_id": "c3", "verdict": "outdated"},
        {"claim_id": "c4", "verdict": "unsubstantiated"},
    ]
    eval_res = evaluate_fact_verifier_accuracy(labeled, predictions)
    assert eval_res["overall_accuracy"] == 1.0
    assert eval_res["per_class_breakdown"]["outdated"]["tp"] == 1
