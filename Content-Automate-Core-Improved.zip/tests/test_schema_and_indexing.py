"""
Unit tests for Programmatic Schema Generator & IndexNow Instant Crawl Client (Pillar II).
"""

import pytest
from unittest.mock import patch, MagicMock
from pipeline.adapters.schema_builder import (
    extract_faq_pairs_from_markdown,
    extract_howto_steps_from_markdown,
    extract_citations_from_markdown,
    extract_entity_mentions,
    clean_markdown_text,
    generate_person_schema,
    generate_organization_schema,
    generate_breadcrumb_schema,
    generate_howto_schema,
    generate_video_schema,
    generate_claim_review_schema,
    build_json_ld_schemas,
    build_json_ld_graph,
    render_json_ld_script,
    validate_schema_for_rich_results,
)
from pipeline.adapters.indexnow_client import submit_indexnow_urls


def test_clean_markdown_text():
    md = "## Header with **Bold** and *Italics* and [Link](https://example.com) plus `inline code`"
    cleaned = clean_markdown_text(md)
    assert "##" not in cleaned
    assert "**" not in cleaned
    assert "https://example.com" not in cleaned
    assert "Link" in cleaned
    assert "inline code" in cleaned


def test_extract_faq_pairs():
    content = """# Main Article

Some introduction text.

### What is Generative Engine Optimization?
Generative Engine Optimization (GEO) is the practice of optimizing content to be cited by AI answer engines like ChatGPT and Perplexity.

### What is Answer Engine Optimization?
Answer Engine Optimization (AEO) formats direct answers for Google Featured Snippets and People Also Ask.
"""
    faqs = extract_faq_pairs_from_markdown(content)
    assert len(faqs) == 2
    assert "Generative Engine Optimization" in faqs[0]["question"]
    assert "ChatGPT and Perplexity" in faqs[0]["answer"]
    assert "Answer Engine Optimization" in faqs[1]["question"]


def test_extract_entity_mentions():
    content = "We built our full stack pipeline with FastAPI, LangGraph, and PostgreSQL on Cloudflare."
    about, mentions = extract_entity_mentions(content, title="Building with LangGraph and FastAPI")
    names = [e["name"] for e in about + mentions]
    assert "LangGraph" in names
    assert "FastAPI" in names
    # Verify sameAs Wikipedia/GitHub resolution
    langgraph_ent = next(e for e in about + mentions if e["name"] == "LangGraph")
    assert "sameAs" in langgraph_ent
    assert "github.com" in langgraph_ent["sameAs"]


def test_extract_citations():
    content = """
According to [W3C Standards](https://www.w3.org/TR/wot-architecture/) and
[MDN Web Docs](https://developer.mozilla.org/en-US/docs/Web/HTTP), internal links like
[Home](http://localhost:3000) should be excluded.
"""
    citations = extract_citations_from_markdown(content)
    assert "https://www.w3.org/TR/wot-architecture/" in citations
    assert "https://developer.mozilla.org/en-US/docs/Web/HTTP" in citations
    assert not any("localhost" in c for c in citations)


def test_build_json_ld_schemas_richness():
    content = """# Title

### What is the primary benefit?
It eliminates hallucinations and captures rich snippets in AI Overviews.

## Step 1: Initialize Database
Run sqlite migrations.

## Step 2: Start Studio Server
Execute python main.py studio.

## Step 3: Verify Output
Check http://localhost:8000.
"""
    schemas = build_json_ld_schemas(
        title="Architecting Authority in 2026",
        slug="architecting-authority-2026",
        content=content,
        meta_description="A blueprint for verified SEO content.",
        hero_image_url="/uploads/hero.png",
        author_name="Dr. Jane Doe",
        author_role="Principal AI Systems Architect",
        author_bio="Pioneer in agentic workflows and automated search grounding.",
        publisher_name="Dispatch Media Group",
        same_as_links=["https://www.wikidata.org/wiki/Q12345"],
        tags=["LangGraph", "FastAPI"],
        category="Artificial Intelligence",
        verified_claims=[
            {"statement": "LangGraph manages state graphs.", "verdict": "Supported"}
        ],
    )

    types = [s.get("@type") for s in schemas]
    assert "Article" in types
    assert "FAQPage" in types
    assert "HowTo" in types
    assert "BreadcrumbList" in types
    assert "Organization" in types
    assert "Person" in types
    assert "ClaimReview" in types

    # Verify Article schema details
    article = next(s for s in schemas if s.get("@type") == "Article")
    assert article["headline"] == "Architecting Authority in 2026"
    assert article["image"] == ["/uploads/hero.png"]
    assert article["wordCount"] > 10
    assert "about" in article
    assert "speakable" in article

    # Verify Person E-E-A-T details
    person = next(s for s in schemas if s.get("@type") == "Person")
    assert person["name"] == "Dr. Jane Doe"
    assert person["jobTitle"] == "Principal AI Systems Architect"
    assert "author-dr-jane-doe" in person["@id"]

    # Verify Breadcrumbs
    breadcrumbs = next(s for s in schemas if s.get("@type") == "BreadcrumbList")
    assert len(breadcrumbs["itemListElement"]) == 3
    assert breadcrumbs["itemListElement"][0]["name"] == "Home"

    # Verify Rich Results Readiness
    validation = validate_schema_for_rich_results(schemas)
    assert validation["valid"] is True
    assert len(validation["errors"]) == 0


def test_build_json_ld_graph_and_rendering():
    content = "### How does it work?\nIt runs completely offline using local embeddings."
    graph = build_json_ld_graph(
        title="Offline Search Architecture",
        slug="offline-search",
        content=content,
    )
    assert "@context" in graph
    assert "@graph" in graph
    assert len(graph["@graph"]) >= 3

    # Test HTML script generation
    script_html = render_json_ld_script(graph)
    assert '<script type="application/ld+json">' in script_html
    assert "</script>" in script_html
    assert "Offline Search Architecture" in script_html


def test_indexnow_client_skipped_when_no_key():
    with patch("pipeline.adapters.indexnow_client.config") as mock_cfg:
        mock_cfg.INDEXNOW_KEY = ""
        res = submit_indexnow_urls(["https://example.com/posts/test"], api_key="")
        assert res["status"] == "skipped"


def test_indexnow_client_success():
    with patch("httpx.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_client.post.return_value = mock_resp
        mock_client_cls.return_value.__enter__.return_value = mock_client

        res = submit_indexnow_urls(
            ["https://example.com/posts/test"],
            api_key="mock_indexnow_key_123"
        )
        assert res["status"] == "success"
        assert res["status_code"] == 200
