import random
import time
import sys
import os
from pathlib import Path

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from pipeline.adapters.codex_image import generate_and_save_image, synthesize_visual_prompt

import pytest


@pytest.mark.live
def test_random_image():
    topics = [
        "Quantum computing processor with glowing crystalline photonic circuits in obsidian vault",
        "Minimalist architectural cantilever hovering over obsidian desert at dusk, neon vermilion accents",
        "Autonomous multi-agent neural network visualized as floating geometric prisms with cyan light trails",
        "Cybernetic bio-computational core with bioluminescent crystalline glass and deep slate textures"
    ]

    chosen_topic = random.choice(topics)
    print("=" * 60)
    print("Testing Random Image Generation")
    print("=" * 60)
    print(f"Topic: {chosen_topic}")

    # 1. Synthesize visual prompt
    prompt = synthesize_visual_prompt(
        title=f"The Future of {chosen_topic[:30]}",
        topic=chosen_topic,
        draft_excerpt="Autonomous pipelines, neural architecture, edge execution."
    )
    print(f"\nSynthesized Editorial Prompt:\n\"{prompt}\"\n")

    # 2. Generate and save image
    slug = f"test-random-{int(time.time()) % 10000}"
    result = generate_and_save_image(prompt=prompt, slug=slug)

    print("=" * 60)
    print("Execution Output:")
    print(f"  Engine:            {result.get('engine')}")
    print(f"  Model:             {result.get('model')}")
    print(f"  Codex Rate Limited:{result.get('codex_rate_limited')}")
    print(f"  Saved Image Path:  {result.get('hero_image_path')}")
    print(f"  Relative URL:      {result.get('hero_image_url')}")
    print(f"  Public Image URL:  {result.get('public_image_url')}")

    # 3. File Verifications
    local_p = Path(result["hero_image_path"])
    assert local_p.exists(), f"Image not found at {local_p}"
    assert local_p.stat().st_size > 0, "Image size is 0 bytes"
    print(f"\n[OK] Local Asset Verified: {local_p.name} ({local_p.stat().st_size} bytes)")

    nextjs_p = Path("D:/next js website/public") / result["hero_image_url"].lstrip("/")
    if nextjs_p.exists():
        print(f"[OK] Next.js Sync Verified: {nextjs_p} ({nextjs_p.stat().st_size} bytes)")
    else:
        print(f"[NOTE] Next.js file at {nextjs_p} not found.")

    print("\n" + "=" * 60)
    print(">>> RANDOM IMAGE GENERATION TEST COMPLETED SUCCESSFULLY! <<<")
    print("=" * 60)

if __name__ == "__main__":
    test_random_image()
