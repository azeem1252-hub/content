import unittest
from unittest.mock import patch, MagicMock
from storage.db import init_db, create_website, get_website_by_id, update_website, get_all_websites
from pipeline.nodes.publish_node import publish_node, _discover_local_nextjs_dirs, _sync_local_nextjs_repo


class TestMultiWebsitePublishing(unittest.TestCase):
    def setUp(self):
        init_db()

    def test_database_backed_website_skips_github_commit(self):
        """Rule 1: If website is database-backed or uses Upstash, NO GitHub commit is made."""
        site = create_website(
            name="Supabase Tech Blog",
            url="https://supabase-blog.com/api/posts",
            storage_type="database"
        )
        self.assertEqual(site["storage_type"], "database")

        state = {
            "title": "PostgreSQL 17 Vector Search Guide",
            "draft": "# PostgreSQL 17 Guide\n\nVector search is now natively accelerated...",
            "slug": "pg-17-vector-search",
            "website_id": site["id"],
            "meta_description": "Vector search guide for PostgreSQL 17."
        }

        # Mock publish_to_nextjs returning success with database engine
        with patch("pipeline.nodes.publish_node.publish_to_nextjs") as mock_pub, \
             patch("pipeline.nodes.publish_node._sync_local_nextjs_repo") as mock_sync:
            
            mock_pub.return_value = {
                "status": "success",
                "post_url": "https://supabase-blog.com/posts/pg-17-vector-search",
                "response": {"status": "success", "engines": ["database", "prisma"]}
            }

            result = publish_node(state)

            self.assertEqual(result["status"], "published")
            self.assertEqual(result["published_url"], "https://supabase-blog.com/posts/pg-17-vector-search")
            # Verify _sync_local_nextjs_repo was NEVER called (no GitHub commit needed!)
            mock_sync.assert_not_called()

    def test_upstash_redis_website_skips_github_commit(self):
        """Rule 1b: If endpoint returns upstash_redis in auto mode, NO GitHub commit is made."""
        site = create_website(
            name="Upstash Edge Blog",
            url="https://edge-blog.vercel.app/api/posts",
            storage_type="auto"
        )

        state = {
            "title": "Zero Latency Edge Content",
            "draft": "# Edge Content Guide\n\nFast redis caching at the edge...",
            "slug": "zero-latency-edge",
            "website_id": site["id"],
            "meta_description": "Edge guide."
        }

        with patch("pipeline.nodes.publish_node.publish_to_nextjs") as mock_pub, \
             patch("pipeline.nodes.publish_node._sync_local_nextjs_repo") as mock_sync:
            
            mock_pub.return_value = {
                "status": "success",
                "post_url": "https://edge-blog.vercel.app/posts/zero-latency-edge",
                "response": {"status": "success", "engines": ["upstash_redis"]}
            }

            result = publish_node(state)

            self.assertEqual(result["status"], "published")
            mock_sync.assert_not_called()

    def test_serverless_git_backed_website_triggers_github_commit_to_its_own_repo(self):
        """Rule 2: Serverless website with NO database and NO Upstash triggers GitHub commit to its specific repo."""
        site1 = create_website(
            name="Site 1 Gaming",
            url="https://site1.vercel.app/api/posts",
            storage_type="git",
            github_repo="Azeem1252/gaming-editorial",
            github_branch="main"
        )
        site2 = create_website(
            name="Site 2 Crypto",
            url="https://site2.vercel.app/api/posts",
            storage_type="git",
            github_repo="Azeem1252/crypto-insights",
            github_branch="prod"
        )

        state = {
            "title": "Crypto Security 2026",
            "draft": "# Crypto Security 2026\n\nHardware enclave signing...",
            "slug": "crypto-security-2026",
            "website_id": site2["id"],
            "meta_description": "Crypto security guide."
        }

        with patch("pipeline.nodes.publish_node.publish_to_nextjs") as mock_pub, \
             patch("pipeline.nodes.publish_node._sync_local_nextjs_repo") as mock_sync:
            
            mock_pub.return_value = {
                "status": "success",
                "post_url": "https://site2.vercel.app/posts/crypto-security-2026",
                "response": {"status": "success", "engines": ["disk:tmp"]}
            }
            mock_sync.return_value = True

            result = publish_node(state)

            self.assertEqual(result["status"], "published")
            # Verify _sync_local_nextjs_repo was called WITH target_site pointing to site2
            mock_sync.assert_called_once()
            called_target_site = mock_sync.call_args[1].get("target_site")
            self.assertEqual(called_target_site["github_repo"], "Azeem1252/crypto-insights")
            self.assertEqual(called_target_site["github_branch"], "prod")

    def test_multi_website_db_isolation(self):
        """Verify multiple websites store and retrieve their own independent github_repo and storage_type."""
        site_a = create_website(
            name="Alpha Portal",
            url="https://alpha.com/api/posts",
            storage_type="database",
            github_repo="alpha/repo-a"
        )
        site_b = create_website(
            name="Beta Portal",
            url="https://beta.com/api/posts",
            storage_type="git",
            github_repo="beta/repo-b"
        )

        fetched_a = get_website_by_id(site_a["id"])
        fetched_b = get_website_by_id(site_b["id"])

        self.assertEqual(fetched_a["storage_type"], "database")
        self.assertEqual(fetched_a["github_repo"], "alpha/repo-a")

        self.assertEqual(fetched_b["storage_type"], "git")
        self.assertEqual(fetched_b["github_repo"], "beta/repo-b")

        # Update site_a to git without affecting site_b
        updated_a = update_website(site_a["id"], storage_type="git", github_repo="alpha/new-repo")
        self.assertEqual(updated_a["storage_type"], "git")
        self.assertEqual(updated_a["github_repo"], "alpha/new-repo")

        # site_b unchanged
        refetched_b = get_website_by_id(site_b["id"])
        self.assertEqual(refetched_b["github_repo"], "beta/repo-b")


if __name__ == "__main__":
    unittest.main()
