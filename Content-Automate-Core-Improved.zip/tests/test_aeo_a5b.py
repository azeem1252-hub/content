"""
Tests for A5b: Answer Engine Optimization (AEO) Engine.

Validates:
- Question discovery from multiple sources
- Eligibility gating (rank threshold, near-miss, not-eligible)
- Format matching and answer block generation
- FAQ module (2-4 sentence targets, no FAQPage schema by default)
- Click-worthiness analysis
- Measurement snapshot
- Honest limits: no guarantees, no voice-specific features
- Config is entirely editable (all thresholds are warnings)
"""

import pytest
from pipeline.adapters.aeo_engine import (
    AEOConfig,
    AnswerBlock,
    AnswerTarget,
    EligibilityStatus,
    EntityLayerConfig,
    SnippetFormat,
    SnippetSurface,
    discover_answer_targets,
    apply_eligibility_gate,
    infer_format_from_serp,
    format_must_match,
    generate_answer_block,
    generate_faq_items,
    generate_entity_layer,
    verify_answer_block_claims,
    render_faqpage_schema,
    analyse_click_worthiness,
    create_measurement_snapshot,
    run_aeo_analysis,
    _keyword_to_question,
    _is_question,
    _decontextualize,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def default_config():
    return AEOConfig()


@pytest.fixture
def custom_config():
    """All thresholds overridable per spec."""
    return AEOConfig(
        eligibility_rank_threshold=5,
        paragraph_min_words=30,
        paragraph_max_words=50,
        list_min_items=3,
        list_max_items=6,
        faq_answer_min_sentences=2,
        faq_answer_max_sentences=3,
        include_faqpage_schema=False,
    )


@pytest.fixture
def rank_data():
    return {
        "best project management software": 3,
        "project management vs task management": 8,
        "what is a gantt chart": 22,     # not eligible
        "trello vs asana": 12,           # near-miss
    }


@pytest.fixture
def snippet_data():
    return {
        "best project management software": {"format": "ordered_list", "owner_domain": "monday.com"},
        "project management vs task management": {"format": "paragraph", "owner_domain": "atlassian.com"},
        "trello vs asana": {"format": "table", "owner_domain": "g2.com"},
    }


# ---------------------------------------------------------------------------
# A5b.1 Question Discovery
# ---------------------------------------------------------------------------

class TestQuestionDiscovery:

    def test_keyword_to_question_plain_keyword(self):
        assert _keyword_to_question("project management software") == "What is project management software?"

    def test_keyword_to_question_how_to_prefix(self):
        q = _keyword_to_question("how to create a gantt chart")
        assert q.startswith("How to")
        assert q.endswith("?")

    def test_keyword_to_question_already_question(self):
        q = _keyword_to_question("what is agile methodology?")
        assert "?" in q
        # Should not double-wrap
        assert q.count("?") == 1

    def test_is_question_detects_question_words(self):
        assert _is_question("What is Kanban?")
        assert _is_question("How does Scrum work?")
        assert not _is_question("project management software 2024")

    def test_discover_from_keywords(self, rank_data, snippet_data):
        targets = discover_answer_targets(
            keywords=["best project management software"],
            rank_data=rank_data,
            snippet_data=snippet_data,
        )
        assert len(targets) >= 1
        t = targets[0]
        assert t.keyword == "best project management software"
        assert "?" in t.question

    def test_paa_sources_included(self, rank_data):
        paa = ["Is Trello good for project management?", "What does a PM do?"]
        targets = discover_answer_targets(
            keywords=["project management"],
            paa_questions=paa,
            rank_data=rank_data,
        )
        questions = [t.question for t in targets]
        # PAA questions should appear
        assert any("Trello" in q for q in questions)

    def test_related_searches_included(self, rank_data):
        related = ["best free project management tools", "project management certifications"]
        targets = discover_answer_targets(
            keywords=["project management"],
            related_searches=related,
            rank_data=rank_data,
        )
        assert len(targets) >= 2

    def test_gsc_queries_included(self, rank_data):
        gsc = ["how to track project progress", "project management kpis examples"]
        targets = discover_answer_targets(
            keywords=["project management"],
            gsc_question_queries=gsc,
            rank_data=rank_data,
        )
        assert any("track project" in t.keyword.lower() or "kpis" in t.keyword.lower() for t in targets)

    def test_no_duplicate_questions(self, rank_data):
        targets = discover_answer_targets(
            keywords=["project management"],
            paa_questions=["What is project management?"],
            related_searches=["project management"],
        )
        questions = [t.question.lower() for t in targets]
        assert len(questions) == len(set(questions)), "Duplicate questions should be deduplicated"

    def test_sorted_eligible_first(self, rank_data, snippet_data):
        targets = discover_answer_targets(
            keywords=["best project management software", "trello vs asana", "what is a gantt chart"],
            rank_data=rank_data,
            snippet_data=snippet_data,
        )
        statuses = [t.eligibility_status for t in targets]
        # ELIGIBLE should come before NOT_ELIGIBLE
        if EligibilityStatus.ELIGIBLE in statuses and EligibilityStatus.NOT_ELIGIBLE in statuses:
            eligible_idx = statuses.index(EligibilityStatus.ELIGIBLE)
            not_eligible_idx = statuses.index(EligibilityStatus.NOT_ELIGIBLE)
            assert eligible_idx < not_eligible_idx


# ---------------------------------------------------------------------------
# A5b.2 Eligibility Gate
# ---------------------------------------------------------------------------

class TestEligibilityGate:

    def test_rank_3_is_eligible(self, default_config, rank_data, snippet_data):
        targets = discover_answer_targets(
            keywords=["best project management software"],
            rank_data=rank_data,
            snippet_data=snippet_data,
            config=default_config,
        )
        eligible, near_miss, not_eligible = apply_eligibility_gate(targets, config=default_config)
        assert len(eligible) == 1
        assert eligible[0].eligibility_status == EligibilityStatus.ELIGIBLE

    def test_rank_12_is_near_miss(self, default_config, rank_data, snippet_data):
        targets = discover_answer_targets(
            keywords=["trello vs asana"],
            rank_data=rank_data,
            snippet_data=snippet_data,
            config=default_config,
        )
        _, near_miss, _ = apply_eligibility_gate(targets, config=default_config)
        assert any(t.keyword == "trello vs asana" for t in near_miss)

    def test_rank_22_is_not_eligible(self, default_config, rank_data, snippet_data):
        targets = discover_answer_targets(
            keywords=["what is a gantt chart"],
            rank_data=rank_data,
            snippet_data=snippet_data,
            config=default_config,
        )
        _, _, not_eligible = apply_eligibility_gate(targets, config=default_config)
        assert any("gantt" in t.keyword for t in not_eligible)

    def test_no_rank_data_lands_in_near_miss(self, default_config):
        targets = discover_answer_targets(keywords=["unknown keyword"])
        _, near_miss, _ = apply_eligibility_gate(targets, config=default_config)
        assert len(near_miss) == 1
        assert near_miss[0].eligibility_status == EligibilityStatus.NO_RANK_DATA

    def test_custom_threshold_respected(self, rank_data, snippet_data):
        """Spec: thresholds are configurable, not hard rules."""
        strict_config = AEOConfig(eligibility_rank_threshold=5, near_miss_rank_threshold=8)
        targets = discover_answer_targets(
            keywords=["best project management software", "project management vs task management"],
            rank_data=rank_data,
            snippet_data=snippet_data,
            config=strict_config,
        )
        eligible, near_miss, not_eligible = apply_eligibility_gate(targets, config=strict_config)
        # rank 3 → eligible; rank 8 → near_miss (exactly at near_miss threshold)
        assert any(t.keyword == "best project management software" for t in eligible)


# ---------------------------------------------------------------------------
# A5b.3 Format Matching
# ---------------------------------------------------------------------------

class TestFormatMatching:

    def test_ordered_list_detected(self):
        snippet = "1. Open the app\n2. Click settings\n3. Set your timezone\n4. Save"
        assert infer_format_from_serp(snippet) == SnippetFormat.ORDERED_LIST

    def test_unordered_list_detected(self):
        snippet = "• Trello\n• Asana\n• Monday.com\n• Jira"
        assert infer_format_from_serp(snippet) == SnippetFormat.UNORDERED_LIST

    def test_table_detected(self):
        snippet = "| Tool | Price | Free tier |\n|------|-------|----------|\n| Trello | $5/mo | Yes |"
        assert infer_format_from_serp(snippet) == SnippetFormat.TABLE

    def test_paragraph_default(self):
        snippet = "Project management is the process of leading a team to achieve specific goals."
        assert infer_format_from_serp(snippet) == SnippetFormat.PARAGRAPH

    def test_video_detected(self):
        snippet = "Watch on youtube.com: how to use Trello"
        assert infer_format_from_serp(snippet) == SnippetFormat.VIDEO

    def test_empty_snippet_returns_paragraph(self):
        assert infer_format_from_serp("") == SnippetFormat.PARAGRAPH
        assert infer_format_from_serp(None) == SnippetFormat.PARAGRAPH

    def test_format_instructions_never_force_wrong_format(self):
        """Spec: Never force a table where the SERP shows a list."""
        list_instruction = format_must_match(SnippetFormat.ORDERED_LIST)
        assert "<ol>" in list_instruction or "ol" in list_instruction
        assert "table" not in list_instruction.lower()

    def test_table_instruction_requires_caption_and_scope(self):
        instruction = format_must_match(SnippetFormat.TABLE)
        assert "caption" in instruction.lower()
        assert "scope" in instruction.lower()
        assert "image of a table" in instruction.lower()


# ---------------------------------------------------------------------------
# A5b.4 Answer Block Generator
# ---------------------------------------------------------------------------

class TestAnswerBlockGenerator:

    def _make_eligible_target(self, fmt=SnippetFormat.PARAGRAPH):
        return AnswerTarget(
            keyword="best project management software",
            question="What is the best project management software?",
            surface=SnippetSurface.FEATURED_SNIPPET,
            snippet_format=fmt,
            our_position=3,
            eligibility_status=EligibilityStatus.ELIGIBLE,
        )

    def test_paragraph_block_generated(self, default_config):
        target = self._make_eligible_target(SnippetFormat.PARAGRAPH)
        block = generate_answer_block(
            target,
            "Asana is the best project management software for teams of 5-50 people, "
            "offering task boards, timeline views, and integrations with 200+ tools. "
            "It ranks first in G2's 2024 Enterprise category with a 4.6/5 score.",
            config=default_config,
        )
        assert block.block_id
        assert block.target_format == SnippetFormat.PARAGRAPH
        assert block.word_count > 0

    def test_cross_reference_removed(self, default_config):
        """Spec: decontextualize — no 'as mentioned above'."""
        target = self._make_eligible_target(SnippetFormat.PARAGRAPH)
        raw = "As mentioned above, Asana is the best choice. As we discussed, it has 200 integrations."
        block = generate_answer_block(target, raw, config=default_config)
        assert "as mentioned above" not in block.direct_answer.lower()
        assert "as we discussed" not in block.direct_answer.lower()

    def test_list_block_rendered_as_html(self, default_config):
        target = self._make_eligible_target(SnippetFormat.ORDERED_LIST)
        raw = "1. Set your goals\n2. Assign tasks\n3. Set deadlines\n4. Track progress\n5. Review weekly"
        block = generate_answer_block(target, raw, config=default_config)
        assert "<ol>" in block.rendered_html
        assert "<li>" in block.rendered_html

    def test_unordered_list_rendered(self, default_config):
        target = self._make_eligible_target(SnippetFormat.UNORDERED_LIST)
        raw = "- Trello\n- Asana\n- Monday.com\n- Jira\n- ClickUp"
        block = generate_answer_block(target, raw, config=default_config)
        assert "<ul>" in block.rendered_html

    def test_question_heading_in_html(self, default_config):
        target = self._make_eligible_target(SnippetFormat.PARAGRAPH)
        block = generate_answer_block(target, "Asana is the best tool for small teams.", config=default_config)
        assert "What is the best project management software?" in block.rendered_html

    def test_click_anchor_auto_assigned_with_depth(self, default_config):
        target = self._make_eligible_target(SnippetFormat.PARAGRAPH)
        block = generate_answer_block(
            target,
            "Asana is rated #1 for teams.",
            depth_content="## Full Comparison Table\n\n| Tool | Score |\n|------|------|\n| Asana | 4.6 |",
            config=default_config,
        )
        assert block.click_anchor is not None

    def test_config_thresholds_applied(self, custom_config):
        """Spec: all thresholds are configurable warnings, not hard failures."""
        target = self._make_eligible_target(SnippetFormat.PARAGRAPH)
        # Short answer (under custom min of 30 words) — still generates, just logs warning
        block = generate_answer_block(target, "Asana is great.", config=custom_config)
        assert block.block_id  # block was created despite short answer
        assert "format_warnings" in block.config_snapshot


# ---------------------------------------------------------------------------
# A5b.5 FAQ Module
# ---------------------------------------------------------------------------

class TestFAQModule:

    def test_faq_items_generated(self, default_config):
        items = generate_faq_items(
            paa_questions=["Is Trello free?", "What is Asana used for?"],
            answers={
                "Is Trello free?": "Trello offers a free plan for individuals. Paid plans start at $5/user/month and include automations, timeline views, and admin controls.",
                "What is Asana used for?": "Asana is a work management platform used for task tracking, project planning, and team collaboration. It integrates with tools like Slack, Google Workspace, and Zoom.",
            },
            config=default_config,
        )
        assert len(items) == 2
        assert items[0].question.endswith("?")
        assert items[0].answer

    def test_faqpage_schema_disabled_by_default(self, default_config):
        """Spec: FAQPage removed as Google rich result May 2026; off by default."""
        assert default_config.include_faqpage_schema is False

    def test_faqpage_schema_not_emitted_when_disabled(self, default_config):
        items = generate_faq_items(
            paa_questions=["Is Trello free?"],
            answers={"Is Trello free?": "Yes, Trello has a free plan."},
            config=default_config,
        )
        schema = render_faqpage_schema(items)
        assert schema is None

    def test_faqpage_schema_carries_note_when_enabled(self):
        cfg = AEOConfig(include_faqpage_schema=True)
        items = generate_faq_items(
            paa_questions=["Is Trello free?"],
            answers={"Is Trello free?": "Trello has a free plan for individuals. Paid plans start at $5 per user per month."},
            config=cfg,
        )
        schema = render_faqpage_schema(items)
        assert schema is not None
        # Must carry the honest note about removal
        assert "May 2026" in schema.get("_note", "")
        assert "@type" in schema
        assert schema["@type"] == "FAQPage"

    def test_faq_answer_trimmed_to_max_sentences(self, default_config):
        long_answer = "Sentence one. Sentence two. Sentence three. Sentence four. Sentence five."
        items = generate_faq_items(
            paa_questions=["What is Asana?"],
            answers={"What is Asana?": long_answer},
            config=default_config,  # max 4 sentences
        )
        assert items[0].answer.count(".") <= default_config.faq_answer_max_sentences + 1

    def test_cross_references_removed_from_faq(self, default_config):
        answer = "As mentioned above, Asana is great. As we discussed, it has 200+ integrations."
        items = generate_faq_items(
            paa_questions=["What is Asana?"],
            answers={"What is Asana?": answer},
            config=default_config,
        )
        assert "as mentioned above" not in items[0].answer.lower()


# ---------------------------------------------------------------------------
# A5b.6 Click-Worthiness
# ---------------------------------------------------------------------------

class TestClickWorthiness:

    def _make_block(self, click_anchor=None, depth_content=None):
        from pipeline.adapters.aeo_engine import AnswerBlock, SnippetFormat
        return AnswerBlock(
            block_id="test001",
            question="What is the best PM software?",
            keyword="best pm software",
            target_format=SnippetFormat.PARAGRAPH,
            direct_answer="Asana is rated #1 for teams of 5-50.",
            click_anchor=click_anchor,
            depth_content=depth_content,
        )

    def test_no_depth_triggers_recommendation(self):
        block = self._make_block()
        assessments = analyse_click_worthiness([block], draft="Short draft with no tables or data.")
        assert not assessments[0]["click_worthiness_ok"] or assessments[0].get("recommendation")

    def test_draft_with_table_signals_depth(self):
        block = self._make_block()
        draft_with_table = "| Tool | Price |\n|------|-------|\n| Asana | $10 |\n| Trello | $5 |"
        assessments = analyse_click_worthiness([block], draft=draft_with_table)
        assert "comparison table" in assessments[0]["depth_signals_in_draft"]

    def test_draft_with_code_signals_depth(self):
        block = self._make_block()
        assessments = analyse_click_worthiness([block], draft="Some text.\n```python\nprint('hello')\n```")
        assert "code example" in assessments[0]["depth_signals_in_draft"]


# ---------------------------------------------------------------------------
# A5b.7 Honest Limits
# ---------------------------------------------------------------------------

class TestHonestLimits:

    def test_voice_not_enabled_by_default(self, default_config):
        """Spec: no voice-specific features — direct evidence too thin."""
        assert default_config.voice_enabled is False

    def test_full_report_carries_honest_limits(self):
        result = run_aeo_analysis(
            article_keyword="project management software",
            keywords=["project management software"],
            draft="## What is project management software?\n\nPM software is a tool for tracking tasks.",
        )
        assert "honest_limits" in result
        limits = result["honest_limits"]
        assert "Google chooses" in limits
        assert "cannot predict" in limits.lower() or "guarantee" in limits.lower()

    def test_measurement_snapshot_carries_volatility_note(self):
        targets = [
            AnswerTarget(
                keyword="pm software",
                question="What is the best PM software?",
                eligibility_status=EligibilityStatus.ELIGIBLE,
            )
        ]
        snapshot = create_measurement_snapshot(tracked_targets=targets)
        assert "volatile" in snapshot.volatility_note.lower()

    def test_measurement_snapshot_carries_voice_note(self):
        snapshot = create_measurement_snapshot(tracked_targets=[])
        assert "voice" in snapshot.voice_note.lower()
        assert "thin" in snapshot.voice_note.lower()

    def test_faqpage_note_in_full_report(self):
        result = run_aeo_analysis(
            article_keyword="test",
            keywords=["test keyword"],
            draft="Short draft.",
        )
        note = result.get("faqpage_schema_note", "")
        assert "May 2026" in note

    def test_not_eligible_action_is_seo_first(self, rank_data, snippet_data):
        """Spec: if not eligible, pipeline action is plain SEO first."""
        targets = discover_answer_targets(
            keywords=["what is a gantt chart"],
            rank_data=rank_data,
            snippet_data=snippet_data,
        )
        _, _, not_eligible = apply_eligibility_gate(targets)
        assert len(not_eligible) == 1
        # Not-eligible targets should have low priority
        assert not_eligible[0].priority == "low"


# ---------------------------------------------------------------------------
# A5b: Entity Layer & Wikipedia Conflict of Interest Safeguards
# ---------------------------------------------------------------------------

class TestEntityLayerAndCOI:

    def test_entity_layer_generates_organization_and_person(self):
        cfg = EntityLayerConfig(
            organization_name="Evergreen Ops",
            organization_url="https://evergreenops.com",
            wikidata_id="Q123456",
            same_as_links=["https://twitter.com/evergreenops"],
            person_authors=[{"name": "Jane Doe", "sameAs": ["https://linkedin.com/in/janedoe"]}],
            is_local_brand=False,
        )
        layer = generate_entity_layer(cfg)
        assert layer["organization_schema"]["@type"] == "Organization"
        assert layer["organization_schema"]["name"] == "Evergreen Ops"
        assert "https://www.wikidata.org/wiki/Q123456" in layer["organization_schema"]["sameAs"]
        assert layer["person_schema"]["name"] == "Jane Doe"
        assert layer["wikipedia_coi_compliant"] is True
        assert "Never self-edit Wikipedia" in layer["coi_safeguard_warning"]

    def test_entity_layer_filters_wikipedia_coi_drafts_and_user_pages(self):
        """Spec: Never self-edit Wikipedia against its conflict-of-interest rules."""
        cfg = EntityLayerConfig(
            organization_name="Spam Brand",
            same_as_links=[
                "https://en.wikipedia.org/wiki/User:SpamBrand/draft",
                "https://en.wikipedia.org/wiki/Draft:SpamBrand",
                "https://www.wikidata.org/wiki/Q999",
            ],
            person_authors=[{"name": "Spammer", "sameAs": ["https://en.wikipedia.org/w/index.php?title=User:Spammer&action=edit"]}],
        )
        layer = generate_entity_layer(cfg)
        assert layer["wikipedia_coi_compliant"] is False
        assert len(layer["coi_violations_filtered"]) == 3
        # Valid wikidata remains in sameAs
        assert any("wikidata.org" in s for s in layer["organization_schema"].get("sameAs", []))
        # COI warning attached
        assert "Never self-edit Wikipedia against its conflict-of-interest rules." == layer["coi_safeguard_warning"]

    def test_entity_layer_local_brand_google_business_profile(self):
        cfg = EntityLayerConfig(
            organization_name="Local Dental Clinic",
            google_business_profile_url="https://maps.google.com/?cid=1234567890",
            is_local_brand=True,
        )
        layer = generate_entity_layer(cfg)
        assert layer["organization_schema"]["@type"] == "LocalBusiness"
        assert layer["organization_schema"]["hasMap"] == "https://maps.google.com/?cid=1234567890"


# ---------------------------------------------------------------------------
# A5b: Answer Block Claim Verification (A4 Integration)
# ---------------------------------------------------------------------------

class TestAnswerBlockClaimVerification:

    def test_verify_answer_block_claims_with_search_sources(self):
        """Spec: Every answer block is verified in A4 as its own claim set."""
        target = AnswerTarget(
            keyword="project management software",
            question="What is project management software?",
            snippet_format=SnippetFormat.PARAGRAPH,
        )
        block = generate_answer_block(
            target,
            "Project management software helps distributed teams plan timelines, allocate resources, and track deliverables in real-time."
        )
        sources = [
            {
                "url": "https://pmi.org/guide",
                "snippet": "Project management software allows distributed teams to plan timelines, track milestones, and manage resources efficiently.",
            }
        ]
        verified_block = verify_answer_block_claims(block, search_sources=sources)
        assert verified_block.fact_verified is True
        assert len(verified_block.fact_check_claims) > 0
        first_claim = verified_block.fact_check_claims[0]
        assert first_claim["verdict"] == "supported"
        assert first_claim["confidence"] >= 0.90
        assert first_claim["source_url"] == "https://pmi.org/guide"

    def test_verify_answer_block_claims_fallback_empirical(self):
        target = AnswerTarget(
            keyword="scrum vs kanban",
            question="What is the difference between Scrum and Kanban?",
            snippet_format=SnippetFormat.PARAGRAPH,
        )
        block = generate_answer_block(
            target,
            "Scrum uses fixed-length sprints of two weeks. Kanban focuses on continuous delivery with work-in-progress limits."
        )
        verified_block = verify_answer_block_claims(block, search_sources=[])
        assert verified_block.fact_verified is True
        assert len(verified_block.fact_check_claims) == 2
        for c in verified_block.fact_check_claims:
            assert c["verdict"] == "supported"


# ---------------------------------------------------------------------------
# A5b: Enhanced Measurement, Won/Lost Events & KPIs
# ---------------------------------------------------------------------------

class TestEnhancedMeasurementAndKPIs:

    def test_measurement_tracks_won_events_and_kpis(self):
        targets = [
            AnswerTarget(
                keyword="task board",
                question="What is a task board?",
                snippet_format=SnippetFormat.PARAGRAPH,
                our_url="https://ourbrand.com/task-board",
            ),
            AnswerTarget(
                keyword="agile burndown",
                question="What is an agile burndown chart?",
                snippet_format=SnippetFormat.PARAGRAPH,
                our_url="https://ourbrand.com/burndown",
            ),
        ]
        serp_results = {
            "task board": {
                "snippet_owner_domain": "ourbrand.com",
                "paa_includes_our_url": True,
                "aio_cites_our_url": True,
            },
            "agile burndown": {
                "snippet_owner_domain": "competitor.com",
                "paa_includes_our_url": False,
                "aio_cites_our_url": False,
            },
        }
        sc_data = {
            "task board": {"impressions": 1200, "ctr": 0.01},  # zero-click candidate
        }
        snapshot = create_measurement_snapshot(
            tracked_targets=targets,
            serp_results=serp_results,
            sc_data=sc_data,
            our_domain="ourbrand.com",
        )
        assert snapshot.snippet_wins == 1
        assert snapshot.ownership_share_pct == 50.0
        assert snapshot.paa_presence_pct == 50.0
        assert snapshot.aio_citation_share_pct == 50.0
        assert len(snapshot.won_events) == 1
        assert snapshot.won_events[0]["keyword"] == "task board"
        assert "task board" in snapshot.zero_click_candidates
        assert snapshot.kpis["total_won_events"] == 1
        assert snapshot.kpis["total_tracked"] == 2

    def test_measurement_tracks_lost_events(self):
        target = AnswerTarget(
            keyword="sprint planning",
            question="How to run sprint planning?",
            won_at="2026-09-01T00:00:00Z",
            our_url="https://ourbrand.com/sprint-planning",
        )
        serp_results = {
            "sprint planning": {
                "snippet_owner_domain": "competitor.com",
            }
        }
        snapshot = create_measurement_snapshot(
            tracked_targets=[target],
            serp_results=serp_results,
            our_domain="ourbrand.com",
        )
        assert snapshot.snippet_losses == 1
        assert len(snapshot.lost_events) == 1
        assert snapshot.lost_events[0]["keyword"] == "sprint planning"
        assert snapshot.lost_events[0]["new_owner"] == "competitor.com"


# ---------------------------------------------------------------------------
# A5b: Database Persistence & CRUD
# ---------------------------------------------------------------------------

class TestAEOStorageCRUD:

    def test_upsert_and_retrieve_answer_targets(self):
        from storage.db import (
            init_db,
            upsert_answer_target,
            get_answer_targets_by_website,
            delete_answer_target,
        )
        init_db()
        t_data = {
            "website_id": "test_site_aeo",
            "keyword": "user story mapping",
            "question": "What is user story mapping?",
            "surface": "snippet",
            "snippet_format": "ordered_list",
            "current_owner_domain": "atlassian.com",
            "our_position": 4,
            "eligibility_status": "eligible",
        }
        tid = upsert_answer_target(t_data)
        assert tid is not None

        records = get_answer_targets_by_website("test_site_aeo")
        found = [r for r in records if r["keyword"] == "user story mapping"]
        assert len(found) == 1
        assert found[0]["question"] == "What is user story mapping?"
        assert found[0]["our_position"] == 4

        # Clean up
        deleted = delete_answer_target(found[0]["id"])
        assert deleted is True

    def test_record_and_retrieve_aeo_snapshots(self):
        from storage.db import record_aeo_measurement_snapshot, get_aeo_measurement_snapshots
        snap_data = {
            "snapshot_at": "2026-10-06T12:00:00Z",
            "keywords_tracked": 10,
            "snippet_wins": 3,
            "snippet_losses": 1,
            "ownership_share_pct": 30.0,
            "won_events": [{"keyword": "kw1", "won_at": "2026-10-06T12:00:00Z"}],
            "lost_events": [{"keyword": "kw2", "lost_at": "2026-10-06T12:00:00Z"}],
            "zero_click_candidates": ["kw1"],
            "kpis": {"snippet_ownership_share_pct": 30.0},
        }
        sid = record_aeo_measurement_snapshot("test_site_aeo", snap_data)
        assert sid is not None

        history = get_aeo_measurement_snapshots("test_site_aeo", limit=5)
        assert len(history) >= 1
        assert history[0]["keywords_tracked"] == 10
        assert history[0]["ownership_share_pct"] == 30.0


# ---------------------------------------------------------------------------
# A5b: FastAPI REST API Endpoints
# ---------------------------------------------------------------------------

class TestAEOFastAPIRoutes:

    def test_aeo_api_flow(self):
        from fastapi.testclient import TestClient
        from web.app import app
        client = TestClient(app)

        # 1. Config
        cfg_resp = client.get("/api/aeo/config")
        assert cfg_resp.status_code == 200
        cfg_json = cfg_resp.json()
        assert "config" in cfg_json
        assert cfg_json["config"]["eligibility_rank_threshold"] == 10

        # Update config
        up_resp = client.post("/api/aeo/config", json={"eligibility_rank_threshold": 8, "paragraph_min_words": 42})
        assert up_resp.status_code == 200
        assert up_resp.json()["config"]["eligibility_rank_threshold"] == 8
        assert up_resp.json()["config"]["paragraph_min_words"] == 42

        # 2. Targets upsert & get
        post_target = client.post("/api/aeo/targets", json={
            "website_id": "api_test_site",
            "keyword": "what is velocity in agile",
            "surface": "snippet",
            "snippet_format": "paragraph",
        })
        assert post_target.status_code == 200
        target_id = post_target.json()["target_id"]

        get_targets = client.get("/api/aeo/targets?website_id=api_test_site")
        assert get_targets.status_code == 200
        assert get_targets.json()["total"] >= 1

        # Delete target
        del_target = client.delete(f"/api/aeo/targets/{target_id}")
        assert del_target.status_code == 200

        # 3. Measurement
        measure_resp = client.get("/api/aeo/measurement")
        assert measure_resp.status_code == 200
        assert "honest_limits" in measure_resp.json()

        # 4. Verify block claim
        verify_resp = client.post("/api/aeo/verify-block", json={
            "keyword": "kanban wip limits",
            "question": "What are Kanban WIP limits?",
            "direct_answer": "WIP limits restrict maximum unfinished tasks at any workflow stage.",
            "target_format": "paragraph",
        })
        assert verify_resp.status_code == 200
        assert verify_resp.json()["verified_block"]["fact_verified"] is True

