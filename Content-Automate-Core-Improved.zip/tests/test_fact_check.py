"""
Unit tests for Fact Verification Node (Pillar I).
Tests claim extraction, verdict evaluation, and auto-correction.
"""

import pytest
from unittest.mock import patch
from pipeline.nodes.fact_check_node import (
    evaluate_claims_verdict,
    auto_correct_draft_claims,
    fact_check_node
)


def test_evaluate_claims_verdict_supported():
    claims_with_evidence = [
        {
            "claim_id": "c1",
            "statement": "PostgreSQL is an open-source object-relational database system.",
            "evidence": [
                {
                    "title": "PostgreSQL Docs",
                    "url": "https://www.postgresql.org",
                    "snippet": "PostgreSQL is a powerful, open-source object-relational database system."
                }
            ]
        }
    ]

    mock_llm_response = """```json
    {
      "verified_claims": [
        {
          "claim_id": "c1",
          "statement": "PostgreSQL is an open-source object-relational database system.",
          "verdict": "Supported",
          "confidence_score": 0.98,
          "source_url": "https://www.postgresql.org",
          "reasoning": "Corroborated by official documentation.",
          "correction": null
        }
      ],
      "overall_verdict": "supported",
      "summary": "Verified by official PostgreSQL docs."
    }
    ```"""

    with patch("pipeline.nodes.fact_check_node.call_llm", return_value=mock_llm_response):
        result = evaluate_claims_verdict(claims_with_evidence)
        assert result["overall_verdict"] == "supported"
        assert result["fact_check_score"] == 100
        assert len(result["verified_claims"]) == 1
        assert result["verified_claims"][0]["verdict"] == "Supported"


def test_auto_correct_draft_claims():
    original_draft = "# Title\n\nPostgreSQL is an in-memory key-value cache."
    verified_claims = [
        {
            "claim_id": "c1",
            "statement": "PostgreSQL is an in-memory key-value cache.",
            "verdict": "Contradicted",
            "source_url": "https://www.postgresql.org",
            "correction": "PostgreSQL is an open-source relational database system."
        }
    ]

    mock_corrected_draft = "# Title\n\nPostgreSQL is an open-source relational database system."

    with patch("pipeline.nodes.fact_check_node.call_llm", return_value=mock_corrected_draft):
        corrected = auto_correct_draft_claims(original_draft, verified_claims)
        assert "PostgreSQL is an open-source relational database system." in corrected


def test_fact_check_node_empty_draft():
    state = {"draft": ""}
    output = fact_check_node(state)
    assert output["fact_check_score"] == 100
    assert output["fact_check_verdict"] == "supported"
