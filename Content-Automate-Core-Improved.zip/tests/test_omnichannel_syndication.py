"""
Unit tests for Omnichannel Syndication via Headless Postiz (Pillar V).
"""

import pytest
from unittest.mock import patch, MagicMock
from pipeline.adapters.postiz_client import schedule_postiz_publication
from pipeline.nodes.repurpose_node import repurpose_node


def test_schedule_postiz_staged_locally_when_unconfigured():
    with patch("pipeline.adapters.postiz_client.config") as mock_cfg:
        mock_cfg.POSTIZ_API_URL = ""
        mock_cfg.POSTIZ_API_KEY = ""
        res = schedule_postiz_publication(
            title="Architecting Authority Beyond TrySoro",
            copy_by_platform={"twitter": "Tweet text", "linkedin": "LinkedIn text"}
        )
        assert res["status"] == "staged_locally"
        assert "twitter" in res["platforms"]


def test_schedule_postiz_http_success():
    with patch("pipeline.adapters.postiz_client.config") as mock_cfg:
        mock_cfg.POSTIZ_API_URL = "https://postiz.internal.local"
        mock_cfg.POSTIZ_API_KEY = "test_key_123"

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"id": "post_789", "scheduled": True}
            mock_client.post.return_value = mock_resp
            mock_client_cls.return_value.__enter__.return_value = mock_client

            res = schedule_postiz_publication(
                title="Architecting Authority Beyond TrySoro",
                copy_by_platform={"twitter": "Tweet text"}
            )
            assert res["status"] == "success"
            assert res["postiz_response"]["id"] == "post_789"


def test_repurpose_node_includes_social_copy_and_postiz():
    mock_llm_json = """```json
    {
      "linkedin_post": "Detailed LinkedIn analysis...",
      "twitter_thread": ["1/3 Hook...", "2/3 Evidence...", "3/3 Conclusion..."]
    }
    ```"""

    state = {
        "title": "Autonomous Editorial Publishing Engine",
        "topic": "SEO and GEO Optimization",
        "meta_description": "Building programmatic editorial content pipelines.",
        "draft": "# Title\\n\\nProse content...",
        "hero_image_url": "/uploads/hero.webp"
    }

    with patch("pipeline.nodes.repurpose_node.call_llm", return_value=mock_llm_json):
        output = repurpose_node(state)
        assert "linkedin_post" in output
        assert "twitter_thread" in output
        assert output["postiz_status"] in ("staged", "staged_locally", "success")

