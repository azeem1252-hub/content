"""
Tests for A5c: Article Production Studio.

Validates:
- All 14 block types: heading, paragraph, answer_block, key_takeaways, list, table,
  figure (diagram | chart | image | screenshot), callout, quote (real, attributed),
  code, faq, references, cta, author_box.
- Every block carries claims[] and sources[]; figures carry alt, caption, credit, provenance.
- All 7 article blueprints: how_to, comparison, definition, roundup, data_study, case_study, pillar.
- Blueprint configuration per site (custom overrides).
- Verification (A4) and lint run on the model ONCE.
- Renderers: Semantic HTML, Markdown/MDX, WordPress blocks (JSON + comment HTML), CMS-specific payloads.
- Markdown draft parser into typed document model.
- LangGraph node execution.
"""

import json
import pytest
from datetime import datetime, timezone

from pipeline.adapters.article_model import (
    ArticleDocumentModel,
    ArticleType,
    ArticleBlueprint,
    BlueprintComponent,
    BLUEPRINTS,
    HeadingBlock,
    ParagraphBlock,
    AnswerBlock,
    KeyTakeawaysBlock,
    ListBlock,
    TableBlock,
    FigureBlock,
    FigureProvenance,
    CalloutBlock,
    QuoteBlock,
    CodeBlock,
    FAQBlock,
    ReferencesBlock,
    CTABlock,
    AuthorBoxBlock,
    ClaimRef,
    SourceRef,
    ArticleRenderers,
    check_blueprint_compliance,
    lint_article_model,
    attach_verification_to_model,
    get_blueprint_for_site,
    configure_site_blueprint,
    parse_markdown_to_model,
    VisualSituation,
    VisualComponentKind,
    VisualDecisionRule,
    DEFAULT_VISUAL_RULES,
    VisualProposal,
    VisualDensityAnalysis,
    HardProhibitionsReport,
    VisualPlanReport,
    VisualDecisionConfig,
    validate_mermaid_syntax,
    render_mermaid_to_svg,
    audit_hard_prohibitions,
    analyze_visual_density,
    plan_visuals_for_article,
)
from pipeline.nodes.article_studio_node import article_studio_node, _infer_article_type
from pipeline.state import ContentState


# ===========================================================================
# 1. Block Types (A5c.1)
# ===========================================================================

class TestBlockTypes:
    def test_all_14_block_types_instantiate(self):
        """Every specified block type can be created and carries claims[] and sources[]."""
        prov = FigureProvenance(source="ai_generated", generator="cloudflare/flux-1-schnell")
        
        blocks = [
            HeadingBlock(level=2, text="Introduction"),
            ParagraphBlock(text="This is an editorial paragraph with crucial context."),
            AnswerBlock(
                question="What is LangGraph?",
                direct_answer="LangGraph is a framework for building stateful, multi-agent workflows using graphs.",
                heading_level=2,
            ),
            KeyTakeawaysBlock(items=["Point 1", "Point 2", "Point 3"]),
            ListBlock(ordered=True, items=["Step 1: Install", "Step 2: Configure"]),
            TableBlock(
                caption="Feature Comparison",
                headers=["Feature", "Tool A", "Tool B"],
                rows=[["Speed", "Fast", "Normal"], ["Cost", "$10", "$20"]],
                last_checked="2026-10-01",
            ),
            FigureBlock(
                kind="screenshot",
                src="/uploads/dash.png",
                alt="Studio Dashboard Interface",
                caption="The editorial production dashboard in action.",
                credit="Screenshot by Editorial Team",
                provenance=FigureProvenance(source="real_screenshot"),
                software_version="v2.4",
            ),
            FigureBlock(
                kind="chart",
                src="/uploads/retention.png",
                alt="User Retention Chart",
                caption="90-day retention curve across 5,000 users.",
                credit="Source: Internal Telemetry",
                provenance=FigureProvenance(source="original_data"),
                data_source="https://data.example.com/retention.csv",
                chart_type="line",
            ),
            CalloutBlock(variant="tip", title="Pro Tip", text="Always test endpoints in dev first."),
            QuoteBlock(
                text="The pipeline cut our editorial cycle from 4 days to 4 hours.",
                speaker="Jane Doe",
                role="VP of Content",
                organisation="Acme Corp",
            ),
            CodeBlock(language="python", code="pip install langgraph", caption="Installation command"),
            FAQBlock(items=[{"question": "Is it free?", "answer": "Yes, open-source."}]),
            ReferencesBlock(items=[{"title": "Google Search Central", "url": "https://developers.google.com"}]),
            CTABlock(text="Ready to build?", button_label="Try Now", button_url="https://example.com/signup"),
            AuthorBoxBlock(name="Sarah Connor", bio="Technical writer and systems architect.", role="Lead Editor"),
        ]

        assert len(blocks) == 15
        
        # Verify every block carries claims and sources
        for b in blocks:
            assert hasattr(b, "claims")
            assert hasattr(b, "sources")
            assert hasattr(b, "block_id")
            assert b.block_id != ""

    def test_claims_and_sources_attached_to_block(self):
        """Blocks carry ClaimRef and SourceRef for verification."""
        p = ParagraphBlock(text="Cloudflare processes over 55 million HTTP requests per second.")
        p.claims.append(ClaimRef(
            claim_text="Cloudflare processes 55M requests/sec",
            source_url="https://cloudflare.com/network",
            verified=True,
            confidence=0.99,
        ))
        p.sources.append(SourceRef(
            url="https://cloudflare.com/network",
            title="Cloudflare Network Status",
        ))

        assert len(p.claims) == 1
        assert p.claims[0].verified is True
        assert len(p.sources) == 1
        assert p.sources[0].url == "https://cloudflare.com/network"

    def test_figure_provenance_and_metadata(self):
        """Figures carry alt, caption, credit, and provenance."""
        fig = FigureBlock(
            kind="diagram",
            src="/uploads/architecture.webp",
            alt="Multi-Agent Pipeline Architecture Diagram",
            caption="Complete flow from outline to distribution.",
            credit="Generated via Graphviz & Flux",
            provenance=FigureProvenance(
                source="ai_generated",
                generator="gemini-2.5-flash-image",
                license="CC-BY-SA-4.0",
            ),
        )
        assert fig.kind == "diagram"
        assert fig.alt == "Multi-Agent Pipeline Architecture Diagram"
        assert fig.caption == "Complete flow from outline to distribution."
        assert fig.credit == "Generated via Graphviz & Flux"
        assert fig.provenance.source == "ai_generated"
        assert fig.provenance.generator == "gemini-2.5-flash-image"


# ===========================================================================
# 2. Blueprints by Article Type (A5c.2)
# ===========================================================================

class TestBlueprints:
    def test_all_7_blueprints_registered(self):
        """All 7 blueprints from the spec table exist."""
        expected = ["how_to", "comparison", "definition", "roundup", "data_study", "case_study", "pillar"]
        for bp_key in expected:
            assert bp_key in BLUEPRINTS, f"Missing blueprint: {bp_key}"
            bp = BLUEPRINTS[bp_key]
            assert bp.display_name != ""
            assert len(bp.required_components) > 0

    def test_how_to_blueprint_components(self):
        """How-to blueprint requires answer-first intro, key takeaways, numbered steps, FAQ."""
        bp = BLUEPRINTS["how_to"]
        req_types = [c.block_type for c in bp.required_components]
        assert "answer_block" in req_types
        assert "key_takeaways" in req_types
        assert "list" in req_types
        assert "faq" in req_types

    def test_comparison_blueprint_components(self):
        """Comparison requires verdict up top, comparison table, criteria, sources."""
        bp = BLUEPRINTS["comparison"]
        req_types = [c.block_type for c in bp.required_components]
        assert "answer_block" in req_types
        assert "table" in req_types
        assert "paragraph" in req_types
        assert "references" in req_types

    def test_definition_blueprint_components(self):
        """Definition requires definition answer block, why it matters, example."""
        bp = BLUEPRINTS["definition"]
        req_types = [c.block_type for c in bp.required_components]
        assert "answer_block" in req_types
        assert "paragraph" in req_types

    def test_roundup_blueprint_components(self):
        """Roundup requires selection criteria, consistent list, summary table."""
        bp = BLUEPRINTS["roundup"]
        req_types = [c.block_type for c in bp.required_components]
        assert "paragraph" in req_types
        assert "list" in req_types
        assert "table" in req_types

    def test_data_study_blueprint_components(self):
        """Data study requires methodology, charts from real data, raw dataset cta, limitations."""
        bp = BLUEPRINTS["data_study"]
        req_types = [c.block_type for c in bp.required_components]
        assert "paragraph" in req_types
        assert "figure" in req_types
        assert "cta" in req_types

    def test_case_study_blueprint_components(self):
        """Case study requires customer context, real numbers, timeline."""
        bp = BLUEPRINTS["case_study"]
        req_types = [c.block_type for c in bp.required_components]
        assert "paragraph" in req_types
        assert "list" in req_types

    def test_pillar_blueprint_components(self):
        """Pillar requires TOC, section answer blocks, internal link hub."""
        bp = BLUEPRINTS["pillar"]
        req_types = [c.block_type for c in bp.required_components]
        assert "list" in req_types
        assert "answer_block" in req_types
        assert "references" in req_types

    def test_blueprint_site_customization(self):
        """Per-site blueprint configuration can override min_word_count and required components."""
        site_id = "gaming-hub"
        overrides = {
            "min_word_count": 1200,
            "max_word_count": 4500,
        }
        custom_bp = configure_site_blueprint(site_id, "how_to", overrides)
        assert custom_bp.min_word_count == 1200
        assert custom_bp.max_word_count == 4500

        resolved = get_blueprint_for_site("how_to", {"site_id": site_id})
        assert resolved.min_word_count == 1200


# ===========================================================================
# 3. Verification & Linting on the Model (A5c.1)
# ===========================================================================

class TestVerificationAndLint:
    def test_attach_verification_to_matching_blocks(self):
        """attach_verification_to_model attaches verified claims to matching blocks."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="How to Configure Next.js Rewrites",
            slug="nextjs-rewrites",
            blocks=[
                ParagraphBlock(text="Next.js rewrites allow you to map an incoming request path to a different destination path."),
                ParagraphBlock(text="Rewrites act as a URL proxy and mask the destination path, making it appear the user has not changed their location."),
            ]
        )

        verified_claims = [
            {
                "statement": "Next.js rewrites allow you to map an incoming request path to a different destination path",
                "verdict": "Supported",
                "source_url": "https://nextjs.org/docs/app/api-reference/next-config-js/rewrites",
                "confidence": 0.98,
            },
            {
                "statement": "Rewrites permanently redirect the browser with a 301 status code",
                "verdict": "Contradicted",
                "correction": "Rewrites do not redirect the browser; they mask the destination without changing the URL.",
            }
        ]

        doc = attach_verification_to_model(doc, verified_claims)

        summary = doc.fact_verification_summary
        assert summary is not None
        assert summary["total_claims"] == 2
        assert summary["supported"] == 1
        assert summary["contradicted"] == 1
        assert summary["all_supported"] is False

        # First block should be verified True
        assert doc.blocks[0].verified is True
        assert len(doc.blocks[0].claims) == 1

    def test_contradicted_claims_trigger_lint_warnings(self):
        """Contradicted claims create explicit lint warnings."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Test",
            slug="test",
            blocks=[
                ParagraphBlock(text="Postgres 16 was released in 1995."),
            ]
        )
        claims = [{
            "statement": "Postgres 16 was released in 1995",
            "verdict": "Contradicted",
            "correction": "PostgreSQL 16 was released in September 2023.",
        }]
        doc = attach_verification_to_model(doc, claims)
        report = lint_article_model(doc)

        assert any("CONTRADICTED" in w for w in report.warnings)
        assert doc.blocks[0].verified is False

    def test_lint_detects_missing_figure_alt_and_caption(self):
        """Linting flags figures without alt text or caption."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Guide",
            slug="guide",
            blocks=[
                FigureBlock(
                    kind="image",
                    src="/uploads/pic.jpg",
                    alt="image",  # Generic!
                    caption="",   # Empty!
                    provenance=FigureProvenance(source="stock"),
                )
            ]
        )
        report = lint_article_model(doc)
        assert any("Alt text is missing or generic" in w for w in report.warnings)
        assert any("Figure caption is missing" in w for w in report.warnings)

    def test_lint_detects_chart_without_data_source(self):
        """Charts must specify a data_source linking to verifiable data."""
        doc = ArticleDocumentModel(
            article_type="data_study",
            title="Benchmark Study",
            slug="benchmarks",
            blocks=[
                FigureBlock(
                    kind="chart",
                    src="/uploads/chart.png",
                    alt="Latency Benchmark Chart",
                    caption="P99 latency comparison.",
                    data_source=None,  # Missing!
                    provenance=FigureProvenance(source="original_data"),
                )
            ]
        )
        report = lint_article_model(doc)
        assert any("data_source" in w for w in report.warnings)

    def test_lint_detects_unattributed_quotes(self):
        """Quotes must have an attributed speaker and a source."""
        doc = ArticleDocumentModel(
            article_type="case_study",
            title="Case Study",
            slug="case-study",
            blocks=[
                QuoteBlock(
                    text="We loved using this software.",
                    speaker="",  # Missing!
                )
            ]
        )
        report = lint_article_model(doc)
        assert any("attributed speaker" in w for w in report.warnings)
        assert any("verifiable source citation" in w for w in report.warnings)

    def test_lint_evaluates_answer_block_practitioner_length(self):
        """Answer blocks are checked against practitioner rule of thumb (40-60 words)."""
        doc = ArticleDocumentModel(
            article_type="definition",
            title="What is RAG?",
            slug="what-is-rag",
            blocks=[
                AnswerBlock(
                    question="What is RAG?",
                    direct_answer="RAG stands for retrieval augmented generation.",  # Only 6 words!
                    heading_level=2,
                )
            ]
        )
        report = lint_article_model(doc)
        assert any("Answer block is too brief" in w for w in report.warnings)


# ===========================================================================
# 4. Renderers (A5c.1)
# ===========================================================================

class TestRenderers:
    @pytest.fixture
    def sample_doc(self) -> ArticleDocumentModel:
        prov = FigureProvenance(source="ai_generated", generator="flux-1-schnell")
        return ArticleDocumentModel(
            article_type="comparison",
            title="Next.js vs Remix in 2026",
            slug="nextjs-vs-remix",
            meta_description="A comprehensive architectural comparison between Next.js and Remix.",
            author="Dev Advocate",
            blocks=[
                AnswerBlock(
                    question="Which is better, Next.js or Remix?",
                    direct_answer="Next.js is better suited for enterprise applications requiring Server Actions and Static Site Generation, while Remix excels at nested routing and resilient forms.",
                    heading_level=2,
                ),
                TableBlock(
                    caption="Architecture Overview",
                    headers=["Feature", "Next.js", "Remix"],
                    rows=[["React Server Components", "Native", "Via Vite"], ["Routing", "App Router", "Nested Routes"]],
                    last_checked="2026-10-01",
                ),
                CalloutBlock(variant="tip", title="Decision Matrix", text="Choose Next.js if deploying on Vercel."),
                FigureBlock(
                    kind="diagram",
                    src="/uploads/routing-flow.webp",
                    alt="Routing Execution Pipeline",
                    caption="Client to server lifecycle across both frameworks.",
                    credit="Antigravity Graphics",
                    provenance=prov,
                ),
                QuoteBlock(
                    text="Remix prioritises web fundamentals, while Next.js pushes React boundaries.",
                    speaker="Alex Rivera",
                    role="Principal Architect",
                    sources=[SourceRef(url="https://example.com/interview")],
                ),
                CodeBlock(language="typescript", code="export default function Page() { return <h1>Hello</h1>; }"),
                FAQBlock(items=[{"question": "Can I use both?", "answer": "Usually you choose one framework per project."}]),
                ReferencesBlock(items=[{"title": "Next.js Docs", "url": "https://nextjs.org"}]),
                CTABlock(text="Start migrating today.", button_label="Download Guide", button_url="https://example.com/guide"),
            ]
        )

    def test_render_semantic_html(self, sample_doc):
        """Semantic HTML renderer emits proper article, table, caption, figure, and block tags."""
        html = ArticleRenderers.to_html(sample_doc)
        
        assert '<article data-doc-id=' in html
        assert '<h1>Next.js vs Remix in 2026</h1>' in html
        assert '<section class=\'answer-block\'>' in html
        assert '<table>' in html
        assert '<caption>Architecture Overview' in html
        assert '<th scope="col">Next.js</th>' in html
        assert '<figure>' in html
        assert '<img src="/uploads/routing-flow.webp"' in html
        assert '<figcaption>Client to server lifecycle' in html
        assert '<aside class="callout callout-tip">' in html
        assert '<blockquote>' in html
        assert '<cite>Alex Rivera' in html
        assert '<figure class=\'code-block\'>' in html
        assert '<section class=\'faq\'>' in html
        assert '<section class=\'references\'>' in html
        assert '<aside class="cta cta-primary">' in html

    def test_render_markdown(self, sample_doc):
        """Markdown renderer produces clean Markdown with pipe tables, blockquotes, and code fences."""
        md = ArticleRenderers.to_markdown(sample_doc)
        
        assert "# Next.js vs Remix in 2026" in md
        assert "## Which is better, Next.js or Remix?" in md
        assert "| Feature | Next.js | Remix |" in md
        assert "> **Decision Matrix:** Choose Next.js if deploying on Vercel." in md
        assert "![Routing Execution Pipeline](/uploads/routing-flow.webp)" in md
        assert "> — Alex Rivera" in md
        assert "```typescript" in md
        assert "## Frequently Asked Questions" in md
        assert "## References" in md
        assert "[Download Guide](https://example.com/guide)" in md

    def test_render_wordpress_blocks_json(self, sample_doc):
        """to_wordpress_blocks emits Gutenberg JSON structures for WordPress REST API."""
        wp_blocks = ArticleRenderers.to_wordpress_blocks(sample_doc)
        assert len(wp_blocks) > 0
        
        block_names = [b["blockName"] for b in wp_blocks]
        assert "core/paragraph" in block_names
        assert "core/table" in block_names
        assert "core/image" in block_names
        assert "core/quote" in block_names
        assert "core/code" in block_names

    def test_render_wordpress_html_comments(self, sample_doc):
        """to_wordpress_html emits standard Gutenberg block HTML comment delimiters."""
        wp_html = ArticleRenderers.to_wordpress_html(sample_doc)
        
        assert "<!-- wp:heading" in wp_html
        assert "<!-- /wp:heading -->" in wp_html
        assert "<!-- wp:paragraph -->" in wp_html
        assert "<!-- wp:table -->" in wp_html
        assert "<!-- wp:image" in wp_html
        assert "<!-- wp:quote -->" in wp_html

    def test_render_cms_payload_nextjs(self, sample_doc):
        """to_cms_payload enforces Next.js frontmatter and /uploads/ image rule."""
        payload = ArticleRenderers.to_cms_payload(sample_doc, cms_type="nextjs")
        
        assert payload["title"] == sample_doc.title
        assert payload["slug"] == sample_doc.slug
        assert "frontmatter" in payload
        fm = payload["frontmatter"]
        assert fm["slug"] == "nextjs-vs-remix"
        assert fm["hero_image_url"].startswith("/uploads/")
        assert not fm["hero_image_url"].startswith("/static/uploads/")
        assert "content" in payload
        assert "html" in payload


# ===========================================================================
# 5. Markdown Draft Parser (parse_markdown_to_model)
# ===========================================================================

class TestMarkdownParser:
    def test_parse_complex_markdown_into_typed_blocks(self):
        """Existing Markdown draft parses into all block types."""
        md = """
## What is Docker?

Docker is an open-source platform that enables developers to build, deploy, and run applications in isolated containers across any infrastructure.

> **Key Takeaways**
> - Containers package code with all dependencies.
> - Docker runs natively on Linux.
> - Images are immutable templates.

### Core Comparison

| Feature | Docker | Virtual Machine |
|---|---|---|
| Startup | Milliseconds | Minutes |
| Overhead | Low | High |

*Comparison of containers vs VMs*

> **Tip:** Always use multi-stage builds to keep image sizes small.

> "Docker changed how we ship software forever."
> — Solomon Hykes, Founder

![Docker Architecture Diagram](/uploads/docker-arch.png)
*Architecture of the Docker daemon and client*

```bash
docker run -d -p 80:80 nginx:alpine
```

## FAQ

### Is Docker free for commercial use?
Docker Desktop requires a paid subscription for enterprises, but the Docker engine remains open-source.

## References

1. [Official Docker Documentation](https://docs.docker.com)
"""
        doc = parse_markdown_to_model(
            markdown=md,
            title="Understanding Docker",
            slug="understanding-docker",
            article_type="how_to",
        )

        types = [b.block_type for b in doc.blocks]
        assert "answer_block" in types
        assert "key_takeaways" in types
        assert "table" in types
        assert "callout" in types
        assert "quote" in types
        assert "figure" in types
        assert "code" in types
        assert "faq" in types
        assert "references" in types

        # Check AnswerBlock parsed accurately
        ans_blocks = [b for b in doc.blocks if b.block_type == "answer_block"]
        assert len(ans_blocks) == 1
        assert ans_blocks[0].question == "What is Docker?"
        assert "isolated containers" in ans_blocks[0].direct_answer

        # Check TableBlock caption
        tables = [b for b in doc.blocks if b.block_type == "table"]
        assert len(tables) == 1
        assert tables[0].caption == "Comparison of containers vs VMs"
        assert len(tables[0].rows) == 2

        # Check QuoteBlock speaker
        quotes = [b for b in doc.blocks if b.block_type == "quote"]
        assert len(quotes) == 1
        assert quotes[0].speaker == "Solomon Hykes"

        # Check FigureBlock
        figures = [b for b in doc.blocks if b.block_type == "figure"]
        assert len(figures) == 1
        assert figures[0].kind == "diagram"
        assert figures[0].src == "/uploads/docker-arch.png"


# ===========================================================================
# 6. LangGraph Node Integration
# ===========================================================================

class TestArticleStudioNode:
    def test_node_transforms_state(self):
        """article_studio_node reads state and outputs article_model and renderers."""
        initial_state: ContentState = {
            "title": "How to Automate Content Production",
            "slug": "how-to-automate-content",
            "draft": """
# How to Automate Content Production

Automating content production involves orchestrating research, drafting, verification, and rendering pipelines into an autonomous loop.

> **Key Takeaways**
> - Keep verification separate from generation.
> - Use typed document models.

1. Step 1: Discover topics
2. Step 2: Extract claims
3. Step 3: Publish to CMS

## Frequently Asked Questions

### Can AI publish without human review?
A human review gate in Slack or web UI is recommended for quality control.
""",
            "keywords": ["Content Automation", "LangGraph", "Editorial"],
            "editorial_persona": "Managing Editor",
            "content_brief": {"article_type": "how_to"},
            "verified_claims": [
                {
                    "statement": "Automating content production involves orchestrating research, drafting, verification, and rendering pipelines",
                    "verdict": "Supported",
                    "source_url": "https://example.com/automation",
                }
            ],
            "revision_count": 0,
            "review_status": "pending",
            "thread_id": "test-studio-node-101",
            "status": "drafting",
        }

        result = article_studio_node(initial_state)

        assert "article_model" in result
        assert "article_html" in result
        assert "article_markdown" in result
        assert "article_wp_blocks" in result
        assert "article_cms_payload" in result
        assert "blueprint_compliance" in result
        assert "lint_summary" in result

        model_dict = result["article_model"]
        assert model_dict["article_type"] == "how_to"
        assert len(model_dict["blocks"]) > 0

        compliance = result["blueprint_compliance"]
        assert compliance["blueprint_id"] == "how_to"

        lint = result["lint_summary"]
        assert lint["is_valid"] is True

    def test_infer_article_type_fallbacks(self):
        """_infer_article_type correctly recognizes types from briefs or title patterns."""
        assert _infer_article_type({"content_brief": {"article_type": "comparison"}}) == "comparison"
        assert _infer_article_type({"title": "Next.js vs Remix"}) == "comparison"
        assert _infer_article_type({"title": "How to Deploy Next.js to Cloudflare"}) == "how_to"
        assert _infer_article_type({"title": "What is GraphRAG?"}) == "definition"
        assert _infer_article_type({"title": "10 Best SEO Tools for 2026"}) == "roundup"
        assert _infer_article_type({"title": "Acme Corp Case Study: 40% Growth"}) == "case_study"
        assert _infer_article_type({"title": "The Definitive Guide to Autonomous Publishing"}) == "pillar"


# ===========================================================================
# 7. Visual Decision Engine (A5c.3)
# ===========================================================================

class TestVisualDecisionEngine:
    def test_default_rules_registered(self):
        """All 7 visual situations from spec are covered in DEFAULT_VISUAL_RULES."""
        assert len(DEFAULT_VISUAL_RULES) == 7
        situations = {r.situation for r in DEFAULT_VISUAL_RULES}
        assert VisualSituation.COMPARE_ITEMS in situations
        assert VisualSituation.SEQUENCE_STEPS in situations
        assert VisualSituation.ARCHITECTURE_RELATIONSHIPS in situations
        assert VisualSituation.NUMBERS_OVER_TIME in situations
        assert VisualSituation.SOFTWARE_UI in situations
        assert VisualSituation.CONCEPT_MOOD in situations
        assert VisualSituation.QUOTE_TESTIMONY in situations

    def test_plan_visuals_proposes_table_for_comparison(self):
        """Sections comparing items propose an HTML table with mandatory justification."""
        doc = ArticleDocumentModel(
            article_type="comparison",
            title="Postgres vs MySQL",
            slug="postgres-vs-mysql",
            blocks=[
                HeadingBlock(level=2, text="Core Comparison & Feature Matrix"),
                ParagraphBlock(text="Comparing ACID compliance, indexing algorithms, and replication architecture."),
            ]
        )
        report = plan_visuals_for_article(doc)
        table_proposals = [p for p in report.proposals if p.preferred_component == "table"]
        assert len(table_proposals) >= 1
        prop = table_proposals[0]
        assert prop.situation == VisualSituation.COMPARE_ITEMS
        assert prop.approved is True
        assert len(prop.justification) > 20

    def test_plan_visuals_proposes_diagram_for_architecture(self):
        """Architecture sections propose diagrams with validated Mermaid source and SVG."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Building Agentic Pipelines",
            slug="agentic-pipelines",
            blocks=[
                HeadingBlock(level=2, text="System Architecture and Workflow Design"),
                ParagraphBlock(text="How nodes connect via conditional edges to the review gate."),
            ]
        )
        report = plan_visuals_for_article(doc)
        diag_proposals = [p for p in report.proposals if p.preferred_component == "diagram"]
        assert len(diag_proposals) >= 1
        prop = diag_proposals[0]
        assert prop.diagram_valid is True
        assert prop.diagram_svg is not None
        assert "<svg" in prop.diagram_svg
        assert prop.approved is True

    def test_plan_visuals_distinguishes_linear_vs_branching_steps(self):
        """Linear steps propose numbered list; branching steps propose flow diagram."""
        linear_doc = ArticleDocumentModel(
            article_type="how_to",
            title="Deploying Next.js",
            slug="deploy-nextjs",
            blocks=[
                HeadingBlock(level=2, text="Deployment Procedure"),
                ListBlock(ordered=True, items=["Run npm run build", "Run git push origin main", "Verify domain DNS"]),
            ]
        )
        rep1 = plan_visuals_for_article(linear_doc)
        list_props = [p for p in rep1.proposals if p.preferred_component == "numbered_list"]
        assert len(list_props) >= 1
        assert list_props[0].approved is True

        branching_doc = ArticleDocumentModel(
            article_type="how_to",
            title="Deploying Next.js with Fallbacks",
            slug="deploy-nextjs-fallbacks",
            blocks=[
                HeadingBlock(level=2, text="Deployment with Fallback Strategy"),
                ListBlock(ordered=True, items=[
                    "Check server status",
                    "If primary database is down, switch to Upstash replica",
                    "Notify admin if webhook fails",
                ]),
            ]
        )
        rep2 = plan_visuals_for_article(branching_doc)
        flow_props = [p for p in rep2.proposals if p.preferred_component == "flow_diagram"]
        assert len(flow_props) >= 1
        assert flow_props[0].has_branching is True
        assert flow_props[0].diagram_valid is True
        assert "<svg" in flow_props[0].diagram_svg

    def test_plan_visuals_proposes_screenshot_for_ui(self):
        """Software UI procedures propose screenshots."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Configuring the Studio Dashboard",
            slug="configuring-dashboard",
            blocks=[
                HeadingBlock(level=2, text="Navigating the Settings Dashboard"),
                ParagraphBlock(text="Click on the API keys tab in the upper-right navigation."),
            ]
        )
        report = plan_visuals_for_article(doc)
        screen_props = [p for p in report.proposals if p.preferred_component == "screenshot"]
        assert len(screen_props) >= 1
        assert screen_props[0].situation == VisualSituation.SOFTWARE_UI

    def test_strict_ban_on_decorative_filler(self):
        """Proposals marked as decorative or lacking substance are rejected."""
        prop = VisualProposal(
            section_title="Filler Section",
            situation=VisualSituation.CONCEPT_MOOD,
            preferred_component="hero_image",
            justification="Looks nice and provides visual appeal",
            is_decorative_filler=True,
        )
        assert prop.is_decorative_filler is True

    def test_visual_density_analysis_calculations(self):
        """Visual density is evaluated against target ~1 visual per 300-400 words."""
        paras = [ParagraphBlock(text=" ".join(["word"] * 350)), ParagraphBlock(text=" ".join(["word"] * 350))]
        figs = [
            FigureBlock(kind="diagram", src="/uploads/1.png", alt="A", caption="B", provenance=FigureProvenance(source="stock")),
            TableBlock(caption="T", headers=["A", "B"], rows=[["1", "2"], ["3", "4"]]),
        ]
        doc_optimal = ArticleDocumentModel(
            article_type="how_to",
            title="Optimal Density",
            slug="optimal-density",
            blocks=paras + figs,
        )
        d_optimal = analyze_visual_density(doc_optimal)
        assert d_optimal.density_status == "optimal"
        assert d_optimal.words_per_visual == 350.0

        doc_dense = ArticleDocumentModel(
            article_type="how_to",
            title="Too Dense",
            slug="too-dense",
            blocks=[ParagraphBlock(text=" ".join(["word"] * 200))] + figs,
        )
        d_dense = analyze_visual_density(doc_dense)
        assert d_dense.density_status == "too_dense"

        doc_sparse = ArticleDocumentModel(
            article_type="how_to",
            title="Too Sparse",
            slug="too-sparse",
            blocks=[ParagraphBlock(text=" ".join(["word"] * 1200)), figs[0]],
        )
        d_sparse = analyze_visual_density(doc_sparse)
        assert d_sparse.density_status == "too_sparse"


# ===========================================================================
# 8. Hard Prohibitions Audit (A5c.3)
# ===========================================================================

class TestHardProhibitions:
    def test_reject_chart_without_data_source(self):
        """Chart without verifiable data source triggers prohibition and invalidates lint."""
        doc = ArticleDocumentModel(
            article_type="data_study",
            title="Unverifiable Chart Test",
            slug="chart-test",
            blocks=[
                FigureBlock(
                    kind="chart",
                    src="/uploads/fake-chart.png",
                    alt="P99 Latency Curve",
                    caption="Latency across 10,000 requests",
                    data_source="none",
                    provenance=FigureProvenance(source="ai_generated"),
                )
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is True
        assert any(v["rule"] == "invented_data_or_charts" for v in audit.violations)

        report = lint_article_model(doc)
        assert report.is_valid is False
        assert any("HARD PROHIBITION" in e for e in report.errors)

    def test_reject_fake_ai_screenshot(self):
        """AI-generated software screenshots are strictly prohibited."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Fake UI Screenshot Test",
            slug="fake-ui",
            blocks=[
                FigureBlock(
                    kind="screenshot",
                    src="/uploads/fake-ui.png",
                    alt="Dashboard UI",
                    caption="Dashboard interface",
                    provenance=FigureProvenance(source="ai_generated"),
                )
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is True
        assert any(v["rule"] == "fake_screenshots" for v in audit.violations)

    def test_reject_fake_or_anonymous_testimonial(self):
        """Quotes without attributed real speakers or without sources are rejected."""
        doc = ArticleDocumentModel(
            article_type="case_study",
            title="Fake Testimonial Test",
            slug="fake-quote",
            blocks=[
                QuoteBlock(
                    text="Best platform ever.",
                    speaker="Anonymous",
                )
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is True
        assert any(v["rule"] == "fake_testimonials_or_people" for v in audit.violations)

    def test_reject_unauthorized_trademark_logo(self):
        """Brand logos without license or permission credit are rejected."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Unauthorized Logo Test",
            slug="logo-test",
            blocks=[
                FigureBlock(
                    kind="image",
                    src="/uploads/logo.png",
                    alt="Official Google Logo",
                    caption="The Google logo",
                    provenance=FigureProvenance(source="stock"),
                    credit="Found on web",
                )
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is True
        assert any(v["rule"] == "unauthorized_logos_or_trademarks" for v in audit.violations)

    def test_reject_unverified_text_in_ai_image(self):
        """AI images with baked-in numbers/claims not verified via A4 claims are rejected."""
        doc = ArticleDocumentModel(
            article_type="how_to",
            title="Unverified AI Image Text",
            slug="ai-image-text",
            blocks=[
                FigureBlock(
                    kind="image",
                    src="/uploads/infographic.png",
                    alt="Infographic showing 95% latency reduction and $500k savings",
                    caption="Figure illustrates 95% latency reduction",
                    provenance=FigureProvenance(source="ai_generated", generator="flux-1-schnell"),
                    claims=[],
                )
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is True
        assert any(v["rule"] == "unverified_image_text" for v in audit.violations)

    def test_clean_doc_passes_all_prohibitions(self):
        """Legitimate document with sourced assets passes all prohibitions cleanly."""
        doc = ArticleDocumentModel(
            article_type="data_study",
            title="Clean Benchmark Report",
            slug="clean-report",
            blocks=[
                FigureBlock(
                    kind="chart",
                    src="/uploads/bench.png",
                    alt="Postgres Latency Curve",
                    caption="Measured P99 latency on c6i.2xlarge instances.",
                    data_source="https://benchmarks.example.com/postgres-16.csv",
                    provenance=FigureProvenance(source="original_data"),
                ),
                FigureBlock(
                    kind="screenshot",
                    src="https://app.example.com/settings",
                    alt="Settings Dashboard",
                    caption="Production cluster settings console.",
                    software_version="Grafana v10.4 / Chrome 126",
                    provenance=FigureProvenance(source="real_screenshot"),
                ),
                QuoteBlock(
                    text="The migration saved 40 engineering hours per week.",
                    speaker="Elena Rostova",
                    role="VP Engineering",
                    organisation="CloudTech",
                    sources=[SourceRef(url="https://cloudtech.example.com/interview")],
                ),
            ]
        )
        audit = audit_hard_prohibitions(doc)
        assert audit.has_violations is False
        assert len(audit.violations) == 0


# ===========================================================================
# 9. Diagram Validation & SVG Rendering (A5c.3)
# ===========================================================================

class TestDiagramValidationAndSVG:
    def test_validate_valid_mermaid_flowchart(self):
        """Valid flowchart syntax passes validation."""
        code = "graph TD\n  A[Start] --> B[Process]\n  B --> C[Finish]"
        valid, err = validate_mermaid_syntax(code)
        assert valid is True
        assert err is None

    def test_validate_valid_mermaid_sequence_diagram(self):
        """Valid sequence diagram passes validation."""
        code = "sequenceDiagram\n  Client->>Server: Request\n  Server-->>Client: Response"
        valid, err = validate_mermaid_syntax(code)
        assert valid is True
        assert err is None

    def test_validate_invalid_syntax_missing_keyword(self):
        """Snippet without diagram keyword is rejected."""
        code = "A -> B -> C"
        valid, err = validate_mermaid_syntax(code)
        assert valid is False
        assert "recognized diagram keyword" in err

    def test_validate_invalid_syntax_unbalanced_brackets(self):
        """Snippet with unbalanced brackets is rejected."""
        code = "graph TD\n  A[Start --> B[Finish]"
        valid, err = validate_mermaid_syntax(code)
        assert valid is False
        assert "Unbalanced square brackets" in err

    def test_render_mermaid_to_svg(self):
        """render_mermaid_to_svg generates valid vector SVG."""
        code = "graph TD\n  Client[Client] --> Server[FastAPI Server]\n  Server --> DB[(Postgres)]"
        svg = render_mermaid_to_svg(code, title="API Architecture")
        assert svg.startswith("<svg")
        assert svg.endswith("</svg>")
        assert 'role="img"' in svg
        assert "<rect" in svg
        assert "<line" in svg
        assert "Client" in svg
        assert "FastAPI Server" in svg

    def test_render_invalid_mermaid_returns_error_svg(self):
        """Invalid mermaid source produces graceful error SVG."""
        code = "invalid diagram syntax without keywords"
        svg = render_mermaid_to_svg(code)
        assert "<svg" in svg
        assert "Mermaid Syntax Error" in svg


# ===========================================================================
# 10. Studio FastAPI Endpoints (A5c.3)
# ===========================================================================

class TestVisualStudioAPI:
    @pytest.fixture
    def client(self):
        from web.app import app
        from fastapi.testclient import TestClient
        return TestClient(app)

    def test_api_get_visual_rules(self, client):
        """GET /api/studio/visual-rules returns 200 and all rules."""
        res = client.get("/api/studio/visual-rules")
        assert res.status_code == 200
        data = res.json()
        assert len(data["rules"]) == 7
        assert "density_guideline" in data
        assert "hard_prohibitions" in data

    def test_api_post_visual_plan(self, client):
        """POST /api/studio/visual-plan generates section visual proposals."""
        md = """
# Scaling Microservices

## Architecture Overview
System architecture from load balancer to worker pool.

## Database Benchmarks
Comparing query latency and throughput.

## Step-by-Step Deployment
1. Provision cluster
2. Configure certificates
3. Deploy manifests
"""
        res = client.post("/api/studio/visual-plan", json={
            "markdown": md,
            "title": "Scaling Microservices",
            "slug": "scaling-microservices",
            "article_type": "how_to",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert "visual_plan" in data
        vp = data["visual_plan"]
        assert len(vp["proposals"]) >= 2
        assert vp["density"]["words_per_visual"] > 0

    def test_api_post_validate_diagram(self, client):
        """POST /api/studio/validate-diagram validates and renders SVG."""
        code = "graph TD\n  A[Frontend] --> B[Backend]"
        res = client.post("/api/studio/validate-diagram", json={
            "source": code,
            "title": "Web Architecture",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["valid"] is True
        assert data["svg"] is not None
        assert "<svg" in data["svg"]

    def test_api_post_studio_lint(self, client):
        """POST /api/studio/lint executes single-pass verification & lint."""
        md = """
# Guide
Content paragraph.
"""
        res = client.post("/api/studio/lint", json={
            "markdown": md,
            "title": "Guide",
            "slug": "guide",
            "article_type": "how_to",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert "lint_report" in data
        lr = data["lint_report"]
        assert "compliance" in lr
        assert "prohibitions" in lr
        assert "visual_density" in lr

