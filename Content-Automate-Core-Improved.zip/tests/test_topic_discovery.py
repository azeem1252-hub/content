"""
Unit and integration tests for Autonomous Topic Discovery & Website Scraping.
Validates:
1. Multi-vector web scraping (HTML, JSON-LD, RSS, Sitemap).
2. Site isolation (no cross-website data pollution).
3. Dynamic niche deduction (Gaming, Fintech, Culinary, Health, SaaS).
4. Topic generation with tailored audience persona and keywords.
5. Deduplication guard preventing repetition of existing articles.
"""

import json
import pytest
from unittest.mock import patch, MagicMock

from pipeline.topic_researcher import (
    clean_slug_to_title,
    scrape_website_context,
    autonomous_discover_topic,
    discover_unique_topic,
    get_archetype_for_niche,
)
from pipeline.utils import is_duplicate_topic, title_similarity


def test_clean_slug_to_title():
    assert clean_slug_to_title("/posts/game-architecture-2026-building-games") == "Game Architecture 2026 Building Games"
    assert clean_slug_to_title("https://example.com/blog/how-to-scale-postgres-in-2026") == "How To Scale Postgres In 2026"
    assert clean_slug_to_title("/article/future-of-ai") == "Future Of Ai"


def test_title_similarity_and_deduplication():
    # Very similar titles
    t1 = "Game Architecture for 2026: Building Games That Last"
    t2 = "Game Architecture in 2026: How to Build Games That Last"
    score = title_similarity(t1, t2)
    assert score >= 0.78

    dup = is_duplicate_topic(t2, [t1], threshold=0.78)
    assert dup is not None
    assert dup["title"] == t1

    # Completely different titles
    t3 = "The Ultimate Guide to Sourdough Fermentation Techniques"
    assert is_duplicate_topic(t3, [t1], threshold=0.78) is None


def test_scrape_website_context_site_isolation():
    """Ensure that scraping a non-gaming site never pulls in gaming articles or categories."""
    fintech_site = {
        "id": "site-test-fintech",
        "name": "Fintech Global Advisory",
        "url": "https://fintech-mock-nonexistent-12345.com/api/posts",
    }
    ctx = scrape_website_context(fintech_site)
    assert "Fintech" in ctx["editorial_niche"] or "Financial" in ctx["editorial_niche"]
    assert "Video Games" not in ctx["editorial_niche"]
    # Existing articles should NOT contain gaming titles
    for title in ctx["existing_articles"]:
        assert "game" not in title.lower()
        assert "gta" not in title.lower()


def test_scrape_website_context_html_parsing():
    """Test BeautifulSoup extraction from mock HTML."""
    mock_html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>SaaS Velocity — B2B Cloud Platform</title>
        <meta name="description" content="Engineering high-scale cloud native platforms and B2B SaaS architecture.">
    </head>
    <body>
        <h1>Latest Insights</h1>
        <article class="post-card">
            <a href="/blog/scaling-multi-tenant-postgres">
                <h2>Scaling Multi-Tenant Postgres to 100k Databases</h2>
            </a>
            <span class="badge">Architecture</span>
        </article>
        <article class="post-card">
            <a href="/blog/zero-trust-kubernetes-service-mesh">
                <h2>Zero-Trust Kubernetes Service Mesh Deployments</h2>
            </a>
            <span class="badge">DevOps</span>
        </article>
    </body>
    </html>
    """
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = mock_html

    with patch("httpx.Client.get", return_value=mock_resp):
        site = {
            "id": "site-saas-test",
            "name": "SaaS Velocity",
            "url": "https://saasvelocity.io/api/posts",
        }
        ctx = scrape_website_context(site)
        assert "SaaS Velocity" in ctx["site_title"]
        assert "Scaling Multi-Tenant Postgres to 100k Databases" in ctx["existing_articles"]
        assert "Zero-Trust Kubernetes Service Mesh Deployments" in ctx["existing_articles"]
        assert "Architecture" in ctx["categories"] or "DevOps" in ctx["categories"]
        assert "SaaS" in ctx["editorial_niche"] or "Cloud" in ctx["editorial_niche"]


def test_autonomous_discover_topic_tailored_persona():
    """Verify that autonomous topic discovery generates niche-tailored persona and keywords."""
    site = {
        "id": "site-coffee-test",
        "name": "Specialty Coffee Roasters",
        "url": "https://coffeeroasters.example.com",
    }

    mock_llm_json = {
        "topic": "The Chemistry of Anaerobic Fermentation in Single-Origin Geisha Beans (2026 Guide)",
        "reasoning": "High demand among specialty coffee baristas exploring precision fermentation techniques.",
        "keywords": ["anaerobic fermentation coffee", "single-origin geisha beans", "specialty coffee roasting 2026", "coffee microbial chemistry"],
        "target_audience": "Specialty coffee roasters, head baristas, and craft cafe owners"
    }

    with patch("pipeline.topic_researcher.fetch_tavily_intelligence", return_value={"results": []}), \
         patch("pipeline.topic_researcher.call_llm", return_value=json.dumps(mock_llm_json)):
        
        result = autonomous_discover_topic(site_obj=site)
        assert result["topic"] == mock_llm_json["topic"]
        assert result["target_audience"] == mock_llm_json["target_audience"]
        assert "coffee" in result["target_audience"].lower() or "barista" in result["target_audience"].lower()
        assert len(result["keywords"]) == 4


def test_discover_unique_topic_deduplication_retry():
    """Verify that near-duplicates are rejected and retried with excluded titles."""
    site = {
        "id": "site-dedupe-test",
        "name": "Cloud Native Weekly",
        "url": "https://cloudnative.example.com",
    }

    existing_title = "Kubernetes Multi-Cluster Networking in 2026"
    duplicate_title = "Kubernetes Multi-Cluster Networking for 2026"
    fresh_title = "eBPF-Powered Observability: Replacing Sidecars in Enterprise Mesh"

    responses = [
        # Attempt 1: duplicate of existing
        json.dumps({
            "topic": duplicate_title,
            "reasoning": "trending",
            "keywords": ["k8s", "networking"],
            "target_audience": "Cloud Engineers"
        }),
        # Attempt 2: unique and distinct
        json.dumps({
            "topic": fresh_title,
            "reasoning": "new gap",
            "keywords": ["eBPF", "observability", "service mesh"],
            "target_audience": "Site Reliability Engineers & Platform Architects"
        })
    ]

    with patch("pipeline.topic_researcher.scrape_website_context", return_value={
        "site_name": "Cloud Native Weekly",
        "site_url": "https://cloudnative.example.com",
        "base_url": "https://cloudnative.example.com",
        "site_title": "Cloud Native Weekly",
        "site_desc": "Kubernetes and cloud native architecture",
        "editorial_niche": "Cloud Infrastructure, Kubernetes, and DevOps",
        "categories": ["Kubernetes", "DevOps"],
        "existing_articles": [existing_title]
    }), \
    patch("pipeline.topic_researcher.fetch_tavily_intelligence", return_value={"results": []}), \
    patch("pipeline.topic_researcher.call_llm", side_effect=responses):

        result = discover_unique_topic(site_obj=site)
        assert result["topic"] == fresh_title
        assert result["dedupe"]["attempt"] == 2


def test_get_archetype_for_niche():
    """Verify archetype resolution by slug and text fallback."""
    culinary_arch = get_archetype_for_niche("culinary")
    assert culinary_arch["slug"] == "culinary"
    assert "Chef" in culinary_arch["persona"]
    assert "Cooking" in culinary_arch["community_query"]

    gaming_arch = get_archetype_for_niche(fallback_text="Latest PS5 and Nintendo Switch boss loadouts")
    assert gaming_arch["slug"] == "gaming"
    assert "Games Journalist" in gaming_arch["persona"]


def test_outline_node_domain_adaptive():
    """Verify outline generation adapts queries and personas to the specific website niche."""
    from pipeline.nodes.outline_node import outline_node

    state = {
        "topic": "Handmade Sourdough Focaccia with Rosemary and Flaky Sea Salt",
        "keywords": ["sourdough focaccia", "artisanal baking"],
        "target_audience": "Artisan home bakers and culinary enthusiasts",
        "site_niche": "Gourmet Culinary Arts, Artisanal Recipes",
        "niche_slug": "culinary",
        "angle_or_hook": "High-hydration cold fermentation technique for blistered crust",
        "content_format": "Artisanal Masterclass Recipe",
    }

    mock_analysis_json = {
        "high_ranking_keywords": ["sourdough focaccia recipe", "cold fermentation focaccia", "dimpling technique"],
        "target_audience": "Home artisan bakers",
        "audience_pain_points": ["Dense crumb without air pockets", "Dough sticking to pan"],
        "competitor_gaps": "Most recipes omit pan preheating and exact olive oil hydration ratios",
        "novel_information_gain": "24-hour cold proof with 85% hydration and olive oil bath",
        "direct_answer_summary": "For an airy sourdough focaccia, use an 85% hydration dough with a 24-hour cold retard."
    }

    mock_outline_text = "# Sourdough Focaccia Masterclass\n\n## The Secret to Wild Crumb & Blistered Crust"

    from pipeline.adapters.brief_builder import ContentBrief, BriefSection

    mock_brief = ContentBrief(
        primary_keyword="sourdough focaccia",
        intent="informational",
        target_reader="Home artisan bakers",
        unique_angle="24-hour cold proof with 85% hydration and olive oil bath",
        required_entities=["sourdough focaccia recipe", "cold fermentation focaccia", "dimpling technique"],
        required_sections=[
            BriefSection(
                heading="Introduction",
                intent_goal="Introduce sourdough focaccia technique and target outcome",
                required_entities=["sourdough focaccia recipe"]
            )
        ],
    )

    with patch("pipeline.nodes.outline_node.fetch_tavily_intelligence", return_value={"results": []}), \
         patch("pipeline.nodes.outline_node.build_evidence_based_brief", return_value=mock_brief):
        res = outline_node(state)
        assert res["status"] == "outlined"
        assert "sourdough focaccia recipe" in res["discovered_keywords"]
        assert "focaccia" in res["target_audience"].lower() or "baker" in res["target_audience"].lower()

