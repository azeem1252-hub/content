import pytest
from pipeline.adapters.keyword_intelligence import (
    classify_search_intent,
    estimate_ai_search_suitability,
    calculate_opportunity_score,
    fetch_gsc_candidates,
    fetch_competitor_candidates,
    fetch_seed_expansion_candidates,
    fetch_question_candidates,
    enrich_keyword_candidates,
    run_merged_candidate_generation,
)
import storage.db as db


def test_classify_search_intent():
    assert classify_search_intent("best physics engine for nextjs") == "commercial"
    assert classify_search_intent("buy game physics assets cheap") == "transactional"
    assert classify_search_intent("hades official site login") == "navigational"
    assert classify_search_intent("how do collision bounding boxes work") == "informational"


def test_estimate_ai_search_suitability():
    vol, is_chat = estimate_ai_search_suitability("how to optimize sub-tick collision in unreal engine")
    assert is_chat is True
    assert vol == 1

    vol2, is_chat2 = estimate_ai_search_suitability("game physics")
    assert is_chat2 is False


def test_calculate_opportunity_score():
    # Striking distance on page 2 (pos 10.5) with low CTR should score very high
    score_striking = calculate_opportunity_score(
        opportunity_type="striking_distance",
        avg_position=10.5,
        impressions=250,
        ctr=1.2,
        search_volume=1200,
        keyword_difficulty=22.0,
        search_intent="commercial",
        has_ai_overview=True,
        has_featured_snippet=False,
    )
    assert score_striking >= 80.0

    # High KD (> 65) competitor gap should have lower score
    score_hard_gap = calculate_opportunity_score(
        opportunity_type="competitor_gap",
        avg_position=None,
        impressions=0,
        ctr=0.0,
        search_volume=1000,
        keyword_difficulty=75.0,
        search_intent="informational",
        has_ai_overview=False,
        has_featured_snippet=False,
    )
    assert score_hard_gap < score_striking


@pytest.mark.live
def test_four_sources_and_merged_pipeline():
    db.init_db()

    # 1. Own site GSC candidates
    gsc_cands = fetch_gsc_candidates(website_id="default")
    assert len(gsc_cands) > 0
    assert any(c["source"] == "own_site_gsc" for c in gsc_cands)

    # 2. Competitor gap candidates
    comp_cands = fetch_competitor_candidates(
        competitor_domains=["ign.com"],
        website_id="default",
        niche="gaming physics",
    )
    assert len(comp_cands) > 0
    assert any(c["source"] == "competitor_gap" for c in comp_cands)

    # 3. Seed expansion candidates
    seed_cands = fetch_seed_expansion_candidates(
        seed_keywords=["hades combat", "death stranding physics"],
        website_id="default",
    )
    assert len(seed_cands) > 0
    assert any(c["source"] == "seed_expansion" for c in seed_cands)

    # 4. Question / PAA candidates
    paa_cands = fetch_question_candidates(
        seed_keywords=["physics engine"],
        website_id="default",
    )
    assert len(paa_cands) > 0
    assert any(c["source"] == "paa_question" for c in paa_cands)

    # Full 4-source merged run
    summary = run_merged_candidate_generation(
        website_id="default",
        competitor_domains=["ign.com", "kotaku.com"],
        seed_keywords=["game physics", "nextjs rendering"],
    )

    assert summary["total_candidates"] > 0
    assert summary["persisted_count"] > 0
    assert summary["breakdown_by_source"]["own_site_gsc"] > 0
    assert summary["breakdown_by_source"]["competitor_gap"] > 0
    assert summary["breakdown_by_source"]["seed_expansion"] > 0
    assert summary["breakdown_by_source"]["paa_question"] > 0

    # Query from DB to verify persistence and ordering
    stored = db.get_keyword_candidates(website_id="default", limit=50)
    assert len(stored) > 0
    # Should be sorted by opportunity_score descending
    scores = [s["opportunity_score"] for s in stored]
    assert scores == sorted(scores, reverse=True)


@pytest.mark.live
def test_keyword_api_endpoints():
    from fastapi.testclient import TestClient
    from web.app import app

    client = TestClient(app)

    # 1. GET /api/keywords/candidates
    resp = client.get("/api/keywords/candidates?website_id=default&limit=10")
    assert resp.status_code == 200
    data = resp.json()
    assert "candidates" in data
    assert isinstance(data["candidates"], list)

    # 2. POST /api/keywords/generate-candidates
    gen_resp = client.post("/api/keywords/generate-candidates", json={
        "website_id": "default",
        "competitor_domains": ["ign.com"],
        "seed_keywords": ["physics simulation"],
    })
    assert gen_resp.status_code == 200
    gen_data = gen_resp.json()
    assert gen_data["total_candidates"] > 0
    assert "breakdown_by_source" in gen_data
    assert "top_opportunities" in gen_data

    # 3. GET /api/keywords/seeds
    seed_resp = client.get("/api/keywords/seeds?website_id=default")
    assert seed_resp.status_code == 200
    assert "seeds" in seed_resp.json()

    # 4. GET /api/keywords/empirical-reach
    reach_resp = client.get("/api/keywords/empirical-reach?website_id=default")
    assert reach_resp.status_code == 200
    reach_data = reach_resp.json()
    assert "median_kd" in reach_data
    assert "p75_kd" in reach_data

    # 5. POST /api/keywords/empirical-reach/calibrate
    cal_resp = client.post("/api/keywords/empirical-reach/calibrate", json={"website_id": "default"})
    assert cal_resp.status_code == 200
    cal_data = cal_resp.json()
    assert "median_kd" in cal_data
    assert cal_data["median_kd"] > 0


def test_empirical_reach_calibration_and_attainability():
    from pipeline.adapters.keyword_intelligence import (
        calibrate_site_empirical_reach,
        classify_keyword_attainability,
    )

    # 1. New site baseline with no ranking history
    new_reach = calibrate_site_empirical_reach(website_id="brand-new-site-123", force_recompute=True)
    assert new_reach["is_new_site"] is True
    assert new_reach["median_kd"] == 20.0
    assert new_reach["p75_kd"] == 30.0

    # 2. Attainability classification against baseline (p75 = 30.0)
    # Low-KD keyword (<= 30.0) -> attainable
    status, delta = classify_keyword_attainability(22.0, new_reach)
    assert status == "attainable"
    assert delta == -8.0

    # Mid-KD keyword (31.0 - 45.0) -> stretch
    status_stretch, delta_stretch = classify_keyword_attainability(38.0, new_reach)
    assert status_stretch == "stretch"
    assert delta_stretch == 8.0

    # High-KD keyword (> 45.0) -> out_of_reach (deprioritised)
    status_out, delta_out = classify_keyword_attainability(75.0, new_reach)
    assert status_out == "out_of_reach"
    assert delta_out == 45.0

    # 3. Opportunity score penalty for out_of_reach vs attainable
    score_attainable = calculate_opportunity_score(
        opportunity_type="seed_expansion",
        avg_position=None,
        impressions=0,
        ctr=0.0,
        search_volume=1200,
        keyword_difficulty=22.0,
        search_intent="informational",
        has_ai_overview=False,
        has_featured_snippet=False,
        attainability_status="attainable",
    )
    score_out_of_reach = calculate_opportunity_score(
        opportunity_type="seed_expansion",
        avg_position=None,
        impressions=0,
        ctr=0.0,
        search_volume=1200,
        keyword_difficulty=75.0,
        search_intent="informational",
        has_ai_overview=False,
        has_featured_snippet=False,
        attainability_status="out_of_reach",
    )
    assert score_attainable > score_out_of_reach + 30.0


def test_a14_scoring_formula():
    from pipeline.adapters.keyword_intelligence import (
        calculate_feasibility,
        calculate_business_fit,
        calculate_expected_clicks,
        calculate_opportunity_formula,
        fit_gsc_ctr_curve,
    )

    # 1. Feasibility sigmoid test
    # When KD equals empirical reach (30.0), sigmoid is 0.50
    feas_even = calculate_feasibility(empirical_reach_kd=30.0, keyword_difficulty=30.0, k=10.0)
    assert abs(feas_even - 0.50) < 0.01

    # When KD is 15 points easier, feasibility should be high (~0.82)
    feas_easy = calculate_feasibility(empirical_reach_kd=30.0, keyword_difficulty=15.0, k=10.0)
    assert feas_easy > 0.80

    # When KD is far above reach (60.0), feasibility should be low (<0.10)
    feas_hard = calculate_feasibility(empirical_reach_kd=30.0, keyword_difficulty=60.0, k=10.0)
    assert feas_hard < 0.10

    # 2. Expected clicks with SERP penalty
    clicks_clean = calculate_expected_clicks(volume=10000, target_position=1, serp_features=[])
    assert clicks_clean > 2500  # Pos 1 ~28.5%

    # AI Overview penalty reduces expected clicks by 30%
    clicks_aio = calculate_expected_clicks(volume=10000, target_position=1, serp_features=["ai_overview"])
    assert abs(clicks_aio - (clicks_clean * 0.70)) < 2.0

    # 3. Business fit test
    fit_commercial = calculate_business_fit("best physics engine for nextjs", search_intent="commercial")
    fit_navigational = calculate_business_fit("hades login", search_intent="navigational")
    assert fit_commercial > fit_navigational

    # 4. Opportunity formula output
    opp_high = calculate_opportunity_formula(
        expected_clicks=500.0,
        business_fit=0.85,
        feasibility=0.80,
        freshness_factor=1.0,
    )
    assert opp_high["passed_business_fit"] is True
    assert opp_high["opportunity_score"] > 80.0

    # Low business fit drops score
    opp_low_fit = calculate_opportunity_formula(
        expected_clicks=500.0,
        business_fit=0.10,
        feasibility=0.80,
        freshness_factor=1.0,
    )
    assert opp_low_fit["passed_business_fit"] is False
    assert opp_low_fit["opportunity_score"] < opp_high["opportunity_score"] - 25.0


def test_a15_clustering_and_content_plan():
    from pipeline.adapters.keyword_intelligence import (
        cluster_keywords_by_serp_overlap,
        generate_prioritized_content_plan,
        run_keyword_clustering_and_plan,
    )

    db.init_db()

    candidates = [
        {
            "keyword": "unreal engine physics simulation",
            "opportunity_score": 88.0,
            "expected_clicks": 320.0,
            "search_volume": 3200,
            "search_intent": "informational",
            "website_id": "default",
        },
        {
            "keyword": "unreal engine sub-tick collision physics",
            "opportunity_score": 84.0,
            "expected_clicks": 210.0,
            "search_volume": 1800,
            "search_intent": "informational",
            "website_id": "default",
        },
        {
            "keyword": "best roguelike games 2026",
            "opportunity_score": 75.0,
            "expected_clicks": 450.0,
            "search_volume": 4500,
            "search_intent": "commercial",
            "website_id": "default",
        },
    ]

    # Cluster keywords by SERP overlap (N=3)
    clusters = cluster_keywords_by_serp_overlap(candidates, overlap_threshold=3)
    assert len(clusters) > 0
    # One cluster = One page
    for cl in clusters:
        assert "primary_keyword" in cl
        assert "supporting_keywords" in cl
        assert "cluster_score" in cl

    # Generate Content Plan (actions: new, refresh, consolidate)
    plan = generate_prioritized_content_plan("default", clusters)
    assert len(plan) > 0
    for p in plan:
        assert p["action"] in ("new", "refresh", "consolidate")
        assert len(p["reason"]) > 10

    # Full clustering and plan master run
    master_res = run_keyword_clustering_and_plan("default")
    assert master_res["total_clusters"] > 0
    assert master_res["total_plan_items"] > 0
    assert "actions_breakdown" in master_res



