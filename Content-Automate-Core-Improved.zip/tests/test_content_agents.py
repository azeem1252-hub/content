import os
import sys

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from pipeline.nodes.outline_node import generate_outline
from pipeline.nodes.draft_node import generate_draft
from pipeline.nodes.audit_node import audit_and_optimize_seo

import pytest


@pytest.mark.live
def test_content_pipeline_step2():
    print("=" * 60)
    print("Testing Step 2: Content Drafting & SEO Guardrail Agents")
    print("=" * 60)

    topic = "Autonomous AI Agents for Content Creation"
    keywords = ["AI agents", "autonomous publishing", "Slack approval"]

    # 1. Outline Node
    print("\n[1/4] Running Outline Agent...")
    outline_res = generate_outline(topic=topic, keywords=keywords)
    assert outline_res["status"] == "outlined"
    assert len(outline_res["outline"]) > 100
    print("[OK] Outline generated successfully!")
    print(f"Outline Preview:\n{outline_res['outline'][:250]}...\n")

    # 2. Draft Node
    print("[2/4] Running Draft Agent...")
    draft_res = generate_draft(
        outline=outline_res["outline"],
        topic=topic,
        keywords=keywords
    )
    assert draft_res["status"] == "drafted"
    assert len(draft_res["draft"]) > 300
    assert draft_res["title"]
    print(f"[OK] Draft generated successfully! Title: '{draft_res['title']}'")
    print(f"Draft Preview (first 250 chars):\n{draft_res['draft'][:250]}...\n")

    # 3. Editorial Feedback Loop Test
    print("[3/4] Testing Editorial Revision Feedback Loop...")
    feedback = "Add a specific section mentioning Groq and Mistral fast inference."
    revised_res = generate_draft(
        outline=outline_res["outline"],
        topic=topic,
        keywords=keywords,
        reviewer_feedback=feedback,
        revision_count=1
    )
    assert revised_res["revision_count"] == 2
    print("[OK] Revision loop completed successfully! Revision count: 2")

    # 4. SEO & Quality Audit Node
    print("[4/4] Running SEO & Quality Guardrail Agent...")
    audit_res = audit_and_optimize_seo(
        title=draft_res["title"],
        draft=draft_res["draft"],
        topic=topic,
        keywords=keywords
    )
    assert audit_res["status"] == "audited"
    assert audit_res["slug"]
    assert audit_res["meta_title"]
    assert audit_res["meta_description"]
    assert isinstance(audit_res["tags"], list)
    assert audit_res["seo_score"] >= 70

    print(f"[OK] SEO Audit passed!")
    print(f"  Generated Slug:      {audit_res['slug']}")
    print(f"  Meta Title:          {audit_res['meta_title']}")
    print(f"  Meta Description:    {audit_res['meta_description']}")
    print(f"  Tags:                {', '.join(audit_res['tags'])}")
    print(f"  SEO Score:           {audit_res['seo_score']}/100")
    print(f"  Word Count:          {audit_res['word_count']} words (~{audit_res['read_time']} min read)")

    print("\n" + "=" * 60)
    print(">>> STEP 2 CONTENT & SEO AGENTS VERIFIED SUCCESSFULLY! <<<")
    print("=" * 60)

if __name__ == "__main__":
    test_content_pipeline_step2()
