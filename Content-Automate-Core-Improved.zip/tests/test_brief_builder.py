import pytest
from unittest.mock import patch, MagicMock
from pipeline.adapters.brief_builder import (
    HeadingItem,
    CompetitorPageAnalysis,
    SerpAnalysisResult,
    BriefSection,
    ContentBrief,
    extract_headings_from_html,
    extract_media_types_from_html,
    extract_schema_types_from_html,
    extract_statistics_from_text,
    extract_entities_from_text,
    analyze_serp_gaps,
    calculate_word_count_range,
    plan_schema,
    resolve_unique_angle,
    scrape_and_analyze_page,
    build_evidence_based_brief,
    brief_to_outline_markdown,
)
from pipeline.nodes.outline_node import outline_node, generate_outline


def test_extract_headings_from_html():
    html_sample = """
    <html>
      <body>
        <h1>Main Title (ignored)</h1>
        <h2>Foundations of <span>Sub-Tick</span> Physics</h2>
        <p>Paragraph text...</p>
        <h3>Continuous vs Discrete Collision</h3>
        <p>More text...</p>
        <h2>Benchmarking Under High Load</h2>
        <h3>Memory Overhead Trade-Offs</h3>
      </body>
    </html>
    """
    headings = extract_headings_from_html(html_sample)
    assert len(headings) == 4
    assert headings[0].level == 2
    assert headings[0].text == "Foundations of Sub-Tick Physics"
    assert headings[1].level == 3
    assert headings[1].text == "Continuous vs Discrete Collision"
    assert headings[2].level == 2
    assert headings[2].text == "Benchmarking Under High Load"
    assert headings[3].level == 3
    assert headings[3].text == "Memory Overhead Trade-Offs"


def test_extract_media_types_from_html():
    html_sample = """
    <div>
      <img src="hero.png" />
      <img src="chart.png" />
      <iframe src="https://youtube.com/embed/xyz"></iframe>
      <table><tr><td>Metric</td></tr></table>
      <pre><code>const engine = new PhysicsEngine();</code></pre>
    </div>
    """
    media = extract_media_types_from_html(html_sample)
    assert media["images"] == 2
    assert media["videos"] == 1
    assert media["tables"] == 1
    assert media["code_blocks"] >= 1


def test_extract_schema_types_from_html():
    html_sample = """
    <html>
      <head>
        <script type="application/ld+json">
          {
            "@context": "https://schema.org",
            "@type": "TechArticle",
            "headline": "Physics Engines"
          }
        </script>
        <script type="application/ld+json">
          {
            "@graph": [
              {"@type": "BreadcrumbList"},
              {"@type": "FAQPage"}
            ]
          }
        </script>
      </head>
    </html>
    """
    schemas = extract_schema_types_from_html(html_sample)
    assert "TechArticle" in schemas
    assert "BreadcrumbList" in schemas
    assert "FAQPage" in schemas


def test_extract_statistics_from_text():
    text_sample = (
        "Sub-tick execution at 120 fps reduces collision tunneling by 94.5% compared to baseline. "
        "The proprietary memory allocator yields a 3.5x throughput multiplier under synthetic stress. "
        "The enterprise migration budget exceeded $1.2 million across tier-1 studios."
    )
    stats = extract_statistics_from_text(text_sample)
    assert len(stats) >= 2
    combined = " ".join(stats)
    assert "94.5%" in combined or "3.5x" in combined or "120 fps" in combined


def test_extract_entities_from_text():
    text_sample = (
        "In Unreal Engine and Havok, developers frequently encounter tunneling artifacts. "
        "PhysX implements continuous collision sweeps, whereas Box2D relies on speculative contacts. "
        "Nvidia and Epic Games have pioneered sub-tick physics calculations."
    )
    entities = extract_entities_from_text(text_sample)
    assert any(e in entities for e in ["Unreal Engine", "Havok", "PhysX", "Box2D", "Epic Games", "Nvidia"])


def test_analyze_serp_gaps():
    # Setup 4 competitor pages
    page1 = CompetitorPageAnalysis(
        url="https://site1.com/guide",
        domain="site1.com",
        is_scraped=True,
        word_count=1800,
        entities=["Continuous Collision", "Havok", "Bounding Box", "Speculative Contacts"],
        headings=[
            HeadingItem(level=2, text="What is Continuous Collision Detection?"),
            HeadingItem(level=2, text="Overview of Bounding Boxes"),
        ]
    )
    page2 = CompetitorPageAnalysis(
        url="https://site2.com/guide",
        domain="site2.com",
        is_scraped=True,
        word_count=2200,
        entities=["Continuous Collision", "Havok", "Raycast", "Bounding Box"],
        headings=[
            HeadingItem(level=2, text="Continuous Collision Basics"),
            HeadingItem(level=2, text="Raycast Implementation"),
        ]
    )
    page3 = CompetitorPageAnalysis(
        url="https://site3.com/guide",
        domain="site3.com",
        is_scraped=True,
        word_count=2000,
        entities=["Continuous Collision", "PhysX", "Bounding Box"],
        headings=[
            HeadingItem(level=2, text="PhysX Architecture and Bounding Boxes"),
        ]
    )
    page4 = CompetitorPageAnalysis(
        url="https://site4.com/guide",
        domain="site4.com",
        is_scraped=True,
        word_count=2400,
        entities=["Continuous Collision", "Bounding Box", "Spatial Hashing"],
        headings=[
            HeadingItem(level=2, text="Spatial Hashing in Game Physics"),
        ]
    )

    paa_questions = [
        "What is continuous collision detection?",  # Answered by competitor headings
        "How to prevent tunneling at high velocity without performance degradation?",  # UNANSWERED OPPORTUNITY
        "Why is continuous collision computationally expensive?",  # UNANSWERED OPPORTUNITY
    ]

    gaps = analyze_serp_gaps([page1, page2, page3, page4], paa_questions)

    # "Continuous Collision" and "Bounding Box" appear in 4/4 pages (>= 50%) -> Table Stakes
    assert "Continuous Collision" in gaps["table_stakes_entities"]
    assert "Bounding Box" in gaps["table_stakes_entities"]

    # "Spatial Hashing" and "Speculative Contacts" appear in only 1 page -> Differentiators
    assert "Spatial Hashing" in gaps["differentiator_entities"] or "Speculative Contacts" in gaps["differentiator_entities"]

    # "How to prevent tunneling at high velocity..." should be identified as unanswered opportunity
    assert any("tunneling" in q.lower() for q in gaps["unanswered_paa_questions"])
    assert gaps["average_word_count"] == 2100


def test_unique_angle_from_evidence_pack():
    # 1. From explicit Evidence Pack (A3.2)
    pack = {
        "unique_angle": "Speculative contacts outperform continuous sweeps by 3.8x with zero tunneling under 120Hz ticks",
        "primary_finding": "Sweeps cause exponential CPU spikes when geometry density exceeds 5k polygons",
    }
    angle = resolve_unique_angle(evidence_pack=pack, primary_keyword="game physics")
    assert "Speculative contacts outperform" in angle

    # 2. Fallback synthesis
    fallback_angle = resolve_unique_angle(
        evidence_pack=None,
        angle_or_hook=None,
        primary_keyword="game physics",
        unanswered_paa=["How to prevent tunneling without lag?"],
        differentiators=["Spatial Hashing"],
    )
    assert "Spatial Hashing" in fallback_angle or "prevent tunneling" in fallback_angle


def test_calculate_word_count_range():
    pages = [
        CompetitorPageAnalysis(url="https://a.com", domain="a.com", word_count=2000, is_scraped=True),
        CompetitorPageAnalysis(url="https://b.com", domain="b.com", word_count=2200, is_scraped=True),
        CompetitorPageAnalysis(url="https://c.com", domain="c.com", word_count=1800, is_scraped=True),
    ]
    res = calculate_word_count_range(pages)
    # Average = 2000. Range should be 0.90x avg (1800) to 1.25x avg (2500)
    assert res["min"] == 1800
    assert res["max"] == 2500
    assert res["target_median"] == 2000
    assert "range" in res["guidance"].lower()
    assert "not an arbitrary keyword stuffing target" in res["guidance"].lower()


def test_plan_schema():
    schemas = plan_schema(
        topic="Building High-Performance Physics Engines in Next.js",
        search_intent="informational",
        has_paa=True,
        competitor_schemas=["TechArticle", "BreadcrumbList", "ItemList"],
    )
    assert "Article" in schemas
    assert "TechArticle" in schemas
    assert "FAQPage" in schemas
    assert "BreadcrumbList" in schemas
    assert "ItemList" in schemas


def test_scrape_and_analyze_page_mocked():
    html_content = """
    <!DOCTYPE html>
    <html>
      <head>
        <title>Ultimate Guide to Game Collision</title>
        <script type="application/ld+json">
          {"@type": "TechArticle", "headline": "Collision Mechanics"}
        </script>
      </head>
      <body>
        <h1>Title</h1>
        <h2>Understanding Raycasting</h2>
        <p>Continuous collision detection guarantees that fast projectiles will never tunnel through thin walls. In our benchmark testing across 500 instances, sub-tick integration reduced tunneling by 98% with an average frame time of 14 ms.</p>
        <h3>Speculative Contacts vs Sweeps</h3>
        <p>PhysX and Havok maintain distinct solver algorithms for high angular velocity simulations.</p>
        <img src="/test.jpg" />
        <pre><code>solver.integrate();</code></pre>
      </body>
    </html>
    """

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = html_content

    with patch("httpx.Client.get", return_value=mock_resp):
        analysis = scrape_and_analyze_page("https://example.com/physics", rank=1, check_robots=False)

    assert analysis.is_scraped is True
    assert analysis.rank == 1
    assert analysis.domain == "example.com"
    assert analysis.title == "Ultimate Guide to Game Collision"
    assert len(analysis.headings) >= 2
    assert "TechArticle" in analysis.schema_types
    assert analysis.media_types["images"] >= 1
    assert analysis.media_types["code_blocks"] >= 1
    assert analysis.word_count > 30


@patch("pipeline.adapters.brief_builder.fetch_and_analyze_competitors", return_value=[
    CompetitorPageAnalysis(url="https://site1.com", domain="site1.com", word_count=2100, is_scraped=True, entities=["Sub-Tick", "Havok", "Collision"], headings=[HeadingItem(level=2, text="Physics Architecture")]),
    CompetitorPageAnalysis(url="https://site2.com", domain="site2.com", word_count=1900, is_scraped=True, entities=["Sub-Tick", "PhysX", "Collision"], headings=[HeadingItem(level=2, text="Sub-Tick Simulation")]),
])
@patch("pipeline.adapters.brief_builder.call_llm", return_value='{"sections": [{"heading": "Core Mechanics of Physics", "level": 2, "intent_goal": "Foundational physics loop", "answer_first_guidance": "Direct Answer Target: Factual 40-word direct answer statement.", "required_entities": ["Sub-Tick", "Havok"], "required_statistics_or_claims": ["120 fps"]}]}')
def test_build_evidence_based_brief_full(mock_llm, mock_competitors):
    evidence_pack = {
        "unique_angle": "Empirical benchmark: Decoupling sub-tick collision sweeps into compute shaders eliminates 90% of main-thread lag",
        "primary_finding": "Main thread physics ticks stutter when rigid bodies exceed 2,000 active colliders",
    }

    brief = build_evidence_based_brief(
        topic="Sub-Tick Physics Engines in Unreal Engine",
        primary_keyword="sub-tick physics unreal",
        website_id="site_gaming",
        evidence_pack=evidence_pack,
        target_audience="Lead Gameplay Engineers and Simulation Developers",
        check_robots=False,
    )

    assert isinstance(brief, ContentBrief)
    assert brief.primary_keyword == "sub-tick physics unreal"
    assert "Empirical benchmark" in brief.unique_angle
    assert brief.target_reader == "Lead Gameplay Engineers and Simulation Developers"
    assert len(brief.required_sections) >= 1
    assert len(brief.required_entities) >= 2
    assert len(brief.questions_to_answer) >= 1
    # Check answer-first form is present
    first_q = brief.questions_to_answer[0]
    assert "answer_first_form" in first_q
    assert "Direct Answer Target:" in first_q["answer_first_form"]
    # Check word count range
    assert brief.word_count_range["min"] > 500
    assert brief.word_count_range["max"] > brief.word_count_range["min"]
    assert "claims_needing_sources" in brief.model_dump()
    assert "schema_plan" in brief.model_dump()
    assert brief.serp_summary is not None
    assert "competitor_count" in brief.serp_summary


def test_brief_to_outline_markdown():
    brief = ContentBrief(
        primary_keyword="game physics optimization",
        intent="Informational — High-performance game architecture",
        target_reader="Senior Simulation Engineers",
        unique_angle="Speculative contacts yield 4x frame stability over continuous sweeps",
        required_sections=[
            BriefSection(
                heading="Foundations of Discrete vs Continuous Collision",
                level=2,
                intent_goal="Explain core physics loop mechanics",
                answer_first_guidance="Direct Answer: Discrete collision checks overlaps at fixed intervals, whereas continuous checks swept volumes.",
                required_entities=["Bounding Box", "Time-of-Impact"],
                required_statistics_or_claims=["120Hz tick benchmark"],
            )
        ],
        required_entities=["Havok", "PhysX", "Bounding Box"],
        questions_to_answer=[
            {
                "question": "How do physics engines stop tunneling?",
                "answer_first_form": "Direct Answer: Engines employ continuous collision sweeps or conservative advancement.",
                "opportunity_type": "unanswered_paa_opportunity"
            }
        ],
        claims_needing_sources=["Sweeps add up to 4x CPU overhead compared to AABBs."],
        internal_link_candidates=[{"title": "Unreal Architecture", "target_url": "/posts/unreal-architecture"}],
        schema_plan=["TechArticle", "FAQPage"],
        word_count_range={"min": 1800, "max": 2400, "target_median": 2100},
        serp_summary={"competitor_count": 5}
    )

    markdown = brief_to_outline_markdown(brief)
    assert "# Content Brief & Production Outline" in markdown
    assert "Senior Simulation Engineers" in markdown
    assert "Speculative contacts yield 4x" in markdown
    assert "Direct Answer:" in markdown
    assert "How do physics engines stop tunneling?" in markdown
    assert "Claims Requiring Verified Sources" in markdown
    assert "Structured Data Schema Plan" in markdown


@patch("pipeline.adapters.brief_builder.fetch_and_analyze_competitors", return_value=[
    CompetitorPageAnalysis(url="https://site1.com", domain="site1.com", word_count=2100, is_scraped=True, entities=["Havok", "Fixed-Point", "Determinism"], headings=[HeadingItem(level=2, text="Physics Architecture")]),
    CompetitorPageAnalysis(url="https://site2.com", domain="site2.com", word_count=1900, is_scraped=True, entities=["Havok", "Speculative", "Determinism"], headings=[HeadingItem(level=2, text="Deterministic Sync")]),
])
@patch("pipeline.adapters.brief_builder.is_allowed_by_robots", return_value=True)
@patch("pipeline.adapters.brief_builder.call_llm", return_value='{"sections": [{"heading": "Foundations of Determinism", "level": 2, "intent_goal": "Explain deterministic loop", "answer_first_guidance": "Direct Answer Target: Deterministic simulation requires fixed timesteps.", "required_entities": ["Fixed-Point", "Havok"], "required_statistics_or_claims": ["Zero desync across 10k frames"]}]}')
def test_outline_node_integration(mock_llm, mock_robots, mock_competitors):
    state = {
        "topic": "Deterministic Game Physics Architecture",
        "keywords": ["game physics engine", "deterministic physics"],
        "target_audience": "Game engine developers and graphics programmers",
        "thread_id": "test-thread-a2",
        "status": "pending",
        "evidence_pack": {
            "unique_angle": "Fixed-point arithmetic with speculative contacts guarantees 100% network sync determinism across platforms"
        }
    }

    result = outline_node(state)
    assert result["status"] == "outlined"
    assert "content_brief" in result
    assert "serp_analysis" in result
    assert "outline" in result
    assert len(result["outline"]) > 200
    assert "discovered_keywords" in result
    assert result["evidence_pack"] is not None
    assert result["content_brief"]["primary_keyword"] == "game physics engine"
    assert "Fixed-point arithmetic" in result["content_brief"]["unique_angle"]
