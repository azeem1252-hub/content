"""
Unit test suite for the Humanizer skill and adapter.

Tests:
1. Verification of the Humanizer skill file (.agents/skills/humanizer/SKILL.md)
2. Dynamic skill loading via load_humanizer_skill()
3. Detection of classic AI writing patterns (em-dashes, overused words, not-X-but-Y, staged openers)
4. Deterministic cleaning of mechanical tells without affecting code blocks
5. Integration with editorial auditing (audit_node)
"""

import sys
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pytest
from pipeline.adapters.humanizer import (
    get_humanizer_skill_path,
    load_humanizer_skill,
    detect_ai_tells,
    clean_deterministic_tells
)
from pipeline.nodes.audit_node import audit_and_optimize_seo


def test_humanizer_skill_file_exists():
    path = get_humanizer_skill_path()
    assert path.exists(), f"Skill file does not exist at {path}"
    content = path.read_text(encoding="utf-8")
    assert "name: humanizer" in content
    assert "Rewrite AI-sounding text" in content
    assert "Signs of AI writing" in content
    assert "Not X but Y" in content


def test_load_humanizer_skill_loads_content():
    skill_text = load_humanizer_skill()
    assert len(skill_text) > 500
    assert "Humanizer: remove AI writing patterns" in skill_text
    assert "§1. Not X but Y" in skill_text or "1. Not X but Y" in skill_text


def test_detect_ai_tells_identifies_patterns():
    ai_sample = (
        "Let's dive in. It's not just about speed, it's about reliability.\n\n"
        "The new architecture stands as a testament to engineering excellence — delivering results.\n"
        "We delve deep into the tapestry of microservices. That is the real win.\n"
        "```python\n"
        "# Code block with dash should be ignored\n"
        "result = a - b\n"
        "```\n"
    )

    tells = detect_ai_tells(ai_sample)
    rules_detected = [t.get("rule", "") for t in tells]
    words_detected = [t.get("word", "") for t in tells if "word" in t]

    # Verify em-dash detection
    assert any("Em/En-dashes" in r for r in rules_detected)
    # Verify staged opener detection
    assert any("Staged opener" in r for r in rules_detected)
    # Verify overused words detection
    assert "delve" in words_detected
    assert "testament" in words_detected
    assert "tapestry" in words_detected


def test_clean_deterministic_tells_normalizes_text():
    sample_with_tells = (
        "Here is the announcement.\n"
        "The system — fast and reliable – scales easily.\n"
        "“Smart quotes” and ‘single quotes’ should become straight.\n"
        "```python\n"
        "# Preserve code block untouched\n"
        "x = 10 — 5\n"
        "```\n"
        "I hope this helps! Let me know if you need more details.\n"
    )

    cleaned = clean_deterministic_tells(sample_with_tells)

    # Em-dashes in prose should be replaced
    assert "system, fast and reliable, scales" in cleaned or "system - fast" in cleaned
    # Curly quotes should be straight
    assert '“' not in cleaned
    assert '”' not in cleaned
    assert '"Smart quotes"' in cleaned
    # Chatbot residue should be stripped
    assert "I hope this helps!" not in cleaned
    # Code block preserved
    assert "x = 10 — 5" in cleaned


def test_clean_text_produces_zero_critical_tells():
    clean_sample = (
        "Next.js handles routing and caching automatically. "
        "Engineers configure the cache handler using Redis or SQLite. "
        "The benchmark showed a 40ms response time on cache hits."
    )
    tells = detect_ai_tells(clean_sample)
    # No staged openers, em-dashes, or overused buzzwords
    assert len(tells) == 0


def test_audit_node_incorporates_humanizer():
    title = "Deploying Distributed Cache on Edge Networks"
    # Realistic article body (800+ words, 3 H2s, keyword in intro) so the
    # deterministic SEO checks pass like they would for a real draft.
    body = (
        "Edge caching changes how applications deliver content to users around the world. "
        "When a response is cached close to the reader, latency drops and origin servers stay healthy. "
        "This guide walks through the architecture decisions that make edge caching work in practice.\n\n"
        "## Why Cache at the Edge\n\n"
        "Caching cuts redundant network trips across edge nodes. Engineers configure memory bounds "
        "and eviction policies directly in the gateway config. A request that once crossed three "
        "continents now resolves in the same metro area as the reader. The result is a faster and "
        "more predictable experience for everyone, especially on mobile networks where round trips "
        "are expensive. Teams that moved static assets to the edge report meaningful gains in "
        "conversion and engagement because pages paint sooner.\n\n"
        "## Designing the Cache Hierarchy\n\n"
        "A good hierarchy separates immutable assets from dynamic responses. Hash filenames for "
        "static bundles so they can live at the edge for months, and keep personalized responses "
        "at the origin behind short TTLs. Redis or a similar in-memory store handles hot keys close "
        "to the application, while the edge network absorbs the long tail. Monitor hit ratios per "
        "region and adjust TTLs based on real traffic instead of guesses. When a deploy invalidates "
        "paths, purge them surgically rather than flushing everything.\n\n"
        "## Operating and Measuring\n\n"
        "Operationally, edge caching needs observability. Track p95 latency, cache hit ratio, and "
        "origin error rate on one dashboard. Alert on hit ratio drops because they usually signal a "
        "misconfigured header or an accidental cache bust. Run load tests before major launches and "
        "verify that failover works when a region goes dark. The edge caching layer should degrade "
        "gracefully to origin without stampeding it. With these practices, the edge caching tier "
        "becomes a dependable part of the platform rather than a source of surprises."
    )
    res = audit_and_optimize_seo(
        title=title,
        draft=body,
        topic="Edge Caching",
        keywords=["Edge Caching", "Redis"]
    )
    assert "Humanizer:" in res["audit_notes"]
    assert res["seo_score"] >= 70
