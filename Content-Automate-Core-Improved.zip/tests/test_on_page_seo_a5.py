"""
Unit and Integration Tests for Pillar A5: On-Page SEO, Schema, and Internal Links.

Validates:
1. Meta title/description/slug from brief with configurable length checks & A4 cross-check.
2. Structured data:
   - Emits Article, Person (with sameAs), Organization (with sameAs), BreadcrumbList, Product.
   - FAQPage emitted ONLY when visible FAQ content exists, tagged with unproven/AB test metadata.
   - HowTo markup is optional (retired by Google as rich result, steps kept in HTML).
   - Value matching between schema and visible page.
   - CI JSON-LD validation simulating extruct round-trip.
3. Internal links:
   - Embeds draft and proposes 3-5 contextual links with natural anchor text.
   - Inbound link proposals from related cluster posts.
   - Human review workflow (approve/reject).
4. Answer-first lint:
   - Direct lead answers in major sections.
   - Length targets treated as configurable warnings, not rules.
   - Preamble fluff warnings.
5. Quality lint:
   - Readability metrics (Flesch Reading Ease, Flesch-Kincaid Grade Level).
   - Banned phrases (AI clichés).
   - "Every statistic has a source" check.
   - Byline and updated-date presence.
   - Unsourced superlatives detection.
6. Image provenance & IPTC metadata:
   - Classifies user assets, screenshots, charts, AI generation.
   - Emits standard IPTC trainedAlgorithmicMedia metadata for AI images.
"""

import json
import pytest
from pipeline.adapters.on_page_seo_linter import (
    MetaLengthConfig,
    validate_meta_elements,
    lint_answer_first,
    calculate_readability,
    lint_quality_standards,
    run_on_page_seo_audit,
)
from pipeline.adapters.schema_builder import (
    build_json_ld_schemas,
    generate_product_schema,
    validate_page_content_matching,
    validate_json_ld_ci,
    render_json_ld_script,
)
from pipeline.adapters.internal_linker import (
    propose_contextual_internal_links,
    update_link_proposal_status,
    apply_approved_outbound_links,
)
from pipeline.adapters.image_provenance import (
    create_image_provenance,
    IPTC_TRAINED_ALGORITHMIC_MEDIA,
    IPTC_ORIGINAL_MEDIA,
    IPTC_DATA_DRIVEN_MEDIA,
)


SAMPLE_ARTICLE_DRAFT = """
# Enterprise Hybrid Search Architecture

## What is Hybrid Search?
Hybrid search combines dense vector retrieval and sparse keyword matching into a single scoring pipeline. Dense vectors capture deep semantic intent and conceptual synonyms, while sparse BM25 indexing guarantees precision on exact product codes, acronyms, and alphanumeric part numbers.

### Performance Benchmarks Across Vector Engines
According to production benchmarks published by DeepScale Labs, query latency remains under 35ms:

| Database | Latency (p99) | Precision@10 | Memory Usage |
| :--- | :--- | :--- | :--- |
| Qdrant | 18ms | 94.2% | 16 GB |
| Pinecone | 24ms | 91.8% | Cloud |
| Milvus | 22ms | 93.1% | 24 GB |

## How to Configure Reciprocal Rank Fusion
Follow these sequential implementation steps:

1. Generate standard 768-dimension dense embeddings from input text chunks.
2. Ingest document tokens into a sparse BM25 inverted index.
3. Compute reciprocal rank fusion across both ranked candidate lists with a constant of 60.
4. Pass top 20 fused candidates to the cross-encoder re-ranker model.

### Frequently Asked Questions

**What is the primary benefit of hybrid search?**
The primary benefit is eliminating zero-result edge cases when users search for exact technical codes or industry terminology.

**Does hybrid search increase query latency?**
Hybrid search adds approximately 4ms to 8ms of rank fusion overhead compared to single-index vector search alone.
"""

SAMPLE_DRAFT_WITH_FLUFF = """
# Modern Technology

## What is Technology?
In today's fast-paced digital world, it is important to note that technology is changing everything. Dive deep to explore the wonderful landscape of digital innovation.

We believe this is the best and fastest solution ever created. 85% of users love it.
"""


# ---------------------------------------------------------------------------
# 1. Meta Elements & Length Checks Tests
# ---------------------------------------------------------------------------

def test_meta_elements_valid_length():
    """Verify optimal length checks for title, meta description, and slug."""
    title = "Enterprise Hybrid Search Architecture: Complete Guide"
    desc = "Explore how enterprise hybrid search combines dense vector retrieval and sparse BM25 indexing to achieve 94% precision with sub-35ms query latency."
    slug = "enterprise-hybrid-search-architecture"

    res = validate_meta_elements(title, desc, slug)
    assert res["passed"] is True
    assert len(res["issues"]) == 0
    assert 50 <= res["title_length"] <= 60
    assert 120 <= res["description_length"] <= 160


def test_meta_elements_length_warnings():
    """Verify warnings (not hard errors) are issued when lengths deviate from targets."""
    short_title = "Search"
    short_desc = "Quick guide."
    invalid_slug = "Invalid Slug With Spaces & Special!"

    res = validate_meta_elements(short_title, short_desc, invalid_slug)
    assert res["passed"] is False
    assert any(w["field"] == "meta_title" for w in res["warnings"])
    assert any(w["field"] == "meta_description" for w in res["warnings"])
    # Slug format error is an issue
    assert any(i["field"] == "slug" for i in res["issues"])


def test_meta_elements_a4_cross_check():
    """Verify integration cross-check with A4 fact-verification report."""
    title = "Enterprise Hybrid Search Architecture"
    desc = "A complete architectural breakdown of reciprocal rank fusion."
    slug = "enterprise-hybrid-search"

    fact_report = {
        "surfaces_checked": {
            "title": {"checked": True, "verdict": "supported"},
            "meta_description": {"checked": True, "verdict": "supported"},
        }
    }
    res = validate_meta_elements(title, desc, slug, fact_verification_report=fact_report)
    assert res["checked_in_a4"] is True


# ---------------------------------------------------------------------------
# 2. Structured Data (Schema.org JSON-LD) Tests
# ---------------------------------------------------------------------------

def test_schema_emits_core_types_and_product():
    """Verify emission of Article, Person, Organization, BreadcrumbList, and Product."""
    product_data = {
        "name": "Qdrant Vector Engine",
        "description": "High-performance vector database with hybrid search support.",
        "brand": "Qdrant Solutions",
        "rating_value": 4.8,
        "review_count": 42,
        "offers": {"price": "0.00", "currency": "USD"},
    }

    schemas = build_json_ld_schemas(
        title="Enterprise Hybrid Search Architecture",
        slug="enterprise-hybrid-search",
        content=SAMPLE_ARTICLE_DRAFT,
        meta_description="Enterprise guide to hybrid vector and sparse search.",
        author_name="Elena Vance",
        publisher_name="DeepScale Labs",
        product_info=product_data,
        include_howto_schema=False,
    )

    types = [s.get("@type") for s in schemas]
    assert "Article" in types
    assert "Person" in types
    assert "Organization" in types
    assert "BreadcrumbList" in types
    assert "Product" in types

    # Verify Product schema details
    prod_schema = next(s for s in schemas if s.get("@type") == "Product")
    assert prod_schema["name"] == "Qdrant Vector Engine"
    assert prod_schema["aggregateRating"]["ratingValue"] == 4.8
    assert prod_schema["offers"]["price"] == "0.00"


def test_faq_page_schema_only_with_visible_faq_and_ab_test():
    """Verify FAQPage is emitted ONLY when visible FAQ exists, and includes A/B test metadata."""
    # Draft with FAQ pairs
    schemas_with_faq = build_json_ld_schemas(
        title="Enterprise Hybrid Search",
        slug="hybrid-search",
        content=SAMPLE_ARTICLE_DRAFT,
        visible_faq_required=True,
    )
    faq_schema = next((s for s in schemas_with_faq if s.get("@type") == "FAQPage"), None)
    assert faq_schema is not None
    assert len(faq_schema["mainEntity"]) == 2
    assert faq_schema.get("abTestGroup") == "ai_citation_experiment"
    assert "Retired as Google rich snippet" in faq_schema.get("comment", "")

    # Content without any FAQ content
    content_no_faq = "# Just a Title\n\nNo questions and answers here."
    schemas_without_faq = build_json_ld_schemas(
        title="No FAQ Post",
        slug="no-faq-post",
        content=content_no_faq,
        visible_faq_required=True,
    )
    assert not any(s.get("@type") == "FAQPage" for s in schemas_without_faq)


def test_howto_schema_optional():
    """Verify HowTo schema is retired by default, and optional when explicitly requested."""
    # Default: HowTo markup is disabled (HTML step lists kept in draft)
    schemas_default = build_json_ld_schemas(
        title="How to Configure Reciprocal Rank Fusion",
        slug="how-to-fusion",
        content=SAMPLE_ARTICLE_DRAFT,
        include_howto_schema=False,
    )
    assert not any(s.get("@type") == "HowTo" for s in schemas_default)

    # Optional: explicitly enabled
    schemas_enabled = build_json_ld_schemas(
        title="How to Configure Reciprocal Rank Fusion",
        slug="how-to-fusion",
        content=SAMPLE_ARTICLE_DRAFT,
        include_howto_schema=True,
    )
    assert any(s.get("@type") == "HowTo" for s in schemas_enabled)


def test_schema_values_match_visible_page():
    """Verify that schema values match visible content on the page."""
    schemas = build_json_ld_schemas(
        title="Enterprise Hybrid Search Architecture",
        slug="enterprise-hybrid-search",
        content=SAMPLE_ARTICLE_DRAFT,
        author_name="Elena Vance",
    )
    matching = validate_page_content_matching(schemas, SAMPLE_ARTICLE_DRAFT)
    assert matching["passed"] is True
    assert len(matching["mismatches"]) == 0

    # Test discrepancy: fabricate a headline not on page
    bogus_schema = [{"@type": "Article", "headline": "Completely Unrelated Cryptocurrency Guide"}]
    bad_matching = validate_page_content_matching(bogus_schema, SAMPLE_ARTICLE_DRAFT)
    assert bad_matching["passed"] is False
    assert len(bad_matching["mismatches"]) >= 1


def test_json_ld_ci_round_trip_validation():
    """Verify CI JSON-LD validator round-trip parsing and compliance."""
    schemas = build_json_ld_schemas(
        title="Enterprise Hybrid Search Architecture",
        slug="enterprise-hybrid-search",
        content=SAMPLE_ARTICLE_DRAFT,
        author_name="Elena Vance",
    )
    html_script = render_json_ld_script(schemas)

    ci_result = validate_json_ld_ci(html_script, visible_text=SAMPLE_ARTICLE_DRAFT)
    assert ci_result["valid"] is True
    assert len(ci_result["errors"]) == 0
    assert "Article" in ci_result["detected_types"]


# ---------------------------------------------------------------------------
# 3. Contextual Internal Links Tests
# ---------------------------------------------------------------------------

def test_contextual_internal_link_proposals():
    """Verify generation of 3-5 contextual outbound proposals and inbound suggestions."""
    proposals = propose_contextual_internal_links(
        draft=SAMPLE_ARTICLE_DRAFT,
        new_post_slug="enterprise-hybrid-search",
        new_post_title="Enterprise Hybrid Search Architecture",
        min_links=3,
        max_links=5,
    )
    assert "outbound_proposals" in proposals
    assert "inbound_proposals" in proposals
    # Proposals start in 'proposed' status
    for p in proposals["outbound_proposals"]:
        assert p["status"] == "proposed"
        assert p["anchor_text"] != ""
        assert p["target_url"].startswith("/posts/")


def test_internal_link_human_review_workflow():
    """Verify humans can approve or reject link proposals."""
    sample_proposals = [
        {"id": "outbound-1", "type": "outbound", "anchor_text": "dense vector retrieval", "target_url": "/posts/vectors", "status": "proposed"},
        {"id": "outbound-2", "type": "outbound", "anchor_text": "BM25 inverted index", "target_url": "/posts/bm25", "status": "proposed"},
    ]

    # Human approves outbound-1 and rejects outbound-2
    updated = update_link_proposal_status(sample_proposals, "outbound-1", "approved", comment="Great contextual fit")
    updated = update_link_proposal_status(updated, "outbound-2", "rejected", comment="Too granular")

    assert updated[0]["status"] == "approved"
    assert updated[0]["review_comment"] == "Great contextual fit"
    assert updated[1]["status"] == "rejected"

    # Only approved links are applied to the markdown draft
    draft_applied = apply_approved_outbound_links(SAMPLE_ARTICLE_DRAFT, updated)
    assert "[dense vector retrieval](/posts/vectors)" in draft_applied
    assert "[BM25 inverted index](/posts/bm25)" not in draft_applied


# ---------------------------------------------------------------------------
# 4. Answer-First Lint Tests (Warnings, Not Rules)
# ---------------------------------------------------------------------------

def test_answer_first_clean_draft():
    """Verify clean direct lead sentences pass without warnings."""
    res = lint_answer_first(SAMPLE_ARTICLE_DRAFT)
    assert res["passed"] is True
    assert res["answer_first_count"] >= 1


def test_answer_first_fluff_warnings():
    """Verify preamble fluff triggers configurable warnings without breaking pipeline."""
    res = lint_answer_first(SAMPLE_DRAFT_WITH_FLUFF)
    assert any(w["type"] == "preamble_fluff" for w in res["warnings"])
    assert "warnings, never hard blocking rules" in res["guidance"]


# ---------------------------------------------------------------------------
# 5. Quality Lint Tests
# ---------------------------------------------------------------------------

def test_readability_metrics():
    """Verify Flesch Reading Ease and Grade Level calculations."""
    readability = calculate_readability(SAMPLE_ARTICLE_DRAFT)
    assert "flesch_reading_ease" in readability
    assert "flesch_kincaid_grade" in readability
    assert readability["flesch_reading_ease"] > 0


def test_quality_lint_banned_phrases_and_unsourced_stats():
    """Verify banned AI phrases and unsourced statistics/superlatives are detected."""
    res = lint_quality_standards(
        draft=SAMPLE_DRAFT_WITH_FLUFF,
        author="Admin",  # Generic author triggers warning
        published_at=None,  # Missing date triggers warning
    )
    assert res["passed"] is False

    # Banned phrases detected
    banned = [b["phrase"] for b in res["banned_phrases_detected"]]
    assert any("fast-paced world" in b or "dive deep" in b or "it is important to note that" in b for b in banned)

    # Unsourced superlatives detected
    assert len(res["unsourced_superlatives"]) >= 1

    # Missing byline / dates warnings
    types = [w["type"] for w in res["warnings"]]
    assert "missing_byline" in types
    assert "missing_updated_date" in types


def test_quality_lint_clean_draft():
    """Verify clean draft with cited stats and named author passes quality lint."""
    res = lint_quality_standards(
        draft=SAMPLE_ARTICLE_DRAFT,
        author="Dr. Elena Vance",
        published_at="2026-03-20T10:00:00Z",
        updated_at="2026-03-25T12:00:00Z",
    )
    assert res["has_author_byline"] is True
    assert res["has_dates"] is True
    assert len(res["banned_phrases_detected"]) == 0


def test_run_on_page_seo_audit_master():
    """Verify master on-page SEO audit combining meta, answer-first, and quality checks."""
    result = run_on_page_seo_audit(
        draft=SAMPLE_ARTICLE_DRAFT,
        title="Enterprise Hybrid Search Architecture: Complete Guide",
        meta_description="A complete architectural breakdown of enterprise hybrid search combining dense vectors and sparse BM25 indexing.",
        slug="enterprise-hybrid-search-architecture",
        author="Elena Vance",
        published_at="2026-03-20T10:00:00Z",
        updated_at="2026-03-25T12:00:00Z",
    )
    assert result["passed"] is True
    assert "meta_validation" in result
    assert "answer_first_lint" in result
    assert "quality_lint" in result


# ---------------------------------------------------------------------------
# 6. Image Provenance & IPTC Metadata Tests
# ---------------------------------------------------------------------------

def test_image_provenance_ai_generated():
    """Verify AI image provenance includes IPTC trainedAlgorithmicMedia tag."""
    rec = create_image_provenance(
        image_url="/uploads/hero-hybrid-search.png",
        image_type="ai_generated",
        ai_engine="cloudflare",
        model_name="flux-1-schnell",
        generation_prompt="Architectural blueprint of dense vector clusters",
    )
    assert rec.is_ai_generated is True
    assert rec.ai_engine == "cloudflare"
    assert rec.iptc_metadata["DigitalSourceType"] == IPTC_TRAINED_ALGORITHMIC_MEDIA
    assert "flux-1-schnell" in rec.iptc_metadata["CreditLine"]


def test_image_provenance_chart_and_user_asset():
    """Verify non-AI assets receive appropriate IPTC tags."""
    chart_rec = create_image_provenance(
        image_url="/uploads/latency-benchmark.png",
        image_type="data_chart",
        publisher_name="DeepScale Labs",
    )
    assert chart_rec.is_ai_generated is False
    assert chart_rec.iptc_metadata["DigitalSourceType"] == IPTC_DATA_DRIVEN_MEDIA

    user_rec = create_image_provenance(
        image_url="/uploads/author-headshot.jpg",
        image_type="user_asset",
        publisher_name="DeepScale Labs",
    )
    assert user_rec.is_ai_generated is False
    assert user_rec.iptc_metadata["DigitalSourceType"] == IPTC_ORIGINAL_MEDIA
