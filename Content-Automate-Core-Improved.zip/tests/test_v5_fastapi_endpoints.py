"""
Tests for FastAPI REST Endpoints (v5 Pillars A0, A1b, A8b, A9, A10, A12).
"""

import pytest
from starlette.testclient import TestClient
from web.app import app
import storage.db as db

client = TestClient(app)
SITE_ID = "test_endpoint_site"


@pytest.fixture(autouse=True)
def setup_test_site():
    db.init_db()
    db.upsert_website(SITE_ID, "Endpoint Test Site", "https://endpoints.test.com", "token_test_123")


def test_business_profile_and_competitor_endpoints():
    # 1. Get profile (unconfigured initially)
    resp = client.get(f"/api/onboarding/business-profile/{SITE_ID}")
    assert resp.status_code == 200
    assert resp.json()["status"] in ("unconfigured", "configured")

    # 2. Classify competitors
    resp_comp = client.post(
        f"/api/onboarding/competitors/{SITE_ID}",
        json={"domains": ["reddit.com", "mycompetitor.io"]}
    )
    assert resp_comp.status_code == 200
    data = resp_comp.json()
    assert data["success"] is True
    assert len(data["competitors"]) == 2


def test_opportunity_feed_endpoints():
    # 1. Generate opportunities
    resp_gen = client.post(f"/api/opportunities/generate/{SITE_ID}?limit=10")
    assert resp_gen.status_code == 200
    gen_data = resp_gen.json()
    assert gen_data["success"] is True
    assert len(gen_data["opportunities"]) >= 1

    item_id = gen_data["opportunities"][0]["id"]

    # 2. Get feed
    resp_get = client.get(f"/api/opportunities/feed/{SITE_ID}")
    assert resp_get.status_code == 200
    assert resp_get.json()["count"] >= 1

    # 3. Process feedback
    resp_fb = client.post(
        f"/api/opportunities/{item_id}/feedback",
        json={"action": "accepted"}
    )
    assert resp_fb.status_code == 200
    assert resp_fb.json()["new_status"] == "accepted"


def test_decay_and_change_set_endpoints():
    # Get decay plans
    resp_plans = client.get(f"/api/decay/plans/{SITE_ID}")
    assert resp_plans.status_code == 200
    assert "plans" in resp_plans.json()

    # Get change set
    resp_chg = client.get(f"/api/decay/plans/plan_123/changes?website_id={SITE_ID}&url=https://example.com/test")
    assert resp_chg.status_code == 200
    assert resp_chg.json()["success"] is True


def test_off_site_endpoints():
    # Get summary
    resp_sum = client.get(f"/api/off-site/summary/{SITE_ID}")
    assert resp_sum.status_code == 200
    assert "compliance_rules" in resp_sum.json()

    # Create plan
    resp_plan = client.post(
        f"/api/off-site/plan/{SITE_ID}",
        json={"cluster_id": "clus_api", "topic": "FastAPI Production Best Practices"}
    )
    assert resp_plan.status_code == 200
    assert resp_plan.json()["success"] is True
    assert len(resp_plan.json()["plan_targets"]) >= 3


def test_compliance_and_attestation_endpoints():
    # 1. Settings GET & POST
    resp_set = client.get(f"/api/compliance/settings/{SITE_ID}")
    assert resp_set.status_code == 200
    assert resp_set.json()["website_id"] == SITE_ID

    resp_save = client.post(
        f"/api/compliance/settings/{SITE_ID}",
        json={
            "eu_ai_act_disclosure_enabled": True,
            "disclosure_label_text": "Fact-checked by our editorial board.",
            "disclosure_position": "header_and_footer",
            "require_expert_for_ymyl": True,
            "embed_iptc_provenance": True
        }
    )
    assert resp_save.status_code == 200
    assert resp_save.json()["settings"]["disclosure_position"] == "header_and_footer"

    # 2. Incomplete checklist -> fails with 400
    bad_att = client.post(
        "/api/compliance/attest",
        json={
            "website_id": SITE_ID,
            "post_slug": "api-guide",
            "title": "API Guide",
            "content": "Sample content",
            "reviewer_name": "Jane",
            "reviewer_email": "jane@internal.com",
            "is_qualified_expert": True,
            "checklist": {"title_verified": True}  # Missing other required items
        }
    )
    assert bad_att.status_code == 400

    # 3. Complete checklist -> succeeds
    good_att = client.post(
        "/api/compliance/attest",
        json={
            "website_id": SITE_ID,
            "post_slug": "api-guide",
            "title": "API Guide",
            "content": "Sample content",
            "reviewer_name": "Jane Doe",
            "reviewer_email": "jane@internal.com",
            "reviewer_role": "Managing Editor",
            "is_qualified_expert": True,
            "checklist": {
                "title_verified": True,
                "meta_description_verified": True,
                "schema_verified": True,
                "alt_text_verified": True,
                "claims_and_stats_verified": True
            }
        }
    )
    assert good_att.status_code == 200
    assert good_att.json()["success"] is True

    # 4. Fetch attestations
    resp_att_list = client.get(f"/api/compliance/attestations/{SITE_ID}")
    assert resp_att_list.status_code == 200
    assert resp_att_list.json()["count"] >= 1


def test_experiments_did_endpoints():
    # 1. Launch experiment
    resp_launch = client.post(
        "/api/experiments/launch",
        json={
            "website_id": SITE_ID,
            "hypothesis": "Adding direct answer blocks improves CTR and snippet wins.",
            "experiment_type": "aeo_answer_blocks",
            "treated_urls": ["https://example.com/p1", "https://example.com/p2"],
            "control_urls": ["https://example.com/c1", "https://example.com/c2"]
        }
    )
    assert resp_launch.status_code == 200
    assert resp_launch.json()["success"] is True

    # 2. Evaluate DiD
    resp_did = client.post(
        "/api/experiments/evaluate-did",
        json={
            "treatment_pre": [10.0, 12.0, 11.0],
            "treatment_post": [25.0, 27.0, 26.0],
            "control_pre": [10.0, 11.0, 10.0],
            "control_post": [11.0, 12.0, 11.0],
            "metric_name": "clicks"
        }
    )
    assert resp_did.status_code == 200
    res = resp_did.json()
    assert res["did_causal_effect"] > 10.0
    assert res["verdict"] == "positive_lift"
