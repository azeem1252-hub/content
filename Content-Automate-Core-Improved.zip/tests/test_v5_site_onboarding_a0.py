"""
Tests for Pillar A0: Site Onboarding, Business Understanding & Content Inventory.
"""

import pytest
from pipeline.adapters.site_onboarding import (
    parse_html_page_inventory,
    detect_orphan_pages,
    classify_competitor_domain,
    discover_and_classify_competitors,
    extract_business_profile_from_content
)
import storage.db as db


SAMPLE_HTML = """<!DOCTYPE html>
<html>
<head>
    <title>Enterprise Content Automation Platform</title>
    <meta name="description" content="AI editorial automation pipeline with closed-loop fact verification.">
    <link rel="canonical" href="https://example.com/platform">
    <meta property="article:published_time" content="2026-01-15T08:00:00Z">
    <meta property="article:modified_time" content="2026-03-20T10:00:00Z">
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "TechArticle",
        "headline": "Enterprise Content Automation Platform"
    }
    </script>
</head>
<body>
    <h1>Enterprise Content Automation</h1>
    <p>Automate your complete editorial lifecycle with rigorous fact verification.</p>
    <h2>Core Engine</h2>
    <p>Using LangGraph state machines and multi-model routing.</p>
    <img src="/assets/diagram.png" alt="Architecture flow diagram">
    <img src="/assets/decorative.png" alt="">
    <a href="https://example.com/pricing">See Pricing</a>
    <a href="https://github.com/example/repo">GitHub Repository</a>
</body>
</html>
"""


def test_parse_html_page_inventory():
    record = parse_html_page_inventory(
        url="https://example.com/platform",
        html=SAMPLE_HTML,
        website_id="site_test_a0"
    )
    assert record["title"] == "Enterprise Content Automation Platform"
    assert "fact verification" in record["meta_description"]
    assert record["canonical_url"] == "https://example.com/platform"
    assert record["is_indexable"] is True
    assert record["published_date"] == "2026-01-15T08:00:00Z"
    assert record["modified_date"] == "2026-03-20T10:00:00Z"
    assert "TechArticle" in record["schema_types"]
    assert len(record["h_tree"]) == 2
    assert record["h_tree"][0]["text"] == "Enterprise Content Automation"
    assert len(record["images"]) == 2
    assert record["images"][0]["has_alt"] is True
    assert record["images"][1]["has_alt"] is False
    assert record["outbound_links_count"] == 1  # github.com is external


def test_detect_orphan_pages():
    pages = [
        {"url": "https://example.com/", "content_type": "home"},
        {"url": "https://example.com/pricing", "content_type": "page"},
        {"url": "https://example.com/abandoned-draft", "content_type": "blog"}
    ]
    # pricing is linked from home, abandoned-draft has no inbound links
    links = [
        ("https://example.com/", "https://example.com/pricing")
    ]
    audited = detect_orphan_pages("site_test_a0", pages, links)
    by_url = {p["url"]: p for p in audited}

    assert by_url["https://example.com/pricing"]["is_orphan"] is False
    assert by_url["https://example.com/abandoned-draft"]["is_orphan"] is True
    assert by_url["https://example.com/"]["is_orphan"] is False


def test_competitor_classification():
    assert classify_competitor_domain("wikipedia.org") == "search"
    assert classify_competitor_domain("reddit.com") == "search"
    assert classify_competitor_domain("g2.com") == "search"
    assert classify_competitor_domain("jasper.ai") == "business"
    assert classify_competitor_domain("copy.ai") == "business"

    classified = discover_and_classify_competitors("site_test_a0", ["reddit.com", "jasper.ai"])
    assert len(classified) == 2
    types = {c["domain"]: c["competitor_type"] for c in classified}
    assert types["reddit.com"] == "search"
    assert types["jasper.ai"] == "business"


def test_extract_business_profile_mock(monkeypatch):
    monkeypatch.setattr(
        "pipeline.adapters.site_onboarding.call_llm",
        lambda **kwargs: '{"offerings": ["Enterprise AI Publishing"], "pricing_model": "subscription", "tone": "authoritative"}'
    )
    profile = extract_business_profile_from_content(
        website_id="site_test_a0",
        home_html="<h1>Enterprise AI Publishing</h1>"
    )
    assert profile["website_id"] == "site_test_a0"
    assert profile["offerings"] == ["Enterprise AI Publishing"]
    assert profile["pricing_model"] == "subscription"
