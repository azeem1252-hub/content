import os
import sys
import json

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from pipeline.adapters.slack_bot import (
    build_slack_review_card,
    build_feedback_modal,
    build_approval_banner,
    send_slack_card
)

def test_slack_review_card_system():
    print("=" * 60)
    print("Testing Step 4: Slack Interactive Review Gate & Block Kit")
    print("=" * 60)

    sample_state = {
        "title": "Autonomous AI Agents in 2026: The Architecture of Self-Publishing Engines",
        "topic": "Autonomous AI Agents",
        "slug": "autonomous-ai-agents-2026",
        "draft": "# Title: Autonomous AI Agents in 2026\n\nDeep longform text here...",
        "meta_description": "A technical deep-dive into state persistence, interrupts, and human review gates.",
        "hero_image_url": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
        "discovered_keywords": ["LangGraph", "Groq", "Autonomous Publishing"],
        "word_count": 1420,
        "read_time": 7,
        "seo_score": 95,
        "revision_count": 1,
        "thread_id": "thread-slack-test-101",
        "review_status": "pending",
        "status": "audited"
    }

    # 1. Test Block Kit Review Card Generation
    print("\n[1/4] Generating Slack Block Kit Review Card...")
    card = build_slack_review_card(sample_state)
    assert card["channel"] is not None
    assert "blocks" in card
    blocks = card["blocks"]
    assert len(blocks) >= 4

    # Validate action buttons
    action_block = next((b for b in blocks if b.get("type") == "actions"), None)
    assert action_block is not None, "Actions block with buttons is missing!"
    elements = action_block.get("elements", [])
    action_ids = [el.get("action_id") for el in elements]
    assert "action_approve" in action_ids, "action_approve button missing!"
    assert "action_request_changes" in action_ids, "action_request_changes button missing!"
    assert "action_reject" in action_ids, "action_reject button missing!"
    print("[OK] Review card Block Kit generated with Approve, Request Changes, and Reject buttons.")

    # 2. Test Feedback Modal Generation
    print("\n[2/4] Testing Editorial Revision Modal...")
    modal = build_feedback_modal(thread_id="thread-slack-test-101", current_title=sample_state["title"])
    assert modal["type"] == "modal"
    assert modal["callback_id"] == "modal_editorial_feedback"
    assert "feedback_input_block" in str(modal["blocks"])
    print("[OK] Feedback modal view generated successfully.")

    # 3. Test In-Place Approval Banner
    print("\n[3/4] Testing Post-Approval Success Banner...")
    banner = build_approval_banner(
        title=sample_state["title"],
        user_name="lead_editor",
        published_url="http://127.0.0.1:8000/posts/autonomous-ai-agents-2026"
    )
    assert len(banner) >= 2
    assert "lead_editor" in banner[1]["text"]["text"]
    assert "http://127.0.0.1:8000/posts/autonomous-ai-agents-2026" in banner[1]["text"]["text"]
    print("[OK] Approval banner generated successfully.")

    # 4. Test Card Dispatch (Offline / Simulation Mode)
    print("\n[4/4] Testing Card Dispatch Simulation...")
    dispatch_res = send_slack_card(card)
    # Without a configured Slack token the bot must report an honest skip
    # instead of a simulated success; with a token it must really post.
    assert dispatch_res.get("ok") is True or dispatch_res.get("skipped") is True, dispatch_res
    print(f"[OK] Dispatch handled honestly: {dispatch_res}")

    print("\n" + "=" * 60)
    print(">>> STEP 4 SLACK REVIEW CARD & BLOCK KIT VERIFIED! <<<")
    print("=" * 60)

if __name__ == "__main__":
    test_slack_review_card_system()
