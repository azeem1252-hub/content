"""
Tests for A5c.4, A5c.5, and A5c.6: Rendering Pipelines, Image Delivery & Performance, and Links Engine.

Covers:
A5c.4 Rendering Pipelines:
- Diagrams: Mermaid / D2 / Graphviz syntax validation, themed inline SVG (<title>, <desc>, role="img"),
  deterministic Visual QA (font size >= 12px, contrast >= 4.5:1, zero overflow), vision critique prompt, social PNG.
- Charts: Data table -> SVG/PNG with caption, source line, accessible <details> table fallback;
  chart-type rules in code (time -> line, categories -> bar, parts of whole -> donut only if <= 5).
- AI Images: Dynamic provider router in config (OpenAI gpt-image, Gemini, FLUX, Ideogram),
  brand style guide prompt builder, candidate generator & vision rubric, provenance preservation (raw file + IPTC metadata).
- Screenshots: Fixed viewport spec, Pillow annotation, automated secret/PII redaction pass.
- Open Graph / Social Cards: Templated deterministic 1200x630 card with on-brand typography (zero generative model).

A5c.5 Image Delivery and Performance:
- AVIF/WebP picture markup with srcset/sizes and explicit width/height preventing CLS.
- LCP image is never lazy-loaded (load eagerly, fetchpriority="high", <link rel="preload">); below-the-fold lazy.
- Descriptive hyphenated file names.
- Alt text linter (< 125 chars, describes function/context, alt="" for decorative, flagged for human review).
- ImageObject in Article schema.
- max-image-preview:large in robots meta directive.
- Google XML image sitemap generator.

A5c.6 Links Engine ("Where Needed"):
- Internal: 3-5 contextual links, descriptive anchors (no "click here").
- External: Primary source claim grounding (A4 evidence URL), Source Tiers 1-4.
- Outbound volume heuristic (3-8 links per 1,500 words).
- Pre/post-publishing health checks & weekly link-rot monitor with archive.org replacement.
- Rel attributes (rel="sponsored", rel="ugc", rel="nofollow"), affiliate disclosure text, competitor sales warning.
- Visible Sources/References block generator.

Studio API Endpoints:
- /api/studio/render-chart, /api/studio/render-diagram, /api/studio/generate-og-card,
  /api/studio/audit-links, /api/studio/image-delivery-audit, /api/studio/link-rot-check.
"""

import io
import pytest
from pathlib import Path
from fastapi.testclient import TestClient

from pipeline.adapters.media_renderers import (
    BrandTokens,
    calculate_contrast_ratio,
    validate_diagram_syntax,
    run_diagram_visual_qa,
    render_diagram_to_themed_svg,
    render_diagram_to_png_social_card,
    decide_chart_type,
    generate_accessible_data_table,
    render_chart_to_svg,
    DYNAMIC_IMAGE_PROVIDERS,
    BrandStyleGuide,
    build_brand_image_prompt,
    preserve_image_provenance_and_metadata,
    ImageCandidate,
    annotate_and_redact_screenshot,
    generate_social_card_og_svg,
    generate_social_card_og_png,
)
from pipeline.adapters.image_delivery import (
    sanitize_hyphenated_image_filename,
    validate_and_audit_alt_text,
    generate_responsive_picture_markup,
    generate_image_object_schema,
    generate_robots_meta_directives,
    generate_xml_image_sitemap,
    ImageDeliveryAsset,
)
from pipeline.adapters.links_engine import (
    SourceTier,
    classify_source_tier,
    validate_anchor_text,
    determine_link_attributes,
    check_is_competitor_sales_page,
    audit_outbound_link_volume,
    simulate_link_health_check,
    suggest_link_rot_replacement,
    audit_article_links,
    build_references_section,
)
from pipeline.adapters.article_model import (
    ArticleDocumentModel,
    FigureBlock,
    FigureProvenance,
    ArticleRenderers,
)
from web.app import app


client = TestClient(app)


# ===========================================================================
# 1. DIAGRAM PIPELINES & VISUAL QA (A5c.4)
# ===========================================================================

class TestDiagramPipelines:
    def test_mermaid_syntax_validation(self):
        valid_src = "graph TD\n  Client[Browser] --> Gateway[API Gateway]\n  Gateway --> Service[App Engine]"
        is_valid, err = validate_diagram_syntax(valid_src, format_type="mermaid")
        assert is_valid is True
        assert err is None

        invalid_src = "graph TD\n  Client[Browser --> Gateway"
        is_invalid, err_msg = validate_diagram_syntax(invalid_src, format_type="mermaid")
        assert is_invalid is False
        assert "brackets" in err_msg.lower() or "syntax" in err_msg.lower()

    def test_d2_syntax_validation(self):
        valid_d2 = "client: Web Client\ngateway: API Gateway\nclient -> gateway: HTTP Request"
        is_valid, err = validate_diagram_syntax(valid_d2, format_type="d2")
        assert is_valid is True
        assert err is None

        invalid_d2 = "client: Web Client { unclosed brace"
        is_invalid, err = validate_diagram_syntax(invalid_d2, format_type="d2")
        assert is_invalid is False
        assert "brace" in err.lower()

    def test_graphviz_dot_syntax_validation(self):
        valid_dot = "digraph Architecture {\n  Client -> Gateway;\n  Gateway -> Database;\n}"
        is_valid, err = validate_diagram_syntax(valid_dot, format_type="graphviz")
        assert is_valid is True
        assert err is None

        invalid_dot = "invalid_declaration {\n  A -> B;\n}"
        is_invalid, err = validate_diagram_syntax(invalid_dot, format_type="graphviz")
        assert is_invalid is False
        assert "digraph" in err.lower()

    def test_render_diagram_to_themed_svg_with_brand_tokens(self):
        src = "graph TD\n  A[Frontend] --> B[FastAPI Gateway]\n  B --> C[Postgres DB]"
        tokens = BrandTokens(
            primary_color="#2563EB",
            text_color="#0F172A",
            surface_color="#FFFFFF",
        )
        svg, qa = render_diagram_to_themed_svg(
            source=src,
            title="System Pipeline Topology",
            description="Detailed topology of microservices",
            format_type="mermaid",
            tokens=tokens,
        )

        assert "<svg" in svg
        assert 'role="img"' in svg
        assert "<title" in svg
        assert "<desc" in svg
        assert "System Pipeline Topology" in svg
        assert "Frontend" in svg
        assert "FastAPI Gateway" in svg

        # Visual QA deterministic evaluations
        assert qa.passed is True
        assert qa.min_font_size >= 12.0
        assert qa.min_font_size_passed is True
        assert qa.contrast_ratio >= 4.5
        assert qa.contrast_passed is True
        assert qa.no_overflow_passed is True
        assert qa.vision_critique_prompt is not None

    def test_visual_qa_detects_contrast_and_small_font(self):
        # Craft an SVG with poor contrast and tiny 9px font
        bad_svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400" width="100%" height="400">'
            '<rect width="800" height="400" fill="#FFFFFF"/>'
            '<text x="50" y="50" font-size="9px" fill="#FAFAFA">Tiny and unreadable</text>'
            '</svg>'
        )
        qa = run_diagram_visual_qa(bad_svg, min_required_font_size=12.0)
        assert qa.min_font_size == 9.0
        assert qa.min_font_size_passed is False
        assert any("Font size too small" in issue for issue in qa.issues)

    def test_render_diagram_to_png_social_card(self, tmp_path):
        svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 400"><rect width="800" height="400" fill="#FFF"/></svg>'
        out_png = tmp_path / "social_diagram.png"
        raw_bytes = render_diagram_to_png_social_card(svg, output_path=str(out_png))
        assert raw_bytes is not None
        assert len(raw_bytes) > 0
        assert out_png.exists()
        assert out_png.stat().st_size > 0


# ===========================================================================
# 2. CHARTS PIPELINE & ACCESSIBLE TABLES (A5c.4)
# ===========================================================================

class TestChartsPipeline:
    def test_chart_type_rules_time_series(self):
        decision = decide_chart_type(
            data_headers=["Month", "API Requests (M)"],
            data_rows=[["Jan", 12], ["Feb", 18], ["Mar", 29]],
            is_time_series=True,
        )
        assert decision.selected_chart_type == "line"
        assert "time-series" in decision.justification.lower()

    def test_chart_type_rules_categories(self):
        decision = decide_chart_type(
            data_headers=["Cloud Provider", "Latency (ms)"],
            data_rows=[["Cloudflare", 12], ["AWS", 35], ["Vercel", 28]],
        )
        assert decision.selected_chart_type == "bar"

    def test_chart_type_rules_parts_of_whole_few_slices(self):
        decision = decide_chart_type(
            data_headers=["Engine", "Market Share %"],
            data_rows=[["Google", 65], ["ChatGPT", 20], ["Perplexity", 15]],
            is_part_of_whole=True,
        )
        assert decision.selected_chart_type == "donut"

    def test_chart_type_rules_parts_of_whole_too_many_slices_fallback(self):
        decision = decide_chart_type(
            data_headers=["Segment", "Share %"],
            data_rows=[["A", 20], ["B", 15], ["C", 15], ["D", 10], ["E", 10], ["F", 10], ["G", 20]],
            is_part_of_whole=True,
        )
        assert decision.selected_chart_type == "bar"
        assert decision.warning is not None
        assert "exceeds" in decision.warning.lower() or "prohibited" in decision.warning.lower()

    def test_render_chart_to_svg_and_accessible_details_table(self):
        caption = "Vector Database P99 Latency Comparison"
        headers = ["Database", "P99 Latency (ms)"]
        rows = [["Qdrant", 8.4], ["Pinecone", 14.2], ["Milvus", 11.8], ["pgvector", 19.5]]
        source_url = "https://benchmarks.example.com/vector-db"

        svg, details_html, decision = render_chart_to_svg(
            caption=caption,
            headers=headers,
            rows=rows,
            source_url=source_url,
        )

        assert "<svg" in svg
        assert "Vector Database P99 Latency Comparison" in svg
        assert "Source: https://benchmarks.example.com/vector-db" in svg
        assert decision.selected_chart_type == "bar"

        # Verify accessible <details> table fallback
        assert "<details class=\"accessible-chart-data\">" in details_html
        assert "<caption>Vector Database P99 Latency Comparison</caption>" in details_html
        assert '<th scope="col">Database</th>' in details_html
        assert '<th scope="col">P99 Latency (ms)</th>' in details_html
        assert "<td>Qdrant</td>" in details_html
        assert "<td>8.4</td>" in details_html
        assert 'href="https://benchmarks.example.com/vector-db"' in details_html


# ===========================================================================
# 3. AI IMAGE ROUTER, BRAND PROMPTS & PROVENANCE (A5c.4)
# ===========================================================================

class TestAIImageRouterAndProvenance:
    def test_dynamic_image_providers_catalog(self):
        providers = DYNAMIC_IMAGE_PROVIDERS
        assert "cloudflare" in providers
        assert "gemini" in providers
        assert "openai" in providers
        assert "ideogram" in providers

        # Verify pricing and capabilities are dynamically configured
        assert providers["cloudflare"].cost_per_image_usd > 0
        assert providers["gemini"].supports_synthid is True
        assert providers["openai"].supports_c2pa is True

    def test_build_brand_image_prompt_forbids_text_and_artifacts(self):
        guide = BrandStyleGuide(
            brand_name="Dispatch Editorial",
            visual_theme="High-contrast studio architectural photography",
        )
        prompt = build_brand_image_prompt(
            subject="Kubernetes Pod Autoscaling",
            article_title="High-Scale Cluster Scaling Architecture",
            brand_guide=guide,
        )

        assert "Kubernetes Pod Autoscaling" in prompt
        assert "High-contrast studio architectural photography" in prompt
        assert "ABSOLUTELY NO" in prompt
        assert "text" in prompt
        assert "watermarks" in prompt
        assert "UI mockups" in prompt

    def test_preserve_image_provenance_and_metadata(self, tmp_path):
        from PIL import Image

        # Generate a small raw dummy PNG
        img = Image.new("RGB", (100, 100), color=(37, 99, 235))
        raw_buf = io.BytesIO()
        img.save(raw_buf, format="PNG")
        raw_bytes = raw_buf.getvalue()

        cand = ImageCandidate(
            candidate_id="cand-123",
            provider_id="openai",
            model_name="gpt-image-2",
            prompt="Editorial photograph of server racks",
            url="/uploads/server-racks.webp",
            has_c2pa_manifest=True,
        )

        raw_path, webp_path = preserve_image_provenance_and_metadata(
            raw_image_bytes=raw_bytes,
            candidate=cand,
            target_dir=tmp_path,
            filename_base="server-racks-benchmark",
        )

        assert Path(raw_path).exists()
        assert Path(webp_path).exists()
        assert raw_path.endswith("-raw.png")
        assert webp_path.endswith(".webp")


# ===========================================================================
# 4. SCREENSHOTS & SOCIAL CARDS (A5c.4)
# ===========================================================================

class TestScreenshotsAndSocialCards:
    def test_screenshot_annotation_and_redaction(self):
        from PIL import Image

        base_img = Image.new("RGB", (600, 400), color=(255, 255, 255))
        buf = io.BytesIO()
        base_img.save(buf, format="PNG")
        raw_bytes = buf.getvalue()

        annotations = [{"box": [50, 50, 200, 120], "label": "Step 1"}]
        redaction_boxes = [(300, 50, 450, 80)]

        annotated_bytes = annotate_and_redact_screenshot(
            image_bytes=raw_bytes,
            annotations=annotations,
            redaction_boxes=redaction_boxes,
        )
        assert len(annotated_bytes) > 0

    def test_generate_social_card_og_svg(self):
        svg = generate_social_card_og_svg(
            title="Building Stateful Agents with LangGraph in Production",
            brand_name="Dispatch Technical Bureau",
            category="Systems Architecture",
            reading_time_minutes=8,
            author_name="Sarah Connor",
        )
        assert "<svg" in svg
        assert 'width="1200" height="630"' in svg
        assert "Dispatch Technical Bureau" in svg
        assert "SYSTEMS ARCHITECTURE" in svg
        assert "8 min read" in svg
        assert "By Sarah Connor" in svg

    def test_generate_social_card_og_png(self, tmp_path):
        out_png = tmp_path / "og_card.png"
        png_bytes = generate_social_card_og_png(
            title="Enterprise Vector Search Benchmarks",
            output_path=str(out_png),
            brand_name="Editorial Dispatch",
            category="Data Study",
            reading_time_minutes=5,
        )
        assert png_bytes is not None
        assert out_png.exists()
        assert out_png.stat().st_size > 0


# ===========================================================================
# 5. IMAGE DELIVERY & PERFORMANCE (A5c.5)
# ===========================================================================

class TestImageDeliveryAndPerformance:
    def test_sanitize_hyphenated_filename(self):
        res = sanitize_hyphenated_image_filename("Kubernetes Pod Scaling Architecture v2.0", extension="webp")
        assert res == "kubernetes-pod-scaling-architecture-v2-0.webp"
        assert not res.startswith("-")

    def test_validate_and_audit_alt_text(self):
        # Compliant alt text
        good_alt = "Bar chart comparing P99 query latency between Qdrant, Pinecone, and pgvector in milliseconds."
        audit_good = validate_and_audit_alt_text(good_alt)
        assert audit_good.is_valid is True
        assert audit_good.char_count_compliant is True
        assert audit_good.needs_human_review is True  # Google 1 Oct 2026 guidance

        # Too long (> 125 chars)
        long_alt = "A very long descriptive alt text that goes on and on with way too many words explaining every single detail of the visual diagram rather than succinctly communicating its functional editorial context to the reader."
        audit_long = validate_and_audit_alt_text(long_alt)
        assert audit_long.is_valid is False
        assert any("too long" in w for w in audit_long.warnings)

        # Decorative alt=""
        audit_decor = validate_and_audit_alt_text("", is_decorative=True)
        assert audit_decor.is_valid is True
        assert audit_decor.alt_text == ""
        assert audit_decor.is_decorative is True

    def test_generate_responsive_picture_markup_lcp_eager(self):
        asset = ImageDeliveryAsset(
            src="/uploads/cluster-scaling.webp",
            alt="Cluster scaling topology",
            caption="Overview of node autoscaler.",
            width=1200,
            height=675,
            is_lcp=True,  # Likely Largest Contentful Paint figure
        )
        html_pic, preload = generate_responsive_picture_markup(asset)

        assert "<picture>" in html_pic
        assert 'type="image/avif"' in html_pic
        assert 'type="image/webp"' in html_pic
        assert 'width="1200" height="675"' in html_pic
        assert 'loading="eager"' in html_pic
        assert 'fetchpriority="high"' in html_pic
        assert "loading=\"lazy\"" not in html_pic
        assert preload is not None
        assert '<link rel="preload" as="image"' in preload
        assert 'fetchpriority="high"' in preload

    def test_generate_responsive_picture_markup_below_fold_lazy(self):
        asset = ImageDeliveryAsset(
            src="/uploads/detail-benchmark.webp",
            alt="Detail latency benchmark",
            caption="P99 distribution curves.",
            is_lcp=False,
        )
        html_pic, preload = generate_responsive_picture_markup(asset)
        assert 'loading="lazy"' in html_pic
        assert 'decoding="async"' in html_pic
        assert preload is None

    def test_image_object_schema_generation(self):
        asset = ImageDeliveryAsset(
            src="/uploads/hero.webp",
            alt="Hero Visual Asset",
            caption="Editorial Hero",
            credit="Editorial Bureau",
            width=1200,
            height=675,
            is_lcp=True,
        )
        schema = generate_image_object_schema(asset, site_url="https://editorial.example.com")
        assert schema["@type"] == "ImageObject"
        assert schema["url"] == "https://editorial.example.com/uploads/hero.webp"
        assert schema["contentUrl"] == "https://editorial.example.com/uploads/hero.webp"
        assert schema["width"] == 1200
        assert schema["height"] == 675
        assert schema["representativeOfPage"] is True
        assert schema["creator"]["name"] == "Editorial Bureau"

    def test_robots_meta_directive_has_max_image_preview_large(self):
        meta = generate_robots_meta_directives()
        assert "max-image-preview:large" in meta

    def test_generate_xml_image_sitemap(self):
        pages = [{
            "url": "/posts/rag-architecture",
            "images": [{"src": "/uploads/rag.webp", "title": "RAG Flow", "caption": "Vector retrieval diagram"}]
        }]
        xml = generate_xml_image_sitemap(pages, site_url="https://example.com")
        assert '<?xml version="1.0" encoding="UTF-8"?>' in xml
        assert '<image:image>' in xml
        assert '<image:loc>https://example.com/uploads/rag.webp</image:loc>' in xml


# ===========================================================================
# 6. EDITORIAL LINKS ENGINE & SOURCE TIERS (A5c.6)
# ===========================================================================

class TestEditorialLinksEngine:
    def test_source_tier_classification(self):
        t1_gov, _ = classify_source_tier("https://www.nist.gov/publications/ai-rmf")
        assert t1_gov == SourceTier.TIER_1_PRIMARY

        t1_edu, _ = classify_source_tier("https://cs.stanford.edu/research/paper.pdf")
        assert t1_edu == SourceTier.TIER_1_PRIMARY

        t1_docs, _ = classify_source_tier("https://docs.python.org/3/library/asyncio.html")
        assert t1_docs == SourceTier.TIER_1_PRIMARY

        t2_media, _ = classify_source_tier("https://www.reuters.com/technology/ai-advances-2026")
        assert t2_media == SourceTier.TIER_2_MEDIA

        t3_vendor, _ = classify_source_tier("https://stripe.com/blog/payments-infrastructure")
        assert t3_vendor == SourceTier.TIER_3_VENDOR

        t4_ugc, _ = classify_source_tier("https://www.reddit.com/r/MachineLearning/comments/12345")
        assert t4_ugc == SourceTier.TIER_4_UNTRUSTED

    def test_validate_anchor_text_prohibits_click_here(self):
        valid, _ = validate_anchor_text("detailed analysis of distributed consensus algorithms")
        assert valid is True

        invalid_click, msg = validate_anchor_text("click here")
        assert invalid_click is False
        assert "prohibited" in msg.lower()

        invalid_read, _ = validate_anchor_text("Read More")
        assert invalid_read is False

    def test_determine_link_attributes(self):
        # Affiliate / sponsored link
        rels_aff, disc = determine_link_attributes("https://partner.com/deal", is_affiliate=True)
        assert "sponsored" in rels_aff
        assert disc is True

        # Untrusted Tier 4 link
        rels_ugc, _ = determine_link_attributes("https://reddit.com/r/tech", source_tier=SourceTier.TIER_4_UNTRUSTED)
        assert "ugc" in rels_ugc
        assert "nofollow" in rels_ugc

    def test_outbound_volume_heuristic(self):
        # 5 links per 1500 words is optimal
        status, _ = audit_outbound_link_volume(1500, 5)
        assert status == "optimal"

        # 1 link for 2000 words is too sparse
        status_sparse, _ = audit_outbound_link_volume(2000, 1)
        assert status_sparse == "too_sparse"

    def test_link_rot_replacement_suggestion(self):
        dead_url = "https://legacy-site.example.com/benchmark-2022.html"
        rep = suggest_link_rot_replacement(dead_url, claim_text="PostgreSQL 15 query throughput benchmark")
        assert "archive.org" in rep["archive_fallback_url"]
        assert "google.com/search" in rep["suggested_search_query"]

    def test_comprehensive_article_links_audit(self):
        markdown = """
Here is an overview based on the [NIST AI Risk Management Framework](https://www.nist.gov/ai-rmf).
According to [Reuters Technology Reporting](https://www.reuters.com/tech-report), deployments grew 40%.
Check out our partner deal at [Special Hosting Offer](https://hosting.com/?aff=123).
Discussion on [Reddit Thread](https://reddit.com/r/programming/123).
Do not miss this [click here](https://random.com).
"""
        evidence_pack = ["https://www.nist.gov/ai-rmf", "https://www.reuters.com/tech-report"]
        report = audit_article_links(
            content_markdown=markdown,
            word_count=1200,
            verified_claim_sources=evidence_pack,
        )

        assert report.total_links == 5
        assert report.tier_distribution[SourceTier.TIER_1_PRIMARY.value] >= 1
        assert report.tier_distribution[SourceTier.TIER_2_MEDIA.value] >= 1
        assert report.has_affiliate_links is True
        assert report.affiliate_disclosure_required is True
        assert "Affiliate Disclosure" in report.affiliate_disclosure_text
        assert "click here" in report.banned_anchors_found

    def test_build_references_section_html_and_markdown(self):
        citations = [
            {"title": "W3C Web Standards", "url": "https://www.w3.org", "accessed_at": "2026-10-01"},
            {"title": "Reuters Technology", "url": "https://www.reuters.com", "accessed_at": "2026-10-02"},
        ]
        html_refs = build_references_section(citations, format_type="html")
        assert '<section class="editorial-references"' in html_refs
        assert "Sources &amp; References" in html_refs or "Sources & References" in html_refs
        assert 'href="https://www.w3.org"' in html_refs
        assert "(Accessed 2026-10-01)" in html_refs

        md_refs = build_references_section(citations, format_type="markdown")
        assert "## Sources & References" in md_refs
        assert "[W3C Web Standards](https://www.w3.org)" in md_refs


# ===========================================================================
# 7. STUDIO API ENDPOINTS INTEGRATION
# ===========================================================================

class TestStudioApiEndpoints:
    def test_api_render_chart(self):
        res = client.post("/api/studio/render-chart", json={
            "caption": "Memory Consumption by Worker",
            "headers": ["Worker ID", "RAM (MB)"],
            "rows": [["Worker-1", 140], ["Worker-2", 210], ["Worker-3", 185]],
            "source_url": "https://telemetry.example.com",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert "<svg" in data["svg"]
        assert "<details" in data["accessible_table_html"]
        assert data["decision"]["selected_chart_type"] == "bar"

    def test_api_render_diagram(self):
        res = client.post("/api/studio/render-diagram", json={
            "source": "graph TD\n  A[App] --> B[Cache]\n  B --> C[DB]",
            "title": "Caching Architecture",
            "format_type": "mermaid",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert "<svg" in data["svg"]
        assert data["visual_qa"]["passed"] is True
        assert data["visual_qa"]["contrast_passed"] is True

    def test_api_generate_og_card(self):
        res = client.post("/api/studio/generate-og-card", json={
            "title": "Autonomous Content Pipelines with LangGraph",
            "brand_name": "Dispatch Media",
            "category": "Deep Dive",
            "reading_time_minutes": 7,
            "author_name": "Alex Rivera",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert data["dimensions"]["width"] == 1200
        assert data["dimensions"]["height"] == 630
        assert "<svg" in data["svg"]

    def test_api_audit_links(self):
        res = client.post("/api/studio/audit-links", json={
            "markdown": "Research from [Stanford AI Lab](https://stanford.edu/ai). Read [click here](https://spam.com).",
            "word_count": 800,
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        audit = data["link_audit"]
        assert audit["total_links"] == 2
        assert "click here" in audit["banned_anchors_found"]

    def test_api_image_delivery_audit(self):
        res = client.post("/api/studio/image-delivery-audit", json={
            "images": [
                {"src": "/uploads/hero-test.webp", "alt": "Hero architecture", "caption": "System Diagram", "is_lcp": True},
                {"src": "/uploads/below-fold.webp", "alt": "Secondary chart", "caption": "Chart Diagram", "is_lcp": False},
            ],
            "article_title": "Enterprise Pipeline Architecture",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert len(data["assets"]) == 2
        assert data["assets"][0]["is_lcp"] is True
        assert len(data["lcp_preload_tags"]) == 1
        assert "fetchpriority=\"high\"" in data["lcp_preload_tags"][0]
        assert "max-image-preview:large" in data["robots_meta_directive"]

    def test_api_link_rot_check(self):
        res = client.post("/api/studio/link-rot-check", json={
            "url": "https://example.com/active-article",
            "claim_text": "Active claim text",
        })
        assert res.status_code == 200
        data = res.json()
        assert data["success"] is True
        assert data["is_healthy"] is True
