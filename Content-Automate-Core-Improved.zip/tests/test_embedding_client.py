"""Tests for Dense Embedding Client & Vector Store Bridge."""

from unittest.mock import MagicMock, patch
import pytest

from pipeline.adapters import embedding_client


def test_local_embed_text_deterministic():
    vec1 = embedding_client.local_embed_text("gaming graphics benchmark RTX 5090")
    vec2 = embedding_client.local_embed_text("gaming graphics benchmark RTX 5090")
    assert len(vec1) == embedding_client.LOCAL_DIM
    assert vec1 == vec2


def test_cosine_similarity():
    v1 = [1.0, 0.0, 0.0]
    v2 = [1.0, 0.0, 0.0]
    v3 = [0.0, 1.0, 0.0]
    assert pytest.approx(embedding_client.cosine_similarity(v1, v2), 0.001) == 1.0
    assert pytest.approx(embedding_client.cosine_similarity(v1, v3), 0.001) == 0.0


def test_resolve_provider_priority():
    # When mistral key is present, mistral is preferred
    with patch.object(embedding_client, "_mistral_key", return_value="test-key"):
        with patch.object(embedding_client, "config") as mock_cfg:
            mock_cfg.EMBEDDING_PROVIDER = "auto"
            assert embedding_client.resolve_provider() == "mistral"

    # When no keys present, local fallback is used
    with patch.object(embedding_client, "_mistral_key", return_value=""), \
         patch.object(embedding_client, "_openai_key", return_value=""), \
         patch.object(embedding_client, "_custom_base_url", return_value=""):
        with patch.object(embedding_client, "config") as mock_cfg:
            mock_cfg.EMBEDDING_PROVIDER = "auto"
            assert embedding_client.resolve_provider() == "local"


def test_embed_texts_fallback_on_failure():
    # If remote provider raises/fails, falls back cleanly to local embeddings
    with patch.object(embedding_client, "resolve_provider", return_value="mistral"), \
         patch.object(embedding_client, "_embed_mistral", return_value=None):
        results = embedding_client.embed_texts(["hello world"])
        assert len(results) == 1
        assert len(results[0]) == embedding_client.LOCAL_DIM
        assert embedding_client.last_used_provider() == "local"


def test_embed_texts_mistral_success():
    fake_vector = [0.1] * 1024
    with patch.object(embedding_client, "resolve_provider", return_value="mistral"), \
         patch.object(embedding_client, "_embed_mistral", return_value=[fake_vector]):
        results = embedding_client.embed_texts(["mistral test"])
        assert len(results) == 1
        assert len(results[0]) == 1024
        assert embedding_client.last_used_provider() == "mistral"


def test_provider_status():
    status = embedding_client.provider_status()
    assert "provider" in status
    assert "model" in status
    assert "remote" in status
    assert "dimension" in status
