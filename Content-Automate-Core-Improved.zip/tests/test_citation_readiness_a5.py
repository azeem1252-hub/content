"""
Unit and Integration Tests for Pillar A5: AI Citation Mechanics & Citation-Readiness.

Validates the 7 levers in order of evidence strength:
1. Rank in classic search first (directional 94% vendor study stat, internal inbound links).
2. Crawlable by AI retrieval bots (robots.txt, SSR HTML, retrieval vs training crawler distinction).
3. Publish extractable, original facts (tables, step lists, stats, definitions, quotes).
4. Answer-first passages & question-mapped headings (immediate direct answer, fluff penalties).
5. Entity clarity (JSON-LD schema, sameAs links, author attribution, grounding references).
6. Third-party corroboration (multi-platform citations, outreach suggestions, Google spam policy warning).
7. Freshness & dated updates (timestamps, recent temporal anchors).

Also verifies the non-predictive nature of the checklist (never a guarantee/ML score).
"""

import pytest
from pipeline.adapters.citation_readiness import (
    AI_RETRIEVAL_CRAWLERS,
    AI_TRAINING_CRAWLERS,
    CORROBORATION_PLATFORMS,
    parse_robots_txt_rules,
    evaluate_crawler_access,
    detect_original_facts,
    detect_answer_first_passages,
    evaluate_entity_clarity,
    analyze_third_party_corroboration,
    evaluate_freshness_signals,
    evaluate_citation_readiness,
)
from pipeline.adapters.citable_evaluator import evaluate_citable_score


SAMPLE_HIGH_READINESS_DRAFT = """
# Modern Vector Databases for Enterprise Search

## What is a Vector Database?
A vector database is a specialized storage engine designed to index and query high-dimensional embeddings efficiently. Unlike relational databases that match exact strings, vector databases calculate mathematical cosine or euclidean distance between dense vectors to return semantically similar records in under 25ms.

### Key Benchmark Metrics
Here are the empirical benchmarks measured across production workloads:

| Vector Engine | Query Latency (p99) | Index Build Time | Memory Footprint |
| :--- | :--- | :--- | :--- |
| Qdrant | 12ms | 4.2 hours | 16 GB |
| Milvus | 18ms | 5.1 hours | 24 GB |
| Pinecone | 22ms | Serverless | Cloud-managed |

### How to Implement Hybrid Vector Search
Follow these exact steps to deploy hybrid dense-sparse retrieval:

1. Ingest document chunks into an embedding pipeline utilizing standard 768-dimension vectors.
2. Index raw token frequencies into a sparse BM25 inverted index for keyword matching.
3. Compute reciprocal rank fusion (RRF) across both result lists with a constant of 60.
4. Return the top 20 candidate documents to the re-ranking model.

According to Dr. Elena Vance, Principal AI Systems Architect at DeepScale: "Hybrid search reduces zero-result edge cases by 43% compared to pure vector search alone."

For further architecture specifications, consult the official [GitHub](https://github.com/example/vector-benchmarks) repository and [Wikipedia's vector space model](https://en.wikipedia.org/wiki/Vector_space_model) documentation.
Reference canonical grounding definitions at /grounding/vector-db.
"""

SAMPLE_FLUFFY_DRAFT = """
# Vector Databases

## What is a Vector Database?
In today's fast-paced modern digital world, data is growing at an unprecedented rate. It is important to note that many enterprises struggle with their search infrastructure. Dive deep to explore how modern technology changes the landscape of information retrieval.

We can see many things happening in search today.
"""


def test_crawler_registry_differentiation():
    """Verify clear distinction between retrieval bots and training bots."""
    # Retrieval bots must include primary answer engine bots
    assert "Googlebot" in AI_RETRIEVAL_CRAWLERS
    assert "OAI-SearchBot" in AI_RETRIEVAL_CRAWLERS
    assert "PerplexityBot" in AI_RETRIEVAL_CRAWLERS
    assert "ChatGPT-User" in AI_RETRIEVAL_CRAWLERS
    assert "ClaudeBot" in AI_RETRIEVAL_CRAWLERS
    assert AI_RETRIEVAL_CRAWLERS["OAI-SearchBot"]["is_retrieval"] is True

    # Training bots must include training-only crawlers
    assert "GPTBot" in AI_TRAINING_CRAWLERS
    assert "Google-Extended" in AI_TRAINING_CRAWLERS
    assert "Applebot-Extended" in AI_TRAINING_CRAWLERS
    assert "CCBot" in AI_TRAINING_CRAWLERS
    assert AI_TRAINING_CRAWLERS["GPTBot"]["is_retrieval"] is False


def test_robots_txt_parsing_and_evaluation():
    """Test that blocking GPTBot (training) does NOT block OAI-SearchBot (retrieval/citations)."""
    robots_content = """
    User-agent: GPTBot
    Disallow: /

    User-agent: Google-Extended
    Disallow: /

    User-agent: OAI-SearchBot
    Allow: /

    User-agent: *
    Allow: /
    """
    eval_result = evaluate_crawler_access(
        robots_txt_content=robots_content,
        is_server_rendered=True
    )
    assert eval_result["passed"] is True
    # OAI-SearchBot is allowed
    assert eval_result["retrieval_crawlers"]["OAI-SearchBot"]["allowed"] is True
    # Googlebot is allowed by wildcard
    assert eval_result["retrieval_crawlers"]["Googlebot"]["allowed"] is True
    # GPTBot is blocked from training
    assert eval_result["training_crawlers"]["GPTBot"]["allowed"] is False
    assert eval_result["training_crawlers"]["Google-Extended"]["allowed"] is False


def test_robots_txt_blocking_searchbot_fails():
    """Blocking retrieval bots must fail the crawlability lever."""
    robots_content = """
    User-agent: OAI-SearchBot
    Disallow: /

    User-agent: *
    Allow: /
    """
    eval_result = evaluate_crawler_access(
        robots_txt_content=robots_content,
        is_server_rendered=True
    )
    assert eval_result["passed"] is False
    assert "OAI-SearchBot" in eval_result["blocked_retrieval_bots"]


def test_ssr_check_fails_on_client_rendering():
    """Non-server-rendered HTML fails the crawlability lever."""
    eval_result = evaluate_crawler_access(
        robots_txt_content="User-agent: *\nAllow: /",
        is_server_rendered=False
    )
    assert eval_result["passed"] is False


def test_detect_original_facts_rich_draft():
    """Rich draft with tables, steps, stats, definitions, and quotes passes."""
    facts = detect_original_facts(SAMPLE_HIGH_READINESS_DRAFT)
    assert facts["passed"] is True
    assert facts["has_comparison_table"] is True
    assert facts["has_step_list"] is True
    assert facts["statistics_count"] >= 2
    assert facts["quotes_count"] >= 1
    assert facts["total_fact_score"] >= 3


def test_detect_original_facts_fluffy_draft():
    """Fluffy draft with zero tables, stats, or steps fails."""
    facts = detect_original_facts(SAMPLE_FLUFFY_DRAFT)
    assert facts["passed"] is False
    assert facts["has_comparison_table"] is False
    assert facts["has_step_list"] is False
    assert facts["statistics_count"] == 0


def test_detect_answer_first_passages_clean():
    """Question heading followed by 40-160 word direct factual block passes."""
    res = detect_answer_first_passages(SAMPLE_HIGH_READINESS_DRAFT)
    assert res["passed"] is True
    assert res["question_headings_count"] >= 1
    assert res["answer_first_blocks_count"] >= 1
    assert res["preamble_penalties"] == 0


def test_detect_answer_first_passages_penalizes_fluff():
    """Fluffy intro phrases are detected and penalized."""
    res = detect_answer_first_passages(SAMPLE_FLUFFY_DRAFT)
    assert res["passed"] is False
    assert res["preamble_penalties"] >= 1
    assert res["answer_first_blocks_count"] == 0


def test_evaluate_entity_clarity():
    """Tests JSON-LD schema parsing, author validation, and sameAs links."""
    schema = {
        "@context": "https://schema.org",
        "@type": "TechArticle",
        "headline": "Modern Vector Databases",
        "author": {
            "@type": "Person",
            "name": "Alex Mercer",
            "sameAs": ["https://www.wikidata.org/wiki/Q12345", "https://linkedin.com/in/alexmercer"]
        }
    }
    result = evaluate_entity_clarity(
        draft=SAMPLE_HIGH_READINESS_DRAFT,
        schema_markup=schema,
        author="Alex Mercer"
    )
    assert result["passed"] is True
    assert result["has_named_author"] is True
    assert result["has_same_as_links"] is True
    assert "TechArticle" in result["schema_types_detected"]
    assert result["has_grounding_page_reference"] is True


def test_analyze_third_party_corroboration():
    """Verifies recognition of cited platforms, outreach hints, and Google spam policy warning."""
    result = analyze_third_party_corroboration(
        draft=SAMPLE_HIGH_READINESS_DRAFT,
        primary_topic="Vector Databases"
    )
    assert result["passed"] is True
    assert "GitHub" in result["corroboration_platforms_cited"]
    assert "Wikipedia" in result["corroboration_platforms_cited"]
    assert len(result["suggested_outreach"]) > 0
    # Strict compliance: Google Spam Policy warning must be present
    assert "Site Reputation Abuse" in result["google_spam_policy_warning"]
    assert "Never automate fake user mentions" in result["google_spam_policy_warning"]


def test_evaluate_freshness_signals():
    """Verifies date and temporal anchors."""
    result = evaluate_freshness_signals(
        draft=SAMPLE_HIGH_READINESS_DRAFT,
        published_at="2026-03-15T10:00:00Z",
        updated_at="2026-03-20T12:00:00Z"
    )
    assert result["passed"] is True
    assert result["published_at"] == "2026-03-15T10:00:00Z"


def test_full_citation_readiness_report_structure():
    """Verifies complete 7-lever report structure, non-predictive promise, and directional benchmark."""
    schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "author": {"@type": "Person", "name": "Elena Vance"}
    }
    robots_txt = "User-agent: *\nAllow: /"

    report = evaluate_citation_readiness(
        title="Modern Vector Databases for Enterprise Search",
        draft=SAMPLE_HIGH_READINESS_DRAFT,
        schema_markup=schema,
        author="Dr. Elena Vance",
        published_at="2026-03-15T10:00:00Z",
        internal_inbound_links_count=3,
        robots_txt_content=robots_txt,
        is_server_rendered=True,
    )

    # 1. Total 7 levers
    assert report["total_count"] == 7
    assert len(report["items"]) == 7
    assert report["passed_count"] >= 6
    assert report["readiness_tier"] == "High Readiness"

    # 2. Levers in order of evidence strength
    orders = [item["evidence_order"] for item in report["items"]]
    assert set(orders) == {1, 2, 3, 4, 5, 6, 7}

    # 3. Transparent non-predictive promise and disclaimer
    assert "no system can guarantee citations" in report["promise"].lower()
    assert "never an outcome predictor" in report["disclaimer"].lower()

    # 4. Classic search foundation & directional vendor stat
    context = report["classic_search_context"]
    assert "94% of Google AI Overviews" in context["vendor_study_stat"]
    assert "Directional" in context["stat_characterization"]

    # 5. Evidence Matrix
    assert "evidence_matrix" in report
    assert len(report["evidence_matrix"]) == 8
    assert "Peer-reviewed benchmark" in report["evidence_matrix"][0]["evidence_level"]

    # 6. Summaries
    assert report["detected_facts_summary"]["tables"] >= 1
    assert report["crawler_policy_summary"]["retrieval_allowed"] is True
    assert report["crawler_policy_summary"]["server_rendered"] is True


def test_evidence_ranked_matrix_table():
    """Verify honest confidence matrix and implementation mappings from specification."""
    from pipeline.adapters.citation_readiness import EVIDENCE_RANKED_LEVERS
    assert len(EVIDENCE_RANKED_LEVERS) == 8
    # Lever 1: Evidence-rich content
    assert EVIDENCE_RANKED_LEVERS[0]["rank"] == 1
    assert "Peer-reviewed benchmark (KDD 2024)" in EVIDENCE_RANKED_LEVERS[0]["evidence_level"]
    assert "A3.1, test in A12" in EVIDENCE_RANKED_LEVERS[0]["implementation"]

    # Lever 2: Classic ranking
    assert "Helps, but weaker than before" in EVIDENCE_RANKED_LEVERS[1]["evidence_level"]
    assert "A1-A5" in EVIDENCE_RANKED_LEVERS[1]["implementation"]

    # Lever 3: Crawl access
    assert "Practitioner consensus, mechanically necessary" in EVIDENCE_RANKED_LEVERS[2]["evidence_level"]
    assert "A6.2" in EVIDENCE_RANKED_LEVERS[2]["implementation"]

    # Lever 4: Third-party presence
    assert "Multiple large citation studies" in EVIDENCE_RANKED_LEVERS[3]["evidence_level"]
    assert "A9" in EVIDENCE_RANKED_LEVERS[3]["implementation"]

    # Lever 5: Entity clarity
    assert "Plausible, low direct evidence" in EVIDENCE_RANKED_LEVERS[4]["evidence_level"]
    assert "A5" in EVIDENCE_RANKED_LEVERS[4]["implementation"]

    # Lever 6: Original data
    assert "Plausible; also earns links and mentions" in EVIDENCE_RANKED_LEVERS[5]["evidence_level"]
    assert "A3.2, A9" in EVIDENCE_RANKED_LEVERS[5]["implementation"]

    # Lever 7: Freshness
    assert "Plausible" in EVIDENCE_RANKED_LEVERS[6]["evidence_level"]
    assert "A8 refresh loop" in EVIDENCE_RANKED_LEVERS[6]["implementation"]

    # Lever 8: Volatility / half-life
    assert "Volatility studies" in EVIDENCE_RANKED_LEVERS[7]["evidence_level"]
    assert "A7" in EVIDENCE_RANKED_LEVERS[7]["implementation"]


def test_backward_compatibility_with_citable_evaluator():
    """Ensures evaluate_citable_score continues to work for callers while attaching the 7-lever report."""
    legacy_res = evaluate_citable_score(
        title="Modern Vector Databases for Enterprise Search",
        draft=SAMPLE_HIGH_READINESS_DRAFT,
        keywords=["vector databases", "enterprise search"],
        has_citations=True,
        has_schema=True,
    )
    # Core fields
    assert "citable_score" in legacy_res
    assert "dimension_scores" in legacy_res
    assert "diagnostic_details" in legacy_res
    # A5 extended report
    assert "citation_readiness" in legacy_res
    report = legacy_res["citation_readiness"]
    assert report["total_count"] == 7
    assert report["readiness_tier"] in ["High Readiness", "Moderate Readiness"]
