"""Regression tests for studio-origin and remote-auth controls. Runtime depends on web extras."""
from fastapi.testclient import TestClient
from web.app import app, _loopback_origin


def test_opaque_and_suffix_localhost_origins_are_not_trusted(monkeypatch):
    monkeypatch.delenv("STUDIO_ALLOWED_ORIGINS", raising=False)
    assert _loopback_origin("http://localhost:5173")
    assert _loopback_origin("http://127.0.0.1:8000")
    assert not _loopback_origin("null")
    assert not _loopback_origin("http://attacker.localhost:5173")
    assert not _loopback_origin("https://attacker.example")


def test_foreign_preflight_is_rejected(monkeypatch):
    monkeypatch.delenv("ALLOW_REMOTE_ACCESS", raising=False)
    res=TestClient(app).options("/dashboard",headers={"Origin":"https://attacker.example","Access-Control-Request-Method":"POST","Access-Control-Request-Headers":"content-type"})
    assert res.status_code == 403
    assert "Access-Control-Allow-Origin" not in res.headers


def test_remote_mode_fails_closed_without_credentials(monkeypatch):
    monkeypatch.setenv("ALLOW_REMOTE_ACCESS","true")
    monkeypatch.delenv("STUDIO_ACCESS_USERNAME",raising=False)
    monkeypatch.delenv("STUDIO_ACCESS_PASSWORD",raising=False)
    res=TestClient(app).get("/dashboard")
    assert res.status_code == 503
