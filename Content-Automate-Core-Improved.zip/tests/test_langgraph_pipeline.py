import os
import sys

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from langgraph.graph import StateGraph, START, END
import pytest

from pipeline.state import ContentState
from pipeline.nodes.outline_node import outline_node
from pipeline.nodes.draft_node import draft_node
from pipeline.nodes.audit_node import audit_node


@pytest.mark.live
def test_langgraph_subgraph():
    print("=" * 60)
    print("Testing LangGraph Content Pipeline (Step 2 Subgraph)")
    print("=" * 60)

    # 1. Build the StateGraph
    builder = StateGraph(ContentState)

    builder.add_node("outline", outline_node)
    builder.add_node("draft", draft_node)
    builder.add_node("audit", audit_node)

    # Edge wiring: START -> outline -> draft -> audit -> END
    builder.add_edge(START, "outline")
    builder.add_edge("outline", "draft")
    builder.add_edge("draft", "audit")
    builder.add_edge("audit", END)

    # Compile graph
    graph = builder.compile()
    print("[OK] LangGraph StateGraph compiled successfully!")

    # 2. Invoke the graph with initial input state
    initial_state = {
        "topic": "Autonomous AI Publishing with LangGraph",
        "keywords": ["LangGraph", "Groq", "Mistral", "Autonomous Agents"],
        "target_audience": "Software developers and technical leaders",
        "revision_count": 0,
        "review_status": "pending",
        "thread_id": "test-run-101",
        "status": "queued"
    }

    print("\nExecuting LangGraph workflow...")
    final_state = graph.invoke(initial_state)

    # 3. Assertions
    assert final_state["status"] == "audited"
    assert final_state["outline"] is not None
    assert final_state["draft"] is not None
    assert final_state["title"] is not None
    assert final_state["slug"] is not None
    assert final_state["seo_score"] >= 70

    print("\n[OK] LangGraph Execution Completed Successfully!")
    print(f"  Title:       {final_state['title']}")
    print(f"  Slug:        {final_state['slug']}")
    print(f"  SEO Score:   {final_state['seo_score']}/100")
    print(f"  Word Count:  {final_state['word_count']} words (~{final_state['read_time']} min read)")
    print(f"  Tags:        {', '.join(final_state['tags'])}")
    print(f"  Meta Title:  {final_state['meta_title']}")
    
    print("\n" + "=" * 60)
    print(">>> LANGGRAPH PIPELINE VERIFICATION PASSED! <<<")
    print("=" * 60)

if __name__ == "__main__":
    test_langgraph_subgraph()
