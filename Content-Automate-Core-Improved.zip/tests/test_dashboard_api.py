import os
import sys
import time
import json

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from fastapi.testclient import TestClient
from web.app import app
from storage.db import init_db, get_website_by_id, get_schedule_by_id

import pytest


@pytest.mark.live
def test_content_pipeline_agent_nextjs_suite():
    """
    Comprehensive test suite for the Next.js Content Pipeline Agent:
    1. System diagnostics & Health APIs
    2. HTML Dashboard Views (Overview, Next.js Websites, Schedules, Studio, Review Inbox)
    3. Next.js Website CRUD & Connection Testing
    4. Next.js API Route Snippet Generator
    5. Automated Cadence Schedules & 'Escalate Now'
    6. Agent Operations KPIs & System Telemetry
    7. End-to-End Autonomous Pipeline Execution with Next.js Target
    8. Slack Human Review Gate Revision Loop & Approval
    9. Slack Interactive Webhook Payload Handling
    """
    print("\n" + "=" * 76)
    print("  TESTING CONTENT PIPELINE AGENT - NEXT.JS PLATFORM & OPS DASHBOARD")
    print("=" * 76)

    init_db()

    with TestClient(app) as client:
        # 1. Health check
        res = client.get("/health")
        assert res.status_code == 200
        assert res.json()["status"] == "healthy"
        print("[OK] Health check passed")

        # 2. System status diagnostics
        res = client.get("/api/agent/system-status")
        assert res.status_code == 200
        data = res.json()
        assert "groq" in data
        assert "database" in data
        print("[OK] System diagnostics API operational")

        # 3. Autonomous Topic Discovery API
        from unittest.mock import patch
        def _topic_llm_mock(prompt, system_instruction=None, temperature=0.7):
            return json.dumps({
                "topic": "Autonomous AI Micro-Agents on Next.js Edge Runtime",
                "reasoning": "High search volume and trending developer demand in 2026",
                "keywords": ["Next.js Edge", "AI Micro-Agents", "Serverless"],
                "target_audience": "Principal Cloud Architects"
            })
        with patch("pipeline.topic_researcher.call_llm", side_effect=_topic_llm_mock):
            res = client.get("/api/agent/discover-topic")
            assert res.status_code == 200
            discovery = res.json()
            assert "topic" in discovery
            assert "keywords" in discovery
            assert "target_audience" in discovery
            print(f"[OK] Autonomous Topic Discovery verified: '{discovery['topic']}'")

        # 4. HTML Dashboard View
        res = client.get("/dashboard")
        assert res.status_code == 200
        html = res.text
        assert "ContentOps Studio" in html
        assert "Next.js Agent Platform" in html
        assert "Next.js Websites" in html
        assert "Automated Schedules" in html
        assert "Pipeline Studio" in html
        assert "Review Inbox (Slack)" in html
        print("[OK] Next.js Operations Dashboard HTML interface rendered with all sections")

        # 5. Dashboard KPIs API
        res = client.get("/api/agent/kpis")
        assert res.status_code == 200
        kpis = res.json()
        assert "connected_websites" in kpis
        assert "active_schedules" in kpis
        assert "published_count" in kpis
        assert "avg_seo_score" in kpis
        print(f"[OK] KPI Telemetry active: {kpis['connected_websites']} Next.js sites, {kpis['active_schedules']} active schedules")

        # 6. Next.js Website API Route Snippet Generator & Storage Persistence
        res = client.get("/api/websites/nextjs-snippet")
        assert res.status_code == 200
        snippet_data = res.json()
        assert "snippet" in snippet_data
        assert "lib_posts" in snippet_data
        assert "agent_prompt" in snippet_data
        assert "curl_command" in snippet_data
        snippet = snippet_data["snippet"]
        assert "app/api/posts/route.ts" in snippet
        assert "NextResponse" in snippet
        assert "AGENT_SECRET_TOKEN" in snippet
        assert "UPSTASH_REDIS_REST_URL" in snippet
        assert "GITHUB_TOKEN" in snippet
        assert "getPostBySlugAsync" in snippet_data["lib_posts"]
        assert "app/api/posts/route.ts" in snippet_data["agent_prompt"]
        print("[OK] Next.js route.ts drop-in code snippet & AI prompt generated successfully")

        # 6b. Storage Connection Test API
        storage_res = client.post("/api/websites/test-storage", json={
            "engine": "upstash",
            "upstash_url": "https://fake-endpoint.upstash.io",
            "upstash_token": "fake_token_123"
        })
        assert storage_res.status_code == 200
        assert "success" in storage_res.json()
        print("[OK] Cloud Storage connectivity test API operational")

        # 7. Next.js Website CRUD
        res = client.get("/api/websites")
        assert res.status_code == 200
        websites = res.json()
        if len(websites) == 0:
            client.post("/api/websites", json={
                "name": "The Dispatch (Next.js Production)",
                "url": "http://127.0.0.1:8000/api/posts",
                "is_default": True
            })
            websites = client.get("/api/websites").json()
        assert len(websites) >= 1
        default_site = websites[0]
        print(f"[OK] Found {len(websites)} registered website(s): Default '{default_site['name']}'")

        # Register a second Next.js production website
        new_site_payload = {
            "name": "Cloud Engineering Blog (Next.js)",
            "url": "https://tech-dispatch.vercel.app/api/posts",
            "type": "nextjs",
            "secret_token": "nxt_sec_vercel_production_key_4492",
            "slack_channel_id": "#editorial-reviews",
            "slack_webhook_url": "https://hooks.slack.com/services/T00/B00/mockhook",
            "slack_enabled": True
        }
        res = client.post("/api/websites", json=new_site_payload)
        assert res.status_code == 200
        created_site = res.json()
        site_id = created_site["id"]
        assert created_site["name"] == new_site_payload["name"]
        print(f"[OK] Registered new Next.js website: '{created_site['name']}' (ID: {site_id})")

        # Test endpoint ping (simulated since target is remote/mock)
        res = client.post(f"/api/websites/{site_id}/test")
        assert res.status_code == 200
        test_res = res.json()
        assert "status" in test_res
        assert "latency_ms" in test_res
        print(f"[OK] Connection test executed for site {site_id} (Status: {test_res.get('status')})")

        # 8. Automated Schedules API
        res = client.get("/api/schedules")
        assert res.status_code == 200
        schedules = res.json()
        assert isinstance(schedules, list)
        print(f"[OK] Found {len(schedules)} active automated schedule(s)")

        # Create a new scheduled publishing cadence
        new_sched_payload = {
            "name": "Weekly Cloud Architecture Briefing",
            "website_id": site_id,
            "topic_prompt": "State of Serverless & Edge AI Runtime in 2026",
            "keywords": ["Serverless", "Edge AI", "Vercel", "Next.js"],
            "target_audience": "Principal Cloud Architects",
            "frequency": "weekly",
            "interval_hours": 168,
            "slack_review_required": True
        }
        res = client.post("/api/schedules", json=new_sched_payload)
        assert res.status_code == 200
        created_sched = res.json()
        sched_id = created_sched["id"]
        assert created_sched["frequency"] == "weekly"
        print(f"[OK] Created automated publishing cadence '{created_sched['name']}' (ID: {sched_id})")

        # Toggle schedule pause/active
        res = client.post(f"/api/schedules/{sched_id}/toggle")
        assert res.status_code == 200
        assert res.json()["status"] == "paused"
        res = client.post(f"/api/schedules/{sched_id}/toggle")
        assert res.status_code == 200
        assert res.json()["status"] == "active"
        print("[OK] Schedule active/pause toggle confirmed")

        # 9. Test 'Escalate Now' on Schedule
        res = client.post(f"/api/schedules/{sched_id}/escalate")
        assert res.status_code == 200
        escalate_res = res.json()
        assert escalate_res["status"] == "escalated"
        escalated_thread_id = escalate_res["thread_id"]
        assert escalated_thread_id is not None
        print(f"[OK] 'Escalate Now' triggered autonomous pipeline run: {escalated_thread_id}")

        # 10. Autonomous Pipeline Run with Human Review Gate (Pure LangGraph State Graph)
        def _test_llm_mock(prompt, system_instruction=None, temperature=0.7):
            p = prompt.lower()
            if "high_ranking_keywords" in p or "search intelligence" in p:
                return json.dumps({
                    "high_ranking_keywords": ["Next.js", "Server Actions", "LangGraph", "Groq"],
                    "target_audience": "Full-Stack AI Engineers",
                    "audience_pain_points": ["State recovery", "Review checkpoints"],
                    "competitor_gaps": "Deterministic graph execution"
                })
            if "blog post outline" in p:
                return "# Next.js App Router in 2026\n## 1. State Machines\n## 2. Server Actions"
            if "seo metadata" in p or "slug" in p:
                return json.dumps({
                    "slug": "nextjs-app-router-ai-integration-2026",
                    "meta_title": "Next.js App Router & AI Agents in 2026",
                    "meta_description": "Architecting autonomous content pipelines with Next.js App Router.",
                    "tags": ["Next.js", "AI", "LangGraph"],
                    "seo_score": 96,
                    "audit_notes": "Optimal keyword density and H1/H2 structure."
                })
            if "visual prompt" in p:
                return "Minimalist editorial tech art with high contrast"
            if "repurpose" in p:
                return json.dumps({
                    "linkedin_post": "🚀 New breakdown on Next.js + AI Agents in 2026! Check it out.",
                    "twitter_thread": ["1/3 Next.js + AI pipelines in 2026 🧵", "2/3 State graphs matter", "3/3 Read the dispatch!"]
                })
            return "# Next.js App Router & AI Agent Integration in 2026\n\nAutonomous agentic publishing is transforming modern web applications."

        from unittest.mock import patch
        mock_img_res = {
            "hero_image_path": "static/uploads/mock.png",
            "hero_image_url": "/static/uploads/mock.png",
            "hero_image_full_url": "http://127.0.0.1:8000/static/uploads/mock.png",
            "public_image_url": "http://127.0.0.1:8000/static/uploads/mock.png",
            "image_prompt": "Mock prompt",
            "status": "image_generated"
        }
        with patch("pipeline.nodes.outline_node.call_llm", side_effect=_test_llm_mock), \
             patch("pipeline.nodes.draft_node.call_llm", side_effect=_test_llm_mock), \
             patch("pipeline.nodes.audit_node.call_llm", side_effect=_test_llm_mock), \
             patch("pipeline.nodes.image_node.generate_hero_image_for_article", return_value=mock_img_res), \
             patch("pipeline.adapters.codex_image.call_llm", side_effect=_test_llm_mock), \
             patch("pipeline.nodes.repurpose_node.call_llm", side_effect=_test_llm_mock):

            run_payload = {
                "topic": "Next.js App Router & AI Agent Integration in 2026",
                "keywords": ["Next.js", "Server Actions", "LangGraph", "Groq"],
                "target_audience": "Full-Stack AI Engineers",
                "website_id": site_id,
                "auto_approve": False
            }
            res = client.post("/api/agent/run", json=run_payload)
            assert res.status_code == 200
            run_data = res.json()
            thread_id = run_data["thread_id"]
            assert thread_id.startswith("dispatch-")
            print(f"[OK] Direct Studio pipeline run initiated: {thread_id} for Next.js site {site_id}")

            # Poll until paused at Human/Slack Review Gate
            print("  Waiting for real LangGraph pipeline to reach Review Gate...")
            paused = False
            for _ in range(40):
                res = client.get(f"/api/agent/runs/{thread_id}")
                if res.status_code == 200:
                    run_state = res.json()
                    if run_state.get("status") == "review_pending":
                        paused = True
                        break
                time.sleep(0.5)

            assert paused, "Pipeline did not pause at review_gate!"
            assert run_state.get("title") is not None
            assert run_state.get("seo_score") is not None
            assert run_state.get("website_id") == site_id
            print(f"[OK] Pipeline paused at Review Gate:")
            print(f"     Title:        {run_state['title']}")
            print(f"     SEO Score:    {run_state['seo_score']}/100")
            print(f"     Target Site:  {run_state['website_id']}")

            # Test Editorial Revisions Loop
            print("  Simulating Slack / Dashboard editor requesting revisions...")
            review_payload = {
                "action": "request_changes",
                "feedback": "Include an enterprise production code snippet showing Next.js route handlers."
            }
            res = client.post(f"/api/agent/runs/{thread_id}/review", json=review_payload)
            assert res.status_code == 200
            rev_data = res.json()
            assert rev_data["status"] == "changes_requested"
            print(f"[OK] Revision loop handled successfully (Revision #{rev_data['revision_count']})")

            time.sleep(1.0)

            # Single-Click Approve & Publish
            print("  Simulating Slack / Dashboard approval & publish dispatch...")
            res = client.post(f"/api/agent/runs/{thread_id}/review", json={"action": "approved"})
            assert res.status_code == 200
            assert res.json()["status"] == "approved"

            # Wait for publish completion
            time.sleep(2.0)
            res = client.get(f"/api/agent/runs/{thread_id}")
            final_run = res.json()
            assert final_run.get("status") == "completed"
            assert final_run.get("published_url") is not None
            print(f"[OK] Post published! Destination: {final_run['published_url']}")

        # 11. Test Slack Interactive Webhook Handling
        slack_payload = {
            "payload": json.dumps({
                "type": "block_actions",
                "user": {"id": "U12345", "username": "azeem_editor"},
                "actions": [
                    {
                        "action_id": "approve_publish",
                        "value": thread_id
                    }
                ]
            })
        }
        res = client.post("/api/slack/interactive", data=slack_payload)
        assert res.status_code == 200
        slack_reply = res.json()
        assert "response_type" in slack_reply
        assert "approv" in slack_reply["text"].lower()
        print("[OK] Slack interactive Block Kit button callback handled successfully")

    print("\n" + "=" * 76)
    print(">>> ALL NEXT.JS CONTENT PIPELINE AGENT SUITE TESTS PASSED! <<<")
    print("=" * 76 + "\n")


if __name__ == "__main__":
    test_content_pipeline_agent_nextjs_suite()
