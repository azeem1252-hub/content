import os
import sys
from pathlib import Path

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from pipeline.adapters.codex_image import synthesize_visual_prompt, generate_and_save_image
from pipeline.nodes.image_node import generate_hero_image_for_article, image_node

import pytest


@pytest.mark.live
def test_codex_image_engine():
    print("=" * 60)
    print("Testing Step 3: Codex Image Generation & Fallback Engine")
    print("=" * 60)

    title = "Autonomous AI Agents in 2026: Self-Publishing Architecture"
    topic = "Autonomous AI Agents"
    slug = "test-autonomous-agents-2026"

    # 1. Test Visual Prompt Synthesis
    print("\n[1/3] Testing Visual Prompt Synthesis...")
    prompt = synthesize_visual_prompt(title=title, topic=topic, draft_excerpt="StateGraph orchestration and human review gates in Slack.")
    assert prompt is not None
    assert len(prompt) > 20
    print(f"[OK] Visual prompt synthesized: '{prompt}'\n")

    # 2. Test Asset Generation & Saving to Disk
    print("[2/3] Testing Image Generation & Local Asset Storage...")
    result = generate_and_save_image(prompt=prompt, slug=slug)
    assert result["hero_image_path"] is not None
    assert result["hero_image_url"].startswith("/static/uploads/")
    
    saved_file = Path(result["hero_image_path"])
    assert saved_file.exists(), f"Image file not found at: {saved_file}"
    assert saved_file.stat().st_size > 0, "Image file is 0 bytes!"
    print(f"[OK] Hero image saved successfully to disk: {saved_file} ({saved_file.stat().st_size} bytes)")
    print(f"     Relative URL: {result['hero_image_url']}")

    # 3. Test LangGraph Node Adapter
    print("\n[3/3] Testing LangGraph image_node Adapter...")
    sample_state = {
        "title": title,
        "topic": topic,
        "slug": slug,
        "draft": "Sample draft content for image node test",
        "thread_id": "test-thread-img",
        "status": "drafted"
    }
    node_res = image_node(sample_state)
    assert node_res["status"] == "image_generated"
    assert node_res["hero_image_url"] is not None
    print(f"[OK] image_node execution verified! URL: {node_res['hero_image_url']}")

    print("\n" + "=" * 60)
    print(">>> STEP 3 CODEX IMAGE GENERATION VERIFIED SUCCESSFULLY! <<<")
    print("=" * 60)

if __name__ == "__main__":
    test_codex_image_engine()
