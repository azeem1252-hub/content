"""
Unit Tests for Pillar A3: Article Writing
- A3.1 Generation Design (Section-by-section drafting, Structured Pydantic Draft, Brand Voice from Data, Jinja2 Prompts, Model Router)
- A3.2 Originality: Evidence Pack Gating (Scaled Content Policy)
- A3.3 Self-Critique Loop (Max 2 iterations, brief coverage, repetition, vague claims, tone)
"""

import os
import unittest
from unittest.mock import patch, MagicMock

from pipeline.adapters.structured_draft import StructuredDraft, DraftSection, ClaimCitation
from pipeline.adapters.brand_voice import (
    analyze_articles_for_style,
    extract_candidate_exemplars,
    get_active_style_profile,
    save_style_profile,
    get_style_profile,
    approve_style_profile,
)
from pipeline.adapters.prompt_manager import render_prompt
from pipeline.adapters.model_router import resolve_model_route, ROLE_DRAFTING, ROLE_CRITIC
from pipeline.adapters.evidence_pack import (
    has_minimum_evidence,
    place_evidence_in_brief,
    save_evidence_item,
    get_evidence_items_by_website,
)
from pipeline.adapters.self_critic import (
    evaluate_draft_critique,
    execute_critique_and_revision_loop,
    DraftCritique,
)
from pipeline.adapters.section_drafter import generate_structured_article_draft


class TestPillarA3ArticleWriting(unittest.TestCase):

    def test_structured_draft_pydantic_tree_and_markdown(self):
        """Validates that StructuredDraft correctly structures sections and renders clean Markdown."""
        section1 = DraftSection(
            heading="Deterministic Simulation Principles",
            level=2,
            direct_answer="Sub-tick deterministic simulation decouples frame pacing from game physics state.",
            markdown_content=(
                "Sub-tick deterministic simulation decouples frame pacing from game physics state. "
                "By maintaining an immutable ring buffer of input states, rollback netcode reconstructs "
                "authoritative server frames with zero desynchronization."
            ),
            claims=[
                ClaimCitation(
                    claim_text="Sub-tick physics decouples render tick from server tick",
                    source_url="https://example.com/physics",
                    anchor_text="Physics Whitepaper",
                    citation_type="first_party",
                )
            ],
            citations=[{"url": "https://example.com/physics", "title": "Physics Whitepaper"}],
            key_entities_covered=["Ring Buffer", "Rollback Netcode"],
            evidence_used=["Telemetry Benchmark 2026"],
        )

        draft = StructuredDraft(
            title="Building High-Performance Netcode in Rust",
            slug="building-high-performance-netcode-in-rust",
            meta_description="A technical teardown of deterministic sub-tick networking in Rust.",
            sections=[section1],
        )
        draft.recompute_metrics()

        self.assertGreater(draft.total_word_count, 10)
        self.assertIn("Telemetry Benchmark 2026", draft.evidence_items_used)

        md = draft.to_markdown()
        self.assertTrue(md.startswith("# Building High-Performance Netcode in Rust"))
        self.assertIn("## Deterministic Simulation Principles", md)
        self.assertIn("## References", md)
        self.assertIn("[Physics Whitepaper](https://example.com/physics)", md)

    def test_brand_voice_analysis_and_style_profile(self):
        """Tests empirical brand voice extraction from sample articles."""
        articles = [
            {
                "title": "Systems Engineering 101",
                "content": (
                    "## Architectural Foundations\n"
                    "We built a robust deterministic queue. You will notice zero latency spikes. "
                    "The system handles fifty thousand operations per second without garbage collection pauses. "
                    "| Metric | Result |\n| Throughput | 50k ops/sec |\n"
                )
            }
        ]
        metrics = analyze_articles_for_style(articles)
        self.assertIn("sentence_length_avg", metrics)
        self.assertIn("person_distribution", metrics)
        self.assertIn("banned_phrases", metrics)
        self.assertTrue(metrics["formatting_habits"]["uses_tables"])

    def test_style_profile_storage_and_human_approval_gate(self):
        """Verifies style profile persistence, versioning, and approval gate."""
        wid = "test_site_a3"
        saved = save_style_profile(
            website_id=wid,
            sentence_length_avg=14.5,
            sentence_length_median=14.0,
            person_distribution={"first_person": 0.2, "second_person": 0.4, "third_person": 0.4},
            banned_phrases=["delve", "tapestry"],
            preferred_phrases=["zero-copy", "sub-tick"],
            formatting_habits={"uses_tables": True},
            few_shot_exemplars=[],
            status="pending_review",
        )
        self.assertEqual(saved.get("status"), "pending_review")

        # Human approves
        approved = approve_style_profile(wid)
        self.assertTrue(approved)

        active = get_style_profile(wid)
        self.assertEqual(active.get("status"), "approved")

    def test_jinja2_prompt_manager_rendering(self):
        """Tests rendering of section_draft and self_critic templates with Jinja2."""
        context = {
            "section_index": 1,
            "brief_slice": {
                "heading": "Concurrency Models",
                "level": 2,
                "target_word_count": 250,
                "answer_first_guidance": "State the lock-free queue advantages directly.",
                "required_entities": ["CAS", "RingBuffer"],
                "questions_to_answer": ["Why avoid mutexes in hot loops?"],
                "claims_needing_sources": [],
                "internal_links": [],
            },
            "evidence_slice": [
                {
                    "title": "L1 Cache Benchmark",
                    "evidence_type": "first_party_data",
                    "content": "CAS operations average 4.2ns vs 42ns for OS mutex acquisition.",
                    "source_url": "https://example.com/benchmarks",
                    "author_or_expert": "Perf Team",
                }
            ],
            "style_profile": {
                "version": 1,
                "sentence_length_avg": 15.0,
                "sentence_length_median": 14.0,
                "person_distribution": {"second_person": 0.5},
                "banned_phrases": ["delve", "pivotal"],
                "preferred_phrases": ["lock-free"],
                "formatting_habits": {"uses_tables": True, "uses_code_blocks": True},
                "few_shot_exemplars": [],
            },
            "prior_sections_summary": "",
            "topic": "Lock-Free Rust",
        }
        rendered, ver = render_prompt("section_draft", context, version="v1.0.0")
        self.assertEqual(ver, "v1.0.0")
        self.assertIn("Concurrency Models", rendered)
        self.assertIn("L1 Cache Benchmark", rendered)
        self.assertIn("CAS operations average 4.2ns", rendered)

    def test_model_router_resolves_different_models(self):
        """Tests config-driven model router for drafting vs critique."""
        draft_route = resolve_model_route(ROLE_DRAFTING)
        critic_route = resolve_model_route(ROLE_CRITIC)

        self.assertEqual(draft_route["role"], ROLE_DRAFTING)
        self.assertEqual(critic_route["role"], ROLE_CRITIC)
        self.assertTrue(bool(draft_route["model"]))
        self.assertTrue(bool(critic_route["model"]))

    def test_evidence_pack_gating_and_placement(self):
        """Tests Google Scaled Content Policy gating and evidence-to-brief section mapping."""
        # Gating check
        self.assertFalse(has_minimum_evidence([]))
        self.assertFalse(has_minimum_evidence({}))
        self.assertTrue(has_minimum_evidence([{"title": "Test Proof", "content": "Benchmark"}]))

        # Evidence saving and retrieval
        item = save_evidence_item(
            website_id="test_site_a3",
            title="Telemetry 2026",
            evidence_type="first_party_data",
            content="Real-world production measurements.",
            source_url="https://example.com",
            author_or_expert="Lead Architect",
        )
        self.assertEqual(item["title"], "Telemetry 2026")

        items = get_evidence_items_by_website("test_site_a3")
        self.assertGreaterEqual(len(items), 1)

        # Placement in brief
        sections = [
            {"heading": "Introduction & Overview", "questions_to_answer": ["What is telemetry?"]},
            {"heading": "Benchmark Analysis", "questions_to_answer": ["What are the numbers?"]},
        ]
        placement = place_evidence_in_brief(sections, items)
        self.assertIn("Benchmark Analysis", placement)
        self.assertIn("Introduction & Overview", placement)

    @patch("pipeline.adapters.self_critic.routed_call_llm")
    def test_self_critique_evaluator(self, mock_llm):
        """Tests self-critique loop detection of banned words and score calculation."""
        mock_llm.side_effect = RuntimeError("Offline unit test fallback")
        sec = DraftSection(
            heading="Section 1",
            level=2,
            direct_answer="Direct answer here.",
            markdown_content="We delve into this complex tapestry.",
        )
        draft = StructuredDraft(title="Test Title", slug="test-slug", sections=[sec])
        style = {"version": 1, "banned_phrases": ["delve", "tapestry"]}
        brief = {"primary_keyword": "test", "target_reader": "Engineers"}

        critique = evaluate_draft_critique(draft, brief, style)
        self.assertIn("delve", critique.banned_words_found)
        self.assertIn("tapestry", critique.banned_words_found)
        self.assertFalse(critique.passed)


if __name__ == "__main__":
    unittest.main()
