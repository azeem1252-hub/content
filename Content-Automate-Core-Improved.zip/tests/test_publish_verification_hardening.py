"""Regression checks for real publish confirmation and GitHub review flows."""
from pipeline.adapters import cms_publishers
from pipeline.adapters.cms_publishers import (
    CMSArticlePayload, CMSMetadata, CMSMediaAsset, NextJsAdapter, WordPressAdapter,
)


def payload(hero_image=None):
    return CMSArticlePayload(
        title="A Test Article", slug="a-test-article", html_content="<p>Text</p>",
        markdown_content="Text", excerpt="Summary",
        metadata=CMSMetadata(title="A Test Article", meta_title="A Test Article",
            meta_description="Summary", slug="a-test-article"),
        hero_image=hero_image,
    )


def disable_test_mode(monkeypatch):
    monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
    monkeypatch.delenv("TESTING", raising=False)


def test_post_publish_does_not_fake_success_for_testish_url(monkeypatch):
    disable_test_mode(monkeypatch)
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def get(self, *args, **kwargs): raise RuntimeError("network unavailable")
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter = WordPressAdapter({"id":"contest-site", "url":"https://contest-blog.testimonials.co", "secret_token":"live-token"})
    checks = adapter.post_publish_check("https://contest-blog.testimonials.co/posts/a-test-article", "A Test Article")
    assert checks["http_status_ok"] is False
    assert checks["status_code"] == 0
    assert checks["error"] == "RuntimeError"


def test_wordpress_publish_requires_confirmed_remote_response(monkeypatch):
    disable_test_mode(monkeypatch)
    class Response:
        status_code = 401
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def post(self, *args, **kwargs): return Response()
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter = WordPressAdapter({"id":"live-site", "url":"https://cms.example.test", "secret_token":"live-token"})
    result = adapter.publish_or_schedule("12", payload())
    assert result.success is False and result.status == "failed"
    assert "HTTP 401" in result.error


def test_wordpress_draft_and_publish_fail_without_credentials(monkeypatch):
    disable_test_mode(monkeypatch)
    adapter = WordPressAdapter({"id":"no-creds", "url":"https://cms.example.test"})
    staged = adapter.stage_draft(payload())
    published = adapter.publish_or_schedule("12", payload())
    assert staged.success is False and staged.status == "failed"
    assert published.success is False and published.status == "failed"


def test_mock_detection_does_not_use_url_or_site_id_substrings(monkeypatch):
    disable_test_mode(monkeypatch)
    for conf in (
        {"id":"contest-site", "url":"https://contest-blog.testimonials.co", "secret_token":"live-token"},
        {"id":"customer-site", "url":"https://example.com", "secret_token":"live-token"},
        {"id":"testimonials-brand", "url":"https://customer.example.org", "secret_token":"production-token"},
    ):
        assert NextJsAdapter(conf)._is_mock_target() is False


def test_nextjs_unpublish_failure_does_not_report_success(monkeypatch):
    disable_test_mode(monkeypatch)
    class Response:
        def __init__(self, status_code): self.status_code = status_code
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def post(self, *args, **kwargs): return Response(500)
        def patch(self, *args, **kwargs): return Response(302)
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter = NextJsAdapter({"id":"site", "url":"https://site.example.org", "secret_token":"live-token"})
    assert adapter.unpublish("1", "a-test-article") is False


def test_headless_git_staging_creates_branch_and_commits_article(monkeypatch):
    monkeypatch.setattr(cms_publishers, "_is_test_runtime", lambda: False)
    calls=[]
    class Response:
        def __init__(self, status_code, body=None): self.status_code=status_code; self.body=body if body is not None else {}
        def json(self): return self.body
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self,*args): return False
        def get(self,url,**kwargs):
            calls.append(("GET",url,kwargs))
            if "/git/ref/heads/main" in url: return Response(200,{"object":{"sha":"base-sha"}})
            if "/git/ref/heads/content/" in url: return Response(404)
            if "/contents/" in url: return Response(404)
            return Response(404)
        def post(self,url,**kwargs): calls.append(("POST",url,kwargs)); return Response(201,{"ref":"refs/heads/content/pr-a-test-article-abcdef12"})
        def put(self,url,**kwargs): calls.append(("PUT",url,kwargs)); return Response(201,{"content":{"sha":"new-sha"}})
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter=cms_publishers.HeadlessGitPRAdapter({"id":"site","url":"https://content.example.org","github_repo":"acme/editorial-site","github_branch":"main","github_token":"token-for-mock-only","type":"headless_git"})
    media_payload = payload(hero_image=CMSMediaAsset(filename="hero.webp", file_bytes=b"image-data"))
    result=adapter.stage_draft(media_payload)
    assert result.success and result.status == "staged"
    assert result.raw_response["content_path"] == "content/posts/a-test-article.mdx"
    assert any(m == "PUT" and "/contents/content/posts/a-test-article.mdx" in url for m,url,_ in calls)
    assert any(m == "PUT" and "/contents/public/uploads/hero.webp" in url for m,url,_ in calls)


def test_headless_git_rejects_traversal_slug_before_network(monkeypatch):
    monkeypatch.setattr(cms_publishers,"_is_test_runtime",lambda:False)
    adapter=cms_publishers.HeadlessGitPRAdapter({"id":"site","github_repo":"acme/site","github_branch":"main","github_token":"token"})
    bad=payload(); bad.slug="../secret"
    result=adapter.stage_draft(bad)
    assert result.success is False and result.status == "failed"


def test_headless_git_creates_draft_pr_only_after_http_confirmation(monkeypatch):
    monkeypatch.setattr(cms_publishers,"_is_test_runtime",lambda:False)
    calls=[]
    class Response:
        def __init__(self,status_code,body=None): self.status_code=status_code; self.body=body if body is not None else {}
        def json(self): return self.body
    class Client:
        def __init__(self,**kwargs): pass
        def __enter__(self): return self
        def __exit__(self,*args): return False
        def get(self,url,**kwargs): calls.append(("GET",url,kwargs)); return Response(200,[])
        def post(self,url,**kwargs): calls.append(("POST",url,kwargs)); return Response(201,{"html_url":"https://github.com/acme/editorial-site/pull/42"})
    monkeypatch.setattr(cms_publishers.httpx,"Client",Client)
    adapter=cms_publishers.HeadlessGitPRAdapter({"id":"site","url":"https://content.example.org","github_repo":"acme/editorial-site","github_branch":"main","github_token":"token-for-mock-only","type":"headless_git"})
    result=adapter.publish_or_schedule("content/pr-a-test-article-abcdef12",payload())
    assert result.success is True and result.status == "draft_pr"
    pr_body=[kw["json"] for method,url,kw in calls if method=="POST"][0]
    assert pr_body["draft"] is True


def test_media_uploaders_do_not_invent_live_upload_urls(monkeypatch):
    disable_test_mode(monkeypatch)
    asset=CMSMediaAsset(filename="hero.webp", file_bytes=b"image-bytes")
    for adapter in (
        cms_publishers.WebflowAdapter({"id":"wf","url":"https://wf.example","secret_token":"tok","webflow_collection_id":"col"}),
        cms_publishers.ShopifyAdapter({"id":"sh","url":"https://shop.example","secret_token":"tok","shopify_blog_id":"1"}),
        cms_publishers.GhostAdapter({"id":"gh","url":"https://ghost.example","secret_token":"key"}),
        cms_publishers.NextJsAdapter({"id":"nx","url":"https://next.example","secret_token":"tok"}),
    ):
        result=adapter.upload_media(asset)
        assert result.success is False
        assert not result.cms_media_url


def test_wordpress_upload_does_not_return_guessed_url_on_failed_request(monkeypatch):
    disable_test_mode(monkeypatch)
    class Response:
        status_code = 503
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def post(self, *args, **kwargs): return Response()
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter=WordPressAdapter({"id":"wp","url":"https://wp.example","secret_token":"token"})
    result=adapter.upload_media(CMSMediaAsset(filename="hero.webp",file_bytes=b"img"))
    assert result.success is False and not result.cms_media_url
    assert "HTTP 503" in result.error


def test_ghost_publish_does_not_claim_success_on_http_failure(monkeypatch):
    disable_test_mode(monkeypatch)
    class Response:
        status_code = 500
    class Client:
        def __init__(self, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def put(self, *args, **kwargs): return Response()
    monkeypatch.setattr(cms_publishers.httpx, "Client", Client)
    adapter=cms_publishers.GhostAdapter({"id":"ghost","url":"https://ghost.example","secret_token":"0123456789abcdef0123456789abcdef:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"})
    result=adapter.publish_or_schedule("post-1",payload())
    assert result.success is False and result.status == "failed"
    assert "HTTP 500" in result.error


def test_nextjs_media_path_traversal_is_rejected(monkeypatch):
    disable_test_mode(monkeypatch)
    adapter = NextJsAdapter({"id": "next", "url": "https://next.example", "secret_token": "real-token"})
    result = adapter.upload_media(CMSMediaAsset(filename="hero.webp", source_url="/uploads/../../etc/passwd"))
    assert result.success is False
    assert result.cms_media_url == ""
