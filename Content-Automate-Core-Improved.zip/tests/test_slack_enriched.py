"""
Manual / live verification of the enriched Slack review card.

Requires a configured website row with a real slack_webhook_url.
Run explicitly with:  pytest -m live -k test_slack_enriched
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from pipeline.adapters.slack_bot import build_slack_review_card, send_slack_card


@pytest.mark.live
def test_slack_enriched():
    from storage.db import get_website_by_id

    site = get_website_by_id("site-60489ec2")
    webhook = site.get("slack_webhook_url") if site else None

    state = {
        "title": "Autonomous Next.js Publishing with Human-in-the-Loop Review",
        "slug": "autonomous-nextjs-publishing-human-in-the-loop-review",
        "meta_description": "A blueprint for automated content pipelines using LangGraph state machines, Slack review gates, and Next.js App Router.",
        "draft": """---
title: Autonomous Next.js Publishing with Human-in-the-Loop Review
description: A blueprint for automated content pipelines using LangGraph state machines, Slack review gates, and Next.js App Router.
---

# Autonomous Next.js Publishing with Human-in-the-Loop Review

The intersection of generative AI agents and modern web architectures has unlocked a new paradigm for content engineering. Rather than treating content publishing as a purely manual editorial task or an unmonitored script, production teams are deploying stateful AI pipelines orchestrated by LangGraph with human review gates in Slack.

## The Architectural Blueprint

A resilient autonomous publishing architecture requires three foundational layers:

1. **Stateful Graph Orchestration**: LangGraph coordinates outline generation, deep draft synthesis, SEO auditing, and visual asset generation.
2. **Human-in-the-Loop Review Gate**: Drafts pause at an interrupt checkpoint, notifying editorial leads via interactive Slack cards.
3. **Target Destination Adapter**: Approved dispatches publish directly to Next.js App Router via authenticated REST API routes.

## Immediate Operational Value

By maintaining human oversight at the review gate while automating synthesis and distribution, engineering teams reduce article time-to-publish from days to under 60 seconds.""",
        "hero_image_url": "/static/uploads/test-autonomous-agents-2026-30571-302.jpg",
        "public_image_url": "https://image.pollinations.ai/prompt/Editorial%20tech%20illustration%20minimalist%20geometric%20Nextjs%20architecture?width=1200&height=630&nologo=true&seed=849204",
        "word_count": 1420,
        "read_time": 7,
        "seo_score": 94,
        "thread_id": "dispatch-live-verify-001",
        "revision_count": 1,
        "keywords": ["Next.js", "LangGraph", "AI Agents", "Slack Gate"]
    }

    card = build_slack_review_card(
        state,
        website_name=site["name"] if site else "Minimal Website",
        website_id=site["id"] if site else "site-60489ec2"
    )
    print("Card blocks created:", len(card["blocks"]))
    assert len(card["blocks"]) >= 4

    if webhook:
        res = send_slack_card(card, webhook_url=webhook)
        print("Slack dispatch result:", res)
        assert res.get("ok") is True
    else:
        print("No webhook URL configured — card construction verified only.")
