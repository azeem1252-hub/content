"""Regression tests that separate live SERP evidence from generated suggestions."""
from unittest.mock import patch
from pipeline.adapters.brief_builder import build_evidence_based_brief, resolve_unique_angle


def test_fallback_angle_does_not_claim_unverified_measurements():
    angle=resolve_unique_angle(primary_keyword="redis caching", unanswered_paa=[], differentiators=["Cache invalidation"])
    assert "source-grounded" in angle
    assert "measured results only when independently verified" in angle
    assert "zero performance degradation" not in angle


@patch("pipeline.adapters.brief_builder._synthesize_brief_sections", return_value=[])
@patch("pipeline.adapters.brief_builder.get_cluster_candidates", return_value=[])
@patch("pipeline.adapters.brief_builder.fetch_serp_live_advanced", return_value={
    "query":"redis caching","provider":"unconfigured","top_urls":[],"serp_features":[],
    "paa_questions":[],"related_searches":[],"has_ai_overview":False,"ai_overview_sources":[],
})
def test_suggested_questions_are_not_reported_as_live_serp_paa(_fetch,_cluster,_sections):
    brief=build_evidence_based_brief(topic="redis caching",check_robots=False)
    assert brief.serp_summary["paa_questions_source"] == "generated_suggestions"
    assert brief.serp_summary["observed_paa_count"] == 0
    assert brief.serp_summary["live_data_available"] is False
    assert all(x["opportunity_type"] != "serp_consensus_paa" for x in brief.questions_to_answer)
