"""
Tests for universal LLM providers, image generators, and Codex device connection flow.
"""
import pytest
from starlette.testclient import TestClient
from web.app import app
import config

client = TestClient(app)

def test_system_status_includes_all_providers():
    res = client.get("/api/agent/system-status")
    assert res.status_code == 200
    data = res.json()

    # LLM providers
    assert "openai" in data
    assert "claude" in data
    assert "qwen" in data
    assert "glm" in data
    assert "kimi" in data
    assert "deepseek" in data
    assert "custom_llm" in data
    assert "mistral" in data
    assert "groq" in data

    # Image providers
    assert "openai_image" in data
    assert "custom_image" in data
    assert "cloudflare" in data
    assert "gemini" in data
    assert "codex" in data
    assert "tavily" in data

def test_update_settings_and_system_status():
    # Test setting preferred provider and models
    res = client.post("/api/agent/settings", json={
        "preferred_provider": "openai",
        "openai_model": "gpt-4o",
        "anthropic_model": "claude-3-5-haiku-20241022",
        "qwen_model": "qwen-max",
        "openai_image_model": "dall-e-3",
        "custom_image_url": "https://api.together.xyz/v1/images/generations",
        "custom_image_model": "black-forest-labs/FLUX.1-schnell",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "success"

    status_res = client.get("/api/agent/system-status")
    status_data = status_res.json()
    assert status_data["preferred_provider"] == "openai"
    assert status_data["openai"]["model"] == "gpt-4o"
    assert status_data["claude"]["model"] == "claude-3-5-haiku-20241022"
    assert status_data["qwen"]["model"] == "qwen-max"
    assert status_data["openai_image"]["model"] == "dall-e-3"
    assert status_data["custom_image"]["endpoint_url"] == "https://api.together.xyz/v1/images/generations"

def test_test_llm_validation():
    # Calling with empty key should report not configured or error gracefully
    res = client.post("/api/agent/test-llm", json={
        "provider": "openai",
        "api_key": "invalid_test_key",
        "model": "gpt-4o-mini"
    })
    assert res.status_code == 200
    data = res.json()
    assert "ok" in data

def test_test_openai_image_validation():
    res = client.post("/api/agent/test-openai-image", json={
        "api_key": "invalid_test_key",
        "model": "dall-e-3"
    })
    assert res.status_code == 200
    data = res.json()
    assert "ok" in data
    assert data["ok"] is False

def test_test_custom_image_validation():
    res = client.post("/api/agent/test-custom-image", json={
        "endpoint_url": "http://127.0.0.1:9999/nonexistent",
        "api_key": "test",
        "model": "flux"
    })
    assert res.status_code == 200
    data = res.json()
    assert "ok" in data
    assert data["ok"] is False

@pytest.mark.live
def test_codex_endpoints():
    # Probe local capture
    res_cap = client.post("/api/agent/codex-capture-local")
    assert res_cap.status_code == 200
    assert "ok" in res_cap.json()

    # Probe codex test
    res_test = client.post("/api/agent/test-codex", json={"token": ""})
    assert res_test.status_code == 200
    assert "ok" in res_test.json()

    # Probe codex status
    res_status = client.get("/api/agent/codex-status")
    assert res_status.status_code == 200
    assert "provider" in res_status.json()
