"""Security regression coverage for crawler destination checks."""
from pipeline.adapters.url_safety import validate_audit_target

def test_disallows_private_and_loopback_address_literals(monkeypatch):
    monkeypatch.delenv("ALLOW_PRIVATE_AUDIT_TARGETS", raising=False)
    for url in ("http://127.0.0.1/admin", "http://10.0.0.5/", "http://169.254.169.254/latest/meta-data", "http://[::1]/"):
        ok, reason = validate_audit_target(url, resolve_dns=False)
        assert not ok and reason

def test_disallows_non_http_and_embedded_credentials():
    assert validate_audit_target("file:///etc/passwd", resolve_dns=False)[0] is False
    assert validate_audit_target("https://user:pass@example.com", resolve_dns=False)[0] is False

def test_explicit_private_audit_override_is_operator_controlled(monkeypatch):
    monkeypatch.setenv("ALLOW_PRIVATE_AUDIT_TARGETS", "true")
    assert validate_audit_target("http://127.0.0.1:8000", resolve_dns=False)[0] is True


def test_crawler_does_not_fetch_cross_origin_sitemaps(monkeypatch):
    from pipeline.adapters import technical_audit

    calls = []

    class Response:
        def __init__(self, status_code, text=""):
            self.status_code = status_code
            self.text = text

    class Client:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def get(self, url):
            calls.append(url)
            if url.endswith("/robots.txt"):
                return Response(200, "Sitemap: https://attacker.example/sitemap.xml\nSitemap: https://site.example/sitemap.xml")
            if url.endswith("/sitemap.xml"):
                return Response(200, "<urlset><url><loc>https://site.example/post-a</loc></url></urlset>")
            return Response(200, "<html></html>")

    monkeypatch.setattr(technical_audit.httpx, "Client", Client)
    monkeypatch.setenv("ALLOW_PRIVATE_AUDIT_TARGETS", "true")
    urls = technical_audit.discover_urls("https://site.example", max_pages=10)
    assert "https://site.example/post-a" in urls
    assert "https://attacker.example/sitemap.xml" not in calls
    assert all("attacker.example" not in url for url in calls)
