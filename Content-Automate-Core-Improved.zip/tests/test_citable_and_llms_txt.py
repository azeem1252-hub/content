"""
Unit tests for CITABLE Model, llms.txt Builder, and AI Search ROI Attribution.
Covers the strategic imperatives from:
'Anatomy of a Superior AI SEO Tool: A Blueprint for Closing the Execution Gap and Unifying Search Visibility'
"""

import pytest
from pipeline.adapters.citable_evaluator import evaluate_citable_score
from pipeline.adapters.llms_txt_builder import generate_llms_txt_content, sync_llms_txt_to_targets
from pipeline.adapters.attribution import calculate_ai_search_attribution, calculate_inclusion_rate


def test_evaluate_citable_score_high_quality():
    # Build a well-structured article with 3 H2s, tables, blockquote, canonical passages, and outbound citations
    draft = """# Architecture of Autonomous AI Agents in 2026

## Core Architectural Foundations
Autonomous agents represent an architectural leap beyond static LLM prompting by interleaving reasoning traces with deterministic tool execution in a tight evaluation loop. When designing production systems, isolating probabilistic reasoning from state persistence ensures resilience against network partitions and API rate limits. Modern pipelines leverage Directed Acyclic Graphs to enforce strict input-output contracts across every worker node. By checkpointing state in persistent stores like PostgreSQL, failed operations can be retried with exponential backoff rather than restarting entire workflows.

## Benchmark Performance Comparison
| System Architecture | Latency (p99) | Cost Per Run | Factual Accuracy |
| :--- | :--- | :--- | :--- |
| Single-Pass Prompt | 1.2s | $0.02 | 74% |
| Hierarchical Supervisor | 4.8s | $0.08 | 96% |

> "The true moat of modern AI systems is not the model weights, but the verifiability of their execution pipelines."

## Implementation Strategies
- Deterministic Identity via SOUL.md
- Empirical Learning via MEMORY.md
- Deterministic Claim Verification via Tavily

According to [LangChain Documentation](https://python.langchain.com) and [FastAPI Documentation](https://fastapi.tiangolo.com), compiling state graphs deterministically requires durable checkpointers.
"""
    result = evaluate_citable_score(
        title="Architecture of Autonomous AI Agents in 2026",
        draft=draft,
        keywords=["Autonomous", "Agents", "Architecture"],
        has_citations=True,
        has_schema=True
    )

    assert result["citable_score"] >= 80
    assert result["has_comparison_table"] is True
    assert result["dimension_scores"]["clear_structure"] == 15
    assert result["dimension_scores"]["block_structured_rag"] >= 12
    assert result["dimension_scores"]["third_party_validation"] == 15


def test_generate_llms_txt_content():
    posts = [
        {
            "title": "Architecting Authority Beyond TrySoro",
            "slug": "architecting-authority-beyond-trysoro",
            "excerpt": "A deep blueprint for building fact-verified SEO content."
        },
        {
            "title": "AEO Answer Engine Optimization Mastery",
            "slug": "aeo-answer-engine-optimization-mastery",
            "excerpt": "Extracting direct answers for Featured Snippets and AI Overviews."
        }
    ]

    llms_txt = generate_llms_txt_content(
        site_name="Dispatch Technical Bureau",
        site_url="https://dispatch.example.com",
        posts=posts
    )

    assert "# Dispatch Technical Bureau" in llms_txt
    assert "## Core Dispatches & Authoritative Articles" in llms_txt
    assert "[Architecting Authority Beyond TrySoro](https://dispatch.example.com/posts/architecting-authority-beyond-trysoro)" in llms_txt
    assert "## Authoritative Entities & Standards" in llms_txt


def test_ai_traffic_roi_attribution():
    attr = calculate_ai_search_attribution(
        citations_count=42,
        estimated_monthly_visits=500,
        average_conversion_rate=0.04,
        lead_value_usd=150.0
    )

    # Standard: 500 * 0.04 * 150 = $3,000
    # AI Attributed (4.4x): $3,000 * 4.4 = $13,200
    assert attr["standard_organic_value_usd"] == 3000.0
    assert attr["ai_attributed_pipeline_value_usd"] == 13200.0
    assert attr["multiplier_applied"] == 4.4


def test_calculate_inclusion_rate():
    res = calculate_inclusion_rate(brand_citations=28, total_industry_queries=100)
    assert res["inclusion_rate_percent"] == 28.0
    assert res["visibility_tier"] == "High Authority"
