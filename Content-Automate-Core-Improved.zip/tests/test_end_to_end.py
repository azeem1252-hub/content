import os
import sys
import httpx
from pathlib import Path

# Ensure project root in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
from langgraph.types import Command
from pipeline.graph import build_content_pipeline
from storage.db import init_db, get_post_by_slug


@pytest.mark.live
def test_full_pipeline_roundtrip():
    print("=" * 65)
    print("Executing End-to-End Autonomous Publishing Pipeline Test")
    print("=" * 65)

    init_db()
    pipeline = build_content_pipeline()

    topic = "Autonomous Multi-Agent Pipelines in 2026"
    keywords = ["LangGraph", "Groq", "Tavily", "Slack Gate"]
    thread_id = "test-e2e-run-001"

    config = {"configurable": {"thread_id": thread_id}}

    # Phase 1: Initial Generation Pass (Pre-Approval)
    print("\n[Phase 1/4] Triggering initial generation pass (Outline -> Draft -> Image -> Audit -> Review Gate)...")
    initial_input = {
        "topic": topic,
        "keywords": keywords,
        "target_audience": "Senior Systems Engineers & Engineering Directors",
        "revision_count": 0,
        "review_status": "pending",
        "thread_id": thread_id,
        "status": "queued"
    }

    state_phase1 = pipeline.invoke(initial_input, config=config)
    print(f"[OK] Phase 1 completed.")
    print(f"     Title:           {state_phase1.get('title')}")
    print(f"     Slug:            {state_phase1.get('slug')}")
    print(f"     SEO Score:       {state_phase1.get('seo_score')}/100")
    print(f"     Hero Image URL:  {state_phase1.get('hero_image_url')}")
    print(f"     Review Status:   {state_phase1.get('review_status')}")
    assert state_phase1["outline"] is not None
    assert state_phase1["draft"] is not None
    assert state_phase1["hero_image_url"] is not None
    assert "__interrupt__" in state_phase1, "Pipeline did not interrupt at review_gate!"

    # Phase 2: Test Human Editorial Revision Feedback Loop
    print("\n[Phase 2/4] Simulating Human Editor Requesting Changes via Slack...")
    feedback_text = "Emphasize how fast inference under 10 seconds empowers editors to iterate without lag."
    
    # Resume pipeline with changes requested via native LangGraph Command
    resume_command = Command(resume={
        "action": "request_changes",
        "feedback": feedback_text
    })
    state_phase2 = pipeline.invoke(resume_command, config=config)
    print(f"[OK] Revision loop executed successfully.")
    print(f"     Revision Count:  {state_phase2.get('revision_count')}")
    assert state_phase2["revision_count"] >= 2
    assert "__interrupt__" in state_phase2, "Pipeline did not pause at review_gate for revised draft!"

    # Phase 3: Simulate Human Approval in Slack
    print("\n[Phase 3/4] Simulating Human Editor Approval (Single-Click Approve)...")
    approval_command = Command(resume="approved")
    final_state = pipeline.invoke(approval_command, config=config)
    print(f"[OK] Publishing & Repurposing completed.")
    print(f"     Published URL:   {final_state.get('published_url')}")
    print(f"     Final Status:    {final_state.get('status')}")
    assert final_state.get("published_url") is not None
    assert final_state.get("status") == "completed"

    # Phase 4: Verify Live Publication & Social Repurposing
    print("\n[Phase 4/4] Verifying Published Assets & Live Website Verification...")
    
    # Verify social content
    assert final_state.get("linkedin_post"), "LinkedIn post was not generated!"
    assert len(final_state.get("twitter_thread", [])) >= 3, "Twitter thread missing tweets!"
    print(f"[OK] LinkedIn Post Generated ({len(final_state['linkedin_post'])} chars)")
    print(f"[OK] Twitter Thread Generated ({len(final_state['twitter_thread'])} tweets)")

    # Verify post exists in SQLite database
    slug = final_state.get("slug")
    db_post = get_post_by_slug(slug)
    assert db_post is not None, f"Post with slug '{slug}' not found in posts.db!"
    print(f"[OK] Article verified in database: '{db_post['title']}' (slug: {db_post['slug']})")

    print("\n" + "=" * 65)
    print(">>> COMPLETE END-TO-END PUBLISHING PIPELINE PASSED! <<<")
    print("=" * 65)

if __name__ == "__main__":
    test_full_pipeline_roundtrip()
