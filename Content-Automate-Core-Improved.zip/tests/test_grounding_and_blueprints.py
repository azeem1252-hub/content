"""
Tests for Grounding Page Standard v1.6, 4-Layer Verification, and Blueprint integrations.
"""

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient
from web.app import app
from pipeline.adapters.grounding_page_builder import (
    build_grounding_page_payload,
    save_and_deploy_grounding_page,
    list_existing_grounding_pages,
)
from pipeline.nodes.fact_check_node import (
    compute_source_trust_score,
    compute_rag_grounding_score,
    evaluate_decision_risk,
    reflexion_critique_pass,
    fact_check_node,
)
from pipeline.adapters.schema_builder import (
    generate_howto_schema,
    generate_person_schema,
    extract_howto_steps_from_markdown,
)

client = TestClient(app)


def test_build_grounding_page_payload_v16_structure():
    page_data = build_grounding_page_payload(
        entity_name="LangGraph Studio",
        canonical_url="https://editorial.example.com",
        entity_type="SoftwareApplication",
        stable_definition="LangGraph Studio is a specialized local development environment for building, inspecting, and debugging complex agentic workflows.",
        what_it_is_not=[
            "It is NOT a general-purpose code editor like VS Code or Cursor.",
            "It is NOT a cloud deployment service."
        ],
        atomic_facts=[
            {"statement": "Provides visual graph inspection of state transitions.", "source": "Official Docs"},
            {"statement": "Runs locally alongside FastAPI backend instances.", "source": "Release Notes"}
        ],
        key_specifications={
            "License": "Proprietary / Developer Free Tier",
            "Runtime": "Python 3.10+",
            "Interface": "Web GUI (React)"
        },
        same_as_links=[
            "https://www.wikidata.org/wiki/Q12345",
            "https://github.com/langchain-ai/langgraph"
        ],
    )

    assert page_data["entity_name"] == "LangGraph Studio"
    assert page_data["slug"] == "langgraph-studio"
    assert "Standard v1.6" in page_data["markdown"]
    assert "What It Is Not" in page_data["markdown"]
    assert "SoftwareApplication" in page_data["json_ld"]["@type"]
    assert len(page_data["atomic_facts"]) == 2


def test_save_and_deploy_grounding_page(tmp_path):
    with patch("pipeline.adapters.grounding_page_builder.BASE_DIR", tmp_path), \
         patch("pipeline.adapters.grounding_page_builder.GROUNDING_DIR", tmp_path / "web" / "static" / "grounding"):
        res = save_and_deploy_grounding_page(
            entity_name="Test Entity",
            canonical_url="https://test.com",
            stable_definition="Test Entity is an automated verification target.",
        )
        assert res["status"] in ("deployed", "success")
        assert res["slug"] == "test-entity"
        
        # Verify listing
        listing = list_existing_grounding_pages()
        assert listing["count"] >= 1
        assert any(p["slug"] == "test-entity" for p in listing["pages"])


def test_4layer_source_trust_score():
    high_trust_evidence = [
        {"url": "https://www.cdc.gov/flu/index.html"},
        {"url": "https://developer.mozilla.org/en-US/docs/Web/JavaScript"},
        {"url": "https://stanford.edu/research/paper.pdf"}
    ]
    score_high = compute_source_trust_score(high_trust_evidence)
    assert score_high >= 80

    low_trust_evidence = [
        {"url": "https://random-unverified-blog.xyz/post"},
        {"url": "http://spamsite.click/article"}
    ]
    score_low = compute_source_trust_score(low_trust_evidence)
    assert score_low <= 70


def test_4layer_rag_grounding_score():
    strong_claims_with_evidence = [
        {
            "statement": "FastAPI provides automatic OpenAPI documentation generation.",
            "evidence": [
                {"snippet": "FastAPI generates interactive OpenAPI documentation and Swagger UI automatically."}
            ]
        }
    ]
    score_strong = compute_rag_grounding_score(strong_claims_with_evidence)
    assert score_strong > 40

    weak_claims_with_evidence = [
        {
            "statement": "FastAPI provides automatic OpenAPI documentation generation.",
            "evidence": [
                {"snippet": "The weather in Seattle is rainy during autumn months."}
            ]
        }
    ]
    score_weak = compute_rag_grounding_score(weak_claims_with_evidence)
    assert score_weak < score_strong


def test_4layer_decision_risk():
    # Low risk: high scores, zero contradictions
    claims_low = [
        {"claim_id": "c1", "statement": "Statement 1", "verdict": "Supported"}
    ]
    risk_low = evaluate_decision_risk(
        verified_claims=claims_low,
        faithfulness_score=95,
        grounding_score=85,
        source_trust_score=90
    )
    assert risk_low["risk_level"] == "Low"
    assert risk_low["routing_action"] == "auto_approve_eligible"

    # High risk: contradictions detected
    claims_high = [
        {"claim_id": "c1", "statement": "Statement 1", "verdict": "Contradicted"}
    ]
    risk_high = evaluate_decision_risk(
        verified_claims=claims_high,
        faithfulness_score=40,
        grounding_score=40,
        source_trust_score=50
    )
    assert risk_high["risk_level"] == "High"
    assert risk_high["routing_action"] == "human_review_required"



def test_howto_and_person_schema():
    md = """# Setup Guide
## Step 1: Install Dependencies
Run npm install in the project directory.

## Step 2: Configure Environment
Copy .env.example to .env and set your API keys.
"""
    steps = extract_howto_steps_from_markdown(md)
    assert len(steps) == 2
    assert "Install Dependencies" in steps[0]["name"]

    schema = generate_howto_schema(
        name="Setup Guide",
        description="A complete guide to setup.",
        steps=steps
    )
    assert schema["@type"] == "HowTo"
    assert len(schema["step"]) == 2

    person_schema = generate_person_schema(
        author_name="Dr. Alex Vance",
        author_role="Lead Technical Editor",
        organization_name="AI Research Daily"
    )
    assert person_schema["@type"] == "Person"
    assert person_schema["worksFor"]["name"] == "AI Research Daily"


def test_grounding_page_api_endpoints():
    response = client.get("/api/grounding-pages")
    assert response.status_code == 200
    data = response.json()
    assert "pages" in data

    post_payload = {
        "entity_name": "API Test Model",
        "canonical_url": "https://api-test.com",
        "entity_type": "Thing",
        "what_it_is_not": ["Not a physical hardware device."],
        "atomic_facts": [{"statement": "Processes JSON requests in under 50ms.", "source": "Bench"}],
        "key_specifications": {"Protocol": "REST / HTTP2"},
        "same_as_links": ["https://schema.org/Thing"]
    }
    create_res = client.post("/api/grounding-pages/generate", json=post_payload)
    assert create_res.status_code == 200
    res_data = create_res.json()
    assert res_data["status"] in ("deployed", "success")
    assert res_data["slug"] == "api-test-model"
