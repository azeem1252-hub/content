"""
Convenience re-export of storage.db within the web package.
"""

from storage.db import *
