"""
Web Studio and publishing platform package for Content Pipeline Agent.
Hosts the FastAPI application, REST endpoints, Mission Control Dashboard, and Dispatch Blog.
"""

from web.app import app

__all__ = ["app"]
