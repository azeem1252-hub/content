"""
Closed-Loop Performance Auditing & Self-Improving Feedback Engine (Pillar VI).

Implements the automated 30-day performance harvesting and triage engine:
1. Ingests search analytics (Google Search Console) and video retention (Postiz).
2. Algorithmic Content Triage:
   - Position 11-20 Plateau: Triggers Entity-Gap re-optimization & IndexNow ping.
   - High Impressions, CTR < 1.5%: Automatically rewrites H1, title tag, and meta description.
   - Sub-30% Video 3s Retention: Calibrates hook pacing heuristics.
3. Closes the loop by continuously recording validated patterns into `.agents/MEMORY.md`.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block
from pipeline.adapters.brand_dna import append_memory_learning
from pipeline.adapters.indexnow_client import submit_indexnow_urls

logger = logging.getLogger("pipeline.auditor")


def triage_search_performance(
    url: str,
    title: str,
    impressions: int,
    clicks: int,
    average_position: float
) -> Dict[str, Any]:
    """
    Evaluates organic search performance against algorithmic triage thresholds.
    """
    ctr = (clicks / impressions * 100) if impressions > 0 else 0.0

    # 1. Position 11-20 Plateau (Page 2 Decay / Entity Gap)
    if 10.5 <= average_position <= 20.5 and impressions >= 100:
        logger.info(f"Triage Triggered: '{title}' is plateaued on Page 2 (Pos: {average_position:.1f}).")
        return {
            "workflow": "decay_reoptimization",
            "url": url,
            "title": title,
            "reason": f"Position {average_position:.1f} plateau with {impressions} impressions. Entity gap expansion needed.",
            "action_required": "expand_entities"
        }

    # 2. High Impressions, Low CTR (< 1.5%)
    if impressions >= 500 and ctr < 1.5:
        logger.info(f"Triage Triggered: '{title}' has low CTR ({ctr:.2f}%). Title & snippet rewrite needed.")
        return {
            "workflow": "headline_optimization",
            "url": url,
            "title": title,
            "reason": f"High search impressions ({impressions}) with sub-1.5% CTR ({ctr:.2f}%).",
            "action_required": "rewrite_metadata"
        }

    return {
        "workflow": "nominal",
        "url": url,
        "title": title,
        "ctr": round(ctr, 2),
        "reason": "Performance within normal bounds."
    }


def triage_video_retention(
    video_title: str,
    hook_3s: str,
    views: int,
    three_second_retention_rate: float
) -> Dict[str, Any]:
    """
    Evaluates short-form video retention against the 30% retention threshold.
    """
    if views >= 100 and three_second_retention_rate < 0.30:
        logger.warning(
            f"Video Retention Alert: '{video_title}' achieved only "
            f"{three_second_retention_rate:.0%} 3s retention (threshold: 30%)."
        )
        learning = f"Underperforming hook: '{hook_3s[:80]}...' resulted in {three_second_retention_rate:.0%} retention. Shift to higher-contrast opening."
        append_memory_learning("Short-Form Video Hook Heuristics (3-Second Retention Models)", learning)
        return {
            "status": "calibrated",
            "retention_rate": three_second_retention_rate,
            "learning_recorded": True
        }

    return {
        "status": "healthy",
        "retention_rate": three_second_retention_rate,
        "learning_recorded": False
    }


def optimize_low_ctr_headline(
    current_title: str,
    topic: str,
    current_ctr: float
) -> Dict[str, str]:
    """
    Generates high-intent replacement title and meta description using verified formulas.
    """
    prompt = f"""
You are an elite SEO CTR Optimization Specialist.
The following article is ranking well but suffering from a low Click-Through Rate ({current_ctr:.2f}% < 1.5%):

Current Title: {current_title}
Topic: {topic}

Generate a compelling, high-intent, authoritative replacement Title (under 60 characters)
and Meta Description (under 155 characters) that eliminates fluff and increases search clicks.

Return a strict JSON object:
```json
{{
  "optimized_title": "...",
  "optimized_meta_description": "..."
}}
```
"""
    try:
        raw = call_llm(prompt, temperature=0.7)
        data = extract_json_block(raw)
        if data and data.get("optimized_title"):
            learning = f"Rewrote title from '{current_title}' to '{data['optimized_title']}' for topic '{topic}'."
            append_memory_learning("High-Performing Headline & Hook Formulas", learning)
            return {
                "optimized_title": data["optimized_title"],
                "optimized_meta_description": data.get("optimized_meta_description", "")
            }
    except Exception as e:
        logger.warning(f"Headline optimization LLM error: {e}")

    return {
        "optimized_title": f"{topic}: Production Architecture Guide (2026)",
        "optimized_meta_description": f"Comprehensive architectural analysis and benchmark data for {topic}."
    }
