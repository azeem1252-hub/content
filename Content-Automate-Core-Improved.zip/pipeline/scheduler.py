import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional

try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    AsyncIOScheduler = None

from storage.db import (
    get_due_schedules,
    get_schedule_by_id,
    update_schedule_last_run,
    mark_schedule_completed
)
from pipeline.pipeline_manager import pipeline_manager

logger = logging.getLogger("pipeline.scheduler")


class AutomationScheduler:
    """
    Background worker evaluating active publishing schedules for connected Next.js websites.
    Executes autonomous generation passes and dispatches Slack review cards when due.
    Powered by an asynchronous loop and an integrated APScheduler AsyncIOScheduler.
    """

    def __init__(self):
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._check_interval_seconds = 30
        self._in_flight: set = set()
        self._apscheduler = AsyncIOScheduler() if APSCHEDULER_AVAILABLE else None

    @property
    def apscheduler(self) -> Optional[Any]:
        """Provides direct access to the underlying APScheduler instance."""
        return self._apscheduler

    def start(self):
        """Starts the scheduler background loop and APScheduler."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        if self._apscheduler and not self._apscheduler.running:
            try:
                self._apscheduler.start()
                logger.info("APScheduler AsyncIOScheduler started successfully.")
            except Exception as e:
                logger.warning(f"Failed to start APScheduler: {e}")
        logger.info("Next.js Content Pipeline Automation Scheduler started.")

    def stop(self):
        """Stops the scheduler and APScheduler."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        if self._apscheduler and self._apscheduler.running:
            try:
                self._apscheduler.shutdown(wait=False)
                logger.info("APScheduler AsyncIOScheduler shut down.")
            except Exception as e:
                logger.warning(f"Error shutting down APScheduler: {e}")
        logger.info("Automation Scheduler stopped.")

    async def _loop(self):
        """Checks for due schedules periodically."""
        while self._running:
            try:
                due_schedules = await asyncio.to_thread(get_due_schedules)
                for sched in due_schedules:
                    sched_id = sched["id"]
                    if sched_id in self._in_flight:
                        continue
                    self._in_flight.add(sched_id)
                    try:
                        logger.info(f"Triggering scheduled dispatch: '{sched['name']}' for Next.js website '{sched.get('website_name')}'")

                        # Trigger the pipeline FIRST; only advance next_run_at if the
                        # trigger actually succeeded, so failed triggers are retried
                        # on the next evaluation instead of being silently skipped.
                        try:
                            auto_approve = bool(sched.get("slack_review_required") == 0)
                            # Empty topic => the pipeline autonomously discovers a
                            # unique topic at fire time, same as a manual dispatch
                            # without a topic.
                            run_topic = (sched.get("topic_prompt") or "").strip() or None
                            if run_topic and sched.get("last_run_at"):
                                # A re-fired fixed topic is near-identical to the
                                # previous article and would be silently swapped
                                # for a discovered topic by the duplicate guard;
                                # the dated suffix keeps the editor's chosen topic
                                # while still producing a distinct slug (same
                                # behavior as manual escalation).
                                run_topic = f"{run_topic} (re-run {datetime.now().strftime('%Y-%m-%d %H:%M')})"
                            pipeline_manager.start_pipeline(
                                topic=run_topic,
                                website_id=sched.get("website_id"),
                                keywords=sched.get("keywords") or [],
                                target_audience=sched.get("target_audience"),
                                mode="live",
                                auto_approve=auto_approve,
                                content_format=sched.get("content_format"),
                                content_options=sched.get("content_options") or {},
                            )
                        except Exception as trigger_err:
                            logger.error(f"Failed to trigger schedule '{sched['name']}': {trigger_err}")
                            continue

                        if sched.get("schedule_type") == "once":
                            # One-time dispatch: fire once, then close out so the
                            # scheduler never re-runs it.
                            await asyncio.to_thread(mark_schedule_completed, sched_id)
                            logger.info(f"One-time schedule '{sched['name']}' fired and marked completed.")
                        else:
                            await asyncio.to_thread(
                                update_schedule_last_run,
                                sched_id=sched_id,
                                interval_hours=sched.get("interval_hours", 24),
                                publish_time=sched.get("publish_time")
                            )
                    finally:
                        self._in_flight.discard(sched_id)
            except Exception as e:
                logger.error(f"Error in scheduler evaluation loop: {e}")

            await asyncio.sleep(self._check_interval_seconds)

    def escalate_now(self, schedule_id: str) -> Dict[str, Any]:
        """Triggers immediate on-demand execution for a specific schedule."""
        sched = get_schedule_by_id(schedule_id)
        if not sched:
            raise ValueError("Schedule not found")

        if schedule_id in self._in_flight:
            logger.warning(f"Schedule '{schedule_id}' is already actively triggering. Skipping duplicate escalation.")
            return {
                "status": "already_running",
                "schedule_id": schedule_id,
                "schedule_name": sched["name"],
                "message": "This schedule is already actively triggering."
            }

        self._in_flight.add(schedule_id)
        try:
            logger.info(f"Escalating schedule on-demand: '{sched['name']}'")
            auto_approve = bool(sched.get("slack_review_required") == 0)
            sched_type = (sched.get("schedule_type") or "recurring").lower()
            run_topic = (sched.get("topic_prompt") or "").strip() or None
            if run_topic:
                # A re-fired run would duplicate the article: append a unique
                # suffix so the slug differs from the previous firing.
                run_topic = f"{run_topic} (re-run {datetime.now().strftime('%Y-%m-%d %H:%M')})"
            result = pipeline_manager.start_pipeline(
                topic=run_topic,
                website_id=sched.get("website_id"),
                keywords=sched.get("keywords") or [],
                target_audience=sched.get("target_audience"),
                mode="live",
                auto_approve=auto_approve,
                content_format=sched.get("content_format"),
                content_options=sched.get("content_options") or {},
            )
            # Advance the cadence only after a successful trigger. One-time
            # schedules are completed rather than rescheduled.
            if sched_type == "once":
                mark_schedule_completed(schedule_id)
            else:
                update_schedule_last_run(
                    sched_id=schedule_id,
                    interval_hours=sched.get("interval_hours", 24),
                    publish_time=sched.get("publish_time")
                )
            return {
                "status": "escalated",
                "schedule_id": schedule_id,
                "schedule_name": sched["name"],
                "thread_id": result.get("thread_id"),
                "pipeline_run": result
            }
        finally:
            self._in_flight.discard(schedule_id)


automation_scheduler = AutomationScheduler()
