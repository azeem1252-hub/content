"""
Editorial Design & Content Archetypes System — 36 Master Archetypes.

Defines the complete taxonomy of 36 editorial design archetypes, bridging:
1. Content Domain (what the publication covers: Haute Couture, Gaming Systems, Gourmet Culinary, etc.)
2. Visual & Editorial Art Direction (how stories are written, structured, paced, and visually photographed).

Used across:
- pipeline.topic_researcher: Identifies target website's editorial archetype.
- pipeline.nodes.outline_node: Structures the narrative and metadata sections.
- pipeline.nodes.draft_node: Sets voice, rhythm, pull quotes, and editorial depth.
- pipeline.nodes.image_node & codex_image: Drives authentic art-directed photography.
"""

from typing import Dict, Any, Optional, List
import re

EDITORIAL_DESIGN_ARCHETYPES: Dict[str, Dict[str, Any]] = {
    "classic_magazine": {
        "id": 1,
        "slug": "classic_magazine",
        "name": "Classic Magazine Editorial",
        "feeling": "Sophisticated, authoritative, traditional, literary. Inspired by Vogue, GQ, Esquire, Vanity Fair.",
        "characteristics": "Large feature headlines, dominant photography, supporting stories, multiple columns, elegant whitespace, captions, bylines, strong typographic hierarchy.",
        "writing_style": "Literary, narrative journalism with evocative ledes, immersive character or scene setting, witty transitions, and prestigious prose.",
        "image_direction": "Prestigious editorial portraiture or iconic reportage, medium format film look, studio or location lighting, dramatic composition, 35mm grain, 0 text, 0 UI.",
        "structure": ["Theatrical Lede", "The Narrative Body", "Editorial Pull Quote", "Supporting Perspectives", "Critical Reflection"],
        "pattern": r"\b(magazine|vogue|gq|esquire|vanity fair|classic editorial|bureau|dispatch)\b"
    },
    "fashion_editorial": {
        "id": 2,
        "slug": "fashion_editorial",
        "name": "Fashion Editorial",
        "feeling": "Ultra-luxurious, exclusive, poetic, avant-garde. High fashion + fine art photography + Haute Couture reverie.",
        "characteristics": "Enormous photography, elegant serif typography (Cormorant, Garamond, Didot), unusual image crops, expansive whitespace, minimal UI, art-directed compositions.",
        "writing_style": "Poetic, sensual, highly descriptive of silhouette architecture, fabric drapery, artisanal savoir-faire, and runway dramaturgy. Written from the desk of an acclaimed Paris fashion critic.",
        "image_direction": "High-fashion editorial photography, haute couture models on twilight Parisian colonnades or minimalist atelier spaces, sculptural double-silk velvet, bullion embroidery glints, Hasselblad 100mm f/2.0, dramatic chiaroscuro, 0 text, 0 UI.",
        "structure": ["Runway or Atelier Scene", "Silhouette & Textile Architecture", "The Craftsman's Hands (Savoir-Faire)", "Philosophical Pull Quote", "Atelier Notes (Hours of craft, provenance)", "The Collection Verdict"],
        "pattern": r"\b(fashion|couture|haute couture|runway|atelier|ateliers|savoir-faire|jewelry|jewellery|garment|apparel|tailoring|textile|silhouette|draping|vogue|maison|catwalk|model|wardrobe|paris fashion week|milan fashion week)\b"
    },
    "newspaper_editorial": {
        "id": 3,
        "slug": "newspaper_editorial",
        "name": "Newspaper Editorial",
        "feeling": "Urgent, factual, dense, highly structured, timeless journalism.",
        "characteristics": "Multi-column layout, headlines at varying scales, small briefs, rules/dividers, timestamps, dense information, strong hierarchy.",
        "writing_style": "Inverted pyramid journalism, crisp objective statements, hard data, expert quotes, zero fluff, investigative clarity.",
        "image_direction": "Photojournalism, candid documentary photography, natural lighting, gritty realism, archival press feel, 0 text, 0 UI.",
        "structure": ["Lead Bulletin", "The Hard Evidence & Timeline", "Key Stakeholder Statements", "Statistical Breakdown", "Broader Implications"],
        "pattern": r"\b(newspaper|gazette|chronicle|herald|tribune|broadsheet|dispatch desk)\b"
    },
    "digital_newspaper": {
        "id": 4,
        "slug": "digital_newspaper",
        "name": "Digital Newspaper",
        "feeling": "Dynamic, live, continuous, analytical. Inspired by The New York Times, The Guardian, Bloomberg.",
        "characteristics": "Responsive columns, live updates, article feeds, interactive charts, sticky navigation, distinct editorial hierarchy.",
        "writing_style": "Analytical, real-time investigative breakdown, contextual explanations, historical precedents, and multi-perspective insights.",
        "image_direction": "Modern photojournalism, crisp press photography, architectural and situational context, clean neutral grading, 0 text, 0 UI.",
        "structure": ["Breaking Assessment", "Developing Analysis", "Data Points & Key Metrics", "Expert Consensus", "What Comes Next"],
        "pattern": r"\b(digital newspaper|times|guardian|bloomberg|live wire|bulletin|news feed)\b"
    },
    "editorial_minimal": {
        "id": 5,
        "slug": "editorial_minimal",
        "name": "Editorial Minimal",
        "feeling": "Pure, restrained, quiet confidence, zen-like clarity.",
        "characteristics": "Stripped down to essential typography + strict grid + massive whitespace + singular powerful imagery. Thin rules, subtle metadata, no decorative noise.",
        "writing_style": "Extremely concise, deliberate, high-impact phrasing, measured pacing, zero filler words, every sentence counts.",
        "image_direction": "Minimalist fine art photography, single focal subject, negative space, soft ambient daylight, clean lines, monochrome or desaturated palette, 0 text, 0 UI.",
        "structure": ["The Thesis Statement", "Core Exposition", "A Single Provocative Quote", "The Synthesis"],
        "pattern": r"\b(minimal|minimalist|minimalism|reductive|quiet|zen|clean grid)\b"
    },
    "swiss_editorial": {
        "id": 6,
        "slug": "swiss_editorial",
        "name": "Swiss Editorial",
        "feeling": "Systematic, objective, mathematical, rational, modernist.",
        "characteristics": "International Typographic Style, strict mathematical grid, sans-serif typography (Helvetica/Inter), precise alignment, asymmetric tension, limited color palette.",
        "writing_style": "Structural, analytical, logical dissection of principles, systems architecture, objective frameworks, clear taxonomy.",
        "image_direction": "Geometric, architectural compositions, high contrast black and white or primary accent, structured angles, clean shadows, 0 text, 0 UI.",
        "structure": ["System Definition", "Structural Analysis", "Methodological Breakdown", "Case Application", "Empirical Conclusions"],
        "pattern": r"\b(swiss|international style|grid system|rationalist|helvetica|bauhaus|systematic)\b"
    },
    "art_directed": {
        "id": 7,
        "slug": "art_directed",
        "name": "Art-Directed Editorial",
        "feeling": "Bespoke, cinematic, dynamic, expressive.",
        "characteristics": "Each section composed intentionally around narrative beats. Variable scale headlines, bespoke pull quotes, custom thematic color shifts.",
        "writing_style": "Rhythmic, cinematic storytelling that ebbs and flows between macro philosophy and micro sensory detail.",
        "image_direction": "Bespoke concept art or conceptual editorial photography, unconventional framing, atmospheric haze, color-matched to mood, 0 text, 0 UI.",
        "structure": ["The Hook / Scene Setting", "The Tension / Conflict", "Deep Immersion", "The Climax / Breakthrough", "Lasting Resonance"],
        "pattern": r"\b(art directed|bespoke|curated|cinematic layout|immersive story)\b"
    },
    "typographic_editorial": {
        "id": 8,
        "slug": "typographic_editorial",
        "name": "Typographic Editorial",
        "feeling": "Bold, graphic, structural, intellectual.",
        "characteristics": "Typography as the primary visual element, enormous scale, unusual line breaks, oversized words, contrasting weights, rhythm.",
        "writing_style": "Rhythmic, punchy, manifestos, structural declarations, thought-provoking slogans and tight arguments.",
        "image_direction": "High-contrast abstract forms, sculpted shadows, architectural textures, monochrome starkness, 0 text, 0 UI.",
        "structure": ["The Proposition", "The Structural Breakdown", "Key Axiom", "The Counter-Argument", "The Manifesto"],
        "pattern": r"\b(typographic|typography|letterforms|kerning|type design|manifesto)\b"
    },
    "photography_editorial": {
        "id": 9,
        "slug": "photography_editorial",
        "name": "Photography Editorial",
        "feeling": "Visual-first, immersive, contemplative, visual storytelling.",
        "characteristics": "Full-bleed imagery, sequence-driven storytelling, detailed captions, minimal interface, visual rhythm.",
        "writing_style": "Evocative, observational, writing that complements and breathes around imagery rather than overcrowding it.",
        "image_direction": "Master-level 50mm/85mm documentary or fine-art photography, gorgeous bokeh, authentic human presence, location intimacy, 0 text, 0 UI.",
        "structure": ["Visual Opening", "Scene & Atmosphere", "Field Dispatch", "Sensory Detail", "Closing Frame"],
        "pattern": r"\b(photography|photographic|photojournalism|full-bleed|visual story|camera)\b"
    },
    "art_culture": {
        "id": 10,
        "slug": "art_culture",
        "name": "Art / Culture Editorial",
        "feeling": "Intellectual, curatorial, museum-grade, avant-garde.",
        "characteristics": "Unconventional compositions, sophisticated serif typography, lots of whitespace, gallery-grade presentation.",
        "writing_style": "Curatorial critique, artistic lineage analysis, philosophical reflections on society, culture, and meaning.",
        "image_direction": "Gallery installation atmosphere, sculptural art forms, museum spotlighting, evocative textures, abstract contemplation, 0 text, 0 UI.",
        "structure": ["Curatorial Introduction", "The Exhibition / Movement Context", "Formal Critique & Meaning", "Cultural Impact", "Curator's Epilogue"],
        "pattern": r"\b(art|culture|cultural|museum|gallery|exhibition|sculpture|painting|curator|biennale)\b"
    },
    "architecture_editorial": {
        "id": 11,
        "slug": "architecture_editorial",
        "name": "Architecture Editorial",
        "feeling": "Monumental, precise, spatial, sculptural.",
        "characteristics": "Geometric layouts, architectural photography, precise grids, thin typography, diagrams, plans, dramatic elevation shots.",
        "writing_style": "Spatial, structural, analyzing light, materials (concrete, glass, timber), proportions, environmental harmony, and urban philosophy.",
        "image_direction": "Architectural photography, Golden Hour or blue hour exterior/interior, raw concrete, glass reflections, clean perspective lines, tilt-shift lens feel, 0 text, 0 UI.",
        "structure": ["The Site & Urban Context", "Spatial Concept & Massing", "Materiality & Light Studies", "Structural Engineering Innovation", "Habitation & Legacy"],
        "pattern": r"\b(architecture|architectural|building|concrete|spatial|facade|urban planning|interior design)\b"
    },
    "design_editorial": {
        "id": 12,
        "slug": "design_editorial",
        "name": "Design Editorial",
        "feeling": "Craft-centric, analytical, beautiful, process-oriented.",
        "characteristics": "Visual case studies, typography focus, grid experimentation, diagrams, project documentation, strong art direction.",
        "writing_style": "Deep exploration of craft, design systems, usability ergonomics, aesthetic principles, and deliberate trade-offs.",
        "image_direction": "Design studio tabletop, tactile materials, prototype models, clean directional lighting, crisp industrial or graphic craft, 0 text, 0 UI.",
        "structure": ["The Creative Brief", "Design Philosophy", "Iterative Exploration", "The Final Form", "Design System Impact"],
        "pattern": r"\b(design system|product design|industrial design|craft|ergonomics|creative studio)\b"
    },
    "journalistic_editorial": {
        "id": 13,
        "slug": "journalistic_editorial",
        "name": "Journalistic Editorial",
        "feeling": "Serious, investigative, documentary, evidence-backed.",
        "characteristics": "Strong headlines, investigative storytelling, charts, quotes, timelines, photographs, verified source attribution.",
        "writing_style": "Meticulous investigative prose, chronological timelines, verified facts, multiple corroborated testimonies.",
        "image_direction": "Documentary reportage, realistic atmospheric conditions, candid interaction, authentic unvarnished scene, 0 text, 0 UI.",
        "structure": ["The Investigation Lead", "Chronology of Events", "The Document Trail", "On-the-Record Statements", "The Unanswered Questions"],
        "pattern": r"\b(investigative|journalistic|reportage|chronicle|expose|uncovered|evidence)\b"
    },
    "longform_editorial": {
        "id": 14,
        "slug": "longform_editorial",
        "name": "Long-Form Editorial",
        "feeling": "Deeply immersive, novelistic, comprehensive, definitive.",
        "characteristics": "Designed around a single monumental story. Prominent author/date metadata, heroic cover image, rich chapters, pull quotes, chapter dividers.",
        "writing_style": "Exhaustive, narrative non-fiction with character development, rich sensory detail, thematic depth, and authoritative pacing.",
        "image_direction": "Cinematic visual epic, panoramic establishing shot, atmospheric storytelling mood, cinematic color grading, 0 text, 0 UI.",
        "structure": ["Prologue / Establishing Scene", "Chapter I: The Genesis", "Chapter II: The Friction", "Chapter III: The Anatomy", "Chapter IV: The Frontier", "Epilogue"],
        "pattern": r"\b(longform|deep dive|in-depth|exhaustive|definitive guide|masterclass|epic)\b"
    },
    "essay_literary": {
        "id": 15,
        "slug": "essay_literary",
        "name": "Essay / Literary Editorial",
        "feeling": "Contemplative, scholarly, quiet, intellectually rich.",
        "characteristics": "Narrow reading column, classic serif typography, subtle metadata, footnotes, pull quotes, restrained imagery.",
        "writing_style": "Reflective, philosophical, personal yet rigorous essayistic prose with literary allusions, metaphor, and graceful cadence.",
        "image_direction": "Moody, evocative still life or quiet landscape, soft diffused northern window light, painterly quality, muted earth tones, 0 text, 0 UI.",
        "structure": ["The Philosophical Premise", "Meditative Exploration", "Literary & Historical Counterpoints", "Personal Observation", "The Quiet Conclusion"],
        "pattern": r"\b(essay|literary|philosophical|treatise|reflection|meditation|monograph)\b"
    },
    "academic_editorial": {
        "id": 16,
        "slug": "academic_editorial",
        "name": "Academic Editorial",
        "feeling": "Rigorous, peer-reviewed, empirical, structured.",
        "characteristics": "References, citations, figures, structured headings, footnotes, conservative typography, empirical tables.",
        "writing_style": "Precise scholarly academic prose, passive and active methodological explanations, rigorous data citation, statistical boundaries.",
        "image_direction": "Scientific visualization, molecular or algorithmic render, microscopy or laboratory equipment, crisp technical clarity, 0 text, 0 UI.",
        "structure": ["Abstract & Problem Formulation", "Literature Review & Prior Art", "Methodology / Mechanism", "Empirical Findings & Data", "Discussion & Limitations", "References"],
        "pattern": r"\b(academic|peer-reviewed|journal|empirical|scientific study|methodology|citations)\b"
    },
    "tech_editorial": {
        "id": 17,
        "slug": "tech_editorial",
        "name": "Tech Editorial",
        "feeling": "Forward-looking, cutting-edge, analytical. Wired meets Stripe Press.",
        "characteristics": "Strong headlines, technical photography, architecture diagrams, code blocks, technical metadata, deep engineering storytelling.",
        "writing_style": "Engineering-first, precise technical teardowns, latency/memory tradeoffs, production architectures, zero superficial marketing fluff.",
        "image_direction": "Futuristic industrial technology, glowing optical fibers, clean server silicon, abstract computational geometry, neon accents against dark slate, 0 text, 0 UI.",
        "structure": ["The Architectural Challenge", "System Architecture & Tradeoffs", "Production Implementation & Code", "Benchmark & Latency Analysis", "Failure Modes & Edge Cases", "The Future Stack"],
        "pattern": r"\b(tech|technology|engineering|software|devops|cloud|ai|kubernetes|compiler|architecture|infrastructure)\b"
    },
    "business_editorial": {
        "id": 18,
        "slug": "business_editorial",
        "name": "Business Editorial",
        "feeling": "Executive, strategic, data-driven. Bloomberg meets Financial Times.",
        "characteristics": "Data charts, financial metrics, restrained color palette (deep navy, charcoal, gold), data visualization, editorial portraiture.",
        "writing_style": "Executive-grade strategic analysis, capital allocation frameworks, unit economics, macroeconomic levers, and institutional risk.",
        "image_direction": "High-altitude financial district photography at dusk, trading floor geometry, sleek corporate glass towers, executive board ambiance, 0 text, 0 UI.",
        "structure": ["Executive Summary & Market Signal", "Macroeconomic Context", "Unit Economics & Financial Anatomy", "Competitive Moats & Valuation", "Strategic Risk Matrix"],
        "pattern": r"\b(business|finance|financial|markets|economy|macro|venture capital|equity|investing|wall street|bloomberg)\b"
    },
    "lifestyle_editorial": {
        "id": 19,
        "slug": "lifestyle_editorial",
        "name": "Lifestyle Editorial",
        "feeling": "Warm, relaxed, aspirational, tactile, human.",
        "characteristics": "Warm palette, relaxed multi-column grids, lifestyle photography, wellness and living stories, welcoming aesthetic.",
        "writing_style": "Conversational yet refined, inspiring, sensory-rich, celebrating daily rituals, homes, and mindful living.",
        "image_direction": "Sun-drenched interiors, morning coffee steam, organic linen textures, lush indoor botanicals, warm golden hour tones, 0 text, 0 UI.",
        "structure": ["The Morning Ritual", "The Living Space", "Sensory Details", "Curated Essentials", "Mindful Living Notes"],
        "pattern": r"\b(lifestyle|wellness|living|home|interior|mindfulness|rituals|cozy)\b"
    },
    "travel_editorial": {
        "id": 20,
        "slug": "travel_editorial",
        "name": "Travel Editorial",
        "feeling": "Evocative, wanderlust, cinematic, cultural.",
        "characteristics": "Enormous full-bleed photography, location typography, maps, curated itinerary info, field storytelling, full-screen chapters.",
        "writing_style": "Immersive travel journalism, local dialect and customs, culinary sensory descriptions, off-the-beaten-path expeditions.",
        "image_direction": "Breathtaking landscape or atmospheric alleyway, dramatic natural light (mist, golden hour, starlight), authentic local culture, 35mm film grain, 0 text, 0 UI.",
        "structure": ["Arrival & Sensory Shock", "The Hidden Neighborhood", "The Culinary Table", "Local Voices & Lore", "Curated 72-Hour Expedition Plan"],
        "pattern": r"\b(travel|destination|itinerary|wanderlust|expedition|journey|hotel|voyage|nomad)\b"
    },
    "food_editorial": {
        "id": 21,
        "slug": "food_editorial",
        "name": "Food / Culinary Editorial",
        "feeling": "Appetizing, artisanal, sensory, mouthwatering, chef-driven.",
        "characteristics": "Gourmet food photography, recipe typography, ingredient lists, artisanal culinary stories, warm earthy palette.",
        "writing_style": "Sensory-rich food writing, maillard reaction chemistry, pan sauce emulsions, seasonal terroir, chef technique masterclass.",
        "image_direction": "Artisanal culinary photography, rustic stoneware, drizzle of olive oil, steam rising, shallow depth of field, natural side lighting, 0 text, 0 UI.",
        "structure": ["The Flavor Concept & Terroir", "The Secret Culinary Technique", "The Artisanal Recipe & Mise en Place", "Emulsion Science & Chef Tips", "Tasting Notes & Pairings"],
        "pattern": r"\b(food|culinary|recipe|cooking|gastronomy|chef|gourmet|baking|pastry|dish|kitchen)\b"
    },
    "sports_editorial": {
        "id": 22,
        "slug": "sports_editorial",
        "name": "Sports Editorial",
        "feeling": "High-octane, dynamic, athletic, dramatic.",
        "characteristics": "Action freeze-frame photography, bold typography, statistics, scores, rankings, dynamic angled layouts.",
        "writing_style": "Tactical sports breakdown, momentum shifts, athletic physiology, pressure moments, play-by-play tactical analysis.",
        "image_direction": "High-shutter speed sports action photography, sweat droplets in stadium floodlights, motion blur background, raw emotional tension, 0 text, 0 UI.",
        "structure": ["The Championship Moment", "Tactical Scheme Breakdown", "Physicality & Performance Metrics", "The Decisive Turn", "Legacy Analysis"],
        "pattern": r"\b(sports|athlete|athletic|football|basketball|soccer|tennis|championship|match|olympic)\b"
    },
    "gaming_cinematic": {
        "id": 23,
        "slug": "gaming_cinematic",
        "name": "Gaming Cinematic Editorial",
        "feeling": "Atmospheric, serious, systems-driven, monumental. Game craft as fine art.",
        "characteristics": "Huge game engine imagery, dramatic headlines, systems breakdowns, technical frame pacing charts, dark cinematic UI, zero tacky neon.",
        "writing_style": "Literary video game critique, ludonarrative harmony, combat mechanics dissection, level architecture, atmospheric scene-setting.",
        "image_direction": "Cinematic in-engine screenshot aesthetic, photorealistic Unreal Engine 5 lighting, volumetric fog, dramatic hero silhouette, vast landscapes, 0 HUD, 0 text.",
        "structure": ["The World & Atmosphere", "Systems Architecture & Combat Mechanics", "Level Design & Spatial Flow", "Narrative & Ludonarrative Tension", "The Critical Verdict"],
        "pattern": r"\b(gaming|games|gameplay|playstation|ps5|xbox|steam|switch|rpg|fps|esports|game design|unreal engine)\b"
    },
    "catalog_editorial": {
        "id": 24,
        "slug": "catalog_editorial",
        "name": "Catalog Editorial",
        "feeling": "Curated, modular, tactile, product-oriented.",
        "characteristics": "Structured modular grids, crisp product photography, specifications, categories, materials, pricing, comparisons.",
        "writing_style": "Curatorial product reviews, craftsmanship provenance, durability tests, material specifications, ergonomic evaluation.",
        "image_direction": "Clean studio product photography on minimalist podium, soft shadows, neutral background, exquisite material texture, 0 text, 0 UI.",
        "structure": ["The Collection Overview", "Product Teardown & Specs", "Materials & Provenance", "Comparative Matrix", "Buying Recommendations"],
        "pattern": r"\b(catalog|lookbook|curated products|merchandise|specifications|collection items)\b"
    },
    "zine_editorial": {
        "id": 25,
        "slug": "zine_editorial",
        "name": "Zine Editorial",
        "feeling": "Underground, rebellious, indie, tactile, imperfect.",
        "characteristics": "Unconventional typography, rough layouts, photocopy textures, irregular alignments, collage elements, authentic counter-culture feel.",
        "writing_style": "Raw, candid, punchy, unfiltered, conversational, energetic, anti-corporate voice.",
        "image_direction": "Monochrome xerox or high-contrast risograph texture, flash photography, raw candid moments, indie subculture grit, 0 text, 0 UI.",
        "structure": ["Raw Manifesto", "Street Dispatches", "DIY Blueprint", "Subcultural Critique", "Parting Roar"],
        "pattern": r"\b(zine|indie|underground|diy|counter-culture|subculture|fanzine)\b"
    },
    "brutalist_editorial": {
        "id": 26,
        "slug": "brutalist_editorial",
        "name": "Brutalist Editorial",
        "feeling": "Stark, unadorned, industrial, anti-commercial, raw.",
        "characteristics": "Monochrome black/white, raw typography, hard borders (1px solid black), zero decoration, exposed grid, uncompromising truth to materials.",
        "writing_style": "Direct, unembellished, clinical, provocative, sharp, stripped of pleasantries and corporate fluff.",
        "image_direction": "Stark black and white photography, harsh flash, brutalist concrete architecture, exposed industrial metal, harsh shadows, 0 text, 0 UI.",
        "structure": ["Premise", "The Machine", "Dissection", "Systemic Failure", "Terminal Point"],
        "pattern": r"\b(brutalist|brutalism|raw typography|monochrome grid|stark|industrial)\b"
    },
    "experimental_editorial": {
        "id": 27,
        "slug": "experimental_editorial",
        "name": "Experimental Editorial",
        "feeling": "Avant-garde, rule-breaking, chaotic yet controlled, boundary-pushing.",
        "characteristics": "Overlapping typography, dynamic grid shifts, unexpected alignments, artistic friction, kinetic energy.",
        "writing_style": "Experimental non-linear prose, poetic stream-of-consciousness anchored by sharp intellectual insights.",
        "image_direction": "Glitch aesthetics, double exposure, refracted light through prisms, experimental darkroom manipulation, surreal conceptual art, 0 text, 0 UI.",
        "structure": ["The Disruption", "Fragmented Observations", "The Shift", "New Paradigms", "Open Horizon"],
        "pattern": r"\b(experimental|avant-garde|kinetic|unconventional|boundary-pushing)\b"
    },
    "contemporary_editorial": {
        "id": 28,
        "slug": "contemporary_editorial",
        "name": "Contemporary Editorial",
        "feeling": "Sleek, modern, airy, polished, state-of-the-art.",
        "characteristics": "Modern sans-serif typography, oversized type, subtle micro-animations, responsive asymmetric grids, minimal color accents, editorial photography.",
        "writing_style": "Crisp, insightful modern journalism, conversational authority, accessible depth, modern culture commentary.",
        "image_direction": "Sleek contemporary photography, balanced natural lighting, clean architectural lines, curated color palette, 0 text, 0 UI.",
        "structure": ["The Modern Lens", "The Underlying Shift", "Key Developments", "What it Means", "Looking Ahead"],
        "pattern": r"\b(contemporary|modern editorial|clean contemporary|state of the art)\b"
    },
    "editorial_luxury": {
        "id": 29,
        "slug": "editorial_luxury",
        "name": "Editorial Luxury",
        "feeling": "Heirloom, majestic, gilded, timeless, ultra-refined. Haute Couture + High Jewelry.",
        "characteristics": "Cream/charcoal/black/gold palette, elegant serif typography, huge photography, almost zero UI distractions, sophisticated spacing, restrained accents.",
        "writing_style": "Aristocratic, highly polished, reverent of master craft, heirloom durability, haute couture savoir-faire, and timeless prestige.",
        "image_direction": "Luxury editorial photography, gilded interior details, 24k gold leaf glints, fine emerald cuts, sculpted silk velvet, twilight Palais-Royal courtyard, 0 text, 0 UI.",
        "structure": ["The Heritage / Prologue", "The Master Savoir-Faire", "Material Alchemy (Emeralds, Silk, Bullion)", "Atelier Notes & Provenance", "The Heirloom Verdict"],
        "pattern": r"\b(luxury|luxary|gilded|heirloom|haute horlogerie|place vendome|bespoke atelier|fine jewelry|savoir-faire)\b"
    },
    "editorial_noir": {
        "id": 30,
        "slug": "editorial_noir",
        "name": "Editorial Noir",
        "feeling": "Cinematic dark mode, enigmatic, high-contrast, moody.",
        "characteristics": "True black, charcoal, monochrome photography, luminous white typography, single rich accent (gold, crimson, or amber), cinematic imagery.",
        "writing_style": "Atmospheric, tense, literary noir, sharp contrast, philosophical tension, nocturnal gravity.",
        "image_direction": "Cinematic chiaroscuro photography, deep shadows, single warm key light, moody silhouette, wet cobblestones or midnight studio, 0 text, 0 UI.",
        "structure": ["The Midnight Opening", "Shadow & Structure", "The Critical Friction", "Atmospheric Tension", "Final Resolution in the Dark"],
        "pattern": r"\b(noir|dark editorial|cinematic dark|charcoal|chiaroscuro|monochrome dark)\b"
    },
    "editorial_collage": {
        "id": 31,
        "slug": "editorial_collage",
        "name": "Editorial Collage",
        "feeling": "Tactile, artistic, layered, multi-dimensional.",
        "characteristics": "Layered photography, scanned ephemera, paper textures, overlapping typography, scrapbook energy translated into high design.",
        "writing_style": "Layered, multi-vocal, assembling disparate cultural threads into a unified tapestry of thought.",
        "image_direction": "Artistic collage composition, vintage torn paper edges, overlaid botanical and architectural sketches, mixed-media textures, 0 text, 0 UI.",
        "structure": ["The Fragment", "The Mosaic", "Interlocking Threads", "The Unified Picture", "Coda"],
        "pattern": r"\b(collage|mixed media|layered|ephemera|textures|paper art)\b"
    },
    "editorial_scrapbook": {
        "id": 32,
        "slug": "editorial_scrapbook",
        "name": "Editorial Scrapbook",
        "feeling": "Intimate, personal, annotated, authentic, journal-like.",
        "characteristics": "Field notes, annotations, polaroid-style photography, journal margins, handwritten flourishes.",
        "writing_style": "First-person reflective journal, intimate confessions of craft, field notes, lessons learned behind the scenes.",
        "image_direction": "Polaroid or snapshot aesthetic, authentic workbench mess, field notebook with annotations, candid natural light, 0 text, 0 UI.",
        "structure": ["Journal Entry: Day Zero", "Field Discoveries", "The Mistakes & Breakages", "The Unexpected Revelation", "Notebook Closing"],
        "pattern": r"\b(scrapbook|journal|field notes|annotated|personal diary|behind the scenes)\b"
    },
    "editorial_documentary": {
        "id": 33,
        "slug": "editorial_documentary",
        "name": "Editorial Documentary",
        "feeling": "Truth-seeking, historical, grave, authentic.",
        "characteristics": "Documentary photographs, captions with exact dates and coordinates, quotes, historical timelines, minimal decoration.",
        "writing_style": "Objective documentary chronicle, verified timestamps, historical depth, unvarnished human truth.",
        "image_direction": "Magnum-style documentary photography, authentic human emotion, natural unposed environment, black and white or Kodachrome color science, 0 text, 0 UI.",
        "structure": ["The Coordinates & Date", "Historical Context", "The Human Subject", "The Systemic Reality", "Archival Epilogue"],
        "pattern": r"\b(documentary|photojournalist|chronicle|magnum|historical record|archive)\b"
    },
    "editorial_portfolio": {
        "id": 34,
        "slug": "editorial_portfolio",
        "name": "Editorial Portfolio",
        "feeling": "Curated, prestigious, personal brand as a fine magazine.",
        "characteristics": "Magazine-like layout for projects: hero intro, selected work chapters, oversized imagery, deep project narratives, notes section.",
        "writing_style": "Artisan case narrative, creator philosophy, creative dilemmas solved, client vision realized.",
        "image_direction": "Pristine case study showcase, finished work in context, refined gallery lighting, 0 text, 0 UI.",
        "structure": ["The Creator's Ethos", "Selected Works", "Case Breakdown", "Artistic Philosophy", "Collaboration Invitation"],
        "pattern": r"\b(portfolio|selected work|creative director portfolio|case showcase)\b"
    },
    "editorial_case_study": {
        "id": 35,
        "slug": "editorial_case_study",
        "name": "Editorial Case Study",
        "feeling": "Exhaustive, methodical, transformative, problem-solving.",
        "characteristics": "Deep structure: Problem -> Context -> Research -> Approach -> System -> Implementation -> Results -> Lessons.",
        "writing_style": "Methodical, transparent engineering or design breakdown, metrics, failures overcome, definitive lessons.",
        "image_direction": "System architecture diagram or physical product prototype, clean studio environment, diagnostic lighting, 0 text, 0 UI.",
        "structure": ["Executive Problem Statement", "Context & Root Cause Analysis", "Research & Methodology", "The Architectural Solution", "Empirical Results & Metrics", "Lessons for Practitioners"],
        "pattern": r"\b(case study|problem solution|teardown|architecture case|implementation study)\b"
    },
    "editorial_storytelling": {
        "id": 36,
        "slug": "editorial_storytelling",
        "name": "Editorial Storytelling / Scrollytelling",
        "feeling": "Cinematic, pacing-driven, experiential, narrative crescendo.",
        "characteristics": "Designed for digital scroll pacing: full-bleed visual transitions, dynamic callouts, progressive disclosure of ideas.",
        "writing_style": "Screenplay-like narrative pacing, rising tension, visceral scene-setting, memorable dramatic turns.",
        "image_direction": "Cinematic visual storyboard, wide anamorphic aspect ratio aesthetic, volumetric lighting, epic scale, 0 text, 0 UI.",
        "structure": ["The Inciting Incident", "The Descent / Rising Action", "The Crucible / Technical Core", "The Revelation", "The New World Order"],
        "pattern": r"\b(storytelling|scrollytelling|narrative arc|cinematic scroll|interactive story)\b"
    }
}


def detect_editorial_archetype(
    site_name: str = "",
    site_desc: str = "",
    categories: Optional[List[str]] = None,
    titles: Optional[List[str]] = None,
    fallback_niche: str = ""
) -> Dict[str, Any]:
    """
    Exhaustively scores all 36 Editorial Design Archetypes against target website signals.
    Returns the highest-ranking archetype dictionary.
    """
    cats = " ".join(categories or [])
    ts = " ".join(titles or [])
    combined = f"{site_name} {site_desc} {cats} {ts} {fallback_niche}".lower()

    # Prioritize multi-word matches
    best_arch = None
    best_score = 0

    for slug, arch in EDITORIAL_DESIGN_ARCHETYPES.items():
        matches = re.findall(arch["pattern"], combined, re.IGNORECASE)
        score = len(matches)
        
        # Bonus weights for site name or description exact matches
        if any(w in site_name.lower() for w in ["couture", "fashion", "luxury", "vogue", "haute"]) and slug in ("fashion_editorial", "editorial_luxury"):
            score += 10
        if any(w in site_name.lower() for w in ["game", "gaming", "esport"]) and slug in ("gaming_cinematic", "classic_magazine"):
            score += 10
        if any(w in site_name.lower() for w in ["food", "recipe", "culinary", "chef"]) and slug == "food_editorial":
            score += 10
        if any(w in site_name.lower() for w in ["tech", "cloud", "devops", "code"]) and slug == "tech_editorial":
            score += 10

        if score > best_score:
            best_score = score
            best_arch = arch

    # Default fallback: Contemporary Editorial (#28) or Editorial Luxury (#29) if luxury signals exist
    if not best_arch or best_score == 0:
        if "lux" in combined or "gold" in combined or "couture" in combined or "editorial" in combined:
            return EDITORIAL_DESIGN_ARCHETYPES["editorial_luxury"]
        return EDITORIAL_DESIGN_ARCHETYPES["contemporary_editorial"]

    return best_arch


def get_design_archetype_by_slug(slug: Optional[str]) -> Dict[str, Any]:
    """Safely retrieves archetype by slug, defaulting to contemporary_editorial."""
    if not slug:
        return EDITORIAL_DESIGN_ARCHETYPES["contemporary_editorial"]
    slug_clean = slug.strip().lower()
    return EDITORIAL_DESIGN_ARCHETYPES.get(slug_clean, EDITORIAL_DESIGN_ARCHETYPES["contemporary_editorial"])
