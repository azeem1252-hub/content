"""
Closed-Loop Performance Harvest (Pillar VI: Self-Improving Feedback Engine).

The auditor's triage functions previously had no data feed: they accepted
impressions/clicks/position as arguments that nothing ever supplied. This module
is that feed. On a schedule it:

  1. Ingests first-party analytics (Search Console / GA4 / PostHog / Plausible).
  2. Measures real AI-search citations for the site's tracked queries.
  3. Captures SERP rank snapshots for its target keywords.
  4. Runs a bounded technical audit and stores findings.
  5. Derives backlink/link-gap opportunities from live SERP competitors.
  6. Rebuilds the entity knowledge graph when it is missing or stale.
  7. Records an empirical learning to `.agents/MEMORY.md`.

Everything degrades gracefully: unconfigured sources are reported as
``configured: False`` and skipped, never fabricated.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
from config import BASE_DIR
from storage.db import (
    get_all_websites,
    get_default_website,
    get_all_pipeline_runs,
    get_all_posts,
    save_rank_snapshots,
    get_kg_nodes,
)
from pipeline.adapters.brand_dna import append_memory_learning

logger = logging.getLogger("pipeline.harvest")

STATE_FILE = BASE_DIR / "data" / "harvest_state.json"

# Bound network work per website so one harvest pass stays cheap and fast.
MAX_RANK_KEYWORDS = 5
MAX_AI_QUERIES = 10


def _domain_of(url: str) -> str:
    from urllib.parse import urlparse
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc[4:] if netloc.startswith("www.") else netloc
    except Exception:  # noqa: BLE001
        return ""


def _load_state() -> Dict[str, Any]:
    try:
        if STATE_FILE.exists():
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        pass
    return {}


def _save_state(state: Dict[str, Any]) -> None:
    try:
        STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Could not persist harvest state: {e}")


def gather_tracked_queries(website_id: Optional[str], limit: int = MAX_AI_QUERIES) -> List[str]:
    """Derives tracked queries from the website's published titles and keywords."""
    queries: List[str] = []
    seen = set()

    runs = get_all_pipeline_runs(limit=100)
    if website_id:
        runs = [r for r in runs if r.get("website_id") == website_id]

    for run in runs:
        candidates: List[str] = []
        if run.get("keywords"):
            candidates.extend(str(k) for k in run["keywords"])
        if run.get("title"):
            candidates.append(str(run["title"]))
        for cand in candidates:
            clean = cand.strip()
            if clean and clean.lower() not in seen:
                seen.add(clean.lower())
                queries.append(clean)
        if len(queries) >= limit:
            break

    if not queries:
        for post in get_all_posts(limit=limit, status=None):
            title = (post.get("title") or "").strip()
            if title and title.lower() not in seen:
                seen.add(title.lower())
                queries.append(title)

    return queries[:limit]


def run_website_harvest(website: Dict[str, Any], check_cwv: bool = True) -> Dict[str, Any]:
    """Runs the full harvest cycle for one website."""
    website_id = website.get("id")
    site_url = str(website.get("url") or "").strip()
    site_name = website.get("name") or "Editorial Publication"
    domain = _domain_of(site_url)
    base_url = site_url.split("/api/")[0].rstrip("/") if "/api/" in site_url else site_url.rstrip("/")
    queries = gather_tracked_queries(website_id)

    result: Dict[str, Any] = {
        "website_id": website_id,
        "site_name": site_name,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "analytics": None,
        "ai_visibility": None,
        "ranks": None,
        "technical_audit": None,
        "backlinks": None,
        "knowledge_graph": None,
    }

    # 1. First-party analytics
    try:
        from pipeline.adapters.analytics_client import harvest_search_performance
        result["analytics"] = harvest_search_performance(website_id)
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] Analytics harvest failed: {e}")
        result["analytics"] = {"configured": False, "error": str(e)}

    # 2. AI visibility measurement
    try:
        from pipeline.adapters.ai_visibility import measure_queries, provider_status
        status = provider_status()
        if status["configured"] and queries:
            snapshots = measure_queries(website_id, queries[:MAX_AI_QUERIES], site_name, domain)
            measured = [s for s in snapshots if s.get("measured")]
            if measured:
                from storage.db import save_ai_visibility_snapshots
                save_ai_visibility_snapshots(website_id, measured)
            result["ai_visibility"] = {
                "configured": True,
                "provider": status["provider"],
                "queries_measured": len(measured),
                "cited": sum(1 for s in measured if s.get("brand_cited")),
            }
        else:
            result["ai_visibility"] = {"configured": False, "reason": status.get("note") or "no provider"}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] AI visibility harvest failed: {e}")
        result["ai_visibility"] = {"configured": False, "error": str(e)}

    # 3. SERP rank snapshots
    try:
        from pipeline.adapters.serp_client import build_rank_snapshot, provider_status as serp_status
        serp = serp_status()
        if serp["configured"] and domain and queries:
            snapshots = []
            for keyword in queries[:MAX_RANK_KEYWORDS]:
                snap = build_rank_snapshot(website_id, keyword, domain)
                if snap.get("measured"):
                    snapshots.append(snap)
            if snapshots:
                save_rank_snapshots(website_id, snapshots)
            result["ranks"] = {"configured": True, "provider": serp["provider"], "snapshots": len(snapshots)}
        else:
            result["ranks"] = {"configured": False, "reason": serp.get("note") or "no provider"}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] Rank harvest failed: {e}")
        result["ranks"] = {"configured": False, "error": str(e)}

    # 4. Technical audit
    try:
        from pipeline.adapters.technical_audit import run_technical_audit
        if base_url.startswith("http"):
            audit = run_technical_audit(website_id, base_url, check_cwv=check_cwv)
            result["technical_audit"] = {
                "configured": True,
                "pages_crawled": audit.get("pages_crawled"),
                "finding_count": audit.get("finding_count"),
                "by_severity": audit.get("by_severity"),
            }
        else:
            result["technical_audit"] = {"configured": False, "reason": "no absolute site URL"}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] Technical audit failed: {e}")
        result["technical_audit"] = {"configured": False, "error": str(e)}

    # 5. Backlink intelligence + link-gap prospecting
    try:
        from pipeline.adapters.backlink_analyzer import analyze_link_gaps, summarize_backlinks
        from storage.db import replace_backlink_opportunities
        gaps = analyze_link_gaps(website_id, queries, domain) if domain else {"opportunities": [], "measured": False}
        if gaps.get("opportunities"):
            replace_backlink_opportunities(website_id, gaps["opportunities"])
        result["backlinks"] = {
            "measured": gaps.get("measured", False),
            "opportunities": len(gaps.get("opportunities") or []),
            "profile": summarize_backlinks(website_id),
        }
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] Backlink harvest failed: {e}")
        result["backlinks"] = {"measured": False, "error": str(e)}

    # 6. Knowledge graph (build when missing)
    try:
        from pipeline.adapters.knowledge_graph import build_knowledge_graph, summarize_graph
        if not get_kg_nodes(website_id):
            graph = build_knowledge_graph(website_id, site_name=site_name, site_url=base_url)
            result["knowledge_graph"] = {"built": True, **graph}
        else:
            result["knowledge_graph"] = {"built": False, **summarize_graph(website_id)}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"[{site_name}] Knowledge graph refresh failed: {e}")
        result["knowledge_graph"] = {"built": False, "error": str(e)}

    # 7. Record the empirical learning
    try:
        analytics_ok = bool((result.get("analytics") or {}).get("configured"))
        ai = result.get("ai_visibility") or {}
        tech = result.get("technical_audit") or {}
        append_memory_learning(
            "Closed-Loop Performance Harvest",
            f"Harvested '{site_name}': analytics={'on' if analytics_ok else 'off'}, "
            f"AI citations={ai.get('cited', 0)}/{ai.get('queries_measured', 0)}, "
            f"technical findings={tech.get('finding_count', 0)}, "
            f"link opportunities={(result.get('backlinks') or {}).get('opportunities', 0)}."
        )
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Memory learning skipped: {e}")

    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    return result


def run_full_harvest(check_cwv: bool = True) -> Dict[str, Any]:
    """Runs the harvest for every connected website (falling back to the default)."""
    websites = get_all_websites()
    if not websites:
        default = get_default_website()
        websites = [default] if default else []

    results = [run_website_harvest(site, check_cwv=check_cwv) for site in websites]

    state = _load_state()
    state["last_run_at"] = datetime.now(timezone.utc).isoformat()
    state["websites"] = {
        r["website_id"] or "_default": {"finished_at": r.get("finished_at")}
        for r in results
    }
    _save_state(state)

    logger.info(f"Performance harvest complete for {len(results)} website(s).")
    return {
        "ran_at": state["last_run_at"],
        "website_count": len(results),
        "websites": results,
    }


class PerformanceHarvestScheduler:
    """Background loop that runs the closed-loop harvest on a fixed interval."""

    def __init__(self) -> None:
        self._running = False
        self._task: Optional[asyncio.Task] = None

    def _interval_seconds(self) -> int:
        try:
            hours = int(getattr(config, "PERFORMANCE_HARVEST_INTERVAL_HOURS", 24) or 24)
        except (TypeError, ValueError):
            hours = 24
        return max(300, hours * 3600)

    def start(self) -> None:
        if self._running:
            return
        if not getattr(config, "PERFORMANCE_HARVEST_ENABLED", True):
            logger.info("Performance harvest scheduler disabled (PERFORMANCE_HARVEST_ENABLED=false).")
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        logger.info("Closed-loop Performance Harvest Scheduler started.")

    def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
        logger.info("Performance Harvest Scheduler stopped.")

    async def _loop(self) -> None:
        # Small initial delay so the studio finishes starting before network work.
        await asyncio.sleep(45)
        while self._running:
            try:
                state = _load_state()
                last = state.get("last_run_at")
                due = True
                if last:
                    try:
                        last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
                        elapsed = (datetime.now(timezone.utc) - last_dt).total_seconds()
                        due = elapsed >= self._interval_seconds()
                    except Exception:  # noqa: BLE001
                        due = True
                if due:
                    await asyncio.to_thread(run_full_harvest)
            except asyncio.CancelledError:
                break
            except Exception as e:  # noqa: BLE001
                logger.error(f"Performance harvest loop error: {e}")
            await asyncio.sleep(600)

    def run_now(self) -> Dict[str, Any]:
        """On-demand harvest for the Studio UI / API."""
        return run_full_harvest()

    def status(self) -> Dict[str, Any]:
        state = _load_state()
        return {
            "enabled": bool(getattr(config, "PERFORMANCE_HARVEST_ENABLED", True)),
            "running": self._running,
            "interval_hours": self._interval_seconds() // 3600,
            "last_run_at": state.get("last_run_at"),
        }


performance_harvest_scheduler = PerformanceHarvestScheduler()
