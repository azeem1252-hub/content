import os
import re
import json
import logging
import time
from typing import Optional

import config

logger = logging.getLogger("pipeline.llm_client")

# Wall-clock cap per provider request. Without it a hung connection can stall a
# run indefinitely; call_llm does its own bounded retries and provider fallback.
LLM_REQUEST_TIMEOUT = float(os.getenv("LLM_REQUEST_TIMEOUT", "90") or 90)

# Message fragments that indicate a *permanent* failure: retrying or waiting
# only delays the cross-provider fallback (e.g. a blocked/invalid API key).
_NON_TRANSIENT_ERROR_HINTS = (
    "unauthorized", "invalid api key", "invalid_api_key", "incorrect api key",
    "permission", "forbidden", "access denied", "not found", "model_not_found",
    "invalid request", "context length", "context_length", "authentication",
)

# Message fragments that indicate a transient failure worth retrying.
_TRANSIENT_ERROR_HINTS = (
    "429", "rate limit", "rate_limit", "too many requests", "timeout",
    "timed out", "read timeout", "connect", "connection", "reset by peer",
    "temporarily", "overloaded", "unavailable", "internal server error",
    "internal error", "bad gateway", "gateway timeout", "deadline",
    "try again", "service error", "server error",
)


def _extract_status_code(err: Exception) -> Optional[int]:
    """Best-effort extraction of an HTTP status code from provider exceptions."""
    for attr in ("status_code", "http_status", "code"):
        val = getattr(err, attr, None)
        if isinstance(val, int) and 100 <= val <= 599:
            return val
    response = getattr(err, "response", None)
    code = getattr(response, "status_code", None)
    if isinstance(code, int) and 100 <= code <= 599:
        return code
    match = re.search(r"\b([45]\d{2})\b", str(err))
    return int(match.group(1)) if match else None


def is_transient_llm_error(err: Exception) -> bool:
    """Classifies an LLM exception as retryable (transient) or permanent.

    Status codes win over text heuristics: 5xx/429/408/409/425 retry, other
    4xx fail fast so the alternate provider takes over immediately.
    """
    code = _extract_status_code(err)
    if code is not None:
        if code in (408, 409, 425, 429) or 500 <= code < 600:
            return True
        if 400 <= code < 500:
            return False
    msg = str(err).lower()
    if any(hint in msg for hint in _NON_TRANSIENT_ERROR_HINTS):
        return False
    return any(hint in msg for hint in _TRANSIENT_ERROR_HINTS)

import httpx
from typing import Dict, Any, List

class HTTPChatResponse:
    def __init__(self, content: str):
        self.content = content


class HTTPOpenAICompatibleChatModel:
    def __init__(
        self,
        endpoint_url: str,
        api_key: str,
        model: str,
        temperature: float = 0.7,
        timeout: float = LLM_REQUEST_TIMEOUT,
        extra_headers: Optional[Dict[str, str]] = None
    ):
        self.endpoint_url = endpoint_url
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.timeout = timeout
        self.extra_headers = extra_headers or {}

    def invoke(self, messages) -> HTTPChatResponse:
        formatted = []
        for m in messages:
            role = "user"
            content = ""
            if hasattr(m, "type"):
                if m.type in ("system", "system_message"):
                    role = "system"
                elif m.type in ("ai", "assistant"):
                    role = "assistant"
                else:
                    role = "user"
                content = str(getattr(m, "content", ""))
            elif isinstance(m, dict):
                role = m.get("role", "user")
                content = m.get("content", "")
            else:
                content = str(m)
            formatted.append({"role": role, "content": content})

        headers = {
            "Content-Type": "application/json",
            **self.extra_headers
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "model": self.model,
            "messages": formatted,
            "temperature": self.temperature,
        }

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.endpoint_url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"HTTP {resp.status_code} from {self.endpoint_url}: {resp.text[:300]}")
            data = resp.json()
            choices = data.get("choices", [])
            if not choices:
                raise RuntimeError(f"No choices returned from LLM provider: {resp.text[:300]}")
            msg = choices[0].get("message", {})
            content = msg.get("content")
            if content is None:
                # Some reasoning models (e.g. DeepSeek-R1, Qwen reasoning) return reasoning_content
                content = msg.get("reasoning_content") or msg.get("reasoning") or ""
            return HTTPChatResponse(content=str(content))


class HTTPAnthropicChatModel:
    def __init__(
        self,
        api_key: str,
        model: str = "claude-3-7-sonnet-20250219",
        temperature: float = 0.7,
        timeout: float = LLM_REQUEST_TIMEOUT
    ):
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.timeout = timeout
        self.endpoint_url = "https://api.anthropic.com/v1/messages"

    def invoke(self, messages) -> HTTPChatResponse:
        system_prompts = []
        formatted = []
        for m in messages:
            content = str(getattr(m, "content", m))
            m_type = getattr(m, "type", "user")
            if m_type in ("system", "system_message"):
                system_prompts.append(content)
            elif m_type in ("ai", "assistant"):
                formatted.append({"role": "assistant", "content": content})
            else:
                formatted.append({"role": "user", "content": content})

        if not formatted:
            formatted = [{"role": "user", "content": "Hello"}]

        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": formatted,
            "max_tokens": 4096,
            "temperature": self.temperature,
        }
        if system_prompts:
            payload["system"] = "\n\n".join(system_prompts)

        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.endpoint_url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"HTTP {resp.status_code} from Anthropic: {resp.text[:300]}")
            data = resp.json()
            content_items = data.get("content", [])
            text = "".join(item.get("text", "") for item in content_items if item.get("type") == "text")
            return HTTPChatResponse(content=text)


def _get_configured_providers() -> List[str]:
    """Returns a list of all providers that have keys or endpoints configured."""
    configured = []
    if os.getenv("OPENAI_API_KEY", "").strip() or getattr(config, "OPENAI_API_KEY", ""):
        configured.append("openai")
    if os.getenv("ANTHROPIC_API_KEY", "").strip() or getattr(config, "ANTHROPIC_API_KEY", ""):
        configured.append("claude")
    if os.getenv("MISTRAL_API_KEY", "").strip() or getattr(config, "MISTRAL_API_KEY", ""):
        configured.append("mistral")
    if os.getenv("GROQ_API_KEY", "").strip() or getattr(config, "GROQ_API_KEY", ""):
        configured.append("groq")
    if os.getenv("QWEN_API_KEY", "").strip() or os.getenv("DASHSCOPE_API_KEY", "").strip() or getattr(config, "QWEN_API_KEY", ""):
        configured.append("qwen")
    if os.getenv("GLM_API_KEY", "").strip() or os.getenv("ZHIPU_API_KEY", "").strip() or getattr(config, "GLM_API_KEY", ""):
        configured.append("glm")
    if os.getenv("KIMI_API_KEY", "").strip() or os.getenv("MOONSHOT_API_KEY", "").strip() or getattr(config, "KIMI_API_KEY", ""):
        configured.append("kimi")
    if os.getenv("DEEPSEEK_API_KEY", "").strip() or getattr(config, "DEEPSEEK_API_KEY", ""):
        configured.append("deepseek")
    if os.getenv("GEMINI_API_KEY", "").strip() or getattr(config, "GEMINI_API_KEY", ""):
        configured.append("gemini")
    if os.getenv("CUSTOM_LLM_BASE_URL", "").strip() or getattr(config, "CUSTOM_LLM_BASE_URL", ""):
        configured.append("custom")
    return configured


def get_chat_model(
    temperature: float = 0.7,
    provider_override: Optional[str] = None,
    model_override: Optional[str] = None,
):
    """
    Returns an initialized ChatModel (LangChain model or universal HTTP model).
    Supports: openai, claude, mistral, groq, qwen, glm, kimi, deepseek, gemini, custom.
    Reads keys dynamically to ensure real-time settings updates take effect immediately.
    """
    cfg = config.reload_config() if hasattr(config, "reload_config") else {}
    provider = (
        provider_override
        or os.getenv("PREFERRED_PROVIDER", "").strip()
        or cfg.get("PREFERRED_PROVIDER", "")
        or "mistral"
    ).lower().strip()
    if provider == "anthropic":
        provider = "claude"

    # 1. OpenAI
    if provider == "openai":
        openai_key = os.getenv("OPENAI_API_KEY", "").strip() or cfg.get("OPENAI_API_KEY", "")
        openai_model = os.getenv("OPENAI_MODEL", "").strip() or cfg.get("OPENAI_MODEL", "gpt-4o")
        if openai_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://api.openai.com/v1/chat/completions",
                api_key=openai_key,
                model=openai_model,
                temperature=temperature,
            )

    # 2. Claude (Anthropic)
    if provider == "claude":
        claude_key = os.getenv("ANTHROPIC_API_KEY", "").strip() or cfg.get("ANTHROPIC_API_KEY", "")
        claude_model = os.getenv("ANTHROPIC_MODEL", "").strip() or cfg.get("ANTHROPIC_MODEL", "claude-3-7-sonnet-20250219")
        if claude_key:
            return HTTPAnthropicChatModel(
                api_key=claude_key,
                model=claude_model,
                temperature=temperature,
            )

    # 3. Mistral AI
    if provider == "mistral":
        mistral_key = os.getenv("MISTRAL_API_KEY", "").strip() or cfg.get("MISTRAL_API_KEY", "")
        mistral_model = os.getenv("MISTRAL_MODEL", "").strip() or cfg.get("MISTRAL_MODEL", "ministral-14b-latest")
        if mistral_key:
            try:
                from langchain_mistralai import ChatMistralAI
                return ChatMistralAI(
                    model=mistral_model,
                    mistral_api_key=mistral_key,
                    temperature=temperature,
                    timeout=LLM_REQUEST_TIMEOUT,
                    max_retries=0
                )
            except Exception as e:
                logger.warning(f"Could not initialize ChatMistralAI, falling back to HTTP: {e}")
                return HTTPOpenAICompatibleChatModel(
                    endpoint_url="https://api.mistral.ai/v1/chat/completions",
                    api_key=mistral_key,
                    model=mistral_model,
                    temperature=temperature,
                )

    # 4. Groq
    if provider == "groq":
        groq_key = os.getenv("GROQ_API_KEY", "").strip() or cfg.get("GROQ_API_KEY", "")
        groq_model = os.getenv("GROQ_MODEL", "").strip() or cfg.get("GROQ_MODEL", "qwen/qwen3.8-27b")
        if groq_key:
            try:
                from langchain_groq import ChatGroq
                return ChatGroq(
                    model=groq_model,
                    groq_api_key=groq_key,
                    temperature=temperature,
                    timeout=LLM_REQUEST_TIMEOUT,
                    max_retries=0
                )
            except Exception as e:
                logger.warning(f"Could not initialize ChatGroq, falling back to HTTP: {e}")
                return HTTPOpenAICompatibleChatModel(
                    endpoint_url="https://api.groq.com/openai/v1/chat/completions",
                    api_key=groq_key,
                    model=groq_model,
                    temperature=temperature,
                )

    # 5. Qwen (Alibaba DashScope)
    if provider == "qwen":
        qwen_key = os.getenv("QWEN_API_KEY", "").strip() or os.getenv("DASHSCOPE_API_KEY", "").strip() or cfg.get("QWEN_API_KEY", "")
        qwen_model = os.getenv("QWEN_MODEL", "").strip() or cfg.get("QWEN_MODEL", "qwen-plus")
        if qwen_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
                api_key=qwen_key,
                model=qwen_model,
                temperature=temperature,
            )

    # 6. GLM (Zhipu AI)
    if provider == "glm":
        glm_key = os.getenv("GLM_API_KEY", "").strip() or os.getenv("ZHIPU_API_KEY", "").strip() or cfg.get("GLM_API_KEY", "")
        glm_model = os.getenv("GLM_MODEL", "").strip() or cfg.get("GLM_MODEL", "glm-4-flash")
        if glm_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://open.bigmodel.cn/api/paas/v4/chat/completions",
                api_key=glm_key,
                model=glm_model,
                temperature=temperature,
            )

    # 7. Kimi (Moonshot AI)
    if provider == "kimi":
        kimi_key = os.getenv("KIMI_API_KEY", "").strip() or os.getenv("MOONSHOT_API_KEY", "").strip() or cfg.get("KIMI_API_KEY", "")
        kimi_model = os.getenv("KIMI_MODEL", "").strip() or cfg.get("KIMI_MODEL", "moonshot-v1-8k")
        if kimi_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://api.moonshot.cn/v1/chat/completions",
                api_key=kimi_key,
                model=kimi_model,
                temperature=temperature,
            )

    # 8. DeepSeek
    if provider == "deepseek":
        deepseek_key = os.getenv("DEEPSEEK_API_KEY", "").strip() or cfg.get("DEEPSEEK_API_KEY", "")
        deepseek_model = os.getenv("DEEPSEEK_MODEL", "").strip() or cfg.get("DEEPSEEK_MODEL", "deepseek-chat")
        if deepseek_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://api.deepseek.com/chat/completions",
                api_key=deepseek_key,
                model=deepseek_model,
                temperature=temperature,
            )

    # 9. Gemini (Google AI via OpenAI-compatible endpoint)
    if provider in ("gemini", "google"):
        gemini_key = os.getenv("GEMINI_API_KEY", "").strip() or cfg.get("GEMINI_API_KEY", "")
        gemini_model = model_override or os.getenv("GEMINI_MODEL", "").strip() or cfg.get("GEMINI_MODEL", "gemini-2.5-flash")
        if gemini_key:
            return HTTPOpenAICompatibleChatModel(
                endpoint_url="https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
                api_key=gemini_key,
                model=gemini_model,
                temperature=temperature,
            )

    # 10. Custom / OpenAI-Compatible Endpoint
    if provider == "custom":
        base_url = (os.getenv("CUSTOM_LLM_BASE_URL", "").strip() or cfg.get("CUSTOM_LLM_BASE_URL", "")).rstrip("/")
        custom_key = os.getenv("CUSTOM_LLM_API_KEY", "").strip() or cfg.get("CUSTOM_LLM_API_KEY", "")
        custom_model = model_override or os.getenv("CUSTOM_LLM_MODEL", "").strip() or cfg.get("CUSTOM_LLM_MODEL", "default")
        if base_url:
            endpoint = base_url if base_url.endswith("/chat/completions") else f"{base_url}/chat/completions"
            return HTTPOpenAICompatibleChatModel(
                endpoint_url=endpoint,
                api_key=custom_key,
                model=custom_model,
                temperature=temperature,
            )

    # Fallback to any other configured provider
    for alt_p in _get_configured_providers():
        if alt_p != provider:
            m = get_chat_model(temperature=temperature, provider_override=alt_p, model_override=model_override)
            if m:
                logger.info(f"Using alternate configured LLM provider '{alt_p}' (requested '{provider}' was not ready).")
                return m

    return None


def call_llm(
    prompt: str,
    system_instruction: Optional[str] = None,
    temperature: float = 0.7,
    max_retries: int = 3,
    provider_override: Optional[str] = None,
    model_override: Optional[str] = None,
) -> str:
    """
    Executes a real LLM call across any configured provider (OpenAI, Claude, Qwen,
    GLM, Kimi, DeepSeek, Groq, Mistral, Gemini, Custom).
    Supports model_override and provider_override for config-driven model routing.
    Retries transient failures (rate limits, timeouts, 5xx) with exponential
    backoff, and automatically falls back to alternate configured providers.
    Raises ValueError if no API key is configured.
    """
    active_provider = (
        provider_override
        or os.getenv("PREFERRED_PROVIDER", "").strip()
        or getattr(config, "PREFERRED_PROVIDER", "")
        or "mistral"
    ).lower()
    model = get_chat_model(temperature=temperature, provider_override=active_provider, model_override=model_override)
    if not model:
        raise ValueError(
            "No LLM API key configured! Please configure at least one API key (OpenAI, Claude, Qwen, GLM, Kimi, Groq, Mistral, or Gemini) in Settings or your .env file."
        )

    from langchain_core.messages import HumanMessage, SystemMessage
    messages = []
    if system_instruction:
        messages.append(SystemMessage(content=system_instruction))
    messages.append(HumanMessage(content=prompt))

    last_err: Exception = RuntimeError("LLM call failed")
    for attempt in range(1, max_retries + 1):
        try:
            response = model.invoke(messages)
            return str(response.content).strip()
        except Exception as e:  # noqa: BLE001
            last_err = e
            msg = str(e)
            transient = is_transient_llm_error(e)
            if attempt < max_retries and transient:
                delay = 2 ** attempt
                logger.warning(
                    f"LLM call failed (attempt {attempt}/{max_retries}, transient={transient}): {msg[:160]} — retrying in {delay}s"
                )
                time.sleep(delay)
                continue
            break

    # If primary provider failed, attempt cross-provider fallback across all configured providers
    all_configured = _get_configured_providers()
    for alt_p in all_configured:
        if alt_p == active_provider:
            continue
        alt_model = get_chat_model(temperature=temperature, provider_override=alt_p)
        if alt_model:
            logger.warning(
                f"Primary LLM provider ('{active_provider}') exhausted retries ({last_err}). "
                f"Failing over to alternate provider ('{alt_p}')..."
            )
            try:
                response = alt_model.invoke(messages)
                return str(response.content).strip()
            except Exception as alt_err:
                logger.error(f"Fallback provider '{alt_p}' also failed: {alt_err}")

    raise last_err

