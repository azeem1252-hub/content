"""
Model Context Protocol (MCP) Server for Content Pipeline Agent.
Exposes tools for autonomous search visibility, Action Center 1-click execution,
CITABLE 7-point evaluation, article discovery, and pipeline dispatches.

Compliant with Model Context Protocol (MCP) JSON-RPC 2.0 over stdio.
"""

import sys
import json
import logging
from typing import Dict, Any, List, Optional

from storage.db import get_all_posts, get_post_by_slug
from pipeline.adapters.action_center import (
    scan_action_center_opportunities,
    execute_action_center_opportunity
)
from pipeline.adapters.citable_evaluator import evaluate_citable_score
from pipeline.pipeline_manager import pipeline_manager

logger = logging.getLogger("pipeline.mcp_server")

SERVER_NAME = "content-pipeline-agent"
SERVER_VERSION = "2.0.0"
PROTOCOL_VERSION = "2024-11-05"

TOOLS_REGISTRY: List[Dict[str, Any]] = [
    {
        "name": "search_articles",
        "description": "Search published articles and drafts by keyword, slug, or tag.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Keyword, topic, or search term to match against articles."
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of articles to return (default: 10).",
                    "default": 10
                },
                "status": {
                    "type": "string",
                    "description": "Filter by post status (e.g. 'published', 'draft'). Optional."
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "scan_action_center",
        "description": "Scan active search opportunities (CITABLE deficits, Page 2 plateaus, low CTR headlines, missing video, /llms.txt sync).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "website_id": {
                    "type": "string",
                    "description": "Optional website ID to scope the Action Center scan."
                }
            }
        }
    },
    {
        "name": "execute_action",
        "description": "Execute 1-click autonomous remediations on an identified SEO execution gap (entity expansion, headline optimization, CITABLE alignment).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "opportunity_type": {
                    "type": "string",
                    "description": "Type of opportunity (e.g., 'citable_boost', 'ctr_headline_test', 'page_two_plateau', 'missing_video_summary', 'llms_txt_sync')."
                },
                "post_slug": {
                    "type": "string",
                    "description": "Slug of the article to remediate."
                },
                "website_id": {
                    "type": "string",
                    "description": "Target website ID. Optional."
                },
                "extra_params": {
                    "type": "object",
                    "description": "Optional additional configuration for the execution."
                }
            },
            "required": ["opportunity_type", "post_slug"]
        }
    },
    {
        "name": "evaluate_citable",
        "description": "Score any markdown draft against the proprietary CITABLE 7-point model (0-100 score + grading breakdown).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Headline of the candidate article."
                },
                "draft": {
                    "type": "string",
                    "description": "Markdown body content of the article."
                },
                "keywords": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Target SEO and semantic keywords."
                },
                "has_citations": {
                    "type": "boolean",
                    "description": "Whether the draft includes external reference links."
                },
                "has_schema": {
                    "type": "boolean",
                    "description": "Whether structured JSON-LD schema is embedded."
                }
            },
            "required": ["title", "draft"]
        }
    },
    {
        "name": "trigger_pipeline_run",
        "description": "Trigger autonomous research, drafting, and publishing pipeline for a given website.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "topic": {
                    "type": "string",
                    "description": "Target topic or leave empty for autonomous trend discovery."
                },
                "website_id": {
                    "type": "string",
                    "description": "Website ID to target. Optional."
                },
                "keywords": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of target SEO keywords."
                },
                "target_audience": {
                    "type": "string",
                    "description": "Target reader persona profile."
                },
                "auto_approve": {
                    "type": "boolean",
                    "description": "Bypass human review gate if true.",
                    "default": False
                }
            }
        }
    }
]


class ContentPipelineMCPServer:
    """Standard JSON-RPC 2.0 Model Context Protocol Server."""

    def __init__(self):
        self.tools = {t["name"]: t for t in TOOLS_REGISTRY}

    def handle_request(self, req: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Processes a single JSON-RPC 2.0 message."""
        jsonrpc = req.get("jsonrpc", "2.0")
        msg_id = req.get("id")
        method = req.get("method")
        params = req.get("params", {})

        # Handle notifications (no response needed)
        if method == "notifications/initialized":
            return None

        # Route requests
        if method == "initialize":
            return {
                "jsonrpc": jsonrpc,
                "id": msg_id,
                "result": {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {
                        "tools": {}
                    },
                    "serverInfo": {
                        "name": SERVER_NAME,
                        "version": SERVER_VERSION
                    }
                }
            }

        elif method == "ping":
            return {"jsonrpc": jsonrpc, "id": msg_id, "result": {}}

        elif method == "tools/list":
            return {
                "jsonrpc": jsonrpc,
                "id": msg_id,
                "result": {
                    "tools": TOOLS_REGISTRY
                }
            }

        elif method == "tools/call":
            tool_name = params.get("name")
            tool_args = params.get("arguments", {})
            return self._dispatch_tool(msg_id, tool_name, tool_args)

        else:
            return {
                "jsonrpc": jsonrpc,
                "id": msg_id,
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }

    def _dispatch_tool(self, msg_id: Any, name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatches tool execution and formats standard MCP tool response."""
        try:
            if name == "search_articles":
                res_data = self._tool_search_articles(args)
            elif name == "scan_action_center":
                res_data = self._tool_scan_action_center(args)
            elif name == "execute_action":
                res_data = self._tool_execute_action(args)
            elif name == "evaluate_citable":
                res_data = self._tool_evaluate_citable(args)
            elif name == "trigger_pipeline_run":
                res_data = self._tool_trigger_pipeline_run(args)
            else:
                return {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "isError": True,
                    "content": [{"type": "text", "text": f"Unknown tool: {name}"}]
                }

            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(res_data, indent=2, default=str)
                        }
                    ]
                }
            }
        except Exception as e:
            logger.error(f"Error executing MCP tool {name}: {e}", exc_info=True)
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "isError": True,
                    "content": [{"type": "text", "text": f"Tool execution failed: {str(e)}"}]
                }
            }

    def _tool_search_articles(self, args: Dict[str, Any]) -> Dict[str, Any]:
        query = (args.get("query") or "").lower().strip()
        limit = int(args.get("limit") or 10)
        status = args.get("status")

        posts = get_all_posts(limit=100, status=status)
        matched = []
        for p in posts:
            title = (p.get("title") or "").lower()
            slug = (p.get("slug") or "").lower()
            content = (p.get("content") or "").lower()
            tags = [t.lower() for t in (p.get("tags") or [])]

            if query in title or query in slug or query in content or any(query in t for t in tags):
                matched.append({
                    "title": p.get("title"),
                    "slug": p.get("slug"),
                    "status": p.get("status"),
                    "category": p.get("category"),
                    "tags": p.get("tags"),
                    "seo_score": p.get("seo_score"),
                    "created_at": p.get("created_at")
                })
                if len(matched) >= limit:
                    break

        return {"matches": matched, "count": len(matched), "query": query}

    def _tool_scan_action_center(self, args: Dict[str, Any]) -> Dict[str, Any]:
        website_id = args.get("website_id")
        scan_result = scan_action_center_opportunities(website_id=website_id)
        return scan_result

    def _tool_execute_action(self, args: Dict[str, Any]) -> Dict[str, Any]:
        op_type = args.get("opportunity_type")
        post_slug = args.get("post_slug")
        website_id = args.get("website_id")
        extra_params = args.get("extra_params") or {}

        if not op_type or not post_slug:
            raise ValueError("opportunity_type and post_slug are required")

        result = execute_action_center_opportunity(
            opportunity_type=op_type,
            post_slug=post_slug,
            website_id=website_id,
            extra_params=extra_params
        )
        return result

    def _tool_evaluate_citable(self, args: Dict[str, Any]) -> Dict[str, Any]:
        title = args.get("title") or ""
        draft = args.get("draft") or ""
        keywords = args.get("keywords") or []
        has_citations = args.get("has_citations", "http" in draft)
        has_schema = args.get("has_schema", "application/ld+json" in draft or "schema.org" in draft)

        if not title or not draft:
            raise ValueError("title and draft are required")

        return evaluate_citable_score(
            title=title,
            draft=draft,
            keywords=keywords,
            has_citations=has_citations,
            has_schema=has_schema
        )

    def _tool_trigger_pipeline_run(self, args: Dict[str, Any]) -> Dict[str, Any]:
        topic = args.get("topic")
        website_id = args.get("website_id")
        keywords = args.get("keywords") or []
        target_audience = args.get("target_audience")
        auto_approve = bool(args.get("auto_approve", False))

        res = pipeline_manager.start_pipeline(
            topic=topic,
            website_id=website_id,
            keywords=keywords,
            target_audience=target_audience,
            auto_approve=auto_approve
        )
        return res

    def run_stdio(self):
        """Standard input/output JSON-RPC event loop."""
        if sys.platform == "win32":
            sys.stdin.reconfigure(encoding="utf-8")
            sys.stdout.reconfigure(encoding="utf-8")

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                req = json.loads(line)
                resp = self.handle_request(req)
                if resp is not None:
                    sys.stdout.write(json.dumps(resp) + "\n")
                    sys.stdout.flush()
            except json.JSONDecodeError:
                err_resp = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32700, "message": "Parse error"}
                }
                sys.stdout.write(json.dumps(err_resp) + "\n")
                sys.stdout.flush()
            except Exception as ex:
                err_resp = {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32603, "message": f"Internal error: {str(ex)}"}
                }
                sys.stdout.write(json.dumps(err_resp) + "\n")
                sys.stdout.flush()


def main():
    server = ContentPipelineMCPServer()
    server.run_stdio()


if __name__ == "__main__":
    main()
