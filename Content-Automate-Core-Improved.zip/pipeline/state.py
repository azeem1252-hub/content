from typing import TypedDict, Optional, List, Literal, Any, Dict, Union

class ContentState(TypedDict):
    """
    Central state definition for the LangGraph Content Publishing Pipeline.
    Checkpointed across pause/resume boundaries for Slack human-in-the-loop review.
    """
    # Trigger & Input
    topic: str
    keywords: List[str]
    secondary_keywords: Optional[List[str]]
    target_audience: Optional[str]
    website_id: Optional[str]
    destination_url: Optional[str]
    destination_name: Optional[str]
    brand_voice: Optional[str]
    article_depth: Optional[str]
    inject_evidence: Optional[bool]

    # Real-Time Research Intelligence (Tavily Scraper & Information Gain)
    discovered_keywords: Optional[List[str]]
    audience_insights: Optional[str]
    search_sources: Optional[List[dict]]
    gsc_question_queries: Optional[List[str]]   # A5b: GSC question-form queries
    site_niche: Optional[str]
    niche_slug: Optional[str]
    content_format: Optional[str]
    angle_or_hook: Optional[str]
    information_gain_score: Optional[int]
    editorial_persona: Optional[str]
    editorial_archetype: Optional[str]
    design_guide: Optional[dict]
    
    # Generation Artifacts
    outline: Optional[str]
    content_brief: Optional[dict]
    serp_analysis: Optional[dict]
    evidence_pack: Optional[Any]
    structured_draft: Optional[dict]
    style_profile: Optional[dict]
    prompt_versions: Optional[dict]
    critique_result: Optional[dict]
    critique_loop_count: Optional[int]
    evidence_status: Optional[str]
    title: Optional[str]
    draft: Optional[str]
    image_prompt: Optional[str]
    hero_image_path: Optional[str]
    hero_image_url: Optional[str]
    hero_image_full_url: Optional[str]
    public_image_url: Optional[str]
    
    # Quality & SEO Metadata
    # Anti-Cannibalization & Entity Discovery
    is_content_refresh: Optional[bool]
    target_existing_post_id: Optional[int]
    entity_gap_similarity: Optional[float]

    # Fact Verification & Grounding (Pillar A4 / Pillar I)
    verified_claims: Optional[List[dict]]
    fact_check_score: Optional[int]
    fact_check_verdict: Optional[str]
    verification_report: Optional[dict]
    requires_human_approval: Optional[bool]
    named_human_approver: Optional[str]
    fact_check_escalated: Optional[bool]
    source_citations: Optional[List[dict]]
    verification_layers: Optional[dict]

    # Knowledge Graph & GraphRAG grounding (Pillar I/III)
    knowledge_graph_context: Optional[str]
    graph_entities: Optional[List[str]]

    # AI-search (GEO) scoring, Citation-Readiness (Pillar A5), and AEO (Pillar A5b)
    citable_score: Optional[int]
    citable_evaluation: Optional[dict]
    citation_readiness: Optional[dict]
    serp_coverage: Optional[dict]
    live_serp_context: Optional[str]
    # A5b: Answer Engine Optimization
    aeo_report: Optional[dict]
    answer_blocks: Optional[List[dict]]
    aeo_faq_items: Optional[List[dict]]
    aeo_eligible_targets: Optional[List[dict]]
    aeo_near_miss_targets: Optional[List[dict]]
    aeo_not_eligible_targets: Optional[List[dict]]
    aeo_click_worthiness: Optional[List[dict]]
    aeo_faqpage_schema: Optional[dict]
    aeo_config: Optional[dict]
    # A5c: Article Production Studio — typed block model + renderers
    article_model: Optional[dict]
    article_html: Optional[str]
    article_markdown: Optional[str]
    article_wp_blocks: Optional[List[dict]]
    blueprint_compliance: Optional[dict]


    # Quality & SEO Metadata
    meta_title: Optional[str]
    meta_description: Optional[str]
    slug: Optional[str]
    tags: Optional[List[str]]
    seo_score: Optional[int]
    on_page_seo: Optional[dict]
    schema_markup: Optional[Union[dict, List[dict]]]
    internal_link_proposals: Optional[List[dict]]
    inbound_link_proposals: Optional[List[dict]]
    image_provenance: Optional[dict]
    grounding_page_url: Optional[str]
    topic_cluster: Optional[dict]
    audit_notes: Optional[str]
    word_count: Optional[int]
    read_time: Optional[int]
    
    # Human Review (Slack Gate)
    review_status: Literal["pending", "approved", "changes_requested", "rejected"]
    reviewer_feedback: Optional[str]
    revision_count: int
    slack_message_ts: Optional[str]
    slack_channel_id: Optional[str]
    slack_dispatch: Optional[bool]
    
    # Target Website & Social Distribution (A5d, A9)
    published_url: Optional[str]
    publish_error: Optional[str]
    linkedin_post: Optional[str]
    twitter_thread: Optional[List[str]]
    postiz_status: Optional[str]
    engine_errors: Optional[dict]
    
    # Graph Orchestration & Observability
    thread_id: str
    status: str


