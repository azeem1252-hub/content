import logging
from typing import Dict, Any, Literal
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from pipeline.state import ContentState
from pipeline.nodes.outline_node import outline_node
from pipeline.nodes.draft_node import draft_node
from pipeline.nodes.fact_check_node import fact_check_node
from pipeline.nodes.aeo_node import aeo_node
from pipeline.nodes.article_studio_node import article_studio_node
from pipeline.nodes.image_node import image_node
from pipeline.nodes.audit_node import audit_node
from pipeline.nodes.review_node import review_node
from pipeline.nodes.publish_node import publish_node
from pipeline.nodes.repurpose_node import repurpose_node

logger = logging.getLogger("pipeline.graph")

def get_allowed_msgpack_modules():
    return [
        ("pipeline.adapters.aeo_engine", "SnippetSurface"),
        ("pipeline.adapters.aeo_engine", "SnippetFormat"),
        ("pipeline.adapters.aeo_engine", "EligibilityStatus"),
        ("pipeline.adapters.article_model", "VisualSituation"),
    ]

def build_checkpointer_serializer():
    """Builds a JsonPlusSerializer configured with domain enum allowlists to eliminate msgpack warnings."""
    try:
        from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
        return JsonPlusSerializer(allowed_msgpack_modules=get_allowed_msgpack_modules())
    except Exception:
        return None

# Maximum editorial revision cycles before the run is force-ended. Prevents an
# unbounded changes_requested loop from burning LLM/image quota forever.
MAX_REVISIONS = 3

def route_after_review(state: ContentState) -> Literal["publish", "draft", "__end__"]:
    """
    Conditional edge router evaluating the Slack human review decision.
    - 'approved' -> triggers publishing and social repurposing
    - 'changes_requested' -> loops back to draft_node with human feedback
      (capped at MAX_REVISIONS, then the run ends instead of looping forever)
    - 'rejected' / other -> terminates graph and archives
    """
    review_status = state.get("review_status", "pending")
    revision_count = state.get("revision_count", 0)
    logger.info(f"Routing after review gate: review_status='{review_status}' (revision_count={revision_count})")

    if review_status == "approved":
        return "publish"
    elif review_status == "changes_requested":
        if revision_count >= MAX_REVISIONS:
            logger.warning(
                f"Revision cap reached ({revision_count}/{MAX_REVISIONS}); ending run instead of looping again."
            )
            return "__end__"
        return "draft"
    else:
        return "__end__"


def route_after_publish(state: ContentState) -> Literal["repurpose", "__end__"]:
    """Skip post-publishing distribution when publish failed — generating
    social assets for an article that never went live wastes quota."""
    if state.get("status") == "failed" or (state.get("publish_error") and not state.get("published_url")):
        logger.warning("Publish failed; skipping post-publishing distribution stages.")
        return "__end__"
    return "repurpose"


def build_content_pipeline(checkpointer: Any = None):
    """
    Constructs and compiles the full end-to-end LangGraph autonomous publishing pipeline.
    """
    builder = StateGraph(ContentState)

    # 1. Register all editorial article nodes
    builder.add_node("outline", outline_node)
    builder.add_node("draft", draft_node)
    builder.add_node("fact_check", fact_check_node)
    builder.add_node("aeo", aeo_node)
    builder.add_node("article_studio", article_studio_node)
    builder.add_node("audit", audit_node)
    builder.add_node("image", image_node)
    builder.add_node("review_gate", review_node)
    builder.add_node("publish", publish_node)
    builder.add_node("repurpose", repurpose_node)

    # 2. Sequential pipeline edges
    # outline -> draft -> fact_check -> aeo -> article_studio -> audit -> image -> review_gate
    # fact_check extracts and verifies claims (A4);
    # aeo discovers questions & formats snippet answer targets (A5b);
    # article_studio constructs typed document model, runs verification & linting once, and renders (A5c);
    # audit performs SEO on-page checks;
    # image generates hero & visual assets with provenance.
    builder.add_edge(START, "outline")
    builder.add_edge("outline", "draft")
    builder.add_edge("draft", "fact_check")
    builder.add_edge("fact_check", "aeo")
    builder.add_edge("aeo", "article_studio")
    builder.add_edge("article_studio", "audit")
    builder.add_edge("audit", "image")
    builder.add_edge("image", "review_gate")

    # 3. Conditional Human-in-the-Loop review routing
    builder.add_conditional_edges(
        "review_gate",
        route_after_review,
        {
            "publish": "publish",
            "draft": "draft",
            "__end__": END
        }
    )

    # 4. Post-publishing distribution (publish -> repurpose -> END)
    builder.add_conditional_edges(
        "publish",
        route_after_publish,
        {
            "repurpose": "repurpose",
            "__end__": END
        }
    )
    builder.add_edge("repurpose", END)


    # 5. Compile with durable checkpointer (defaults to MemorySaver if none provided)
    if checkpointer is not None:
        active_checkpointer = checkpointer
    else:
        serde = build_checkpointer_serializer()
        active_checkpointer = MemorySaver(serde=serde) if serde is not None else MemorySaver()
    compiled_graph = builder.compile(checkpointer=active_checkpointer)

    logger.info("LangGraph Content Pipeline compiled successfully.")
    return compiled_graph
