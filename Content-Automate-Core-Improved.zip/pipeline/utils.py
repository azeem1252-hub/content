"""
Shared utility helpers for the content pipeline.

Extracts the JSON-fence parsing and article content sanitization logic that was
previously duplicated across outline_node, draft_node, audit_node, repurpose_node,
website_client, and dashboard.js into one canonical implementation.
"""

import difflib
import hashlib
import hmac
import json
import logging
import os
import re
import httpx
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("pipeline.utils")


# ---------------------------------------------------------------------------
# Signed one-click actions (Slack quick-approve links)
# ---------------------------------------------------------------------------

def _quick_action_secret() -> str:
    """Signing key for one-click review links.

    Prefers SLACK_SIGNING_SECRET (already required to verify Slack webhooks),
    then AGENT_SECRET_TOKEN. Both are read from the live environment first so
    settings changes apply without a process restart.
    """
    import config
    for candidate in (
        os.getenv("SLACK_SIGNING_SECRET", "").strip(),
        getattr(config, "SLACK_SIGNING_SECRET", "") or "",
        os.getenv("AGENT_SECRET_TOKEN", "").strip(),
        getattr(config, "AGENT_SECRET_TOKEN", "") or "",
    ):
        if candidate and candidate.strip():
            return candidate.strip()
    return ""


def quick_action_signing_configured() -> bool:
    """True when one-click review links can be cryptographically signed."""
    return bool(_quick_action_secret())


def sign_quick_action(thread_id: str, action: str = "approve") -> str:
    """Returns the HMAC signature for a one-click action, or '' when unconfigured."""
    secret = _quick_action_secret()
    if not secret or not thread_id:
        return ""
    return hmac.new(
        secret.encode("utf-8"),
        f"{thread_id}:{action}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def verify_quick_action(thread_id: str, action: str, signature: str) -> bool:
    """Constant-time verification of a one-click action signature."""
    secret = _quick_action_secret()
    if not secret or not thread_id:
        return False
    expected = sign_quick_action(thread_id, action)
    return hmac.compare_digest(expected, (signature or "").strip())

# ---------------------------------------------------------------------------
# JSON extraction
# ---------------------------------------------------------------------------

def extract_section_from_malformed_json(text: str) -> Dict[str, Any]:
    """
    Extracts heading, direct_answer, and markdown_content from an LLM section JSON response,
    even when the JSON has unescaped quotes or nested markdown code blocks that break standard json.loads.
    """
    if not text:
        return {}

    # 1. Heading
    heading_match = re.search(r'"heading"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"', text)
    heading = ""
    if heading_match:
        try:
            heading = heading_match.group(1).encode("utf-8").decode("unicode_escape", errors="replace")
        except Exception:
            heading = heading_match.group(1)

    # 2. Level
    level_match = re.search(r'"level"\s*:\s*(\d+)', text)
    level = int(level_match.group(1)) if level_match else 2

    # 3. Direct answer
    direct_match = re.search(r'"direct_answer"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"', text)
    direct_answer = ""
    if direct_match:
        try:
            direct_answer = direct_match.group(1).encode("utf-8").decode("unicode_escape", errors="replace")
        except Exception:
            direct_answer = direct_match.group(1)

    # 4. Markdown content: find where `"markdown_content"\s*:\s*"` begins
    mc_start_match = re.search(r'"markdown_content"\s*:\s*"', text)
    markdown_content = ""
    if mc_start_match:
        mc_start = mc_start_match.end()
        # Find where top-level `"claims"\s*:` or `"citations"\s*:` or end of JSON `\n\s*}` occurs
        next_key_match = re.search(r'"\s*,\s*\n\s*"(?:claims|citations|key_entities_covered|evidence_used)"\s*:', text[mc_start:])
        if next_key_match:
            raw_mc = text[mc_start:mc_start + next_key_match.start()]
        else:
            end_match = re.search(r'"\s*\n\s*\}\s*$', text[mc_start:])
            if end_match:
                raw_mc = text[mc_start:mc_start + end_match.start()]
            else:
                raw_mc = text[mc_start:].rstrip('"\n }')

        # Clean escaped quotes/newlines
        raw_mc = raw_mc.replace('\\"', '"').replace('\\n', '\n').replace('\\t', '\t')
        markdown_content = raw_mc.strip()

    return {
        "heading": heading,
        "level": level,
        "direct_answer": direct_answer,
        "markdown_content": markdown_content
    }


def extract_json_block(raw_response: str) -> Optional[Dict[str, Any]]:
    """
    Parses a JSON object out of a raw LLM response.

    Handles ```json fenced blocks, plain ``` fences, raw JSON,
    rogue markdown formatting (e.g. bold **"value"**), and trailing commas.
    Returns the parsed dict, or None if parsing fails.
    """
    if not raw_response:
        return None
    clean = raw_response.strip()
    if "```json" in clean:
        clean = clean.split("```json", 1)[1]
        if "```" in clean:
            clean = clean.rsplit("```", 1)[0].strip()
    elif clean.startswith("```"):
        clean = clean.split("```", 1)[1]
        if "```" in clean:
            clean = clean.rsplit("```", 1)[0].strip()

    # Find the outermost JSON object bounds
    start = clean.find("{")
    end = clean.rfind("}")
    if start != -1 and end != -1 and end > start:
        clean = clean[start:end + 1]

    # Clean markdown bold/italic asterisks that LLMs sometimes insert around JSON values
    cleaned = clean.replace("**", "")
    # Remove trailing commas before closing braces/brackets
    cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)

    try:
        data = json.loads(cleaned, strict=False)
        return data if isinstance(data, dict) else None
    except Exception as e:
        # Check if this was a section draft with unescaped quotes or nested code fences
        if '"markdown_content"' in clean:
            recovered_sec = extract_section_from_malformed_json(clean)
            if recovered_sec and recovered_sec.get("markdown_content"):
                logger.info("Successfully recovered section JSON object with unescaped quotes/markdown fences.")
                return recovered_sec

        # Fallback regex extraction for standard keys
        try:
            extracted: Dict[str, Any] = {}
            for key in ["topic", "title", "reasoning", "target_audience", "summary", "draft", "meta_title", "meta_description"]:
                m = re.search(rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*?)"', cleaned, re.DOTALL)
                if m:
                    extracted[key] = m.group(1).replace('\\"', '"').strip()

            # Keywords list
            km = re.search(r'"keywords"\s*:\s*\[(.*?)\]', cleaned, re.DOTALL)
            if km:
                kws = re.findall(r'"((?:[^"\\]|\\.)*?)"', km.group(1), re.DOTALL)
                extracted["keywords"] = [k.replace('\\"', '"').strip() for k in kws if k.strip()]

            if extracted and ("topic" in extracted or "title" in extracted or "draft" in extracted):
                logger.info("Successfully recovered JSON object using regex fallback.")
                return extracted
        except Exception:
            pass

        logger.debug(f"extract_json_block failed: {e}")
        return None


def merge_unique_keywords(
    *keyword_lists: Optional[List[str]],
    limit: int = 0
) -> List[str]:
    """Merges keyword lists preserving order, case-insensitive dedupe."""
    merged: List[str] = []
    seen_lower = set()
    for kws in keyword_lists:
        for kw in (kws or []):
            if kw and str(kw).strip():
                s = str(kw).strip()
                if s.lower() not in seen_lower:
                    seen_lower.add(s.lower())
                    merged.append(s)
    return merged[:limit] if limit > 0 else merged


# ---------------------------------------------------------------------------
# Article content sanitization
# ---------------------------------------------------------------------------

def clean_article_content(content: str) -> str:
    """
    Canonical sanitization applied to LLM-generated article Markdown:

    - Strips markdown code fences wrapping the whole document
    - Strips YAML frontmatter
    - Strips placeholder markdown images (![...](...))
    - Strips "Visual concept:" / "Hero Image Concept:" narration lines
    - Strips trailing internal metadata (SEO notes, word counts, "Why This Works")
    - Removes orphan horizontal rules after the H1 title
    """
    if not content:
        return ""

    text = content.strip()

    # 1. Whole-document code fences
    text = re.sub(r"^```(?:markdown|md)?\s*[\r\n]+", "", text).strip()
    text = re.sub(r"[\r\n]+```\s*$", "", text).strip()

    # 2. YAML frontmatter
    text = re.sub(r"^---\s*[\r\n]+[\s\S]*?[\r\n]+---\s*", "", text).strip()

    # 3. Placeholder / broken markdown images (preserve genuine local and published /uploads/ URLs)
    def _strip_placeholder_images(match: re.Match) -> str:
        url = match.group(2).strip()
        if url.startswith(("/uploads/", "http://", "https://")) and not re.search(r"placeholder|via\.placeholder|example\.com", url, re.I):
            return match.group(0)
        return ""

    text = re.sub(r"!\[(.*?)\]\((.*?)\)\s*[\r\n]*", _strip_placeholder_images, text)

    # 4. Visual concept narration
    text = re.sub(r"(?i)\*?\*?Visual concept:[\s\S]*?\*?\*?(?=\n\n|\n##|\n---|$)", "", text)
    text = re.sub(r"(?i)\*?\*?Hero Image Concept:[\s\S]*?\*?\*?(?=\n\n|\n##|\n---|$)", "", text)

    # 5. Trailing or embedded internal metadata and meta-SEO sections
    patterns_to_cut = [
        r"(?i)\n+---+\s*\n+\*?\*?SEO Optimization Notes:?[\s\S]*",
        r"(?i)\n+\*?\*?SEO Optimization Notes:?[\s\S]*",
        r"(?i)\n+---+\s*\n+\*?\*?Estimated Word Count:?[\s\S]*",
        r"(?i)\n+\*?\*?Estimated Word Count:?[\s\S]*",
        r"(?i)\n+---+\s*\n+\*?\*?Why This Works:?[\s\S]*",
        r"(?i)\n+\*?\*?Why This Works:?[\s\S]*",
        # Meta SEO commentary headings that break reader immersion
        r"(?is)\n+---+\s*\n+##\s+Why This (?:Recipe|Article|Post|Dish|Guide) Ranks.*?(?=\n##|\n---|\Z)",
        r"(?is)\n+##\s+Why This (?:Recipe|Article|Post|Dish|Guide) Ranks.*?(?=\n##|\n---|\Z)",
        r"(?is)\n+---+\s*\n+##\s+(?:SEO Strategy|Search Engine Optimization|Information Gain Analysis).*?(?=\n##|\n---|\Z)",
        r"(?is)\n+##\s+(?:SEO Strategy|Search Engine Optimization|Information Gain Analysis).*?(?=\n##|\n---|\Z)",
    ]
    for pat in patterns_to_cut:
        text = re.sub(pat, "", text)

    # 6. Clean Markdown Headings: strip redundant bold/italic wrapping (e.g. # **Title** -> # Title, ## **Section** -> ## Section)
    text = re.sub(r"^(#{1,6})\s*\*\*([^*\n]+)\*\*\s*$", r"\1 \2", text, flags=re.MULTILINE)
    text = re.sub(r"^(#{1,6})\s*\*([^*\n]+)\*\s*$", r"\1 \2", text, flags=re.MULTILINE)

    # Clean H1 title line: if bold kicker is glued directly to the H1 (e.g. # Title **Kicker**)
    text = re.sub(r"^(#\s+[^\n*]+?)\s+(\*\*[^*\n]+\*\*)\s*", r"\1\n\n\2\n\n", text)
    # Ensure H1 has clean double newline after it
    text = re.sub(r"^(#[^\n]+)\n([^\n#])", r"\1\n\n\2", text)

    # 7. Orphan hr directly under the H1 title
    text = re.sub(r"(^# [^\n]+\n+)\s*---\s*\n+", r"\1\n", text.strip())

    # 8. Unpack any leaked raw section JSON blocks { "heading": ..., "markdown_content": ... }
    def _unwrap_section_json(match: re.Match) -> str:
        block = match.group(0)
        unpacked = extract_section_from_malformed_json(block)
        if unpacked and unpacked.get("markdown_content"):
            return unpacked["markdown_content"]
        return block

    text = re.sub(
        r'\{\s*"heading"\s*:\s*"[^"]*",\s*"level"\s*:\s*\d+,\s*[\s\S]*?"markdown_content"\s*:\s*[\s\S]*?\n\s*\}',
        _unwrap_section_json,
        text
    )

    return text.strip()


RESERVED_SLUGS = {
    "api", "posts", "reviews", "categories", "about", "admin", "static",
    "_next", "favicon", "sitemap", "robots", "login", "register", "dashboard"
}


def clean_slug(raw: Any, max_len: int = 80, fallback: str = "post") -> str:
    """Slugifies a title/slug string to lowercase alphanumeric + hyphens with reserved route protection.

    LLM JSON is untyped, so non-string input (a list of keywords, a nested
    object) is discarded rather than crashing the caller with an AttributeError.
    """
    if isinstance(raw, str):
        text = raw
    elif isinstance(raw, (int, float)) and not isinstance(raw, bool):
        text = str(raw)
    else:
        text = ""
    s = re.sub(r"[^a-z0-9-]", "-", text.lower())
    s = re.sub(r"-+", "-", s).strip("-")[:max_len].rstrip("-")
    if not s:
        s = fallback
    if s in RESERVED_SLUGS:
        s = f"{s}-post"
    return s


def extract_h1_title(markdown_text: str, fallback: str = "") -> str:
    """Extracts the article title from the first '# ' heading, unformatted."""
    for line in (markdown_text or "").strip().split("\n"):
        cleaned = line.strip()
        if cleaned.startswith("# "):
            raw_title = cleaned.replace("# ", "").strip()
            raw_title = raw_title.strip("*").strip('"').strip("'").strip()
            return raw_title or fallback
    return fallback


# ---------------------------------------------------------------------------
# Text similarity & word counting
# ---------------------------------------------------------------------------

def strip_markdown(md: str) -> str:
    """Removes markdown syntax (headings, emphasis, links, code, tables, images)
    so word counts reflect real prose rather than markup tokens."""
    if not md:
        return ""
    text = md.strip()
    # Fenced code blocks (keep the inner text but drop fence markers)
    text = re.sub(r"```[\w-]*\n?", " ", text)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", text)  # images
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)  # links -> anchor text
    text = re.sub(r"^#{1,6}\s+", " ", text, flags=re.MULTILINE)  # headings
    text = re.sub(r"(\*\*|__|\*|_|~~|`)", " ", text)  # emphasis / inline code
    text = re.sub(r"^\s*>\s?", " ", text, flags=re.MULTILINE)  # blockquotes
    text = re.sub(r"^\s*([-*+]|\d+\.)\s+", " ", text, flags=re.MULTILINE)  # list markers
    text = re.sub(r"^\s*\|.*\|\s*$", " ", text, flags=re.MULTILINE)  # tables
    text = re.sub(r"^-{3,}\s*$", " ", text, flags=re.MULTILINE)  # hrules
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def count_words(markdown_text: str) -> int:
    """Word count of real prose (markdown stripped), matching reader experience.
    Tokens without any letters/digits (stray punctuation from stripped markup) are ignored."""
    words = strip_markdown(markdown_text).split()
    return len([w for w in words if any(c.isalnum() for c in w)])


STOP_TOPIC_WORDS = {
    "the", "a", "an", "in", "for", "of", "and", "to", "on", "with", "from",
    "by", "at", "about", "into", "through", "how", "what", "why", "when",
    "where", "guide", "masterclass", "ultimate", "essential", "definitive",
    "complete", "introduction", "overview", "2024", "2025", "2026", "2027",
    "recipe", "recipes", "dish", "dishes", "tips", "tricks", "secrets", "best", "pro"
}


def title_similarity(a: str, b: str) -> float:
    """Normalized similarity between two titles/topics in [0.0, 1.0].

    Blends token-set Jaccard, containment overlap, consecutive bigram matching,
    and sequence ratios so duplicate subjects (even with different adjectives,
    garnishes, or subtitles) are reliably detected and prevented.
    """
    def tokens(s: str) -> List[str]:
        clean = re.sub(r"[^a-z0-9\s]", " ", (s or "").lower())
        return [w for w in clean.split() if w not in STOP_TOPIC_WORDS and len(w) > 2]

    ta, tb = tokens(a), tokens(b)
    if not ta or not tb:
        return 0.0

    sa, sb = set(ta), set(tb)
    jaccard = len(sa & sb) / len(sa | sb) if (sa | sb) else 0.0
    overlap = len(sa & sb) / min(len(sa), len(sb)) if min(len(sa), len(sb)) else 0.0
    ratio = difflib.SequenceMatcher(None, " ".join(ta), " ".join(tb)).ratio()

    # Consecutive 2-gram overlap check (e.g. 'duck breast', 'sea scallops', 'service mesh')
    bigrams_a = set(zip(ta[:-1], ta[1:]))
    bigrams_b = set(zip(tb[:-1], tb[1:]))
    common_bigrams = bigrams_a & bigrams_b
    if common_bigrams:
        return max(0.82, max(jaccard, ratio, overlap))

    # Distinctive anchor word overlap (e.g. 'pavlova', 'tagliatelle', 'carpaccio')
    distinctive_common = [w for w in (sa & sb) if len(w) >= 6]
    if len(distinctive_common) >= 1 and (len(sa) <= 4 or len(sb) <= 4):
        return max(0.78, max(jaccard, ratio, overlap))
    if len(distinctive_common) >= 2:
        return max(0.80, max(jaccard, ratio, overlap))

    return max(jaccard, ratio * 0.95, overlap * 0.75)


def is_duplicate_topic(
    new_topic: str,
    existing_titles: List[str],
    threshold: float = 0.85,
) -> Optional[Dict[str, Any]]:
    """Returns the first matching {'title', 'score'} if new_topic is >= threshold
    similar to any existing title, else None."""
    best = None
    for title in existing_titles:
        if not title:
            continue
        score = title_similarity(new_topic, title)
        if score >= threshold and (best is None or score > best["score"]):
            best = {"title": title, "score": round(score, 3)}
    return best


def unique_slug(base: str, max_len: int = 80, fallback: str = "post") -> str:
    """Deterministic suffix slug: strips trailing -N, appends the next free -N
    so regenerated slugs stay stable-ish instead of growing unbounded."""
    core = clean_slug(base, max_len=max_len - 6, fallback=fallback)
    m = re.match(r"^(.*?)-\d+$", core)
    if m and m.group(1):
        core = m.group(1)
    # The caller is expected to have checked for existence; we just provide the
    # base with a numeric discriminator. Callers pass the set of taken slugs.
    return core


def slug_with_suffix(base: str, taken: set) -> str:
    """Returns a slug free among `taken`: base, base-2, base-3, ..."""
    core = unique_slug(base)
    if core not in taken:
        return core
    i = 2
    while f"{core}-{i}" in taken:
        i += 1
    return f"{core}-{i}"


def discover_local_nextjs_public_dir(target_site: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """Finds the public/uploads directory of the local clone for a website.

    Hero images are mirrored into the local clone so the site can serve them
    before/without a git commit. With two websites developed side by side, one
    shared global directory would mix their assets, so the destination is
    matched per website (repo folder name, then website name). Only directories
    that are actually Next.js projects are accepted, so unrelated sibling
    folders are never touched. Returns None when there is no unambiguous local
    clone; callers fall back to the global NEXTJS_PUBLIC_DIR.
    """
    from config import BASE_DIR

    override = os.getenv("NEXTJS_LOCAL_DIR", "").strip()
    if override:
        p = Path(override)
        return str(p / "public" / "uploads") if (p / "public").is_dir() else None

    if not target_site:
        return None

    folder = None
    if target_site.get("github_repo"):
        folder = str(target_site["github_repo"]).split("/")[-1].strip().lower()
    elif target_site.get("name"):
        folder = str(target_site["name"]).strip().lower().replace(" ", "-")
    if not folder:
        return None

    base = Path(BASE_DIR).resolve()
    search_dirs: List[Path] = []
    try:
        search_dirs.extend([s for s in base.parent.iterdir() if s.is_dir()])
    except Exception:
        pass
    try:
        search_dirs.extend([c for c in base.iterdir() if c.is_dir()])
    except Exception:
        pass

    for d in search_dirs:
        if not (d / "public").is_dir():
            continue
        is_nextjs = (d / "package.json").exists() or any(
            (d / cfg).exists() for cfg in ("next.config.js", "next.config.mjs", "next.config.ts")
        )
        if is_nextjs and (d.name.lower() == folder or folder in d.name.lower()):
            return str(d / "public" / "uploads")
    return None


def _reported_public_base_url(run_or_state: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """
    Derives the target site's public base URL from what the run actually
    reported (destination_url, or an absolute published_url), or None.

    Unlike resolve_published_base_url it never falls back to
    config.PUBLIC_BASE_URL, so callers can distinguish a real remote site from
    the local studio default.
    """
    from urllib.parse import urlparse

    data = run_or_state or {}
    state = data.get("state") if isinstance(data.get("state"), dict) else {}
    published = data.get("published_url") or (state or {}).get("published_url")
    candidates = [
        data.get("destination_url"),
        (state or {}).get("destination_url"),
        published if (published and str(published).startswith("http")) else None,
    ]
    for candidate in candidates:
        if not candidate:
            continue
        c_str = str(candidate).strip()
        if not c_str:
            continue
        if "/api/" in c_str:
            return c_str.split("/api/")[0].rstrip("/")
        if c_str.startswith("http"):
            parsed = urlparse(c_str)
            if parsed.scheme and parsed.netloc:
                return f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
    return None


def resolve_published_base_url(run_or_state: Optional[Dict[str, Any]] = None) -> str:
    """
    Derives the public base URL of the target site (e.g.
    'https://myblog.com/api/posts' -> 'https://myblog.com'), falling back to
    PUBLIC_BASE_URL. Never assumes localhost:3000.
    """
    import config

    reported = _reported_public_base_url(run_or_state)
    if reported:
        return reported
    return getattr(config, "PUBLIC_BASE_URL", "http://127.0.0.1:8000").rstrip("/")


def resolve_full_published_url(
    published_url: Optional[str] = None,
    run_or_state: Optional[Dict[str, Any]] = None,
    slug: Optional[str] = None
) -> Optional[str]:
    """
    Returns a fully-qualified, absolute URL for social distribution and Slack
    links, or None when no URL was ever reported.

    Converts relative paths like '/posts/my-slug' into
    'https://myblog.com/posts/my-slug'. When nothing was reported it returns
    None rather than inventing '{base}/posts/{slug}': a fabricated deep link
    ships a possible 404 to readers, so callers must omit the link instead.
    `slug` is kept for call-site compatibility.
    """
    if isinstance(published_url, str) and published_url.strip():
        target = published_url.strip()
        if target.startswith("http://") or target.startswith("https://"):
            return target
        base = resolve_published_base_url(run_or_state)
        if not target.startswith("/"):
            target = f"/{target}"
        return f"{base}{target}"

    reported_base = _reported_public_base_url(run_or_state)
    if reported_base:
        # The site reported where it lives but not the post's own URL: link to
        # the publication itself rather than guessing a deep link.
        return reported_base

    logger.info("No published URL was reported; omitting the link instead of fabricating one.")
    return None


def fetch_tavily_intelligence(
    query: str,
    max_results: int = 5,
    search_depth: str = "basic",
    include_raw_content: bool = False
) -> Dict[str, Any]:
    """
    Executes a search via the Tavily API to scrape live web intelligence,
    high-ranking competitor pages, and audience discussions.
    Supports 'basic' (balanced medium depth, 1 credit) and 'advanced' (deep, 2 credits).
    """
    import config
    api_key = os.getenv("TAVILY_API_KEY", "").strip() or getattr(config, "TAVILY_API_KEY", "")
    if not api_key:
        logger.info("TAVILY_API_KEY not configured. Using synthetic keyword and audience research.")
        return {"results": [], "answer": None, "error": "TAVILY_API_KEY not configured"}

    if bool(os.getenv("PYTEST_CURRENT_TEST") or os.getenv("TESTING")):
        return {"results": [], "answer": None, "query": query, "offline_test": True}

    # Map friendly depth names: 'medium'/'standard' -> 'basic' (Tavily's balanced tier)
    depth_clean = (search_depth or os.getenv("TAVILY_SEARCH_DEPTH", "basic")).strip().lower()
    depth_map = {
        "medium": "basic",
        "standard": "basic",
        "normal": "basic",
        "deep": "advanced",
    }
    resolved_depth = depth_map.get(depth_clean, depth_clean)
    if resolved_depth not in ("ultra-fast", "fast", "basic", "advanced"):
        resolved_depth = "basic"

    url = "https://api.tavily.com/search"
    payload = {
        "api_key": api_key,
        "query": query,
        "search_depth": resolved_depth,
        "include_answer": True,
        "include_raw_content": include_raw_content,
        "max_results": max_results
    }

    timeout_sec = float(os.getenv("TAVILY_TIMEOUT", "25.0"))

    try:
        with httpx.Client(timeout=timeout_sec) as client:
            response = client.post(url, json=payload)
            if response.status_code == 200:
                data = response.json()
                logger.info(f"Tavily search successful for '{query}'. Found {len(data.get('results', []))} results.")
                return data
            else:
                logger.warning(f"Tavily API returned status {response.status_code}: {response.text[:200]}")
                return {"results": [], "answer": None, "error": f"Tavily HTTP {response.status_code}"}
    except (httpx.TimeoutException, TimeoutError) as t_err:
        logger.warning(f"Tavily search '{query[:60]}' timed out with depth='{search_depth}' ({t_err}). Retrying with fast basic search...")
        if search_depth != "basic":
            try:
                payload["search_depth"] = "basic"
                with httpx.Client(timeout=12.0) as client:
                    response = client.post(url, json=payload)
                    if response.status_code == 200:
                        data = response.json()
                        logger.info(f"Tavily basic fallback successful for '{query[:60]}'. Found {len(data.get('results', []))} results.")
                        return data
            except Exception as retry_err:
                logger.warning(f"Tavily basic retry also failed: {retry_err}")
        return {"results": [], "answer": None, "error": f"Tavily timeout: {t_err}"}
    except Exception as e:
        logger.warning(f"Tavily search request failed: {e}. Falling back to internal heuristic research.")
        return {"results": [], "answer": None, "error": f"Tavily request failed: {e}"}

    return {"results": [], "answer": None, "error": "Tavily returned no usable response"}


def fetch_tavily_extract(urls: List[str]) -> Dict[str, Any]:
    """
    Scrapes the full page content for the given URLs via Tavily Extract.
    Returns {"results": [{url, raw_content}, ...]} (empty on any failure).
    """
    import config
    api_key = os.getenv("TAVILY_API_KEY", "").strip() or getattr(config, "TAVILY_API_KEY", "")
    if not api_key or not urls:
        return {"results": []}

    try:
        with httpx.Client(timeout=20.0) as client:
            response = client.post(
                "https://api.tavily.com/extract",
                json={
                    "api_key": api_key,
                    "urls": urls[:5],
                    "extract_depth": "basic"
                }
            )
            if response.status_code == 200:
                data = response.json()
                results = data.get("results", [])
                logger.info(f"Tavily Extract scraped full content for {len(results)}/{len(urls)} pages.")
                return data
            logger.warning(f"Tavily Extract returned {response.status_code}: {response.text[:200]}")
    except Exception as e:
        logger.warning(f"Tavily Extract request failed: {e}")

    return {"results": []}

