import asyncio
import json
import logging
import uuid
from collections import deque
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, AsyncGenerator
from langgraph.types import Command
from langgraph.checkpoint.memory import MemorySaver

from pipeline.graph import build_content_pipeline
from storage.db import (
    save_pipeline_run,
    update_pipeline_run_status,
    get_pipeline_run,
    get_website_by_id,
    get_default_website,
    resolve_run_website,
    save_verification_report,
)
import os
import config
from pipeline.adapters.slack_bot import build_slack_review_card, send_slack_card, build_approval_banner
from pipeline.topic_researcher import (
    discover_unique_topic,
    fetch_remote_site_titles,
    scrape_website_context,
    DUPLICATE_TOPIC_THRESHOLD,
)
from pipeline.graph import MAX_REVISIONS, build_checkpointer_serializer
from pipeline.utils import is_duplicate_topic
from pipeline.adapters.semantic_matcher import evaluate_anti_cannibalization, CANNIBALIZATION_THRESHOLD
from storage.db import get_all_posts

logger = logging.getLogger("pipeline.manager")


def _build_checkpointer():
    """
    Prefers a durable SQLite checkpointer so runs paused at the human review gate
    survive server restarts; falls back to in-memory if the optional packages
    (langgraph-checkpoint-sqlite + aiosqlite) are not installed.

    Uses AsyncSqliteSaver because the pipeline executes asynchronously
    (astream/ainvoke) and the sync SqliteSaver raises at runtime once invoked
    from an async graph. The saver is constructed inside a dedicated background
    event loop, which it captures; its synchronous bridge methods (e.g. the
    out-of-process Slack listener's invoke()) dispatch onto that loop, so a
    single saver serves both async and sync callers.
    """
    try:
        import threading
        import aiosqlite
        from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
        from config import BASE_DIR

        checkpoint_loop = asyncio.new_event_loop()
        threading.Thread(
            target=checkpoint_loop.run_forever,
            name="checkpoint-sqlite-loop",
            daemon=True,
        ).start()

        # The connection AND the saver must be created ON the checkpoint loop:
        # aiosqlite.connect() returns an awaitable Connection (not a coroutine)
        # and AsyncSqliteSaver.__init__ binds to the currently running loop.
        async def _connect():
            db_file = BASE_DIR / "data" / "pipeline_checkpoints.db"
            if not db_file.parent.exists():
                db_file.parent.mkdir(parents=True, exist_ok=True)
            if not db_file.exists() and (BASE_DIR / "pipeline_checkpoints.db").exists():
                db_file = BASE_DIR / "pipeline_checkpoints.db"
            conn = await aiosqlite.connect(str(db_file))
            serde = build_checkpointer_serializer()
            return AsyncSqliteSaver(conn, serde=serde) if serde is not None else AsyncSqliteSaver(conn)

        saver = asyncio.run_coroutine_threadsafe(
            _connect(),
            checkpoint_loop,
        ).result(timeout=15)
        # NOTE: do NOT eagerly run saver.setup() here. The saver's internal
        # asyncio.Lock binds to the first event loop that awaits it; setup()
        # runs automatically inside every saver method, on whichever loop the
        # caller is on (main loop for the async server, the checkpoint loop for
        # sync-bridge callers like run_slack_listener.py).
        logger.info("Using durable SQLite LangGraph checkpointer (pipeline_checkpoints.db).")
        return saver
    except Exception as e:
        logger.warning(
            f"SQLite checkpointer unavailable ({e}); using in-memory MemorySaver. "
            "Runs paused at the review gate will NOT survive a server restart. "
            "Install langgraph-checkpoint-sqlite for durability."
        )
        serde = build_checkpointer_serializer()
        return MemorySaver(serde=serde) if serde is not None else MemorySaver()


# Global Checkpointer shared across graph executions
GLOBAL_CHECKPOINTER = _build_checkpointer()
COMPILED_PIPELINE = build_content_pipeline(checkpointer=GLOBAL_CHECKPOINTER)


class PipelineManager:
    """
    Central Orchestrator managing background LangGraph executions,
    real-time event streaming via Server-Sent Events (SSE),
    Next.js website publishing, and Slack human review gates.
    Pure backend agent logic — no mock data or simulated flows.
    """

    # Terminal SSE events that end a subscriber stream
    _TERMINAL_EVENTS = ("pipeline_complete", "pipeline_error", "pipeline_rejected")
    # Run statuses that will never progress again; their in-memory snapshots can
    # be released because the SQLite run record stays the source of truth.
    _TERMINAL_RUN_STATUSES = ("completed", "rejected", "error")
    _MAX_BUFFERED_EVENTS = 200
    _MAX_BUFFERED_THREADS = 40
    # Retention cap for per-thread in-memory bookkeeping (~50-80KB per state).
    _MAX_ACTIVE_RUNS = 64
    # Concurrent executing runs allowed at once. Each run drives several LLM,
    # image and scrape calls, so unbounded dispatch (a spammed button, or many
    # schedules firing together) would exhaust provider rate limits. Runs paused
    # at the human review gate do not count toward this cap.
    _MAX_CONCURRENT_RUNS = 5

    def __init__(self):
        self._active_runs: Dict[str, Dict[str, Any]] = {}
        self._listeners: Dict[str, List[asyncio.Queue]] = {}
        self._tasks: Dict[str, asyncio.Task] = {}
        self._review_locks: Dict[str, asyncio.Lock] = {}
        self._event_buffers: Dict[str, deque] = {}

    def _get_or_create_listeners(self, thread_id: str) -> List[asyncio.Queue]:
        if thread_id not in self._listeners:
            self._listeners[thread_id] = []
        return self._listeners[thread_id]

    def _prune_finished_run(self, thread_id: str):
        """Drops per-run bookkeeping for finished runs to avoid unbounded growth.

        Called when the run task ends — either truly finished or paused at the
        review interrupt, in which case the run stays resumable through its
        SQLite record. Terminal runs additionally release their (potentially
        tens-of-KB) state snapshot, drop buffered events, and are evicted
        oldest-first once the retention cap is exceeded.
        """
        self._tasks.pop(thread_id, None)
        self._review_locks.pop(thread_id, None)
        info = self._active_runs.get(thread_id)
        if info and info.get("status") in self._TERMINAL_RUN_STATUSES:
            info.pop("state", None)
            self._event_buffers.pop(thread_id, None)
            self._evict_finished_runs()

    def _evict_finished_runs(self):
        """Evicts oldest terminal run entries once the retention cap is exceeded."""
        while len(self._active_runs) > self._MAX_ACTIVE_RUNS:
            victim = next(
                (
                    tid for tid, info in self._active_runs.items()
                    if info.get("status") in self._TERMINAL_RUN_STATUSES
                ),
                None,
            )
            if victim is None:
                break
            self._active_runs.pop(victim, None)
            self._event_buffers.pop(victim, None)

    async def prune_stale_checkpoints(self, keep_days: int = 30) -> int:
        """Deletes LangGraph checkpoints for long-finished runs.

        Terminal runs no longer need their graph checkpoint (the run row keeps
        the state and assets), and the checkpoints SQLite file otherwise grows
        forever. Resumable runs (queued/running/review_pending/error) are always
        kept. Returns the number of threads pruned.
        """
        from datetime import timedelta
        from storage.db import get_all_pipeline_runs

        delete_thread = getattr(GLOBAL_CHECKPOINTER, "adelete_thread", None)
        if not callable(delete_thread):
            return 0

        terminal_statuses = {"completed", "rejected", "revision_cap_reached"}
        try:
            runs = await asyncio.to_thread(get_all_pipeline_runs, 1000)
        except Exception as err:
            logger.warning(f"Checkpoint retention skipped: {err}")
            return 0

        cutoff = datetime.now(timezone.utc) - timedelta(days=keep_days)
        pruned = 0
        for run in runs:
            thread_id = run.get("thread_id")
            if not thread_id or run.get("status") not in terminal_statuses:
                continue
            if thread_id in self._active_runs:
                continue
            stamp = run.get("updated_at") or run.get("created_at")
            try:
                when = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
                if when.tzinfo is None:
                    when = when.replace(tzinfo=timezone.utc)
            except Exception:
                continue
            if when >= cutoff:
                continue
            try:
                await delete_thread(thread_id)
                pruned += 1
            except Exception as err:
                logger.debug(f"Could not prune checkpoint thread '{thread_id}': {err}")

        if pruned:
            logger.info(f"Checkpoint retention: pruned {pruned} finished run(s) older than {keep_days} days.")
        return pruned

    async def broadcast_event(self, thread_id: str, event_type: str, data: Dict[str, Any]):
        """Emits an SSE event to all connected browser clients for a given thread."""
        payload = {
            "thread_id": thread_id,
            "event": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data": data
        }

        # Buffer events so subscribers that connect after the run started can replay them
        buf = self._event_buffers.setdefault(thread_id, deque(maxlen=self._MAX_BUFFERED_EVENTS))
        buf.append(payload)
        if len(self._event_buffers) > self._MAX_BUFFERED_THREADS:
            for old_id in list(self._event_buffers.keys()):
                if old_id == thread_id:
                    continue
                info = self._active_runs.get(old_id)
                # Evict finished runs and threads with no live run entry at all;
                # pruning must not be blocked by earlier entries being dropped.
                if info is None or info.get("status") in self._TERMINAL_RUN_STATUSES:
                    self._event_buffers.pop(old_id, None)
                if len(self._event_buffers) <= self._MAX_BUFFERED_THREADS:
                    break

        listeners = self._get_or_create_listeners(thread_id)
        for q in listeners:
            try:
                await q.put(payload)
            except Exception as e:
                logger.warning(f"Error queueing event for listener: {e}")

    async def subscribe(self, thread_id: str) -> AsyncGenerator[str, None]:
        """Subscribes an HTTP request to Server-Sent Events (SSE) for thread_id."""
        q = asyncio.Queue()
        listeners = self._get_or_create_listeners(thread_id)
        listeners.append(q)
        logger.info(f"New SSE subscriber connected to thread '{thread_id}' (Total: {len(listeners)})")

        try:
            run_record = get_pipeline_run(thread_id)
            init_data = {
                "event": "connected",
                "thread_id": thread_id,
                "current_status": run_record.get("status") if run_record else "unknown",
                "run": run_record
            }
            yield f"event: connected\ndata: {json.dumps(init_data)}\n\n"

            # Check if this run has already reached a terminal state
            is_terminal = (run_record.get("status") in ("completed", "rejected", "error")) if run_record else False
            if not is_terminal:
                for past in self._event_buffers.get(thread_id, []):
                    if past["event"] in self._TERMINAL_EVENTS:
                        is_terminal = True
                        break

            # Replay buffered events so late subscribers see the full stage history
            for past in list(self._event_buffers.get(thread_id, [])):
                # If run is already completed/terminal, skip replaying interactive review events
                # to prevent reconnecting clients from getting stuck in an infinite review loop.
                if is_terminal and past["event"] == "review_required":
                    continue
                yield f"event: {past['event']}\ndata: {json.dumps(past['data'])}\n\n"

            if is_terminal:
                # Tell EventSource client not to auto-reconnect
                yield "retry: 86400000\n\n"
                return

            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=15.0)
                    yield f"event: {event['event']}\ndata: {json.dumps(event['data'])}\n\n"
                    
                    if event["event"] in self._TERMINAL_EVENTS:
                        yield "retry: 86400000\n\n"
                        break
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        except asyncio.CancelledError:
            logger.info(f"SSE subscriber disconnected from thread '{thread_id}'")
        finally:
            if q in listeners:
                listeners.remove(q)
            if not listeners and thread_id in self._listeners:
                self._listeners.pop(thread_id, None)

    def start_pipeline(
        self,
        topic: Optional[str] = None,
        website_id: Optional[str] = None,
        keywords: Optional[List[str]] = None,
        target_audience: Optional[str] = None,
        mode: Optional[str] = None,
        auto_approve: bool = False,
        content_format: Optional[str] = None,
        content_options: Optional[Dict[str, bool]] = None,
        brand_voice: Optional[str] = None,
        article_depth: Optional[str] = None,
        secondary_keywords: Optional[List[str]] = None,
        niche: Optional[str] = None,
        inject_evidence: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Initiates an autonomous pipeline run targeted at a specific Next.js website."""
        thread_id = f"dispatch-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
        keywords = keywords or []

        in_flight = sum(
            1 for info in self._active_runs.values()
            if info.get("status") in ("queued", "running")
        )
        if in_flight >= self._MAX_CONCURRENT_RUNS:
            raise ValueError(
                f"{in_flight} pipeline runs are already executing "
                f"(limit {self._MAX_CONCURRENT_RUNS}). Wait for one to finish, then retry."
            )

        # Resolve website. An explicitly requested site that no longer exists
        # fails the dispatch instead of silently falling back to the default
        # website, which would cross-publish to an unintended destination.
        target_site = resolve_run_website(website_id)

        resolved_site_id = target_site["id"] if target_site else None
        destination_url = target_site["url"] if target_site else None
        site_name = target_site["name"] if target_site else "Next.js Production Blog"

        initial_topic_label = topic.strip() if (topic and topic.strip()) else f"Autonomous Topic Discovery ({site_name})"

        # Record initial entry in DB
        save_pipeline_run(
            thread_id=thread_id,
            website_id=resolved_site_id,
            destination_url=destination_url,
            topic=initial_topic_label,
            keywords=keywords,
            target_audience=target_audience or "",
            status="queued"
        )

        effective_auto_approve = (
            auto_approve
            or getattr(config, "AUTO_PUBLISH_APPROVED", False)
            or not getattr(config, "REQUIRE_HUMAN_GATE", True)
        )
        run_context = {
            "thread_id": thread_id,
            "website_id": resolved_site_id,
            "destination_url": destination_url,
            "destination_name": site_name,
            "topic": topic.strip() if (topic and topic.strip()) else None,
            "keywords": keywords,
            "secondary_keywords": secondary_keywords or [],
            "target_audience": target_audience.strip() if (target_audience and target_audience.strip()) else None,
            "content_format": content_format.strip() if (content_format and content_format.strip()) else None,
            "brand_voice": brand_voice.strip() if (brand_voice and brand_voice.strip()) else None,
            "article_depth": article_depth or "standard",
            "niche": niche.strip() if (niche and niche.strip()) else None,
            "inject_evidence": inject_evidence if inject_evidence is not None else True,
            "content_options": content_options or {},
            "auto_approve": effective_auto_approve,
            "status": "queued",
            "state": {}
        }
        self._active_runs[thread_id] = run_context

        # Spawn real background LangGraph execution
        try:
            loop = asyncio.get_running_loop()
            task = loop.create_task(self._execute_pipeline(thread_id))
            task.add_done_callback(lambda _t: self._prune_finished_run(thread_id))
            self._tasks[thread_id] = task
        except RuntimeError:
            import threading
            def _bg():
                asyncio.run(self._execute_pipeline(thread_id))
            th = threading.Thread(target=_bg, daemon=True)
            th.start()

        logger.info(f"Pipeline run queued: thread_id={thread_id}, website={site_name}, topic={topic}")
        return {
            "status": "queued",
            "thread_id": thread_id,
            "website_id": resolved_site_id,
            "website_name": site_name,
            "topic": initial_topic_label
        }

    async def _execute_pipeline(self, thread_id: str):
        """Asynchronous worker executing the real 7-stage LangGraph workflow."""
        run_info = self._active_runs.get(thread_id)
        if not run_info:
            return

        topic = run_info.get("topic")
        website_id = run_info.get("website_id")
        site_name = run_info.get("destination_name", "Next.js Blog")
        keywords = list(run_info.get("keywords") or [])
        target_audience = run_info.get("target_audience")
        auto_approve = run_info.get("auto_approve", False)

        # 1. Autonomous Topic & Market Demand Research if no custom topic was provided
        if not topic or not topic.strip():
            await self.broadcast_event(thread_id, "log", {
                "level": "AGENT",
                "message": f"🔍 [Autonomous Research] No custom topic provided. Researching target website '{site_name}' & search demand..."
            })
            # Sync LLM + Tavily research runs in a worker thread so the event loop stays responsive.
            # discover_unique_topic similarity-checks each proposal against the target
            # website's live article list and the local archive, rejecting near-duplicates.
            discovered = await asyncio.to_thread(discover_unique_topic, website_id)
            topic = discovered.get("topic") or f"Authoritative Guide for {site_name}"
            reasoning = discovered.get("reasoning", "High organic search demand identified.")
            site_niche = discovered.get("site_niche")
            niche_slug = discovered.get("niche_slug")
            content_format = run_info.get("content_format") or discovered.get("content_format")
            angle_or_hook = discovered.get("angle_or_hook")
            editorial_persona = discovered.get("editorial_persona")
            information_gain_score = discovered.get("information_gain_score") or 92

            dedupe_info = discovered.get("dedupe") or {}
            if dedupe_info.get("fallback"):
                await self.broadcast_event(thread_id, "log", {
                    "level": "WARN",
                    "message": f"⚠️ Topic dedupe: no unique topic found after {dedupe_info.get('attempt', 3)} attempts. Proceeding with best available proposal."
                })
            else:
                await self.broadcast_event(thread_id, "log", {
                    "level": "SUCCESS",
                    "message": f"💡 [Autonomous Topic Discovered]: '{topic}' ({reasoning}) — verified unique against {dedupe_info.get('checked_against', 0)} existing articles"
                })

            # Auto-populate keywords if user left them empty
            if not keywords and discovered.get("keywords"):
                keywords = discovered["keywords"]
                await self.broadcast_event(thread_id, "log", {
                    "level": "INFO",
                    "message": f"🎯 [Autonomous Keywords Found]: {', '.join(keywords)}"
                })

            # Auto-populate audience if user left it empty
            if not target_audience and discovered.get("target_audience"):
                target_audience = discovered["target_audience"]
                await self.broadcast_event(thread_id, "log", {
                    "level": "INFO",
                    "message": f"👤 [Autonomous Audience Profiled]: {target_audience}"
                })
        else:
            await self.broadcast_event(thread_id, "log", {
                "level": "AGENT",
                "message": f"🚀 Initializing Autonomous Content Pipeline for custom topic: '{topic}'"
            })
            site_obj = resolve_run_website(website_id)
            ctx = scrape_website_context(site_obj)
            site_niche = run_info.get("niche") or ctx.get("editorial_niche")
            niche_slug = ctx.get("niche_slug")
            arch = ctx.get("archetype") or {}
            editorial_persona = run_info.get("brand_voice") or arch.get("persona")
            content_format = run_info.get("content_format") or "Authoritative In-Depth Masterclass"
            angle_or_hook = f"Actionable domain guide tailored to {site_name}"
            information_gain_score = 90

            # Duplicate guard for CUSTOM topics too: if the requested topic matches
            # (or is near-identical to) an existing article on the target website,
            # reject it and autonomously discover a fresh unique topic instead.
            try:
                existing_titles = await asyncio.to_thread(fetch_remote_site_titles, site_obj)
                duplicate = is_duplicate_topic(topic, existing_titles, threshold=DUPLICATE_TOPIC_THRESHOLD)
            except Exception as dedupe_err:
                logger.warning(f"Custom-topic dedupe check failed (continuing): {dedupe_err}")
                duplicate = None

            if duplicate:
                await self.broadcast_event(thread_id, "log", {
                    "level": "WARN",
                    "message": f"🚫 Custom topic '{topic}' is {duplicate['score']:.0%} similar to existing article "
                               f"'{duplicate['title']}' on '{site_name}'. Rejecting and discovering a fresh unique topic..."
                })
                discovered = await asyncio.to_thread(discover_unique_topic, website_id)
                new_topic = (discovered.get("topic") or "").strip()
                if new_topic:
                    topic = new_topic
                    keywords = list(run_info.get("keywords") or []) or (discovered.get("keywords") or keywords)
                    site_niche = discovered.get("site_niche") or site_niche
                    niche_slug = discovered.get("niche_slug") or niche_slug
                    content_format = discovered.get("content_format") or content_format
                    angle_or_hook = discovered.get("angle_or_hook") or angle_or_hook
                    editorial_persona = discovered.get("editorial_persona") or editorial_persona
                    information_gain_score = discovered.get("information_gain_score") or 92
                    run_info["topic"] = topic
                    run_info["keywords"] = keywords
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": f"💡 [Replacement Topic Discovered]: '{topic}' ({discovered.get('reasoning', '')})"
                    })
                    await asyncio.to_thread(
                        save_pipeline_run,
                        thread_id=thread_id,
                        website_id=website_id,
                        destination_url=run_info.get("destination_url"),
                        topic=topic,
                        keywords=keywords,
                        target_audience=target_audience,
                        status="running"
                    )

        default_aud = (arch.get("default_audience") if 'arch' in locals() and arch else None) or "Discerning practitioners, enthusiasts, and active readers"
        target_audience = target_audience or default_aud
        run_info["topic"] = topic
        run_info["keywords"] = keywords
        run_info["target_audience"] = target_audience

        # Update run in DB with resolved topic
        await asyncio.to_thread(
            save_pipeline_run,
            thread_id=thread_id,
            website_id=website_id,
            destination_url=run_info.get("destination_url"),
            topic=topic,
            keywords=keywords,
            target_audience=target_audience,
            status="running"
        )

        await self._run_live_flow(
            thread_id=thread_id,
            topic=topic,
            website_id=website_id,
            site_name=site_name,
            keywords=keywords,
            target_audience=target_audience,
            auto_approve=auto_approve,
            destination_url=run_info.get("destination_url"),
            site_niche=site_niche,
            niche_slug=niche_slug,
            content_format=content_format,
            angle_or_hook=angle_or_hook,
            editorial_persona=editorial_persona,
            information_gain_score=information_gain_score,
        )

    async def _run_live_flow(
        self,
        thread_id: str,
        topic: str,
        website_id: Optional[str],
        site_name: str,
        keywords: List[str],
        target_audience: str,
        auto_approve: bool,
        destination_url: Optional[str] = None,
        site_niche: Optional[str] = None,
        niche_slug: Optional[str] = None,
        content_format: Optional[str] = None,
        angle_or_hook: Optional[str] = None,
        editorial_persona: Optional[str] = None,
        information_gain_score: Optional[int] = None,
    ):
        """Executes live LangGraph StateMachine with real-time SSE stage streaming."""
        config = {"configurable": {"thread_id": thread_id}}
        run_opts = self._active_runs.get(thread_id, {}).get("content_options") or {}
        initial_input = {
            "topic": topic,
            "website_id": website_id,
            "destination_name": site_name,
            # Carry the target site's URL into the graph so link resolution and
            # social copy use the same destination the run row was saved with.
            "destination_url": destination_url,
            "keywords": keywords,
            "target_audience": target_audience,
            "site_niche": site_niche,
            "niche_slug": niche_slug,
            "content_format": content_format,
            "angle_or_hook": angle_or_hook,
            "editorial_persona": editorial_persona,
            "brand_voice": self._active_runs.get(thread_id, {}).get("brand_voice"),
            "article_depth": self._active_runs.get(thread_id, {}).get("article_depth", "standard"),
            "secondary_keywords": self._active_runs.get(thread_id, {}).get("secondary_keywords") or [],
            "inject_evidence": self._active_runs.get(thread_id, {}).get("inject_evidence", True),
            "information_gain_score": information_gain_score,
            "revision_count": 0,
            "review_status": "approved" if auto_approve else "pending",
            "thread_id": thread_id,
            "status": "queued",
            "content_options": run_opts,
            "enable_diagrams": run_opts.get("enable_diagrams", True),
            "enable_tables": run_opts.get("enable_tables", True),
            "enable_faqs": run_opts.get("enable_faqs", True),
            "enable_takeaways": run_opts.get("enable_takeaways", True),
            "enable_answer_blocks": run_opts.get("enable_answer_blocks", True),
            "enable_citations": run_opts.get("enable_citations", True),
            "enable_hero_image": run_opts.get("enable_hero_image", True),
            "enable_visual_assets": run_opts.get("enable_hero_image", True),
            # The manager dispatches its own website-targeted Slack card after the
            # interrupt; prevent review_node from sending a second duplicate card.
            "slack_dispatch": False
        }

        try:
            await asyncio.to_thread(update_pipeline_run_status, thread_id, "running", initial_input)
            await self.broadcast_event(thread_id, "stage_start", {"stage": "outline", "progress": 15})
            if angle_or_hook:
                await self.broadcast_event(thread_id, "log", {
                    "level": "INFO",
                    "message": f"💎 [Information Gain Hook]: {angle_or_hook} ({content_format or 'Masterclass'})"
                })
            await self.broadcast_event(thread_id, "log", {
                "level": "AGENT",
                "message": "🔍 [Stage 1/10 - Outline] Researching topic, ranking keywords & audience intent..."
            })

            accumulated_state = dict(initial_input)
            interrupted = False
            async for chunk in COMPILED_PIPELINE.astream(initial_input, config=config, stream_mode="updates"):
                logger.debug(f"LangGraph chunk for {thread_id}: {list(chunk.keys())}")

                # Accumulate state updates across all chunks
                for node_name, updates in chunk.items():
                    if isinstance(updates, dict):
                        accumulated_state.update(updates)

                # Keep in-memory active runs and SQLite row in sync immediately so UI preview drawer has live state
                if thread_id in self._active_runs:
                    self._active_runs[thread_id]["state"] = accumulated_state
                await asyncio.to_thread(update_pipeline_run_status, thread_id, "running", accumulated_state)

                if "outline" in chunk:
                    node_out = chunk["outline"]
                    disc_kws = node_out.get("discovered_keywords", [])
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "outline", "progress": 20})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "INFO",
                        "message": f"Discovered high-intent keywords: {', '.join(disc_kws[:5]) if disc_kws else topic}"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "draft", "progress": 25})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "✍️ [Stage 2/10 - Draft] Synthesizing comprehensive longform article..."
                    })

                elif "draft" in chunk:
                    node_out = chunk["draft"]
                    title = node_out.get("title", topic)
                    draft_text = node_out.get("draft", "")
                    wc = len(draft_text.split()) if draft_text else 0
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "draft", "progress": 35})
                    await self.broadcast_event(thread_id, "draft_updated", {"draft": draft_text, "title": title})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": f"Draft created: '{title}' ({wc} words, ready for preview)"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "fact_check", "progress": 40})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🛡️ [Stage 3/10 - Fact-Check] Extracting empirical claims & executing multi-source web verification..."
                    })

                elif "fact_check" in chunk:
                    node_out = chunk["fact_check"]
                    fc_score = node_out.get("fact_check_score", 100)
                    verdict = node_out.get("fact_check_verdict", "supported")
                    verified_claims = node_out.get("verified_claims", [])
                    citations = node_out.get("source_citations", [])
                    verification_report = node_out.get("verification_report")
                    req_human = node_out.get("requires_human_approval", False)
                    named_approver = node_out.get("named_human_approver")

                    if verification_report:
                        try:
                            run_info = get_pipeline_run(thread_id) or {}
                            save_verification_report(
                                thread_id=thread_id,
                                report=verification_report,
                                post_slug=run_info.get("slug"),
                                website_id=run_info.get("website_id"),
                            )
                        except Exception as rep_err:
                            logger.warning(f"Could not persist verification report for thread {thread_id}: {rep_err}")

                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "fact_check", "progress": 50})
                    human_gate_note = f" (Human Approver: {named_approver})" if req_human and named_approver else ""
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS" if verdict == "supported" else ("WARN" if verdict in ("needs_revision", "human_approval_required") else "ERROR"),
                        "message": f"🛡️ Fact-Check Complete! Verdict: {verdict.upper()} | Integrity Score: {fc_score}/100 ({len(verified_claims)} claims audited, {len(citations)} citations verified){human_gate_note}"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "aeo", "progress": 55})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🎯 [Stage 4/10 - AEO Engine] Discovering search intent questions & synthesizing direct answer blocks..."
                    })

                elif "aeo" in chunk:
                    node_out = chunk["aeo"]
                    answer_blocks = node_out.get("answer_blocks", [])
                    faq_items = node_out.get("aeo_faq_items", [])
                    eligible = node_out.get("aeo_eligible_targets", [])
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "aeo", "progress": 60})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": f"🎯 AEO Analysis Complete! Synthesized {len(answer_blocks)} direct answer blocks & {len(faq_items)} FAQ items ({len(eligible)} snippet targets qualified)"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "article_studio", "progress": 65})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🏗️ [Stage 5/10 - Article Studio] Building typed document model, enforcing layout blueprint & pre-publish quality gates..."
                    })

                elif "article_studio" in chunk:
                    node_out = chunk["article_studio"]
                    compliance = node_out.get("blueprint_compliance") or {}
                    is_comp = compliance.get("is_compliant", True) if isinstance(compliance, dict) else True
                    visual_plan = node_out.get("visual_plan") or {}
                    proposals = visual_plan.get("proposals", []) if isinstance(visual_plan, dict) else []
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "article_studio", "progress": 70})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS" if is_comp else "WARN",
                        "message": f"🏗️ Article Studio Complete! Blueprint Compliant: {is_comp} | Visual Density: {len(proposals)} visual anchors planned"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "audit", "progress": 75})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🔍 [Stage 6/10 - Audit] Running automated SEO, readability & link architecture audit..."
                    })

                elif "audit" in chunk:
                    node_out = chunk["audit"]
                    seo_score = node_out.get("seo_score", 85)
                    wc = node_out.get("word_count", 0)
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "audit", "progress": 78})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": f"Audit complete! SEO Score: {seo_score}/100 | Word Count: {wc} words"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "image", "progress": 80})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🎨 [Stage 7/10 - Image] Synthesizing bespoke editorial hero visual with provenance..."
                    })

                elif "image" in chunk:
                    node_out = chunk["image"]
                    hero_url = node_out.get("hero_image_url", "")
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "image", "progress": 85})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": f"Hero visual asset generated: {hero_url}"
                    })
                    await self.broadcast_event(thread_id, "stage_start", {"stage": "review_gate", "progress": 86})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "AGENT",
                        "message": "🧑‍⚖️ [Stage 8/10 - Review Gate] Evaluating quality thresholds & human review policies..."
                    })

                elif "publish" in chunk:
                    node_out = chunk["publish"]
                    pub_url = node_out.get("published_url") or ""
                    if node_out.get("status") == "failed" or (node_out.get("publish_error") and not pub_url):
                        await self.broadcast_event(thread_id, "log", {
                            "level": "ERROR",
                            "message": f"❌ [Stage 9/10 - Publish] Publish failed: {node_out.get('publish_error') or 'unknown error'}"
                        })
                    else:
                        await self.broadcast_event(thread_id, "stage_complete", {"stage": "publish", "progress": 95})
                        await self.broadcast_event(thread_id, "log", {
                            "level": "SUCCESS",
                            "message": f"🚀 [Stage 9/10 - Publish] Article published: {pub_url}"
                        })
                        await self.broadcast_event(thread_id, "stage_start", {"stage": "repurpose", "progress": 96})
                        await self.broadcast_event(thread_id, "log", {
                            "level": "AGENT",
                            "message": "🌐 [Stage 10/10 - Repurpose] Generating multi-channel social repurposing assets..."
                        })

                elif "repurpose" in chunk:
                    await self.broadcast_event(thread_id, "stage_complete", {"stage": "repurpose", "progress": 100})
                    await self.broadcast_event(thread_id, "log", {
                        "level": "SUCCESS",
                        "message": "🎉 Multi-channel social distribution assets created and ready!"
                    })


                elif "__interrupt__" in chunk:
                    interrupted = True
                    break

            state = (await COMPILED_PIPELINE.aget_state(config)).values
            if thread_id in self._active_runs:
                self._active_runs[thread_id]["state"] = state

            if interrupted:
                logger.info(f"Thread {thread_id} paused at review_gate interrupt")
                await asyncio.to_thread(update_pipeline_run_status, thread_id, "review_pending", state)
                await self.broadcast_event(thread_id, "stage_start", {"stage": "review_gate", "progress": 80})

                # Dispatch Slack card if configured (per-website or global credentials) and enabled in settings
                await self._dispatch_review_slack_card(thread_id, state, site_name, website_id)

                await self.broadcast_event(thread_id, "log", {
                    "level": "WARN",
                    "message": f"⏸️ Pipeline paused at Human Editorial Review Gate for '{site_name}'. Awaiting browser or Slack approval."
                })
                await self.broadcast_event(thread_id, "review_required", {
                    "thread_id": thread_id,
                    "website_id": website_id,
                    "website_name": site_name,
                    "title": state.get("title"),
                    "slug": state.get("slug"),
                    "seo_score": state.get("seo_score", 85),
                    "word_count": state.get("word_count", 0),
                    "read_time": state.get("read_time", 1),
                    "hero_image_url": state.get("hero_image_url"),
                    "draft": state.get("draft"),
                    "revision_count": state.get("revision_count", 0),
                    "audit_notes": state.get("audit_notes")
                })
            else:
                await self._finalize_run(thread_id, state)

        except Exception as e:
            logger.error(f"Live pipeline execution error: {e}", exc_info=True)
            # Persist the partial state so failures can be inspected/resumed later
            err_state = {}
            try:
                err_state = (await COMPILED_PIPELINE.aget_state(config)).values or {}
            except Exception:
                pass
            await asyncio.to_thread(update_pipeline_run_status, thread_id, "error", err_state)
            await self.broadcast_event(thread_id, "log", {
                "level": "ERROR",
                "message": f"❌ Pipeline execution error: {str(e)}"
            })
            await self.broadcast_event(thread_id, "pipeline_error", {"error": str(e), "thread_id": thread_id})

    async def review_run(
        self,
        thread_id: str,
        action: str,
        feedback: Optional[str] = None,
        wait: bool = True,
    ) -> Dict[str, Any]:
        """Handles human review action (approve, request_changes, reject) and resumes LangGraph.

        With wait=False the resume executes as a background task and this method
        returns immediately with status 'accepted' (or 'busy'). The dashboard uses
        this so the HTTP request doesn't block for the multi-minute redraft/publish
        cycle. Slack integrations keep the default wait=True so they can react to
        the final outcome.
        """
        # Serialize concurrent review actions for the same thread (e.g. Slack click
        # racing a dashboard click) to prevent interleaved graph resumes.
        lock = self._review_locks.setdefault(thread_id, asyncio.Lock())
        if lock.locked():
            return {"status": "busy", "thread_id": thread_id, "message": "A review action is already being processed for this run."}

        # Synchronous terminal-state guard: with wait=False the caller gets an
        # immediate verdict instead of an 'accepted' that silently no-ops later
        # in the background task.
        db_run = await asyncio.to_thread(get_pipeline_run, thread_id)
        run_status = (db_run or {}).get("status")
        is_revision = action in ("request_changes", "changes_requested")
        reopen_completed = False
        # 'error' runs stay reviewable so a failed publish can be retried with
        # another approve (the publish node preserved the draft in the archive).
        if run_status in ("completed", "rejected"):
            if not is_revision:
                logger.info(f"Ignoring review action '{action}' for thread '{thread_id}' (already {run_status})")
                return {"status": run_status, "thread_id": thread_id, "message": f"Run already {run_status}; review action ignored."}
            if run_status == "rejected":
                return {"status": run_status, "thread_id": thread_id, "message": "Rejected runs are archived and cannot be re-opened for revisions."}
            reopen_completed = True

        pending = self._tasks.get(thread_id)
        if pending and not pending.done():
            return {"status": "busy", "thread_id": thread_id, "message": "A review action is already being processed for this run."}

        async def _run_action():
            if reopen_completed:
                return await self._revise_completed_run(thread_id, (db_run or {}).get("state") or {}, feedback)
            return await self._review_run_locked(thread_id, action, feedback)

        if not wait:
            async def _bg_review():
                async with lock:
                    await _run_action()

            loop = asyncio.get_running_loop()
            task = loop.create_task(_bg_review())
            task.add_done_callback(lambda _t: self._prune_review_task(thread_id, task))
            self._tasks[thread_id] = task
            logger.info(f"Review action '{action}' for thread '{thread_id}' dispatched to background (non-blocking).")
            return {"status": "accepted", "thread_id": thread_id, "action": action}

        async with lock:
            return await _run_action()

    async def resume_review(
        self, thread_id: str, action: str, feedback: Optional[str] = None
    ) -> Dict[str, Any]:
        """Resumes a paused review gate run (delegates to review_run)."""
        return await self.review_run(thread_id=thread_id, action=action, feedback=feedback)

    async def get_run_state(self, thread_id: str) -> Optional[Dict[str, Any]]:
        """Returns the in-memory or persisted LangGraph state for a given run."""
        run = self._active_runs.get(thread_id)
        if run and run.get("state"):
            return run["state"]
        from storage.db import get_pipeline_run
        db_run = await asyncio.to_thread(get_pipeline_run, thread_id)
        return (db_run or {}).get("state")

    def _prune_review_task(self, thread_id: str, task: "asyncio.Task"):
        """Drops the bookkeeping entry for a finished background review task."""
        if self._tasks.get(thread_id) is task:
            self._tasks.pop(thread_id, None)

    async def _dispatch_review_slack_card(
        self, thread_id: str, state: Dict[str, Any], site_name: str, website_id: Optional[str]
    ) -> None:
        """Sends (or reports why it could not send) the review card to Slack.

        Shared by the first interrupt and every revision re-interrupt: the
        original card still shows the pre-revision draft, so revisions 2+ would
        otherwise wait silently with nothing to review in Slack.
        """
        notify_review = getattr(config, "NOTIFY_REVIEW_NEEDED", True)
        site = await asyncio.to_thread(get_website_by_id, website_id) if website_id else None
        global_bot = os.getenv("SLACK_BOT_TOKEN", "").strip() or getattr(config, "SLACK_BOT_TOKEN", "")
        global_chan = os.getenv("SLACK_CHANNEL_ID", "").strip() or getattr(config, "SLACK_CHANNEL_ID", "")
        has_global_slack = bool(global_bot and not global_bot.startswith("xoxb-your") and global_chan and not global_chan.startswith("C0123"))

        if not (notify_review and ((site and site.get("slack_enabled")) or has_global_slack)):
            return

        card = build_slack_review_card(state, website_name=site_name, website_id=website_id)
        hook_url = site.get("slack_webhook_url") if site else None
        chan_id = (site.get("slack_channel_id") if site else None) or global_chan
        if chan_id and chan_id.startswith("https://hooks.slack.com/"):
            hook_url = chan_id
            chan_id = None
        slack_res = await asyncio.to_thread(
            send_slack_card,
            card,
            webhook_url=hook_url,
            channel_override=chan_id
        )
        if slack_res.get("ok"):
            if slack_res.get("ts"):
                state["slack_message_ts"] = slack_res.get("ts")
            if slack_res.get("channel"):
                state["slack_channel_id"] = slack_res.get("channel")
            elif chan_id:
                state["slack_channel_id"] = chan_id
            await asyncio.to_thread(update_pipeline_run_status, thread_id, "review_pending", state)
            await self.broadcast_event(thread_id, "log", {
                "level": "INFO",
                "message": f"📱 Review card sent to Slack ({chan_id or 'Incoming Webhook'}). Waiting for approval..."
            })
        elif slack_res.get("skipped"):
            # No credential was present — say so instead of claiming a send.
            await self.broadcast_event(thread_id, "log", {
                "level": "WARN",
                "message": (
                    "📱 Slack review card was not sent "
                    f"({slack_res.get('reason') or 'no Slack credentials configured'}). "
                    "Approve or request changes from the dashboard."
                )
            })
        else:
            await self.broadcast_event(thread_id, "log", {
                "level": "WARN",
                "message": (
                    "⚠️ Slack review card could not be delivered: "
                    f"{slack_res.get('error') or 'unknown Slack error'}. "
                    "Approve or request changes from the dashboard."
                )
            })

    async def _review_run_locked(self, thread_id: str, action: str, feedback: Optional[str] = None) -> Dict[str, Any]:
        """Core review handling, executed under the per-thread review lock."""
        config = {"configurable": {"thread_id": thread_id}}
        run_info = self._active_runs.get(thread_id)
        current_state = run_info.get("state", {}) if run_info else {}
        if not current_state:
            db_run = get_pipeline_run(thread_id)
            if db_run and db_run.get("state"):
                current_state = db_run["state"]

        site_name = current_state.get("destination_name") or "Next.js Blog"
        website_id = current_state.get("website_id")
        logger.info(f"Review action received for thread '{thread_id}': action='{action}', feedback='{feedback}'")

        # Idempotency guard: ignore review actions for runs that already reached a
        # terminal state, UNLESS the editor is requesting changes on a completed/archived draft.
        db_run = await asyncio.to_thread(get_pipeline_run, thread_id)
        run_status = (db_run or {}).get("status")
        # 'error' runs stay reviewable so a failed publish can be retried with
        # another approve (the publish node preserved the draft in the archive).
        if run_status in ("completed", "rejected"):
            if action in ["request_changes", "changes_requested"]:
                logger.info(f"Re-opening completed/archived run '{thread_id}' for revision based on editor feedback.")
                return await self._revise_completed_run(thread_id, current_state, feedback)
            else:
                logger.info(f"Ignoring review action '{action}' for thread '{thread_id}' (already {run_status})")
                return {
                    "status": run_status,
                    "thread_id": thread_id,
                    "message": f"Run already {run_status}; review action ignored."
                }

        try:
            if action in ["approve", "approved"]:
                await self.broadcast_event(thread_id, "log", {
                    "level": "SUCCESS",
                    "message": f"✅ Human Editor Approved dispatch! Resuming pipeline for publishing to {site_name}..."
                })
                await self.broadcast_event(thread_id, "stage_complete", {"stage": "review_gate", "progress": 85})
                await self.broadcast_event(thread_id, "stage_start", {"stage": "publish", "progress": 86})

                # A re-opened (completed/errored) run has no pending interrupt to
                # resume; executing the publish+repurpose nodes directly is the
                # only way approval can still publish the revised draft.
                graph_snap = await COMPILED_PIPELINE.aget_state(config)
                if getattr(graph_snap, "next", None):
                    approval_cmd = Command(resume="approved")
                    async for chunk in COMPILED_PIPELINE.astream(approval_cmd, config=config, stream_mode="updates"):
                        if "publish" in chunk:
                            node_out = chunk["publish"]
                            pub_url = node_out.get("published_url") or ""
                            if node_out.get("status") == "failed" or (node_out.get("publish_error") and not pub_url):
                                await self.broadcast_event(thread_id, "log", {
                                    "level": "ERROR",
                                    "message": f"❌ [Stage 6/7 - Publish] Publish failed: {node_out.get('publish_error') or 'unknown error'}"
                                })
                            else:
                                await self.broadcast_event(thread_id, "stage_complete", {"stage": "publish", "progress": 90})
                                await self.broadcast_event(thread_id, "log", {
                                     "level": "SUCCESS",
                                     "message": f"🚀 [Stage 9/10 - Publish] Article published: {pub_url}"
                                 })
                                await self.broadcast_event(thread_id, "stage_start", {"stage": "repurpose", "progress": 95})
                                await self.broadcast_event(thread_id, "log", {
                                     "level": "AGENT",
                                     "message": "🌐 [Stage 10/10 - Repurpose] Generating multi-channel social repurposing assets..."
                                 })
                        elif "repurpose" in chunk:
                            await self.broadcast_event(thread_id, "stage_complete", {"stage": "repurpose", "progress": 100})
                            await self.broadcast_event(thread_id, "log", {
                                "level": "SUCCESS",
                                "message": "🎉 Multi-channel social distribution assets created and ready!"
                            })
                    resumed_state = (await COMPILED_PIPELINE.aget_state(config)).values
                else:
                    from pipeline.nodes.publish_node import publish_node
                    from pipeline.nodes.repurpose_node import repurpose_node
                    resumed_state = dict(current_state)
                    resumed_state["review_status"] = "approved"
                    pub_out = await asyncio.to_thread(publish_node, resumed_state)
                    resumed_state.update(pub_out)
                    if pub_out.get("status") != "failed":
                        rep_out = await asyncio.to_thread(repurpose_node, resumed_state)
                        resumed_state.update(rep_out)


                await self._finalize_run(thread_id, resumed_state)
                if (resumed_state or {}).get("publish_error") and not (resumed_state or {}).get("published_url"):
                    return {"status": "error", "thread_id": thread_id, "error": resumed_state.get("publish_error")}
                return {"status": "approved", "thread_id": thread_id}

            elif action in ["request_changes", "changes_requested"]:
                rev_count = current_state.get("revision_count", 0) + 1
                if rev_count > MAX_REVISIONS:
                    # Router would end the graph anyway; close the run out cleanly
                    # here so the DB/SSE state reflects a finished revision cycle.
                    await self.broadcast_event(thread_id, "log", {
                        "level": "WARN",
                        "message": f"🛑 Revision cap ({MAX_REVISIONS}) reached. Run closed without publishing."
                    })
                    await asyncio.to_thread(update_pipeline_run_status, thread_id, "revision_cap_reached", current_state)
                    self._prune_finished_run(thread_id)
                    await self.broadcast_event(thread_id, "pipeline_rejected", {
                        "thread_id": thread_id,
                        "reason": "revision_cap_reached"
                    })
                    return {"status": "revision_cap_reached", "thread_id": thread_id, "revision_count": current_state.get("revision_count", 0)}

                await self.broadcast_event(thread_id, "log", {
                    "level": "WARN",
                    "message": f"📝 Changes requested by editor (Revision #{rev_count}): '{feedback or 'General revisions'}'"
                })
                await asyncio.to_thread(update_pipeline_run_status, thread_id, "running", current_state)
                await self.broadcast_event(thread_id, "stage_start", {"stage": "draft", "progress": 35})

                rev_cmd = Command(resume={"action": "request_changes", "feedback": feedback})
                async for chunk in COMPILED_PIPELINE.astream(rev_cmd, config=config, stream_mode="updates"):
                    if "draft" in chunk:
                        node_out = chunk["draft"]
                        await self.broadcast_event(thread_id, "stage_complete", {"stage": "draft", "progress": 50})
                        await self.broadcast_event(thread_id, "log", {
                            "level": "SUCCESS",
                            "message": f"Draft revised based on editorial feedback! Title: '{node_out.get('title')}'"
                        })
                        await self.broadcast_event(thread_id, "stage_start", {"stage": "audit", "progress": 55})
                    elif "audit" in chunk:
                        node_out = chunk["audit"]
                        await self.broadcast_event(thread_id, "stage_complete", {"stage": "audit", "progress": 65})
                        await self.broadcast_event(thread_id, "log", {
                            "level": "SUCCESS",
                            "message": f"Revised SEO Audit complete! Score: {node_out.get('seo_score')}/100"
                        })
                        await self.broadcast_event(thread_id, "stage_start", {"stage": "image", "progress": 70})
                    elif "image" in chunk:
                        node_out = chunk["image"]
                        await self.broadcast_event(thread_id, "stage_complete", {"stage": "image", "progress": 75})
                        await self.broadcast_event(thread_id, "log", {
                            "level": "INFO",
                            "message": f"Hero visual ready: {node_out.get('hero_image_url', '')}"
                        })

                graph_snap = await COMPILED_PIPELINE.aget_state(config)
                rev_state = graph_snap.values
                if not getattr(graph_snap, "next", None):
                    # The router ended the graph (revision cap) instead of
                    # re-interrupting at the gate. Close the run out cleanly so it
                    # doesn't linger in the review inbox as a zombie.
                    final_state = rev_state or current_state
                    await self.broadcast_event(thread_id, "log", {
                        "level": "WARN",
                        "message": f"🛑 Revision cap ({MAX_REVISIONS}) reached. Run closed without publishing."
                    })
                    await asyncio.to_thread(update_pipeline_run_status, thread_id, "revision_cap_reached", final_state)
                    self._prune_finished_run(thread_id)
                    await self.broadcast_event(thread_id, "pipeline_rejected", {
                        "thread_id": thread_id,
                        "reason": "revision_cap_reached"
                    })
                    return {"status": "revision_cap_reached", "thread_id": thread_id, "revision_count": final_state.get("revision_count", rev_count)}

                if thread_id in self._active_runs:
                    self._active_runs[thread_id]["state"] = rev_state
                await asyncio.to_thread(update_pipeline_run_status, thread_id, "review_pending", rev_state)
                await self.broadcast_event(thread_id, "stage_start", {"stage": "review_gate", "progress": 80})
                await self.broadcast_event(thread_id, "review_required", {
                    "thread_id": thread_id,
                    "website_id": website_id,
                    "website_name": site_name,
                    "title": rev_state.get("title"),
                    "slug": rev_state.get("slug"),
                    "seo_score": rev_state.get("seo_score", 85),
                    "word_count": rev_state.get("word_count", 0),
                    "read_time": rev_state.get("read_time", 1),
                    "hero_image_url": rev_state.get("hero_image_url"),
                    "draft": rev_state.get("draft"),
                    "revision_count": rev_state.get("revision_count", rev_count),
                    "audit_notes": rev_state.get("audit_notes")
                })
                # The original Slack card still shows the pre-revision draft, so
                # send a fresh card for this revision as well.
                await self._dispatch_review_slack_card(thread_id, rev_state, site_name, website_id)
                return {"status": "changes_requested", "thread_id": thread_id, "revision_count": rev_state.get("revision_count", rev_count)}

            else:
                # Reject
                await self.broadcast_event(thread_id, "log", {
                    "level": "WARN",
                    "message": "❌ Dispatch rejected by editor. Run cancelled and archived."
                })
                reject_cmd = Command(resume={"action": "reject"})
                async for _ in COMPILED_PIPELINE.astream(reject_cmd, config=config, stream_mode="updates"):
                    pass
                await asyncio.to_thread(update_pipeline_run_status, thread_id, "rejected", current_state)
                self._prune_finished_run(thread_id)
                await self.broadcast_event(thread_id, "pipeline_rejected", {"thread_id": thread_id})
                return {"status": "rejected", "thread_id": thread_id}

        except Exception as e:
            logger.error(f"Error handling review action '{action}': {e}", exc_info=True)
            await self.broadcast_event(thread_id, "log", {
                "level": "ERROR",
                "message": f"❌ Error resuming pipeline: {str(e)}"
            })
            await self.broadcast_event(thread_id, "pipeline_error", {"error": str(e), "thread_id": thread_id})
            # Restore the pre-action status so the editor can retry: the LangGraph
            # interrupt is still pending in the checkpointer.
            try:
                await asyncio.to_thread(
                    update_pipeline_run_status,
                    thread_id,
                    run_status or "review_pending",
                    current_state,
                )
            except Exception:
                pass
            return {"status": "error", "error": str(e), "thread_id": thread_id}

    async def _finalize_run(self, thread_id: str, state: Dict[str, Any]):
        """Marks pipeline run completed in DB and broadcasts completion event.

        If the publish node reported a failure (state['publish_error'] with no
        published_url), the run is marked 'error' instead of 'completed' so
        automation cannot mistake a failed dispatch for a successful one.
        """
        website_id = state.get("website_id")
        site_name = state.get("destination_name", "Next.js Blog")
        title = state.get("title", "Untitled Article")
        slug = state.get("slug", "")
        # Never fabricate a /posts/<slug> deep link: a site may have confirmed
        # the publish without reporting a URL. None stays None (announced as
        # 'link not reported') instead of pointing users at a possible 404.
        published_url = state.get("published_url")

        # Publish failure propagation: never mark a failed dispatch 'completed'.
        if state.get("publish_error") and not state.get("published_url"):
            publish_error = str(state.get("publish_error"))
            state["status"] = "error"
            await asyncio.to_thread(update_pipeline_run_status, thread_id, "error", state)
            if thread_id in self._active_runs:
                self._active_runs[thread_id]["status"] = "error"
                self._active_runs[thread_id]["state"] = state
            await self.broadcast_event(thread_id, "log", {
                "level": "ERROR",
                "message": f"❌ Publish failed for '{title}': {publish_error}. Run marked as error — approve again to retry."
            })
            await self.broadcast_event(thread_id, "pipeline_error", {
                "error": f"Publish failed: {publish_error}",
                "thread_id": thread_id,
                "stage": "publish"
            })
            return
        hero_image_url = state.get("hero_image_url", "")
        linkedin_post = state.get("linkedin_post", "")
        twitter_thread = state.get("twitter_thread", [])

        state["status"] = "completed"
        state["published_url"] = published_url
        await asyncio.to_thread(update_pipeline_run_status, thread_id, "completed", state)
        if thread_id in self._active_runs:
            self._active_runs[thread_id]["status"] = "completed"
            self._active_runs[thread_id]["state"] = state
        self._prune_finished_run(thread_id)

        # Keep the review card in sync with the published state when enabled.
        bot_token = os.getenv("SLACK_BOT_TOKEN", "").strip() or getattr(config, "SLACK_BOT_TOKEN", "")
        slack_ts = state.get("slack_message_ts")
        slack_chan = state.get("slack_channel_id")
        if getattr(config, "NOTIFY_SLACK_SYNC", True) and bot_token and not bot_token.startswith("xoxb-your") and slack_ts and slack_chan:
            try:
                from slack_sdk import WebClient
                client = WebClient(token=bot_token)
                new_blocks = build_approval_banner(
                    title=title,
                    user_name="editorial-bot",
                    published_url=published_url,
                    site_name=site_name
                )
                await asyncio.to_thread(
                    client.chat_update,
                    channel=slack_chan,
                    ts=slack_ts,
                    text=f"✅ Approved and published: {title}",
                    blocks=new_blocks
                )
            except Exception as e:
                logger.warning(f"Could not update Slack card banner for thread {thread_id}: {e}")

        # Published confirmations are a separate preference from updating the
        # existing interactive review card.
        if getattr(config, "NOTIFY_PUBLISHED", True):
            try:
                site = get_website_by_id(website_id) if website_id else None
                site_slack_enabled = site.get("slack_enabled", True) if site else True
                if site_slack_enabled:
                    hook_url = site.get("slack_webhook_url") if site else None
                    channel = (
                        (site.get("slack_channel_id") if site else None)
                        or state.get("slack_channel_id")
                        or os.getenv("SLACK_CHANNEL_ID", "").strip()
                        or getattr(config, "SLACK_CHANNEL_ID", "")
                    )
                    text = (
                        f"Article published: {title} — {published_url}"
                        if published_url
                        else f"Article published: {title} (live link not reported by the site)"
                    )
                    if hook_url:
                        import httpx
                        response = await asyncio.to_thread(httpx.post, hook_url, json={"text": text}, timeout=10.0)
                        response.raise_for_status()
                    elif bot_token and not bot_token.startswith("xoxb-your") and channel:
                        from slack_sdk import WebClient
                        client = WebClient(token=bot_token)
                        await asyncio.to_thread(client.chat_postMessage, channel=channel, text=text)
            except Exception as e:
                logger.warning(f"Could not send published notification for thread {thread_id}: {e}")

        await self.broadcast_event(thread_id, "pipeline_complete", {
            "thread_id": thread_id,
            "website_id": website_id,
            "website_name": site_name,
            "status": "completed",
            "published_url": published_url,
            "title": title,
            "slug": slug,
            "seo_score": state.get("seo_score", 0),
            "hero_image_url": hero_image_url,
            "linkedin_post": linkedin_post,
            "twitter_thread": twitter_thread
        })

    async def _revise_completed_run(self, thread_id: str, state: Dict[str, Any], feedback: Optional[str] = None) -> Dict[str, Any]:
        """Re-opens a finished or archived run to apply editorial revisions to its draft directly."""
        from pipeline.nodes.draft_node import generate_draft
        from pipeline.nodes.audit_node import audit_and_optimize_seo

        rev_count = state.get("revision_count", 1) + 1
        site_name = state.get("destination_name") or "Next.js Blog"
        website_id = state.get("website_id")

        await self.broadcast_event(thread_id, "log", {
            "level": "WARN",
            "message": f"📝 Re-opening dispatch for revision #{rev_count}: '{feedback or 'General revisions'}'"
        })
        await asyncio.to_thread(update_pipeline_run_status, thread_id, "running", state)
        await self.broadcast_event(thread_id, "stage_start", {"stage": "draft", "progress": 35})

        draft_res = await asyncio.to_thread(
            generate_draft,
            outline=state.get("outline", ""),
            topic=state.get("topic", ""),
            keywords=state.get("keywords", []),
            discovered_keywords=state.get("discovered_keywords"),
            audience_insights=state.get("audience_insights"),
            search_sources=state.get("search_sources"),
            reviewer_feedback=feedback,
            revision_count=rev_count,
            review_status="pending",
            existing_draft=state.get("draft")
        )

        new_draft = draft_res.get("draft", state.get("draft", ""))
        new_title = draft_res.get("title", state.get("title", ""))

        await self.broadcast_event(thread_id, "stage_complete", {"stage": "draft", "progress": 50})
        await self.broadcast_event(thread_id, "log", {
            "level": "SUCCESS",
            "message": f"Draft revised based on editorial feedback! Title: '{new_title}'"
        })
        await self.broadcast_event(thread_id, "stage_start", {"stage": "audit", "progress": 65})

        audit_res = await asyncio.to_thread(
            audit_and_optimize_seo,
            title=new_title,
            draft=new_draft,
            topic=state.get("topic", ""),
            keywords=state.get("keywords", []),
            discovered_keywords=state.get("discovered_keywords")
        )

        await self.broadcast_event(thread_id, "stage_complete", {"stage": "audit", "progress": 75})

        state["draft"] = new_draft
        state["title"] = new_title
        state["revision_count"] = rev_count
        state["review_status"] = "pending"
        state["reviewer_feedback"] = None
        state["seo_score"] = audit_res.get("seo_score", state.get("seo_score", 85))
        state["slug"] = audit_res.get("slug", state.get("slug"))
        state["meta_title"] = audit_res.get("meta_title", state.get("meta_title"))
        state["meta_description"] = audit_res.get("meta_description", state.get("meta_description"))
        state["tags"] = audit_res.get("tags", state.get("tags"))
        state["audit_notes"] = audit_res.get("audit_notes", state.get("audit_notes"))
        state["word_count"] = audit_res.get("word_count", state.get("word_count"))
        state["read_time"] = audit_res.get("read_time", state.get("read_time"))

        if thread_id in self._active_runs:
            self._active_runs[thread_id]["state"] = state
            self._active_runs[thread_id]["status"] = "review_pending"

        await asyncio.to_thread(update_pipeline_run_status, thread_id, "review_pending", state)
        await self.broadcast_event(thread_id, "stage_start", {"stage": "review_gate", "progress": 80})
        await self.broadcast_event(thread_id, "review_required", {
            "thread_id": thread_id,
            "website_id": website_id,
            "website_name": site_name,
            "title": new_title,
            "slug": state.get("slug"),
            "seo_score": state.get("seo_score"),
            "word_count": state.get("word_count"),
            "read_time": state.get("read_time"),
            "hero_image_url": state.get("hero_image_url"),
            "draft": new_draft,
            "revision_count": rev_count,
            "audit_notes": state.get("audit_notes")
        })

        return {"status": "changes_requested", "thread_id": thread_id, "revision_count": rev_count}


# Global singleton instance
pipeline_manager = PipelineManager()
