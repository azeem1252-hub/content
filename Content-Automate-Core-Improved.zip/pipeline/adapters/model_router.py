"""
Config-Driven Model Router (Pillar A3.1).

Routes LLM requests to appropriate models based on role:
- Fast model for sectional drafting (e.g. gemini-2.5-flash, mistral, groq, qwen)
- Stronger, distinct model for self-critique, verification, and editorial auditing (e.g. gemini-2.5-pro, gpt-4o, claude-3-7-sonnet)
Unified behind call_llm / get_chat_model interface.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional, Tuple

import config
from pipeline.llm_client import call_llm, _get_configured_providers

logger = logging.getLogger("pipeline.adapters.model_router")

# Role definitions
ROLE_DRAFTING = "drafting"
ROLE_CRITIC = "critic"
ROLE_VERIFICATION = "verification"
ROLE_GENERAL = "general"


def resolve_model_route(role: str = ROLE_GENERAL) -> Dict[str, str]:
    """
    Resolves the provider and model for a given operational role.
    Respects DRAFTING_MODEL and CRITIC_MODEL in config or environment.
    """
    configured = _get_configured_providers()
    active_preferred = (os.getenv("PREFERRED_PROVIDER", "").strip() or getattr(config, "PREFERRED_PROVIDER", "") or "mistral").lower()

    if role == ROLE_DRAFTING:
        # Fast model for sectional generation
        configured_draft_model = getattr(config, "DRAFTING_MODEL", "") or os.getenv("DRAFTING_MODEL", "")
        if configured_draft_model:
            # Check if format is "provider/model"
            if "/" in configured_draft_model:
                parts = configured_draft_model.split("/", 1)
                return {"role": role, "provider": parts[0], "model": parts[1]}
            return {"role": role, "provider": active_preferred, "model": configured_draft_model}

        # Fast model defaults by available provider
        if "gemini" in configured:
            return {"role": role, "provider": "gemini", "model": "gemini-2.5-flash"}
        if "groq" in configured:
            return {"role": role, "provider": "groq", "model": getattr(config, "GROQ_MODEL", "qwen/qwen3.8-27b")}
        if "mistral" in configured:
            return {"role": role, "provider": "mistral", "model": getattr(config, "MISTRAL_MODEL", "ministral-14b-latest")}
        return {"role": role, "provider": active_preferred, "model": "default"}

    elif role in (ROLE_CRITIC, ROLE_VERIFICATION):
        # Stronger model for self-critique and verification
        configured_critic_model = getattr(config, "CRITIC_MODEL", "") or os.getenv("CRITIC_MODEL", "")
        if configured_critic_model:
            if "/" in configured_critic_model:
                parts = configured_critic_model.split("/", 1)
                return {"role": role, "provider": parts[0], "model": parts[1]}
            return {"role": role, "provider": active_preferred, "model": configured_critic_model}

        # Strong model defaults by available provider (prefers deep analysis models)
        if "claude" in configured:
            return {"role": role, "provider": "claude", "model": getattr(config, "ANTHROPIC_MODEL", "claude-3-7-sonnet-20250219")}
        if "openai" in configured:
            return {"role": role, "provider": "openai", "model": getattr(config, "OPENAI_MODEL", "gpt-4o")}
        if "gemini" in configured:
            return {"role": role, "provider": "gemini", "model": "gemini-3.1-pro-preview"}
        if "deepseek" in configured:
            return {"role": role, "provider": "deepseek", "model": getattr(config, "DEEPSEEK_MODEL", "deepseek-chat")}
        return {"role": role, "provider": active_preferred, "model": "default"}

    return {"role": role, "provider": active_preferred, "model": "default"}


def routed_call_llm(
    role: str,
    prompt: str,
    system_instruction: Optional[str] = None,
    temperature: float = 0.7,
    max_retries: int = 3,
) -> Tuple[str, Dict[str, str]]:
    """
    Executes an LLM call routed to the optimal model for the given role.
    Returns:
        (response_content, route_telemetry)
    """
    route = resolve_model_route(role)
    provider = route.get("provider")
    model = route.get("model")
    model_arg = None if model == "default" else model

    logger.info(f"Model Router dispatching role='{role}' to provider='{provider}' model='{model}'")
    content = call_llm(
        prompt=prompt,
        system_instruction=system_instruction,
        temperature=temperature,
        max_retries=max_retries,
        provider_override=provider,
        model_override=model_arg,
    )

    telemetry = {
        "role": role,
        "provider": provider or "auto",
        "model": model or "default",
    }
    return content, telemetry
