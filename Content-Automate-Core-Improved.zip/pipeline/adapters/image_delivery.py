"""
A5c.5 Image Delivery, Performance & SEO Engine.

Implements modern high-performance delivery standards:
1. AVIF/WebP with fallback markup (<picture> with srcset and sizes).
2. Explicit width and height attributes preventing Cumulative Layout Shift (CLS).
3. LCP Image Optimization:
   - The likely LCP image is NEVER lazy-loaded (load eagerly, fetchpriority="high", <link rel="preload">)
   - All below-the-fold images load lazily (loading="lazy", decoding="async")
4. Descriptive hyphenated file names.
5. Alt text linting & verification:
   - Describes function and context, not keywords (< 125 chars, alt="" for decorative)
   - Flags AI-generated alt text for mandatory human verification (Google 1 Oct 2026 guidance)
6. Visible captions (<figcaption>).
7. Rich ImageObject in Schema.org Article structured data.
8. Robots meta directive with max-image-preview:large for Discover eligibility.
9. XML Image Sitemap generation.
"""

from __future__ import annotations

import html
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
from pydantic import BaseModel, Field

logger = logging.getLogger("pipeline.adapters.image_delivery")


class AltTextAudit(BaseModel):
    """Alt text evaluation result per Google accessibility & SEO guidelines."""
    alt_text: str
    is_valid: bool
    char_count: int
    char_count_compliant: bool      # Under 125 characters
    is_decorative: bool = False
    is_keyword_stuffed: bool = False
    needs_human_review: bool = True  # Google Oct 2026 guidance names alt text as AI metadata requiring human check
    warnings: List[str] = Field(default_factory=list)


class ImageDeliveryAsset(BaseModel):
    """Complete delivery specification for a production image asset."""
    src: str                         # /uploads/<filename>
    alt: str
    caption: str
    credit: Optional[str] = None
    width: int = 1200
    height: int = 675                # 16:9 aspect ratio standard
    is_lcp: bool = False             # Likely Largest Contentful Paint figure
    is_decorative: bool = False
    avif_available: bool = True
    webp_available: bool = True


def sanitize_hyphenated_image_filename(
    context_name: str,
    extension: str = "webp",
    max_length: int = 60,
) -> str:
    """
    Transforms descriptive titles into clean, lowercase, hyphenated file names.
    Example: 'Vector Search Indexing Benchmark v2' -> 'vector-search-indexing-benchmark.webp'
    """
    cleaned = context_name.lower().strip()
    # Strip extension if already present
    cleaned = re.sub(r"\.(png|jpg|jpeg|webp|avif|svg)$", "", cleaned)
    # Replace non-alphanumeric with hyphens
    cleaned = re.sub(r"[^a-z0-9]+", "-", cleaned)
    # Collapse duplicate hyphens
    cleaned = re.sub(r"-+", "-", cleaned).strip("-")
    if not cleaned:
        cleaned = "editorial-asset"
    cleaned = cleaned[:max_length].rstrip("-")
    ext = extension.lstrip(".")
    return f"{cleaned}.{ext}"


def validate_and_audit_alt_text(
    alt: str,
    is_decorative: bool = False,
    target_keyword: Optional[str] = None,
) -> AltTextAudit:
    """
    Audits alt text against editorial guidelines:
    - Target length: under 125 characters
    - Purely decorative images must use alt=""
    - Detects keyword stuffing or redundant phrases ('image of', 'photo of')
    - Flags AI-generated alt text for human verification per Google 1 Oct 2026 guidance
    """
    clean_alt = alt.strip() if alt else ""
    warnings: List[str] = []

    if is_decorative:
        return AltTextAudit(
            alt_text="",
            is_valid=True,
            char_count=0,
            char_count_compliant=True,
            is_decorative=True,
            needs_human_review=False,
            warnings=[],
        )

    if not clean_alt:
        return AltTextAudit(
            alt_text="",
            is_valid=False,
            char_count=0,
            char_count_compliant=True,
            needs_human_review=True,
            warnings=["Alt text is missing. Informative figures require descriptive alt text."],
        )

    char_count = len(clean_alt)
    char_count_compliant = char_count <= 125
    if not char_count_compliant:
        warnings.append(
            f"Alt text is too long ({char_count} chars). Aim for under 125 characters for screen reader usability."
        )

    # Detect redundant filler prefixes
    lower_alt = clean_alt.lower()
    if lower_alt.startswith(("image of", "photo of", "picture of", "graphic of", "screenshot of a")):
        warnings.append("Avoid prefixing alt text with 'image of' or 'photo of'; screen readers already announce the image role.")

    # Keyword stuffing check: repeated words
    words = re.findall(r"\b\w{3,}\b", lower_alt)
    stuffed = False
    if len(words) >= 6:
        word_freq: Dict[str, int] = {}
        for w in words:
            word_freq[w] = word_freq.get(w, 0) + 1
            if word_freq[w] >= 3:
                stuffed = True
                warnings.append(f"Potential keyword stuffing detected on repeated term: '{w}'.")
                break

    is_valid = len(warnings) == 0

    return AltTextAudit(
        alt_text=clean_alt,
        is_valid=is_valid,
        char_count=char_count,
        char_count_compliant=char_count_compliant,
        is_decorative=False,
        is_keyword_stuffed=stuffed,
        needs_human_review=True,
        warnings=warnings,
    )


def generate_responsive_picture_markup(
    asset: ImageDeliveryAsset,
    sizes: str = "(max-width: 768px) 100vw, 1200px",
) -> Tuple[str, Optional[str]]:
    """
    Renders high-performance <picture> tag with AVIF/WebP srcset,
    explicit width/height preventing layout shift (CLS),
    and LCP preload tag if eager.
    Returns (picture_html, preload_link_tag).
    """
    src = asset.src
    # Standardize image URL
    if "uploads/" in src:
        filename = src.split("uploads/")[-1]
    else:
        filename = src.split("/")[-1]

    stem = Path(filename).stem
    safe_caption = html.escape(asset.caption)
    safe_credit = f'<small class="figure-credit">{html.escape(asset.credit)}</small>' if asset.credit else ""
    safe_alt = html.escape(asset.alt) if not asset.is_decorative else ""

    loading_attr = 'loading="eager" fetchpriority="high" decoding="sync"' if asset.is_lcp else 'loading="lazy" fetchpriority="auto" decoding="async"'
    lcp_class = " lcp-hero-asset" if asset.is_lcp else ""

    picture_html = f"""<figure class="editorial-figure{lcp_class}">
  <picture>
    <source type="image/avif" srcset="/uploads/{stem}.avif 1200w, /uploads/{stem}-800.avif 800w" sizes="{sizes}" />
    <source type="image/webp" srcset="/uploads/{stem}.webp 1200w, /uploads/{stem}-800.webp 800w" sizes="{sizes}" />
    <img src="/uploads/{stem}.webp" alt="{safe_alt}" width="{asset.width}" height="{asset.height}" {loading_attr} />
  </picture>
  <figcaption>{safe_caption}{safe_credit}</figcaption>
</figure>"""

    preload_tag = None
    if asset.is_lcp:
        preload_tag = f'<link rel="preload" as="image" href="/uploads/{stem}.webp" type="image/webp" fetchpriority="high" />'

    return picture_html, preload_tag


def generate_image_object_schema(
    asset: ImageDeliveryAsset,
    site_url: str = "https://example.com",
    article_title: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Constructs a rich Schema.org ImageObject for the Article schema.
    """
    base = site_url.rstrip("/")
    full_url = f"{base}{asset.src}" if asset.src.startswith("/") else asset.src

    schema: Dict[str, Any] = {
        "@type": "ImageObject",
        "@id": f"{full_url}#image",
        "url": full_url,
        "contentUrl": full_url,
        "caption": asset.caption or (article_title or "Editorial Figure"),
        "description": asset.alt or asset.caption,
        "width": asset.width,
        "height": asset.height,
        "representativeOfPage": asset.is_lcp,
    }
    if asset.credit:
        schema["creator"] = {
            "@type": "Organization",
            "name": asset.credit,
        }
    return schema


def generate_robots_meta_directives() -> str:
    """
    Emits the robots meta directive ensuring max-image-preview:large for Discover & large card eligibility.
    """
    return '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />'


def generate_xml_image_sitemap(
    pages: List[Dict[str, Any]],
    site_url: str = "https://example.com",
) -> str:
    """
    Generates a Google-compliant XML Image Sitemap.
    Each page entry format:
      {"url": "/posts/sample", "images": [{"src": "/uploads/hero.webp", "title": "...", "caption": "..."}]}
    """
    base = site_url.rstrip("/")
    url_nodes = []

    for p in pages:
        page_loc = f"{base}{p['url']}" if p['url'].startswith("/") else p['url']
        img_nodes = []
        for img in p.get("images", []):
            img_loc = f"{base}{img['src']}" if img['src'].startswith("/") else img['src']
            img_nodes.append(
                f"    <image:image>\n"
                f"      <image:loc>{html.escape(img_loc)}</image:loc>\n"
                f"      <image:title>{html.escape(img.get('title') or '')}</image:title>\n"
                f"      <image:caption>{html.escape(img.get('caption') or '')}</image:caption>\n"
                f"    </image:image>"
            )

        if img_nodes:
            images_xml = "\n".join(img_nodes)
            url_nodes.append(
                f"  <url>\n"
                f"    <loc>{html.escape(page_loc)}</loc>\n"
                f"{images_xml}\n"
                f"  </url>"
            )

    body = "\n".join(url_nodes)
    return (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"\n'
        f'        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n'
        f'{body}\n'
        f'</urlset>'
    )
