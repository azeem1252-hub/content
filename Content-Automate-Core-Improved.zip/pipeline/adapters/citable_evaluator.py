"""
The CITABLE Framework Evaluator (Pillar: Reverse-Engineering AI Retrieval).

Evaluates content across the 7 dimensions identified in the blueprint to maximize
citation probability in LLM answer engines (ChatGPT Search, Perplexity, Google AI Overviews):
- C: Clear Entity & Structure
- I: Intent Architecture
- T: Third-Party Validation
- A: Answer Grounding (Canonical passages 134-167 words)
- B: Block-Structured for RAG (Tables, lists, blockquotes)
- L: Latest & Consistent
- E: Entity Graph & Schema
"""

import re
import logging
from typing import Dict, Any, List

logger = logging.getLogger("pipeline.adapters.citable")


def evaluate_citable_score(
    title: str,
    draft: str,
    keywords: List[str],
    has_citations: bool = False,
    has_schema: bool = False
) -> Dict[str, Any]:
    """
    Evaluates a draft against the 7 CITABLE dimensions, returning a score (0-100)
    and detailed diagnostic criteria.
    """
    scores = {}
    details = []

    # 1. C: Clear Entity & Structure (Heading hierarchy, clear entity anchors)
    h2s = len(re.findall(r"^##\s+", draft, re.MULTILINE))
    h3s = len(re.findall(r"^###\s+", draft, re.MULTILINE))
    if h2s >= 3 or (h2s >= 2 and h3s >= 1):
        scores["clear_structure"] = 15
    elif h2s >= 2:
        scores["clear_structure"] = 10
    else:
        scores["clear_structure"] = 5
        details.append("Structure: Needs at least 3 distinct H2 sections.")

    # 2. I: Intent Architecture (Keyword alignment & query resolution)
    clean_draft_lower = draft.lower()
    kws_found = sum(1 for kw in keywords if kw.lower() in clean_draft_lower)
    kw_coverage = (kws_found / len(keywords)) if keywords else 1.0
    scores["intent_architecture"] = 15 if kw_coverage >= 0.7 else (10 if kw_coverage >= 0.4 else 5)
    if kw_coverage < 0.7:
        details.append(f"Intent: Only {kws_found}/{len(keywords)} target keywords naturally integrated.")

    # 3. T: Third-Party Validation (Outbound authority links and source citations)
    markdown_links = len(re.findall(r"\[([^\]]+)\]\((https?://[^\)]+)\)", draft))
    if markdown_links >= 3 or has_citations:
        scores["third_party_validation"] = 15
    elif markdown_links >= 1:
        scores["third_party_validation"] = 10
    else:
        scores["third_party_validation"] = 0
        details.append("Validation: Missing outbound authoritative citations.")

    # 4. A: Answer Grounding (Canonical passages: 134-167 words with direct 1-sentence opening)
    paragraphs = [p.strip() for p in draft.split("\n\n") if p.strip() and not p.startswith("#")]
    canonical_passages = 0
    for p in paragraphs:
        w_count = len(p.split())
        # The empirical sweet spot correlating r=0.87 with Google AI Overviews is 134-167 words
        if 110 <= w_count <= 180:
            canonical_passages += 1

    if canonical_passages >= 2:
        scores["answer_grounding"] = 20
    elif canonical_passages >= 1:
        scores["answer_grounding"] = 14
    else:
        scores["answer_grounding"] = 8
        details.append("Answer Grounding: Add 134-167 word self-contained canonical answer passages.")

    # 5. B: Block-Structured for RAG (Comparison tables, bullet lists, blockquotes)
    has_table = bool(re.search(r"\|.*\|.*\n\|[-:\s|]+\|", draft))
    has_list = bool(re.search(r"^\s*[-*+]\s+", draft, re.MULTILINE))
    has_blockquote = bool(re.search(r"^\s*>\s+", draft, re.MULTILINE))

    block_points = (7 if has_table else 0) + (5 if has_list else 0) + (3 if has_blockquote else 0)
    scores["block_structured_rag"] = min(15, block_points)
    if not has_table:
        details.append("RAG Optimization: Include a markdown comparison table for LLM extraction.")

    # 6. L: Latest & Consistent (Freshness signals, 2026 temporal markers)
    has_freshness = bool(re.search(r"\b(2025|2026|current|latest|modern)\b", clean_draft_lower))
    scores["latest_consistent"] = 10 if has_freshness else 5

    # 7. E: Entity Graph & Schema (Rich entities & schema readiness)
    # Estimate entity density: count capitalized noun entities
    potential_entities = set(re.findall(r"\b[A-Z][a-zA-Z0-9_-]+(?:\s+[A-Z][a-zA-Z0-9_-]+)*\b", draft))
    entity_count = len(potential_entities)
    if entity_count >= 15 or has_schema:
        scores["entity_graph"] = 10
    else:
        scores["entity_graph"] = 5
        details.append(f"Entity Density: Found {entity_count} entities (target: >= 15).")

    total_citable_score = sum(scores.values())

    # Generate transparent 7-lever Citation-Readiness Checklist (Pillar A5)
    from pipeline.adapters.citation_readiness import evaluate_citation_readiness
    readiness_report = evaluate_citation_readiness(
        title=title,
        draft=draft,
        keywords=keywords,
        schema_markup={"@type": "Article"} if has_schema else None,
        author="Editorial Bureau",
        internal_inbound_links_count=2,
        is_server_rendered=True,
    )

    return {
        "citable_score": min(100, total_citable_score),
        "dimension_scores": scores,
        "canonical_passages_count": canonical_passages,
        "has_comparison_table": has_table,
        "entity_count": entity_count,
        "diagnostic_details": details,
        "citation_readiness": readiness_report,
        "checklist_passed_count": readiness_report.get("passed_count", 0),
        "readiness_tier": readiness_report.get("readiness_tier", "Moderate Readiness"),
        "promise": readiness_report.get("promise"),
    }

