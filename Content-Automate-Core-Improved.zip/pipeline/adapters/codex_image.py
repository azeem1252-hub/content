"""
OpenAI Image Generation — ChatGPT/Codex OAuth & gpt-image-2 Adapter.

Implements native ChatGPT / Codex backend endpoint:
  POST https://chatgpt.com/backend-api/codex/images/generations
using gpt-image-2 via OAuth. No OPENAI_API_KEY required.
Supports native OpenAI device code authentication (auth.openai.com/codex/device),
local credentials stored in ~/.codex/auth.json, or environment tokens.
Gracefully falls back to high-resolution editorial generation if rate-limited or unauthenticated.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import time
import urllib.parse
import uuid
import random
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import httpx

import config
from pipeline.llm_client import call_llm
from pipeline.adapters.gemini_image import generate_gemini_image, get_gemini_api_key

logger = logging.getLogger("pipeline.adapters.codex_image")

# Path to static uploads directory (web/static/uploads)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
UPLOADS_DIR = _PROJECT_ROOT / "web" / "static" / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

# Codex API Constants
_CODEX_BASE_URL = "https://chatgpt.com/backend-api/codex"
_OPENAI_AUTH_ISSUER = "https://auth.openai.com"
_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_CODEX_OAUTH_TOKEN_URL = "https://auth.openai.com/oauth/token"
_CODEX_AUTH_DIR = Path.home() / ".codex"
_CODEX_AUTH_FILE = _CODEX_AUTH_DIR / "auth.json"

GPT_IMAGE_2_DEFAULT = "gpt-image-2"
GPT_IMAGE_2_TIERS = ["gpt-image-2", "gpt-image-2-medium", "gpt-image-2-high"]
_MAX_ERROR_BODY_CHARS = 500

_VALID_ENGINES = ("gemini", "cloudflare", "openai", "codex", "custom", "tavily", "pollinations")


def _resolve_engine_order() -> List[str]:
    """
    Resolves the image engine priority from config (IMAGE_ENGINE_ORDER).

    Accepts a comma-separated subset of: gemini, cloudflare, openai, codex, custom, tavily, pollinations.
    Default ("auto"): ["cloudflare", "gemini", "openai", "codex", "tavily"].
    The procedural SVG placeholder is always the implicit last resort.
    """
    raw = (getattr(config, "IMAGE_ENGINE_ORDER", "") or "auto").strip().lower()
    if raw in ("", "auto", "default"):
        return ["cloudflare", "gemini", "openai", "codex", "tavily"]
    picked = [e.strip() for e in raw.split(",") if e.strip()]
    ordered = [e for e in picked if e in _VALID_ENGINES]
    if not ordered:
        logger.warning(f"Unrecognized IMAGE_ENGINE_ORDER '{raw}'; using default engine order.")
        return ["cloudflare", "gemini", "openai", "codex", "tavily"]
    return ordered


def _summarize_error_body(body: str) -> str:
    """Bounded summary preferring parsed error.message."""
    text = body or ""
    try:
        payload = json.loads(text)
        error = payload.get("error") if isinstance(payload, dict) else None
        message = error.get("message") if isinstance(error, dict) else None
        if isinstance(message, str) and message.strip():
            return message.strip()[:_MAX_ERROR_BODY_CHARS]
    except (TypeError, ValueError):
        pass
    return text[:_MAX_ERROR_BODY_CHARS]


def _extract_jwt_claims(token: str) -> Dict[str, Any]:
    """Safely extracts JWT claims without verifying cryptographic signature."""
    if not token or not isinstance(token, str):
        return {}
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
        return json.loads(base64.urlsafe_b64decode(payload_b64))
    except Exception:
        return {}


def _extract_chatgpt_account_id(token: str) -> Optional[str]:
    """Extracts chatgpt_account_id claim from OAuth token if present."""
    claims = _extract_jwt_claims(token)
    auth = claims.get("https://api.openai.com/auth", {})
    acct = auth.get("chatgpt_account_id")
    return str(acct) if acct else None


def save_codex_credentials(access_token: str, refresh_token: Optional[str] = None) -> bool:
    """Persists OAuth tokens to local ~/.codex/auth.json and updates .env."""
    try:
        _CODEX_AUTH_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "access_token": access_token,
            "session_token": access_token,
            "updated_at": int(time.time()),
        }
        if refresh_token:
            data["refresh_token"] = refresh_token
        with open(_CODEX_AUTH_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        # Update .env
        config.update_env_file({"CODEX_SESSION_TOKEN": access_token})
        return True
    except Exception as e:
        logger.warning(f"Could not persist Codex credentials: {e}")
        return False


def start_device_code_login() -> Dict[str, Any]:
    """
    Initiates native OpenAI Codex OAuth device code flow.
    Returns user_code, verification_url, and device_auth_id for polling.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Origin": _OPENAI_AUTH_ISSUER,
        "Referer": f"{_OPENAI_AUTH_ISSUER}/codex/device"
    }

    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(
                f"{_OPENAI_AUTH_ISSUER}/api/accounts/deviceauth/usercode",
                json={"client_id": _CODEX_CLIENT_ID},
                headers=headers
            )
            if resp.status_code == 200:
                data = resp.json()
                return {
                    "ok": True,
                    "user_code": data.get("user_code"),
                    "device_auth_id": data.get("device_auth_id"),
                    "verification_url": f"{_OPENAI_AUTH_ISSUER}/codex/device",
                    "interval": int(data.get("interval", 5)),
                    "expires_at": data.get("expires_at"),
                    "message": "Device code generated successfully."
                }
            elif resp.status_code == 429:
                return {
                    "ok": False,
                    "rate_limited": True,
                    "message": "OpenAI login rate limited. Please wait a moment and try again."
                }
            else:
                return {
                    "ok": False,
                    "status_code": resp.status_code,
                    "message": f"Failed to generate device code: {resp.text[:200]}"
                }
    except Exception as e:
        return {
            "ok": False,
            "message": f"Error contacting OpenAI auth: {str(e)}"
        }


def poll_device_code_login(device_auth_id: str, user_code: str) -> Dict[str, Any]:
    """
    Polls OpenAI device code authorization status.
    If authorized, automatically exchanges code for tokens and saves to ~/.codex/auth.json.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Origin": _OPENAI_AUTH_ISSUER,
        "Referer": f"{_OPENAI_AUTH_ISSUER}/codex/device"
    }

    try:
        with httpx.Client(timeout=15.0) as client:
            poll_resp = client.post(
                f"{_OPENAI_AUTH_ISSUER}/api/accounts/deviceauth/token",
                json={"device_auth_id": device_auth_id, "user_code": user_code},
                headers=headers
            )

            # 403 / 404 indicates user has not yet entered code
            if poll_resp.status_code in {403, 404}:
                return {
                    "ok": True,
                    "status": "pending",
                    "message": "Waiting for confirmation in browser..."
                }

            if poll_resp.status_code == 200:
                code_data = poll_resp.json()
                auth_code = code_data.get("authorization_code")
                verifier = code_data.get("code_verifier")
                redirect_uri = f"{_OPENAI_AUTH_ISSUER}/deviceauth/callback"

                if not auth_code or not verifier:
                    return {
                        "ok": False,
                        "status": "error",
                        "message": "Authorization payload missing verification tokens."
                    }

                # Exchange authorization code for tokens
                token_resp = client.post(
                    _CODEX_OAUTH_TOKEN_URL,
                    data={
                        "grant_type": "authorization_code",
                        "code": auth_code,
                        "redirect_uri": redirect_uri,
                        "client_id": _CODEX_CLIENT_ID,
                        "code_verifier": verifier
                    },
                    headers={"Content-Type": "application/x-www-form-urlencoded"}
                )

                if token_resp.status_code == 200:
                    token_data = token_resp.json()
                    access_token = token_data.get("access_token", "")
                    refresh_token = token_data.get("refresh_token", "")

                    if access_token:
                        save_codex_credentials(access_token, refresh_token)
                        return {
                            "ok": True,
                            "status": "connected",
                            "access_token": access_token,
                            "message": "OpenAI (Codex auth) connected successfully!"
                        }

                return {
                    "ok": False,
                    "status": "exchange_failed",
                    "message": f"Token exchange failed (HTTP {token_resp.status_code})."
                }

            return {
                "ok": False,
                "status": "polling_error",
                "message": f"Polling returned status {poll_resp.status_code}."
            }
    except Exception as e:
        return {
            "ok": False,
            "status": "error",
            "message": f"Device auth error: {str(e)}"
        }


def _read_local_cached_tokens() -> Optional[str]:
    """Quietly inspects standard local credential cache files."""
    candidate_paths: List[Path] = []

    # 0. Explicit override via config/env (CODEX_AUTH_PATH)
    explicit_path = (os.getenv("CODEX_AUTH_PATH", "").strip() or config.CODEX_AUTH_PATH or "").strip()
    if explicit_path:
        candidate_paths.append(Path(explicit_path))

    # 1. ~/.codex/auth.json
    candidate_paths.append(_CODEX_AUTH_FILE)

    # 2. Local application data stores
    local_app_data = os.getenv("LOCALAPPDATA", "")
    if local_app_data:
        local_dir = Path(local_app_data)
        for alt in ["codex", "openai"]:
            candidate_paths.append(local_dir / alt / "auth.json")
    for alt in [".codex"]:
        candidate_paths.append(Path.home() / alt / "auth.json")

    seen = set()
    for p in candidate_paths:
        p_str = str(p)
        if p_str in seen:
            continue
        seen.add(p_str)
        if not p.exists():
            continue
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Check pool
            pool = data.get("credential_pool", {}).get("openai-codex", [])
            if isinstance(pool, list) and pool:
                tok = pool[0].get("access_token")
                if tok and str(tok).strip():
                    return str(tok).strip()
            tok = data.get("access_token") or data.get("session_token") or data.get("token")
            if tok and str(tok).strip():
                return str(tok).strip()
        except Exception:
            pass

    return None


def get_codex_token() -> Optional[str]:
    """
    Retrieves the Codex / ChatGPT / OpenAI session token.
    Order of precedence:
    1. CODEX_SESSION_TOKEN in environment / .env
    2. Local cached credentials (~/.codex/auth.json or local auth store)
    3. OPENAI_API_KEY
    """
    token = os.getenv("CODEX_SESSION_TOKEN", "").strip() or config.CODEX_SESSION_TOKEN
    if token:
        return token

    # Check local credential store
    local_token = _read_local_cached_tokens()
    if local_token:
        return local_token

    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    if openai_key:
        return openai_key

    return None


def get_codex_status_details() -> Dict[str, Any]:
    """Returns status information about OpenAI Codex OAuth credentials."""
    token = get_codex_token()
    has_token = bool(token)
    claims = _extract_jwt_claims(token) if token else {}
    auth_claims = claims.get("https://api.openai.com/auth", {})
    account_id = auth_claims.get("chatgpt_account_id") or ""
    plan_type = auth_claims.get("chatgpt_plan_type") or "standard"
    exp = claims.get("exp")
    is_expired = (exp is not None and time.time() > exp)

    # Determine display source
    source = "Not Configured"
    if os.getenv("CODEX_SESSION_TOKEN", "").strip() or config.CODEX_SESSION_TOKEN:
        source = ".env (CODEX_SESSION_TOKEN)"
    elif _CODEX_AUTH_FILE.exists():
        source = f"Local File ({_CODEX_AUTH_FILE.name})"
    elif _read_local_cached_tokens():
        source = "Local Authentication Store"
    elif os.getenv("OPENAI_API_KEY"):
        source = "OPENAI_API_KEY"

    return {
        "ok": True,
        "provider": "openai-codex",
        "provider_label": "OpenAI (Codex auth)",
        "badge": "free",
        "tag": "gpt-image-2 via ChatGPT/Codex OAuth — no API key required; supports text and image inputs",
        "has_token": has_token,
        "is_active": has_token,
        "status": "Active" if (has_token and not is_expired) else ("Expired" if is_expired else "Needs Auth"),
        "plan_type": plan_type,
        "account_id": account_id,
        "account_masked": f"{account_id[:8]}...{account_id[-6:]}" if len(account_id) > 14 else account_id,
        "expires_at": exp,
        "is_expired": is_expired,
        "source": source,
        "models": GPT_IMAGE_2_TIERS,
        "default_model": GPT_IMAGE_2_DEFAULT,
        "endpoint": f"{_CODEX_BASE_URL}/images/generations"
    }


def _build_codex_headers(token: str) -> Dict[str, str]:
    """Generates standard Codex client headers including account-ID and uuid turn."""
    headers = {
        "User-Agent": "codex_cli_rs/0.1.0",
        "originator": "codex_cli_rs",
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "x-codex-image-turn-id": str(uuid.uuid4()),
    }
    acct_id = _extract_chatgpt_account_id(token)
    if acct_id:
        headers["ChatGPT-Account-ID"] = acct_id
    return headers


def test_codex_connection(custom_token: Optional[str] = None) -> Dict[str, Any]:
    """
    Diagnostic probe testing image generation capability using OpenAI Codex OAuth
    or resilient fallback engine.
    """
    token = custom_token or get_codex_token()
    prompt = "Modern editorial tech architecture, sleek geometric forms, dramatic lighting"
    clean_slug = "diagnostic-test"

    details = get_codex_status_details()
    asset = generate_and_save_image(prompt=prompt, slug=clean_slug)

    is_codex = asset.get("engine") == "openai_codex_oauth"
    is_gemini = asset.get("engine") == "google_gemini"
    rate_limited = asset.get("codex_rate_limited", False)

    if is_gemini:
        msg = f"✓ Successfully generated visual via Google Gemini [{asset.get('model')}]!"
    elif is_codex:
        msg = f"✓ Successfully generated visual via OpenAI (Codex auth) [{GPT_IMAGE_2_DEFAULT}]!"
    elif rate_limited:
        msg = "OpenAI Codex OAuth connected! Account rate limited (resets automatically) — preview generated via resilient engine."
    elif token:
        msg = "Codex session detected. Resilient high-res visual generated successfully."
    else:
        msg = "Generative high-res engine operational (Gemini API key or Codex OAuth optional)."

    # A procedural SVG placeholder means every real engine failed. Reporting
    # ok=True for it would hide broken credentials/engines from the dashboard.
    procedural_only = asset.get("engine") == "procedural-svg"
    if procedural_only:
        msg = "All image engines failed; a procedural placeholder was generated instead."

    return {
        "ok": not procedural_only,
        "engine_errors": asset.get("engine_errors") or {},
        "mode": "gemini_image" if is_gemini else ("codex_authenticated" if is_codex else "generative_highres_engine"),
        "engine": asset.get("engine"),
        "model": asset.get("model", GPT_IMAGE_2_DEFAULT),
        "token_detected": bool(token),
        "rate_limited": rate_limited,
        "rate_limit_reset_in": asset.get("resets_in_seconds"),
        "plan_type": details.get("plan_type"),
        "account_id": details.get("account_id"),
        "hero_image_url": asset.get("hero_image_url"),
        "hero_image_path": asset.get("hero_image_path"),
        "message": msg
    }


def synthesize_visual_prompt(
    title: str,
    topic: str,
    draft_excerpt: str = "",
    editorial_archetype: Optional[str] = None
) -> str:
    """
    Uses LLM to synthesize a high-contrast, topic-tailored editorial photography/illustration prompt
    matching the article's core thesis and the publication's 36-archetype editorial art direction.
    Optimized for FLUX.1 [schnell], Gemini Imagen, and SDXL.
    """
    from pipeline.editorial_archetypes import get_design_archetype_by_slug
    design = get_design_archetype_by_slug(editorial_archetype)
    specific_direction = design.get("image_direction") or "Cinematic editorial photography, dramatic volumetric lighting, cohesive color palette, 0 text, 0 UI."

    system_instruction = (
        f"You are an acclaimed Art Director and Visual Concept Designer for prestige editorial publications "
        f"embodying the '#{design.get('id', 28)} {design.get('name', 'Contemporary Editorial')}' archetype ({design.get('feeling', '')}). "
        "Create a single, evocative, and visually striking image generation prompt for an editorial hero photograph or artwork. "
        "Guidelines:\n"
        f"- Mandatory Visual & Photography Direction: {specific_direction}\n"
        "- Emphasize dramatic volumetric lighting, tactile material textures, and striking compositional depth.\n"
        "- NEVER include any text, letters, titles, words, numbers, watermarks, logos, or UI elements in the image.\n"
        "- Return ONLY the visual prompt itself in 1 to 2 vivid sentences without conversational preamble or quotation marks."
    )

    prompt = f"""Article Title: {title}
Core Topic: {topic}
Key Narrative Excerpt: {draft_excerpt[:600]}
Editorial Archetype: #{design.get('id', 28)} {design.get('name', 'Contemporary Editorial')}

Generate an evocative, high-aesthetic visual prompt for this article's hero image:"""
    logger.info(f"Synthesizing visual prompt for article: '{title}' (archetype: {design.get('slug')})")
    try:
        visual_prompt = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.7)
        clean_prompt = visual_prompt.strip().strip('"').strip("'")
    except Exception as e:
        logger.warning(f"Could not synthesize visual prompt via LLM ({e}). Generating editorial prompt directly from topic.")
        clean_prompt = f"{specific_direction.replace(', 0 text, 0 UI.', '')} representing {topic}, dramatic volumetric lighting, high atmospheric contrast, sleek compositional depth, no text"

    if not clean_prompt or len(clean_prompt) < 15:
        clean_prompt = f"{specific_direction.replace(', 0 text, 0 UI.', '')} for {topic}, dramatic lighting, rich color palette, textured atmosphere, no text"

    return clean_prompt


def search_tavily_free_stock_image(
    prompt: str,
    slug: str
) -> Optional[Tuple[bytes, str, str]]:
    """
    Searches Tavily API for authentic, high-resolution free-licensed editorial photos
    (Unsplash, Pexels, Wikimedia, etc.) matching the article topic or prompt.
    Downloads and returns (image_bytes, source_url, model_name).
    """
    tavily_key = os.getenv("TAVILY_API_KEY", "").strip() or getattr(config, "TAVILY_API_KEY", "")
    if not tavily_key or any(placeholder in tavily_key.lower() for placeholder in ("tvly-placeholder", "your-", "xxx")):
        logger.warning("TAVILY_API_KEY is not configured or is a placeholder. Cannot perform image search.")
        return None

    # Clean the topic from slug and prompt
    clean_topic = re.sub(r"[^\w\s-]", " ", slug.replace("-", " ")).strip()
    # Strip common AI photo prompt boilerplates to get the core subject
    cleaned_prompt = re.sub(
        r"(?i)\b(photorealistic|editorial|photo|photograph|wide banner|illustration|hyperrealistic|cinematic lighting|8k|4k|high quality|minimalist|clean)\b",
        "",
        prompt
    ).strip()
    cleaned_prompt = " ".join(cleaned_prompt.split()[:12])

    search_queries = [
        f"{clean_topic} unsplash pexels photography",
        f"{cleaned_prompt or clean_topic} free stock photography high resolution",
        f"{clean_topic} editorial wallpaper",
    ]

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    }

    FREE_STOCK_DOMAINS = (
        "images.unsplash.com",
        "unsplash.com",
        "images.pexels.com",
        "pexels.com",
        "wikimedia.org",
        "pixabay.com",
        "freepik.com"
    )

    for query in search_queries:
        if not query.strip():
            continue
        try:
            logger.info(f"Querying Tavily for free-licensed stock imagery with query: '{query}'")
            with httpx.Client(timeout=15.0) as client:
                res = client.post(
                    "https://api.tavily.com/search",
                    json={
                        "api_key": tavily_key,
                        "query": query,
                        "include_images": True,
                        "max_results": 8,
                    }
                )
            if res.status_code != 200:
                logger.warning(f"Tavily image search API returned HTTP {res.status_code}: {res.text[:150]}")
                continue

            data = res.json()
            raw_images = data.get("images", [])
            if not raw_images:
                continue

            candidate_urls: List[str] = []
            for item in raw_images:
                u = item if isinstance(item, str) else (item.get("url") if isinstance(item, dict) else None)
                if u and isinstance(u, str) and u.startswith("http") and u not in candidate_urls:
                    candidate_urls.append(u)

            if not candidate_urls:
                continue

            # Prioritize known free-stock domains (Unsplash, Pexels, Wikimedia)
            prioritized_urls = sorted(
                candidate_urls,
                key=lambda u: 0 if any(dom in u.lower() for dom in FREE_STOCK_DOMAINS) else 1
            )

            for img_url in prioritized_urls[:6]:
                try:
                    with httpx.Client(timeout=12.0, follow_redirects=True, headers=headers) as dl_client:
                        dl_res = dl_client.get(img_url)
                        if dl_res.status_code == 200 and len(dl_res.content) > 5000:
                            content_type = dl_res.headers.get("content-type", "").lower()
                            is_image = (
                                content_type.startswith("image/") or
                                dl_res.content.startswith(b"\xff\xd8") or  # JPEG
                                dl_res.content.startswith(b"\x89PNG") or  # PNG
                                (dl_res.content.startswith(b"RIFF") and b"WEBP" in dl_res.content[:16])  # WebP
                            )
                            if is_image:
                                logger.info(f"Successfully downloaded free-licensed stock image ({len(dl_res.content)} bytes) from: {img_url}")
                                model_name = "tavily-unsplash" if "unsplash" in img_url.lower() else (
                                    "tavily-pexels" if "pexels" in img_url.lower() else "tavily-free-stock"
                                )
                                return (dl_res.content, img_url, model_name)
                except Exception as dl_err:
                    logger.debug(f"Failed to download candidate image {img_url}: {dl_err}")
                    continue

        except Exception as e:
            logger.warning(f"Tavily search attempt failed for query '{query}': {e}")
            continue

    return None


def get_cloudflare_account_id() -> Optional[str]:
    return (os.getenv("CLOUDFLARE_ACCOUNT_ID", "") or getattr(config, "CLOUDFLARE_ACCOUNT_ID", "") or "").strip()


def get_cloudflare_api_token() -> Optional[str]:
    return (os.getenv("CLOUDFLARE_API_TOKEN", "") or getattr(config, "CLOUDFLARE_API_TOKEN", "") or "").strip()


def get_cloudflare_image_model() -> str:
    return (os.getenv("CLOUDFLARE_IMAGE_MODEL", "") or getattr(config, "CLOUDFLARE_IMAGE_MODEL", "") or "@cf/black-forest-labs/flux-1-schnell").strip()


def generate_cloudflare_image(
    prompt: str,
    slug: str = "hero",
    account_id: Optional[str] = None,
    api_token: Optional[str] = None,
    model: Optional[str] = None
) -> Dict[str, Any]:
    """
    Invokes Cloudflare Workers AI Image Generation via REST API.
    Supports Flux-1-Schnell, SDXL Base 1.0, SDXL Lightning, etc.
    Endpoint: https://api.cloudflare.com/client/v4/accounts/{account_id}/ai/run/{model}
    """
    acc_id = (account_id or get_cloudflare_account_id() or "").strip()
    token = (api_token or get_cloudflare_api_token() or "").strip()
    target_model = (model or get_cloudflare_image_model() or "@cf/black-forest-labs/flux-1-schnell").strip()

    if not acc_id:
        return {"ok": False, "error": "CLOUDFLARE_ACCOUNT_ID not configured"}
    if not token:
        return {"ok": False, "error": "CLOUDFLARE_API_TOKEN not configured"}

    url = f"https://api.cloudflare.com/client/v4/accounts/{acc_id}/ai/run/{target_model}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "User-Agent": "ContentPipelineAgent/2.0"
    }

    payload: Dict[str, Any] = {
        "prompt": prompt,
    }
    model_lower = target_model.lower()
    if "flux" in model_lower:
        # Flux.1-Schnell strictly accepts 'prompt', 'steps' (1-8), and 'seed'. Rejects width/height/num_steps.
        payload["steps"] = 4
    elif "lightning" in model_lower:
        # SDXL Lightning supports width, height, num_steps
        payload["width"] = 1024
        payload["height"] = 1024
        payload["num_steps"] = 4
    elif "xl" in model_lower or "diffusion" in model_lower:
        # SDXL Base 1.0 supports num_steps up to 20
        payload["num_steps"] = 20

    t0 = time.time()
    try:
        with httpx.Client(timeout=60.0) as client:
            res = client.post(url, headers=headers, json=payload)
            latency_ms = int((time.time() - t0) * 1000)

            if res.status_code == 200:
                ct = res.headers.get("content-type", "").lower()
                image_bytes = None

                # Check for JSON payload (either declared in Content-Type or starting with '{')
                if "application/json" in ct or res.content.strip().startswith(b"{"):
                    try:
                        data = res.json()
                        b64 = None
                        if isinstance(data, dict):
                            if data.get("result") and isinstance(data["result"], dict):
                                b64 = data["result"].get("image")
                            elif data.get("image"):
                                b64 = data.get("image")
                        if b64:
                            image_bytes = base64.b64decode(b64)
                    except Exception:
                        pass

                # If not decoded from JSON base64, treat binary stream as raw image bytes
                if not image_bytes and len(res.content) > 100:
                    image_bytes = res.content

                if image_bytes:
                    return {
                        "ok": True,
                        "image_bytes": image_bytes,
                        "model": target_model,
                        "engine": "cloudflare_workers_ai",
                        "latency_ms": latency_ms,
                        "bytes": len(image_bytes)
                    }
                else:
                    return {
                        "ok": False,
                        "error": f"Empty image response from Cloudflare ({res.status_code}, {ct})",
                        "latency_ms": latency_ms
                    }

            err_msg = f"HTTP {res.status_code}"
            try:
                err_data = res.json()
                if err_data.get("errors") and isinstance(err_data["errors"], list):
                    err_msg = "; ".join(e.get("message", str(e)) for e in err_data["errors"])
                elif err_data.get("error"):
                    err_msg = str(err_data["error"])
            except Exception:
                err_msg = res.text[:200]

            return {
                "ok": False,
                "error": f"Cloudflare Workers AI error: {err_msg}",
                "status_code": res.status_code,
                "latency_ms": latency_ms
            }

    except Exception as e:
        latency_ms = int((time.time() - t0) * 1000)
        return {
            "ok": False,
            "error": f"Cloudflare request failed: {str(e)}",
            "latency_ms": latency_ms
        }


def get_openai_image_key() -> Optional[str]:
    return (os.getenv("OPENAI_IMAGE_KEY", "") or os.getenv("OPENAI_API_KEY", "") or getattr(config, "OPENAI_IMAGE_KEY", "") or getattr(config, "OPENAI_API_KEY", "") or "").strip()


def get_openai_image_model() -> str:
    return (os.getenv("OPENAI_IMAGE_MODEL", "") or getattr(config, "OPENAI_IMAGE_MODEL", "") or "dall-e-3").strip()


def get_custom_image_url() -> Optional[str]:
    return (os.getenv("CUSTOM_IMAGE_URL", "") or getattr(config, "CUSTOM_IMAGE_URL", "") or "").strip()


def get_custom_image_key() -> Optional[str]:
    return (os.getenv("CUSTOM_IMAGE_KEY", "") or getattr(config, "CUSTOM_IMAGE_KEY", "") or "").strip()


def get_custom_image_model() -> str:
    return (os.getenv("CUSTOM_IMAGE_MODEL", "") or getattr(config, "CUSTOM_IMAGE_MODEL", "") or "default").strip()


def generate_openai_image(
    prompt: str,
    slug: str = "hero",
    api_key: Optional[str] = None,
    model: Optional[str] = None
) -> Dict[str, Any]:
    """Invokes OpenAI DALL-E 3 / Images API (POST https://api.openai.com/v1/images/generations)."""
    key = (api_key or get_openai_image_key() or "").strip()
    target_model = (model or get_openai_image_model() or "dall-e-3").strip()
    if not key:
        return {"ok": False, "error": "OPENAI_API_KEY / OPENAI_IMAGE_KEY not configured"}

    url = "https://api.openai.com/v1/images/generations"
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json"
    }
    payload = {
        "prompt": prompt,
        "model": target_model,
        "n": 1,
        "size": "1024x1024",
        "response_format": "b64_json"
    }
    t0 = time.time()
    try:
        with httpx.Client(timeout=60.0) as client:
            res = client.post(url, headers=headers, json=payload)
            latency_ms = int((time.time() - t0) * 1000)
            if res.status_code == 200:
                data = res.json()
                items = data.get("data", [])
                if items and isinstance(items[0], dict):
                    b64 = items[0].get("b64_json")
                    if b64:
                        img_bytes = base64.b64decode(b64)
                        return {
                            "ok": True,
                            "image_bytes": img_bytes,
                            "model": target_model,
                            "engine": "openai_dalle",
                            "latency_ms": latency_ms,
                            "bytes": len(img_bytes)
                        }
                    img_url = items[0].get("url")
                    if img_url:
                        dl_res = client.get(img_url, timeout=30.0)
                        if dl_res.status_code == 200 and len(dl_res.content) > 100:
                            return {
                                "ok": True,
                                "image_bytes": dl_res.content,
                                "model": target_model,
                                "engine": "openai_dalle",
                                "latency_ms": latency_ms,
                                "bytes": len(dl_res.content)
                            }
            err_msg = f"HTTP {res.status_code}"
            try:
                err_msg = res.json().get("error", {}).get("message", res.text[:200])
            except Exception:
                err_msg = res.text[:200]
            return {"ok": False, "error": f"OpenAI Images error: {err_msg}", "status_code": res.status_code, "latency_ms": latency_ms}
    except Exception as e:
        return {"ok": False, "error": f"OpenAI Images request failed: {str(e)}", "latency_ms": int((time.time() - t0) * 1000)}


def generate_custom_image(
    prompt: str,
    slug: str = "hero",
    endpoint_url: Optional[str] = None,
    api_key: Optional[str] = None,
    model: Optional[str] = None
) -> Dict[str, Any]:
    """Invokes custom/generic OpenAI-compatible Image Generation API."""
    url = (endpoint_url or get_custom_image_url() or "").strip()
    key = (api_key or get_custom_image_key() or "").strip()
    target_model = (model or get_custom_image_model() or "default").strip()
    if not url:
        return {"ok": False, "error": "CUSTOM_IMAGE_URL not configured"}

    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    payload = {
        "prompt": prompt,
        "model": target_model,
        "n": 1,
        "size": "1024x1024",
        "response_format": "b64_json"
    }
    t0 = time.time()
    try:
        with httpx.Client(timeout=60.0) as client:
            res = client.post(url, headers=headers, json=payload)
            latency_ms = int((time.time() - t0) * 1000)
            if res.status_code == 200:
                ct = res.headers.get("content-type", "").lower()
                if "application/json" in ct or res.content.strip().startswith(b"{"):
                    data = res.json()
                    b64 = None
                    img_url = None
                    if isinstance(data, dict):
                        if data.get("data") and isinstance(data["data"], list) and data["data"]:
                            b64 = data["data"][0].get("b64_json")
                            img_url = data["data"][0].get("url")
                        elif data.get("image"):
                            b64 = data.get("image")
                    if b64:
                        img_bytes = base64.b64decode(b64)
                        return {
                            "ok": True,
                            "image_bytes": img_bytes,
                            "model": target_model,
                            "engine": "custom_image",
                            "latency_ms": latency_ms,
                            "bytes": len(img_bytes)
                        }
                    if img_url:
                        dl_res = client.get(img_url, timeout=30.0)
                        if dl_res.status_code == 200 and len(dl_res.content) > 100:
                            return {
                                "ok": True,
                                "image_bytes": dl_res.content,
                                "model": target_model,
                                "engine": "custom_image",
                                "latency_ms": latency_ms,
                                "bytes": len(dl_res.content)
                            }
                if len(res.content) > 100:
                    return {
                        "ok": True,
                        "image_bytes": res.content,
                        "model": target_model,
                        "engine": "custom_image",
                        "latency_ms": latency_ms,
                        "bytes": len(res.content)
                    }
            return {"ok": False, "error": f"Custom Image error: HTTP {res.status_code} - {res.text[:200]}", "latency_ms": latency_ms}
    except Exception as e:
        return {"ok": False, "error": f"Custom Image request failed: {str(e)}", "latency_ms": int((time.time() - t0) * 1000)}


def generate_and_save_image(
    prompt: str,
    slug: str,
    public_dir: Optional[str] = None
) -> Dict[str, Any]:
    """
    Generates and saves a hero image by trying engines in the order configured
    via IMAGE_ENGINE_ORDER (config.py / .env / Settings UI):

      - "gemini":      Google Gemini API key (GEMINI_API_KEY) — free tier
      - "cloudflare":  Cloudflare Workers AI (Flux-1-Schnell, SDXL) via REST API
      - "openai":      OpenAI DALL-E 3 / Images API (OPENAI_IMAGE_KEY / OPENAI_API_KEY)
      - "codex":       ChatGPT/Codex OAuth backend (gpt-image-2)
      - "custom":      Custom image generation endpoint (CUSTOM_IMAGE_URL)
      - "tavily":      Tavily Search API for free-licensed stock photos (Unsplash, Pexels, etc.)
      - "pollinations": keyless generative fallback (legacy)

    Default ("auto"): cloudflare -> gemini -> openai -> codex -> tavily -> procedural SVG.
    The first engine that returns an image wins; every failure reason is
    captured in the returned engine_errors dict for dashboard diagnostics.

    public_dir: optional per-website local Next.js public/uploads target used
    instead of the global NEXTJS_PUBLIC_DIR (keeps two local clones isolated).
    """
    clean_slug = re.sub(r"[^\w-]", "", slug.lower().replace(" ", "-"))[:40] or "hero"
    unique_suffix = f"{int(time.time()) % 100000}-{random.randint(100, 999)}"
    file_name = f"{clean_slug}-{unique_suffix}.jpg"
    output_path = UPLOADS_DIR / file_name

    token = get_codex_token()
    image_bytes = None
    engine_used = "generative_highres_engine"
    model_used = GPT_IMAGE_2_DEFAULT
    imagegen_request_id = None
    codex_rate_limited = False
    resets_in_seconds = None

    # Engines are tried in the user-configured order (IMAGE_ENGINE_ORDER);
    # each records why it failed so the dashboard can show real diagnostics.
    gemini_asset = None
    fallback_url = None
    engine_errors: Dict[str, str] = {}

    for engine in _resolve_engine_order():
        if image_bytes:
            break

        if engine == "gemini":
            # Google Gemini (free tier, plain API key — no OAuth)
            if not get_gemini_api_key():
                engine_errors["gemini"] = "GEMINI_API_KEY not configured"
                continue
            logger.info("Dispatching image prompt to Google Gemini...")
            try:
                gemini_asset = generate_gemini_image(prompt=prompt, slug=clean_slug)
                if gemini_asset.get("image_bytes"):
                    image_bytes = gemini_asset["image_bytes"]
                    engine_used = "google_gemini"
                    model_used = gemini_asset.get("model") or "gemini"
                    logger.info(f"Successfully generated image via Google Gemini ({model_used})!")
                else:
                    engine_errors["gemini"] = gemini_asset.get("error") or "unknown error"
                    logger.warning(f"Gemini image generation failed: {engine_errors['gemini']}. Trying next engine.")
                    gemini_asset = None
            except Exception as e:
                engine_errors["gemini"] = str(e)
                logger.warning(f"Gemini image generation error: {e}. Trying next engine.")
                gemini_asset = None

        elif engine == "cloudflare":
            # Cloudflare Workers AI (Flux-1-Schnell, SDXL, etc.)
            if not get_cloudflare_account_id() or not get_cloudflare_api_token():
                engine_errors["cloudflare"] = "Cloudflare Account ID or API Token not configured"
                continue
            logger.info("Dispatching image prompt to Cloudflare Workers AI...")
            try:
                cf_asset = generate_cloudflare_image(prompt=prompt, slug=clean_slug)
                if cf_asset.get("image_bytes"):
                    image_bytes = cf_asset["image_bytes"]
                    engine_used = "cloudflare_workers_ai"
                    model_used = cf_asset.get("model") or "flux-1-schnell"
                    logger.info(f"Successfully generated image via Cloudflare Workers AI ({model_used})!")
                else:
                    engine_errors["cloudflare"] = cf_asset.get("error") or "Unknown Cloudflare error"
                    logger.warning(f"Cloudflare Workers AI failed: {engine_errors['cloudflare']}. Trying next engine.")
            except Exception as e:
                engine_errors["cloudflare"] = str(e)
                logger.warning(f"Cloudflare Workers AI generation error: {e}. Trying next engine.")

        elif engine == "openai":
            # OpenAI DALL-E / Images API
            if not get_openai_image_key():
                engine_errors["openai"] = "OPENAI_IMAGE_KEY / OPENAI_API_KEY not configured"
                continue
            logger.info("Dispatching image prompt to OpenAI DALL-E...")
            try:
                oai_asset = generate_openai_image(prompt=prompt, slug=clean_slug)
                if oai_asset.get("image_bytes"):
                    image_bytes = oai_asset["image_bytes"]
                    engine_used = "openai_dalle"
                    model_used = oai_asset.get("model") or "dall-e-3"
                    logger.info(f"Successfully generated image via OpenAI ({model_used})!")
                else:
                    engine_errors["openai"] = oai_asset.get("error") or "Unknown OpenAI Images error"
                    logger.warning(f"OpenAI Images failed: {engine_errors['openai']}. Trying next engine.")
            except Exception as e:
                engine_errors["openai"] = str(e)
                logger.warning(f"OpenAI image generation error: {e}. Trying next engine.")

        elif engine == "codex":
            # Native ChatGPT / Codex backend dispatch (gpt-image-2)
            if not token:
                engine_errors["codex"] = "No Codex OAuth token configured"
                continue
            logger.info(f"Dispatching image prompt to Codex backend ({GPT_IMAGE_2_DEFAULT})...")
            try:
                headers = _build_codex_headers(token)
                body = {
                    "prompt": prompt,
                    "model": GPT_IMAGE_2_DEFAULT,
                    "n": 1,
                    "quality": "medium",
                    "size": "1024x1024",
                    "background": "opaque"
                }
                with httpx.Client(timeout=60.0) as client:
                    res = client.post(f"{_CODEX_BASE_URL}/images/generations", headers=headers, json=body)
                    imagegen_request_id = res.headers.get("x-codex-imagegen-request-id")

                    if res.status_code == 200:
                        payload = res.json()
                        data = payload.get("data")
                        if isinstance(data, list) and data and isinstance(data[0], dict):
                            b64 = data[0].get("b64_json")
                            if b64:
                                image_bytes = base64.b64decode(b64)
                                engine_used = "openai_codex_oauth"
                                logger.info("Successfully generated image via OpenAI Codex OAuth!")
                    elif res.status_code == 429:
                        codex_rate_limited = True
                        try:
                            err_payload = res.json().get("error", {})
                            resets_in_seconds = err_payload.get("resets_in_seconds")
                        except Exception:
                            pass
                        engine_errors["codex"] = f"Rate limited (resets in {resets_in_seconds}s)"
                        logger.warning(f"Codex OAuth 429 (usage limit reached). Resets in {resets_in_seconds}s. Using next engine.")
                    else:
                        engine_errors["codex"] = f"HTTP {res.status_code}: {_summarize_error_body(res.text)}"
                        logger.warning(f"Codex API responded HTTP {res.status_code}: {_summarize_error_body(res.text)}")
            except Exception as e:
                engine_errors["codex"] = str(e)
                logger.warning(f"Codex image generation error: {e}. Switching to next engine.")

        elif engine == "custom":
            # Custom Image Generation Endpoint
            if not get_custom_image_url():
                engine_errors["custom"] = "CUSTOM_IMAGE_URL not configured"
                continue
            logger.info("Dispatching image prompt to Custom Image Endpoint...")
            try:
                custom_asset = generate_custom_image(prompt=prompt, slug=clean_slug)
                if custom_asset.get("image_bytes"):
                    image_bytes = custom_asset["image_bytes"]
                    engine_used = "custom_image"
                    model_used = custom_asset.get("model") or "custom"
                    logger.info(f"Successfully generated image via Custom Endpoint ({model_used})!")
                else:
                    engine_errors["custom"] = custom_asset.get("error") or "Unknown Custom Image error"
                    logger.warning(f"Custom Image failed: {engine_errors['custom']}. Trying next engine.")
            except Exception as e:
                engine_errors["custom"] = str(e)
                logger.warning(f"Custom image generation error: {e}. Trying next engine.")

        elif engine == "tavily":
            # Search Tavily API for authentic, high-res free-licensed photos (Unsplash, Pexels, Wikimedia)
            logger.info(f"Searching Tavily for free-licensed stock imagery (Unsplash/Pexels) for: '{clean_slug}'...")
            tavily_res = search_tavily_free_stock_image(prompt=prompt, slug=clean_slug)
            if tavily_res:
                image_bytes, source_url, model_used = tavily_res
                engine_used = "tavily_search"
                fallback_url = source_url
                logger.info(f"Successfully retrieved free-licensed editorial image via Tavily: {source_url[:80]}...")
            else:
                engine_errors["tavily"] = "Tavily search returned no valid downloadable free-licensed images"
                logger.warning("Tavily free-licensed image search was unsuccessful. Trying next engine.")

        elif engine == "pollinations":
            # Resilient Generative Fallback (Pollinations High-Res Generator, dynamic seed)
            dynamic_seed = random.randint(1000, 9999999)
            logger.info(f"Using high-resolution generative fallback (seed={dynamic_seed}) for prompt: '{prompt[:60]}...'")
            encoded_prompt = urllib.parse.quote(prompt)
            fallback_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}?width=1200&height=630&nologo=true&seed={dynamic_seed}"

            try:
                with httpx.Client(timeout=20.0, follow_redirects=True) as client:
                    res = client.get(fallback_url)
                    content_type = res.headers.get("content-type", "")
                    # Validate we actually got an image (not an HTML error/rate-limit page)
                    if (
                        res.status_code == 200
                        and len(res.content) > 1000
                        and (content_type.startswith("image/") or not content_type)
                    ):
                        image_bytes = res.content
                        engine_used = "pollinations-fallback"
                        model_used = "pollinations-fallback"
                        logger.info("Successfully fetched bespoke hero image from generative fallback!")
                    else:
                        engine_errors["pollinations"] = (
                            f"Non-image response (status={res.status_code}, type={content_type or 'unknown'}, bytes={len(res.content)})"
                        )
                        logger.warning(
                            f"Generative fallback returned non-image response "
                            f"(status={res.status_code}, type={content_type or 'unknown'}, bytes={len(res.content)})."
                        )
            except Exception as e:
                engine_errors["pollinations"] = str(e)
                logger.warning(f"Generative image fallback download failed: {e}")

    # 3. Procedural SVG Fallback if network fails completely
    if not image_bytes:
        logger.info("Creating local procedural editorial placeholder.")
        svg_content = f"""<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
          <defs>
            <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#0c0e12" />
              <stop offset="50%" stop-color="#171b24" />
              <stop offset="100%" stop-color="#11141a" />
            </linearGradient>
            <linearGradient id="glow" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#ff5436" stop-opacity="0.8" />
              <stop offset="100%" stop-color="#f59e0b" stop-opacity="0.8" />
            </linearGradient>
          </defs>
          <rect width="1200" height="630" fill="url(#bg)" />
          <circle cx="950" cy="180" r="280" fill="url(#glow)" opacity="0.12" filter="blur(40px)" />
          <line x1="80" y1="80" x2="1120" y2="80" stroke="rgba(255,255,255,0.1)" stroke-width="1" />
          <text x="80" y="260" font-family="'Newsreader', Georgia, serif" font-size="44" font-weight="600" fill="#f7f6f2">THE DISPATCH</text>
          <text x="80" y="320" font-family="'Plus Jakarta Sans', sans-serif" font-size="24" fill="#9ea4b5">Editorial Visual Asset &bull; Continuous Edition</text>
          <line x1="80" y1="540" x2="1120" y2="540" stroke="rgba(255,255,255,0.08)" stroke-width="1" />
        </svg>"""
        file_name = f"{clean_slug}-{unique_suffix}.svg"
        output_path = UPLOADS_DIR / file_name
        output_path.write_text(svg_content, encoding="utf-8")
        engine_used = "procedural-svg"
        model_used = "procedural-svg"
    else:
        output_path.write_bytes(image_bytes)

    # Calculate local and public URLs (Gemini assets already carry their own paths)
    if gemini_asset:
        local_path_str = gemini_asset["hero_image_path"]
        relative_url = gemini_asset["hero_image_url"]
        public_url = gemini_asset["hero_image_full_url"]
    else:
        local_path_str = str(output_path)
        relative_url = f"/static/uploads/{output_path.name}"
        base_url = os.getenv("PUBLIC_BASE_URL", "").strip() or os.getenv("DEMO_WEBSITE_URL", "").strip() or getattr(config, "PUBLIC_BASE_URL", "http://127.0.0.1:8000")
        public_url = f"{base_url.rstrip('/')}{relative_url}"
    public_image_url = fallback_url if (fallback_url and (fallback_url.startswith("http://") or fallback_url.startswith("https://"))) else public_url

    # Mirror the asset the article actually links to into a local Next.js public
    # directory. A per-site public_dir (two local clones) wins over the global
    # NEXTJS_PUBLIC_DIR, and the Gemini .png is mirrored under the exact name
    # its hero_image_url references instead of the unreferenced .jpg alias.
    nextjs_public_dir = (public_dir or os.getenv("NEXTJS_PUBLIC_DIR", "")).strip()
    if nextjs_public_dir:
        source_asset = Path(local_path_str)
        try:
            nxt_dir = Path(nextjs_public_dir)
            if source_asset.is_file() and nxt_dir.parent.exists():
                nxt_dir.mkdir(parents=True, exist_ok=True)
                dest = nxt_dir / source_asset.name
                if source_asset.resolve() != dest.resolve():
                    shutil.copy2(source_asset, dest)
                    logger.info(f"Synced hero image to Next.js public uploads: {dest}")
        except Exception as sync_err:
            logger.debug(f"Next.js public sync: {sync_err}")

    logger.info(f"Hero image saved to: {local_path_str}")

    return {
        "hero_image_path": local_path_str,
        "hero_image_url": relative_url,
        "hero_image_full_url": public_url,
        "public_image_url": public_image_url,
        "source_url": fallback_url if (fallback_url and (fallback_url.startswith("http://") or fallback_url.startswith("https://"))) else None,
        "image_prompt": prompt,
        "engine": engine_used,
        "model": model_used,
        "codex_rate_limited": codex_rate_limited,
        "resets_in_seconds": resets_in_seconds,
        "imagegen_request_id": imagegen_request_id,
        "engine_errors": engine_errors
    }


def test_openai_image_generation(api_key: Optional[str] = None, model: Optional[str] = None) -> Dict[str, Any]:
    return generate_openai_image(
        prompt="Modern minimalist editorial tech artwork, dramatic lighting, obsidian block, vibrant amber glow, no text",
        slug="openai-diagnostic",
        api_key=api_key,
        model=model,
    )


def test_custom_image_generation(endpoint_url: Optional[str] = None, api_key: Optional[str] = None, model: Optional[str] = None) -> Dict[str, Any]:
    return generate_custom_image(
        prompt="Modern minimalist editorial tech artwork, dramatic lighting, obsidian block, vibrant amber glow, no text",
        slug="custom-diagnostic",
        endpoint_url=endpoint_url,
        api_key=api_key,
        model=model,
    )
