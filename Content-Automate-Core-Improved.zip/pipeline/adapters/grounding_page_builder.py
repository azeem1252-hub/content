"""
Grounding Page Builder — Grounding Page Standard v1.6.

A Grounding Page is the canonical, machine-readable definition of an entity
(brand, product, or organization) published at a stable URL so AI answer engines
resolve the entity unambiguously instead of inferring it from scattered prose.
The blueprint names "Grounding Page generation" as the MVP's foundational GEO
feature.

Each page ships as a triple: human/LLM-readable Markdown, a standalone HTML
document, and Schema.org JSON-LD (with `sameAs` links) for knowledge-graph
resolution.

Standard v1.6 sections:
  1. Canonical Definition        (one immutable sentence)
  2. What It Is Not              (boundary delimitation)
  3. Atomic Facts                (confidence-scored, source-cited assertions)
  4. Key Specifications          (attribute table)
  5. Entity Graph / sameAs       (authoritative profile links)
  6. Citation Block              (a passage LLMs can quote verbatim)

The builder is file-only and offline-safe: it never requires network access.
`BASE_DIR` / `GROUNDING_DIR` are resolved at call time so tests and multi-site
setups can redirect output.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from config import BASE_DIR
from pipeline.adapters.brand_dna import append_memory_learning

logger = logging.getLogger("pipeline.adapters.grounding_page")

GROUNDING_PAGE_STANDARD = "1.6"
STANDARD_LABEL = f"Grounding Page Standard v{GROUNDING_PAGE_STANDARD}"

# Module-level so it can be overridden/patched; resolved at call time below.
GROUNDING_DIR = BASE_DIR / "web" / "static" / "grounding"


def _grounding_dir() -> Path:
    """Resolves the output directory at call time.

    Prefers GROUNDING_DIR when it still lives under BASE_DIR (an explicit
    redirect), otherwise follows BASE_DIR so patching either one works.
    """
    base = Path(BASE_DIR)
    gd = Path(GROUNDING_DIR)
    default = base / "web" / "static" / "grounding"
    try:
        if str(gd) == str(default) or str(gd).startswith(str(base)):
            return gd
    except Exception:  # noqa: BLE001
        pass
    return default


def _slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-") or "entity"


def _normalize_atomic_facts(atomic_facts: Optional[List[Dict[str, Any]]], generated_at: str) -> List[Dict[str, Any]]:
    normalized: List[Dict[str, Any]] = []
    for fact in atomic_facts or []:
        if not isinstance(fact, dict):
            continue
        statement = str(fact.get("statement") or fact.get("claim") or fact.get("fact") or "").strip()
        if not statement:
            continue
        normalized.append({
            "statement": statement,
            "claim": statement,
            "confidence": float(fact.get("confidence", 0.95) or 0.95),
            "source": str(fact.get("source") or "").strip(),
            "timestamp": str(fact.get("timestamp") or fact.get("as_of") or generated_at),
        })
    return normalized


def _citation_block(
    definition: str,
    specifications: Dict[str, str],
    atomic_facts: List[Dict[str, Any]],
) -> str:
    parts = [(definition or "").strip()]
    if specifications:
        pairs = [f"{k}: {v}" for k, v in list(specifications.items())[:4]]
        parts.append("Key specifications include " + "; ".join(pairs) + ".")
    if atomic_facts:
        parts.append(" ".join(f["statement"] for f in atomic_facts[:3]))
    return " ".join(p for p in parts if p).strip()


def build_grounding_json_ld(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Schema.org JSON-LD for knowledge-graph resolution."""
    node: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": payload.get("entity_type") or "Organization",
        "name": payload.get("entity_name"),
        "description": payload.get("canonical_definition"),
        "url": payload.get("grounding_url") or payload.get("canonical_url"),
    }
    if payload.get("same_as_urls"):
        node["sameAs"] = payload["same_as_urls"]
    if payload.get("specifications"):
        node["additionalProperty"] = [
            {"@type": "PropertyValue", "name": k, "value": v}
            for k, v in payload["specifications"].items()
        ]
    if payload.get("atomic_facts"):
        node["subjectOf"] = [
            {
                "@type": "Claim",
                "text": f["statement"],
                "confidence": f.get("confidence"),
                "citation": f.get("source") or None,
            }
            for f in payload["atomic_facts"]
        ]
    if payload.get("what_it_is_not"):
        node["disambiguatingDescription"] = "Not: " + "; ".join(payload["what_it_is_not"])
    return node


def render_grounding_markdown(payload: Dict[str, Any]) -> str:
    """Renders the standard v1.6 markdown document."""
    lines: List[str] = []
    lines.append(f"# {payload.get('entity_name')} — Canonical Entity Definition")
    lines.append("")
    lines.append(f"*{STANDARD_LABEL} · Generated {payload.get('generated_at')}*")
    lines.append("")
    if payload.get("site_name"):
        lines.append(f"Published by {payload['site_name']}.")
        lines.append("")

    lines.append("## 1. Canonical Definition")
    lines.append(payload.get("canonical_definition") or "")
    lines.append("")

    if payload.get("what_it_is_not"):
        lines.append("## 2. What It Is Not")
        for item in payload["what_it_is_not"]:
            text = str(item).strip()
            lines.append(f"- {text}" if text else "-")
        lines.append("")

    if payload.get("atomic_facts"):
        lines.append("## 3. Atomic Facts")
        lines.append("| Assertion | Confidence | Source | Timestamp |")
        lines.append("| :--- | :--- | :--- | :--- |")
        for fact in payload["atomic_facts"]:
            lines.append(
                f"| {fact['statement']} | {fact.get('confidence')} | {fact.get('source') or '—'} | {fact.get('timestamp') or '—'} |"
            )
        lines.append("")

    if payload.get("specifications"):
        lines.append("## 4. Key Specifications")
        lines.append("| Attribute | Value |")
        lines.append("| :--- | :--- |")
        for key, value in payload["specifications"].items():
            lines.append(f"| {key} | {value} |")
        lines.append("")

    if payload.get("same_as_urls"):
        lines.append("## 5. Entity Graph (sameAs)")
        for link in payload["same_as_urls"]:
            lines.append(f"- {link}")
        lines.append("")

    lines.append("## 6. Citation Block")
    lines.append(f"> {payload.get('citation_block')}")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(payload.get("json_ld"), indent=2))
    lines.append("```")
    return "\n".join(lines).strip() + "\n"


def render_grounding_html(payload: Dict[str, Any]) -> str:
    """Renders a standalone HTML document carrying the entity JSON-LD."""
    entity_type = payload.get("entity_type") or "Organization"
    json_ld = json.dumps(payload.get("json_ld"), indent=2)
    facts_html = "".join(
        f"<li><strong>{f['statement']}</strong> <em>(confidence {f.get('confidence')})</em></li>"
        for f in payload.get("atomic_facts") or []
    )
    specs_html = "".join(
        f"<tr><th>{k}</th><td>{v}</td></tr>" for k, v in (payload.get("specifications") or {}).items()
    )
    not_html = "".join(f"<li>{item}</li>" for item in (payload.get("what_it_is_not") or []))
    same_as_html = "".join(f'<li><a href="{u}">{u}</a></li>' for u in (payload.get("same_as_urls") or []))

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>{payload.get('entity_name')} — Grounding Page</title>
<meta name="description" content="{payload.get('canonical_definition')}" />
<link rel="canonical" href="{payload.get('grounding_url') or payload.get('canonical_url')}" />
<script type="application/ld+json">
{json_ld}
</script>
</head>
<body itemscope itemtype="https://schema.org/{entity_type}">
<main>
<header>
  <h1 itemprop="name">{payload.get('entity_name')}</h1>
  <p><small>{STANDARD_LABEL} · generated {payload.get('generated_at')}</small></p>
  <p itemprop="description">{payload.get('canonical_definition')}</p>
</header>
<section><h2>What It Is Not</h2><ul>{not_html}</ul></section>
<section><h2>Atomic Facts</h2><ul>{facts_html}</ul></section>
<section><h2>Key Specifications</h2><table><tbody>{specs_html}</tbody></table></section>
<section><h2>Entity Graph</h2><ul>{same_as_html}</ul></section>
<section><h2>Citation Block</h2><blockquote>{payload.get('citation_block')}</blockquote></section>
<footer><pre>{json_ld}</pre></footer>
</main>
</body>
</html>
"""


def build_grounding_page_payload(
    entity_name: str,
    canonical_url: str = "",
    base_url: Optional[str] = None,
    entity_type: str = "Organization",
    stable_definition: str = "",
    canonical_definition: Optional[str] = None,
    what_it_is_not: Optional[List[str]] = None,
    atomic_facts: Optional[List[Dict[str, Any]]] = None,
    key_specifications: Optional[Dict[str, str]] = None,
    specifications: Optional[Dict[str, str]] = None,
    same_as_links: Optional[List[str]] = None,
    same_as_urls: Optional[List[str]] = None,
    site_name: str = "",
    slug: Optional[str] = None,
) -> Dict[str, Any]:
    """Assembles the structured Grounding Page payload (no I/O).

    Accepts both parameter spellings (`canonical_url`/`base_url`,
    `stable_definition`/`canonical_definition`, `key_specifications`/
    `specifications`, `same_as_links`/`same_as_urls`).
    """
    generated_at = datetime.now(timezone.utc).isoformat()
    url = (base_url or canonical_url or "").strip()
    definition = (canonical_definition or stable_definition or "").strip() or (
        f"{entity_name} is a {entity_type.lower()} documented at {url.rstrip('/')} "
        f"under the {STANDARD_LABEL} for unambiguous machine resolution."
        if url else
        f"{entity_name} is a {entity_type.lower()} documented under the {STANDARD_LABEL} for unambiguous machine resolution."
    )
    page_slug = _slugify(slug or entity_name)
    normalized_facts = _normalize_atomic_facts(atomic_facts, generated_at)
    clean_specs = {str(k): str(v) for k, v in (specifications or key_specifications or {}).items()}
    clean_same_as = [str(x).strip() for x in (same_as_urls or same_as_links or []) if str(x).strip()]

    payload: Dict[str, Any] = {
        "standard": STANDARD_LABEL,
        "standard_version": GROUNDING_PAGE_STANDARD,
        "entity_name": entity_name,
        "entity_type": entity_type or "Organization",
        "slug": page_slug,
        "site_name": site_name,
        "canonical_url": url,
        "grounding_url": f"{url.rstrip('/')}/grounding/{page_slug}" if url else f"/grounding/{page_slug}",
        "canonical_definition": definition,
        "what_it_is_not": [str(x).strip() for x in (what_it_is_not or []) if str(x).strip()],
        "atomic_facts": normalized_facts,
        "specifications": clean_specs,
        "same_as_urls": clean_same_as,
        "generated_at": generated_at,
    }
    payload["citation_block"] = _citation_block(definition, clean_specs, normalized_facts)
    payload["json_ld"] = build_grounding_json_ld(payload)
    markdown = render_grounding_markdown(payload)
    payload["markdown"] = markdown
    payload["markdown_content"] = markdown
    payload["html_content"] = render_grounding_html(payload)
    return payload


# Alias: the same builder under the explicit standard-versioned name.
def generate_grounding_page_v16(**kwargs: Any) -> Dict[str, Any]:
    """Alias for build_grounding_page_payload (standard v1.6)."""
    return build_grounding_page_payload(**kwargs)


def save_and_deploy_grounding_page(
    entity_name: str,
    canonical_url: str = "",
    stable_definition: str = "",
    site_name: str = "",
    base_url: Optional[str] = None,
    entity_type: str = "Organization",
    canonical_definition: Optional[str] = None,
    what_it_is_not: Optional[List[str]] = None,
    atomic_facts: Optional[List[Dict[str, Any]]] = None,
    key_specifications: Optional[Dict[str, str]] = None,
    specifications: Optional[Dict[str, str]] = None,
    same_as_links: Optional[List[str]] = None,
    same_as_urls: Optional[List[str]] = None,
    slug: Optional[str] = None,
) -> Dict[str, Any]:
    """Builds and persists a Grounding Page, returning its deployment record."""
    payload = build_grounding_page_payload(
        entity_name=entity_name,
        canonical_url=canonical_url,
        base_url=base_url,
        entity_type=entity_type,
        stable_definition=stable_definition,
        canonical_definition=canonical_definition,
        what_it_is_not=what_it_is_not,
        atomic_facts=atomic_facts,
        key_specifications=key_specifications,
        specifications=specifications,
        same_as_links=same_as_links,
        same_as_urls=same_as_urls,
        site_name=site_name,
        slug=slug,
    )

    target_dir = _grounding_dir()
    target_dir.mkdir(parents=True, exist_ok=True)
    stem = payload["slug"]
    md_path = target_dir / f"{stem}.md"
    html_path = target_dir / f"{stem}.html"
    json_path = target_dir / f"{stem}.json"

    md_path.write_text(payload["markdown"], encoding="utf-8")
    html_path.write_text(payload["html_content"], encoding="utf-8")
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    try:
        append_memory_learning(
            "Grounding Page Standard v1.6",
            f"Published grounding page for '{entity_name}' ({payload['entity_type']}) at {payload['grounding_url']}.",
        )
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Grounding page memory learning skipped: {e}")

    indexnow_result = None
    try:
        from pipeline.adapters.indexnow_client import submit_indexnow_urls
        if payload.get("canonical_url"):
            indexnow_result = submit_indexnow_urls(urls=[payload["grounding_url"]])
    except Exception as e:  # noqa: BLE001
        logger.debug(f"IndexNow ping for grounding page skipped: {e}")

    logger.info(f"Grounding page deployed: {md_path}")
    return {
        "status": "deployed",
        "standard": STANDARD_LABEL,
        "entity_name": entity_name,
        "slug": stem,
        "grounding_url": payload["grounding_url"],
        "files": {"markdown": str(md_path), "html": str(html_path), "json": str(json_path)},
        "citation_block": payload["citation_block"],
        "atomic_fact_count": len(payload["atomic_facts"]),
        "indexnow": indexnow_result,
    }


def list_existing_grounding_pages() -> Dict[str, Any]:
    """Lists deployed Grounding Pages with their core metadata."""
    pages: List[Dict[str, Any]] = []
    target_dir = _grounding_dir()
    if target_dir.exists():
        for json_file in sorted(target_dir.glob("*.json")):
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            pages.append({
                "slug": data.get("slug") or json_file.stem,
                "entity_name": data.get("entity_name"),
                "entity_type": data.get("entity_type"),
                "grounding_url": data.get("grounding_url"),
                "generated_at": data.get("generated_at"),
                "standard": data.get("standard"),
                "atomic_fact_count": len(data.get("atomic_facts") or []),
            })
    return {
        "standard_version": GROUNDING_PAGE_STANDARD,
        "count": len(pages),
        "pages": pages,
        "directory": str(target_dir),
    }


# Alias kept for API compatibility with earlier integrations.
def list_grounding_pages() -> List[Dict[str, Any]]:
    return list_existing_grounding_pages()["pages"]
