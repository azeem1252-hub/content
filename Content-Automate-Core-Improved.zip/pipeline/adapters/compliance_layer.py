"""
Compliance, Disclosure & Reviewer Attestation Layer (Pillar A10).

Implements strict regulatory compliance and editorial responsibility:
1. EU AI Act Article 50 (effective 2 Aug 2026):
   - Mandatory AI disclosure for public-interest content, UNLESS a human editor reviewed
     and holds documented editorial responsibility.
2. Google 1 Oct 2026 AI Content Guidance:
   - Requires manual verification of titles, meta descriptions, structured data, and alt text.
3. Immutable Reviewer Attestations:
   - Cryptographic version hash, named reviewer identity, verified qualifications, timestamp.
4. YMYL / Public-Interest Topic Classification:
   - Flags sensitive health, financial, or legal domains requiring a qualified expert.
5. AI Image Provenance:
   - Generates IPTC DigitalSourceType metadata and public disclosure badges.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import storage.db as db

logger = logging.getLogger("pipeline.adapters.compliance_layer")

YMYL_KEYWORDS = {
    "health": ["treatment", "cure", "dosage", "medical", "disease", "symptom", "therapy", "pharma"],
    "finance": ["invest", "stocks", "crypto", "loan", "mortgage", "tax", "banking", "financial advice"],
    "legal": ["lawsuit", "attorney", "liability", "contract", "statute", "court", "legal rights"],
    "civic": ["election", "voting", "ballot", "legislation", "government policy"],
}


def classify_ymyl_and_public_interest(topic: str, content: str = "") -> Dict[str, Any]:
    """
    Classifies whether an article falls under Your Money Your Life (YMYL)
    or EU AI Act Article 50 public-interest disclosure scope.
    """
    corpus = f"{topic} {content[:1500]}".lower()
    categories_found = []

    for cat, terms in YMYL_KEYWORDS.items():
        if any(re.search(rf"\b{re.escape(term)}\b", corpus) for term in terms):
            categories_found.append(cat)

    is_ymyl = len(categories_found) > 0
    return {
        "is_ymyl": is_ymyl,
        "is_public_interest": is_ymyl,
        "detected_categories": categories_found,
        "requires_expert_reviewer": is_ymyl
    }


def compute_content_version_hash(title: str, content: str, meta: Dict[str, Any]) -> str:
    """
    Computes an immutable SHA-256 hash of the exact content version being attested.
    Guarantees that post-attestation mutations can be detected immediately.
    """
    payload = {
        "title": title.strip(),
        "content": content.strip(),
        "meta": meta
    }
    dumped = json.dumps(payload, sort_keys=True)
    return hashlib.sha256(dumped.encode("utf-8")).hexdigest()


def generate_eu_ai_act_disclosure(
    website_id: str,
    has_human_attestation: bool,
    reviewer_name: Optional[str] = None
) -> Dict[str, Any]:
    """
    Determines the appropriate EU AI Act Article 50 disclosure notice.
    If a qualified human held editorial responsibility and attested to fact-checking,
    an editorial exemption badge applies. Otherwise, full AI disclosure is emitted.
    """
    settings = db.get_compliance_settings(website_id)
    if not settings.get("eu_ai_act_disclosure_enabled", True):
        return {"disclosure_required": False, "badge_html": "", "position": "none"}

    position = settings.get("disclosure_position", "header_and_footer")

    if has_human_attestation and reviewer_name:
        label_text = f"Reviewed and fact-checked by {reviewer_name}. Editorial responsibility held by publisher."
        badge_html = f'<div class="editorial-responsibility-badge" data-compliance="eu-ai-act-exempt"><span>Verified Editorial: {label_text}</span></div>'
        return {
            "disclosure_required": True,
            "is_human_exempt": True,
            "label_text": label_text,
            "badge_html": badge_html,
            "position": position
        }
    else:
        label_text = settings.get("disclosure_label_text", "Generated with AI assistance. Subject to ongoing editorial review.")
        badge_html = f'<div class="ai-transparency-disclosure" data-compliance="eu-ai-act-art50"><span>Transparency Notice: {label_text}</span></div>'
        return {
            "disclosure_required": True,
            "is_human_exempt": False,
            "label_text": label_text,
            "badge_html": badge_html,
            "position": position
        }


def validate_google_oct2026_checklist(checklist: Dict[str, bool]) -> Tuple[bool, List[str]]:
    """
    Enforces Google 1 Oct 2026 guidelines requiring manual verification
    of titles, meta descriptions, structured data, and alt text.
    """
    mandatory_items = [
        ("title_verified", "Article title manually reviewed for accuracy"),
        ("meta_description_verified", "Meta description manually checked against misleading claims"),
        ("schema_verified", "JSON-LD structured data checked against visible content"),
        ("alt_text_verified", "Image alt text reviewed for factual context without keyword stuffing"),
        ("claims_and_stats_verified", "All statistical figures and factual claims verified against primary sources"),
    ]

    missing = []
    for key, desc in mandatory_items:
        if not checklist.get(key):
            missing.append(desc)

    is_valid = len(missing) == 0
    return is_valid, missing


def submit_reviewer_attestation(
    website_id: str,
    post_slug: str,
    title: str,
    content: str,
    meta: Dict[str, Any],
    reviewer_name: str,
    reviewer_email: str,
    reviewer_role: str,
    is_qualified_expert: bool,
    checklist: Dict[str, bool]
) -> Dict[str, Any]:
    """
    Validates and records an immutable reviewer attestation complying with
    both EU AI Act Art. 50 and Google Oct 2026 editorial standards.
    """
    # 1. Validate checklist
    valid_checklist, missing = validate_google_oct2026_checklist(checklist)
    if not valid_checklist:
        raise ValueError(f"Cannot attest: Mandatory verification checklist incomplete. Missing: {', '.join(missing)}")

    # 2. Check YMYL expert qualification if required
    settings = db.get_compliance_settings(website_id)
    ymyl_check = classify_ymyl_and_public_interest(topic=title, content=content)
    if ymyl_check["requires_expert_reviewer"] and settings.get("require_expert_for_ymyl", True) and not is_qualified_expert:
        raise ValueError("Cannot attest: Topic classified as YMYL/public-interest, requiring a verified qualified expert.")

    # 3. Calculate immutable cryptographic version hash
    v_hash = compute_content_version_hash(title, content, meta)

    attestation_record = {
        "id": f"att_{uuid.uuid4().hex[:12]}",
        "post_slug": post_slug,
        "website_id": website_id,
        "version_hash": v_hash,
        "reviewer_name": reviewer_name,
        "reviewer_email": reviewer_email,
        "reviewer_role": reviewer_role,
        "is_qualified_expert": is_qualified_expert,
        "checklist": checklist,
        "attested_at": datetime.now(timezone.utc).isoformat()
    }

    att_id = db.record_reviewer_attestation(attestation_record)
    attestation_record["id"] = att_id

    logger.info(f"Recorded reviewer attestation {att_id} for {post_slug} by {reviewer_name} (hash={v_hash[:10]}...)")
    return attestation_record


def get_image_iptc_provenance_metadata(is_ai_generated: bool, generator_model: str = "") -> Dict[str, str]:
    """
    Returns IPTC Photo Metadata standards for synthetic/AI imagery
    (DigitalSourceType: compositeSynthetic or trainedAlgorithmicMedia).
    """
    if not is_ai_generated:
        return {"DigitalSourceType": "originalDigitalCapture"}

    return {
        "DigitalSourceType": "trainedAlgorithmicMedia",
        "Credit": f"Generated with {generator_model or 'AI Model'}",
        "CopyrightNotice": "Editorial use only",
        "Disclosure": "Synthetic media created with generative AI. Reviewed and approved by editorial team."
    }
