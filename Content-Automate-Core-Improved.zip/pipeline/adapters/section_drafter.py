"""
Section-by-Section Article Drafting Engine (Pillar A3.1).

Replaces monolithic single-prompt generation with sequential, structured drafting:
- Each section receives: brief slice, evidence for that section, style profile,
  and a running summary of prior sections (prevents repetition).
- Structured output (Pydantic StructuredDraft) forming a tree of sections,
  claims-flagged sentences, canonical answer-first passages, and citations.
- Records Jinja2 prompt version for auditability.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

from pipeline.adapters.structured_draft import StructuredDraft, DraftSection, ClaimCitation
from pipeline.adapters.prompt_manager import render_prompt
from pipeline.adapters.model_router import routed_call_llm, ROLE_DRAFTING
from pipeline.adapters.evidence_pack import place_evidence_in_brief
from pipeline.utils import extract_json_block, extract_section_from_malformed_json
from pipeline.adapters.question_naturalizer import (
    clean_double_question,
    clean_topic_phrase,
    extract_comparison_entities,
    naturalize_question,
)

logger = logging.getLogger("pipeline.adapters.section_drafter")


def _summarize_prior_sections(sections: List[DraftSection]) -> str:
    """Creates a concise summary of already drafted sections to prevent repetition."""
    if not sections:
        return ""
    lines = []
    for s in sections:
        lead = s.direct_answer or (s.markdown_content[:140] + "...")
        lines.append(f"- Section '{s.heading}': Established {lead.strip()}")
    return "\n".join(lines)


def generate_structured_article_draft(
    brief: Any,
    evidence_items: List[Dict[str, Any]],
    style_profile: Dict[str, Any],
    topic: str,
    title: Optional[str] = None,
    slug: Optional[str] = None,
) -> StructuredDraft:
    """
    Executes section-by-section drafting according to Pillar A3.1:
    Iterates through brief.required_sections, feeding each:
    - brief slice
    - evidence slice
    - style profile
    - summary of prior sections
    Outputs a typed StructuredDraft tree.
    """
    brief_data = brief.model_dump() if hasattr(brief, "model_dump") else (brief or {})
    sections_spec = brief_data.get("required_sections") or []

    if not sections_spec:
        # Fallback default 3-section outline if brief had no sections
        clean_subj = clean_topic_phrase(topic)
        comp = extract_comparison_entities(topic)
        if comp:
            h1 = f"Understanding Differences: {comp[0].title()} vs. {comp[1].title()}"
            q1 = f"What is the difference between {comp[0]} and {comp[1]} in games?"
        else:
            h1 = f"Understanding {clean_subj.title()}"
            q1 = naturalize_question(f"What is {clean_subj} and why does it matter?")

        sections_spec = [
            {
                "heading": h1,
                "level": 2,
                "target_word_count": 300,
                "answer_first_guidance": f"Define {clean_subj} and its core implications immediately.",
                "questions_to_answer": [q1],
                "required_entities": [],
                "claims_needing_sources": [],
                "internal_links": [],
            },
            {
                "heading": "Technical Architecture & Practical Mechanics",
                "level": 2,
                "target_word_count": 450,
                "answer_first_guidance": "Explain the architectural mechanics directly.",
                "questions_to_answer": ["How does this operate under real workloads?"],
                "required_entities": [],
                "claims_needing_sources": [],
                "internal_links": [],
            },
            {
                "heading": "Strategic Takeaways & Implementation",
                "level": 2,
                "target_word_count": 300,
                "answer_first_guidance": "Summarize key production recommendations.",
                "questions_to_answer": ["What are the decisive best practices?"],
                "required_entities": [],
                "claims_needing_sources": [],
                "internal_links": [],
            },
        ]

    # Map evidence items into respective sections
    evidence_placement = place_evidence_in_brief(sections_spec, evidence_items)

    art_title = title or brief_data.get("title") or f"Architectural Deep Dive: {topic}"
    art_slug = slug or re.sub(r"[^a-z0-9]+", "-", art_title.lower()).strip("-")

    drafted_sections: List[DraftSection] = []
    recorded_prompt_versions: Dict[str, str] = {}
    drafting_model_name = "default"

    for idx, sec_spec in enumerate(sections_spec, 1):
        heading = sec_spec.get("heading", f"Section {idx}")
        logger.info(f"Drafting section {idx}/{len(sections_spec)}: '{heading}'...")

        prior_summary = _summarize_prior_sections(drafted_sections)
        evidence_slice = evidence_placement.get(heading) or []

        prompt_context = {
            "section_index": idx,
            "brief_slice": sec_spec,
            "evidence_slice": evidence_slice,
            "style_profile": style_profile,
            "prior_sections_summary": prior_summary,
            "topic": topic,
        }

        try:
            prompt_text, prompt_ver = render_prompt("section_draft", prompt_context, version="v1.0.0")
            recorded_prompt_versions[f"section_{idx}"] = prompt_ver

            system_instruction = (
                "You are an acclaimed technical editor optimizing for Generative Engine Optimization (GEO) "
                "and Answer Engine Optimization (AEO). Write direct, authoritative, and empirical sections. "
                "Apply the Authoritative Strategy (cite exact figures/years from sources), the Quotation Strategy "
                "(expert blockquotes), provide direct 30-50 word canonical answers upfront, include Markdown tables "
                "for trade-offs, weave in required domain entities, eliminate AI cliches, and embed authoritative citations."
            )

            response_text, telemetry = routed_call_llm(
                role=ROLE_DRAFTING,
                prompt=prompt_text,
                system_instruction=system_instruction,
                temperature=0.4,
            )
            drafting_model_name = telemetry.get("model", "default")

            parsed = extract_json_block(response_text)
            if parsed and parsed.get("markdown_content"):
                claims = []
                for c in parsed.get("claims", []):
                    if isinstance(c, dict) and c.get("claim_text"):
                        try:
                            claims.append(ClaimCitation(
                                claim_text=str(c["claim_text"]),
                                source_url=c.get("source_url"),
                                anchor_text=c.get("anchor_text"),
                                citation_type=c.get("citation_type", "empirical_fact"),
                            ))
                        except Exception as clm_err:
                            logger.debug(f"Skipping malformed claim citation: {clm_err}")

                sec = DraftSection(
                    heading=parsed.get("heading", heading),
                    level=int(parsed.get("level", sec_spec.get("level", 2))),
                    markdown_content=parsed.get("markdown_content", "").strip(),
                    direct_answer=parsed.get("direct_answer", ""),
                    claims=claims,
                    citations=parsed.get("citations") or [],
                    key_entities_covered=parsed.get("key_entities_covered") or [],
                    evidence_used=parsed.get("evidence_used") or [ev.get("title") for ev in evidence_slice if ev.get("title")],
                )
                drafted_sections.append(sec)
            else:
                # Secondary recovery if response contained malformed JSON with markdown_content
                unpacked = extract_section_from_malformed_json(response_text)
                if unpacked and unpacked.get("markdown_content"):
                    sec = DraftSection(
                        heading=unpacked.get("heading") or heading,
                        level=int(unpacked.get("level") or sec_spec.get("level", 2)),
                        markdown_content=unpacked.get("markdown_content", "").strip(),
                        direct_answer=unpacked.get("direct_answer", ""),
                        evidence_used=[ev.get("title") for ev in evidence_slice if ev.get("title")],
                    )
                else:
                    # Clean text fallback if LLM returned raw text
                    from pipeline.utils import clean_article_content
                    clean_text = clean_article_content(response_text.strip())
                    sec = DraftSection(
                        heading=heading,
                        level=int(sec_spec.get("level", 2)),
                        markdown_content=clean_text,
                        direct_answer="",
                        evidence_used=[ev.get("title") for ev in evidence_slice if ev.get("title")],
                    )
                drafted_sections.append(sec)

        except Exception as e:
            logger.error(f"Failed drafting section '{heading}': {e}", exc_info=True)
            # Create a fallback placeholder section so generation continues
            drafted_sections.append(DraftSection(
                heading=heading,
                level=int(sec_spec.get("level", 2)),
                markdown_content=f"{heading} covers foundational architectural principles and domain benchmarks.",
            ))

    structured_draft = StructuredDraft(
        title=art_title,
        slug=art_slug,
        meta_description=brief_data.get("unique_angle", "")[:160] or f"Comprehensive guide to {topic}.",
        sections=drafted_sections,
        prompt_versions=recorded_prompt_versions,
        model_used=drafting_model_name,
        style_profile_version=style_profile.get("version", 1),
    )
    structured_draft.recompute_metrics()
    return structured_draft
