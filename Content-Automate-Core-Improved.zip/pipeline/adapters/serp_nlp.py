"""
Proprietary SERP-Grounded NLP Engine (Pillar II: Surfer NLP Paradigm).

Reverse-engineers live top-ranking SERP competitor content patterns:
1. Extracts high-salience multi-word semantic concepts & n-grams.
2. Identifies key domain entities, technical architectures, and proper nouns.
3. Maps competitor question-answer search intent structures.
4. Computes a 0-100 SERP Topical Coverage Score comparing a draft against competitor footprints.
5. Generates professional editorial optimization directives.
"""

import re
import logging
from collections import Counter
from typing import Dict, Any, List, Optional, Set

logger = logging.getLogger("pipeline.adapters.serp_nlp")

# Comprehensive Stopwords & Conversational Fluff
STOPWORDS: Set[str] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
    "below", "between", "both", "but", "by", "can", "can't", "cannot", "could",
    "couldn't", "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down",
    "during", "each", "few", "for", "from", "further", "had", "hadn't", "has",
    "hasn't", "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her",
    "here", "here's", "hers", "herself", "him", "himself", "his", "how", "how's",
    "i", "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "isn't", "it",
    "it's", "its", "itself", "let's", "me", "more", "most", "mustn't", "my",
    "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or",
    "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same",
    "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't", "so",
    "some", "such", "than", "that", "that's", "the", "their", "theirs", "them",
    "themselves", "then", "there", "there's", "these", "they", "they'd", "they'll",
    "they're", "they've", "this", "those", "through", "to", "too", "under", "until",
    "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're", "we've", "were",
    "weren't", "what", "what's", "when", "when's", "where", "where's", "which",
    "while", "who", "who's", "whom", "why", "why's", "with", "won't", "would",
    "wouldn't", "you", "you'd", "you'll", "you're", "you've", "your", "yours",
    "yourself", "yourselves", "also", "just", "like", "will", "use", "using", "used", "uses",
    "add", "added", "adding", "get", "got", "getting", "make", "made", "making",
    "take", "takes", "taking", "look", "looks", "see", "seen", "saw", "know", "known",
    "well", "way", "even", "much", "many", "good", "new", "first", "two", "one", "three",
    "day", "days", "time", "times", "year", "years", "pm", "am", "hour", "hours",
    "etc", "per", "vs", "versus",
    # Conversational verbs and generic filler
    "plays", "played", "playing", "sounds", "sounding", "sounded", "comes", "coming",
    "goes", "going", "tells", "telling", "shows", "showing", "gives", "giving",
    "finds", "finding", "works", "working", "helps", "helping", "feels", "feeling",
    "moves", "moving", "creates", "creating", "builds", "building", "explains", "explained",
    "called", "runs", "running", "brings", "bringing", "sets", "setting", "keeps", "keeping",
    "vital", "important", "great", "whole", "main", "real", "best", "various", "different",
    "recent", "several", "certain", "easy", "simple", "actually", "probably", "simply",
    # Scraped webpage and navigation boilerplate
    "ign", "logo", "pdf", "download", "subscribe", "newsletter", "privacy", "policy",
    "terms", "cookie", "cookies", "copyright", "rights", "reserved", "share", "shared",
    "tweet", "facebook", "twitter", "instagram", "youtube", "tiktok", "reddit",
    "login", "signup", "register", "menu", "search", "home", "about", "contact",
    "click", "read", "view", "link", "links", "ad", "ads", "advertisement", "sponsored",
    "affiliate", "disclaimer", "unofficial", "official", "tips", "tricks", "guide", "guides",
    "review", "reviews", "news", "video", "videos", "issue", "issues", "vol", "volume",
    "source", "sources", "entertainment", "media", "post", "posts", "page", "pages",
    "author", "byline", "published", "updated", "read time", "min read"
}


def _tokenize(text: str) -> List[str]:
    """Tokenizes text into clean lowercase alpha words."""
    clean = re.sub(r"[^\w\s-]", " ", text.lower())
    words = [w.strip("-") for w in clean.split() if len(w.strip("-")) >= 2]
    return words


def _extract_ngrams(words: List[str], n: int) -> List[str]:
    """
    Generates clean, semantically salient multi-word domain concepts.
    Enforces strict quality rules:
    - No word in the window may be a stopword, conversational verb, or boilerplate token.
    - Every word must be purely alphabetic and at least 3 characters.
    - Pure numbers and time units are discarded.
    """
    ngrams = []
    for i in range(len(words) - n + 1):
        window = words[i:i + n]
        # Quality rule: Every single word must be a clean domain term
        if any(len(w) < 3 or not w.isalpha() or w in STOPWORDS for w in window):
            continue
        # Reject digits or number prefixes
        if any(re.match(r"^\d+", w) for w in window):
            continue
        ngrams.append(" ".join(window))
    return ngrams


def extract_serp_semantic_footprint(
    competitor_texts: List[str],
    target_keywords: Optional[List[str]] = None,
    min_freq: int = 1
) -> Dict[str, Any]:
    """
    Extracts high-salience semantic clusters, n-grams, and entities from competitor SERP texts.
    Produces clean, professional entity concepts suitable for Surfer/Clearscope-style reporting.
    """
    if not competitor_texts:
        return {
            "salient_bigrams": [],
            "salient_trigrams": [],
            "salient_entities": [],
            "question_patterns": [],
            "total_competitor_words": 0
        }

    combined_text = "\n".join(competitor_texts)
    all_words = _tokenize(combined_text)
    total_words = len(all_words)

    # 1. N-Gram Extraction (Sentence-bounded to prevent boundary artifacts)
    bigrams = []
    trigrams = []
    total_words = 0

    for doc in competitor_texts:
        if not doc:
            continue
        sentences = re.split(r"[.!?\n\r]+", doc)
        for s in sentences:
            s_clean = s.strip()
            if not s_clean:
                continue
            words = _tokenize(s_clean)
            if not words:
                continue
            total_words += len(words)
            bigrams.extend(_extract_ngrams(words, 2))
            trigrams.extend(_extract_ngrams(words, 3))

    bigram_counts = Counter(bigrams)
    trigram_counts = Counter(trigrams)

    top_bigrams = [
        {"phrase": phrase, "count": count}
        for phrase, count in bigram_counts.most_common(20)
        if count >= min_freq
    ]

    top_trigrams = [
        {"phrase": phrase, "count": count}
        for phrase, count in trigram_counts.most_common(15)
        if count >= min_freq
    ]

    # 2. Salient Entity Clustering (Strict 1-3 word proper nouns in Title Case)
    raw_entities = re.findall(r"\b[A-Z][a-z0-9]+(?:\s+[A-Z][a-z0-9]+){0,2}\b", combined_text)
    clean_entities = []
    for ent in raw_entities:
        ent_lower = ent.lower()
        parts = ent_lower.split()
        # Reject if contains any stopword, boilerplate, or verb
        if any(p in STOPWORDS for p in parts):
            continue
        if len(ent) < 3 or len(parts) > 3:
            continue
        clean_entities.append(ent.strip())

    entity_counts = Counter(clean_entities)
    top_entities = [
        {"entity": ent, "count": count}
        for ent, count in entity_counts.most_common(15)
        if count >= min_freq
    ]

    # 3. Question-Answer Pattern Mining (Competitor search intent questions)
    raw_questions = re.findall(
        r"(?:^|\n|\.|\?)\s*([A-Z][a-zA-Z0-9\s,\-'\"]{10,120}\?)",
        combined_text
    )
    clean_questions = []
    for q in raw_questions:
        q_clean = q.strip()
        if len(q_clean) >= 15 and not any(b in q_clean.lower() for b in ("cookie", "privacy", "terms", "subscribe", "login")):
            clean_questions.append(q_clean)
    clean_questions = list(dict.fromkeys(clean_questions))[:6]

    return {
        "salient_bigrams": top_bigrams,
        "salient_trigrams": top_trigrams,
        "salient_entities": top_entities,
        "question_patterns": clean_questions,
        "total_competitor_words": total_words
    }


def evaluate_serp_coverage(
    draft: str,
    footprint: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Evaluates a candidate draft against the competitor semantic footprint.
    Returns coverage score (0-100) and actionable, professional gap recommendations.
    """
    if not draft or not footprint:
        return {
            "serp_coverage_score": 0,
            "matched_phrases_count": 0,
            "matched_bigrams": [],
            "matched_trigrams": [],
            "matched_entities": [],
            "missing_salient_phrases": [],
            "missing_entities": [],
            "recommendations": ["No competitor footprint provided for evaluation."]
        }

    draft_lower = draft.lower()

    # 1. Bigram coverage
    bigrams = footprint.get("salient_bigrams", [])
    matched_bigrams = []
    missing_bigrams = []
    for b in bigrams:
        phrase = b["phrase"]
        if phrase in draft_lower:
            matched_bigrams.append(phrase)
        else:
            missing_bigrams.append(phrase)

    bigram_ratio = (len(matched_bigrams) / len(bigrams)) if bigrams else 1.0

    # 2. Trigram coverage
    trigrams = footprint.get("salient_trigrams", [])
    matched_trigrams = []
    missing_trigrams = []
    for t in trigrams:
        phrase = t["phrase"]
        if phrase in draft_lower:
            matched_trigrams.append(phrase)
        else:
            missing_trigrams.append(phrase)

    trigram_ratio = (len(matched_trigrams) / len(trigrams)) if trigrams else 1.0

    # 3. Entity coverage
    entities = footprint.get("salient_entities", [])
    matched_entities = []
    missing_entities = []
    for e in entities:
        ent = e["entity"]
        if ent.lower() in draft_lower:
            matched_entities.append(ent)
        else:
            missing_entities.append(ent)

    entity_ratio = (len(matched_entities) / len(entities)) if entities else 1.0

    # 4. Question pattern resolution
    questions = footprint.get("question_patterns", [])
    resolved_questions = 0
    for q in questions:
        q_terms = [w for w in _tokenize(q) if w not in STOPWORDS]
        if q_terms:
            matched_q = sum(1 for term in q_terms if term in draft_lower)
            if matched_q / len(q_terms) >= 0.5:
                resolved_questions += 1

    question_ratio = (resolved_questions / len(questions)) if questions else 1.0

    # Weighted Composite Score
    # 35% bigrams, 25% trigrams, 25% entities, 15% question answers
    composite_score = round(
        (bigram_ratio * 35.0) +
        (trigram_ratio * 25.0) +
        (entity_ratio * 25.0) +
        (question_ratio * 15.0)
    )
    clamped_score = max(0, min(100, composite_score))

    # Formulate professional editorial recommendations
    recs = []
    gap_concepts = []
    for p in missing_bigrams[:3]:
        gap_concepts.append(p.title())
    for e in missing_entities[:3]:
        if e not in gap_concepts:
            gap_concepts.append(e)

    if gap_concepts:
        recs.append(f"Strengthen topical authority by addressing competitor coverage of {', '.join(gap_concepts[:4])}.")
    if questions and question_ratio < 0.6:
        recs.append("Incorporate dedicated H2 sections or FAQ answering core user intent questions.")
    if not recs:
        recs.append("Excellent topical coverage: draft fully covers competitor n-gram and entity footprint.")

    return {
        "serp_coverage_score": clamped_score,
        "matched_bigrams": matched_bigrams,
        "matched_trigrams": matched_trigrams,
        "matched_entities": matched_entities,
        "missing_salient_phrases": [p.title() for p in missing_bigrams[:6]],
        "missing_entities": missing_entities[:6],
        "unresolved_questions": [q for q in questions if q not in matched_bigrams][:3],
        "recommendations": recs
    }
