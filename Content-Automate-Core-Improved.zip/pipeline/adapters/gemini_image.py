"""
Google Gemini Image Generation Adapter.

Generates editorial hero images through the native Gemini API
(POST generativelanguage.googleapis.com/v1beta/models/{model}:generateContent)
using the free-tier-friendly GEMINI_API_KEY. No extra dependencies required.

Engine order in generate_and_save_image (codex_image.py) is user-configurable via
IMAGE_ENGINE_ORDER; the default is:
  1. Gemini API (see this module)
  2. Cloudflare Workers AI (Flux-1-Schnell / SDXL)
  3. OpenAI Codex OAuth (frequently rate-limited/unavailable)
  4. Tavily free-licensed stock photography
  5. Pollinations high-res fallback, then a procedural SVG placeholder
"""

from __future__ import annotations

import base64
import json
import logging
import os
from typing import Any, Dict, Optional

import httpx

import config

logger = logging.getLogger("pipeline.adapters.gemini_image")

_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# Tried in order: current recommended model first, then known-good fallbacks.
DEFAULT_GEMINI_IMAGE_MODEL = "gemini-3.1-flash-image-preview"
_GEMINI_MODEL_FALLBACKS = [
    "gemini-3.1-flash-image-preview",
    "gemini-2.5-flash-image",
]

_GEMINI_TIMEOUT_SECONDS = 90.0


def get_gemini_api_key() -> Optional[str]:
    """Resolves the Gemini API key from env/.env."""
    key = os.getenv("GEMINI_API_KEY", "").strip() or config.GEMINI_API_KEY
    return key or None


def get_gemini_image_model() -> str:
    """Resolves the configured Gemini image model (validated against known IDs)."""
    model = os.getenv("GEMINI_IMAGE_MODEL", "").strip() or config.GEMINI_IMAGE_MODEL
    if model and model in _GEMINI_MODEL_FALLBACKS:
        return model
    if model:  # custom model configured by the user — honor it
        return model
    return DEFAULT_GEMINI_IMAGE_MODEL


def get_gemini_status_details() -> Dict[str, Any]:
    """Status information for the dashboard settings panel."""
    key = get_gemini_api_key()
    model = get_gemini_image_model()
    return {
        "ok": True,
        "provider": "google-gemini",
        "provider_label": "Google Gemini (Image)",
        "badge": "free-tier",
        "has_key": bool(key),
        "configured": bool(key),
        "is_active": bool(key),
        "status": "Active" if key else "Needs API Key",
        "model": model,
        "endpoint": f"{_GEMINI_BASE_URL}/models/{model}:generateContent",
        "message": (
            "Gemini image generation active."
            if key
            else "Set GEMINI_API_KEY (free at aistudio.google.com/apikey) to enable Gemini hero image generation."
        ),
    }


def test_gemini_image_generation(api_key: Optional[str] = None, model: Optional[str] = None) -> Dict[str, Any]:
    """Diagnostic probe: generates a tiny test image and reports engine health."""
    if not (api_key or get_gemini_api_key()):
        return {
            "ok": False,
            "engine": "google_gemini",
            "message": "GEMINI_API_KEY not configured. Get a free key at https://aistudio.google.com/apikey",
        }

    result = generate_gemini_image(
        prompt="Minimalist editorial tech illustration: geometric obsidian forms with a single warm vermilion accent, dramatic studio lighting, no text",
        slug="gemini-diagnostic-test",
        model=model,
        api_key=api_key,
    )
    if result.get("image_bytes"):
        return {
            "ok": True,
            "engine": "google_gemini",
            "model": result.get("model"),
            "hero_image_url": result.get("hero_image_url"),
            "hero_image_path": result.get("hero_image_path"),
            "message": f"✓ Gemini image generation working ({result.get('model')})!",
        }
    return {
        "ok": False,
        "engine": "google_gemini",
        "model": result.get("model"),
        "error": result.get("error"),
        "message": f"Gemini image generation failed: {result.get('error')}",
    }


def generate_gemini_image(
    prompt: str,
    slug: str,
    aspect_ratio: str = "16:9",
    model: Optional[str] = None,
    api_key: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates one image via the native Gemini API and saves it to the demo
    website uploads directory.

    Returns {image_bytes, model, hero_image_path, hero_image_url, error}.
    image_bytes is None on failure (caller falls back to the next engine).
    """
    from pipeline.adapters.codex_image import UPLOADS_DIR
    import re as _re
    import time as _time
    import random as _random

    api_key = api_key or get_gemini_api_key()
    if not api_key:
        return {"image_bytes": None, "model": None, "error": "GEMINI_API_KEY not configured"}

    clean_slug = _re.sub(r"[^\w-]", "", (slug or "hero").lower().replace(" ", "-"))[:40] or "hero"
    model = model or get_gemini_image_model()

    # Primary model first, then known-good fallbacks (avoiding duplicates)
    models_to_try = [model] + [m for m in _GEMINI_MODEL_FALLBACKS if m != model]

    url = None
    last_error = None
    image_bytes = None
    used_model = None

    for candidate in models_to_try:
        endpoint = f"{_GEMINI_BASE_URL}/models/{candidate}:generateContent"
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "text": (
                                f"{prompt} Editorial hero illustration, wide 16:9 "
                                f"composition, premium magazine cover quality, no text or "
                                f"typography inside the image."
                            )
                        }
                    ]
                }
            ],
            "generationConfig": {
                "responseModalities": ["IMAGE"],
                "imageConfig": {
                    "aspectRatio": aspect_ratio,
                    "imageSize": "2K",
                },
            },
        }

        try:
            with httpx.Client(timeout=_GEMINI_TIMEOUT_SECONDS) as client:
                res = client.post(
                    endpoint,
                    headers={
                        "x-goog-api-key": api_key,
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )

                if res.status_code != 200:
                    last_error = f"HTTP {res.status_code}: {res.text[:200]}"
                    logger.warning(f"Gemini image request failed for {candidate}: {last_error}")
                    if res.status_code in (400, 403, 404):
                        # Model unavailable/bad key: try the next known model
                        continue
                    # 429/5xx: transient — no point hammering other models, but one
                    # fallback attempt is still cheap. Continue anyway.
                    continue

                data = res.json()
                candidates = data.get("candidates") or []
                for cand in candidates:
                    content = cand.get("content") or {}
                    for part in content.get("parts") or []:
                        inline = part.get("inlineData") or part.get("inline_data")
                        if inline and inline.get("data"):
                            try:
                                image_bytes = base64.b64decode(inline["data"])
                                used_model = candidate
                                mime = inline.get("mimeType") or inline.get("mime_type") or "image/png"
                                ext = "png" if "png" in mime else ("jpg" if "jpeg" in mime or "jpg" in mime else "png")
                                break
                            except Exception as decode_err:
                                last_error = f"base64 decode failed: {decode_err}"
                    if image_bytes:
                        break

                if image_bytes:
                    break

        except Exception as e:
            last_error = str(e)
            logger.warning(f"Gemini image request error for {candidate}: {e}")

    if not image_bytes:
        if not last_error:
            last_error = "No inline image data returned in Gemini response"
        logger.warning(f"Gemini image generation unsuccessful: {last_error}")
        return {"image_bytes": None, "model": used_model, "error": last_error}

    # Save asset
    unique_suffix = f"{int(_time.time()) % 100000}-{_random.randint(100, 999)}"
    file_name = f"{clean_slug}-{unique_suffix}.png"
    output_path = UPLOADS_DIR / file_name
    output_path.write_bytes(image_bytes)

    relative_url = f"/static/uploads/{output_path.name}"
    base_url = os.getenv("PUBLIC_BASE_URL", "").strip() or os.getenv("DEMO_WEBSITE_URL", "").strip() or getattr(config, "PUBLIC_BASE_URL", "http://127.0.0.1:8000")
    public_url = f"{base_url.rstrip('/')}{relative_url}"

    logger.info(f"Gemini hero image saved via {used_model}: {output_path}")

    return {
        "image_bytes": image_bytes,
        "model": used_model,
        "hero_image_path": str(output_path),
        "hero_image_url": relative_url,
        "hero_image_full_url": public_url,
        "error": None,
    }
