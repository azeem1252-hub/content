"""
Brand Voice from Data & Style Profile Engine (Pillar A3.1).

Builds an empirical style profile per website from 10+ approved articles:
- Sentence length (average & median words per sentence)
- Grammatical person distribution (1st, 2nd, 3rd person)
- Banned phrases (AI slop, clichés) and preferred domain terminology
- Formatting habits (bullet frequency, callout blocks, table inclusion, code blocks)
- 3-5 few-shot exemplars retrieved by dense embedding similarity.
- Stored and versioned in SQLite; updating requires human approval.
"""

from __future__ import annotations

import json
import logging
import math
import re
from typing import Any, Dict, List, Optional, Tuple

from storage.db import (
    get_style_profile,
    save_style_profile,
    approve_style_profile,
    get_all_posts,
    get_db_connection,
)
from pipeline.adapters.embedding_client import embed_text, cosine_similarity

logger = logging.getLogger("pipeline.adapters.brand_voice")

# Common AI clichés and hollow filler phrases flagged as banned
DEFAULT_BANNED_PHRASES = [
    "delve", "testament", "tapestry", "pivotal", "game-changer",
    "revolutionize", "unleash", "in today's fast-paced world",
    "landscape", "bustling", "beacon", "nestled", "it is important to remember",
    "let's dive in", "read that again", "let that sink in", "honest truth",
    "stands as a testament", "crucial role", "vital importance", "plethora",
    "seamlessly", "holistic", "dynamic", "synergy", "multifaceted"
]

FIRST_PERSON_PRONOUNS = {"i", "we", "me", "us", "my", "our", "ours", "myself", "ourselves"}
SECOND_PERSON_PRONOUNS = {"you", "your", "yours", "yourself", "yourselves"}
THIRD_PERSON_PRONOUNS = {
    "he", "she", "it", "they", "him", "her", "them", "his", "hers", "its", "their", "theirs", "one"
}


def _split_into_sentences(text: str) -> List[str]:
    """Splits markdown text into plain sentences, avoiding code blocks and tables."""
    # Strip code blocks and tables
    cleaned = re.sub(r"```[\s\S]*?```", "", text)
    cleaned = re.sub(r"\|[^\n]+\|", "", cleaned)
    cleaned = re.sub(r"#+\s+[^\n]+", "", cleaned)
    cleaned = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", cleaned)

    raw_sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", cleaned)
    sentences = []
    for s in raw_sentences:
        s_clean = s.strip()
        words = re.findall(r"\b\w+\b", s_clean)
        if len(words) >= 3:
            sentences.append(s_clean)
    return sentences


def analyze_articles_for_style(articles: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Computes empirical style metrics from a corpus of approved articles:
    - sentence_length_avg & median
    - person_distribution (1st, 2nd, 3rd person)
    - formatting_habits
    - preferred_phrases
    - banned_phrases
    """
    all_sentence_lengths: List[int] = []
    person_counts = {"first_person": 0, "second_person": 0, "third_person": 0}
    total_words = 0
    table_count = 0
    code_block_count = 0
    bullet_list_count = 0
    callout_count = 0
    ngram_counts: Dict[str, int] = {}

    for art in articles:
        content = art.get("content") or art.get("draft") or ""
        if not content:
            continue

        # Formatting counts
        table_count += len(re.findall(r"\|[^\n]+\|[^\n]+\|", content))
        code_block_count += len(re.findall(r"```[a-z]*", content))
        bullet_list_count += len(re.findall(r"^\s*[-*]\s+", content, re.MULTILINE))
        callout_count += len(re.findall(r"^\s*>\s+", content, re.MULTILINE))

        sentences = _split_into_sentences(content)
        for s in sentences:
            words = [w.lower() for w in re.findall(r"\b\w+\b", s)]
            w_len = len(words)
            if w_len > 0:
                all_sentence_lengths.append(w_len)
                total_words += w_len

            # Person counts
            for w in words:
                if w in FIRST_PERSON_PRONOUNS:
                    person_counts["first_person"] += 1
                elif w in SECOND_PERSON_PRONOUNS:
                    person_counts["second_person"] += 1
                elif w in THIRD_PERSON_PRONOUNS:
                    person_counts["third_person"] += 1

            # N-grams (bigrams) for preferred terminology
            for i in range(len(words) - 1):
                w1, w2 = words[i], words[i+1]
                if len(w1) > 3 and len(w2) > 3 and w1 not in DEFAULT_BANNED_PHRASES and w2 not in DEFAULT_BANNED_PHRASES:
                    bigram = f"{w1} {w2}"
                    ngram_counts[bigram] = ngram_counts.get(bigram, 0) + 1

    # Sentence metrics
    if all_sentence_lengths:
        all_sentence_lengths.sort()
        avg_len = round(sum(all_sentence_lengths) / len(all_sentence_lengths), 1)
        med_len = round(all_sentence_lengths[len(all_sentence_lengths) // 2], 1)
    else:
        avg_len = 16.0
        med_len = 15.0

    # Person distribution ratios
    total_pronouns = sum(person_counts.values()) or 1
    person_dist = {
        "first_person": round(person_counts["first_person"] / total_pronouns, 3),
        "second_person": round(person_counts["second_person"] / total_pronouns, 3),
        "third_person": round(person_counts["third_person"] / total_pronouns, 3),
    }

    # Top preferred terminology (high frequency bigrams)
    sorted_ngrams = sorted(ngram_counts.items(), key=lambda x: x[1], reverse=True)
    preferred = [term for term, count in sorted_ngrams[:15] if count >= 3]

    formatting_habits = {
        "bullets_per_1k_words": round((bullet_list_count / max(total_words, 1)) * 1000, 1),
        "uses_tables": table_count > 0,
        "uses_code_blocks": code_block_count > 0,
        "uses_callouts": callout_count > 0,
        "preferred_section_depth": "H2 + H3",
    }

    return {
        "sentence_length_avg": avg_len,
        "sentence_length_median": med_len,
        "person_distribution": person_dist,
        "banned_phrases": DEFAULT_BANNED_PHRASES,
        "preferred_phrases": preferred,
        "formatting_habits": formatting_habits,
        "sample_article_count": len(articles),
    }


def extract_candidate_exemplars(articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Extracts distinctive paragraphs or sections from approved articles as few-shot candidates."""
    candidates = []
    for art in articles:
        content = art.get("content") or art.get("draft") or ""
        title = art.get("title", "")
        # Find H2 sections
        sections = re.split(r"(?=^##\s+)", content, flags=re.MULTILINE)
        for sec in sections:
            sec_clean = sec.strip()
            words = len(re.findall(r"\b\w+\b", sec_clean))
            if 80 <= words <= 250:
                lines = sec_clean.split("\n", 1)
                heading = lines[0].replace("##", "").strip() if lines[0].startswith("##") else "Section Excerpt"
                body = lines[1].strip() if len(lines) > 1 else lines[0]
                candidates.append({
                    "title": title,
                    "heading": heading,
                    "text": body[:600],
                })
    return candidates[:30]


def retrieve_few_shot_exemplars(
    topic: str,
    website_id: str,
    limit: int = 4,
) -> List[Dict[str, Any]]:
    """
    Retrieves 3-5 few-shot exemplars ranked by dense embedding similarity
    to the target topic from the site's approved articles.
    """
    profile = get_style_profile(website_id)
    cached_exemplars = profile.get("few_shot_exemplars", []) if profile else []

    if not cached_exemplars:
        articles = get_all_posts(limit=25)
        cached_exemplars = extract_candidate_exemplars(articles)

    if not cached_exemplars:
        return []

    # Compute similarity to target topic
    try:
        topic_vec = embed_text(topic)
        scored = []
        for ex in cached_exemplars:
            text = f"{ex.get('heading', '')}: {ex.get('text', '')}"
            ex_vec = embed_text(text)
            sim = cosine_similarity(topic_vec, ex_vec)
            scored.append((sim, ex))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [item[1] for item in scored[:limit]]
    except Exception as e:
        logger.warning(f"Embedding similarity failed for exemplars ({e}), using default slice")
        return cached_exemplars[:limit]


def build_or_update_site_style_profile(
    website_id: str,
    auto_approve_if_first: bool = False,
) -> Dict[str, Any]:
    """
    Scans the site's approved articles (10+ required for optimal calibration),
    computes the empirical style profile, and persists it.
    If an existing profile is present, updates increment version and set status to
    'pending_review' so human approval is required.
    """
    # Fetch posts for website from database
    posts: List[Dict[str, Any]] = []
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM posts ORDER BY published_at DESC LIMIT 50")
        posts = [dict(r) for r in cursor.fetchall()]

    existing = get_style_profile(website_id)
    is_first = existing is None
    status = "approved" if (is_first and auto_approve_if_first) else "pending_review"

    metrics = analyze_articles_for_style(posts)
    exemplars = extract_candidate_exemplars(posts)

    saved = save_style_profile(
        website_id=website_id,
        sentence_length_avg=metrics["sentence_length_avg"],
        sentence_length_median=metrics["sentence_length_median"],
        person_distribution=metrics["person_distribution"],
        banned_phrases=metrics["banned_phrases"],
        preferred_phrases=metrics["preferred_phrases"],
        formatting_habits=metrics["formatting_habits"],
        few_shot_exemplars=exemplars,
        status=status,
        sample_article_count=len(posts),
    )
    logger.info(
        f"Style profile generated for website '{website_id}' (version: {saved.get('version')}, "
        f"status: {saved.get('status')}, samples: {len(posts)})"
    )
    return saved


def get_active_style_profile(
    website_id: Optional[str] = None,
    topic: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Retrieves the active approved style profile for a website.
    Falls back to sensible editorial defaults if no profile exists yet.
    """
    wid = website_id or "default"
    profile = get_style_profile(wid)
    if not profile:
        profile = build_or_update_site_style_profile(wid, auto_approve_if_first=True)

    # Attach topic-relevant few-shot exemplars
    if topic:
        exemplars = retrieve_few_shot_exemplars(topic, wid, limit=4)
        profile["few_shot_exemplars"] = exemplars

    return profile
