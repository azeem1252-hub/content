"""
Prompt Template Manager with Jinja2 & Version Tracking (Pillar A3.1).

Stores and versions prompt templates as files and database records.
Renders prompts reproducibly and attaches prompt version strings to run telemetry.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import jinja2

from storage.db import get_prompt_template, save_prompt_template, list_prompt_templates

logger = logging.getLogger("pipeline.adapters.prompt_manager")

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"

# Initialize Jinja2 environment with strict undefined checking for safety
_JINJA_ENV: Optional[jinja2.Environment] = None


def _get_jinja_env() -> jinja2.Environment:
    global _JINJA_ENV
    if _JINJA_ENV is None:
        loader = jinja2.FileSystemLoader(str(PROMPTS_DIR))
        _JINJA_ENV = jinja2.Environment(
            loader=loader,
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
    return _JINJA_ENV


def render_prompt(
    template_name: str,
    context: Dict[str, Any],
    version: str = "v1.0.0",
) -> Tuple[str, str]:
    """
    Renders a prompt template using Jinja2.
    Checks file system first, falls back to database prompt_templates table.
    Returns:
        (rendered_prompt_text, prompt_version_identifier)
    """
    # 1. Try file system
    major_ver = version.split(".")[0] if "." in version else version
    file_candidates = [
        f"{template_name}_{version}.jinja2",
        f"{template_name}_{major_ver}.jinja2",
        f"{template_name}.jinja2",
    ]
    env = _get_jinja_env()
    for filename in file_candidates:
        file_path = PROMPTS_DIR / filename
        if file_path.exists():
            try:
                tmpl = env.get_template(filename)
                rendered = tmpl.render(**context)
                # Sync to DB if not present
                _sync_template_to_db(template_name, version, file_path.read_text(encoding="utf-8"))
                return rendered.strip(), version
            except Exception as e:
                logger.error(f"Error rendering file template {filename}: {e}", exc_info=True)
                break

    # 2. Fall back to DB
    db_tmpl = get_prompt_template(template_name, version)
    if db_tmpl and db_tmpl.get("template_content"):
        try:
            content = db_tmpl["template_content"]
            tmpl = jinja2.Template(content, trim_blocks=True, lstrip_blocks=True)
            rendered = tmpl.render(**context)
            return rendered.strip(), db_tmpl.get("version", version)
        except Exception as e:
            logger.error(f"Error rendering DB template {template_name} ({version}): {e}", exc_info=True)

    raise ValueError(f"Prompt template '{template_name}' (version: {version}) could not be resolved.")


def _sync_template_to_db(name: str, version: str, content: str) -> None:
    """Best-effort persistence of prompt file into DB for centralized auditing."""
    try:
        existing = get_prompt_template(name, version)
        if not existing:
            save_prompt_template(
                name=name,
                version=version,
                template_content=content,
                description=f"Auto-synced from pipeline/prompts/{name}_{version}.jinja2",
            )
    except Exception as e:
        logger.debug(f"Could not auto-sync template to DB: {e}")


def get_available_templates() -> Dict[str, Any]:
    """Lists all available prompt templates and versions."""
    return {"templates": list_prompt_templates()}
