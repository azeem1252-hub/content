"""
Knowledge Graph & GraphRAG Engine (Pillar I: Factual Grounding & Machine Readability).

Builds an explicit, persistent entity/relationship graph for each website and
exposes multi-hop retrieval over it. Where flat vector search loses the
relationships between entities, a graph keeps them: nodes are entities
(organization, article, concept, product, person), edges are typed relations
(publishes, mentions, related_to, authored_by).

Capabilities:
  - build_knowledge_graph(): deterministic entity extraction from published
    inventory, with optional LLM enrichment, persisted to SQLite.
  - multi_hop_query(): BFS traversal answering relational questions
    (e.g. "which entities co-occur with LangGraph?") across N hops.
  - graph_rag_context(): retrieves a relational context block for a query,
    used to ground generation and verification.
  - knowledge_graph_to_jsonld(): exports the graph as Schema.org JSON-LD so the
    relationships are machine-readable by AI crawlers.
  - entity_consistency_audit(): flags duplicate/variant entity names that
    fragment the graph (a direct machine-readability finding).
"""

from __future__ import annotations

import logging
import re
from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple

from storage.db import (
    get_all_posts,
    get_kg_nodes,
    get_kg_edges,
    upsert_kg_nodes,
    upsert_kg_edges,
    clear_knowledge_graph,
)
from pipeline.adapters.embedding_client import embed_text, cosine_similarity

logger = logging.getLogger("pipeline.adapters.knowledge_graph")

GENERIC_ENTITY_WORDS = {
    "the", "and", "for", "with", "how", "what", "why", "when", "where", "guide",
    "best", "top", "vs", "versus", "complete", "ultimate", "2024", "2025", "2026",
    "introduction", "overview", "tips", "tools", "tool", "part", "using", "your",
}

_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9+.#-]*")


def entity_id(name: str) -> str:
    """Stable, URL-safe node identifier for an entity name."""
    slug = re.sub(r"[^a-z0-9]+", "-", (name or "").lower()).strip("-")
    return f"ent:{slug}" if slug else ""


def _entity_name_from_id(node_id: str) -> str:
    return node_id.split(":", 1)[1].replace("-", " ").strip()


def _is_meaningful(name: str) -> bool:
    clean = (name or "").strip()
    if len(clean) < 3 or len(clean) > 60:
        return False
    if clean.lower() in GENERIC_ENTITY_WORDS:
        return False
    return any(c.isalpha() for c in clean)


def extract_entities(text: str, limit: int = 24) -> List[str]:
    """Deterministic entity candidate extraction.

    Captures capitalized multi-word phrases, hyphenated product tokens, and
    acronyms from prose. Kept dependency-free so graph building works offline.
    """
    if not text:
        return []
    found: List[str] = []
    seen: Set[str] = set()

    def push(candidate: str) -> None:
        cand = candidate.strip(" .,;:()[]\"'—-")
        if not _is_meaningful(cand):
            return
        key = cand.lower()
        if key in seen:
            return
        seen.add(key)
        found.append(cand)

    # Capitalized runs (e.g. "Directed Acyclic Graph", "Cloudflare Workers AI")
    for match in re.findall(r"\b(?:[A-Z][A-Za-z0-9+.#-]+(?:\s+[A-Z][A-Za-z0-9+.#-]+){0,3})", text):
        # Drop sentence-initial single words that are just ordinary prose openers
        if " " not in match and match.lower() in GENERIC_ENTITY_WORDS:
            continue
        push(match)
        if len(found) >= limit:
            return found

    # Acronyms and versioned product tokens (RAG, MCP, GPT-4o, flux-1-schnell)
    for match in re.findall(r"\b(?:[A-Z]{3,}|[a-z]+-\d+(?:[.-][a-z0-9]+)+)\b", text):
        push(match)
        if len(found) >= limit:
            return found

    return found


def _post_entities(post: Dict[str, Any]) -> List[str]:
    entities: List[str] = []
    tags = post.get("tags")
    if isinstance(tags, str):
        entities.extend(t.strip() for t in tags.split(",") if t.strip())
    elif isinstance(tags, list):
        entities.extend(str(t).strip() for t in tags if str(t).strip())
    entities.extend(extract_entities(post.get("title") or "", limit=8))
    return entities


def build_knowledge_graph(
    website_id: Optional[str],
    site_name: str = "Editorial Publication",
    site_url: str = "",
    posts: Optional[List[Dict[str, Any]]] = None,
    use_llm: bool = False,
    max_posts: int = 200,
) -> Dict[str, Any]:
    """Rebuilds the entity graph for a website from its published inventory."""
    if posts is None:
        posts = get_all_posts(limit=max_posts, status=None)

    if use_llm:
        extracted = _llm_entities_for_posts(posts)
    else:
        extracted = {}

    clear_knowledge_graph(website_id)

    org_id = f"org:{website_id or 'default'}"
    nodes: List[Dict[str, Any]] = [{
        "id": org_id,
        "name": site_name,
        "node_type": "Organization",
        "properties": {"url": site_url} if site_url else {},
    }]
    edges: List[Dict[str, Any]] = []
    entity_cooccurrence: Dict[Tuple[str, str], int] = {}
    entity_refs: Dict[str, int] = {}

    for post in posts:
        slug = post.get("slug")
        if not slug:
            continue
        post_node = f"post:{slug}"
        nodes.append({
            "id": post_node,
            "name": post.get("title") or slug,
            "node_type": "Article",
            "properties": {
                "url": f"{site_url.rstrip('/')}/posts/{slug}" if site_url else None,
                "published_at": post.get("published_at"),
            },
        })
        edges.append({
            "id": f"{org_id}->publishes->{post_node}",
            "source_id": org_id,
            "target_id": post_node,
            "relation": "publishes",
        })

        names = extracted.get(slug) if extracted else None
        if not names:
            names = _post_entities(post)

        local_ids: List[str] = []
        for name in names:
            nid = entity_id(name)
            if not nid:
                continue
            if nid not in entity_refs:
                nodes.append({
                    "id": nid,
                    "name": name.strip(),
                    "node_type": "Thing",
                    "properties": {},
                })
                entity_refs[nid] = 0
            entity_refs[nid] += 1
            local_ids.append(nid)
            edges.append({
                "id": f"{post_node}->mentions->{nid}",
                "source_id": post_node,
                "target_id": nid,
                "relation": "mentions",
            })

        # Co-occurrence edges link entities that appear in the same article
        unique_local = sorted(set(local_ids))
        for i in range(len(unique_local)):
            for j in range(i + 1, len(unique_local)):
                pair = (unique_local[i], unique_local[j])
                entity_cooccurrence[pair] = entity_cooccurrence.get(pair, 0) + 1

    for (a, b), weight in entity_cooccurrence.items():
        edges.append({
            "id": f"{a}->related_to->{b}",
            "source_id": a,
            "target_id": b,
            "relation": "related_to",
            "weight": float(weight),
        })

    upsert_kg_nodes(website_id, nodes)
    upsert_kg_edges(website_id, edges)

    top_entities = sorted(
        [{"id": nid, "name": _entity_name_from_id(nid), "mentions": c} for nid, c in entity_refs.items()],
        key=lambda e: e["mentions"],
        reverse=True,
    )[:25]

    result = {
        "website_id": website_id,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "entity_count": len(entity_refs),
        "article_count": sum(1 for n in nodes if n["node_type"] == "Article"),
        "top_entities": top_entities,
        "used_llm": bool(extracted),
    }
    logger.info(
        f"Knowledge graph rebuilt for '{site_name}': {result['node_count']} nodes, "
        f"{result['edge_count']} edges, {result['entity_count']} entities."
    )
    return result


def _llm_entities_for_posts(posts: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    """Optional LLM enrichment: extract canonical entities per article.

    Returns an empty mapping on any failure so callers silently fall back to the
    deterministic extractor.
    """
    import json

    from pipeline.llm_client import call_llm
    from pipeline.utils import extract_json_block

    out: Dict[str, List[str]] = {}
    for post in posts[:40]:
        slug = post.get("slug")
        if not slug:
            continue
        content = (post.get("content") or "")[:4000]
        if not content:
            continue
        prompt = (
            "Extract the canonical named entities from this article: organizations, "
            "products, technologies, people, standards, and concepts. Exclude generic "
            "nouns and stopwords. Return strict JSON.\n\n"
            f"TITLE: {post.get('title')}\nCONTENT:\n{content}\n\n"
            'Return: {"entities": ["..."]}'
        )
        try:
            raw = call_llm(prompt, temperature=0.2)
            parsed = extract_json_block(raw) or {}
            ents = parsed.get("entities") or []
            out[slug] = [str(e) for e in ents if _is_meaningful(str(e))][:24]
        except Exception as e:  # noqa: BLE001
            logger.debug(f"LLM entity extraction skipped for '{slug}': {e}")
            break
    if out:
        logger.info(f"LLM entity extraction enriched {len(out)} articles.")
    return out


def _adjacency(edges: List[Dict[str, Any]]) -> Dict[str, List[Tuple[str, str, float]]]:
    adj: Dict[str, List[Tuple[str, str, float]]] = {}
    for e in edges:
        src, dst = e.get("source_id"), e.get("target_id")
        rel = e.get("relation") or "related_to"
        w = float(e.get("weight") or 1.0)
        adj.setdefault(src, []).append((dst, rel, w))
        adj.setdefault(dst, []).append((src, rel, w))
    return adj


def multi_hop_query(
    website_id: Optional[str],
    start_entity: str,
    max_hops: int = 2,
    limit: int = 40,
) -> Dict[str, Any]:
    """Breadth-first graph traversal from an entity, returning typed paths."""
    nodes = {n["id"]: n for n in get_kg_nodes(website_id)}
    edges = get_kg_edges(website_id)
    adj = _adjacency(edges)

    start_id = start_entity if start_entity.startswith("ent:") else entity_id(start_entity)
    if start_id not in nodes:
        # Allow case-insensitive name match
        for nid, node in nodes.items():
            if (node.get("name") or "").lower() == (start_entity or "").lower():
                start_id = nid
                break

    if start_id not in nodes:
        return {"start": start_entity, "found": False, "paths": [], "visited": []}

    visited: Set[str] = {start_id}
    queue: deque = deque([(start_id, 0, [])])
    paths: List[Dict[str, Any]] = []

    while queue and len(paths) < limit:
        current, depth, trail = queue.popleft()
        if depth >= max_hops:
            continue
        for neighbor, relation, weight in adj.get(current, []):
            if neighbor in visited:
                continue
            visited.add(neighbor)
            step = {"from": current, "relation": relation, "to": neighbor, "weight": weight}
            new_trail = trail + [step]
            node = nodes.get(neighbor, {})
            paths.append({
                "depth": depth + 1,
                "entity": node.get("name") or _entity_name_from_id(neighbor),
                "node_type": node.get("node_type"),
                "path": new_trail,
            })
            queue.append((neighbor, depth + 1, new_trail))

    return {
        "start": nodes.get(start_id, {}).get("name") or start_entity,
        "start_id": start_id,
        "found": True,
        "paths": paths,
        "visited": sorted(visited),
    }


def graph_rag_context(
    website_id: Optional[str],
    query: str,
    top_k: int = 4,
    max_hops: int = 2,
) -> str:
    """Returns a relational context block for LLM grounding, or '' when empty.

    Seeds are chosen by embedding similarity between the query and entity names,
    then expanded over the graph so the model receives relationship facts it
    could not infer from flat text.
    """
    nodes = [n for n in get_kg_nodes(website_id) if n.get("node_type") == "Thing"]
    if not nodes or not (query or "").strip():
        return ""
    try:
        q_vec = embed_text(query)
        scored: List[Tuple[float, Dict[str, Any]]] = []
        for node in nodes:
            name = node.get("name") or _entity_name_from_id(node["id"])
            if not name:
                continue
            scored.append((cosine_similarity(q_vec, embed_text(name)), node))
        scored.sort(key=lambda t: t[0], reverse=True)
        seeds = [n for score, n in scored[:top_k] if score > 0.05]
    except Exception as e:  # noqa: BLE001
        logger.warning(f"GraphRAG seeding failed: {e}")
        seeds = nodes[:top_k]

    if not seeds:
        return ""

    lines: List[str] = []
    seen: Set[str] = set()
    for seed in seeds:
        traversal = multi_hop_query(website_id, seed["id"], max_hops=max_hops, limit=12)
        for path in traversal.get("paths", []):
            entity = path.get("entity")
            if not entity or entity in seen:
                continue
            seen.add(entity)
            hops = path.get("path") or []
            if hops:
                chain = " -> ".join(
                    f"{_entity_name_from_id(s['from']) if s['from'].startswith('ent:') else s['from']} "
                    f"-[{s['relation']}]-> {_entity_name_from_id(s['to']) if s['to'].startswith('ent:') else s['to']}"
                    for s in hops
                )
                lines.append(f"- {chain}")
    if not lines:
        return ""
    return "KNOWLEDGE GRAPH RELATIONSHIPS (verified entity links):\n" + "\n".join(lines[:20])


def entity_consistency_audit(website_id: Optional[str]) -> List[Dict[str, Any]]:
    """Flags entity-name variants that fragment the graph.

    Variants are detected when two distinct node ids share a normalized token set
    (e.g. "Cloudflare" vs "Cloudflare Workers AI" is fine, but "LLM" vs "L L M"
    or "Open AI" vs "OpenAI" is not).
    """
    nodes = get_kg_nodes(website_id)
    things = [n for n in nodes if n.get("node_type") == "Thing"]
    normalized: Dict[str, List[Dict[str, Any]]] = {}
    for node in things:
        name = (node.get("name") or "").strip()
        key = re.sub(r"[^a-z0-9]", "", name.lower())
        if key:
            normalized.setdefault(key, []).append(node)

    findings: List[Dict[str, Any]] = []
    for key, group in normalized.items():
        if len(group) > 1:
            names = sorted({(n.get("name") or "").strip() for n in group})
            if len(names) > 1:
                findings.append({
                    "category": "entity_consistency",
                    "severity": "medium",
                    "detail": f"Duplicate entity variants detected: {', '.join(names)}. Consolidate to one canonical name.",
                    "entities": names,
                })
    return findings


def knowledge_graph_to_jsonld(website_id: Optional[str], site_name: str, site_url: str) -> Dict[str, Any]:
    """Exports the graph as a Schema.org JSON-LD document."""
    nodes = get_kg_nodes(website_id)
    edges = get_kg_edges(website_id)
    by_id = {n["id"]: n for n in nodes}

    graph: List[Dict[str, Any]] = []
    org_id = f"org:{website_id or 'default'}"
    org = by_id.get(org_id)
    if org:
        graph.append({
            "@type": "Organization",
            "@id": site_url or org_id,
            "name": org.get("name") or site_name,
        })

    for node in nodes:
        if node.get("node_type") != "Thing":
            continue
        graph.append({
            "@type": "DefinedTerm",
            "@id": f"{site_url.rstrip('/')}/#entity-{node['id'].split(':', 1)[1]}" if site_url else node["id"],
            "name": node.get("name"),
            "termCode": node["id"],
        })

    relations = []
    for e in edges:
        if e.get("relation") != "related_to":
            continue
        src, dst = by_id.get(e.get("source_id")), by_id.get(e.get("target_id"))
        if not src or not dst:
            continue
        relations.append({
            "@type": "PropertyValue",
            "propertyID": "relatedTo",
            "name": src.get("name"),
            "value": {"@type": "DefinedTerm", "name": dst.get("name")},
        })

    return {
        "@context": "https://schema.org",
        "@type": "KnowledgeGraph",
        "name": f"{site_name} Entity Graph",
        "url": site_url,
        "graph": graph,
        "relations": relations,
    }


def summarize_graph(website_id: Optional[str]) -> Dict[str, Any]:
    """Aggregate stats for the Studio UI."""
    nodes = get_kg_nodes(website_id)
    edges = get_kg_edges(website_id)
    by_type: Dict[str, int] = {}
    for n in nodes:
        by_type[n.get("node_type") or "Unknown"] = by_type.get(n.get("node_type") or "Unknown", 0) + 1
    by_relation: Dict[str, int] = {}
    for e in edges:
        by_relation[e.get("relation") or "related_to"] = by_relation.get(e.get("relation") or "related_to", 0) + 1
    return {
        "node_count": len(nodes),
        "edge_count": len(edges),
        "nodes_by_type": by_type,
        "edges_by_relation": by_relation,
        "entity_consistency_findings": entity_consistency_audit(website_id),
    }
