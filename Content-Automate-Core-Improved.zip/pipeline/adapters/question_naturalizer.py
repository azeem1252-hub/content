"""
Question Naturalizer & Intelligent Interrogative Synthesis Engine.

Eliminates robotic prefix stacking across all evidence brief generation,
PAA discovery, AEO engine, section drafting, and FAQ modules:
- Prevents errors like "What is the best approach for what is the difference between A and B?"
- Prevents errors like "How does what is the difference between A and B work in practice?"
- Unwraps legacy double interrogatives from databases and incoming feeds.
- Synthesizes grammatically flawless, authoritative, native-sounding PAA questions
  for comparisons, procedural queries, causal queries, and architectural concepts.
"""

from __future__ import annotations

import re
from typing import List, Optional, Tuple


def _to_gerund(verb: str) -> str:
    """Converts a base verb to its gerund (-ing) form."""
    v = verb.lower().strip()
    if not v:
        return ""
    if v.endswith("e") and not v.endswith("ee"):
        return v[:-1] + "ing"
    if v in ("run", "stop", "get", "set", "hit", "fit", "cut", "drop", "step"):
        return v + v[-1] + "ing"
    return v + "ing"


def clean_double_question(text: str) -> str:
    """
    Unwraps and resolves nested/stacked interrogatives.
    E.g.:
    - 'What is the best approach for what is the difference between A and B?' ->
      'What is the difference between A and B?'
    - 'How does what is the difference between A and B work in practice?' ->
      'What is the difference between A and B?'
    - 'What are common pitfalls when implementing what is the difference between A and B?' ->
      'What is the difference between A and B?'
    - 'Resolving Common Bottlenecks: What is the best approach for X' ->
      'Resolving Common Bottlenecks: X'
    """
    if not text:
        return ""

    s = text.strip()

    # Repeatedly unwrap while double wrappers are detected
    max_passes = 3
    for _ in range(max_passes):
        unwrapped = _unwrap_single_layer(s)
        if unwrapped == s:
            break
        s = unwrapped

    # Ensure single question mark if it was a question
    if "?" in s:
        s = s.rstrip("?. ") + "?"
    return s


def _unwrap_single_layer(s: str) -> str:
    nested_patterns = [
        # "What is the best approach for <interrogative> ..."
        r"^(?:What\s+is\s+(?:the\s+)?(?:best\s+approach\s+for|recommended\s+(?:architecture|pattern)\s+for|best\s+way\s+to\s+handle)\s+)(what|how|why|which|when|where|can|should|is|are)\b(.*)$",
        # "How does <interrogative> ... work in practice?"
        r"^How\s+does\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\s+work(?:\s+in\s+practice)?\??)?$",
        # "What are common pitfalls when implementing <interrogative> ...?"
        r"^What\s+are\s+common\s+pitfalls\s+when\s+implementing\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\??)$",
        # "How to optimize performance for <interrogative> ...?"
        r"^How\s+to\s+optimize\s+performance\s+for\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\??)$",
        # "How do systems implement <interrogative> ... efficiently?"
        r"^How\s+do\s+systems\s+implement\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\s+efficiently\??)?$",
        # "What are the major performance trade-offs of <interrogative> ...?"
        r"^What\s+are\s+the\s+major\s+performance\s+trade-offs\s+of\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\??)$",
        # "Why do traditional methods fail with <interrogative> ... at scale?"
        r"^Why\s+do\s+traditional\s+methods\s+fail\s+with\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\s+at\s+scale\??)?$",
        # "How to benchmark <interrogative> ... against alternatives?"
        r"^How\s+to\s+benchmark\s+(what|how|why|which|when|where|can|should|is|are)\b(.*?)(\s+against\s+alternatives\??)?$",
        # General double interrogative: "How does what is ...", "What is how to ..."
        r"^(?:What\s+is|How\s+does|How\s+do|Why\s+does|Why\s+do)\s+(what|how|why|which|when|where|can|should|is|are)\b(.*)$",
    ]

    for pat in nested_patterns:
        m = re.match(pat, s, re.IGNORECASE)
        if m:
            groups = m.groups()
            interrogative = groups[0]
            rest = groups[1] if len(groups) > 1 else ""
            # Strip trailing artifacts captured from outer wrapper
            rest_clean = re.sub(r"\s+work(?:\s+in\s+practice)?\??$", "", rest, flags=re.I)
            rest_clean = re.sub(r"\s+efficiently\??$", "", rest_clean, flags=re.I)
            rest_clean = re.sub(r"\s+at\s+scale\??$", "", rest_clean, flags=re.I)
            rest_clean = re.sub(r"\s+against\s+alternatives\??$", "", rest_clean, flags=re.I)
            res = f"{interrogative}{rest_clean}".strip().rstrip("?. ") + "?"
            return res[0].upper() + res[1:]

    return s


def extract_comparison_entities(topic: str) -> Optional[Tuple[str, str]]:
    """
    If topic represents a comparison, extracts (entity_a, entity_b).
    Handles:
    - 'what is the difference between ragdoll and kinematics in games' -> ('ragdoll', 'kinematics in games')
    - 'difference between ragdoll and kinematics' -> ('ragdoll', 'kinematics')
    - 'ragdoll vs kinematics' -> ('ragdoll', 'kinematics')
    - 'which is better ragdoll or kinematics in games' -> ('ragdoll', 'kinematics in games')
    """
    clean = clean_double_question(topic).strip()
    clean = re.sub(r"^(?:what\s+is\s+(?:the\s+)?|explain\s+(?:the\s+)?|understanding\s+(?:the\s+)?)", "", clean, flags=re.I)
    clean = clean.rstrip("?. ").strip()

    # Pattern: "difference between A and B"
    m = re.match(r"^difference\s+between\s+(.+?)\s+and\s+(.+)$", clean, re.I)
    if m:
        return (m.group(1).strip(), m.group(2).strip())

    # Pattern: "A vs B" or "A versus B"
    m = re.match(r"^(.+?)\s+(?:vs\.?|versus)\s+(.+)$", clean, re.I)
    if m:
        return (m.group(1).strip(), m.group(2).strip())

    # Pattern: "which is better A or B"
    m = re.match(r"^which\s+is\s+better\s+(.+?)\s+or\s+(.+)$", clean, re.I)
    if m:
        return (m.group(1).strip(), m.group(2).strip())

    # Pattern: "comparing A and B" / "compare A to B"
    m = re.match(r"^compar(?:ing|e)\s+(.+?)\s+(?:and|to|with)\s+(.+)$", clean, re.I)
    if m:
        return (m.group(1).strip(), m.group(2).strip())

    return None


def clean_topic_phrase(topic: str) -> str:
    """
    Extracts a clean subject concept / noun phrase from any query.
    E.g.:
    - 'what is the difference between ragdoll and kinematics in games' -> 'ragdoll vs kinematics in games'
    - 'how to prevent tunneling through thin polygon walls in game physics' -> 'preventing tunneling through thin polygon walls in game physics'
    - 'how do physics engines handle high-velocity bullet collision' -> 'high-velocity bullet collision handling'
    - 'why is continuous collision detection computationally expensive' -> 'continuous collision detection computational expense'
    """
    s = clean_double_question(topic).strip().rstrip("?. ")

    comp = extract_comparison_entities(s)
    if comp:
        return f"{comp[0]} vs {comp[1]}"

    # Procedural queries: "how to prevent X" -> "preventing X"
    m_how_to = re.match(r"^how\s+to\s+([a-z]+)\s+(.+)$", s, re.I)
    if m_how_to:
        verb = m_how_to.group(1).lower()
        rest = m_how_to.group(2).strip()
        return f"{_to_gerund(verb)} {rest}"

    # Causal / descriptive "why is X [adj]"
    m_why = re.match(r"^why\s+(?:is|are)\s+(.+?)\s+(computationally\s+\w+|\w+ly\s+\w+|expensive|slow|inefficient|difficult|hard)$", s, re.I)
    if m_why:
        return f"{m_why.group(1).strip()} {m_why.group(2).strip()}"

    # Specific engines / systems stripping
    prefixes_to_strip = [
        r"^what\s+is\s+(?:the\s+)?",
        r"^what\s+are\s+(?:the\s+)?",
        r"^how\s+do\s+(?:physics\s+engines|game\s+engines|systems)\s+(?:handle|manage|resolve)\s+",
        r"^how\s+do\s+(?:systems\s+|physics\s+engines\s+)?",
        r"^how\s+does\s+",
        r"^why\s+is\s+(?:it\s+)?",
        r"^why\s+do\s+",
        r"^why\s+does\s+",
        r"^can\s+you\s+",
        r"^is\s+it\s+possible\s+to\s+",
        r"^guide\s+to\s+",
        r"^the\s+complete\s+guide\s+to\s+",
        r"^verdict\s+on\s+",
        r"^understanding\s+",
    ]
    for p in prefixes_to_strip:
        s = re.sub(p, "", s, flags=re.I).strip()

    # If the remaining string starts with a base verb, gerundize it for a natural subject phrase
    verb_m = re.match(r"^([a-z]+)\s+(.+)$", s, re.I)
    if verb_m:
        first_word = verb_m.group(1).lower()
        base_verbs = {
            "handle": "handling", "prevent": "preventing", "optimize": "optimizing",
            "benchmark": "benchmarking", "implement": "implementing", "build": "building",
            "calculate": "calculating", "resolve": "resolving", "simulate": "simulating",
            "detect": "detecting", "render": "rendering", "avoid": "avoiding"
        }
        if first_word in base_verbs:
            s = f"{base_verbs[first_word]} {verb_m.group(2)}"

    return s


def naturalize_question(text: str) -> str:
    """
    Takes any keyword, query, or phrase and formats it into a single,
    grammatically correct, fluent question.
    Never produces stacked prefixes.
    """
    if not text:
        return "What is the recommended architecture and best practice?"

    cleaned = clean_double_question(text.strip())

    # Check "how to [verb] [rest]"
    m = re.match(r"^how\s+to\s+(.+)$", cleaned, re.I)
    if m:
        rest = m.group(1).strip().rstrip("?. ")
        return f"How to {rest}?"

    # If already a question, ensure single question mark and sentence case
    q_words = ("what", "how", "why", "when", "which", "where", "can", "should", "is", "are", "do", "does", "will")
    words = cleaned.split()
    first_word = words[0].lower() if words else ""

    if first_word in q_words or cleaned.endswith("?"):
        q = cleaned.rstrip("?. ") + "?"
        return q[0].upper() + q[1:]

    # Check comparison
    comp = extract_comparison_entities(cleaned)
    if comp:
        return f"What is the difference between {comp[0]} and {comp[1]}?"

    # Procedural gerund phrase "preventing tunneling..." -> "How do you prevent..."
    gerund_m = re.match(r"^([a-z]+ing)\s+(.+)$", cleaned, re.I)
    if gerund_m:
        gerund = gerund_m.group(1).lower()
        rest = gerund_m.group(2).strip().rstrip("?. ")
        # Simple degerrundize
        if gerund == "preventing":
            base = "prevent"
        elif gerund == "handling":
            base = "handle"
        elif gerund == "optimizing":
            base = "optimize"
        elif gerund == "benchmarking":
            base = "benchmark"
        elif gerund == "implementing":
            base = "implement"
        else:
            base = gerund[:-3]
        return f"How do you {base} {rest}?"

    # Default noun phrase / concept -> "What is {subj}?"
    subj = cleaned.rstrip("?. ").strip()
    return f"What is {subj}?"


def generate_natural_paa_questions(topic: str, context: Optional[str] = None, count: int = 5) -> List[str]:
    """
    Synthesizes intelligent, native-sounding PAA questions for any topic.
    Categorizes the intent (comparison, procedural, causal, architectural concept)
    to yield realistic, highly relevant questions.
    """
    unwrapped = clean_double_question(topic.strip())
    topic_clean = unwrapped.rstrip("?. ").strip()

    # 1. Comparison Intent (e.g. "what is the difference between ragdoll and kinematics in games")
    comp = extract_comparison_entities(topic_clean)
    if comp:
        ent_a, ent_b = comp
        scope = "" if any(term in f"{ent_a} {ent_b}".lower() for term in ("game", "in games", "development", "engine", "production", "systems")) else " in production"
        q1 = f"What is the primary difference between {ent_a} and {ent_b}?"
        q2 = f"When should you use {ent_a} versus {ent_b}{scope}?"
        q3 = f"What are the performance trade-offs between {ent_a} and {ent_b}?"
        q4 = f"Can {ent_a} and {ent_b} be blended together smoothly?"
        q5 = f"What are common pitfalls when implementing {ent_a} and {ent_b}?"
        return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]

    # 2. Procedural Action ("How to prevent/optimize/implement X")
    m_proc = re.match(r"^how\s+to\s+([a-z]+)\s+(.+)$", topic_clean, re.I)
    if m_proc:
        verb = m_proc.group(1).lower()
        rest = m_proc.group(2).strip()
        gerund = _to_gerund(verb)
        q1 = f"How do you {verb} {rest} effectively?"
        q2 = f"Why do traditional implementations fail when {gerund} {rest}?"
        q3 = f"What is the performance overhead of {gerund} {rest}?"
        q4 = f"What are common mistakes and pitfalls when {gerund} {rest}?"
        q5 = f"What architectural patterns are recommended for {gerund} {rest} in 2026?"
        return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]

    # 3. Causal Inquiry ("Why is / Why do")
    m_why = re.match(r"^why\s+(?:is|do|does)\s+(.+)$", topic_clean, re.I)
    if m_why:
        subject = m_why.group(1).strip()
        q1 = unwrapped if unwrapped.endswith("?") else f"{unwrapped}?"
        q1 = q1[0].upper() + q1[1:]

        m_adj = re.match(r"^(.+?)\s+(computationally\s+\w+|\w+ly\s+\w+|expensive|slow|inefficient|difficult)$", subject, re.I)
        if m_adj:
            core_sub = m_adj.group(1).strip()
            adj = m_adj.group(2).strip()
            q2 = f"What architectural factors make {core_sub} {adj}?"
            q3 = f"How can developers optimize {core_sub} for production workloads?"
            q4 = f"What are the measurable performance trade-offs of {core_sub}?"
            q5 = f"What modern alternatives eliminate the overhead of {core_sub}?"
        else:
            q2 = f"What underlying technical mechanics explain why {subject}?"
            q3 = f"How can engineers mitigate the impact of {subject}?"
            q4 = f"What are the major performance trade-offs associated with {subject}?"
            q5 = f"What are industry best practices to resolve {subject}?"
        return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]

    # 4. Mechanism / Workflow ("How do / How does")
    m_how = re.match(r"^how\s+(?:do|does)\s+(.+)$", topic_clean, re.I)
    if m_how:
        q1 = unwrapped if unwrapped.endswith("?") else f"{unwrapped}?"
        q1 = q1[0].upper() + q1[1:]
        subject = clean_topic_phrase(topic_clean)
        q2 = f"What are the major performance trade-offs in {subject}?"
        q3 = f"What are common pitfalls when implementing {subject}?"
        q4 = f"How to benchmark {subject} against standard baselines?"
        q5 = f"What architectural patterns optimize {subject} in production?"
        return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]

    # 5. Definition / Scope ("What is / What are")
    m_what = re.match(r"^what\s+(?:is|are)\s+(.+)$", topic_clean, re.I)
    if m_what:
        q1 = unwrapped if unwrapped.endswith("?") else f"{unwrapped}?"
        q1 = q1[0].upper() + q1[1:]
        subject = m_what.group(1).strip()
        q2 = f"How does {subject} work in practice?"
        q3 = f"What are the primary performance advantages of {subject}?"
        q4 = f"What are common pitfalls when implementing {subject}?"
        q5 = f"How does {subject} compare to modern alternatives?"
        return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]

    # 6. Default Conceptual / Architectural Subject
    concept = clean_topic_phrase(topic_clean)
    q1 = f"How does {concept} work in modern systems?"
    q2 = f"What are the major performance trade-offs of {concept}?"
    q3 = f"What are common pitfalls when implementing {concept}?"
    q4 = f"How to benchmark and optimize {concept} effectively?"
    q5 = f"What is the recommended architecture for {concept} in 2026?"
    return [clean_double_question(q) for q in [q1, q2, q3, q4, q5][:count]]


def generate_natural_related_searches(topic: str, count: int = 4) -> List[str]:
    """
    Generates realistic, keyword-style related search suggestions
    without awkward sentence concatenation.
    """
    comp = extract_comparison_entities(topic)
    if comp:
        ent_a, ent_b = comp
        return [
            f"{ent_a} vs {ent_b} architecture",
            f"{ent_a} vs {ent_b} performance benchmark 2026",
            f"{ent_a} and {ent_b} blending best practices",
            f"{ent_a} vs {ent_b} game engines",
        ][:count]

    subject = clean_topic_phrase(topic)
    return [
        f"{subject} architecture",
        f"{subject} performance benchmark 2026",
        f"{subject} implementation tutorial",
        f"{subject} common pitfalls",
    ][:count]


def naturalize_heading_from_question(question: str) -> str:
    """
    Converts a question into a clean, compelling H2/H3 section heading.
    E.g. 'What is the primary difference between ragdoll and kinematics in games?'
         -> 'Ragdoll vs. Kinematics: Primary Architectural Differences'
    """
    q_clean = clean_double_question(question).rstrip("?. ").strip()

    comp = extract_comparison_entities(q_clean)
    if comp:
        return f"{comp[0].title()} vs. {comp[1].title()}: Key Differences in Practice"

    # Procedural questions
    m_proc = re.match(r"^how\s+(?:do\s+you|to)\s+([a-z]+)\s+(.+)$", q_clean, re.I)
    if m_proc:
        verb = m_proc.group(1).lower()
        rest = m_proc.group(2).strip()
        return f"{_to_gerund(verb).title()} {rest.title()}: Architectural Solutions"

    # Why questions
    m_why = re.match(r"^why\s+(?:is|do|does)\s+(.+)$", q_clean, re.I)
    if m_why:
        return f"Understanding Root Causes: {m_why.group(1).strip().title()}"

    # Default fallback
    subject = clean_topic_phrase(q_clean)
    return f"Resolving Key Challenges: {subject.title()}"
