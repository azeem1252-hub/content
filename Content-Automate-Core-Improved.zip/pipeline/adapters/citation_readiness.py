"""
AI Citation Mechanics & Citation-Readiness Engine (Pillar A5 / GEO Framework).

Architectural Truth:
No one can guarantee citations in stochastic LLM answer engines (Google AI Overviews,
ChatGPT Search, Perplexity). What you can do is remove technical and structural blockers,
create extractable citable material, and measure.

Levers, in order of evidence strength:
1. Rank in Classic Search First:
   - 94% of Google AI Overviews cite at least one top-20 organic result (vendor-cited study, directional).
   - Classic SEO foundation (A1-A4) directly powers AI answer retrieval.
2. Be Crawlable by AI Retrieval Bots:
   - Check robots.txt, WAF/CDN rules, and server-rendered HTML (SSR).
   - Critical distinction: Training crawlers vs. Search/Retrieval crawlers.
     * OpenAI: OAI-SearchBot (ChatGPT search citations) & ChatGPT-User vs GPTBot (training)
     * Google: Googlebot (Search & AI Overviews) vs Google-Extended (Gemini training)
     * Perplexity: PerplexityBot (Search retrieval and citation indexing)
     * Anthropic: ClaudeBot & anthropic-ai (Crawl/Retrieval)
     * Apple: Applebot (Search) vs Applebot-Extended (Apple Intelligence training)
   - Tenant-configurable allow/deny lists.
3. Publish Extractable, Original Facts:
   - Unique statistics, benchmarks, definitions, comparison tables, step lists, expert quotes.
   - LLM answer engines cite specific, quote-ready facts that competing pages lack.
4. Answer-First Passages & Clear Headings:
   - Headings map directly to question-style prompts (What, How, Why, Best, ?).
   - Immediate lead sentence delivers a direct, self-contained factual answer (40-160 words).
5. Entity Clarity:
   - Consistent brand, product, and author identities.
   - Organization and Person JSON-LD schema with sameAs links (Wikidata, LinkedIn, Crunchbase, GitHub).
   - About page and Grounding Page with dated, one-fact-per-sentence definitions.
6. Third-Party Corroboration:
   - Answer engines heavily cite third-party domains (Reddit, Quora, G2, Trustpilot, GitHub, Wikipedia, tech forums).
   - Identifies which 3rd-party domains get cited for target prompts and suggests outreach.
   - Strict Rule: NEVER automate fake mentions (Google spam policies prohibit manipulative link building and reputation abuse).
7. Freshness & Dated Updates:
   - Explicit publication dates, updated timestamps, and recent temporal markers.
   - Re-indexing / refresh alerts when a page loses citations over time.
8. Citation-Readiness Score (Per Article):
   - A transparent 7-lever checklist (NOT a fake ML score):
     has_original_fact, has_answer_first_block, schema_valid, author_dates_present,
     crawl_allowed, 2+ internal inbound links, third-party mentions count.
   - Show it clearly, but NEVER present it as a predictor or guarantee.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal, Optional, Set, Tuple
from urllib.parse import urlparse
from pydantic import BaseModel, Field

logger = logging.getLogger("pipeline.adapters.citation_readiness")

# ---------------------------------------------------------------------------
# AI Crawler Registry (Training vs Search/Retrieval Distinction)
# ---------------------------------------------------------------------------

AI_RETRIEVAL_CRAWLERS = {
    "OAI-SearchBot": {
        "vendor": "OpenAI",
        "purpose": "Search & Citation Indexing",
        "description": "Used by ChatGPT search to discover and index content for live user citations.",
        "impact_if_blocked": "ChatGPT search will NOT cite or link to your website.",
        "is_retrieval": True,
    },
    "ChatGPT-User": {
        "vendor": "OpenAI",
        "purpose": "User-Directed Browsing",
        "description": "Sent when an active user explicitly instructs ChatGPT to browse a specific URL.",
        "impact_if_blocked": "Users cannot ask ChatGPT to analyze or summarize your links directly.",
        "is_retrieval": True,
    },
    "Googlebot": {
        "vendor": "Google",
        "purpose": "Search & AI Overviews Indexing",
        "description": "Google's primary web crawler. Powers both organic Google Search and Google AI Overviews.",
        "impact_if_blocked": "Removes your site from both Google classic search and AI Overviews entirely.",
        "is_retrieval": True,
    },
    "PerplexityBot": {
        "vendor": "Perplexity",
        "purpose": "Search & Citation Retrieval",
        "description": "Perplexity's indexing crawler for answering queries and attaching citations.",
        "impact_if_blocked": "Perplexity will not cite your pages in its answers.",
        "is_retrieval": True,
    },
    "ClaudeBot": {
        "vendor": "Anthropic",
        "purpose": "Search & Content Retrieval",
        "description": "Anthropic's web retrieval bot for Claude search features.",
        "impact_if_blocked": "Claude will not retrieve or cite your content.",
        "is_retrieval": True,
    },
    "Applebot": {
        "vendor": "Apple",
        "purpose": "Siri & Spotlight Search",
        "description": "Powers search results across Siri, Spotlight, and Safari suggestions.",
        "impact_if_blocked": "Site will not be surfaced in Apple search surfaces.",
        "is_retrieval": True,
    },
}

AI_TRAINING_CRAWLERS = {
    "GPTBot": {
        "vendor": "OpenAI",
        "purpose": "Model Training",
        "description": "Collects web training corpora to train future OpenAI foundation models.",
        "impact_if_blocked": "Your content will not be used in model weights training. Does NOT affect ChatGPT search citations if OAI-SearchBot is allowed.",
        "is_retrieval": False,
    },
    "Google-Extended": {
        "vendor": "Google",
        "purpose": "Model Training (Gemini/Vertex)",
        "description": "Used by Google to train Gemini and Vertex AI models. Independent of Search.",
        "impact_if_blocked": "Prevents Gemini training on your content. Does NOT block Google Search or Google AI Overviews (which rely on Googlebot).",
        "is_retrieval": False,
    },
    "Applebot-Extended": {
        "vendor": "Apple",
        "purpose": "Model Training (Apple Intelligence)",
        "description": "Used by Apple to train Apple Intelligence generative models.",
        "impact_if_blocked": "Blocks Apple Intelligence model training without affecting Siri/Spotlight search.",
        "is_retrieval": False,
    },
    "CCBot": {
        "vendor": "Common Crawl",
        "purpose": "Open Web Corpus Training",
        "description": "Common Crawl web corpus used by multiple academic and commercial AI labs.",
        "impact_if_blocked": "Blocks inclusion in Common Crawl data dumps.",
        "is_retrieval": False,
    },
    "cohere-ai": {
        "vendor": "Cohere",
        "purpose": "Model Training",
        "description": "Web crawler for Cohere LLM training.",
        "impact_if_blocked": "Blocks Cohere training data ingestion.",
        "is_retrieval": False,
    },
    "FacebookBot": {
        "vendor": "Meta",
        "purpose": "Model Training & Indexing",
        "description": "Crawler used by Meta for AI features and speech/language models.",
        "impact_if_blocked": "Blocks Meta AI scraping.",
        "is_retrieval": False,
    },
    "Bytespider": {
        "vendor": "ByteDance",
        "purpose": "Model Training & Search",
        "description": "ByteDance crawler for TikTok and Doubao AI models.",
        "impact_if_blocked": "Blocks ByteDance model ingestion.",
        "is_retrieval": False,
    },
}

# High-Authority Third-Party Corroboration Platforms frequently cited by answer engines
CORROBORATION_PLATFORMS = [
    {"domain": "reddit.com", "name": "Reddit", "type": "Community / Technical Discussion"},
    {"domain": "github.com", "name": "GitHub", "type": "Open Source & Code Repository"},
    {"domain": "wikipedia.org", "name": "Wikipedia", "type": "Collaborative Encyclopedia"},
    {"domain": "stackoverflow.com", "name": "Stack Overflow", "type": "Developer Q&A"},
    {"domain": "g2.com", "name": "G2", "type": "Software Review & Benchmark Directory"},
    {"domain": "trustpilot.com", "name": "Trustpilot", "type": "Consumer Review Platform"},
    {"domain": "news.ycombinator.com", "name": "Hacker News", "type": "Tech Community Discussion"},
    {"domain": "quora.com", "name": "Quora", "type": "Q&A Knowledge Base"},
    {"domain": "producthunt.com", "name": "Product Hunt", "type": "Software Launch Platform"},
    {"domain": "arxiv.org", "name": "arXiv", "type": "Academic Preprint Repository"},
]


# ---------------------------------------------------------------------------
# What Influences AI Citations (Evidence-Ranked Matrix)
# ---------------------------------------------------------------------------

EVIDENCE_RANKED_LEVERS = [
    {
        "rank": 1,
        "lever": "Evidence-rich content: sourced stats, quotations, citations",
        "evidence_level": "Peer-reviewed benchmark (KDD 2024), not a live-engine guarantee",
        "implementation": "A3.1, test in A12",
        "verdict": "High empirical benchmark",
    },
    {
        "rank": 2,
        "lever": "Classic ranking",
        "evidence_level": "Helps, but weaker than before (reported fall in AIO top-10 overlap)",
        "implementation": "A1-A5",
        "verdict": "Directional / Moderate",
    },
    {
        "rank": 3,
        "lever": "Crawl access for search/retrieval bots",
        "evidence_level": "Practitioner consensus, mechanically necessary",
        "implementation": "A6.2",
        "verdict": "Mechanically essential",
    },
    {
        "rank": 4,
        "lever": "Third-party presence: Reddit, YouTube, LinkedIn, Wikipedia, review sites, editorial",
        "evidence_level": "Multiple large citation studies; varies by engine and industry",
        "implementation": "A9",
        "verdict": "Multiple large citation studies",
    },
    {
        "rank": 5,
        "lever": "Entity clarity: consistent names, Organization/Person schema, sameAs, About page",
        "evidence_level": "Plausible, low direct evidence",
        "implementation": "A5",
        "verdict": "Plausible, low direct evidence",
    },
    {
        "rank": 6,
        "lever": "Original data others reference (studies, benchmarks)",
        "evidence_level": "Plausible; also earns links and mentions",
        "implementation": "A3.2, A9",
        "verdict": "Plausible / Link earning",
    },
    {
        "rank": 7,
        "lever": "Freshness",
        "evidence_level": "Plausible",
        "implementation": "A8 refresh loop",
        "verdict": "Plausible",
    },
    {
        "rank": 8,
        "lever": "Citation half-life is short, so expect continuous work",
        "evidence_level": "Volatility studies",
        "implementation": "A7",
        "verdict": "Volatility studies",
    },
]


class ChecklistItem(BaseModel):
    lever_name: str
    passed: bool
    title: str
    description: str
    evidence_order: int
    evidence_level: Optional[str] = None
    implementation_ref: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)
    remediation_hint: Optional[str] = None


class CitationReadinessReport(BaseModel):
    passed_count: int
    total_count: int = 7
    readiness_percentage: float
    readiness_tier: Literal["High Readiness", "Moderate Readiness", "Needs Remediation"]
    promise: str = "Readiness checklist only — no system can guarantee citations in stochastic LLM answer engines."
    disclaimer: str = (
        "Citation-readiness evaluates whether your article removes technical blockers (crawlability, schema) "
        "and provides quotable, extractable material (original facts, answer-first blocks). "
        "It is a transparent diagnostic checklist, never an outcome predictor."
    )
    classic_search_context: Dict[str, Any] = Field(
        default_factory=lambda: {
            "vendor_study_stat": "94% of Google AI Overviews cite at least one top-20 organic result",
            "stat_characterization": "Directional vendor benchmark (BrightEdge/Ahrefs)",
            "guidance": "Rank in classic organic search first; all A1-A5 optimizations reinforce this foundation.",
        }
    )
    evidence_matrix: List[Dict[str, Any]] = Field(default_factory=lambda: list(EVIDENCE_RANKED_LEVERS))
    items: List[ChecklistItem]
    detected_facts_summary: Dict[str, int]
    crawler_policy_summary: Dict[str, Any]
    third_party_corroboration_summary: Dict[str, Any]


# ---------------------------------------------------------------------------
# Lever 2: Crawler Access & Robots.txt Evaluator
# ---------------------------------------------------------------------------

def parse_robots_txt_rules(robots_txt: str) -> Dict[str, List[Tuple[str, str]]]:
    """
    Parses robots.txt into a mapping of user-agent -> list of (allow/disallow, path).
    """
    if not robots_txt:
        return {}

    rules: Dict[str, List[Tuple[str, str]]] = {}
    current_agents = []
    last_directive = None

    for line in robots_txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue

        directive, value = line.split(":", 1)
        directive = directive.strip().lower()
        value = value.strip()

        if directive == "user-agent":
            if last_directive in ("allow", "disallow"):
                current_agents = []
            agent = value.lower()
            current_agents.append(agent)
            if agent not in rules:
                rules[agent] = []
            last_directive = "user-agent"
        elif directive in ("allow", "disallow"):
            for agent in current_agents:
                rules[agent].append((directive, value))
            last_directive = directive
        elif directive in ("sitemap", "host"):
            current_agents = []
            last_directive = directive

    return rules


def evaluate_crawler_access(
    robots_txt_content: Optional[str] = None,
    tenant_policy: Optional[Dict[str, bool]] = None,
    target_path: str = "/posts/",
    is_server_rendered: bool = True,
) -> Dict[str, Any]:
    """
    Evaluates whether AI Retrieval bots (crucial for citations) and Training bots
    are permitted by robots.txt and tenant settings.
    """
    rules = parse_robots_txt_rules(robots_txt_content or "")
    default_rules = rules.get("*", [])

    def _is_allowed(bot_name: str) -> bool:
        bot_lower = bot_name.lower()
        bot_specific = rules.get(bot_lower)
        target_rules = bot_specific if bot_specific is not None else default_rules

        allowed = True
        for action, path in target_rules:
            if not path or path == "":
                if action == "disallow":
                    allowed = True
            elif path == "/":
                if action == "disallow":
                    allowed = False
                elif action == "allow":
                    allowed = True
            elif target_path.startswith(path):
                if action == "disallow":
                    allowed = False
                elif action == "allow":
                    allowed = True
        return allowed

    retrieval_status = {}
    for bot, info in AI_RETRIEVAL_CRAWLERS.items():
        is_allowed_robots = _is_allowed(bot)
        # Check tenant policy override if present
        tenant_allow = tenant_policy.get(bot, True) if tenant_policy else True
        effective_allowed = is_allowed_robots and tenant_allow
        retrieval_status[bot] = {
            "allowed": effective_allowed,
            "vendor": info["vendor"],
            "purpose": info["purpose"],
            "robots_allowed": is_allowed_robots,
            "tenant_allowed": tenant_allow,
            "impact_if_blocked": info["impact_if_blocked"],
        }

    training_status = {}
    for bot, info in AI_TRAINING_CRAWLERS.items():
        is_allowed_robots = _is_allowed(bot)
        tenant_allow = tenant_policy.get(bot, False) if tenant_policy else is_allowed_robots
        effective_allowed = is_allowed_robots and tenant_allow
        training_status[bot] = {
            "allowed": effective_allowed,
            "vendor": info["vendor"],
            "purpose": info["purpose"],
            "robots_allowed": is_allowed_robots,
            "tenant_allowed": tenant_allow,
            "description": info["description"],
        }

    # Retrieval crawlers must be allowed for high citation readiness
    primary_retrieval_bots = ["Googlebot", "OAI-SearchBot", "PerplexityBot"]
    blocked_retrieval = [b for b in primary_retrieval_bots if not retrieval_status.get(b, {}).get("allowed", True)]
    passed = len(blocked_retrieval) == 0 and is_server_rendered

    return {
        "passed": passed,
        "is_server_rendered": is_server_rendered,
        "retrieval_crawlers": retrieval_status,
        "training_crawlers": training_status,
        "blocked_retrieval_bots": blocked_retrieval,
        "ssr_note": "Main content delivered in server-rendered HTML (Next.js SSR/SSG)." if is_server_rendered else "Warning: Client-rendered JS detected; answer engines may fail to parse extractable text.",
    }


# ---------------------------------------------------------------------------
# Lever 3: Extractable, Original Facts Detector
# ---------------------------------------------------------------------------

def detect_original_facts(draft: str, evidence_pack: Optional[Any] = None) -> Dict[str, Any]:
    """
    Detects extractable, quotable empirical artifacts that answer engines prefer:
    - Quantitative statistics and benchmarks
    - Markdown comparison tables
    - Numbered step procedures
    - Canonical definitions
    - Expert / authoritative quotes
    """
    if not draft:
        return {"passed": False, "total_facts": 0, "categories": {}}

    # 1. Comparison tables
    tables = re.findall(r"\|[^\n]+\|\n\|[-:\s|]+\|\n(?:\|[^\n]+\|\n?)+", draft)
    has_table = len(tables) > 0

    # 2. Numbered step lists
    step_lists = re.findall(r"(?:^\s*\d+\.\s+[^\n]+\n?){2,}", draft, re.MULTILINE)
    has_steps = len(step_lists) > 0

    # 3. Statistics and benchmarks (percentages, currency, specific numerical metrics)
    stat_matches = list(set(re.findall(r"\b(?:\d+(?:\.\d+)?%|\$\d+(?:\.\d+)?[kmb]?|\b\d+(?:\.\d+)?\s*(?:ms|seconds|minutes|hours|GB|TB|users|TPS|FPS|queries|parameters)\b)", draft, re.IGNORECASE)))

    # 4. Canonical definitions (e.g. "X is defined as ...", "X refers to ...", "A Y is an architecture that ...")
    definitions = list(set(re.findall(r"\b([A-Z][a-zA-Z0-9_\s-]{2,25}\s+(?:is\s+(?:a|an|the)|refers\s+to|is\s+defined\s+as)\s+[^\.\n]{15,100}\.)", draft)))

    # 5. Attributed expert quotes
    quotes = list(set(re.findall(r'\"([^\"]{20,160})\"(?:\s*(?:said|stated|explained|noted|according to)\s+([A-Z][a-zA-Z\s]+))?', draft)))

    # 6. Check if evidence pack had original proprietary data
    evidence_pack_items = 0
    if evidence_pack:
        if isinstance(evidence_pack, dict):
            evidence_pack_items = len(evidence_pack.get("items", []))
        elif hasattr(evidence_pack, "items"):
            evidence_pack_items = len(getattr(evidence_pack, "items", []))

    total_fact_points = (
        (len(tables) * 2) +
        (len(step_lists) * 1) +
        min(4, len(stat_matches)) +
        min(3, len(definitions)) +
        min(2, len(quotes)) +
        (1 if evidence_pack_items > 0 else 0)
    )

    passed = (has_table or len(stat_matches) >= 2 or len(definitions) >= 1) and total_fact_points >= 3

    return {
        "passed": passed,
        "total_fact_score": total_fact_points,
        "tables_count": len(tables),
        "step_lists_count": len(step_lists),
        "statistics_detected": stat_matches[:8],
        "statistics_count": len(stat_matches),
        "definitions_detected": [d[0] if isinstance(d, tuple) else d for d in definitions[:4]],
        "quotes_count": len(quotes),
        "has_comparison_table": has_table,
        "has_step_list": has_steps,
        "evidence_pack_items": evidence_pack_items,
    }


# ---------------------------------------------------------------------------
# Lever 4: Answer-First Passages & Clear Headings
# ---------------------------------------------------------------------------

_QUESTION_PREFIXES = (
    "what", "how", "why", "when", "where", "which", "who", "can",
    "does", "is", "are", "should", "will", "best", "compare", "difference"
)

_PREAMBLE_FLUFF_PATTERNS = [
    re.compile(r"^in\s+(?:today['’]s|the)\s+(?:[a-z-]+\s+)*digital\s+world", re.IGNORECASE),
    re.compile(r"^it\s+is\s+(?:important|crucial|essential)\s+to\s+note\s+that", re.IGNORECASE),
    re.compile(r"\bdive\s+(?:deep|in)\b", re.IGNORECASE),
    re.compile(r"^when\s+it\s+comes\s+to\s+[a-z\s]+,\s+one\s+might\s+wonder", re.IGNORECASE),
]


def detect_answer_first_passages(draft: str) -> Dict[str, Any]:
    """
    Evaluates whether the draft features:
    1. Headings mapping directly to question-style prompts.
    2. Answer-first lead sentences immediately following the headings without preamble fluff.
    3. Self-contained passages (40-160 words) that answer engines can lift directly.
    """
    if not draft:
        return {"passed": False, "question_headings_count": 0, "answer_first_blocks_count": 0}

    sections = re.split(r"\n(?=#{2,3}\s+)", draft)
    question_headings = []
    answer_first_blocks = []
    preamble_penalties = 0

    for sec in sections:
        sec = sec.strip()
        if not sec.startswith("#"):
            continue

        lines = [line.strip() for line in sec.splitlines() if line.strip()]
        heading_line = lines[0] if lines else ""
        heading_clean = re.sub(r"^#{2,3}\s+", "", heading_line).strip()

        is_question = (
            heading_clean.endswith("?") or
            heading_clean.lower().startswith(_QUESTION_PREFIXES)
        )

        if not is_question:
            continue

        question_headings.append(heading_clean)

        # Look at the first body paragraph after the heading
        body_paras = [p for p in lines[1:] if p and not p.startswith("#")]
        if not body_paras:
            continue

        lead_para = body_paras[0]
        word_count = len(lead_para.split())

        # Check for preamble fluff
        has_fluff = any(p.search(lead_para) for p in _PREAMBLE_FLUFF_PATTERNS)
        if has_fluff:
            preamble_penalties += 1

        # An answer-first passage is direct, between 35 and 160 words, without fluff
        if 35 <= word_count <= 160 and not has_fluff:
            answer_first_blocks.append({
                "heading": heading_clean,
                "lead_snippet": lead_para[:180] + ("..." if len(lead_para) > 180 else ""),
                "word_count": word_count,
            })

    passed = ((len(question_headings) >= 1 and len(answer_first_blocks) >= 1) or len(answer_first_blocks) >= 2) and preamble_penalties == 0

    return {
        "passed": passed,
        "question_headings_count": len(question_headings),
        "question_headings": question_headings[:5],
        "answer_first_blocks_count": len(answer_first_blocks),
        "answer_first_examples": answer_first_blocks[:3],
        "preamble_penalties": preamble_penalties,
    }


# ---------------------------------------------------------------------------
# Lever 5: Entity Clarity & Schema Standards
# ---------------------------------------------------------------------------

def evaluate_entity_clarity(
    draft: str,
    schema_markup: Optional[Any] = None,
    author: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Evaluates entity clarity:
    - Organization and Person JSON-LD Schema
    - sameAs links to authoritative entities (Wikidata, LinkedIn, Crunchbase, GitHub)
    - Named author attribution
    """
    schema_str = ""
    if isinstance(schema_markup, dict):
        import json
        schema_str = json.dumps(schema_markup)
    elif isinstance(schema_markup, str):
        schema_str = schema_markup

    schema_types = []
    has_same_as = False
    if schema_str:
        types_found = re.findall(r'"@type"\s*:\s*"([^"]+)"', schema_str)
        schema_types = list(set(types_found))
        has_same_as = ("sameas" in schema_str.lower() or "wikidata.org" in schema_str or "linkedin.com" in schema_str)

    has_author = bool(author and author.strip() and author.lower() not in ("admin", "user", "anonymous"))

    # Check for Grounding Page standard v1.6 links in draft or schema
    has_grounding_ref = bool(re.search(r"/grounding/|atomic_facts|canonical_definition", draft + " " + schema_str))

    passed = (len(schema_types) >= 1 or has_same_as) and has_author

    return {
        "passed": passed,
        "schema_types_detected": schema_types,
        "has_same_as_links": has_same_as,
        "has_named_author": has_author,
        "author_name": author or "Unspecified",
        "has_grounding_page_reference": has_grounding_ref,
    }


# ---------------------------------------------------------------------------
# Lever 6: Third-Party Corroboration & Outreach Intelligence
# ---------------------------------------------------------------------------

def analyze_third_party_corroboration(
    draft: str,
    external_links: Optional[List[str]] = None,
    third_party_mentions: Optional[List[Dict[str, Any]]] = None,
    primary_topic: str = "",
) -> Dict[str, Any]:
    """
    Analyzes third-party corroboration.
    Answer engines rely heavily on multi-platform corroboration (Reddit, G2, Trustpilot, GitHub, forums).
    Strict Rule: DO NOT automate fake mentions (violates Google spam policies).
    Suggests genuine outreach and community engagement.
    """
    links = external_links or []
    if not links and draft:
        found_urls = re.findall(r"\[[^\]]+\]\((https?://[^\)]+)\)", draft)
        links.extend(found_urls)

    cited_domains = set()
    for u in links:
        try:
            d = urlparse(u).netloc.lower()
            if d.startswith("www."):
                d = d[4:]
            cited_domains.add(d)
        except Exception:
            pass

    corroboration_hits = []
    for platform in CORROBORATION_PLATFORMS:
        p_dom = platform["domain"]
        if any(d == p_dom or d.endswith("." + p_dom) for d in cited_domains):
            corroboration_hits.append(platform)

    # Outreach suggestions for unrepresented high-authority platforms
    suggested_outreach = []
    missing_platforms = [
        p for p in CORROBORATION_PLATFORMS[:5]
        if not any(d == p["domain"] or d.endswith("." + p["domain"]) for d in cited_domains)
    ]
    for p in missing_platforms[:3]:
        suggested_outreach.append({
            "platform": p["name"],
            "domain": p["domain"],
            "type": p["type"],
            "recommendation": f"Participate in verified, organic discussions on {p['name']} regarding '{primary_topic or 'this topic'}'. Avoid automated/spam mentions.",
        })

    mentions_count = len(third_party_mentions or []) + len(corroboration_hits)
    passed = len(corroboration_hits) >= 1 or len(cited_domains) >= 2 or len(third_party_mentions or []) >= 1

    return {
        "passed": passed,
        "outbound_citations_count": len(links),
        "distinct_cited_domains": list(cited_domains)[:6],
        "corroboration_platforms_cited": [p["name"] for p in corroboration_hits],
        "mentions_count": mentions_count,
        "suggested_outreach": suggested_outreach,
        "google_spam_policy_warning": "Strict Policy: Never automate fake user mentions or reviews. Manipulative mentions violate Google Spam Policies (Site Reputation Abuse).",
    }


# ---------------------------------------------------------------------------
# Lever 7: Freshness & Temporal Signals
# ---------------------------------------------------------------------------

def evaluate_freshness_signals(
    draft: str,
    published_at: Optional[str] = None,
    updated_at: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Evaluates temporal signals:
    - Explicit published_at and updated_at dates
    - Recent year anchors (2025, 2026) in draft text
    """
    has_dates = bool(published_at or updated_at)
    current_year = str(datetime.now(timezone.utc).year)
    prior_year = str(datetime.now(timezone.utc).year - 1)

    has_year_markers = bool(re.search(rf"\b({current_year}|{prior_year}|latest|updated)\b", draft, re.IGNORECASE))
    passed = has_dates or has_year_markers

    return {
        "passed": passed,
        "published_at": published_at,
        "updated_at": updated_at,
        "has_recent_year_markers": has_year_markers,
        "current_temporal_anchor": current_year,
    }


# ---------------------------------------------------------------------------
# Comprehensive Citation-Readiness Evaluator (The 7-Lever Checklist)
# ---------------------------------------------------------------------------

def evaluate_citation_readiness(
    title: str,
    draft: str,
    slug: Optional[str] = None,
    keywords: Optional[List[str]] = None,
    schema_markup: Optional[Any] = None,
    author: Optional[str] = None,
    published_at: Optional[str] = None,
    updated_at: Optional[str] = None,
    internal_inbound_links_count: int = 2,
    robots_txt_content: Optional[str] = None,
    tenant_crawler_policy: Optional[Dict[str, bool]] = None,
    third_party_mentions: Optional[List[Dict[str, Any]]] = None,
    evidence_pack: Optional[Any] = None,
    is_server_rendered: bool = True,
) -> Dict[str, Any]:
    """
    Evaluates an article against the 7 real levers of AI citation readiness.
    Produces a transparent diagnostic checklist — NEVER a fake ML predictor score.
    """
    # 1. Facts Lever (Evidence Rank 1)
    facts_eval = detect_original_facts(draft, evidence_pack=evidence_pack)
    item_facts = ChecklistItem(
        lever_name="has_original_fact",
        passed=facts_eval["passed"],
        evidence_order=1,
        title="Evidence-Rich Content: Sourced Stats & Citations",
        evidence_level="Peer-reviewed benchmark (KDD 2024), not a live-engine guarantee",
        implementation_ref="A3.1, test in A12",
        description="Article contains quote-ready statistics, benchmarks, comparison tables, definitions, or step lists.",
        details=facts_eval,
        remediation_hint=None if facts_eval["passed"] else "Add a comparison table, numbered step list, or unique empirical statistics.",
    )

    # 2. Classic Ranking & Inbound Internal Links (Evidence Rank 2)
    has_internal_links = internal_inbound_links_count >= 2
    item_links = ChecklistItem(
        lever_name="internal_inbound_links_valid",
        passed=has_internal_links,
        evidence_order=2,
        title="Classic Ranking Foundation & Inbound Silos",
        evidence_level="Helps, but weaker than before (reported fall in AIO top-10 overlap)",
        implementation_ref="A1-A5",
        description="Article receives at least 2 contextual inbound links from other topic cluster pages on the site.",
        details={"internal_inbound_links_count": internal_inbound_links_count, "target_threshold": 2},
        remediation_hint=None if has_internal_links else f"Add {2 - internal_inbound_links_count} more internal link(s) pointing to this article from related cluster posts.",
    )

    # 3. Crawler Access Lever (Evidence Rank 3)
    crawler_eval = evaluate_crawler_access(
        robots_txt_content=robots_txt_content,
        tenant_policy=tenant_crawler_policy,
        is_server_rendered=is_server_rendered,
    )
    item_crawl = ChecklistItem(
        lever_name="crawl_allowed",
        passed=crawler_eval["passed"],
        evidence_order=3,
        title="Crawl Access for Search & Retrieval Bots",
        evidence_level="Practitioner consensus, mechanically necessary",
        implementation_ref="A6.2",
        description="Robots.txt allows live retrieval bots (Googlebot, OAI-SearchBot, PerplexityBot) and main content is server-rendered.",
        details=crawler_eval,
        remediation_hint=None if crawler_eval["passed"] else f"Unblock retrieval bots in robots.txt ({', '.join(crawler_eval.get('blocked_retrieval_bots', []))}) and serve SSR HTML.",
    )

    # 4. Third-Party Presence Lever (Evidence Rank 4)
    corrob_eval = analyze_third_party_corroboration(draft, primary_topic=title)
    item_corrob = ChecklistItem(
        lever_name="third_party_mentions_present",
        passed=corrob_eval["passed"],
        evidence_order=4,
        title="Third-Party Presence & Multi-Platform Authority",
        evidence_level="Multiple large citation studies; varies by engine and industry",
        implementation_ref="A9",
        description="Outbound citations to authoritative industry sources; third-party forum/review corroboration.",
        details=corrob_eval,
        remediation_hint=None if corrob_eval["passed"] else "Add 2+ outbound citations to authoritative primary documentation or research sources.",
    )

    # 5. Entity Clarity Lever (Evidence Rank 5)
    entity_eval = evaluate_entity_clarity(draft, schema_markup=schema_markup, author=author)
    item_schema = ChecklistItem(
        lever_name="schema_valid",
        passed=entity_eval["passed"],
        evidence_order=5,
        title="Entity Clarity: Schema, sameAs & Grounding",
        evidence_level="Plausible, low direct evidence",
        implementation_ref="A5",
        description="Structured JSON-LD schema (Article/Organization/Person) with sameAs links and verified author attribution.",
        details=entity_eval,
        remediation_hint=None if entity_eval["passed"] else "Ensure JSON-LD Article/Organization schema is present with author and sameAs links.",
    )

    # 6. Answer-First Lever
    answer_eval = detect_answer_first_passages(draft)
    item_answer = ChecklistItem(
        lever_name="has_answer_first_block",
        passed=answer_eval["passed"],
        evidence_order=6,
        title="Answer-First Passages & Clear Headings",
        evidence_level="Empirical retrieval lift for question prompts",
        implementation_ref="A3.1, A5",
        description="Headings map to question prompts, followed immediately by a concise, direct 1-2 sentence answer block.",
        details=answer_eval,
        remediation_hint=None if answer_eval["passed"] else "Format at least one H2 as a question (What is..., How to...) with an immediate 40-160 word answer paragraph.",
    )

    # 7. Freshness & Dated Updates Lever (Evidence Rank 7 & 8)
    freshness_eval = evaluate_freshness_signals(draft, published_at=published_at, updated_at=updated_at)
    item_author_dates = ChecklistItem(
        lever_name="author_dates_present",
        passed=bool(author and freshness_eval["passed"]),
        evidence_order=7,
        title="Freshness & Dated Timestamps (Continuous Lifecycle)",
        evidence_level="Plausible (Citation half-life is short, continuous work required)",
        implementation_ref="A8 refresh loop, A7",
        description="Clear author byline, explicit published_at / updated_at timestamps, and short citation half-life monitoring.",
        details={**freshness_eval, "author": author},
        remediation_hint=None if (author and freshness_eval["passed"]) else "Set a named editorial author and dated timestamps.",
    )

    checklist_items = [
        item_links,         # Lever 1: Classic search foundation
        item_crawl,         # Lever 2: Crawlability
        item_facts,         # Lever 3: Extractable facts
        item_answer,        # Lever 4: Answer-first blocks
        item_schema,        # Lever 5: Entity clarity
        item_corrob,        # Lever 6: Third-party corroboration
        item_author_dates,  # Lever 7: Freshness / author dates
    ]

    passed_count = sum(1 for it in checklist_items if it.passed)
    total_count = len(checklist_items)
    percentage = round((passed_count / total_count) * 100.0, 1)

    if passed_count >= 6:
        readiness_tier = "High Readiness"
    elif passed_count >= 4:
        readiness_tier = "Moderate Readiness"
    else:
        readiness_tier = "Needs Remediation"

    report = CitationReadinessReport(
        passed_count=passed_count,
        total_count=total_count,
        readiness_percentage=percentage,
        readiness_tier=readiness_tier,
        items=checklist_items,
        detected_facts_summary={
            "tables": facts_eval["tables_count"],
            "statistics": facts_eval["statistics_count"],
            "step_lists": facts_eval["step_lists_count"],
            "definitions": len(facts_eval["definitions_detected"]),
        },
        crawler_policy_summary={
            "retrieval_allowed": crawler_eval["passed"],
            "server_rendered": is_server_rendered,
            "blocked_bots": crawler_eval.get("blocked_retrieval_bots", []),
        },
        third_party_corroboration_summary={
            "outbound_citations": corrob_eval["outbound_citations_count"],
            "platforms_cited": corrob_eval["corroboration_platforms_cited"],
            "suggested_outreach_count": len(corrob_eval["suggested_outreach"]),
        },
    )

    return report.model_dump()
