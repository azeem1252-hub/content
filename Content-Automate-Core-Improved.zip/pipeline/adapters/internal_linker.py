"""
Autonomous Internal Linking & Topic Cluster Engine.
Directly implements Topic Cluster Architecture and Link Silos from the Master Blueprint.

Capabilities:
1. Discovers semantically relevant existing articles from the same website.
2. Injects internal linking instructions into Outline and Draft LLM prompts.
3. Post-processes drafts to validate internal links, guard against 404s, and
   deterministically insert contextual links if omitted.
4. Generates topic cluster metadata (Pillar vs. Spoke, inbound/outbound graph).
"""

import re
import logging
from typing import Any, Dict, List, Optional, Tuple, Set

from storage.db import get_all_posts, get_all_pipeline_runs, get_post_by_slug
from pipeline.adapters.semantic_matcher import evaluate_anti_cannibalization, CANNIBALIZATION_THRESHOLD
from pipeline.adapters.embedding_client import embed_texts, local_embed_text, cosine_similarity

logger = logging.getLogger("pipeline.adapters.internal_linker")


def get_cluster_candidates(
    topic: str,
    website_id: Optional[str] = None,
    exclude_slug: Optional[str] = None,
    limit: int = 5,
) -> List[Dict[str, Any]]:
    """
    Finds existing published articles on the same website (or database)
    that are semantically related to `topic` to form an internal link cluster.
    """
    if not topic:
        return []

    # 1. Fetch existing articles from DB
    raw_posts = get_all_posts(limit=100, status=None)
    runs = get_all_pipeline_runs(limit=100)

    # Combine posts and completed runs into a unified deduplicated pool by slug
    seen_slugs: Set[str] = set()
    if exclude_slug:
        seen_slugs.add(exclude_slug.strip().lower())

    candidates_pool: List[Dict[str, Any]] = []

    for p in raw_posts:
        slug = (p.get("slug") or "").strip()
        title = (p.get("title") or "").strip()
        if not slug or not title or slug.lower() in seen_slugs:
            continue
        if website_id and p.get("website_id") and p.get("website_id") != website_id:
            continue
        seen_slugs.add(slug.lower())
        candidates_pool.append({
            "id": p.get("id"),
            "slug": slug,
            "title": title,
            "excerpt": p.get("excerpt") or p.get("meta_description") or "",
            "url": f"/posts/{slug}",
        })

    for r in runs:
        slug = (r.get("slug") or "").strip()
        title = (r.get("title") or "").strip()
        status = (r.get("status") or "").lower()
        if not slug or not title or slug.lower() in seen_slugs:
            continue
        # Include completed or review_pending runs
        if status not in ("completed", "review_pending", "published"):
            continue
        if website_id and r.get("website_id") and r.get("website_id") != website_id:
            continue
        seen_slugs.add(slug.lower())
        candidates_pool.append({
            "id": r.get("thread_id"),
            "slug": slug,
            "title": title,
            "excerpt": (r.get("state") or {}).get("excerpt") or (r.get("state") or {}).get("meta_description") or "",
            "url": f"/posts/{slug}",
        })

    if not candidates_pool:
        return []

    # 2. Score semantic relevance using dense embeddings
    try:
        topic_vec = local_embed_text(topic)
        scored_candidates = []
        for c in candidates_pool:
            c_text = f"{c['title']} {c['excerpt']}".strip()
            c_vec = local_embed_text(c_text)
            sim = cosine_similarity(topic_vec, c_vec)
            # Avoid self-cannibalization candidates (>= 0.88) and completely unrelated ones (< 0.12)
            if 0.12 <= sim < 0.90:
                scored_candidates.append({**c, "similarity": round(sim, 3)})

        # Sort by relevance descending
        scored_candidates.sort(key=lambda x: x["similarity"], reverse=True)
        return scored_candidates[:limit]
    except Exception as e:
        logger.warning(f"Error ranking cluster candidates: {e}")
        return candidates_pool[:limit]


def build_internal_linking_prompt(candidates: List[Dict[str, Any]]) -> str:
    """
    Generates high-authority prompt instructions for the LLM during drafting.
    """
    if not candidates:
        return ""

    lines = []
    for c in candidates:
        lines.append(f'- [{c["title"]}](/posts/{c["slug"]}) — Relevance: {int(c.get("similarity", 0.5) * 100)}%')

    return f"""
--- TOPICAL CLUSTER & INTERNAL LINKING ARCHITECTURE ---
Search engines and AI answer engines evaluate topic clusters and silo depth.
Naturally cross-link 1 to 3 of the following related internal articles from our publication:
{chr(10).join(lines)}

STRICT LINKING RULES:
1. Embed links naturally inside sentences using descriptive, contextual anchor text (e.g. "as detailed in our analysis of [AI-Generated Characters in Games](/posts/...)" or "exploring [physics engine limitations](/posts/...)").
2. NEVER use generic anchors like "click here", "read more", or "this article".
3. ONLY use the exact relative URL paths provided above (`/posts/<slug>`). Never invent or modify slugs.
4. Do not force links where they do not fit; 1 to 3 organic links is ideal.
--- END INTERNAL LINKING ARCHITECTURE ---
"""


def verify_and_inject_internal_links(
    draft: str,
    candidates: List[Dict[str, Any]],
    min_links: int = 1,
    max_links: int = 3
) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Validates internal links in the draft:
    1. Ensures all `/posts/{slug}` links point to valid candidate slugs.
    2. If the LLM omitted internal links, naturally inserts a contextual
       'Related Deep Dive' block before the conclusion or last H2.
    """
    if not draft or not candidates:
        return draft, []

    valid_slug_map = {c["slug"].lower(): c for c in candidates}
    existing_links = re.findall(r'\[([^\]]+)\]\((/posts/([a-zA-Z0-9_\-\.]+))\)', draft)

    found_links: List[Dict[str, Any]] = []
    used_slugs: Set[str] = set()

    for anchor, full_url, slug in existing_links:
        slug_clean = slug.lower()
        if slug_clean in valid_slug_map:
            matched_candidate = valid_slug_map[slug_clean]
            found_links.append({
                "anchor": anchor,
                "url": full_url,
                "slug": matched_candidate["slug"],
                "title": matched_candidate["title"],
                "verified": True,
            })
            used_slugs.add(slug_clean)
        else:
            # Check if this slug exists in DB anyway
            db_post = get_post_by_slug(slug)
            if db_post:
                found_links.append({
                    "anchor": anchor,
                    "url": full_url,
                    "slug": slug,
                    "title": db_post.get("title", slug),
                    "verified": True,
                })
                used_slugs.add(slug_clean)
            else:
                logger.warning(f"Draft references unknown internal link slug: {slug}. Preserving anchor text without 404.")
                # Neutralize broken link: keep anchor text, strip broken URL
                draft = draft.replace(f"[{anchor}]({full_url})", anchor)

    # Deterministic fallback: if LLM included zero internal links, inject top candidate
    if len(found_links) < min_links and candidates:
        top_candidates = [c for c in candidates if c["slug"].lower() not in used_slugs][:max_links]
        if top_candidates:
            # Build an editorial callout box before the conclusion or near the bottom
            related_items = "\n".join([
                f"> - **[{c['title']}](/posts/{c['slug']})**: Deep dive on related architectural patterns and implementation trade-offs."
                for c in top_candidates
            ])
            cluster_callout = f"""

> [!NOTE]
> **Related Topic Cluster Analyses:**
{related_items}

"""
            # Insert before ## Conclusion, ## References, ## Summary, or at end
            m = re.search(r'(?im)^##\s*(?:conclusion|references|summary|final thoughts)\b', draft)
            if m:
                idx = m.start()
                draft = f"{draft[:idx].rstrip()}\n\n{cluster_callout.strip()}\n\n{draft[idx:].lstrip()}"
            else:
                draft = f"{draft.rstrip()}\n\n{cluster_callout.strip()}\n"

            for c in top_candidates:
                found_links.append({
                    "anchor": c["title"],
                    "url": f"/posts/{c['slug']}",
                    "slug": c["slug"],
                    "title": c["title"],
                    "verified": True,
                    "injected_fallback": True,
                })

    return draft, found_links


def extract_topic_cluster_summary(
    draft: str,
    title: str,
    slug: str,
    website_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Computes cluster metrics for the article inspector and research tab.
    """
    words = len(draft.split()) if draft else 0
    internal_links = re.findall(r'\[([^\]]+)\]\((/posts/([a-zA-Z0-9_\-\.]+))\)', draft or "")

    linked_posts = []
    seen = set()
    for anchor, url, post_slug in internal_links:
        if post_slug.lower() not in seen:
            seen.add(post_slug.lower())
            linked_posts.append({
                "anchor": anchor,
                "url": url,
                "slug": post_slug,
            })

    # Pillar criteria: 1400+ words with 2+ internal links
    is_pillar = words >= 1400 and len(linked_posts) >= 2
    cluster_role = "Pillar Authority Guide" if is_pillar else "Cluster Spoke Article"

    # Identify existing posts that could link TO this article (inbound suggestions)
    cluster_candidates = get_cluster_candidates(topic=title, website_id=website_id, exclude_slug=slug, limit=3)

    return {
        "cluster_role": cluster_role,
        "is_pillar": is_pillar,
        "outbound_internal_links": linked_posts,
        "outbound_count": len(linked_posts),
        "inbound_recommendations": cluster_candidates,
        "cluster_health_score": min(100, 70 + (len(linked_posts) * 10) + (10 if is_pillar else 0)),
    }


# =====================================================================
# CONTEXTUAL LINK PROPOSALS & HUMAN REVIEW WORKFLOW (Pillar A5)
# =====================================================================

def propose_contextual_internal_links(
    draft: str,
    new_post_slug: str,
    new_post_title: str,
    website_id: Optional[str] = None,
    min_links: int = 3,
    max_links: int = 5,
) -> Dict[str, Any]:
    """
    Embeds the draft and existing articles:
    - Proposes 3-5 contextual outbound links with descriptive anchor text from draft to existing articles.
    - Proposes inbound links from related existing articles pointing to the new article.
    - Humans can reject or approve each proposal in the UI or Slack gate.
    """
    candidates = get_cluster_candidates(
        topic=new_post_title,
        website_id=website_id,
        exclude_slug=new_post_slug,
        limit=max_links + 3,
    )

    outbound_proposals: List[Dict[str, Any]] = []
    inbound_proposals: List[Dict[str, Any]] = []

    if not draft or not candidates:
        return {
            "outbound_proposals": [],
            "inbound_proposals": [],
            "total_proposed": 0,
            "can_auto_apply": False,
        }

    # Split draft into paragraphs / sentences
    paragraphs = [p.strip() for p in draft.split("\n\n") if p.strip() and not p.startswith("#")]

    # 1. Generate Outbound Proposals (Draft -> Existing articles)
    used_targets = set()
    for idx, cand in enumerate(candidates[:max_links]):
        target_slug = cand["slug"]
        target_title = cand["title"]
        sim = cand.get("similarity", 0.75)

        # Find best paragraph in draft that discusses concepts related to candidate
        best_para = ""
        best_anchor = target_title
        words_target = set(re.findall(r"\b\w{4,}\b", target_title.lower()))

        for p in paragraphs:
            p_lower = p.lower()
            overlap = sum(1 for w in words_target if w in p_lower)
            if overlap >= 1:
                best_para = p
                # Attempt to find a subphrase for the anchor
                for w in words_target:
                    match = re.search(rf"\b({w}(?:\s+\w+){{0,3}})\b", p, re.IGNORECASE)
                    if match and len(match.group(1)) >= len(w):
                        best_anchor = match.group(1)
                        break
                break

        if not best_para and paragraphs:
            best_para = paragraphs[min(idx, len(paragraphs) - 1)]

        outbound_proposals.append({
            "id": f"outbound-{idx + 1}",
            "type": "outbound",
            "source_slug": new_post_slug,
            "source_title": new_post_title,
            "target_slug": target_slug,
            "target_title": target_title,
            "target_url": f"/posts/{target_slug}",
            "anchor_text": best_anchor,
            "context_sentence": best_para[:160] + ("..." if len(best_para) > 160 else ""),
            "relevance_score": sim,
            "status": "proposed",  # proposed | approved | rejected
            "review_comment": None,
        })
        used_targets.add(target_slug.lower())
        if len(outbound_proposals) >= max_links:
            break

    # 2. Generate Inbound Proposals (Related existing articles -> New post)
    for idx, cand in enumerate(candidates[:3]):
        inbound_proposals.append({
            "id": f"inbound-{idx + 1}",
            "type": "inbound",
            "source_slug": cand["slug"],
            "source_title": cand["title"],
            "target_slug": new_post_slug,
            "target_title": new_post_title,
            "target_url": f"/posts/{new_post_slug}",
            "anchor_text": new_post_title,
            "suggested_placement": f"Add contextual link in '{cand['title']}' referencing our deep dive on {new_post_title}.",
            "relevance_score": cand.get("similarity", 0.70),
            "status": "proposed",
            "review_comment": None,
        })

    return {
        "outbound_proposals": outbound_proposals,
        "inbound_proposals": inbound_proposals,
        "total_proposed": len(outbound_proposals) + len(inbound_proposals),
        "guidance": "Humans can reject or approve each proposal. Approved links are woven contextually into Markdown.",
    }


def update_link_proposal_status(
    proposals: List[Dict[str, Any]],
    proposal_id: str,
    new_status: str,
    comment: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Updates the review status of a specific internal link proposal (approved | rejected | proposed).
    """
    valid_statuses = {"approved", "rejected", "proposed"}
    target_status = new_status.lower() if new_status.lower() in valid_statuses else "proposed"

    updated = []
    for p in proposals:
        item = dict(p)
        if item.get("id") == proposal_id:
            item["status"] = target_status
            if comment:
                item["review_comment"] = comment
        updated.append(item)
    return updated


def apply_approved_outbound_links(
    draft: str,
    proposals: List[Dict[str, Any]],
) -> str:
    """
    Applies only human-approved outbound link proposals into the draft markdown.
    Avoids duplicate links and preserves non-approved proposal text.
    """
    if not draft or not proposals:
        return draft

    modified_draft = draft
    for p in proposals:
        if p.get("type") == "outbound" and p.get("status") == "approved":
            anchor = p.get("anchor_text")
            target_url = p.get("target_url")
            if not anchor or not target_url:
                continue

            # Check if link is already present
            if f"({target_url})" in modified_draft:
                continue

            # Replace first instance of anchor not already in markdown link
            pattern = re.compile(rf"(?<!\[)\b({re.escape(anchor)})\b(?!\])", re.IGNORECASE)
            if pattern.search(modified_draft):
                modified_draft = pattern.sub(f"[{anchor}]({target_url})", modified_draft, count=1)

    return modified_draft

