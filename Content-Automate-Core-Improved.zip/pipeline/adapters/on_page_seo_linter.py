"""
On-Page SEO, Answer-First & Quality Linting Engine (Pillar A5).

Core capabilities:
1. Meta title, description, and slug validation from brief with configurable length checks.
   Cross-checked against Pillar A4 fact-verification status.
2. Answer-first lint:
   - Each major section (H2/H3) checked for an immediate direct answer / lead sentence.
   - Word count targets (40-160 words) are configurable warnings, NOT hard failure rules.
   - Detection of preamble fluff ("In today's digital world...", "It is important to note that...", etc.).
3. Quality lint:
   - Readability / Textstat metrics (Flesch Reading Ease, Flesch-Kincaid Grade Level, sentence length).
   - Banned phrases / AI clichés list (configurable per tenant).
   - "Every statistic has a source": Extracts empirical figures (%, $, ms, metrics) and flags unbacked stats.
   - Byline and updated-date presence verification.
   - No unsourced superlatives: Flags claims like "the best", "the fastest", "the #1", "unrivaled"
     unless accompanied by empirical citation / source.
"""

from __future__ import annotations

import logging
import math
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple
from pydantic import BaseModel, Field

logger = logging.getLogger("pipeline.adapters.on_page_seo_linter")

# ---------------------------------------------------------------------------
# Default Configuration Constants
# ---------------------------------------------------------------------------

DEFAULT_BANNED_PHRASES = [
    "delve into",
    "delving into",
    "in today's fast-paced world",
    "in today's digital world",
    "in the modern era",
    "tapestry",
    "testament to",
    "beacon",
    "game-changer",
    "game changer",
    "unlock the potential",
    "harness the power",
    "it is important to note that",
    "it's worth noting that",
    "dive deep",
    "dive in",
    "a myriad of",
    "in conclusion",
    "to sum up",
    "needless to say",
    "it goes without saying",
    "revolutionize the way",
    "at the end of the day",
]

UNSOURCED_SUPERLATIVES = [
    r"\bthe\s+best\b",
    r"\bthe\s+fastest\b",
    r"\bthe\s+most\s+powerful\b",
    r"\bthe\s+most\s+popular\b",
    r"\bthe\s+#1\b",
    r"\bnumber\s+one\b",
    r"\bunrivaled\b",
    r"\bunmatched\b",
    r"\bunparalleled\b",
    r"\bindustry-leading\b",
    r"\bworld's\s+first\b",
    r"\brevolutionary\b",
    r"\bgroundbreaking\b",
]

PREAMBLE_FLUFF_PATTERNS = [
    re.compile(r"^in\s+(?:today['’]s|the)\s+(?:[a-z-]+\s+)*digital\s+world", re.IGNORECASE),
    re.compile(r"^in\s+(?:today['’]s|the)\s+(?:[a-z-]+\s+)*(?:landscape|era|society)", re.IGNORECASE),
    re.compile(r"^it\s+is\s+(?:important|crucial|essential|worth\s+noting)\s+to\s+(?:note|understand|mention)", re.IGNORECASE),
    re.compile(r"\bdive\s+(?:deep|in)\b", re.IGNORECASE),
    re.compile(r"^when\s+it\s+comes\s+to\s+[a-z\s]+,\s+one\s+might\s+wonder", re.IGNORECASE),
    re.compile(r"^as\s+we\s+navigate\s+the\s+complexities\s+of", re.IGNORECASE),
]


class MetaLengthConfig(BaseModel):
    title_min: int = 30
    title_max: int = 65
    title_target_min: int = 50
    title_target_max: int = 60
    desc_min: int = 70
    desc_max: int = 165
    desc_target_min: int = 120
    desc_target_max: int = 160
    slug_max_len: int = 75


# ---------------------------------------------------------------------------
# 1. Meta Title, Description, and Slug Validation
# ---------------------------------------------------------------------------

def validate_meta_elements(
    title: str,
    meta_description: str,
    slug: str,
    config: Optional[MetaLengthConfig] = None,
    fact_verification_report: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Validates meta title, description, and slug with configurable length checks.
    Integrates with A4 fact-verification status.
    """
    cfg = config or MetaLengthConfig()
    issues: List[Dict[str, Any]] = []
    warnings: List[Dict[str, Any]] = []

    clean_title = (title or "").strip()
    clean_desc = (meta_description or "").strip()
    clean_slug = (slug or "").strip().lower()

    # --- Title Checks ---
    title_len = len(clean_title)
    if not clean_title:
        issues.append({"field": "meta_title", "issue": "Missing title", "severity": "error"})
    elif title_len < cfg.title_min:
        warnings.append({
            "field": "meta_title",
            "issue": f"Title is short ({title_len} chars). Google may rewrite titles under {cfg.title_min} chars.",
            "current_length": title_len,
            "target_range": f"{cfg.title_target_min}-{cfg.title_target_max}",
            "severity": "warning",
        })
    elif title_len > cfg.title_max:
        warnings.append({
            "field": "meta_title",
            "issue": f"Title is long ({title_len} chars). May truncate on Google SERP (recommended max {cfg.title_max}).",
            "current_length": title_len,
            "target_range": f"{cfg.title_target_min}-{cfg.title_target_max}",
            "severity": "warning",
        })

    # --- Description Checks ---
    desc_len = len(clean_desc)
    if not clean_desc:
        issues.append({"field": "meta_description", "issue": "Missing meta description", "severity": "error"})
    elif desc_len < cfg.desc_min:
        warnings.append({
            "field": "meta_description",
            "issue": f"Meta description is short ({desc_len} chars). Optimal snippet length is {cfg.desc_target_min}-{cfg.desc_target_max} chars.",
            "current_length": desc_len,
            "target_range": f"{cfg.desc_target_min}-{cfg.desc_target_max}",
            "severity": "warning",
        })
    elif desc_len > cfg.desc_max:
        warnings.append({
            "field": "meta_description",
            "issue": f"Meta description is long ({desc_len} chars). Will truncate on desktop/mobile SERPs.",
            "current_length": desc_len,
            "target_range": f"{cfg.desc_target_min}-{cfg.desc_target_max}",
            "severity": "warning",
        })

    # --- Slug Checks ---
    slug_valid_pattern = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    if not clean_slug:
        issues.append({"field": "slug", "issue": "Missing URL slug", "severity": "error"})
    elif not slug_valid_pattern.match(clean_slug):
        issues.append({
            "field": "slug",
            "issue": "Slug must be lowercase alphanumeric with single hyphens (kebab-case). No spaces or special characters.",
            "current_slug": clean_slug,
            "severity": "error",
        })
    elif len(clean_slug) > cfg.slug_max_len:
        warnings.append({
            "field": "slug",
            "issue": f"Slug is lengthy ({len(clean_slug)} chars). Keep under {cfg.slug_max_len} chars for better user readability.",
            "current_length": len(clean_slug),
            "severity": "warning",
        })

    # --- A4 Fact-Verification Cross-Check ---
    meta_verified_in_a4 = False
    if fact_verification_report:
        surfaces = fact_verification_report.get("surfaces_checked", {})
        title_verified = surfaces.get("title", {}).get("checked", False)
        desc_verified = surfaces.get("meta_description", {}).get("checked", False)
        meta_verified_in_a4 = title_verified and desc_verified

    passed = len(issues) == 0

    return {
        "passed": passed,
        "title_length": title_len,
        "description_length": desc_len,
        "slug_length": len(clean_slug),
        "issues": issues,
        "warnings": warnings,
        "checked_in_a4": meta_verified_in_a4,
        "config_applied": cfg.model_dump(),
    }


# ---------------------------------------------------------------------------
# 2. Answer-First Lint (Configurable Warnings, Not Rules)
# ---------------------------------------------------------------------------

def lint_answer_first(
    draft: str,
    target_min_words: int = 35,
    target_max_words: int = 160,
) -> Dict[str, Any]:
    """
    Evaluates each major section (H2/H3) for answer-first composition.
    Length targets are treated as configurable WARNINGS, not blocking rules.
    Flags preamble fluff so authors can lead with the direct answer.
    """
    if not draft:
        return {
            "passed": False,
            "sections_audited": 0,
            "warnings": [{"section": "Entire Document", "message": "Draft is empty"}],
            "answer_first_count": 0,
        }

    sections = re.split(r"\n(?=#{2,3}\s+)", draft)
    audited_sections = []
    warnings = []
    answer_first_count = 0

    question_words = ("what", "how", "why", "when", "where", "who", "which", "is", "are", "can", "does", "should", "best")

    for sec in sections:
        sec = sec.strip()
        if not sec.startswith("#"):
            continue

        lines = [line.strip() for line in sec.splitlines() if line.strip()]
        heading_line = lines[0] if lines else ""
        heading_clean = re.sub(r"^#{2,3}\s+", "", heading_line).strip()
        is_h2 = heading_line.startswith("## ")
        is_question = heading_clean.endswith("?") or heading_clean.lower().startswith(question_words)

        body_paras = [p for p in lines[1:] if p and not p.startswith("#")]
        if not body_paras:
            continue

        lead_para = body_paras[0]
        words = lead_para.split()
        word_count = len(words)

        # Fluff check
        has_fluff = any(p.search(lead_para) for p in PREAMBLE_FLUFF_PATTERNS)
        fluff_warning = None
        if has_fluff:
            fluff_warning = "Section opens with preamble fluff. Lead immediately with the direct answer/thesis."
            warnings.append({
                "heading": heading_clean,
                "type": "preamble_fluff",
                "message": fluff_warning,
                "severity": "warning",
            })

        # Length target warning (NOT a rule)
        length_warning = None
        if word_count < target_min_words:
            length_warning = f"Lead paragraph is short ({word_count} words). Recommended sweet spot is {target_min_words}-{target_max_words} words."
            warnings.append({
                "heading": heading_clean,
                "type": "answer_length_short",
                "message": length_warning,
                "severity": "warning",
            })
        elif word_count > target_max_words:
            length_warning = f"Lead paragraph is long ({word_count} words). Recommended sweet spot for AI extraction is {target_min_words}-{target_max_words} words."
            warnings.append({
                "heading": heading_clean,
                "type": "answer_length_long",
                "message": length_warning,
                "severity": "warning",
            })

        is_answer_first = not has_fluff and (target_min_words <= word_count <= target_max_words)
        if is_answer_first:
            answer_first_count += 1

        audited_sections.append({
            "heading": heading_clean,
            "is_h2": is_h2,
            "is_question": is_question,
            "lead_word_count": word_count,
            "is_answer_first": is_answer_first,
            "lead_snippet": lead_para[:120] + ("..." if len(lead_para) > 120 else ""),
        })

    # Pass condition: at least 1 answer-first block, and no unaddressed preamble fluff in question sections
    passed = answer_first_count >= 1

    return {
        "passed": passed,
        "sections_audited": len(audited_sections),
        "answer_first_count": answer_first_count,
        "warnings": warnings,
        "sections": audited_sections,
        "guidance": "Length targets are configurable editorial warnings, never hard blocking rules.",
    }


# ---------------------------------------------------------------------------
# 3. Readability & Textstat Utility (Pure Python + textstat optional)
# ---------------------------------------------------------------------------

def _count_syllables_word(word: str) -> int:
    word = word.lower().strip(".:;?!'\"")
    if not word:
        return 0
    if len(word) <= 3:
        return 1
    # Count vowel groups
    word = re.sub(r"(?:[^laeiouy]|ed|es|e)$", "", word)
    word = re.sub(r"^y", "", word)
    syllables = len(re.findall(r"[aeiouy]{1,2}", word))
    return max(1, syllables)


def calculate_readability(text: str) -> Dict[str, Any]:
    """
    Computes Flesch Reading Ease and Flesch-Kincaid Grade Level.
    Uses 'textstat' if installed, otherwise uses standard formula.
    """
    try:
        import textstat
        flesch_reading_ease = round(textstat.flesch_reading_ease(text), 1)
        grade_level = round(textstat.flesch_kincaid_grade(text), 1)
        avg_func = getattr(textstat, "words_per_sentence", None) or getattr(textstat, "avg_sentence_length")
        avg_sentence_len = round(avg_func(text), 1)
        engine = "textstat"
    except ImportError:
        sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
        words = re.findall(r"\b[a-zA-Z0-9'-]+\b", text)
        total_sentences = max(1, len(sentences))
        total_words = max(1, len(words))
        total_syllables = sum(_count_syllables_word(w) for w in words)

        # Flesch Reading Ease = 206.835 - 1.015 * (words/sentences) - 84.6 * (syllables/words)
        asl = total_words / total_sentences
        asw = total_syllables / total_words
        flesch_reading_ease = round(206.835 - (1.015 * asl) - (84.6 * asw), 1)
        flesch_reading_ease = max(0.0, min(100.0, flesch_reading_ease))

        # Flesch-Kincaid Grade Level = 0.39 * (words/sentences) + 11.8 * (syllables/words) - 15.59
        grade_level = round((0.39 * asl) + (11.8 * asw) - 15.59, 1)
        grade_level = max(1.0, grade_level)
        avg_sentence_len = round(asl, 1)
        engine = "native_formula"

    # Evaluation
    if flesch_reading_ease >= 60:
        ease_label = "Standard / Accessible"
    elif flesch_reading_ease >= 45:
        ease_label = "Technical / Professional"
    else:
        ease_label = "Complex / Academic"

    return {
        "flesch_reading_ease": flesch_reading_ease,
        "flesch_kincaid_grade": grade_level,
        "avg_sentence_length": avg_sentence_len,
        "reading_ease_label": ease_label,
        "engine": engine,
    }


# ---------------------------------------------------------------------------
# 4. Quality Lint (Banned Phrases, Sourced Stats, Byline, Superlatives)
# ---------------------------------------------------------------------------

def lint_quality_standards(
    draft: str,
    author: Optional[str] = None,
    published_at: Optional[str] = None,
    updated_at: Optional[str] = None,
    banned_phrases: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Executes editorial quality linting:
    1. Readability metrics (textstat).
    2. Banned phrases (AI clichés).
    3. 'Every statistic has a source': Checks empirical figures for nearby citation or source attribution.
    4. Byline and updated-date presence.
    5. Unsourced superlatives detector.
    """
    warnings: List[Dict[str, Any]] = []
    banned_list = banned_phrases if banned_phrases is not None else DEFAULT_BANNED_PHRASES

    # 1. Readability
    readability = calculate_readability(draft)

    # 2. Banned Phrases
    clean_lower = draft.lower()
    detected_banned = []
    for phrase in banned_list:
        p_clean = phrase.lower().strip()
        if not p_clean:
            continue
        matches = len(re.findall(re.escape(p_clean), clean_lower))
        if matches > 0:
            detected_banned.append({"phrase": phrase, "count": matches})
            warnings.append({
                "type": "banned_phrase",
                "message": f"Contains AI cliché or banned phrase: '{phrase}' ({matches}x)",
                "severity": "warning",
            })

    # 3. 'Every statistic has a source' Check
    stat_pattern = re.compile(
        r"(\b\d+(?:\.\d+)?%|\$\d+(?:\.\d+)?[kmb]?|\b\d+(?:\.\d+)?\s*(?:ms|seconds|minutes|hours|GB|TB|users|TPS|FPS|x)\b)",
        re.IGNORECASE,
    )
    # Attribution signals
    source_attribution_pattern = re.compile(
        r"(?:according\s+to|source:|cited\s+by|reported\s+by|study\s+by|data\s+from|per|benchmark|\[[^\]]+\]\(https?://|\(\s*https?://)",
        re.IGNORECASE,
    )

    sentences = re.split(r"(?<=[.!?])\s+", draft)
    unsourced_statistics = []
    total_stats_found = 0

    for s in sentences:
        s_clean = s.strip()
        stat_matches = stat_pattern.findall(s_clean)
        if not stat_matches:
            continue

        total_stats_found += len(stat_matches)
        has_source = bool(source_attribution_pattern.search(s_clean))

        if not has_source:
            for st in stat_matches:
                unsourced_statistics.append({
                    "statistic": st,
                    "sentence_snippet": s_clean[:140] + ("..." if len(s_clean) > 140 else ""),
                })
                warnings.append({
                    "type": "unsourced_statistic",
                    "message": f"Statistic '{st}' appears without explicit source citation or attribution link.",
                    "severity": "warning",
                })

    # 4. Byline and Dates Presence
    has_valid_author = bool(
        author and author.strip() and author.lower() not in ("admin", "user", "anonymous", "editorial", "")
    )
    if not has_valid_author:
        warnings.append({
            "type": "missing_byline",
            "message": "Missing named author byline. Google E-E-A-T requires a verified human or expert contributor.",
            "severity": "warning",
        })

    has_dates = bool(published_at or updated_at)
    if not has_dates:
        warnings.append({
            "type": "missing_updated_date",
            "message": "Missing published_at or updated_at timestamps for freshness signals.",
            "severity": "warning",
        })

    # 5. Unsourced Superlatives
    unsourced_superlatives = []
    for sup_regex in UNSOURCED_SUPERLATIVES:
        for m in re.finditer(sup_regex, clean_lower):
            sup_word = m.group(0)
            # Find enclosing sentence
            span_start = max(0, m.start() - 100)
            span_end = min(len(draft), m.end() + 100)
            surrounding = draft[span_start:span_end]
            has_source = bool(source_attribution_pattern.search(surrounding))
            if not has_source:
                unsourced_superlatives.append(sup_word)
                warnings.append({
                    "type": "unsourced_superlative",
                    "message": f"Superlative claim '{sup_word}' lacks immediate cited benchmark or supporting source.",
                    "severity": "warning",
                })

    passed = (
        len(detected_banned) == 0
        and has_valid_author
        and has_dates
        and len(unsourced_statistics) <= 2
    )

    return {
        "passed": passed,
        "readability": readability,
        "banned_phrases_detected": detected_banned,
        "total_statistics_count": total_stats_found,
        "unsourced_statistics_count": len(unsourced_statistics),
        "unsourced_statistics": unsourced_statistics[:5],
        "has_author_byline": has_valid_author,
        "has_dates": has_dates,
        "unsourced_superlatives": list(set(unsourced_superlatives)),
        "warnings": warnings,
        "warning_count": len(warnings),
    }


# ---------------------------------------------------------------------------
# 5. Master On-Page SEO Linter
# ---------------------------------------------------------------------------

def run_on_page_seo_audit(
    draft: str,
    title: str,
    meta_description: str,
    slug: str,
    author: Optional[str] = None,
    published_at: Optional[str] = None,
    updated_at: Optional[str] = None,
    meta_config: Optional[MetaLengthConfig] = None,
    banned_phrases: Optional[List[str]] = None,
    fact_verification_report: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Executes the full suite of On-Page SEO checks, Answer-First lint, and Quality lint.
    """
    meta_res = validate_meta_elements(
        title=title,
        meta_description=meta_description,
        slug=slug,
        config=meta_config,
        fact_verification_report=fact_verification_report,
    )

    answer_res = lint_answer_first(draft)

    quality_res = lint_quality_standards(
        draft=draft,
        author=author,
        published_at=published_at,
        updated_at=updated_at,
        banned_phrases=banned_phrases,
    )

    all_warnings = meta_res["warnings"] + answer_res["warnings"] + quality_res["warnings"]
    all_issues = meta_res["issues"]

    overall_passed = meta_res["passed"] and len(all_issues) == 0

    return {
        "passed": overall_passed,
        "meta_validation": meta_res,
        "answer_first_lint": answer_res,
        "quality_lint": quality_res,
        "issues": all_issues,
        "warnings": all_warnings,
        "warning_count": len(all_warnings),
        "issue_count": len(all_issues),
    }
