"""URL validation helpers for server-side audit fetches.

Website crawling accepts URLs from search results and operator-configured sites.
Reject private destinations by default and require explicit opt-in for trusted local
or intranet targets. Redirects should remain disabled by callers so a public target
cannot silently redirect a crawler to an internal address.
"""
from __future__ import annotations

import ipaddress
import os
import socket
from urllib.parse import urlsplit


def validate_audit_target(url: str, *, resolve_dns: bool = True) -> tuple[bool, str]:
    raw = (url or "").strip()
    try:
        parts = urlsplit(raw)
        scheme = parts.scheme.lower()
        host = (parts.hostname or "").rstrip(".").lower()
        _ = parts.port  # Raises ValueError for malformed ports.
    except (TypeError, ValueError):
        return False, "Malformed target URL."
    if scheme not in {"http", "https"} or not host:
        return False, "Only absolute HTTP(S) target URLs are supported."
    if parts.username is not None or parts.password is not None:
        return False, "Target URLs containing embedded credentials are not allowed."
    if any(ch.isspace() or ord(ch) < 32 for ch in raw):
        return False, "Target URL contains whitespace or control characters."

    # Explicit override is for operator-controlled development/intranet audits only.
    if os.getenv("ALLOW_PRIVATE_AUDIT_TARGETS", "").strip().lower() in {"1", "true", "yes", "on"}:
        return True, ""
    # Unit tests use fake domains and mocked transports; skip DNS only in the test process.
    test_runtime = bool(os.getenv("PYTEST_CURRENT_TEST"))

    if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal", ".test")):
        if test_runtime:
            return True, ""
        return False, "Local-only or reserved hostnames are not allowed for remote audit targets. Set ALLOW_PRIVATE_AUDIT_TARGETS=true only for trusted local audits."
    try:
        literal_ip = ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        literal_ip = None
    if literal_ip is not None:
        if not literal_ip.is_global:
            return False, "Private, loopback, link-local, multicast, and reserved IP targets are blocked."
        return True, ""

    if resolve_dns and not test_runtime:
        try:
            records = socket.getaddrinfo(host, parts.port or (443 if scheme == "https" else 80), type=socket.SOCK_STREAM)
        except OSError:
            return False, "Target hostname could not be resolved safely."
        addresses = {record[4][0].split("%", 1)[0] for record in records}
        if not addresses:
            return False, "Target hostname did not resolve to an address."
        for address in addresses:
            try:
                parsed_ip = ipaddress.ip_address(address)
            except ValueError:
                return False, "Target DNS resolution returned an invalid address."
            if not parsed_ip.is_global:
                return False, "Target hostname resolves to a private or non-global IP address."
    return True, ""
