"""
Self-Critique & Targeted Section Revision Loop (Pillar A3.3).

Executes the editorial self-critique loop:
Draft -> Critic (checks brief coverage, repetition, vague claims, tone) -> Revise.
Max 2 loops, then hands off to fact-check (A4).
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, List, Literal, Optional, Tuple
from pydantic import BaseModel, Field

from pipeline.adapters.structured_draft import StructuredDraft, DraftSection, ClaimCitation
from pipeline.adapters.prompt_manager import render_prompt
from pipeline.adapters.model_router import routed_call_llm, ROLE_CRITIC, ROLE_DRAFTING
from pipeline.utils import extract_json_block

logger = logging.getLogger("pipeline.adapters.self_critic")


class SectionCritique(BaseModel):
    """Critique evaluation for an individual section."""
    heading: str
    needs_revision: bool = False
    critique: str = ""
    suggested_actions: List[str] = Field(default_factory=list)


class DraftCritique(BaseModel):
    """Complete editorial evaluation of the article draft."""
    score: float = Field(..., ge=0.0, le=100.0, description="Overall editorial quality score 0-100")
    passed: bool = Field(..., description="True if score >= 85 and no critical blocking issues")
    summary: str = Field(..., description="Summary of critique findings")
    brief_coverage_score: float = Field(85.0, description="Score on brief adherence")
    repetition_issues: List[str] = Field(default_factory=list)
    vague_claim_issues: List[str] = Field(default_factory=list)
    banned_words_found: List[str] = Field(default_factory=list)
    section_critiques: List[SectionCritique] = Field(default_factory=list)


def evaluate_draft_critique(
    draft: StructuredDraft,
    brief: Any,
    style_profile: Dict[str, Any],
) -> DraftCritique:
    """
    Invokes the stronger critic model to evaluate the draft against:
    - Brief coverage (required sections, questions, entities)
    - Repetition and redundancy across sections
    - Vague claims without citations or data
    - Brand voice, sentence rhythm, and banned AI cliches
    """
    # Deterministic scan for banned words
    banned_list = style_profile.get("banned_phrases") or []
    detected_banned: List[str] = []
    draft_markdown = draft.to_markdown().lower()
    for word in banned_list:
        if re.search(rf"\b{re.escape(word.lower())}\b", draft_markdown):
            detected_banned.append(word)

    # Format brief data if it's a Pydantic object
    brief_data = brief.model_dump() if hasattr(brief, "model_dump") else (brief or {})

    context = {
        "draft": draft,
        "brief": brief_data,
        "style_profile": style_profile,
    }

    try:
        prompt_text, _ver = render_prompt("self_critic", context, version="v1.0.0")
        system_instruction = (
            "You are an uncompromising Lead Content Editor. Evaluate the draft rigorously against "
            "empirical depth, factual precision, and elimination of generic AI writing tells."
        )

        response_text, _telemetry = routed_call_llm(
            role=ROLE_CRITIC,
            prompt=prompt_text,
            system_instruction=system_instruction,
            temperature=0.2,
        )

        parsed = extract_json_block(response_text)
        if not parsed:
            raise ValueError(f"Could not parse critique JSON from: {response_text[:200]}")

        # Combine deterministic banned words with model-detected words
        model_banned = parsed.get("banned_words_found") or []
        combined_banned = sorted(list(set(detected_banned + model_banned)))

        score = float(parsed.get("score", 85.0))
        # Deduct score if banned words found
        if combined_banned:
            score = max(0.0, score - (len(combined_banned) * 4.0))

        passed = score >= 85.0 and len(combined_banned) == 0

        section_critiques = []
        for sc in parsed.get("section_critiques", []):
            section_critiques.append(SectionCritique(
                heading=sc.get("heading", ""),
                needs_revision=bool(sc.get("needs_revision", False)),
                critique=sc.get("critique", ""),
                suggested_actions=sc.get("suggested_actions") or [],
            ))

        return DraftCritique(
            score=round(score, 1),
            passed=passed,
            summary=parsed.get("summary", "Automated critique completed."),
            brief_coverage_score=float(parsed.get("brief_coverage_score", 85.0)),
            repetition_issues=parsed.get("repetition_issues") or [],
            vague_claim_issues=parsed.get("vague_claim_issues") or [],
            banned_words_found=combined_banned,
            section_critiques=section_critiques,
        )

    except Exception as e:
        logger.warning(f"Critic model evaluation failed ({e}), performing rule-based fallback critique")
        passed = len(detected_banned) == 0
        return DraftCritique(
            score=88.0 if passed else 75.0,
            passed=passed,
            summary="Rule-based heuristic critique fallback.",
            brief_coverage_score=90.0,
            banned_words_found=detected_banned,
            repetition_issues=[],
            vague_claim_issues=[],
            section_critiques=[],
        )


def revise_draft_section(
    section: DraftSection,
    critique: SectionCritique,
    specific_issues: List[str],
    style_profile: Dict[str, Any],
) -> DraftSection:
    """
    Surgically revises a single section addressing the critic's actionable instructions
    while preserving existing verified data and citations.
    """
    context = {
        "section": section,
        "critique": critique,
        "specific_issues": specific_issues,
        "style_profile": style_profile,
    }

    try:
        prompt_text, _ver = render_prompt("section_revision", context, version="v1.0.0")
        system_instruction = (
            "You are an expert editorial writer surgically revising an article section. "
            "Address every critique directive directly and eliminate all vague assertions or repetition."
        )

        response_text, _telemetry = routed_call_llm(
            role=ROLE_DRAFTING,
            prompt=prompt_text,
            system_instruction=system_instruction,
            temperature=0.4,
        )

        parsed = extract_json_block(response_text)
        if not parsed:
            return section

        revised_claims = []
        for c in parsed.get("claims", []):
            if isinstance(c, dict) and c.get("claim_text"):
                revised_claims.append(ClaimCitation(
                    claim_text=c["claim_text"],
                    source_url=c.get("source_url"),
                    anchor_text=c.get("anchor_text"),
                    citation_type=c.get("citation_type", "empirical_fact"),
                ))

        section.direct_answer = parsed.get("direct_answer", section.direct_answer)
        section.markdown_content = parsed.get("markdown_content", section.markdown_content)
        if revised_claims:
            section.claims = revised_claims
        if parsed.get("citations"):
            section.citations = parsed.get("citations")
        if parsed.get("key_entities_covered"):
            section.key_entities_covered = parsed.get("key_entities_covered")

        # Recalculate section word count
        words = len(re.findall(r"\b\w+\b", section.markdown_content))
        section.word_count = words
        return section

    except Exception as e:
        logger.warning(f"Section revision failed for '{section.heading}': {e}")
        return section


def execute_critique_and_revision_loop(
    draft: StructuredDraft,
    brief: Any,
    style_profile: Dict[str, Any],
    max_loops: int = 2,
) -> Tuple[StructuredDraft, DraftCritique, int]:
    """
    Runs the self-critique loop:
    Draft -> Critic -> Revise (max 2 loops) -> Hand to fact check (A4).
    """
    current_draft = draft
    final_critique: Optional[DraftCritique] = None
    loops_executed = 0

    for loop in range(max_loops):
        loops_executed = loop + 1
        logger.info(f"Self-critique loop iteration {loops_executed}/{max_loops} starting...")
        critique = evaluate_draft_critique(current_draft, brief, style_profile)
        final_critique = critique
        current_draft.critique_score = critique.score

        if critique.passed:
            logger.info(f"Self-critique passed on iteration {loops_executed} (score: {critique.score})")
            break

        logger.info(
            f"Self-critique loop {loops_executed} flagged issues (score: {critique.score}). "
            f"Revising {len([sc for sc in critique.section_critiques if sc.needs_revision])} sections..."
        )

        # Map critique to sections
        critique_map = {sc.heading.lower().strip(): sc for sc in critique.section_critiques}
        for sec in current_draft.sections:
            sc = critique_map.get(sec.heading.lower().strip())
            if sc and sc.needs_revision:
                relevant_issues = [
                    iss for iss in critique.repetition_issues + critique.vague_claim_issues
                    if sec.heading.lower() in iss.lower()
                ]
                revise_draft_section(sec, sc, relevant_issues, style_profile)

        current_draft.recompute_metrics()

    if final_critique is None:
        final_critique = evaluate_draft_critique(current_draft, brief, style_profile)

    return current_draft, final_critique, loops_executed
