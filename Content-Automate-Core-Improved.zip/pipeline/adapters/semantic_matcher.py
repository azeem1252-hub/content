"""
Semantic Entity Matcher & Anti-Cannibalization Engine.

Implements the blueprint specification:
Matches prospective queries/topics against the target website's indexed inventory
using dense vector cosine similarity:
    Similarity(u, v) = (u . v) / (||u|| * ||v||)

If Similarity >= 0.82:
    Classified as an Entity Gap within an existing page.
    Triggers an autonomous content update/expansion workflow instead of drafting a redundant post.
If Similarity < 0.82:
    Classified as a Novel Topic. Triggers new article generation.
"""

import math
import re
import logging
from typing import List, Dict, Any, Optional, Set, Tuple

from pipeline.adapters.embedding_client import embed_texts, cosine_similarity as dense_cosine

logger = logging.getLogger("pipeline.adapters.semantic_matcher")

# TF-IDF cosine operates on a different scale than dense embedding cosine, so
# the two paths use separate thresholds. Dense embeddings separate paraphrases
# from near-duplicates more sharply, which is why the bar sits higher.
CANNIBALIZATION_THRESHOLD = 0.82
EMBEDDING_CANNIBALIZATION_THRESHOLD = 0.88

STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "an", "and", "any",
    "are", "as", "at", "be", "because", "been", "before", "being", "below", "between",
    "both", "but", "by", "can", "did", "do", "does", "doing", "don", "down", "during",
    "each", "few", "for", "from", "further", "had", "has", "have", "having", "he",
    "her", "here", "hers", "herself", "him", "himself", "his", "how", "if", "in",
    "into", "is", "it", "its", "itself", "just", "me", "more", "most", "my", "myself",
    "no", "nor", "not", "now", "of", "off", "on", "once", "only", "or", "other",
    "our", "ours", "ourselves", "out", "over", "own", "s", "same", "she", "should",
    "so", "some", "such", "t", "than", "that", "the", "their", "theirs", "them",
    "themselves", "then", "there", "these", "they", "this", "those", "through",
    "to", "too", "under", "until", "up", "very", "was", "we", "were", "what",
    "when", "where", "which", "while", "who", "whom", "why", "will", "with", "you",
    "your", "yours", "yourself", "yourselves", "guide", "overview", "2025", "2026"
}


def _tokenize(text: str) -> List[str]:
    """Tokenizes text into normalized content words and character 3-grams."""
    clean = re.sub(r"[^a-zA-Z0-9\s]", " ", (text or "").lower())
    words = [w for w in clean.split() if w not in STOPWORDS and len(w) >= 2]
    
    # Generate char 3-grams to capture subword morphology (e.g. 'cannibalize' vs 'cannibalization')
    ngrams = []
    for w in words:
        if len(w) >= 3:
            for i in range(len(w) - 2):
                ngrams.append(w[i:i+3])
    return words + ngrams


def build_term_vector(text: str, vocabulary: Dict[str, int]) -> List[float]:
    """Creates a normalized term-frequency vector given a shared vocabulary."""
    tokens = _tokenize(text)
    vec = [0.0] * len(vocabulary)
    for t in tokens:
        if t in vocabulary:
            vec[vocabulary[t]] += 1.0

    # L2 normalize
    norm = math.sqrt(sum(x * x for x in vec))
    if norm > 0:
        vec = [x / norm for x in vec]
    return vec


def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """
    Computes exact Cosine Similarity between two L2-normalized or dense vectors:
    Similarity(u, v) = (u . v) / (||u|| * ||v||)
    """
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0

    dot_product = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = math.sqrt(sum(a * a for a in vec_a))
    norm_b = math.sqrt(sum(b * b for b in vec_b))

    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0

    return dot_product / (norm_a * norm_b)


def evaluate_anti_cannibalization(
    candidate_topic: str,
    existing_posts: List[Dict[str, Any]],
    threshold: float = CANNIBALIZATION_THRESHOLD
) -> Dict[str, Any]:
    """
    Evaluates whether a candidate topic risks cannibalizing an existing published post.
    
    Returns:
        {
            "is_entity_gap": bool,            # True if >= threshold (0.82)
            "max_similarity": float,          # Peak similarity score
            "matched_post": Optional[dict],    # Post dict if gap detected
            "matched_title": Optional[str],
            "recommendation": str             # 'refresh_existing' | 'create_new'
        }
    """
    if not candidate_topic or not existing_posts:
        return {
            "is_entity_gap": False,
            "max_similarity": 0.0,
            "matched_post": None,
            "matched_title": None,
            "recommendation": "create_new",
            "method": "none"
        }

    # Preferred path: dense embedding similarity (handles paraphrase/synonym
    # overlap that bag-of-words cosine misses). Falls back to TF-IDF below when
    # the embedding call fails for any reason.
    dense_result = _evaluate_with_embeddings(candidate_topic, existing_posts, threshold)
    if dense_result is not None:
        return dense_result

    # Build shared vocabulary across candidate and existing titles/excerpts
    corpus_tokens: Set[str] = set(_tokenize(candidate_topic))
    for p in existing_posts:
        p_text = f"{p.get('title', '')} {p.get('slug', '')} {p.get('excerpt', '')}"
        corpus_tokens.update(_tokenize(p_text))

    vocab = {token: idx for idx, token in enumerate(sorted(corpus_tokens))}
    candidate_vec = build_term_vector(candidate_topic, vocab)

    best_score = 0.0
    best_post = None

    for post in existing_posts:
        p_title = post.get("title", "")
        p_slug = post.get("slug", "")
        p_excerpt = post.get("excerpt", "")

        title_vec = build_term_vector(p_title, vocab)
        full_vec = build_term_vector(f"{p_title} {p_slug} {p_excerpt}", vocab)

        title_score = cosine_similarity(candidate_vec, title_vec)
        full_score = cosine_similarity(candidate_vec, full_vec)
        score = max(title_score, full_score)

        if score > best_score:
            best_score = score
            best_post = post

    is_gap = best_score >= threshold
    recommendation = "refresh_existing" if is_gap else "create_new"

    logger.info(
        f"Anti-cannibalization check for '{candidate_topic}': "
        f"max_similarity={best_score:.3f} (threshold={threshold}) -> {recommendation}"
    )

    return {
        "is_entity_gap": is_gap,
        "max_similarity": round(best_score, 3),
        "matched_post": best_post if is_gap else None,
        "matched_title": best_post.get("title") if (best_post and is_gap) else None,
        "matched_post_id": best_post.get("id") if (best_post and is_gap) else None,
        "recommendation": recommendation,
        "method": "tfidf"
    }


def _evaluate_with_embeddings(
    candidate_topic: str,
    existing_posts: List[Dict[str, Any]],
    threshold: float,
) -> Optional[Dict[str, Any]]:
    """Dense-embedding anti-cannibalization path. Returns None to trigger fallback."""
    try:
        titles = [p.get("title", "").strip() for p in existing_posts]
        corpus_texts = [
            f"{p.get('title', '')} {p.get('slug', '')} {p.get('excerpt', '')}".strip()
            for p in existing_posts
        ]
        all_texts = [candidate_topic] + titles + corpus_texts
        vectors = embed_texts(all_texts)
        if not vectors or len(vectors) != len(all_texts):
            return None
        candidate_vec = vectors[0]
        n_posts = len(existing_posts)
        title_vecs = vectors[1 : 1 + n_posts]
        corpus_vecs = vectors[1 + n_posts :]

        best_score = 0.0
        best_post = None
        for post, t_vec, c_vec in zip(existing_posts, title_vecs, corpus_vecs):
            score = max(dense_cosine(candidate_vec, t_vec), dense_cosine(candidate_vec, c_vec))
            if score > best_score:
                best_score = score
                best_post = post

        from pipeline.adapters.embedding_client import last_used_provider
        effective_threshold = EMBEDDING_CANNIBALIZATION_THRESHOLD if last_used_provider() != "local" else threshold
        is_gap = best_score >= effective_threshold
        logger.info(
            f"Anti-cannibalization (embedding) for '{candidate_topic}': "
            f"max_similarity={best_score:.3f} (threshold={effective_threshold}) -> "
            f"{'refresh_existing' if is_gap else 'create_new'}"
        )
        return {
            "is_entity_gap": is_gap,
            "max_similarity": round(best_score, 3),
            "matched_post": best_post if is_gap else None,
            "matched_title": best_post.get("title") if (best_post and is_gap) else None,
            "matched_post_id": best_post.get("id") if (best_post and is_gap) else None,
            "recommendation": "refresh_existing" if is_gap else "create_new",
            "method": "embedding",
        }
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Embedding-based anti-cannibalization failed, falling back to TF-IDF: {e}")
        return None
