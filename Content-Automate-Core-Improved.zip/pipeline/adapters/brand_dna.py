"""
Brand DNA & Operational Memory Adapter.

Loads and programmatically interfaces with `.agents/SOUL.md` (deterministic identity,
voice directives, banned AI tropes, and GEO guidelines) and `.agents/MEMORY.md`
(empirical performance learnings, high-CTR headline formulas, and video hooks).
"""

import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

from config import BASE_DIR

logger = logging.getLogger("pipeline.adapters.brand_dna")

SOUL_FILE_PATH = BASE_DIR / ".agents" / "SOUL.md"
MEMORY_FILE_PATH = BASE_DIR / ".agents" / "MEMORY.md"


def load_soul_guidelines() -> str:
    """Dynamically loads the Brand DNA identity and guidelines from .agents/SOUL.md."""
    if SOUL_FILE_PATH.exists():
        try:
            return SOUL_FILE_PATH.read_text(encoding="utf-8").strip()
        except Exception as e:
            logger.warning(f"Failed to read SOUL.md at {SOUL_FILE_PATH}: {e}")
    return ""


def load_operational_memory() -> str:
    """Dynamically loads the empirical learning ledger from .agents/MEMORY.md."""
    if MEMORY_FILE_PATH.exists():
        try:
            return MEMORY_FILE_PATH.read_text(encoding="utf-8").strip()
        except Exception as e:
            logger.warning(f"Failed to read MEMORY.md at {MEMORY_FILE_PATH}: {e}")
    return ""


def append_memory_learning(section_header: str, entry: str) -> bool:
    """
    Appends a verified empirical learning or entity gap into .agents/MEMORY.md under
    the specified section header.
    """
    if not MEMORY_FILE_PATH.exists():
        return False

    try:
        content = MEMORY_FILE_PATH.read_text(encoding="utf-8")
        if section_header in content:
            # Insert entry under this section
            parts = content.split(section_header)
            updated_content = parts[0] + section_header + f"\n- {entry.strip()}" + parts[1]
        else:
            updated_content = content + f"\n\n## {section_header}\n- {entry.strip()}\n"

        MEMORY_FILE_PATH.write_text(updated_content, encoding="utf-8")
        logger.info(f"Appended learning to MEMORY.md under '{section_header}'")
        return True
    except Exception as e:
        logger.error(f"Error appending learning to MEMORY.md: {e}")
        return False
