"""
Evidence Pack & Originality Engine (Pillar A3.2).

Google's Scaled Content Policy Gating:
Before drafting, the run requires at least one piece of genuine first-party evidence:
- first_party_data: Proprietary benchmarks, telemetry, survey findings, database stats
- customer_example: Real case study, verified testimonial, practical scenario
- expert_quote: Attributed practitioner interview or authoritative perspective
- original_results: Empirical lab results, benchmark charts, proprietary reproduction

If none exist, the pipeline pauses and asks, separating the system from generic
autopilot spam tools.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field

from storage.db import (
    get_evidence_items_by_website,
    save_evidence_item,
    get_evidence_item_by_id,
    delete_evidence_item,
)
from pipeline.adapters.embedding_client import embed_text, cosine_similarity

logger = logging.getLogger("pipeline.adapters.evidence_pack")

EvidenceType = Literal["first_party_data", "customer_example", "expert_quote", "original_results"]


class EvidenceItem(BaseModel):
    """An individual piece of verified primary evidence."""
    id: str = Field(..., description="Unique evidence ID")
    website_id: str = Field("default", description="Website ID owning this evidence")
    title: str = Field(..., description="Short descriptive title of evidence")
    evidence_type: EvidenceType = Field(..., description="Category of evidence")
    content: str = Field(..., description="Substantive data, quote, benchmark, or findings")
    source_url: Optional[str] = Field(None, description="External verification URL if applicable")
    author_or_expert: Optional[str] = Field(None, description="Name and title of quoted expert or data owner")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Custom metadata tags")


def has_minimum_evidence(evidence_data: Any) -> bool:
    """
    Evaluates whether the run has satisfied Google's Scaled Content Policy requirement
    by having at least one verifiable first-party evidence item.
    """
    if not evidence_data:
        return False
    if isinstance(evidence_data, list):
        return len(evidence_data) > 0
    if isinstance(evidence_data, dict):
        items = evidence_data.get("items") or evidence_data.get("evidence_items") or []
        if items and isinstance(items, list):
            return len(items) > 0
        # Check if dict itself is a single evidence item
        if evidence_data.get("content") or evidence_data.get("title"):
            return True
    return False


def load_site_evidence_pack(
    website_id: str,
    topic: Optional[str] = None,
    limit: int = 10,
) -> List[Dict[str, Any]]:
    """
    Retrieves active evidence items for a website from SQLite, ranking them
    by dense semantic similarity to the target topic if a topic is provided.
    """
    raw_items = get_evidence_items_by_website(website_id=website_id, limit=limit * 2)
    if not raw_items:
        return []

    if not topic:
        return raw_items[:limit]

    try:
        topic_vec = embed_text(topic)
        scored = []
        for item in raw_items:
            text = f"{item.get('title', '')}: {item.get('content', '')}"
            vec = embed_text(text)
            sim = cosine_similarity(topic_vec, vec)
            scored.append((sim, item))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [pair[1] for pair in scored[:limit]]
    except Exception as e:
        logger.warning(f"Could not rank evidence by topic similarity: {e}")
        return raw_items[:limit]


def place_evidence_in_brief(
    brief_sections: List[Dict[str, Any]],
    evidence_items: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Maps available evidence items into the most semantically relevant brief sections.
    Returns:
        Dict mapping section heading -> List of evidence items to incorporate.
    """
    placement: Dict[str, List[Dict[str, Any]]] = {
        sec.get("heading", f"Section {i}"): []
        for i, sec in enumerate(brief_sections)
    }

    if not evidence_items or not brief_sections:
        return placement

    # Compute section embeddings
    section_vectors = []
    section_headings = []
    for sec in brief_sections:
        heading = sec.get("heading", "")
        desc = f"{heading} {' '.join(sec.get('questions_to_answer', []))}"
        try:
            vec = embed_text(desc)
        except Exception:
            vec = []
        section_vectors.append(vec)
        section_headings.append(heading)

    # Assign each evidence item to its highest-affinity section
    for ev in evidence_items:
        ev_text = f"{ev.get('title', '')} {ev.get('content', '')}"
        try:
            ev_vec = embed_text(ev_text)
            best_idx = 0
            best_sim = -1.0
            for idx, s_vec in enumerate(section_vectors):
                if s_vec and ev_vec:
                    sim = cosine_similarity(ev_vec, s_vec)
                    if sim > best_sim:
                        best_sim = sim
                        best_idx = idx
            best_heading = section_headings[best_idx]
            placement[best_heading].append(ev)
        except Exception:
            # Fallback to first non-intro section or first section
            target = section_headings[min(1, len(section_headings) - 1)]
            placement[target].append(ev)

    return placement
