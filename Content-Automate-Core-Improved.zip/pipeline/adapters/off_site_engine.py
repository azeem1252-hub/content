"""
Off-Site Presence Engine (Pillar A9).

Earned-presence optimization across non-owned authoritative domains:
Reddit, YouTube, LinkedIn, Wikipedia, and review platforms.
Studies demonstrate that 3rd-party sources dominate AI citations (ChatGPT, Perplexity,
Claude, Gemini) far beyond brand-owned domains.

Hard Ethical Rules:
- NO fake accounts
- NO astroturfing or automated bot posting to public communities
- NO self-editing Wikipedia (respect Conflict of Interest guidelines)
- The system drafts briefs, scripts, and contribution angles; humans review and publish.
"""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import storage.db as db

logger = logging.getLogger("pipeline.adapters.off_site_engine")

AUTHORITATIVE_OFFSITE_PLATFORMS = {
    "reddit.com": "reddit",
    "youtube.com": "youtube",
    "linkedin.com": "linkedin",
    "wikipedia.org": "wikipedia",
    "g2.com": "review_site",
    "capterra.com": "review_site",
    "trustpilot.com": "review_site",
    "github.com": "developer_hub",
    "stackoverflow.com": "developer_hub",
    "medium.com": "editorial",
    "substack.com": "editorial",
}


def _classify_platform(domain: str) -> str:
    """Matches a domain to its off-site category."""
    d_clean = domain.lower()
    for pattern, plat in AUTHORITATIVE_OFFSITE_PLATFORMS.items():
        if pattern in d_clean:
            return plat
    return "editorial"


def analyze_top_cited_offsite_sources(
    website_id: str,
    cluster_id: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Scans recent AI visibility data to discover which external domains are cited
    most frequently for the brand's target topics.
    """
    snapshots = db.get_ai_visibility_snapshots(website_id=website_id, limit=100)
    domain_counts: Dict[str, int] = {}
    cluster_mapping: Dict[str, str] = {}

    for s in snapshots:
        comp_domains = s.get("competing_domains") or []
        for d in comp_domains:
            if not d:
                continue
            d_norm = d.lower().strip()
            domain_counts[d_norm] = domain_counts.get(d_norm, 0) + 1
            if s.get("cluster_id"):
                cluster_mapping[d_norm] = s["cluster_id"]

    # If no snapshots exist yet, supply authoritative default research targets
    if not domain_counts:
        domain_counts = {
            "reddit.com": 14,
            "youtube.com": 11,
            "linkedin.com": 8,
            "g2.com": 5,
            "wikipedia.org": 4,
        }

    ranked_sources = []
    for domain, citations in sorted(domain_counts.items(), key=lambda x: x[1], reverse=True):
        plat = _classify_platform(domain)
        ranked_sources.append({
            "domain": domain,
            "platform": plat,
            "citations_count": citations,
            "cluster_id": cluster_mapping.get(domain, cluster_id or "cluster_general")
        })

    return ranked_sources


def generate_earned_presence_plan(
    website_id: str,
    cluster_id: str,
    topic: str
) -> List[Dict[str, Any]]:
    """
    Generates a structured earned-presence strategy for a cluster.
    Adheres strictly to the anti-astroturfing policy.
    """
    plan_targets: List[Dict[str, Any]] = [
        # 1. Reddit Discussion Brief
        {
            "id": f"ost_{uuid.uuid4().hex[:12]}",
            "website_id": website_id,
            "cluster_id": cluster_id,
            "platform": "reddit",
            "target_domain": "reddit.com",
            "topic": topic,
            "importance_score": 88.0,
            "strategy": (
                "Identify top 3 active community threads discussing this topic. "
                "Draft a highly technical, helpful response sharing original benchmark data. "
                "Rule: Human author must post manually; must clearly disclose company affiliation; no promo links."
            ),
            "status": "planned"
        },
        # 2. YouTube Video & Chapters Brief
        {
            "id": f"ost_{uuid.uuid4().hex[:12]}",
            "website_id": website_id,
            "cluster_id": cluster_id,
            "platform": "youtube",
            "target_domain": "youtube.com",
            "topic": f"{topic} Complete Walkthrough",
            "importance_score": 82.5,
            "strategy": (
                "Produce a 6-10 minute tactical video walkthrough. "
                "Include timestamped chapters matching direct search questions, "
                "and publish a complete downloadable transcript for search/answer crawler indexing."
            ),
            "status": "planned"
        },
        # 3. LinkedIn Industry Perspective
        {
            "id": f"ost_{uuid.uuid4().hex[:12]}",
            "website_id": website_id,
            "cluster_id": cluster_id,
            "platform": "linkedin",
            "target_domain": "linkedin.com",
            "topic": f"Key Lessons & Data on {topic}",
            "importance_score": 75.0,
            "strategy": (
                "Publish an executive breakdown featuring 3 original charts/statistics. "
                "Tag industry experts to spark substantive discourse."
            ),
            "status": "planned"
        },
        # 4. Review Platform / Entity Profile Optimization
        {
            "id": f"ost_{uuid.uuid4().hex[:12]}",
            "website_id": website_id,
            "cluster_id": cluster_id,
            "platform": "review_site",
            "target_domain": "g2.com",
            "topic": f"{topic} Product Feature Comparison",
            "importance_score": 70.0,
            "strategy": (
                "Verify verified reviews highlight the specific differentiator capabilities. "
                "Keep pricing and feature matrices updated with exact 'as of' dates."
            ),
            "status": "planned"
        }
    ]

    db.save_off_site_targets(plan_targets)
    return plan_targets


def get_off_site_presence_summary(website_id: str) -> Dict[str, Any]:
    """Returns the off-site earned presence overview for a site."""
    targets = db.get_off_site_targets(website_id)
    by_platform: Dict[str, int] = {}
    for t in targets:
        p = t.get("platform", "other")
        by_platform[p] = by_platform.get(p, 0) + 1

    return {
        "website_id": website_id,
        "total_targets": len(targets),
        "platforms_distribution": by_platform,
        "targets": targets,
        "compliance_rules": [
            "Human-reviewed and human-posted only",
            "Mandatory affiliation disclosure on community posts",
            "Strict prohibition of automated bot comments or fake accounts",
            "No Wikipedia conflict-of-interest self-edits"
        ]
    }
