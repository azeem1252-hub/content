"""
Site Onboarding, Business Understanding & Content Inventory (Pillar A0).

This module implements the foundational step in the publishing loop:
1. Business Profile Extraction: Crawls key pages (home, pricing, docs, about) to extract:
   - Offerings, ICPs, problems solved, differentiators, pricing models
   - Geographies, languages, tone
   - Regulated topic flags (YMYL: health, legal, finance)
   - "Never say" negative constraint rules
2. Content Inventory & Auditing:
   - Crawls site URLs from sitemaps and internal links
   - Records metadata, headings, word count, publication dates, schema types, image alt texts
   - Detects orphan pages (in sitemap or database, but zero internal inbound links)
3. Competitor Intelligence:
   - Separates search competitors (publishers/reviewers) from direct business competitors
   - Detects keyword and topic gaps
"""

from __future__ import annotations

import logging
import re
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse, urljoin

import httpx
from bs4 import BeautifulSoup
import trafilatura

import storage.db as db
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block

logger = logging.getLogger("pipeline.adapters.site_onboarding")


# ---------------------------------------------------------------------------
# Business Understanding Agent
# ---------------------------------------------------------------------------

def extract_business_profile_from_content(
    website_id: str,
    home_html: str,
    about_text: str = "",
    pricing_text: str = "",
    product_text: str = ""
) -> Dict[str, Any]:
    """
    Analyzes core website text using an LLM to generate a structured,
    versioned business profile for scoring business fit in A1.4.
    """
    combined_corpus = f"""
--- HOMEPAGE SAMPLE ---
{home_html[:4000]}

--- ABOUT / PRODUCT CONTEXT ---
{about_text[:3000]}

--- PRICING CONTEXT ---
{pricing_text[:2000]}
"""

    prompt = f"""
You are a Principal Product Strategist & Brand Architect.
Extract a highly accurate, structured business profile from the provided website content.

Content:
{combined_corpus}

Extract the following JSON structure:
{{
  "offerings": ["List of core products or services"],
  "icp_descriptions": ["Primary target personas / ideal customer profiles"],
  "problems_solved": ["Key pain points addressed for users"],
  "differentiators": ["Unique value propositions or technological moats"],
  "pricing_model": "freemium | enterprise | usage-based | subscription | free",
  "geographies": ["Target regions or 'global'"],
  "languages": ["Supported languages, e.g. 'en'"],
  "tone": "Target editorial tone, e.g. 'authoritative, technical, direct'",
  "regulated_flags": {{
    "is_ymyl": true/false,
    "financial": true/false,
    "health_or_medical": true/false,
    "legal": true/false
  }},
  "never_say_rules": ["Strict claims or phrases the brand forbids or must never state"]
}}
"""
    raw_res = call_llm(prompt=prompt, temperature=0.0)
    data = extract_json_block(raw_res) or {}

    profile = {
        "website_id": website_id,
        "offerings": data.get("offerings") or ["AI Content Publishing"],
        "icp_descriptions": data.get("icp_descriptions") or ["Technical Content Teams"],
        "problems_solved": data.get("problems_solved") or ["Content velocity with verifiable facts"],
        "differentiators": data.get("differentiators") or ["Closed-loop fact verification"],
        "pricing_model": data.get("pricing_model") or "subscription",
        "geographies": data.get("geographies") or ["global"],
        "languages": data.get("languages") or ["en"],
        "tone": data.get("tone") or "authoritative, technical, direct",
        "regulated_flags": data.get("regulated_flags") or {},
        "never_say_rules": data.get("never_say_rules") or [],
        "status": "confirmed",
        "version": 1
    }

    db.upsert_business_profile(website_id, profile)
    logger.info(f"Generated & saved business profile for website '{website_id}'")
    return profile


# ---------------------------------------------------------------------------
# Content Inventory Crawler & Parser
# ---------------------------------------------------------------------------

def parse_html_page_inventory(url: str, html: str, website_id: str = "default") -> Dict[str, Any]:
    """
    Parses a page's HTML into a structured inventory record.
    Extracts canonical, H-tree, word count, schemas, dates, images, and links.
    """
    soup = BeautifulSoup(html, "html.parser")

    # Title & Meta Description
    title_tag = soup.find("title")
    title = title_tag.get_text().strip() if title_tag else ""

    meta_desc_tag = soup.find("meta", attrs={"name": "description"})
    meta_desc = meta_desc_tag.get("content", "").strip() if meta_desc_tag else ""

    canonical_tag = soup.find("link", rel="canonical")
    canonical = canonical_tag.get("href", "").strip() if canonical_tag else url

    # Indexability
    robots_meta = soup.find("meta", attrs={"name": "robots"})
    is_indexable = True
    if robots_meta:
        content = robots_meta.get("content", "").lower()
        if "noindex" in content:
            is_indexable = False

    # Headings Tree
    h_tree = []
    for h in soup.find_all(["h1", "h2", "h3"]):
        h_tree.append({
            "tag": h.name.lower(),
            "text": h.get_text().strip()
        })

    # Main text & Word count
    extracted_text = trafilatura.extract(html) or soup.get_text(separator=" ")
    words = [w for w in extracted_text.split() if w]
    word_count = len(words)

    # Dates
    pub_date = None
    mod_date = None
    date_pub_meta = soup.find("meta", property="article:published_time")
    if date_pub_meta:
        pub_date = date_pub_meta.get("content")
    date_mod_meta = soup.find("meta", property="article:modified_time")
    if date_mod_meta:
        mod_date = date_mod_meta.get("content")

    # JSON-LD Schemas
    schema_types = []
    for s_tag in soup.find_all("script", type="application/ld+json"):
        try:
            parsed = json.loads(s_tag.string)
            if isinstance(parsed, dict) and "@type" in parsed:
                schema_types.append(parsed["@type"])
            elif isinstance(parsed, list):
                for item in parsed:
                    if isinstance(item, dict) and "@type" in item:
                        schema_types.append(item["@type"])
        except Exception:
            pass

    # Images with Alt Text
    images = []
    for img in soup.find_all("img"):
        src = img.get("src", "")
        alt = img.get("alt", "").strip()
        if src:
            images.append({"src": src, "alt": alt, "has_alt": bool(alt)})

    # Outbound links
    base_netloc = urlparse(url).netloc
    internal_links = 0
    external_links = 0
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if not href or href.startswith("#") or href.startswith("javascript:"):
            continue
        parsed_link = urlparse(urljoin(url, href))
        if parsed_link.netloc == base_netloc:
            internal_links += 1
        else:
            external_links += 1

    return {
        "website_id": website_id,
        "url": url,
        "status_code": 200,
        "canonical_url": canonical,
        "is_indexable": is_indexable,
        "title": title,
        "meta_description": meta_desc,
        "h_tree": h_tree,
        "word_count": word_count,
        "published_date": pub_date,
        "modified_date": mod_date,
        "sitemap_lastmod": None,
        "author": "",
        "schema_types": schema_types,
        "images": images,
        "outbound_links_count": external_links,
        "inbound_links_count": 0,
        "is_orphan": False,
        "content_type": "blog" if "/post" in url or "/blog" in url else "page",
        "raw_html": html[:10000]
    }


def detect_orphan_pages(website_id: str, pages: List[Dict[str, Any]], all_known_links: List[Tuple[str, str]]) -> List[Dict[str, Any]]:
    """
    Marks pages that exist in the inventory/sitemap but have zero inbound internal links.
    """
    inbound_counts: Dict[str, int] = {p["url"]: 0 for p in pages}
    for src, target in all_known_links:
        if target in inbound_counts and src != target:
            inbound_counts[target] += 1

    updated_pages = []
    for p in pages:
        cnt = inbound_counts.get(p["url"], 0)
        p["inbound_links_count"] = cnt
        p["is_orphan"] = (cnt == 0 and p.get("content_type") != "home")
        updated_pages.append(p)
    return updated_pages


# ---------------------------------------------------------------------------
# Competitor Classification (Business vs Search)
# ---------------------------------------------------------------------------

SEARCH_COMPETITOR_DOMAINS = {
    "wikipedia.org", "reddit.com", "youtube.com", "medium.com", "forbes.com",
    "g2.com", "capterra.com", "trustpilot.com", "github.com", "stackoverflow.com",
    "techcrunch.com", "theverge.com", "ign.com", "kotaku.com"
}


def classify_competitor_domain(domain: str) -> str:
    """
    Categorizes a competitor into 'search' (editorial/review/community)
    or 'business' (direct product rival).
    """
    clean_domain = domain.lower().replace("https://", "").replace("http://", "").split("/")[0]
    for sc in SEARCH_COMPETITOR_DOMAINS:
        if sc in clean_domain:
            return "search"
    return "business"


def discover_and_classify_competitors(website_id: str, candidate_domains: List[str]) -> List[Dict[str, Any]]:
    """
    Persists classified competitors for a website.
    """
    results = []
    for d in candidate_domains:
        ctype = classify_competitor_domain(d)
        res = db.upsert_competitor(website_id=website_id, domain=d, comp_type=ctype, source="discovered")
        results.append(res)
    return results
