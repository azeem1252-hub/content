"""
Backlink Intelligence & Link-Gap Prospecting (Pillar: Unmet Market Need).

Both source blueprints call out backlink analysis as a capability their
competitors lack and as a reason users keep a separate Ahrefs/Semrush
subscription. This adapter closes that gap:

  - fetch_backlinks():     real inbound link rows (DataForSEO backlinks API)
  - fetch_domain_authority(): domain rating / authority score (DataForSEO or OpenPageRank)
  - analyze_link_gaps():   derives outreach targets from live SERP competitors —
                           domains ranking above you for tracked terms that are
                           not linking to you are the highest-intent prospects.
  - summarize_backlinks(): aggregate link-profile stats for the Studio UI.

All functions degrade to ``configured: False`` without credentials.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional, Set

import httpx

import config
from pipeline.adapters.serp_client import fetch_serp

logger = logging.getLogger("pipeline.adapters.backlink")

DATAFORSEO_BACKLINKS_ENDPOINT = "https://api.dataforseo.com/v3/backlinks/backlinks/live"
OPENPAGERANK_ENDPOINT = "https://openpagerank.com/api/v1.0/getPageRank"


def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


def resolve_provider() -> str:
    """Returns the active backlink data provider."""
    if _cfg("DATAFORSEO_LOGIN") and _cfg("DATAFORSEO_PASSWORD"):
        return "dataforseo"
    if _cfg("OPENPAGERANK_API_KEY"):
        return "openpagerank"
    return "unconfigured"


def provider_status() -> Dict[str, Any]:
    """Status descriptor for Settings/Health UI."""
    provider = resolve_provider()
    return {
        "provider": provider,
        "configured": provider != "unconfigured",
        "full_backlink_index": provider == "dataforseo",
        "note": (
            "No backlink provider configured. Link-gap prospecting still works from live SERP "
            "data; add DATAFORSEO credentials for full inbound-link indexing."
        ) if provider == "unconfigured" else "",
    }


def fetch_backlinks(domain: str, limit: int = 200) -> Dict[str, Any]:
    """Fetches inbound backlink rows for a domain (DataForSEO only)."""
    if not domain:
        return {"configured": False, "rows": [], "error": "domain is required"}
    login, password = _cfg("DATAFORSEO_LOGIN"), _cfg("DATAFORSEO_PASSWORD")
    if not (login and password):
        return {"configured": False, "rows": [],
                "error": "DataForSEO credentials are required for full backlink indexing"}
    payload = [{
        "target": domain,
        "limit": min(1000, max(1, limit)),
        "mode": "as_is",
        "include_subdomains": True,
    }]
    try:
        with httpx.Client(timeout=45.0) as client:
            resp = client.post(DATAFORSEO_BACKLINKS_ENDPOINT, auth=(login, password), json=payload)
            if resp.status_code != 200:
                return {"configured": True, "rows": [], "error": f"HTTP {resp.status_code}: {resp.text[:160]}"}
            task = (resp.json().get("tasks") or [{}])[0]
            items = ((task.get("result") or [{}])[0]).get("items") or []
            rows = []
            for it in items:
                rows.append({
                    "source_url": it.get("url_from"),
                    "source_domain": it.get("domain_from"),
                    "target_url": it.get("url_to"),
                    "anchor": it.get("anchor"),
                    "domain_rating": it.get("domain_from_rank"),
                    "authority_score": it.get("rank"),
                    "nofollow": it.get("dofollow") is False,
                })
            return {"configured": True, "rows": rows}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"DataForSEO backlinks request failed: {e}")
        return {"configured": True, "rows": [], "error": str(e)}


def fetch_domain_authority(domains: List[str]) -> Dict[str, Any]:
    """Returns authority scores for domains (DataForSEO rank, else OpenPageRank)."""
    clean = [d.strip().lower() for d in domains if d and d.strip()]
    if not clean:
        return {"configured": False, "scores": {}, "error": "no domains supplied"}

    login, password = _cfg("DATAFORSEO_LOGIN"), _cfg("DATAFORSEO_PASSWORD")
    if login and password:
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.post(
                    "https://api.dataforseo.com/v3/backlinks/bulk_ranks/live",
                    auth=(login, password),
                    json=[{"targets": clean[:1000]}],
                )
                if resp.status_code == 200:
                    task = (resp.json().get("tasks") or [{}])[0]
                    items = ((task.get("result") or [{}])[0]).get("items") or []
                    scores = {
                        it.get("target"): it.get("rank")
                        for it in items if it.get("target") is not None
                    }
                    return {"configured": True, "provider": "dataforseo", "scores": scores}
        except Exception as e:  # noqa: BLE001
            logger.warning(f"DataForSEO bulk ranks failed: {e}")

    key = _cfg("OPENPAGERANK_API_KEY")
    if key:
        try:
            with httpx.Client(timeout=30.0) as client:
                resp = client.get(
                    OPENPAGERANK_ENDPOINT,
                    params=[("domains[]", d) for d in clean[:100]],
                    headers={"API-OPR": key},
                )
                if resp.status_code == 200:
                    scores = {}
                    for item in resp.json().get("response", []) or []:
                        domain = item.get("domain")
                        pr = item.get("page_rank_decimal")
                        if domain is not None and pr is not None:
                            scores[domain] = round(float(pr) * 10, 1)
                    return {"configured": True, "provider": "openpagerank", "scores": scores}
                return {"configured": True, "provider": "openpagerank", "scores": {}, "error": f"HTTP {resp.status_code}"}
        except Exception as e:  # noqa: BLE001
            logger.warning(f"OpenPageRank request failed: {e}")
            return {"configured": True, "provider": "openpagerank", "scores": {}, "error": str(e)}

    return {"configured": False, "scores": {}, "error": "No backlink authority provider configured"}


def analyze_link_gaps(
    website_id: Optional[str],
    queries: List[str],
    own_domain: str,
    per_query_depth: int = 10,
) -> Dict[str, Any]:
    """Derives high-intent outreach targets from live SERP competitors.

    A domain that repeatedly outranks you for the terms you care about is a
    credible, topically-aligned link target. Frequency across queries is used as
    a priority signal.
    """
    own = (own_domain or "").lower().replace("www.", "")
    frequency: Dict[str, int] = {}
    measured_queries = 0

    for query in [q for q in (queries or []) if (q or "").strip()][:15]:
        serp = fetch_serp(query, depth=per_query_depth)
        if not serp.get("measured"):
            continue
        measured_queries += 1
        for r in serp.get("results") or []:
            domain = (r.get("domain") or "").lower().replace("www.", "")
            if not domain or domain == own:
                continue
            frequency[domain] = frequency.get(domain, 0) + 1

    opportunities = []
    for domain, count in sorted(frequency.items(), key=lambda kv: kv[1], reverse=True):
        priority = 1 if count >= 3 else (2 if count == 2 else 3)
        opportunities.append({
            "domain": domain,
            "reason": f"Ranks ahead of you on {count} tracked quer{'y' if count == 1 else 'ies'}; topically aligned link prospect.",
            "priority": priority,
            "source": "serp",
        })

    return {
        "website_id": website_id,
        "measured": measured_queries > 0,
        "queries_analyzed": measured_queries,
        "opportunities": opportunities[:50],
        "own_domain": own,
    }


def summarize_backlinks(website_id: Optional[str]) -> Dict[str, Any]:
    """Aggregate inbound-link profile stats for the Studio UI."""
    from storage.db import get_backlinks, get_backlink_opportunities

    links = get_backlinks(website_id, limit=1000)
    opportunities = get_backlink_opportunities(website_id, limit=200)

    domains: Set[str] = {(l.get("source_domain") or "") for l in links if l.get("source_domain")}
    ratings = [l["domain_rating"] for l in links if l.get("domain_rating") is not None]
    nofollow_count = sum(1 for l in links if l.get("nofollow"))

    return {
        "provider": resolve_provider(),
        "configured": resolve_provider() != "unconfigured",
        "total_backlinks": len(links),
        "referring_domains": len(domains),
        "average_domain_rating": round(sum(ratings) / len(ratings), 1) if ratings else None,
        "nofollow_links": nofollow_count,
        "open_opportunities": len(opportunities),
        "top_opportunities": opportunities[:10],
    }
