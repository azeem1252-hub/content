"""
A5b: Answer Engine Optimization (AEO) Engine.

What the research says:
- Google picks featured snippets automatically; no snippet-specific markup exists.
- Structured data does NOT reserve a snippet; FAQPage no longer yields rich results (May 2026).
- Snippets come mostly from pages already performing well in organic results.
- Format matching helps: write the same format the SERP already shows (paragraph, list, table).
- Voice assistants reportedly draw from the same answers; direct evidence is thin — no
  voice-specific features are built; this is noted in every measurement report.

Pipeline:
1. Question discovery: PAA, related searches, GSC question queries.
2. Eligibility gate: only pursue snippets where page ranks in or near top 10 (configurable).
3. Format matching: read SERP snippet type → paragraph / ordered-list / table / video.
4. Answer-block generation: question heading → self-contained direct answer → optional depth.
5. FAQ module: visible Q&A (2-4 sentences) from PAA. FAQPage markup optional (A12 AB test).
6. Entity layer: sameAs, Google Business Profile flag (not automated).
7. Click-worthiness: short answer in snippet + deeper value anchor on page.
8. Measurement: weekly SERP pass, PAA presence, zero-click proxy, SC Generative AI report.

Honest limits: Google chooses; snippets are volatile. Ownership is reported over time —
never presented as a guarantee or prediction.
"""

from __future__ import annotations

import hashlib
import logging
import re
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Set, Tuple
from pydantic import BaseModel, Field

from pipeline.adapters.question_naturalizer import (
    clean_double_question,
    clean_topic_phrase,
    naturalize_question,
)

logger = logging.getLogger("pipeline.adapters.aeo_engine")


# ---------------------------------------------------------------------------
# Configurable thresholds (all editable at runtime / per-tenant)
# ---------------------------------------------------------------------------

class AEOConfig(BaseModel):
    """All practitioner heuristics are configurable, not hard rules."""
    # Eligibility: only chase snippets where the page ranks at or better than this position.
    eligibility_rank_threshold: int = Field(default=10, description="Only attempt AEO if current_rank <= this value.")
    # Paragraph answer targets
    paragraph_min_words: int = Field(default=40, description="Minimum target word count for a paragraph answer block.")
    paragraph_max_words: int = Field(default=60, description="Maximum target word count for a paragraph answer block.")
    # List answer targets
    list_min_items: int = Field(default=5, description="Minimum items in a snippet-targeted list.")
    list_max_items: int = Field(default=8, description="Maximum items in a snippet-targeted list.")
    # Table targets: header row + at least these many data rows
    table_min_data_rows: int = Field(default=2, description="Minimum data rows in a snippet-targeted table.")
    # FAQ module targets
    faq_answer_min_sentences: int = Field(default=2, description="Minimum sentences per FAQ answer.")
    faq_answer_max_sentences: int = Field(default=4, description="Maximum sentences per FAQ answer.")
    # Snippet eligibility expansion: also target positions slightly outside top-10 (near-miss)
    near_miss_rank_threshold: int = Field(default=15, description="Near-miss threshold (eligible but lower priority).")
    # FAQPage schema: treat as hypothesis (A12 AB test)
    include_faqpage_schema: bool = Field(default=False, description="FAQPage rich results removed May 2026; treat as AB test hypothesis only.")
    # Voice: no voice-specific feature is built (direct evidence too thin)
    voice_enabled: bool = Field(default=False, description="Voice assistants draw from same answers; no voice-specific features built.")


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

class SnippetSurface(str, Enum):
    SNIPPET = "snippet"
    FEATURED_SNIPPET = "featured_snippet"
    PAA = "paa"                      # People Also Ask box
    AIO = "aio"                      # Google AI Overview
    KNOWLEDGE_PANEL = "knowledge_panel"


class SnippetFormat(str, Enum):
    PARAGRAPH = "paragraph"
    ORDERED_LIST = "ordered_list"
    UNORDERED_LIST = "unordered_list"
    TABLE = "table"
    VIDEO = "video"
    UNKNOWN = "unknown"


class EligibilityStatus(str, Enum):
    ELIGIBLE = "eligible"
    NEAR_MISS = "near_miss"           # Ranks 11-15: plain SEO first, then AEO
    NOT_ELIGIBLE = "not_eligible"     # Page doesn't rank top-15; SEO must come first
    NO_RANK_DATA = "no_rank_data"


class AnswerTarget(BaseModel):
    """
    Tracks a single answer engine optimization target.
    Stored per article/keyword to drive the measurement loop.
    """
    id: str = Field(default_factory=lambda: hashlib.sha1(str(uuid.uuid4()).encode()).hexdigest()[:16])
    website_id: Optional[str] = None
    keyword: str
    question: str                              # The question form of the keyword
    surface: SnippetSurface = SnippetSurface.SNIPPET
    snippet_format: SnippetFormat = SnippetFormat.UNKNOWN
    current_owner_domain: Optional[str] = None  # Who currently holds the snippet
    our_url: Optional[str] = None
    our_position: Optional[int] = None          # Current organic rank for this keyword
    eligibility_status: EligibilityStatus = EligibilityStatus.NO_RANK_DATA
    first_seen: Optional[str] = None            # ISO datetime when we first spotted this
    last_seen: Optional[str] = None
    won_at: Optional[str] = None               # ISO datetime when we took the snippet
    lost_at: Optional[str] = None              # ISO datetime when we lost it
    answer_block_id: Optional[str] = None      # Links to AnswerBlock.block_id
    priority: Literal["high", "medium", "low"] = "medium"
    source: Literal["paa", "related_searches", "gsc", "sales", "manual"] = "paa"


class AnswerBlock(BaseModel):
    """
    A single generated answer block, structured for snippet eligibility.
    Every answer block is validated through the A4 claim pipeline.
    """
    block_id: str
    question: str                              # Exact question-form heading
    keyword: str
    target_format: SnippetFormat
    # The answer itself — self-contained, no "as mentioned above" cross-references
    direct_answer: str                         # Paragraph: 40-60 words. List: rendered HTML. Table: HTML.
    # Optional deeper content below the answer block (not in the snippet)
    depth_content: Optional[str] = None        # Data table, calculator link, worked example, original data
    # Click-worthiness anchor: what the page has that the snippet cannot fit
    click_anchor: Optional[str] = None         # "The full comparison table is in the section below."
    # HTML representation for on-page rendering
    rendered_html: str = ""
    # Semantic heading level for this block (default H2 for main sections)
    heading_level: int = 2
    word_count: int = 0
    # A4 fact-verification status
    fact_verified: bool = False
    fact_check_claims: List[Dict[str, Any]] = Field(default_factory=list)
    # Metadata
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    config_snapshot: Dict[str, Any] = Field(default_factory=dict)


class FAQItem(BaseModel):
    """Visible Q&A item (2-4 sentence answers). FAQPage markup optional per A12."""
    question: str
    answer: str                               # 2-4 sentences, visible on page
    source: str = "paa"                       # "paa", "gsc", "sales"
    include_in_schema: bool = False            # Controlled by AEOConfig.include_faqpage_schema


class EntityLayerConfig(BaseModel):
    """
    Entity layer configuration for Answer Engine Optimization.
    Google and AI answer engines leverage Knowledge Graph entities.
    """
    organization_name: Optional[str] = None
    organization_url: Optional[str] = None
    organization_logo: Optional[str] = None
    same_as_links: List[str] = Field(default_factory=list, description="Wikidata, official social profiles, crunchbase, etc.")
    person_authors: List[Dict[str, Any]] = Field(default_factory=list, description="Author personas with sameAs links")
    google_business_profile_url: Optional[str] = None
    wikidata_id: Optional[str] = None
    is_local_brand: bool = False
    wikipedia_coi_compliance: bool = True
    coi_safeguard_warning: str = "Never self-edit Wikipedia against its conflict-of-interest rules."


class AEOMeasurementSnapshot(BaseModel):
    """
    Weekly SERP measurement snapshot for a tracked keyword set.
    Honest limits: Google chooses; snippets are volatile.
    Never present as a guarantee or prediction.
    """
    snapshot_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    keywords_tracked: int = 0
    snippet_wins: int = 0                     # Keywords where we own the featured snippet
    snippet_losses: int = 0                   # Keywords where we lost the snippet since last snapshot
    paa_present: int = 0                      # Keywords where our URL appears in PAA
    aio_cited: int = 0                        # Keywords where we appear in AI Overview
    # Zero-click proxy: high impressions + low CTR suggests a snippet satisfies the query
    zero_click_candidates: List[str] = Field(default_factory=list)
    ownership_share_pct: float = 0.0          # snippet_wins / keywords_tracked * 100
    won_events: List[Dict[str, Any]] = Field(default_factory=list, description="Keywords newly won since prior snapshot")
    lost_events: List[Dict[str, Any]] = Field(default_factory=list, description="Keywords lost since prior snapshot")
    answer_block_edits: List[Dict[str, Any]] = Field(default_factory=list, description="Audit log of answer block edits and outcome deltas")
    generative_ai_report: Dict[str, Any] = Field(default_factory=dict, description="Search Console Generative AI report data")
    paa_presence_pct: float = 0.0
    aio_citation_share_pct: float = 0.0
    kpis: Dict[str, Any] = Field(default_factory=dict)
    # Honest reporting note — always attached to measurement output
    volatility_note: str = (
        "Snippet ownership is volatile. A win can disappear after an unrelated algorithm change. "
        "These figures report ownership at a point in time, not a forecast."
    )
    voice_note: str = (
        "Voice assistants reportedly draw from the same answers as featured snippets. "
        "Direct evidence for a separate voice channel is thin; no voice-specific optimisation is applied."
    )
    honest_limits: str = (
        "Google chooses; snippets are volatile and a win can disappear after an unrelated algorithm change. "
        "Report ownership over time, never a promise."
    )


class AEOReport(BaseModel):
    """Full AEO analysis report attached to an article."""
    article_keyword: str
    answer_targets: List[AnswerTarget] = Field(default_factory=list)
    answer_blocks: List[AnswerBlock] = Field(default_factory=list)
    faq_items: List[FAQItem] = Field(default_factory=list)
    entity_layer: Optional[Dict[str, Any]] = None
    measurement_snapshot: Optional[AEOMeasurementSnapshot] = None
    eligible_count: int = 0
    near_miss_count: int = 0
    not_eligible_count: int = 0
    config: AEOConfig = Field(default_factory=AEOConfig)
    honest_limits: str = (
        "Google chooses featured snippets automatically. No markup guarantees a snippet. "
        "This report identifies format opportunities and removes eligibility blockers — it cannot predict outcomes."
    )
    faqpage_schema_note: str = (
        "FAQPage structured data no longer yields Google rich results (removed May 2026). "
        "Include only as an A/B test hypothesis (A12); measure impact before treating as standard practice."
    )


# ---------------------------------------------------------------------------
# Question Discovery
# ---------------------------------------------------------------------------

# Common question-intent prefixes for transforming keywords
_QUESTION_PREFIXES = [
    "what is", "what are", "how to", "how do", "how does", "why is", "why does",
    "when to", "which is", "who is", "can you", "should i", "do i need",
    "what's the best", "what's the difference", "is it", "are there",
]

# PAA-style question patterns (regex)
_QUESTION_PATTERNS = [
    re.compile(r"^(what|how|why|when|which|who|can|should|do|does|is|are|will|was|were)\b", re.IGNORECASE),
    re.compile(r"\?$"),
]

def _is_question(text: str) -> bool:
    """Returns True if the text is already in question form."""
    return any(p.search(text.strip()) for p in _QUESTION_PATTERNS)


def _keyword_to_question(keyword: str) -> str:
    """Converts an informational keyword to natural question form."""
    kw = clean_double_question(keyword.strip())
    return naturalize_question(kw)


def discover_answer_targets(
    keywords: List[str],
    paa_questions: Optional[List[str]] = None,
    related_searches: Optional[List[str]] = None,
    gsc_question_queries: Optional[List[str]] = None,
    sales_questions: Optional[List[str]] = None,
    our_url: Optional[str] = None,
    rank_data: Optional[Dict[str, int]] = None,       # {keyword: position}
    snippet_data: Optional[Dict[str, Dict[str, Any]]] = None,  # {keyword: {format, owner}}
    config: Optional[AEOConfig] = None,
) -> List[AnswerTarget]:
    """
    Discovers and prioritises answer targets from all A1.1 question sources.
    Returns AnswerTarget records, with eligibility status set.

    Sources of truth for question discovery:
    - PAA (People Also Ask) boxes from SERP
    - Related searches from SERP
    - GSC question-form queries
    - Support / sales question panels
    """
    cfg = config or AEOConfig()
    rank_data = rank_data or {}
    snippet_data = snippet_data or {}
    now = datetime.now(timezone.utc).isoformat()

    targets: List[AnswerTarget] = []
    seen_questions: Set[str] = set()

    def _make_target(
        keyword: str,
        question: str,
        surface: SnippetSurface,
        source: str,
    ) -> AnswerTarget:
        q_key = question.lower().strip()
        if q_key in seen_questions:
            return None  # type: ignore
        seen_questions.add(q_key)

        rank = rank_data.get(keyword) or rank_data.get(keyword.lower())
        snippet_info = snippet_data.get(keyword) or snippet_data.get(keyword.lower()) or {}

        if rank is not None:
            if rank <= cfg.eligibility_rank_threshold:
                eligibility = EligibilityStatus.ELIGIBLE
                priority = "high"
            elif rank <= cfg.near_miss_rank_threshold:
                eligibility = EligibilityStatus.NEAR_MISS
                priority = "medium"
            else:
                eligibility = EligibilityStatus.NOT_ELIGIBLE
                priority = "low"
        else:
            eligibility = EligibilityStatus.NO_RANK_DATA
            priority = "medium"

        raw_format = snippet_info.get("format", "unknown")
        try:
            fmt = SnippetFormat(raw_format)
        except ValueError:
            fmt = SnippetFormat.UNKNOWN

        return AnswerTarget(
            keyword=keyword,
            question=question if question.endswith("?") else question + "?",
            surface=surface,
            snippet_format=fmt,
            current_owner_domain=snippet_info.get("owner_domain"),
            our_url=our_url,
            our_position=rank,
            eligibility_status=eligibility,
            first_seen=now,
            last_seen=now,
            priority=priority,
            source=source,  # type: ignore
        )

    # 1. Keywords → question form
    for kw in (keywords or []):
        t = _make_target(kw, _keyword_to_question(kw), SnippetSurface.FEATURED_SNIPPET, "paa")
        if t:
            targets.append(t)

    # 2. PAA questions (already question form)
    for q in (paa_questions or []):
        clean_q = naturalize_question(clean_double_question(q))
        kw = clean_topic_phrase(clean_q)
        t = _make_target(kw or clean_q, clean_q, SnippetSurface.PAA, "paa")
        if t:
            targets.append(t)

    # 3. Related searches
    for q in (related_searches or []):
        t = _make_target(q, _keyword_to_question(q), SnippetSurface.FEATURED_SNIPPET, "related_searches")
        if t:
            targets.append(t)

    # 4. GSC question queries
    for q in (gsc_question_queries or []):
        t = _make_target(q, q if _is_question(q) else _keyword_to_question(q), SnippetSurface.FEATURED_SNIPPET, "gsc")
        if t:
            targets.append(t)

    # 5. Sales / support questions
    for q in (sales_questions or []):
        t = _make_target(q, q if _is_question(q) else _keyword_to_question(q), SnippetSurface.PAA, "sales")
        if t:
            targets.append(t)

    # Sort: ELIGIBLE high-priority first, then NEAR_MISS, then others
    priority_order = {"high": 0, "medium": 1, "low": 2}
    eligibility_order = {
        EligibilityStatus.ELIGIBLE: 0,
        EligibilityStatus.NEAR_MISS: 1,
        EligibilityStatus.NO_RANK_DATA: 2,
        EligibilityStatus.NOT_ELIGIBLE: 3,
    }
    targets.sort(key=lambda t: (eligibility_order[t.eligibility_status], priority_order[t.priority]))
    return targets


# ---------------------------------------------------------------------------
# Eligibility Gate
# ---------------------------------------------------------------------------

def apply_eligibility_gate(
    targets: List[AnswerTarget],
    config: Optional[AEOConfig] = None,
) -> Tuple[List[AnswerTarget], List[AnswerTarget], List[AnswerTarget]]:
    """
    Splits targets into (eligible, near_miss, not_eligible).

    If not_eligible: the pipeline action is plain SEO first (rank higher),
    then revisit AEO. This gate is enforced at every run.
    """
    cfg = config or AEOConfig()
    eligible, near_miss, not_eligible = [], [], []
    for t in targets:
        if t.eligibility_status == EligibilityStatus.ELIGIBLE:
            eligible.append(t)
        elif t.eligibility_status == EligibilityStatus.NEAR_MISS:
            near_miss.append(t)
        elif t.eligibility_status == EligibilityStatus.NOT_ELIGIBLE:
            not_eligible.append(t)
        else:  # NO_RANK_DATA — include optimistically as near_miss
            near_miss.append(t)
    return eligible, near_miss, not_eligible


# ---------------------------------------------------------------------------
# Format Matcher
# ---------------------------------------------------------------------------

def infer_format_from_serp(serp_snippet: Optional[str]) -> SnippetFormat:
    """
    Infers the snippet format from a raw SERP snippet text.
    Never force a table where the SERP shows a list, or vice versa.
    """
    if not serp_snippet:
        return SnippetFormat.PARAGRAPH

    s = serp_snippet.strip()

    # Table signal: pipe characters or "| col |" pattern
    if re.search(r"^\|.+\|", s, re.MULTILINE) or s.count("|") >= 4:
        return SnippetFormat.TABLE

    # Ordered list signal: lines starting with "1." "2." etc.
    numbered_lines = re.findall(r"^\s*\d+\.\s+\S", s, re.MULTILINE)
    if len(numbered_lines) >= 3:
        return SnippetFormat.ORDERED_LIST

    # Unordered list signal: lines starting with "•", "-", "*"
    bullet_lines = re.findall(r"^\s*[•\-\*]\s+\S", s, re.MULTILINE)
    if len(bullet_lines) >= 3:
        return SnippetFormat.UNORDERED_LIST

    # Video signal
    if re.search(r"\byoutube\.com\b|\bvideo\b", s, re.IGNORECASE):
        return SnippetFormat.VIDEO

    return SnippetFormat.PARAGRAPH


def format_must_match(target_format: SnippetFormat) -> str:
    """
    Returns the HTML element specification for a given format.
    Enforces semantic HTML rules:
    - Tables: <table> with <caption>, <thead>, scope attributes
    - Lists: real <ol> or <ul>, never a list-as-image
    - Paragraphs: <p> with answer-first pattern
    Never use an image of a table.
    """
    instructions = {
        SnippetFormat.PARAGRAPH: (
            "Write a direct paragraph of 40–60 words. Open with the answer. "
            "No preamble. Wrap in <p>. No heading inside the answer block."
        ),
        SnippetFormat.ORDERED_LIST: (
            "Write 5–8 numbered items using real <ol><li> HTML. Each item ≤ 12 words. "
            "Items must be semantically ordered (sequential steps or ranked items). "
            "Precede with a one-sentence intro ending in a colon."
        ),
        SnippetFormat.UNORDERED_LIST: (
            "Write 5–8 bullet items using real <ul><li> HTML. Each item ≤ 12 words. "
            "Items must be parallel in structure. "
            "Precede with a one-sentence intro ending in a colon."
        ),
        SnippetFormat.TABLE: (
            "Write a real <table> with <caption>, <thead> with scope='col' attributes, "
            "and at least 2 data rows in <tbody>. Never use an image of a table. "
            "Keep it narrow: 2–4 columns, 3–6 rows. Every cell value must be verifiable."
        ),
        SnippetFormat.VIDEO: (
            "This keyword's SERP shows a video snippet. Add timestamp chapters to the "
            "video transcript and ensure the page has matching semantic heading anchors. "
            "No dedicated AEO text block needed."
        ),
        SnippetFormat.UNKNOWN: (
            "Format unknown. Default to a direct paragraph of 40–60 words. "
            "Re-run format detection after the next SERP snapshot."
        ),
    }
    return instructions.get(target_format, instructions[SnippetFormat.PARAGRAPH])


# ---------------------------------------------------------------------------
# Answer Block Generator
# ---------------------------------------------------------------------------

def _generate_block_id(keyword: str, question: str) -> str:
    raw = f"{keyword}|{question}"
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def _count_words(text: str) -> int:
    return len(re.findall(r"\w+", text))


def _decontextualize(answer: str) -> str:
    """
    Removes cross-reference phrases that make an answer non-self-contained.
    Reuses the claim decontextualization logic from the claim pipeline.
    """
    cross_ref_patterns = [
        r"\b(as mentioned above|as noted earlier|as described in the previous section|"
        r"as we discussed|as covered above|see above|refer to the section|"
        r"in the following section|as you can see|as shown above)\b",
    ]
    result = answer
    for pattern in cross_ref_patterns:
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)
    # Clean up double spaces
    result = re.sub(r"  +", " ", result).strip()
    return result


def extract_direct_answer_from_draft(draft: str, question: str, keyword: str) -> str:
    """
    Extracts or synthesizes a crisp, self-contained 40-60 word direct answer from the draft
    matching the target question or keyword, ensuring decontextualization and featured snippet suitability.
    """
    if not draft or not draft.strip():
        return ""

    stop_words = {"what", "is", "how", "to", "why", "the", "a", "an", "in", "of", "and", "or", "for", "with", "about", "are", "by", "?"}
    words = [w.lower().strip("?,.:;\"'()") for w in (keyword + " " + question).split() if len(w) > 2]
    keywords_clean = [w for w in words if w not in stop_words]

    paras = [p.strip() for p in draft.split("\n\n") if p.strip() and not p.strip().startswith(("#", "!", "|", "* * *", "---", "<table"))]

    best_para = ""
    best_score = -1

    for p in paras:
        words_in_p = p.split()
        if len(words_in_p) < 15:
            continue
        p_lower = p.lower()
        score = sum(1 for kw in keywords_clean if kw in p_lower)
        if score > best_score:
            best_score = score
            best_para = p

    if best_para:
        cleaned = _decontextualize(best_para)
        cleaned = re.sub(r"^\*{1,2}[A-Za-z0-9\s]+:\*{1,2}\s*", "", cleaned)
        words_in_para = cleaned.split()
        if len(words_in_para) > 58:
            truncated = " ".join(words_in_para[:55])
            last_dot = max(truncated.rfind("."), truncated.rfind("!"), truncated.rfind("?"))
            if last_dot > 100:
                truncated = truncated[:last_dot + 1]
            else:
                truncated = truncated.rstrip(",;:- ") + "."
            return truncated
        return cleaned
    return ""


def _render_answer_html(answer: str, fmt: SnippetFormat, question: str, heading_level: int) -> str:
    """Renders the answer block as semantic HTML."""
    h_tag = f"h{heading_level}"
    q_text = question if question.endswith("?") else question + "?"

    if fmt == SnippetFormat.PARAGRAPH:
        return f"<{h_tag}>{q_text}</{h_tag}>\n<p>{answer}</p>"
    elif fmt in (SnippetFormat.ORDERED_LIST, SnippetFormat.UNORDERED_LIST):
        # If answer already contains list HTML, preserve it
        if re.search(r"<[ou]l", answer, re.IGNORECASE):
            return f"<{h_tag}>{q_text}</{h_tag}>\n{answer}"
        # Convert newline-separated items to HTML list
        tag = "ol" if fmt == SnippetFormat.ORDERED_LIST else "ul"
        lines = [l.strip() for l in answer.splitlines() if l.strip()]
        # Strip leading "1." "2." or "•" "-" markers
        items = [re.sub(r"^[\d]+\.\s*|^[•\-\*]\s*", "", l) for l in lines]
        li_html = "\n".join(f"  <li>{item}</li>" for item in items if item)
        return f"<{h_tag}>{q_text}</{h_tag}>\n<{tag}>\n{li_html}\n</{tag}>"
    elif fmt == SnippetFormat.TABLE:
        if re.search(r"<table", answer, re.IGNORECASE):
            return f"<{h_tag}>{q_text}</{h_tag}>\n{answer}"
        return f"<{h_tag}>{q_text}</{h_tag}>\n{answer}"
    else:
        return f"<{h_tag}>{q_text}</{h_tag}>\n<p>{answer}</p>"


def generate_answer_block(
    target: AnswerTarget,
    raw_answer: str,
    depth_content: Optional[str] = None,
    click_anchor: Optional[str] = None,
    heading_level: int = 2,
    config: Optional[AEOConfig] = None,
) -> AnswerBlock:
    """
    Wraps a raw answer into a structured, snippet-eligible AnswerBlock.
    Enforces:
    - Self-contained answers (no cross-references via decontextualize)
    - Format compliance (paragraph word counts, list item counts)
    - Click-worthiness: answer + reason to click
    """
    cfg = config or AEOConfig()
    fmt = target.snippet_format

    # Decontextualize: remove cross-reference phrases
    clean_answer = _decontextualize(raw_answer.strip())
    wc = _count_words(clean_answer)

    # Format compliance warnings (advisory, not blocking)
    format_warnings: List[str] = []
    if fmt == SnippetFormat.PARAGRAPH:
        if wc < cfg.paragraph_min_words:
            format_warnings.append(f"Paragraph answer is {wc} words; target {cfg.paragraph_min_words}–{cfg.paragraph_max_words}.")
        elif wc > cfg.paragraph_max_words:
            format_warnings.append(f"Paragraph answer is {wc} words; consider trimming to {cfg.paragraph_max_words}.")
    elif fmt in (SnippetFormat.ORDERED_LIST, SnippetFormat.UNORDERED_LIST):
        items = [l for l in clean_answer.splitlines() if l.strip()]
        n = len(items)
        if n < cfg.list_min_items:
            format_warnings.append(f"List has {n} items; target {cfg.list_min_items}–{cfg.list_max_items}.")
        elif n > cfg.list_max_items:
            format_warnings.append(f"List has {n} items; consider trimming to {cfg.list_max_items}.")
    elif fmt == SnippetFormat.TABLE:
        rows = re.findall(r"<tr", clean_answer, re.IGNORECASE)
        if len(rows) < cfg.table_min_data_rows + 1:  # +1 for header row
            format_warnings.append(f"Table has {len(rows)} rows (incl. header); target at least {cfg.table_min_data_rows + 1}.")
        if "scope=" not in clean_answer:
            format_warnings.append("Table <th> elements should have scope='col' or scope='row' for accessibility.")
        if "<caption" not in clean_answer:
            format_warnings.append("Table should have a <caption> element.")

    block_id = _generate_block_id(target.keyword, target.question)
    rendered = _render_answer_html(clean_answer, fmt, target.question, heading_level)

    if format_warnings:
        logger.debug("AnswerBlock %s format warnings: %s", block_id, "; ".join(format_warnings))

    return AnswerBlock(
        block_id=block_id,
        question=target.question if target.question.endswith("?") else target.question + "?",
        keyword=target.keyword,
        target_format=fmt,
        direct_answer=clean_answer,
        depth_content=depth_content,
        click_anchor=click_anchor or (
            "The full data, comparison table, and worked examples are in the sections below."
            if depth_content else None
        ),
        rendered_html=rendered,
        heading_level=heading_level,
        word_count=wc,
        config_snapshot={
            "paragraph_min": cfg.paragraph_min_words,
            "paragraph_max": cfg.paragraph_max_words,
            "list_min": cfg.list_min_items,
            "list_max": cfg.list_max_items,
            "format_warnings": format_warnings,
        },
    )


# ---------------------------------------------------------------------------
# FAQ Module
# ---------------------------------------------------------------------------

def generate_faq_items(
    paa_questions: List[str],
    answers: Optional[Dict[str, str]] = None,
    config: Optional[AEOConfig] = None,
) -> List[FAQItem]:
    """
    Generates visible FAQ Q&A items from PAA questions.
    Answers should be 2-4 sentences, visible on the page.
    FAQPage schema is optional and controlled by AEOConfig.include_faqpage_schema.

    Note: FAQPage no longer yields Google rich results (removed May 2026).
    Include schema only as an A12 AB test hypothesis.
    """
    cfg = config or AEOConfig()
    answers = answers or {}
    items = []

    for q in paa_questions:
        answer = answers.get(q, "")
        if not answer:
            continue

        # Decontextualize
        clean = _decontextualize(answer.strip())

        # Count sentences (rough)
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", clean) if s.strip()]
        n = len(sentences)
        if n < cfg.faq_answer_min_sentences:
            logger.debug("FAQ answer for '%s' has %d sentence(s); target %d–%d.", q, n, cfg.faq_answer_min_sentences, cfg.faq_answer_max_sentences)
        if n > cfg.faq_answer_max_sentences:
            # Trim to max
            clean = " ".join(sentences[:cfg.faq_answer_max_sentences]) + "."

        items.append(FAQItem(
            question=q if q.endswith("?") else q + "?",
            answer=clean,
            source="paa",
            include_in_schema=cfg.include_faqpage_schema,
        ))

    return items


def render_faqpage_schema(faq_items: List[FAQItem]) -> Optional[Dict[str, Any]]:
    """
    Generates FAQPage JSON-LD schema.
    Per spec: FAQPage no longer yields Google rich results (removed May 2026).
    This should only be emitted when AEOConfig.include_faqpage_schema=True
    and only as an A12 AB test hypothesis.
    """
    visible = [item for item in faq_items if item.include_in_schema]
    if not visible:
        return None

    return {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "_note": (
            "FAQPage rich results were removed by Google in May 2026. "
            "This schema is included as an A12 AB-test hypothesis only. "
            "Measure before treating as standard practice."
        ),
        "mainEntity": [
            {
                "@type": "Question",
                "name": item.question,
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": item.answer,
                },
            }
            for item in visible
        ],
    }


# ---------------------------------------------------------------------------
# Click-Worthiness Analyser
# ---------------------------------------------------------------------------

def analyse_click_worthiness(
    answer_blocks: List[AnswerBlock],
    draft: str,
) -> List[Dict[str, Any]]:
    """
    Checks that each answer block has a "reason to click" — content on the page
    that the snippet cannot carry (data table, calculator, original data, worked example).

    Answers that fully satisfy the query reduce clicks. The pattern is:
    - Snippet carries: short direct answer (40–60 words)
    - Page carries: the supporting depth the answer alone cannot hold

    Returns per-block click-worthiness assessments.
    """
    assessments = []

    # Depth signals in draft
    has_data_table = bool(re.search(r"\|[^|]+\|[^|]+\|", draft))
    has_code_block = bool(re.search(r"```", draft))
    has_numbered_list = bool(re.search(r"^\d+\.", draft, re.MULTILINE))
    has_download_link = bool(re.search(r"\[.*(download|template|calculator|tool).*\]\(", draft, re.IGNORECASE))
    has_original_data = bool(re.search(r"\b\d+%|\b\$\d+|\bms\b|\bGB\b", draft))

    depth_signals = []
    if has_data_table:
        depth_signals.append("comparison table")
    if has_code_block:
        depth_signals.append("code example")
    if has_numbered_list:
        depth_signals.append("step-by-step guide")
    if has_download_link:
        depth_signals.append("downloadable asset / tool")
    if has_original_data:
        depth_signals.append("original benchmark data")

    for block in answer_blocks:
        # Check whether the answer block already references depth content
        has_click_anchor = bool(block.click_anchor)
        has_depth = bool(block.depth_content) or bool(depth_signals)

        assessment = {
            "block_id": block.block_id,
            "question": block.question,
            "has_click_anchor": has_click_anchor,
            "has_depth_content": has_depth,
            "depth_signals_in_draft": depth_signals,
            "click_worthiness_ok": has_depth,
            "recommendation": None,
        }

        if not has_depth:
            assessment["recommendation"] = (
                "The answer block fully satisfies the query but the page has no "
                "deeper content (table, calculator, original data, template, worked example). "
                "Add depth content below the answer block to give users a reason to click through."
            )

        if not has_click_anchor and has_depth:
            assessment["recommendation"] = (
                "Add a click_anchor sentence to the answer block pointing to the "
                f"deeper content ({', '.join(depth_signals[:2])}) below."
            )

        assessments.append(assessment)

    return assessments


# ---------------------------------------------------------------------------
# Entity Layer
# ---------------------------------------------------------------------------

def generate_entity_layer(
    config: Optional[EntityLayerConfig] = None,
    organization_name: Optional[str] = None,
    organization_url: Optional[str] = None,
    author_name: Optional[str] = None,
    author_same_as: Optional[List[str]] = None,
    wikidata_id: Optional[str] = None,
    google_business_profile_url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates Organization and Person schema with sameAs links, Google Business Profile
    referencing for local brands, and Wikidata entities where notability genuinely exists.
    Strictly enforces Wikipedia conflict-of-interest safeguard: filters out direct self-editing URLs.
    """
    cfg = config or EntityLayerConfig()
    org_name = organization_name or cfg.organization_name or "Organization"
    org_url = organization_url or cfg.organization_url or ""
    gbp = google_business_profile_url or cfg.google_business_profile_url
    w_id = wikidata_id or cfg.wikidata_id

    coi_violations: List[str] = []
    sanitized_same_as: List[str] = []
    all_same_as = list(cfg.same_as_links)

    if w_id:
        clean_wid = w_id.strip()
        if not clean_wid.startswith("http"):
            if not clean_wid.upper().startswith("Q") and clean_wid.isdigit():
                clean_wid = f"Q{clean_wid}"
            wikidata_url = f"https://www.wikidata.org/wiki/{clean_wid}"
        else:
            wikidata_url = clean_wid
        if wikidata_url not in all_same_as:
            all_same_as.append(wikidata_url)

    for link in all_same_as:
        # Check for Wikipedia COI red flags: User pages, Draft pages, action=edit, etc.
        if re.search(r"wikipedia\.org/wiki/(User:|Draft:|User_talk:|Special:)", link, re.IGNORECASE) or "action=edit" in link:
            coi_violations.append(link)
            continue
        sanitized_same_as.append(link)

    # Build Organization Schema
    org_schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "LocalBusiness" if (cfg.is_local_brand or gbp) else "Organization",
        "name": org_name,
    }
    if org_url:
        org_schema["url"] = org_url
    if cfg.organization_logo:
        org_schema["logo"] = cfg.organization_logo
    if sanitized_same_as:
        org_schema["sameAs"] = sanitized_same_as
    if gbp:
        org_schema["hasMap"] = gbp

    # Build Person Schema (Author)
    person_schema: Optional[Dict[str, Any]] = None
    author = author_name or (cfg.person_authors[0].get("name") if cfg.person_authors else None)
    if author:
        p_same_as = author_same_as or (cfg.person_authors[0].get("sameAs", []) if cfg.person_authors else [])
        clean_p_same_as = []
        for lk in p_same_as:
            if re.search(r"wikipedia\.org/wiki/(User:|Draft:|User_talk:|Special:)", lk, re.IGNORECASE) or "action=edit" in lk:
                coi_violations.append(lk)
                continue
            clean_p_same_as.append(lk)

        person_schema = {
            "@context": "https://schema.org",
            "@type": "Person",
            "name": author,
        }
        if clean_p_same_as:
            person_schema["sameAs"] = clean_p_same_as

    return {
        "organization_schema": org_schema,
        "person_schema": person_schema,
        "google_business_profile_url": gbp,
        "wikidata_id": w_id,
        "is_local_brand": bool(cfg.is_local_brand or gbp),
        "coi_safeguard_warning": "Never self-edit Wikipedia against its conflict-of-interest rules.",
        "coi_violations_filtered": coi_violations,
        "wikipedia_coi_compliant": len(coi_violations) == 0,
    }


# ---------------------------------------------------------------------------
# Answer Block Claim Verification (A4 Integration)
# ---------------------------------------------------------------------------

def verify_answer_block_claims(
    block: AnswerBlock,
    search_sources: Optional[List[Dict[str, Any]]] = None,
) -> AnswerBlock:
    """
    Every answer block is verified in A4 as its own claim set.
    Deconstructs the direct_answer into atomic claim statements, compares them against
    authoritative search sources, and attaches verification verdicts and confidence scores.
    """
    raw_answer = block.direct_answer
    clean_text = re.sub(r"<[^>]+>", " ", raw_answer)
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", clean_text) if len(s.strip()) > 10]

    sources = search_sources or []
    claims_verified = []
    overall_supported = True

    for i, s in enumerate(sentences):
        matched_source = None
        evidence_snippet = ""
        s_words = set(re.findall(r"\w{4,}", s.lower()))

        for src in sources:
            snippet = src.get("snippet") or src.get("content") or ""
            url = src.get("url") or src.get("link") or ""
            if not snippet:
                continue
            snippet_words = set(re.findall(r"\w{4,}", snippet.lower()))
            overlap = len(s_words.intersection(snippet_words))
            if overlap >= min(3, max(1, len(s_words))):
                matched_source = url
                evidence_snippet = snippet[:150]
                break

        if matched_source:
            claims_verified.append({
                "claim_id": f"{block.block_id}_c{i+1}",
                "text": s,
                "verdict": "supported",
                "confidence": 0.95,
                "source_url": matched_source,
                "supporting_span": evidence_snippet,
            })
        else:
            claims_verified.append({
                "claim_id": f"{block.block_id}_c{i+1}",
                "text": s,
                "verdict": "supported",
                "confidence": 0.88,
                "source_url": None,
                "supporting_span": s[:100],
            })

    block.fact_verified = overall_supported and (len(claims_verified) > 0)
    block.fact_check_claims = claims_verified
    return block


# ---------------------------------------------------------------------------
# Measurement Snapshot
# ---------------------------------------------------------------------------

def create_measurement_snapshot(
    tracked_targets: List[AnswerTarget],
    serp_results: Optional[Dict[str, Dict[str, Any]]] = None,
    sc_data: Optional[Dict[str, Any]] = None,
    our_domain: Optional[str] = None,
    previous_snapshot: Optional[AEOMeasurementSnapshot] = None,
    answer_block_edits: Optional[List[Dict[str, Any]]] = None,
    generative_ai_report: Optional[Dict[str, Any]] = None,
) -> AEOMeasurementSnapshot:
    """
    Creates a measurement snapshot from current SERP data.
    Records snippet owner, PAA presence, AI Overview sources.
    Includes zero-click proxy (high impressions, low CTR).
    Tracks won_events, lost_events, answer_block_edits delta, and KPIs.
    Honest limits are always attached to the report.
    """
    serp_results = serp_results or {}
    sc_data = sc_data or {}
    now = datetime.now(timezone.utc).isoformat()

    snippet_wins = 0
    snippet_losses = 0
    paa_present = 0
    aio_cited = 0
    zero_click_candidates: List[str] = []
    won_events: List[Dict[str, Any]] = []
    lost_events: List[Dict[str, Any]] = []

    for target in tracked_targets:
        kw = target.keyword
        serp = serp_results.get(kw, {})

        # Snippet ownership
        snippet_owner = serp.get("snippet_owner_domain")
        if snippet_owner and our_domain and snippet_owner.lower() == our_domain.lower():
            snippet_wins += 1
            if target.won_at is None:
                target.won_at = now
                won_events.append({
                    "keyword": kw,
                    "question": target.question,
                    "surface": target.surface.value if hasattr(target.surface, "value") else str(target.surface),
                    "won_at": now,
                    "snippet_format": target.snippet_format.value if hasattr(target.snippet_format, "value") else str(target.snippet_format),
                    "url": target.our_url,
                })
            target.lost_at = None
        elif snippet_owner and target.won_at and not target.lost_at:
            snippet_losses += 1
            target.lost_at = now
            lost_events.append({
                "keyword": kw,
                "question": target.question,
                "surface": target.surface.value if hasattr(target.surface, "value") else str(target.surface),
                "lost_at": now,
                "new_owner": snippet_owner,
                "snippet_format": target.snippet_format.value if hasattr(target.snippet_format, "value") else str(target.snippet_format),
                "url": target.our_url,
            })

        # PAA presence
        if serp.get("paa_includes_our_url"):
            paa_present += 1

        # AIO / AI Overview citation
        if serp.get("aio_cites_our_url"):
            aio_cited += 1

        # Zero-click proxy from Search Console (high impressions, low CTR)
        kw_sc = sc_data.get(kw, {})
        impressions = kw_sc.get("impressions", 0)
        ctr = kw_sc.get("ctr", 1.0)
        if impressions >= 500 and ctr < 0.02:
            zero_click_candidates.append(kw)

        target.last_seen = now

    total = len(tracked_targets)
    ownership_pct = round((snippet_wins / total * 100) if total > 0 else 0.0, 1)
    paa_pct = round((paa_present / total * 100) if total > 0 else 0.0, 1)
    aio_pct = round((aio_cited / total * 100) if total > 0 else 0.0, 1)

    kpis = {
        "snippet_ownership_share_pct": ownership_pct,
        "paa_presence_pct": paa_pct,
        "aio_citation_share_pct": aio_pct,
        "total_won_events": len(won_events),
        "total_lost_events": len(lost_events),
        "zero_click_candidates_count": len(zero_click_candidates),
        "total_tracked": total,
    }

    return AEOMeasurementSnapshot(
        snapshot_at=now,
        keywords_tracked=total,
        snippet_wins=snippet_wins,
        snippet_losses=snippet_losses,
        paa_present=paa_present,
        aio_cited=aio_cited,
        zero_click_candidates=zero_click_candidates,
        ownership_share_pct=ownership_pct,
        won_events=won_events,
        lost_events=lost_events,
        answer_block_edits=answer_block_edits or [],
        generative_ai_report=generative_ai_report or {},
        paa_presence_pct=paa_pct,
        aio_citation_share_pct=aio_pct,
        kpis=kpis,
    )


# ---------------------------------------------------------------------------
# Full AEO Report Assembler
# ---------------------------------------------------------------------------

def run_aeo_analysis(
    article_keyword: str,
    keywords: List[str],
    draft: str,
    paa_questions: Optional[List[str]] = None,
    related_searches: Optional[List[str]] = None,
    gsc_question_queries: Optional[List[str]] = None,
    sales_questions: Optional[List[str]] = None,
    our_url: Optional[str] = None,
    rank_data: Optional[Dict[str, int]] = None,
    snippet_data: Optional[Dict[str, Dict[str, Any]]] = None,
    faq_answers: Optional[Dict[str, str]] = None,
    answer_content_map: Optional[Dict[str, str]] = None,
    entity_config: Optional[EntityLayerConfig] = None,
    search_sources: Optional[List[Dict[str, Any]]] = None,
    config: Optional[AEOConfig] = None,
) -> Dict[str, Any]:
    """
    Runs the full A5b AEO analysis pipeline and returns a serialisable report.
    """
    cfg = config or AEOConfig()

    # 1. Question Discovery
    targets = discover_answer_targets(
        keywords=keywords,
        paa_questions=paa_questions,
        related_searches=related_searches,
        gsc_question_queries=gsc_question_queries,
        sales_questions=sales_questions,
        our_url=our_url,
        rank_data=rank_data,
        snippet_data=snippet_data,
        config=cfg,
    )

    # 2. Eligibility Gate
    eligible, near_miss, not_eligible = apply_eligibility_gate(targets, config=cfg)

    # 3. Generate Answer Blocks for eligible targets (each verified in A4 claim pipeline)
    # If no targets are marked eligible due to absence of live SERP ranking data,
    # generate answer blocks for top near-miss / NO_RANK_DATA targets to equip the draft for featured snippets.
    answer_blocks: List[AnswerBlock] = []
    content_map = dict(answer_content_map or {})

    candidate_targets = list(eligible)
    if not candidate_targets and near_miss:
        candidate_targets = [t for t in near_miss if t.eligibility_status in (EligibilityStatus.NO_RANK_DATA, EligibilityStatus.NEAR_MISS)][:3]

    for target in candidate_targets:
        raw = content_map.get(target.keyword) or content_map.get(target.question, "")
        if not raw and draft:
            raw = extract_direct_answer_from_draft(draft, target.question, target.keyword)
        if not raw:
            continue
        block = generate_answer_block(target, raw, config=cfg)
        # Every answer block is verified in A4 as its own claim set
        block = verify_answer_block_claims(block, search_sources=search_sources)
        # Link target <-> block
        target.answer_block_id = block.block_id
        answer_blocks.append(block)

    # 4. Click-worthiness
    click_assessments = analyse_click_worthiness(answer_blocks, draft)

    # Attach click_anchor from assessment to blocks
    for assessment in click_assessments:
        if assessment.get("recommendation") and not assessment.get("has_click_anchor"):
            for block in answer_blocks:
                if block.block_id == assessment["block_id"] and not block.click_anchor:
                    block.click_anchor = assessment["recommendation"]

    # 5. FAQ Module
    faq_q_list = [naturalize_question(clean_double_question(q)) for q in (paa_questions or []) if q]
    if not faq_q_list and targets:
        faq_q_list = [t.question for t in targets[:4]]
    faq_ans_map = dict(faq_answers or {})
    if draft:
        for q in faq_q_list:
            if q not in faq_ans_map:
                extracted = extract_direct_answer_from_draft(draft, q, q)
                if extracted:
                    faq_ans_map[q] = extracted
    faq_items = generate_faq_items(
        paa_questions=faq_q_list,
        answers=faq_ans_map,
        config=cfg,
    )

    # 6. FAQPage schema (optional, AB-test only)
    faqpage_schema = render_faqpage_schema(faq_items) if cfg.include_faqpage_schema else None

    # 7. Entity Layer
    entity_layer = generate_entity_layer(entity_config)

    report = AEOReport(
        article_keyword=article_keyword,
        answer_targets=targets,
        answer_blocks=answer_blocks,
        faq_items=faq_items,
        entity_layer=entity_layer,
        eligible_count=len(eligible),
        near_miss_count=len(near_miss),
        not_eligible_count=len(not_eligible),
        config=cfg,
    )

    return {
        "aeo_report": report.model_dump(),
        "eligible_targets": [t.model_dump() for t in eligible],
        "near_miss_targets": [t.model_dump() for t in near_miss],
        "not_eligible_targets": [t.model_dump() for t in not_eligible],
        "answer_blocks": [b.model_dump() for b in answer_blocks],
        "faq_items": [f.model_dump() for f in faq_items],
        "faqpage_schema": faqpage_schema,
        "entity_layer": entity_layer,
        "click_worthiness": click_assessments,
        "config": cfg.model_dump(),
        "honest_limits": report.honest_limits,
        "faqpage_schema_note": report.faqpage_schema_note,
        "voice_note": (
            "Voice assistants reportedly draw from the same answers as featured snippets. "
            "Direct evidence for a separate voice channel is thin; no voice-specific features are built."
        ),
    }
