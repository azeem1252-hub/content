import logging
import time
import re
import httpx
from pathlib import Path
from typing import Dict, Any, Optional
from urllib.parse import urlsplit
from config import DEMO_WEBSITE_URL
from pipeline.utils import clean_article_content
from pipeline.utils import clean_slug as slugify

logger = logging.getLogger("pipeline.adapters.website_client")

_FAILURE_STATUS_VALUES = {"error", "failed", "failure"}
_SUCCESS_STATUS_VALUES = {"success", "ok", "published", "created"}


def _public_base_url(api_url: str) -> str:
    """Derives the site's public origin (scheme://host[:port]) from its API endpoint."""
    parts = urlsplit(api_url)
    if parts.scheme and parts.netloc:
        return f"{parts.scheme}://{parts.netloc}"
    return api_url.rstrip("/")


def _verify_publish_response(response: httpx.Response, api_url: str) -> Dict[str, Any]:
    """Verifies that a 2xx publish response proves the article was actually stored.

    A bare 2xx status is NOT proof: hosting platforms happily render error pages,
    SSO interstitials and landing pages with HTTP 200/201. We therefore require a
    JSON body that either reports the post's URL or carries an explicit success
    indicator (status/ok/success/slug). Returns a verdict dict with
    ``verified``, optional ``post_url``/``post_url_source``/``data``, and
    ``detail`` on failure.
    """
    content_type = (response.headers.get("content-type") or "").lower()
    if "json" not in content_type:
        return {
            "verified": False,
            "detail": (
                f"Endpoint returned HTTP {response.status_code} with content-type "
                f"'{content_type or 'unknown'}' instead of JSON — cannot confirm the article was stored."
            ),
        }
    try:
        data = response.json()
    except Exception:
        return {
            "verified": False,
            "detail": "Endpoint returned a 2xx status but the body is not valid JSON — cannot confirm the article was stored.",
        }
    if not isinstance(data, dict):
        return {
            "verified": False,
            "detail": "Endpoint returned a JSON value that is not an object — cannot confirm the article was stored.",
        }

    # Explicit failure payloads (some routes answer 200 with success=false).
    for key in ("ok", "success"):
        if key in data and data.get(key) is False:
            reason = data.get("error") or data.get("message") or f"{key}=false"
            return {"verified": False, "detail": f"Endpoint rejected the article: {reason}"}
    status_value = str(data.get("status", "")).lower()
    if status_value in _FAILURE_STATUS_VALUES:
        reason = data.get("error") or data.get("message") or ""
        return {"verified": False, "detail": f"Endpoint reported status '{status_value}': {reason}".strip()}

    remote_url = None
    for key in ("post_url", "url", "link", "permalink"):
        candidate = data.get(key)
        if isinstance(candidate, str) and candidate.strip():
            remote_url = candidate.strip()
            break

    success_signal = (
        bool(remote_url)
        or data.get("ok") is True
        or data.get("success") is True
        or status_value in _SUCCESS_STATUS_VALUES
        or bool(data.get("slug"))
    )
    if not success_signal:
        return {
            "verified": False,
            "detail": (
                "Endpoint returned a 2xx JSON response without a success indicator "
                "(no post_url/url/slug/ok) — the article may not have been stored."
            ),
        }

    resolved_url = None
    if remote_url:
        if remote_url.startswith(("http://", "https://")):
            resolved_url = remote_url
        elif remote_url.startswith("/"):
            resolved_url = f"{_public_base_url(api_url)}{remote_url}"
        else:
            resolved_url = f"{_public_base_url(api_url)}/{remote_url}"

    return {
        "verified": True,
        "post_url": resolved_url,
        "post_url_source": "site" if resolved_url else "unreported",
        "data": data,
    }


def _normalize_site_url(api_url: str) -> str:
    """Defaults the scheme to https for bare hostnames without rewriting URLs
    that already carry a scheme — an explicit http:// URL (e.g. a LAN test host
    like http://192.168.1.20:3000) must stay on http or it becomes unreachable."""
    api_url = api_url.strip()
    if not api_url.startswith(("http://", "https://")):
        return f"https://{api_url}"
    return api_url


def publish_to_nextjs(
    url: str,
    secret_token: Optional[str],
    title: str,
    content: str,
    slug: Optional[str] = None,
    excerpt: Optional[str] = None,
    hero_image_url: Optional[str] = None,
    tags: Optional[str] = None,
    meta_title: Optional[str] = None,
    meta_description: Optional[str] = None,
    author: str = "The Dispatch Editorial Bureau",
    word_count: Optional[int] = None,
    read_time: Optional[int] = None
) -> Dict[str, Any]:
    """
    Submits an article to a hosted Next.js website via its API route.
    Sends standard JSON payload with Bearer secret authorization.
    """
    api_url = _normalize_site_url(url)

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "ContentPipelineAgent/2.0 (Compatible; EditorialDesk/1.0)",
    }
    if secret_token:
        headers["Authorization"] = f"Bearer {secret_token.strip()}"
        headers["x-nextjs-agent-secret"] = secret_token.strip()

    # 1. Sanitize Slug: lowercase alphanumeric separated by single hyphens, <= 80 chars
    clean_slug = slugify(slug or title, fallback=f"post-{int(time.time())}")

    # 2. Sanitize Title: max 200 chars
    clean_title = (title or "Untitled Article").strip()[:200]

    # 3. Sanitize Excerpt: non-empty, max 500 chars
    clean_excerpt = (excerpt or meta_description or content[:180].replace("#", "").strip()).strip()[:500]
    if not clean_excerpt:
        clean_excerpt = clean_title

    # 4. Sanitize Tags: array of strings, max 8 items, each <= 24 characters
    tag_list = []
    if isinstance(tags, str):
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]
    elif isinstance(tags, list):
        tag_list = [str(t).strip() for t in tags if str(t).strip()]
    
    clean_tags = []
    for t in tag_list:
        clean_t = t[:24].strip()
        if clean_t and clean_t not in clean_tags:
            clean_tags.append(clean_t)
        if len(clean_tags) >= 8:
            break
    if not clean_tags:
        clean_tags = ["Technology"]

    # 5. Sanitize Author: non-empty string (honor the caller-provided author)
    clean_author = (author or "The Dispatch Editorial Bureau").strip()

    # 6. Sanitize Hero Image URL & attach Base64 binary payload if available locally
    clean_hero = hero_image_url.strip() if hero_image_url else None
    if clean_hero and clean_hero.startswith("/static/uploads/"):
        clean_hero = clean_hero.replace("/static/uploads/", "/uploads/")

    hero_b64 = None
    img_filename = None
    if hero_image_url:
        try:
            import base64
            from config import BASE_DIR
            img_filename = Path(hero_image_url).name
            source_img = BASE_DIR / "web" / "static" / "uploads" / img_filename
            if source_img.exists() and source_img.stat().st_size > 0:
                hero_b64 = base64.b64encode(source_img.read_bytes()).decode("ascii")
        except Exception as b64_err:
            logger.debug(f"Could not encode hero image to base64: {b64_err}")

    # 7. Sanitize Content: shared canonical sanitizer (fences, frontmatter,
    #    placeholder images, visual concepts, SEO notes)
    clean_content = clean_article_content(content or "")

    try:
        import markdown
        rendered_html = markdown.markdown(
            clean_content,
            extensions=["fenced_code", "tables", "nl2br", "sane_lists"]
        )
    except Exception:
        rendered_html = ""

    from config import PUBLIC_BASE_URL
    payload = {
        "title": clean_title,
        "slug": clean_slug,
        "content": clean_content,
        "html": rendered_html,
        "excerpt": clean_excerpt,
        "hero_image_url": clean_hero,
        "coverImage": clean_hero,
        "image": clean_hero,
        "hero_image_base64": hero_b64,
        "image_filename": img_filename,
        "public_image_url": f"{PUBLIC_BASE_URL.rstrip('/')}/static/uploads/{img_filename}" if img_filename else None,
        "tags": clean_tags,
        "author": clean_author,
        "meta_title": meta_title or clean_title,
        "meta_description": meta_description or clean_excerpt,
        "word_count": word_count or len(clean_content.split()),
        "read_time": read_time or max(1, round(len(clean_content.split()) / 200)),
        "status": "published"
    }

    logger.info(f"Publishing article '{title}' to Next.js endpoint: {api_url}")
    max_retries = 2
    last_error_detail = ""
    last_status_code = 0

    for attempt in range(1, max_retries + 1):
        try:
            # follow_redirects matters: many hosts answer POSTs with a 307/308 to
            # the canonical host/route (http->https, apex->www, trailing slash),
            # and httpx does not follow redirects by default.
            with httpx.Client(timeout=20.0, follow_redirects=True) as client:
                response = client.post(api_url, json=payload, headers=headers)
                
                if response.status_code in [200, 201]:
                    verdict = _verify_publish_response(response, api_url)
                    if verdict["verified"]:
                        remote_url = verdict.get("post_url")
                        logger.info(
                            f"Successfully published to Next.js: {remote_url or api_url} "
                            f"(status_code={response.status_code}, url_source={verdict.get('post_url_source')})"
                        )
                        return {
                            "status": "success",
                            "post_url": remote_url,
                            "post_url_source": verdict.get("post_url_source", "unreported"),
                            "verified": True,
                            "status_code": response.status_code,
                            "response": verdict.get("data") or {}
                        }
                    logger.error(
                        f"Next.js publish returned HTTP {response.status_code} but could not be "
                        f"verified: {verdict.get('detail')}. Body: {response.text[:200]}"
                    )
                    return {
                        "status": "error",
                        "status_code": response.status_code,
                        "detail": verdict.get("detail") or "Publish could not be verified"
                    }
                elif response.status_code in [429, 500, 502, 503, 504] and attempt < max_retries:
                    logger.warning(f"Next.js gateway error ({response.status_code}) on attempt {attempt}/{max_retries}. Retrying in 2s...")
                    time.sleep(2.0)
                    continue
                else:
                    last_status_code = response.status_code
                    last_error_detail = response.text[:300]
                    logger.error(f"Next.js publish failed ({response.status_code}): {response.text[:200]}")
                    return {
                        "status": "error",
                        "status_code": response.status_code,
                        "detail": last_error_detail
                    }
        except (httpx.TimeoutException, httpx.NetworkError) as net_err:
            last_error_detail = str(net_err)
            if attempt < max_retries:
                logger.warning(f"Next.js connection timeout/network blip ({net_err}) on attempt {attempt}/{max_retries}. Retrying in 2s...")
                time.sleep(2.0)
                continue
            logger.error(f"Connection error publishing to Next.js at {api_url}: {net_err}")
            return {
                "status": "error",
                "detail": str(net_err)
            }
        except Exception as e:
            logger.error(f"Unexpected error publishing to Next.js at {api_url}: {e}")
            return {
                "status": "error",
                "detail": str(e)
            }

    return {
        "status": "error",
        "status_code": last_status_code,
        "detail": last_error_detail or "Publishing failed after retries"
    }


def test_nextjs_connection(url: str, secret_token: Optional[str] = None) -> Dict[str, Any]:
    """
    Verifies a Next.js website API route's reachability, authentication and latency.

    Strategy: a non-destructive GET health check first (the /api/posts route the
    studio generates answers GET with a JSON readiness document, so nothing is
    written). Endpoints without a GET handler fall back to the legacy POST ping.
    The canonical route rejects a title-less ping with a 400 *after* the auth
    gate, so that validation response still proves connectivity + credentials.
    """
    api_url = _normalize_site_url(url)

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "ContentPipelineAgent/2.0 (Compatible; EditorialDesk/1.0)",
    }
    if secret_token:
        headers["Authorization"] = f"Bearer {secret_token.strip()}"
        headers["x-nextjs-agent-secret"] = secret_token.strip()

    test_payload = {
        "action": "ping",
        "test": True,
        "message": "Content Pipeline Agent Connection Test"
    }

    def _auth_error(status_code: int, elapsed_ms: int) -> Dict[str, Any]:
        return {
            "status": "auth_error",
            "success": False,
            "status_code": status_code,
            "latency_ms": elapsed_ms,
            "message": f"Authentication Failed (HTTP {status_code}). Check secret_token."
        }

    def _warning(status_code: int, elapsed_ms: int, note: str = "") -> Dict[str, Any]:
        suffix = f" — {note}" if note else ""
        return {
            "status": "warning",
            "success": False,
            "status_code": status_code,
            "latency_ms": elapsed_ms,
            "message": f"Endpoint reachable but returned HTTP {status_code} ({elapsed_ms}ms){suffix}"
        }

    t0 = time.time()
    try:
        with httpx.Client(timeout=8.0, follow_redirects=True) as client:
            # 1. Primary: non-destructive GET health check.
            get_resp = client.get(api_url, headers=headers)
            elapsed_ms = round((time.time() - t0) * 1000)
            get_json = None
            get_ct = (get_resp.headers.get("content-type") or "").lower()
            if get_resp.status_code in (200, 201) and "json" in get_ct:
                get_json = get_resp.json()
            if get_resp.status_code in (401, 403):
                return _auth_error(get_resp.status_code, elapsed_ms)
            if get_resp.status_code in (200, 201) and isinstance(get_json, dict):
                version = get_json.get("version")
                detail = f" (route version {version})" if version else ""
                return {
                    "status": "success",
                    "success": True,
                    "status_code": get_resp.status_code,
                    "latency_ms": elapsed_ms,
                    "message": f"Connected & Authenticated ({elapsed_ms}ms) — Next.js API Ready{detail}.",
                    "health": get_json,
                }

            # 2. Fallback: legacy endpoints without a GET handler. The title-less
            #    POST ping is deliberately non-destructive for the canonical route.
            response = client.post(api_url, json=test_payload, headers=headers)
            elapsed_ms = round((time.time() - t0) * 1000)
            response_ct = (response.headers.get("content-type") or "").lower()
            if response.status_code in [401, 403]:
                return _auth_error(response.status_code, elapsed_ms)
            if response.status_code in [200, 201]:
                if "json" in response_ct:
                    return {
                        "status": "success",
                        "success": True,
                        "status_code": response.status_code,
                        "latency_ms": elapsed_ms,
                        "message": f"Connected & Authenticated ({elapsed_ms}ms) — Next.js API Ready"
                    }
                return _warning(response.status_code, elapsed_ms, "response was not JSON; cannot confirm the API route")
            if response.status_code in [400, 422]:
                # The canonical route authenticates first, then rejects the
                # title-less ping with a validation error — a healthy signature.
                return {
                    "status": "success",
                    "success": True,
                    "status_code": response.status_code,
                    "latency_ms": elapsed_ms,
                    "message": (
                        f"Connected & Authenticated ({elapsed_ms}ms) — API route is healthy and "
                        f"rejected the diagnostic ping with HTTP {response.status_code} as expected."
                    )
                }
            return _warning(response.status_code, elapsed_ms)
    except Exception as e:
        elapsed_ms = round((time.time() - t0) * 1000)
        return {
            "status": "error",
            "success": False,
            "status_code": 0,
            "latency_ms": elapsed_ms,
            "message": f"Connection unreachable: {str(e)[:120]}"
        }


def publish_to_website(
    title: str,
    content: str,
    slug: Optional[str] = None,
    excerpt: Optional[str] = None,
    hero_image_url: Optional[str] = None,
    tags: Optional[str] = None,
    meta_title: Optional[str] = None,
    meta_description: Optional[str] = None,
    author: str = "The Dispatch Editorial Bureau",
    base_url: Optional[str] = None
) -> Dict[str, Any]:
    """
    Submits an article to the default / local Demo Website (POST /api/posts).
    Maintained for backward compatibility and local testing.
    """
    api_url = f"{(base_url or DEMO_WEBSITE_URL).rstrip('/')}/api/posts"
    return publish_to_nextjs(
        url=api_url,
        secret_token=None,
        title=title,
        content=content,
        slug=slug,
        excerpt=excerpt,
        hero_image_url=hero_image_url,
        tags=tags,
        meta_title=meta_title,
        meta_description=meta_description,
        author=author
    )
