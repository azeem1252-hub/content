"""
First-Party Search & Conversion Analytics Client (Pillar VI: Closed-Loop Auditing).

Replaces the parameter-passing triage stub with real ingestion. Every function
degrades gracefully: missing credentials yield ``configured: False`` and an
explicit reason instead of zeros.

Providers:
  - Google Search Console (impressions / clicks / CTR / position per page+query)
  - Google Analytics 4     (sessions, conversions, revenue per landing page)
  - Plausible              (single API key page breakdown)
  - PostHog                (HogQL page + channel breakdown)

Google auth uses the OAuth refresh-token flow (pure HTTP, no crypto libraries
required). A service-account file is also honoured when `google-auth` happens to
be installed.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx

import config

logger = logging.getLogger("pipeline.adapters.analytics")

GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
GSC_ENDPOINT = "https://searchconsole.googleapis.com/webmasters/v3/sites/{site}/searchAnalytics/query"
GA4_ENDPOINT = "https://analyticsdata.googleapis.com/v1beta/properties/{prop}:runReport"
GA4_SCOPES = ["https://www.googleapis.com/auth/analytics.readonly"]
GSC_SCOPES = ["https://www.googleapis.com/auth/webmasters.readonly"]

AI_REFERRAL_SOURCES = (
    "chatgpt", "openai", "perplexity", "claude", "anthropic", "gemini", "bard",
    "copilot", "you.com", "phind", "poe.com", "ai overview",
)


def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


# ---------------------------------------------------------------------------
# Google OAuth (refresh-token flow)
# ---------------------------------------------------------------------------

def _google_access_token(scopes: List[str]) -> Optional[str]:
    """Returns a Google OAuth access token, or None when unconfigured.

    Order: explicit GOOGLE_ACCESS_TOKEN -> refresh-token exchange ->
    service-account (only if google-auth is installed).
    """
    static = _cfg("GOOGLE_ACCESS_TOKEN")
    if static:
        return static

    client_id = _cfg("GOOGLE_OAUTH_CLIENT_ID")
    client_secret = _cfg("GOOGLE_OAUTH_CLIENT_SECRET")
    refresh_token = _cfg("GOOGLE_OAUTH_REFRESH_TOKEN")
    if client_id and client_secret and refresh_token:
        try:
            with httpx.Client(timeout=20.0) as client:
                resp = client.post(GOOGLE_TOKEN_ENDPOINT, data={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "refresh_token": refresh_token,
                    "grant_type": "refresh_token",
                })
                if resp.status_code == 200:
                    return resp.json().get("access_token")
                logger.warning(f"Google token refresh HTTP {resp.status_code}: {resp.text[:200]}")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Google token refresh failed: {e}")

    sa_path = _cfg("GOOGLE_SERVICE_ACCOUNT_JSON")
    if sa_path:
        try:
            from google.oauth2 import service_account  # type: ignore
            import google.auth.transport.requests as google_requests  # type: ignore

            creds = service_account.Credentials.from_service_account_file(sa_path, scopes=scopes)
            creds.refresh(google_requests.Request())
            return creds.token
        except Exception as e:  # noqa: BLE001
            logger.info(f"Service-account auth unavailable ({e}); use the OAuth refresh-token flow.")

    return None


def google_auth_status() -> Dict[str, Any]:
    """Status descriptor for Settings/Health UI."""
    configured = bool(_cfg("GOOGLE_ACCESS_TOKEN")) or all(
        _cfg(k) for k in ("GOOGLE_OAUTH_CLIENT_ID", "GOOGLE_OAUTH_CLIENT_SECRET", "GOOGLE_OAUTH_REFRESH_TOKEN")
    ) or bool(_cfg("GOOGLE_SERVICE_ACCOUNT_JSON"))
    return {
        "configured": configured,
        "flow": "refresh_token" if _cfg("GOOGLE_OAUTH_REFRESH_TOKEN") else ("access_token" if _cfg("GOOGLE_ACCESS_TOKEN") else "none"),
        "note": "" if configured else "Set GOOGLE_OAUTH_CLIENT_ID/SECRET/REFRESH_TOKEN (or GOOGLE_ACCESS_TOKEN) to ingest Search Console & GA4.",
    }


# ---------------------------------------------------------------------------
# Google Search Console
# ---------------------------------------------------------------------------

def fetch_search_console(
    site_url: Optional[str] = None,
    days: int = 28,
    row_limit: int = 500,
    dimensions: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Fetches search analytics rows from Google Search Console."""
    site = (site_url or _cfg("GSC_SITE_URL")).strip()
    if not site:
        return {"configured": False, "source": "gsc", "rows": [],
                "error": "GSC_SITE_URL is not configured"}
    token = _google_access_token(GSC_SCOPES)
    if not token:
        return {"configured": False, "source": "gsc", "rows": [],
                "error": "Google credentials are not configured"}

    from datetime import datetime, timedelta, timezone
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=max(1, days))
    url = GSC_ENDPOINT.format(site=httpx.URL(site))
    payload = {
        "startDate": start.isoformat(),
        "endDate": end.isoformat(),
        "dimensions": dimensions or ["page", "query"],
        "rowLimit": row_limit,
        "dataState": "final",
    }
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(url, headers={"Authorization": f"Bearer {token}"}, json=payload)
            if resp.status_code != 200:
                logger.warning(f"GSC query HTTP {resp.status_code}: {resp.text[:200]}")
                return {"configured": True, "source": "gsc", "rows": [], "error": f"HTTP {resp.status_code}: {resp.text[:160]}"}
            rows = []
            for r in resp.json().get("rows", []) or []:
                keys = r.get("keys") or []
                rows.append({
                    "url": keys[0] if keys else None,
                    "query": keys[1] if len(keys) > 1 else None,
                    "impressions": int(r.get("impressions") or 0),
                    "clicks": int(r.get("clicks") or 0),
                    "ctr": round(float(r.get("ctr") or 0.0) * 100, 2),
                    "position": round(float(r.get("position") or 0.0), 1),
                    "source": "gsc",
                })
            return {"configured": True, "source": "gsc", "rows": rows, "start": start.isoformat(), "end": end.isoformat()}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"GSC request failed: {e}")
        return {"configured": True, "source": "gsc", "rows": [], "error": str(e)}


# ---------------------------------------------------------------------------
# Google Analytics 4
# ---------------------------------------------------------------------------

def fetch_ga4(
    property_id: Optional[str] = None,
    days: int = 28,
    row_limit: int = 500,
) -> Dict[str, Any]:
    """Fetches page-level sessions/conversions/revenue plus AI-referral breakdown."""
    prop = (property_id or _cfg("GA4_PROPERTY_ID")).strip()
    if not prop:
        return {"configured": False, "source": "ga4", "rows": [], "error": "GA4_PROPERTY_ID is not configured"}
    token = _google_access_token(GA4_SCOPES)
    if not token:
        return {"configured": False, "source": "ga4", "rows": [], "error": "Google credentials are not configured"}

    payload = {
        "dateRanges": [{"startDate": f"{max(1, days)}daysAgo", "endDate": "today"}],
        "dimensions": [{"name": "landingPagePlusQueryString"}, {"name": "sessionSource"}],
        "metrics": [
            {"name": "sessions"},
            {"name": "conversions"},
            {"name": "totalRevenue"},
        ],
        "limit": row_limit,
    }
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                GA4_ENDPOINT.format(prop=prop),
                headers={"Authorization": f"Bearer {token}"},
                json=payload,
            )
            if resp.status_code != 200:
                logger.warning(f"GA4 query HTTP {resp.status_code}: {resp.text[:200]}")
                return {"configured": True, "source": "ga4", "rows": [], "error": f"HTTP {resp.status_code}: {resp.text[:160]}"}
            rows = []
            ai_referrals = {"sessions": 0, "conversions": 0, "revenue": 0.0}
            for r in resp.json().get("rows", []) or []:
                dims = [d.get("value") for d in r.get("dimensionValues", [])]
                mets = [m.get("value") for m in r.get("metricValues", [])]
                sessions = int(float(mets[0])) if len(mets) > 0 and mets[0] else 0
                conversions = float(mets[1]) if len(mets) > 1 and mets[1] else 0.0
                revenue = float(mets[2]) if len(mets) > 2 and mets[2] else 0.0
                source = (dims[1] if len(dims) > 1 else "") or ""
                if any(ai in source.lower() for ai in AI_REFERRAL_SOURCES):
                    ai_referrals["sessions"] += sessions
                    ai_referrals["conversions"] += conversions
                    ai_referrals["revenue"] += revenue
                rows.append({
                    "url": dims[0] if dims else None,
                    "source": source,
                    "sessions": sessions,
                    "conversions": conversions,
                    "revenue": round(revenue, 2),
                    "is_ai_referral": any(ai in source.lower() for ai in AI_REFERRAL_SOURCES),
                })
            return {"configured": True, "source": "ga4", "rows": rows, "ai_referrals": ai_referrals}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"GA4 request failed: {e}")
        return {"configured": True, "source": "ga4", "rows": [], "error": str(e)}


# ---------------------------------------------------------------------------
# Plausible & PostHog (single-key backends)
# ---------------------------------------------------------------------------

def fetch_plausible(site_id: Optional[str] = None, days: int = 28, limit: int = 200) -> Dict[str, Any]:
    """Fetches a Plausible page breakdown (sessions, bounce rate, conversions)."""
    sid = (site_id or _cfg("PLAUSIBLE_SITE_ID")).strip()
    key = _cfg("PLAUSIBLE_API_KEY")
    if not (sid and key):
        return {"configured": False, "source": "plausible", "rows": [],
                "error": "PLAUSIBLE_SITE_ID / PLAUSIBLE_API_KEY are not configured"}
    host = _cfg("PLAUSIBLE_HOST", "https://plausible.io").rstrip("/")
    try:
        with httpx.Client(timeout=25.0) as client:
            resp = client.get(
                f"{host}/api/v1/stats/breakdown",
                params={"site_id": sid, "period": f"{max(1, days)}d", "property": "event:page", "limit": limit},
                headers={"Authorization": f"Bearer {key}"},
            )
            if resp.status_code != 200:
                return {"configured": True, "source": "plausible", "rows": [], "error": f"HTTP {resp.status_code}"}
            rows = []
            for r in resp.json().get("results", []) or []:
                rows.append({
                    "url": r.get("page"),
                    "sessions": int(r.get("visitors") or 0),
                    "pageviews": int(r.get("pageviews") or 0),
                    "conversion_rate": round(float(r.get("conversion_rate") or 0.0), 2),
                })
            return {"configured": True, "source": "plausible", "rows": rows}
    except Exception as e:  # noqa: BLE001
        return {"configured": True, "source": "plausible", "rows": [], "error": str(e)}


def fetch_posthog(project_id: Optional[str] = None, days: int = 28, limit: int = 200) -> Dict[str, Any]:
    """Runs a HogQL query for page-level sessions and AI-referral traffic."""
    pid = (project_id or _cfg("POSTHOG_PROJECT_ID")).strip()
    key = _cfg("POSTHOG_API_KEY")
    if not (pid and key):
        return {"configured": False, "source": "posthog", "rows": [],
                "error": "POSTHOG_PROJECT_ID / POSTHOG_API_KEY are not configured"}
    host = _cfg("POSTHOG_HOST", "https://app.posthog.com").rstrip("/")
    ai_like = "|".join(AI_REFERRAL_SOURCES)
    query = (
        "SELECT properties.$pathname AS path, "
        "count() AS sessions, "
        f"countIf(lower(properties.$referring_domain) LIKE '%{ai_like}%') AS ai_sessions "
        "FROM events WHERE event = '$pageview' "
        f"AND timestamp > now() - INTERVAL {max(1, days)} DAY "
        "GROUP BY path ORDER BY sessions DESC "
        f"LIMIT {limit}"
    )
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                f"{host}/api/projects/{pid}/query",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"query": {"kind": "HogQLQuery", "query": query}},
            )
            if resp.status_code != 200:
                return {"configured": True, "source": "posthog", "rows": [], "error": f"HTTP {resp.status_code}"}
            body = resp.json()
            columns = body.get("columns") or []
            results = body.get("results") or []
            rows = []
            for row in results:
                record = dict(zip(columns, row)) if columns else {}
                rows.append({
                    "url": record.get("path") or (row[0] if row else None),
                    "sessions": int(record.get("sessions") or (row[1] if len(row) > 1 else 0) or 0),
                    "ai_sessions": int(record.get("ai_sessions") or (row[2] if len(row) > 2 else 0) or 0),
                })
            return {"configured": True, "source": "posthog", "rows": rows}
    except Exception as e:  # noqa: BLE001
        return {"configured": True, "source": "posthog", "rows": [], "error": str(e)}


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def resolve_provider() -> str:
    """Returns the preferred analytics source: gsc > ga4 > posthog > plausible."""
    if _cfg("GSC_SITE_URL") and google_auth_status()["configured"]:
        return "gsc"
    if _cfg("GA4_PROPERTY_ID") and google_auth_status()["configured"]:
        return "ga4"
    if _cfg("POSTHOG_PROJECT_ID") and _cfg("POSTHOG_API_KEY"):
        return "posthog"
    if _cfg("PLAUSIBLE_SITE_ID") and _cfg("PLAUSIBLE_API_KEY"):
        return "plausible"
    return "unconfigured"


def provider_status() -> Dict[str, Any]:
    """Status descriptor for Settings/Health UI."""
    provider = resolve_provider()
    return {
        "provider": provider,
        "configured": provider != "unconfigured",
        "google_auth": google_auth_status(),
        "note": "" if provider != "unconfigured" else (
            "No first-party analytics configured. Add Search Console/GA4 OAuth credentials "
            "or a PostHog/Plausible API key to enable real performance triage."
        ),
    }


def harvest_search_performance(website_id: Optional[str], days: int = 28) -> Dict[str, Any]:
    """Ingests whatever analytics sources are configured and persists the rows."""
    from storage.db import save_search_performance

    collected: List[Dict[str, Any]] = []
    sources: Dict[str, Any] = {}

    gsc = fetch_search_console(days=days)
    sources["gsc"] = {"configured": gsc.get("configured"), "rows": len(gsc.get("rows") or []), "error": gsc.get("error")}
    collected.extend(gsc.get("rows") or [])

    ga4 = fetch_ga4(days=days)
    sources["ga4"] = {"configured": ga4.get("configured"), "rows": len(ga4.get("rows") or []), "error": ga4.get("error")}

    plausible = fetch_plausible(days=days) if resolve_provider() == "plausible" else {"rows": []}
    sources["plausible"] = {"configured": plausible.get("configured"), "rows": len(plausible.get("rows") or [])}
    collected.extend(plausible.get("rows") or [])

    posthog = fetch_posthog(days=days) if resolve_provider() == "posthog" else {"rows": []}
    sources["posthog"] = {"configured": posthog.get("configured"), "rows": len(posthog.get("rows") or [])}
    collected.extend(posthog.get("rows") or [])

    written = save_search_performance(website_id, collected) if collected else 0
    return {
        "website_id": website_id,
        "provider": resolve_provider(),
        "configured": resolve_provider() != "unconfigured",
        "rows_collected": len(collected),
        "rows_written": written,
        "sources": sources,
        "ga4_ai_referrals": ga4.get("ai_referrals"),
    }
