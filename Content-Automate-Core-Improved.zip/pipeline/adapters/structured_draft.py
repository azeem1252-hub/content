"""
Structured Output & Sectional Draft Architecture (Pillar A3.1).

Replaces unstructured text blobs with a typed Pydantic tree of sections,
claims-flagged sentences, direct canonical answers, and empirical citations.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, field_validator


class ClaimCitation(BaseModel):
    """A factual claim extracted and flagged for verification and citation fidelity."""
    claim_text: str = Field(..., description="Exact factual assertion made in the section")
    source_url: Optional[str] = Field(None, description="External citation or primary source URL")
    anchor_text: Optional[str] = Field(None, description="Anchor text used in markdown")
    confidence: float = Field(1.0, ge=0.0, le=1.0, description="Verification confidence")
    citation_type: Literal[
        "first_party", "customer", "expert", "external_reference", "empirical_fact"
    ] = Field("empirical_fact", description="Provenance of claim")

    @field_validator("source_url", mode="before")
    @classmethod
    def coerce_source_url(cls, v: Any) -> Optional[str]:
        if isinstance(v, (list, tuple)):
            for item in v:
                if item and str(item).strip():
                    return str(item).strip()
            return None
        if isinstance(v, str):
            v_clean = v.strip()
            return v_clean if v_clean else None
        if v is None:
            return None
        return str(v).strip() or None

    @field_validator("citation_type", mode="before")
    @classmethod
    def coerce_citation_type(cls, v: Any) -> str:
        valid = {"first_party", "customer", "expert", "external_reference", "empirical_fact"}
        if isinstance(v, str) and v.lower() in valid:
            return v.lower()
        return "empirical_fact"


class DraftSection(BaseModel):
    """Individual section within the structured draft tree."""
    heading: str = Field(..., description="Heading text (H2 or H3)")
    level: int = Field(2, ge=2, le=4, description="Heading level (2=H2, 3=H3)")
    markdown_content: str = Field(..., description="Clean markdown body for this section")
    word_count: int = Field(0, description="Word count for this section")
    direct_answer: Optional[str] = Field(
        "", description="Canonical 40-60 word answer-first passage for GEO/AI Overviews"
    )
    claims: List[ClaimCitation] = Field(default_factory=list, description="Flagged factual assertions")
    citations: List[Dict[str, str]] = Field(default_factory=list, description="Extracted [Anchor](URL) links")
    key_entities_covered: List[str] = Field(default_factory=list, description="Key domain entities included")
    evidence_used: List[str] = Field(default_factory=list, description="IDs or titles of evidence pack items utilized")
    schema_snippet: Optional[Dict[str, Any]] = Field(None, description="Sectional JSON-LD schema snippet")


class StructuredDraft(BaseModel):
    """
    Pydantic tree representing the entire article draft.
    Enables section-by-section generation, targeted critique, and surgical revision.
    """
    title: str = Field(..., description="Article primary title (H1)")
    slug: str = Field(..., description="URL slug")
    meta_description: Optional[str] = Field("", description="SEO meta description (150-160 chars)")
    sections: List[DraftSection] = Field(default_factory=list, description="Ordered section tree")
    total_word_count: int = Field(0, description="Aggregate word count across all sections")
    evidence_items_used: List[str] = Field(default_factory=list, description="All evidence pack items cited")
    prompt_versions: Dict[str, str] = Field(default_factory=dict, description="Jinja2 prompt versions used")
    model_used: str = Field("default", description="Model used for drafting")
    style_profile_version: Optional[int] = Field(1, description="Website style profile version applied")
    critique_score: Optional[float] = Field(None, description="Score from self-critique loop")

    def recompute_metrics(self) -> None:
        """Updates word counts and compiles unique evidence items."""
        total = 0
        used_evidence = set()
        for sec in self.sections:
            words = len(re.findall(r"\b\w+\b", sec.markdown_content or ""))
            sec.word_count = words
            total += words
            for ev in sec.evidence_used:
                used_evidence.add(ev)
        self.total_word_count = total
        self.evidence_items_used = sorted(list(used_evidence))

    def to_markdown(self) -> str:
        """
        Renders the structured tree into a clean, complete publication Markdown article.
        Includes title, headings, canonical answer blocks, body content, and references list.
        """
        self.recompute_metrics()
        parts: List[str] = []

        # 1. Title
        title_clean = self.title.strip().lstrip("#").strip()
        parts.append(f"# {title_clean}\n")

        # 2. Sections
        all_citations: List[Dict[str, str]] = []
        for sec in self.sections:
            prefix = "#" * sec.level
            clean_heading = sec.heading.strip().lstrip("#").strip()
            clean_heading = re.sub(r"^\*\*([^*\n]+)\*\*$", r"\1", clean_heading)
            clean_heading = re.sub(r"^\*([^*\n]+)\*$", r"\1", clean_heading)
            parts.append(f"{prefix} {clean_heading}\n")

            # Canonical answer snippet if provided and not already opening the section
            if sec.direct_answer and sec.direct_answer.strip():
                ans = sec.direct_answer.strip()
                if not sec.markdown_content.startswith(ans[:30]):
                    parts.append(f"{ans}\n")

            if sec.markdown_content and sec.markdown_content.strip():
                # Avoid duplicating heading inside body if LLM repeated it
                body = sec.markdown_content.strip()
                heading_pattern = rf"^{re.escape(prefix)}\s+{re.escape(sec.heading)}\s*"
                body = re.sub(heading_pattern, "", body, flags=re.IGNORECASE).strip()
                parts.append(f"{body}\n")

            for c in sec.citations:
                if c.get("url") and c not in all_citations:
                    all_citations.append(c)

        # 3. References section if external citations exist
        if all_citations and not any("## References" in p for p in parts):
            parts.append("## References\n")
            for idx, cit in enumerate(all_citations, 1):
                anchor = cit.get("title") or cit.get("anchor") or cit.get("url") or f"Reference {idx}"
                url = cit.get("url", "#")
                parts.append(f"{idx}. [{anchor}]({url})")
            parts.append("")

        return "\n\n".join(parts).strip()
