"""
AI Search Visibility & First-Party ROI Attribution Engine (Pillar: Measurement Paradigms).

Implements the blueprint specification:
- Measures AI Search Inclusion Rate & Citation Frequency.
- Quantifies the 4.4x traffic value multiplier of AI engine referrals over standard organic clicks.
- Connects generative visibility directly to business impact (leads, pipeline, ROI).
"""

import logging
from typing import Dict, Any

logger = logging.getLogger("pipeline.adapters.attribution")

AI_TRAFFIC_VALUE_MULTIPLIER = 4.4


def calculate_ai_search_attribution(
    citations_count: int,
    estimated_monthly_visits: int = 250,
    average_conversion_rate: float = 0.035,
    lead_value_usd: float = 120.0
) -> Dict[str, Any]:
    """
    Computes tangible business ROI attribution metrics based on the 4.4x AI referral multiplier.
    """
    standard_value = estimated_monthly_visits * average_conversion_rate * lead_value_usd
    ai_adjusted_value = standard_value * AI_TRAFFIC_VALUE_MULTIPLIER

    conversions = round(estimated_monthly_visits * average_conversion_rate, 1)

    return {
        "citations_count": citations_count,
        "estimated_monthly_visits": estimated_monthly_visits,
        "projected_conversions": conversions,
        "standard_organic_value_usd": round(standard_value, 2),
        "ai_attributed_pipeline_value_usd": round(ai_adjusted_value, 2),
        "multiplier_applied": AI_TRAFFIC_VALUE_MULTIPLIER,
        "summary": f"${ai_adjusted_value:,.2f} projected pipeline value from {citations_count} AI citations (4.4x intent multiplier)."
    }


def calculate_first_party_attribution(
    ai_sessions: int,
    ai_conversions: float,
    ai_revenue: float,
    total_sessions: int = 0,
    total_conversions: float = 0.0,
    total_revenue: float = 0.0,
    lead_value_usd: float = 120.0,
) -> Dict[str, Any]:
    """Joins measured AI-referral traffic to downstream conversions and revenue.

    Unlike calculate_ai_search_attribution (which projects from an assumed
    conversion rate), this works from first-party analytics: the sessions that
    arrived from AI sources and the conversions/revenue they actually produced.
    Revenue is used when supplied; otherwise conversions are monetized at
    ``lead_value_usd`` to keep the two comparable.
    """
    effective_revenue = ai_revenue if ai_revenue > 0 else (ai_conversions * lead_value_usd)
    conversion_rate = (ai_conversions / ai_sessions * 100) if ai_sessions > 0 else 0.0
    revenue_per_session = (effective_revenue / ai_sessions) if ai_sessions > 0 else 0.0
    standard_revenue_per_session = (total_revenue / total_sessions) if total_sessions > 0 else 0.0
    lift = (
        round(revenue_per_session / standard_revenue_per_session, 2)
        if standard_revenue_per_session > 0 and revenue_per_session > 0
        else None
    )

    return {
        "measured": True,
        "data_basis": "first_party_analytics",
        "ai_sessions": ai_sessions,
        "ai_conversions": round(float(ai_conversions), 2),
        "ai_revenue_usd": round(float(ai_revenue), 2),
        "ai_attributed_value_usd": round(float(effective_revenue), 2),
        "ai_conversion_rate_percent": round(conversion_rate, 2),
        "revenue_per_ai_session_usd": round(revenue_per_session, 2),
        "revenue_per_standard_session_usd": round(standard_revenue_per_session, 2),
        "measured_value_multiplier": lift,
        "total_sessions": total_sessions,
        "total_conversions": round(float(total_conversions), 2),
        "total_revenue_usd": round(float(total_revenue), 2),
        "summary": (
            f"${effective_revenue:,.2f} attributed to {ai_sessions} AI-referral sessions "
            f"({conversion_rate:.2f}% conversion)."
        ),
    }


def calculate_inclusion_rate(
    brand_citations: int,
    total_industry_queries: int = 100
) -> Dict[str, Any]:
    """
    Computes brand inclusion rate across tracked AI queries (ChatGPT, Perplexity, Google AI Overviews).
    """
    rate = (brand_citations / total_industry_queries * 100) if total_industry_queries > 0 else 0.0
    return {
        "brand_citations": brand_citations,
        "total_queries_tracked": total_industry_queries,
        "inclusion_rate_percent": round(rate, 1),
        "visibility_tier": "High Authority" if rate >= 25.0 else ("Growing Influence" if rate >= 10.0 else "Emerging")
    }
