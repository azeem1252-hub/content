"""
A5c.7 Professional Layout Checklist & Typography Linter (Applied through Blueprints).

Validates the complete professional editorial layout standard:
1. Document Structure & Checklist:
   - H1: Single authoritative title
   - Byline: With photo linking to author page, and optional "reviewed by" expert
   - Dates: Both published and updated dates for freshness signals
   - Reading time: Calculated reading time estimate (225 words/min)
   - Key takeaways near the top: Executive summary within first 25% of document
   - Table of contents with jump links: Required for long posts (>1,200 words or >=3 major headings)
   - Answer-first intro: Direct answer to primary query in opening block
   - Question-form H2/H3: Natural question phrasing for informational queries
   - Tables and figures with captions: Explicit captions, credits, and accessible labels
   - Callouts for notes and warnings: Specialized callout blocks
   - FAQ: Question-and-answer pairs with FAQPage schema alignment
   - References: Visible authoritative Sources & References section
   - CTA: Exactly one relevant, non-spammy Call-To-Action component
   - Related reading: Inbound/contextual cluster links at document close

2. Typography Linting:
   - Paragraph length cap: Flags paragraphs exceeding 5 sentences or 120 words
   - Heading depth cap <= 3: Strictly H1, H2, H3 (rejects H4-H6, flags skipped levels)
   - Consistent terminology: Enforces canonical spelling (e.g. 'e-commerce' vs 'ecommerce')
   - Banned AI-sounding phrase list: Flags tells like 'delve', 'testament', 'tapestry', 'in conclusion'
   - Target reading level per audience: Flesch-Kincaid & Flesch Reading Ease calibration
     (general: 7-9th grade, technical: 10-13th grade, executive: 8-11th grade)
"""

from __future__ import annotations

import logging
import math
import re
from typing import Any, Dict, List, Optional, Set, Tuple
from pydantic import BaseModel, Field

from pipeline.adapters.article_model import (
    ArticleDocumentModel,
    BlockType,
    HeadingBlock,
    ParagraphBlock,
    AnswerBlock,
    KeyTakeawaysBlock,
    TableBlock,
    FigureBlock,
    CalloutBlock,
    FAQBlock,
    ReferencesBlock,
    CTABlock,
    AuthorBoxBlock,
)

logger = logging.getLogger("pipeline.adapters.layout_blueprints")


# ---------------------------------------------------------------------------
# Canonical Terminology & Banned AI Clichés
# ---------------------------------------------------------------------------

DEFAULT_CANONICAL_TERMINOLOGY = {
    # Preferred form: [variations to flag]
    "ecommerce": ["e-commerce", "e - commerce", "E-Commerce"],
    "frontend": ["front-end", "front end", "Front-End"],
    "backend": ["back-end", "back end", "Back-End"],
    "full-stack": ["fullstack", "full stack"],
    "on-premises": ["on-premise", "on premise"],
    "PostgreSQL": ["postgres", "postgresql", "Postgresql", "POSTGRES"],
    "Next.js": ["nextjs", "next.js", "NextJS", "NextJs"],
    "FastAPI": ["fastapi", "FastApi", "fast-api"],
    "SQLite": ["sqlite", "Sqlite", "SQLITE"],
    "TypeScript": ["typescript", "Typescript"],
    "JavaScript": ["javascript", "Javascript"],
    "Wi-Fi": ["wifi", "wi-fi", "WiFi", "Wifi"],
    "open-source": ["opensource", "open source (as adjective)"],
    "API": ["api", "Api"],
    "URL": ["url", "Url"],
}

DEFAULT_BANNED_AI_PHRASES = [
    "delve", "delves", "delving", "delve into", "delving into",
    "testament", "stands as a testament", "a testament to",
    "tapestry", "rich tapestry", "intricate tapestry",
    "in today's digital world", "in today's fast-paced world", "in the modern era",
    "evolving landscape", "rapidly evolving landscape", "competitive landscape",
    "game-changer", "game changer", "revolutionary", "revolutionize the way",
    "beacon", "beacon of hope", "beacon of innovation",
    "at its core", "at the core of",
    "it's important to remember", "it is important to note that", "it's worth noting that",
    "in conclusion", "to sum up", "in summary",
    "dive deep", "deep dive", "let's dive in", "let's break this down",
    "a myriad of", "plethora of", "interplay", "intricate interplay",
    "not only", "fostering a culture", "spearheading",
]


# ---------------------------------------------------------------------------
# Data Models
# ---------------------------------------------------------------------------

class LayoutChecklistItem(BaseModel):
    key: str
    label: str
    required: bool = True
    present: bool = False
    details: str = ""
    severity: str = "warning"  # "error" if hard requirement missing, "warning" otherwise


class LayoutChecklistReport(BaseModel):
    items: List[LayoutChecklistItem] = Field(default_factory=list)
    total_checks: int = 0
    passed_checks: int = 0
    required_missing: List[str] = Field(default_factory=list)
    all_required_met: bool = True
    completion_pct: float = 0.0
    recommendations: List[str] = Field(default_factory=list)


class BloatedParagraph(BaseModel):
    paragraph_index: int
    word_count: int
    sentence_count: int
    preview: str


class InconsistentTermFinding(BaseModel):
    preferred_term: str
    found_variant: str
    count: int


class TypographyLintReport(BaseModel):
    paragraph_cap_compliant: bool = True
    max_paragraph_words_limit: int = 120
    max_paragraph_sentences_limit: int = 5
    bloated_paragraphs: List[BloatedParagraph] = Field(default_factory=list)
    heading_depth_compliant: bool = True
    max_heading_depth: int = 3
    heading_depth_violations: List[str] = Field(default_factory=list)
    terminology_compliant: bool = True
    inconsistent_terms: List[InconsistentTermFinding] = Field(default_factory=list)
    banned_ai_phrases_found: List[Dict[str, Any]] = Field(default_factory=list)
    flesch_reading_ease: float = 0.0
    flesch_kincaid_grade: float = 0.0
    target_audience: str = "general"
    audience_level_match: bool = True
    audience_expected_grade_range: str = "7.0 - 9.0"
    audience_notes: str = ""
    overall_passed: bool = True
    warnings: List[str] = Field(default_factory=list)


class ProfessionalLayoutAudit(BaseModel):
    checklist: LayoutChecklistReport
    typography: TypographyLintReport
    is_compliant: bool
    summary: str


# ---------------------------------------------------------------------------
# A5c.7 Layout Checklist Engine
# ---------------------------------------------------------------------------

def audit_professional_layout_checklist(
    doc: ArticleDocumentModel,
    content_markdown: Optional[str] = None,
) -> LayoutChecklistReport:
    """
    Evaluates article document model against the A5c.7 professional layout checklist.
    Checks:
    - H1 single title
    - Byline with author photo & link (+ optional reviewed_by)
    - Published & updated dates
    - Reading time
    - Key takeaways near the top
    - Table of contents with jump links for long posts
    - Answer-first intro
    - Question-form H2/H3 for question queries
    - Tables & figures with captions
    - Callouts for notes/warnings
    - FAQ
    - References
    - Exactly one relevant CTA
    - Related reading
    """
    items: List[LayoutChecklistItem] = []
    recs: List[str] = []

    # 1. H1 Document Title
    h1_count = sum(1 for b in doc.blocks if b.block_type == "heading" and getattr(b, "level", 0) == 1)
    has_title = bool(doc.title.strip())
    has_valid_h1 = (h1_count == 1) or (h1_count == 0 and has_title)
    items.append(LayoutChecklistItem(
        key="h1",
        label="Single H1 Title",
        required=True,
        present=has_valid_h1,
        details=f"Title: '{doc.title}'" if has_valid_h1 else f"H1 count is {h1_count} (expected exactly 1).",
        severity="error" if not has_valid_h1 else "info",
    ))
    if not has_valid_h1:
        recs.append("Ensure exactly one authoritative H1 heading is present for the page.")

    # 2. Byline with Photo & Link + Optional Reviewed By
    author_box = next((b for b in doc.blocks if b.block_type == "author_box"), None)
    has_author_name = bool(doc.author and doc.author.strip() and doc.author.lower() not in ("admin", "user", "anonymous", ""))
    has_byline = bool(author_box or has_author_name)
    has_photo = bool(author_box and getattr(author_box, "photo_url", None))
    has_link = bool(author_box and (getattr(author_box, "author_url", None) or getattr(author_box, "author_page_link", None)))
    has_reviewed_by = bool(author_box and getattr(author_box, "reviewed_by", None))

    byline_details = f"Author: '{doc.author}'"
    if has_photo:
        byline_details += " [Photo attached]"
    if has_link:
        byline_details += " [Author page link attached]"
    if has_reviewed_by:
        byline_details += f" [Reviewed by: {author_box.reviewed_by}]"

    items.append(LayoutChecklistItem(
        key="byline",
        label="Author Byline & E-E-A-T Bio",
        required=True,
        present=has_byline,
        details=byline_details,
        severity="error" if not has_byline else "info",
    ))
    if not has_byline:
        recs.append("Add a named author byline with profile photo and link to their author page for E-E-A-T.")

    # 3. Published and Updated Dates
    has_pub_date = bool(doc.published_at)
    has_upd_date = bool(doc.updated_at)
    has_dates = has_pub_date and has_upd_date
    items.append(LayoutChecklistItem(
        key="dates",
        label="Published & Freshness Updated Dates",
        required=True,
        present=has_dates,
        details=f"Published: {doc.published_at or 'missing'} | Updated: {doc.updated_at or 'missing'}",
        severity="warning" if not has_dates else "info",
    ))
    if not has_dates:
        recs.append("Include both 'published_at' and 'updated_at' timestamps to signal content freshness.")

    # 4. Reading Time
    reading_mins = getattr(doc, "reading_time_minutes", None) or max(1, math.ceil(max(1, doc.total_word_count) / 225.0))
    has_reading_time = reading_mins > 0
    items.append(LayoutChecklistItem(
        key="reading_time",
        label="Reading Time Estimate",
        required=True,
        present=has_reading_time,
        details=f"{reading_mins} min read ({doc.total_word_count} words)",
        severity="info",
    ))

    # 5. Key Takeaways Near Top
    takeaways_idx = -1
    for idx, b in enumerate(doc.blocks):
        if b.block_type == "key_takeaways":
            takeaways_idx = idx
            break
    has_takeaways = (takeaways_idx >= 0)
    is_near_top = (takeaways_idx in (0, 1, 2, 3)) or (takeaways_idx >= 0 and takeaways_idx <= max(3, len(doc.blocks) // 4))

    items.append(LayoutChecklistItem(
        key="key_takeaways",
        label="Key Takeaways (Near Top)",
        required=True,
        present=has_takeaways and is_near_top,
        details=f"Positioned at block index {takeaways_idx}" if has_takeaways else "No Key Takeaways block found.",
        severity="warning" if not (has_takeaways and is_near_top) else "info",
    ))
    if not has_takeaways:
        recs.append("Add an executive Key Takeaways summary near the top for skimmers and quick takeaways.")

    # 6. Table of Contents with Jump Links
    is_long_post = doc.total_word_count > 1200 or len([b for b in doc.blocks if b.block_type == "heading"]) >= 4
    has_toc = any(
        "table of contents" in str(getattr(b, "text", "")).lower()
        or getattr(b, "block_type", "") == "toc"
        for b in doc.blocks
    )
    if not has_toc and content_markdown:
        has_toc = bool(re.search(r"(?i)(table of contents|contents|jump to)", content_markdown))

    toc_present = has_toc or (not is_long_post)  # Not strictly required for short posts
    items.append(LayoutChecklistItem(
        key="table_of_contents",
        label="Table of Contents (Jump Links)",
        required=is_long_post,
        present=toc_present,
        details=f"Long post ({doc.total_word_count} words): TOC present={has_toc}",
        severity="warning" if is_long_post and not has_toc else "info",
    ))
    if is_long_post and not has_toc:
        recs.append("Add a Table of Contents with jump links for this long-form post (>1,200 words).")

    # 7. Answer-First Intro
    has_answer_block = any(b.block_type == "answer_block" for b in doc.blocks)
    first_para = next((b for b in doc.blocks if b.block_type == "paragraph"), None)
    lead_text = first_para.text if first_para else ""
    is_answer_first = has_answer_block or (len(lead_text.split()) >= 20 and not lead_text.lower().startswith(("in today's", "dive in", "as we navigate")))

    items.append(LayoutChecklistItem(
        key="answer_first_intro",
        label="Answer-First Lead Inverted Pyramid",
        required=True,
        present=is_answer_first,
        details="Answer block present" if has_answer_block else ("Direct opening lead" if is_answer_first else "Opening begins with conversational filler."),
        severity="warning" if not is_answer_first else "info",
    ))
    if not is_answer_first:
        recs.append("Lead with a direct, comprehensive answer in the first paragraph before contextual depth.")

    # 8. Question-Form Headings (where intent is question)
    headings = [b for b in doc.blocks if b.block_type == "heading"]
    question_query = any(k in doc.title.lower() for k in ("how", "what", "why", "when", "where", "can", "is", "should"))
    question_headings = [h for h in headings if "?" in getattr(h, "text", "") or any(getattr(h, "text", "").lower().startswith(q) for q in ("how ", "what ", "why ", "when ", "is "))]
    q_headings_compliant = (not question_query) or (len(question_headings) >= 1)

    items.append(LayoutChecklistItem(
        key="question_form_headings",
        label="Question-Form H2/H3 for Question Queries",
        required=question_query,
        present=q_headings_compliant,
        details=f"{len(question_headings)} question-form headings detected." if q_headings_compliant else "Title is a question query, but section headings lack direct question phrasing.",
        severity="warning" if not q_headings_compliant else "info",
    ))
    if question_query and not q_headings_compliant:
        recs.append("Phrase main section headings (H2/H3) as natural questions matching user search intent.")

    # 9. Tables and Figures with Captions
    figures = [b for b in doc.blocks if b.block_type == "figure"]
    tables = [b for b in doc.blocks if b.block_type == "table"]
    figs_with_captions = sum(1 for f in figures if getattr(f, "caption", "").strip())
    tables_with_captions = sum(1 for t in tables if getattr(t, "caption", "").strip())

    media_captions_compliant = (len(figures) == 0 or figs_with_captions == len(figures)) and (len(tables) == 0 or tables_with_captions == len(tables))
    items.append(LayoutChecklistItem(
        key="captions",
        label="Tables & Figures with Captions",
        required=True,
        present=media_captions_compliant,
        details=f"Figures: {figs_with_captions}/{len(figures)} captioned | Tables: {tables_with_captions}/{len(tables)} captioned",
        severity="warning" if not media_captions_compliant else "info",
    ))
    if not media_captions_compliant:
        recs.append("Every figure (<figcaption>) and table (caption) must carry a descriptive, informative caption.")

    # 10. Callouts for Notes & Warnings
    callouts = [b for b in doc.blocks if b.block_type == "callout"]
    has_callouts = len(callouts) >= 1
    items.append(LayoutChecklistItem(
        key="callouts",
        label="Callouts for Notes & Warnings",
        required=False,
        present=has_callouts,
        details=f"{len(callouts)} callout(s) found ({', '.join(getattr(c, 'kind', 'note') for c in callouts)})",
        severity="info",
    ))

    # 11. FAQ Block
    faqs = [b for b in doc.blocks if b.block_type == "faq"]
    has_faq = len(faqs) >= 1
    items.append(LayoutChecklistItem(
        key="faq",
        label="FAQ Section with Schema Alignment",
        required=False,
        present=has_faq,
        details=f"{len(faqs)} FAQ block(s) present" if has_faq else "No FAQ block present.",
        severity="info",
    ))

    # 12. References Section
    has_references = any(b.block_type == "references" for b in doc.blocks) or bool(re.search(r"(?i)(sources|references)", content_markdown or ""))
    items.append(LayoutChecklistItem(
        key="references",
        label="Authoritative Visible References Block",
        required=True,
        present=has_references,
        details="Visible references section present" if has_references else "No formal references section found.",
        severity="warning" if not has_references else "info",
    ))
    if not has_references:
        recs.append("Append a visible Sources & References section at the end of the post citing all empirical evidence.")

    # 13. One Relevant CTA
    ctas = [b for b in doc.blocks if b.block_type == "cta"]
    has_single_cta = (len(ctas) == 1)
    cta_present = (len(ctas) >= 1)
    items.append(LayoutChecklistItem(
        key="cta",
        label="Single Relevant Call-To-Action (CTA)",
        required=True,
        present=cta_present,
        details=f"{len(ctas)} CTA(s) detected (optimal: exactly 1)" if cta_present else "No editorial CTA found.",
        severity="warning" if not cta_present or len(ctas) > 2 else "info",
    ))
    if not cta_present:
        recs.append("Include exactly one relevant, non-intrusive Call-To-Action component.")
    elif len(ctas) > 2:
        recs.append("Multiple CTAs detected. Editorial guidelines suggest a maximum of 1-2 focused CTAs.")

    # 14. Related Reading
    has_related = any(
        "related" in str(getattr(b, "text", "")).lower() or getattr(b, "block_type", "") == "related"
        for b in doc.blocks
    ) or bool(re.search(r"(?i)(related reading|further reading|recommended articles)", content_markdown or ""))

    items.append(LayoutChecklistItem(
        key="related_reading",
        label="Related Reading / Cluster Links",
        required=False,
        present=has_related,
        details="Related reading block present" if has_related else "No related reading cluster links.",
        severity="info",
    ))

    # Summary calculations
    required_missing = [it.label for it in items if it.required and not it.present]
    passed_count = sum(1 for it in items if it.present)
    total_count = len(items)
    completion_pct = round((passed_count / max(1, total_count)) * 100.0, 1)

    return LayoutChecklistReport(
        items=items,
        total_checks=total_count,
        passed_checks=passed_count,
        required_missing=required_missing,
        all_required_met=len(required_missing) == 0,
        completion_pct=completion_pct,
        recommendations=recs,
    )


# ---------------------------------------------------------------------------
# A5c.7 Typography & Reading Level Linter
# ---------------------------------------------------------------------------

def calculate_reading_scores(text: str) -> Tuple[float, float]:
    """
    Computes Flesch Reading Ease and Flesch-Kincaid Grade Level.
    Formula:
      Flesch Reading Ease = 206.835 - 1.015*(words/sentences) - 84.6*(syllables/words)
      Flesch-Kincaid Grade = 0.39*(words/sentences) + 11.8*(syllables/words) - 15.59
    """
    clean = re.sub(r"[#*`\[\]\(\)]", " ", text).strip()
    words = re.findall(r"\b[a-zA-Z0-9'-]+\b", clean)
    sentences = [s.strip() for s in re.split(r"[.!?]+", clean) if s.strip()]

    word_count = max(1, len(words))
    sentence_count = max(1, len(sentences))

    def count_syllables(word: str) -> int:
        w = word.lower()
        if len(w) <= 3:
            return 1
        w = re.sub(r"(?:[^laeiouy]|ed|es|e)$", "", w)
        w = re.sub(r"^y", "", w)
        s = len(re.findall(r"[aeiouy]{1,2}", w))
        return max(1, s)

    total_syllables = sum(count_syllables(w) for w in words)

    asl = word_count / sentence_count
    asw = total_syllables / word_count

    ease = 206.835 - (1.015 * asl) - (84.6 * asw)
    ease = max(0.0, min(100.0, round(ease, 1)))

    grade = (0.39 * asl) + (11.8 * asw) - 15.59
    grade = max(1.0, round(grade, 1))

    return ease, grade


def lint_typography_and_reading_level(
    text: str,
    headings: Optional[List[Dict[str, Any]]] = None,
    target_audience: str = "general",
    max_paragraph_words: int = 120,
    max_paragraph_sentences: int = 5,
    custom_banned_phrases: Optional[List[str]] = None,
    custom_terminology: Optional[Dict[str, List[str]]] = None,
) -> TypographyLintReport:
    """
    Executes typography and readability linter:
    1. Paragraph length cap (<= 120 words, <= 5 sentences).
    2. Heading depth <= 3 (strictly H1, H2, H3).
    3. Terminology consistency (enforces canonical forms).
    4. Banned 'AI-sounding' phrase list.
    5. Calibrated target reading level per audience persona.
    """
    warnings: List[str] = []
    bloated_paragraphs: List[BloatedParagraph] = []

    # 1. Paragraph Length Cap
    raw_paragraphs = [p.strip() for p in text.split("\n\n") if p.strip() and not p.strip().startswith(("#", "```", "|", "<", ">", "- ", "* ", "1. "))]
    for idx, p in enumerate(raw_paragraphs):
        p_words = len(re.findall(r"\b\w+\b", p))
        p_sentences = len([s for s in re.split(r"[.!?]+", p) if s.strip()])

        if p_words > max_paragraph_words or p_sentences > max_paragraph_sentences:
            preview = p[:90] + ("..." if len(p) > 90 else "")
            bloated_paragraphs.append(BloatedParagraph(
                paragraph_index=idx + 1,
                word_count=p_words,
                sentence_count=p_sentences,
                preview=preview,
            ))
            warnings.append(
                f"Paragraph {idx + 1} exceeds length cap ({p_words} words / {p_sentences} sentences vs max {max_paragraph_words}w / {max_paragraph_sentences}s)."
            )

    paragraph_compliant = (len(bloated_paragraphs) == 0)

    # 2. Heading Depth <= 3
    depth_violations: List[str] = []
    if headings:
        for h in headings:
            lvl = int(h.get("level", 2))
            title = h.get("text", "")
            if lvl > 3:
                depth_violations.append(f"H{lvl}: '{title}' (Maximum allowed heading depth is H3).")
    else:
        # Markdown regex inspection
        for m in re.finditer(r"^(#{4,6})\s+(.+)$", text, re.MULTILINE):
            hashes, title = m.groups()
            depth_violations.append(f"H{len(hashes)}: '{title}' (Maximum allowed heading depth is H3).")

    heading_depth_compliant = (len(depth_violations) == 0)
    if not heading_depth_compliant:
        warnings.append(f"Found {len(depth_violations)} heading depth violation(s) exceeding H3 limit.")

    # 3. Consistent Terminology
    terminology_map = custom_terminology or DEFAULT_CANONICAL_TERMINOLOGY
    inconsistent_terms: List[InconsistentTermFinding] = []
    text_lower = text.lower()

    for preferred, variants in terminology_map.items():
        pref_lower = preferred.lower()
        for var in variants:
            if var == preferred:
                continue
            var_lower = var.lower()
            if var_lower == pref_lower:
                # Case sensitivity check on original text (e.g. "next.js" or "postgresql")
                matches = len(re.findall(r"(?:\b|^|\s)" + re.escape(var) + r"(?:\b|$|\s|[.,;])", text))
                if matches > 0:
                    inconsistent_terms.append(InconsistentTermFinding(
                        preferred_term=preferred,
                        found_variant=var,
                        count=matches,
                    ))
                    warnings.append(f"Inconsistent terminology: found '{var}' ({matches}x); prefer canonical '{preferred}'.")
            else:
                # Spelling or hyphenation variant check
                pattern = r"(?:\b|^|\s)" + re.escape(var_lower) + r"(?:\b|$|\s|[.,;])"
                matches = len(re.findall(pattern, text_lower))
                if matches > 0:
                    inconsistent_terms.append(InconsistentTermFinding(
                        preferred_term=preferred,
                        found_variant=var,
                        count=matches,
                    ))
                    warnings.append(f"Inconsistent terminology: found '{var}' ({matches}x); prefer canonical '{preferred}'.")

    terminology_compliant = (len(inconsistent_terms) == 0)

    # 4. Banned AI-Sounding Phrases
    banned_list = custom_banned_phrases or DEFAULT_BANNED_AI_PHRASES
    banned_found: List[Dict[str, Any]] = []

    for phrase in banned_list:
        p_clean = phrase.lower().strip()
        if not p_clean:
            continue
        count = len(re.findall(r"\b" + re.escape(p_clean) + r"\b", text_lower))
        if count > 0:
            banned_found.append({"phrase": phrase, "count": count})
            warnings.append(f"Banned AI phrase detected: '{phrase}' ({count}x). Rewrite with authentic editorial voice.")

    # 5. Target Reading Level Per Audience
    ease, grade = calculate_reading_scores(text)
    audience = target_audience.lower().strip()

    audience_grade_ranges = {
        "general": (7.0, 9.5),       # 7th to 9th grade (Flesch 60-75)
        "technical": (10.0, 13.5),   # 10th grade to undergraduate (Flesch 45-60)
        "executive": (8.0, 11.0),    # 8th to 11th grade (Flesch 50-65)
        "academic": (12.0, 16.0),    # College+ (Flesch 30-50)
    }

    target_min, target_max = audience_grade_ranges.get(audience, (7.0, 10.0))
    expected_range_str = f"{target_min} - {target_max}"

    level_match = True
    audience_notes = f"Score matches {audience} audience profile."
    if grade < target_min:
        level_match = False
        audience_notes = f"Reading grade level ({grade}) is lower than the target range ({expected_range_str}) for {audience} audience."
        warnings.append(audience_notes)
    elif grade > target_max:
        level_match = False
        audience_notes = f"Reading grade level ({grade}) is higher than the target range ({expected_range_str}) for {audience} audience; simplify complex sentences."
        warnings.append(audience_notes)

    overall_passed = (
        paragraph_compliant
        and heading_depth_compliant
        and len(banned_found) == 0
    )

    return TypographyLintReport(
        paragraph_cap_compliant=paragraph_compliant,
        max_paragraph_words_limit=max_paragraph_words,
        max_paragraph_sentences_limit=max_paragraph_sentences,
        bloated_paragraphs=bloated_paragraphs,
        heading_depth_compliant=heading_depth_compliant,
        max_heading_depth=3,
        heading_depth_violations=depth_violations,
        terminology_compliant=terminology_compliant,
        inconsistent_terms=inconsistent_terms,
        banned_ai_phrases_found=banned_found,
        flesch_reading_ease=ease,
        flesch_kincaid_grade=grade,
        target_audience=audience,
        audience_level_match=level_match,
        audience_expected_grade_range=expected_range_str,
        audience_notes=audience_notes,
        overall_passed=overall_passed,
        warnings=warnings,
    )


def audit_document_layout_blueprint(
    doc: ArticleDocumentModel,
    content_markdown: Optional[str] = None,
    target_audience: str = "general",
) -> ProfessionalLayoutAudit:
    """
    Combined audit for professional layout checklist + typography linting.
    """
    md = content_markdown or ""
    checklist_rep = audit_professional_layout_checklist(doc, content_markdown=md)

    headings_dict = [
        {"level": getattr(b, "level", 2), "text": getattr(b, "text", "")}
        for b in doc.blocks if b.block_type == "heading"
    ]

    typo_rep = lint_typography_and_reading_level(
        text=md or " ".join(getattr(b, "text", "") for b in doc.blocks if hasattr(b, "text")),
        headings=headings_dict,
        target_audience=target_audience,
    )

    is_compliant = checklist_rep.all_required_met and typo_rep.overall_passed

    summary = (
        f"Layout Checklist: {checklist_rep.passed_checks}/{checklist_rep.total_checks} passed ({checklist_rep.completion_pct}%). "
        f"Typography: {'PASS' if typo_rep.overall_passed else 'NEEDS ATTENTION'} (Grade {typo_rep.flesch_kincaid_grade}, Ease {typo_rep.flesch_reading_ease})."
    )

    return ProfessionalLayoutAudit(
        checklist=checklist_rep,
        typography=typo_rep,
        is_compliant=is_compliant,
        summary=summary,
    )
