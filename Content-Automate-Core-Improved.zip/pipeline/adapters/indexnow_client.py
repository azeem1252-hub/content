"""
IndexNow API Client (Pillar II: Instant Crawl & Discovery).

Directly notifies participating search engines (Bing, Yandex, Naver, Seznam)
of newly published or updated content, reducing indexing discovery latency from weeks to minutes.
"""

import os
import logging
from typing import List, Dict, Any, Optional
from urllib.parse import urlparse
import httpx

import config

logger = logging.getLogger("pipeline.adapters.indexnow")

INDEXNOW_ENDPOINT = "https://api.indexnow.org/indexnow"


def submit_indexnow_urls(
    urls: List[str],
    api_key: Optional[str] = None,
    key_location: Optional[str] = None
) -> Dict[str, Any]:
    """
    Submits an array of URLs to the IndexNow protocol endpoint.
    If no INDEXNOW_KEY is configured in .env or settings, skips gracefully.
    """
    key = api_key or os.getenv("INDEXNOW_KEY", "").strip() or getattr(config, "INDEXNOW_KEY", "")
    if not key or not urls:
        logger.info("IndexNow submission skipped: no key or URLs provided.")
        return {"status": "skipped", "message": "IndexNow key not configured"}

    # Derive host from the first URL
    first_url = urls[0]
    parsed = urlparse(first_url)
    host = parsed.netloc or "localhost"

    payload = {
        "host": host,
        "key": key,
        "urlList": urls
    }
    if key_location:
        payload["keyLocation"] = key_location

    try:
        with httpx.Client(timeout=10.0) as client:
            response = client.post(
                INDEXNOW_ENDPOINT,
                json=payload,
                headers={"Content-Type": "application/json; charset=utf-8"}
            )
            # IndexNow returns 200 (OK), 202 (Accepted), or error
            if response.status_code in (200, 202):
                logger.info(f"IndexNow submitted {len(urls)} URLs successfully for host '{host}'.")
                return {"status": "success", "status_code": response.status_code, "urls": urls}
            else:
                logger.warning(f"IndexNow returned status {response.status_code}: {response.text}")
                return {"status": "warning", "status_code": response.status_code, "error": response.text}
    except Exception as e:
        logger.error(f"IndexNow submission request failed: {e}")
        return {"status": "error", "error": str(e)}
