"""
Live SERP Client & Rank Tracker (Pillar II: SERP-Grounded Intelligence).

Feeds the proprietary NLP engine real Page-1 competitor footprints instead of
whatever prose happens to be in the retrieval cache, and records rank snapshots
so position history can be charted over time.

Provider order (configurable, all optional):
  1. DataForSEO  (DATAFORSEO_LOGIN / DATAFORSEO_PASSWORD)
  2. Serper.dev  (SERPER_API_KEY)
  3. Tavily      (TAVILY_API_KEY) — snippets only, no true rank ordering

When no provider is configured every function returns an explicit
``provider: "unconfigured"`` result rather than fabricating rankings.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import httpx

import config
from pipeline.utils import fetch_tavily_intelligence

logger = logging.getLogger("pipeline.adapters.serp")

DATAFORSEO_ENDPOINT = "https://api.dataforseo.com/v3/serp/google/organic/live/advanced"
SERPER_ENDPOINT = "https://google.serper.dev/search"

_KNOWN_SERP_FEATURES = (
    "people_also_ask", "featured_snippet", "ai_overview", "video", "images",
    "local_pack", "knowledge_graph", "shopping", "top_stories", "site_links",
)


def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


def resolve_provider() -> str:
    """Returns the active SERP provider name."""
    if _cfg("DATAFORSEO_LOGIN") and _cfg("DATAFORSEO_PASSWORD"):
        return "dataforseo"
    if _cfg("SERPER_API_KEY"):
        return "serper"
    if _cfg("TAVILY_API_KEY"):
        return "tavily"
    return "unconfigured"


def provider_status() -> Dict[str, Any]:
    """Status descriptor for Settings/Health UI."""
    provider = resolve_provider()
    return {
        "provider": provider,
        "configured": provider != "unconfigured",
        "rank_tracking": provider in ("dataforseo", "serper"),
        "note": (
            "No SERP provider configured — add SERPER_API_KEY or DATAFORSEO credentials "
            "for live Page-1 competitor data and rank tracking."
        ) if provider == "unconfigured" else "",
    }


def _domain_of(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc[4:] if netloc.startswith("www.") else netloc
    except Exception:  # noqa: BLE001
        return ""


def _serp_depth() -> int:
    try:
        return max(1, min(100, int(getattr(config, "SERP_DEPTH", 10) or 10)))
    except (TypeError, ValueError):
        return 10


def _fetch_dataforseo(query: str, depth: int) -> Optional[Dict[str, Any]]:
    login = _cfg("DATAFORSEO_LOGIN")
    password = _cfg("DATAFORSEO_PASSWORD")
    if not (login and password):
        return None
    payload = [{"keyword": query, "language_code": "en", "location_code": 2840, "depth": depth}]
    try:
        with httpx.Client(timeout=45.0) as client:
            resp = client.post(DATAFORSEO_ENDPOINT, auth=(login, password), json=payload)
            if resp.status_code != 200:
                logger.warning(f"DataForSEO SERP HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            data = resp.json()
            task = (data.get("tasks") or [{}])[0]
            results = (task.get("result") or [{}])[0]
            items = results.get("items") or []
            out: List[Dict[str, Any]] = []
            features: List[str] = []
            for item in items:
                item_type = item.get("type") or "organic"
                if item_type != "organic":
                    if item_type in _KNOWN_SERP_FEATURES or "ai_overview" in item_type:
                        if item_type not in features:
                            features.append(item_type)
                    continue
                out.append({
                    "position": item.get("rank_absolute") or item.get("rank_group"),
                    "title": item.get("title"),
                    "url": item.get("url"),
                    "domain": item.get("domain") or _domain_of(item.get("url") or ""),
                    "snippet": item.get("description") or "",
                    "features": item.get("ranked_serp_element", {}).get("serp_item", {}).get("type"),
                })
            return {"results": out, "features": features, "answer": None}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"DataForSEO SERP request failed: {e}")
        return None


def _fetch_serper(query: str, depth: int) -> Optional[Dict[str, Any]]:
    key = _cfg("SERPER_API_KEY")
    if not key:
        return None
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                SERPER_ENDPOINT,
                headers={"X-API-KEY": key, "Content-Type": "application/json"},
                json={"q": query, "num": min(100, depth)},
            )
            if resp.status_code != 200:
                logger.warning(f"Serper SERP HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            data = resp.json()
            out: List[Dict[str, Any]] = []
            features: List[str] = []
            for i, item in enumerate(data.get("organic", []) or [], start=1):
                out.append({
                    "position": item.get("position") or i,
                    "title": item.get("title"),
                    "url": item.get("link"),
                    "domain": _domain_of(item.get("link") or ""),
                    "snippet": item.get("snippet") or "",
                    "features": None,
                })
            if data.get("peopleAlsoAsk"):
                features.append("people_also_ask")
            if data.get("knowledgeGraph"):
                features.append("knowledge_graph")
            if data.get("answerBox"):
                features.append("featured_snippet")
            return {"results": out, "features": features, "answer": (data.get("answerBox") or {}).get("answer")}
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Serper SERP request failed: {e}")
        return None


def _fetch_tavily(query: str, depth: int) -> Optional[Dict[str, Any]]:
    """Tavily fallback: returns competitor snippets but no reliable ranking."""
    res = fetch_tavily_intelligence(query, max_results=max(3, min(depth, 10)), search_depth="basic")
    results = res.get("results") or []
    if not results:
        return None
    out = []
    for i, r in enumerate(results, start=1):
        out.append({
            "position": None,  # Tavily does not expose a SERP position
            "title": r.get("title"),
            "url": r.get("url"),
            "domain": _domain_of(r.get("url") or ""),
            "snippet": (r.get("content") or "")[:400],
            "features": None,
        })
    return {"results": out, "features": [], "answer": res.get("answer")}


def fetch_serp(query: str, depth: Optional[int] = None) -> Dict[str, Any]:
    """Fetches live Page-1 results for a query from the configured provider."""
    depth = depth or _serp_depth()
    provider = resolve_provider()
    if provider == "unconfigured" or not (query or "").strip():
        return {
            "provider": provider,
            "configured": provider != "unconfigured",
            "query": query,
            "results": [],
            "features": [],
            "measured": False,
        }

    data = None
    if provider == "dataforseo":
        data = _fetch_dataforseo(query, depth)
    elif provider == "serper":
        data = _fetch_serper(query, depth)
    if data is None:
        data = _fetch_tavily(query, depth)
        if data is not None and provider in ("dataforseo", "serper"):
            provider = "tavily"
    if data is None:
        return {
            "provider": provider,
            "configured": True,
            "query": query,
            "results": [],
            "features": [],
            "measured": False,
            "error": "SERP provider request failed",
        }

    results = sorted(
        data["results"],
        key=lambda r: (r.get("position") is None, r.get("position") or 999),
    )
    return {
        "provider": provider,
        "configured": True,
        "query": query,
        "results": results[:depth],
        "features": data.get("features") or [],
        "answer": data.get("answer"),
        "measured": True,
    }


def find_domain_rank(results: List[Dict[str, Any]], domain: str) -> Optional[int]:
    """Returns the 1-based position of the first result from `domain`, or None."""
    if not domain:
        return None
    clean = domain.lower().replace("www.", "")
    for idx, r in enumerate(results, start=1):
        r_domain = (r.get("domain") or _domain_of(r.get("url") or "")).lower().replace("www.", "")
        if r_domain == clean or r_domain.endswith(f".{clean}"):
            return r.get("position") or idx
    return None


def competitor_footprint(query: str, exclude_domain: Optional[str] = None) -> Dict[str, Any]:
    """Returns competitor snippets and domains for the proprietary NLP engine."""
    serp = fetch_serp(query)
    results = serp.get("results") or []
    if exclude_domain:
        clean = exclude_domain.lower().replace("www.", "")
        results = [
            r for r in results
            if (r.get("domain") or "").lower().replace("www.", "") != clean
        ]
    snippets = [r.get("snippet") or "" for r in results if r.get("snippet")]
    return {
        "query": query,
        "provider": serp.get("provider"),
        "measured": serp.get("measured", False),
        "features": serp.get("features") or [],
        "snippets": [s for s in snippets if isinstance(s, str) and s],
        "competitor_domains": sorted({r.get("domain") for r in results if r.get("domain")}),
        "results": results,
    }


def serp_context_block(query: str, exclude_domain: Optional[str] = None, limit: int = 8) -> str:
    """Formats live competitor titles/snippets into a prompt context block."""
    footprint = competitor_footprint(query, exclude_domain=exclude_domain)
    results = footprint.get("results") or []
    if not results:
        return ""
    lines = []
    for r in results[:limit]:
        pos = f"#{r.get('position')} " if r.get("position") else ""
        lines.append(f"- {pos}{r.get('title')} ({r.get('domain')}): {(r.get('snippet') or '')[:220]}")
    if not lines:
        return ""
    header = "LIVE SERP COMPETITOR FOOTPRINT (current Page-1 results):"
    if footprint.get("features"):
        header += f"\nSERP features present: {', '.join(footprint['features'])}"
    return header + "\n" + "\n".join(lines)


def build_rank_snapshot(
    website_id: Optional[str],
    keyword: str,
    domain: str,
    depth: Optional[int] = None,
) -> Dict[str, Any]:
    """Fetches the current SERP and returns a rank snapshot record (unpersisted)."""
    serp = fetch_serp(keyword, depth=depth)
    position = find_domain_rank(serp.get("results") or [], domain) if serp.get("measured") else None
    return {
        "website_id": website_id,
        "keyword": keyword,
        "position": position,
        "url": next(
            (r.get("url") for r in (serp.get("results") or []) if (r.get("domain") or "").lower().replace("www.", "") == domain.lower().replace("www.", "")),
            None,
        ),
        "engine": "google",
        "serp_features": serp.get("features") or [],
        "measured": serp.get("measured", False),
        "provider": serp.get("provider"),
    }


def extract_rank_keywords(title: str, keywords: Optional[List[str]] = None, limit: int = 5) -> List[str]:
    """Derives the tracked keywords for an article (targets first, then title)."""
    out: List[str] = []
    for kw in keywords or []:
        if kw and str(kw).strip() and str(kw).strip().lower() not in [o.lower() for o in out]:
            out.append(str(kw).strip())
        if len(out) >= limit:
            return out
    clean_title = re.sub(r"\s+", " ", re.sub(r"[|:–—].*$", "", title or "")).strip()
    if clean_title and clean_title.lower() not in [o.lower() for o in out]:
        out.append(clean_title)
    return out[:limit]
