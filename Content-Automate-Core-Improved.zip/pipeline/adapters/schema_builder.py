"""
Programmatic JSON-LD Schema & Knowledge Graph Generator (Pillar II: GEO & E-E-A-T).

Generates validated, connected Schema.org structured data to maximize visibility in:
1. Google AI Overviews & Generative Engine Optimization (GEO).
2. Traditional Google Rich Snippets (Article, FAQPage, HowTo, BreadcrumbList, VideoObject).
3. Entity Knowledge Graph resolution (Organization with sameAs, Person with E-E-A-T, about/mentions).
4. Automated Fact Verification transparency (ClaimReview for fact-checked assertions).
"""

from __future__ import annotations

import html
import json
import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger("pipeline.adapters.schema_builder")

# Curated high-authority entity knowledge base for automatic entity resolution
CURATED_ENTITY_MAP: Dict[str, Dict[str, str]] = {
    "python": {
        "name": "Python",
        "sameAs": "https://en.wikipedia.org/wiki/Python_(programming_language)",
        "@type": "ComputerLanguage",
    },
    "typescript": {
        "name": "TypeScript",
        "sameAs": "https://en.wikipedia.org/wiki/TypeScript",
        "@type": "ComputerLanguage",
    },
    "javascript": {
        "name": "JavaScript",
        "sameAs": "https://en.wikipedia.org/wiki/JavaScript",
        "@type": "ComputerLanguage",
    },
    "react": {
        "name": "React",
        "sameAs": "https://en.wikipedia.org/wiki/React_(software)",
        "@type": "SoftwareApplication",
    },
    "next.js": {
        "name": "Next.js",
        "sameAs": "https://en.wikipedia.org/wiki/Next.js",
        "@type": "SoftwareApplication",
    },
    "nextjs": {
        "name": "Next.js",
        "sameAs": "https://en.wikipedia.org/wiki/Next.js",
        "@type": "SoftwareApplication",
    },
    "fastapi": {
        "name": "FastAPI",
        "sameAs": "https://en.wikipedia.org/wiki/FastAPI",
        "@type": "SoftwareApplication",
    },
    "langchain": {
        "name": "LangChain",
        "sameAs": "https://en.wikipedia.org/wiki/LangChain",
        "@type": "SoftwareApplication",
    },
    "langgraph": {
        "name": "LangGraph",
        "sameAs": "https://github.com/langchain-ai/langgraph",
        "@type": "SoftwareApplication",
    },
    "cloudflare": {
        "name": "Cloudflare",
        "sameAs": "https://en.wikipedia.org/wiki/Cloudflare",
        "@type": "Organization",
    },
    "redis": {
        "name": "Redis",
        "sameAs": "https://en.wikipedia.org/wiki/Redis",
        "@type": "SoftwareApplication",
    },
    "upstash": {
        "name": "Upstash",
        "sameAs": "https://upstash.com",
        "@type": "Organization",
    },
    "docker": {
        "name": "Docker",
        "sameAs": "https://en.wikipedia.org/wiki/Docker_(software)",
        "@type": "SoftwareApplication",
    },
    "postgresql": {
        "name": "PostgreSQL",
        "sameAs": "https://en.wikipedia.org/wiki/PostgreSQL",
        "@type": "SoftwareApplication",
    },
    "sqlite": {
        "name": "SQLite",
        "sameAs": "https://en.wikipedia.org/wiki/SQLite",
        "@type": "SoftwareApplication",
    },
    "remotion": {
        "name": "Remotion",
        "sameAs": "https://www.remotion.dev",
        "@type": "SoftwareApplication",
    },
    "openai": {
        "name": "OpenAI",
        "sameAs": "https://en.wikipedia.org/wiki/OpenAI",
        "@type": "Organization",
    },
    "google": {
        "name": "Google",
        "sameAs": "https://en.wikipedia.org/wiki/Google",
        "@type": "Organization",
    },
    "anthropic": {
        "name": "Anthropic",
        "sameAs": "https://en.wikipedia.org/wiki/Anthropic",
        "@type": "Organization",
    },
    "tavily": {
        "name": "Tavily",
        "sameAs": "https://tavily.com",
        "@type": "Organization",
    },
    "tailwindcss": {
        "name": "Tailwind CSS",
        "sameAs": "https://en.wikipedia.org/wiki/Tailwind_CSS",
        "@type": "SoftwareApplication",
    },
    "generative engine optimization": {
        "name": "Generative Engine Optimization (GEO)",
        "sameAs": "https://en.wikipedia.org/wiki/Generative_engine_optimization",
        "@type": "Intangible",
    },
    "geo": {
        "name": "Generative Engine Optimization (GEO)",
        "sameAs": "https://en.wikipedia.org/wiki/Generative_engine_optimization",
        "@type": "Intangible",
    },
}


# =====================================================================
# TEXT & MARKDOWN CLEANING UTILITIES
# =====================================================================

def clean_markdown_text(text: str) -> str:
    """
    Strips raw markdown syntax (headers, bold, italic, code blocks, links, images)
    producing clean, human-readable plain text required by Schema.org and Google Rich Snippets.
    """
    if not text:
        return ""
    # Strip HTML tags
    cleaned = re.sub(r"<[^>]+>", " ", text)
    # Strip image embeds ![alt](url)
    cleaned = re.sub(r"!\[([^\]]*)\]\([^)]+\)", r"\1", cleaned)
    # Strip link URLs [text](url) -> text
    cleaned = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", cleaned)
    # Strip code blocks
    cleaned = re.sub(r"```[a-zA-Z]*\n[\s\S]*?\n```", " ", cleaned)
    cleaned = re.sub(r"`([^`]+)`", r"\1", cleaned)
    # Strip heading markers #
    cleaned = re.sub(r"^#{1,6}\s+", "", cleaned, flags=re.MULTILINE)
    # Strip bold and italics **text** or *text* or __text__ or _text_
    cleaned = re.sub(r"[*_]{1,3}([^*_]+)[*_]{1,3}", r"\1", cleaned)
    # Strip blockquotes >
    cleaned = re.sub(r"^>\s+", "", cleaned, flags=re.MULTILINE)
    # Strip bullet points and list numbers
    cleaned = re.sub(r"^[-*+]\s+", "", cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r"^\d+\.\s+", "", cleaned, flags=re.MULTILINE)
    # Unescape HTML entities
    cleaned = html.unescape(cleaned)
    # Normalize excessive whitespace
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def _slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return slug or "entity"


# =====================================================================
# EXTRACTION UTILITIES
# =====================================================================

def extract_faq_pairs_from_markdown(markdown_text: str, limit: int = 10) -> List[Dict[str, str]]:
    """
    Scans markdown text for conversational question-and-answer pairs.
    Recognizes:
    - Markdown headers: H2/H3/H4 questions (e.g. '### What is...', '## How does...', '### Can I...')
    - Headers ending in question marks: '### Is this supported?'
    - Explicit inline Q&A patterns: '**Q: ...?** A: ...' or '**Question:** ... **Answer:** ...'
    """
    if not markdown_text:
        return []

    faqs: List[Dict[str, str]] = []
    seen_questions: set = set()

    # 1. Check for bold inline Q&A patterns
    inline_pattern = re.compile(
        r"(?:\*\*Q(?:\.|uestion)?:?\s*([^*?]+\?)\*\*)\s*(?:\n+|A(?:\.|nswer)?:?\s*)([^\n]+(?:\n[^\n#]+)*)",
        re.IGNORECASE,
    )
    for match in inline_pattern.finditer(markdown_text):
        q_raw, a_raw = match.group(1).strip(), match.group(2).strip()
        q_clean = clean_markdown_text(q_raw)
        a_clean = clean_markdown_text(a_raw)
        if len(q_clean) >= 10 and len(a_clean) >= 20 and q_clean.lower() not in seen_questions:
            seen_questions.add(q_clean.lower())
            faqs.append({"question": q_clean, "answer": a_clean[:1200]})
            if len(faqs) >= limit:
                return faqs

    # 2. Header-based FAQ extraction
    lines = markdown_text.split("\n")
    current_q: Optional[str] = None
    current_a_lines: List[str] = []

    question_words_pattern = re.compile(
        r"^#{2,4}\s+(?:(?:Q\d*[:.]?|\d+[\.:])\s+)?(What|How|Why|When|Where|Can|Is|Are|Which|Will|Does|Do|Should|Could)\b",
        re.IGNORECASE,
    )

    for line in lines:
        stripped = line.strip()
        is_question_header = (
            question_words_pattern.match(stripped)
            or (stripped.startswith("#") and stripped.endswith("?") and len(stripped.split()) >= 3)
        )

        if is_question_header:
            if current_q and current_a_lines:
                ans_text = clean_markdown_text(" ".join(current_a_lines))
                if len(ans_text) >= 25 and current_q.lower() not in seen_questions:
                    seen_questions.add(current_q.lower())
                    faqs.append({"question": current_q, "answer": ans_text[:1200]})
            current_q = clean_markdown_text(re.sub(r"^#{2,4}\s+", "", stripped))
            current_a_lines = []
        elif current_q is not None:
            if stripped.startswith("#"):
                # Hit next section
                ans_text = clean_markdown_text(" ".join(current_a_lines))
                if len(ans_text) >= 25 and current_q.lower() not in seen_questions:
                    seen_questions.add(current_q.lower())
                    faqs.append({"question": current_q, "answer": ans_text[:1200]})
                current_q = None
                current_a_lines = []
            elif stripped:
                current_a_lines.append(stripped)

    if current_q and current_a_lines:
        ans_text = clean_markdown_text(" ".join(current_a_lines))
        if len(ans_text) >= 25 and current_q.lower() not in seen_questions:
            seen_questions.add(current_q.lower())
            faqs.append({"question": current_q, "answer": ans_text[:1200]})

    return faqs[:limit]


def extract_howto_steps_from_markdown(markdown_text: str, limit: int = 12) -> List[Dict[str, Any]]:
    """
    Extracts ordered implementation steps from markdown text.
    Recognizes headers like:
    - '### Step 1: Initialize the Project'
    - '## 1. Configure the API Keys'
    - '### Step 2 - Deploy to Workers'
    Also detects step illustration images if present.
    """
    if not markdown_text:
        return []

    steps: List[Dict[str, Any]] = []
    lines = markdown_text.split("\n")
    current_name: Optional[str] = None
    current_text: List[str] = []
    current_image: Optional[str] = None

    step_pattern = re.compile(
        r"^#{2,4}\s+(?:Step\s+\d+[:.\s-]*|\d+[\.:]\s+)(.+)$",
        re.IGNORECASE,
    )

    for line in lines:
        stripped = line.strip()
        step_match = step_pattern.match(stripped)

        if step_match:
            if current_name and current_text:
                step_body = clean_markdown_text(" ".join(current_text))
                if len(step_body) >= 15:
                    steps.append({
                        "name": current_name,
                        "text": step_body[:1000],
                        "image": current_image,
                    })
            current_name = clean_markdown_text(step_match.group(1))
            current_text = []
            current_image = None
        elif current_name is not None:
            if stripped.startswith("#"):
                # Hit next non-step header
                step_body = clean_markdown_text(" ".join(current_text))
                if len(step_body) >= 15:
                    steps.append({
                        "name": current_name,
                        "text": step_body[:1000],
                        "image": current_image,
                    })
                current_name = None
                current_text = []
                current_image = None
            elif stripped:
                # Detect image inside step
                img_match = re.search(r"!\[.*?\]\((https?://[^\s)]+|/uploads/[^\s)]+)\)", stripped)
                if img_match and not current_image:
                    current_image = img_match.group(1)
                current_text.append(stripped)

    if current_name and current_text:
        step_body = clean_markdown_text(" ".join(current_text))
        if len(step_body) >= 15:
            steps.append({
                "name": current_name,
                "text": step_body[:1000],
                "image": current_image,
            })

    # Support numbered step lists (1. Step text\n2. Step text) if no header steps found
    if not steps:
        list_matches = re.findall(r"^\s*(\d+)\.\s+([^\n]+)", markdown_text, re.MULTILINE)
        if len(list_matches) >= 3:
            for num, text in list_matches[:limit]:
                text_clean = clean_markdown_text(text)
                if len(text_clean) >= 15:
                    steps.append({
                        "name": f"Step {num}: {text_clean[:50]}",
                        "text": text_clean,
                        "image": None,
                    })

    return steps[:limit]


def extract_citations_from_markdown(markdown_text: str) -> List[str]:
    """
    Extracts authoritative external URLs cited in the markdown body.
    These are linked in the Article schema's 'citation' property for E-E-A-T grounding.
    """
    if not markdown_text:
        return []
    # Match markdown link URLs: [Anchor](https://...)
    urls = re.findall(r"\[[^\]]+\]\((https?://[^\s)]+)\)", markdown_text)
    # Deduplicate while preserving order, skipping internal/localhost links
    citations: List[str] = []
    seen = set()
    for u in urls:
        clean_u = u.strip()
        domain_match = re.search(r"https?://([^/]+)", clean_u)
        domain = domain_match.group(1).lower() if domain_match else ""
        if "localhost" in domain or "127.0.0.1" in domain or domain.endswith(".local"):
            continue
        if clean_u not in seen:
            seen.add(clean_u)
            citations.append(clean_u)
    return citations[:15]


def extract_entity_mentions(
    content: str,
    title: str = "",
    tags: Optional[List[str]] = None,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Extracts primary ('about') and secondary ('mentions') entities for Knowledge Graph resolution.
    Maps recognized technologies and concepts to authoritative Schema.org Thing / sameAs URLs.
    """
    combined_text = f"{title} {' '.join(tags or [])} {content[:4000]}".lower()
    about_entities: List[Dict[str, Any]] = []
    mentions_entities: List[Dict[str, Any]] = []
    matched_keys: set = set()

    for key, info in CURATED_ENTITY_MAP.items():
        # Match whole words only
        if re.search(r"\b" + re.escape(key) + r"\b", combined_text):
            if info["name"] in matched_keys:
                continue
            matched_keys.add(info["name"])
            entity_node = {
                "@type": info.get("@type", "Thing"),
                "name": info["name"],
                "sameAs": info["sameAs"],
            }
            # If the entity is in the title, it is a primary subject ('about')
            if key in title.lower():
                about_entities.append(entity_node)
            else:
                mentions_entities.append(entity_node)

    # If title didn't match curated entities, create a clean Thing from tags or title
    if not about_entities and tags:
        for t in tags[:2]:
            clean_tag = clean_markdown_text(str(t))
            if clean_tag:
                about_entities.append({"@type": "Thing", "name": clean_tag})

    return about_entities[:3], mentions_entities[:8]


# =====================================================================
# COMPONENT SCHEMA GENERATORS
# =====================================================================

def generate_person_schema(
    author_name: str,
    author_role: Optional[str] = None,
    organization_name: Optional[str] = None,
    same_as: Optional[List[str]] = None,
    author_url: Optional[str] = None,
    author_bio: Optional[str] = None,
    knows_about: Optional[List[str]] = None,
    alumni_of: Optional[str] = None,
    image_url: Optional[str] = None,
    credentials: Optional[List[str]] = None,
    base_url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates a comprehensive Schema.org Person author schema demonstrating E-E-A-T credentials.
    """
    author_clean = author_name.strip() if author_name else "The Editorial Bureau"
    author_slug = _slugify(author_clean)
    site_prefix = base_url.rstrip("/") if base_url else "https://example.com"
    author_uri = f"{site_prefix}#author-{author_slug}"

    schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "Person",
        "@id": author_uri,
        "name": author_clean,
        "url": author_url or f"{site_prefix}/authors/{author_slug}",
    }

    if author_role:
        schema["jobTitle"] = author_role
    if author_bio:
        schema["description"] = clean_markdown_text(author_bio)
    if image_url:
        schema["image"] = image_url

    if organization_name:
        org_uri = f"{site_prefix}#organization"
        schema["worksFor"] = {
            "@type": "Organization",
            "@id": org_uri,
            "name": organization_name,
        }

    # E-E-A-T topical authority
    if knows_about:
        schema["knowsAbout"] = [str(k).strip() for k in knows_about if str(k).strip()]
    if alumni_of:
        schema["alumniOf"] = {
            "@type": "EducationalOrganization",
            "name": alumni_of,
        }
    if credentials:
        schema["hasCredential"] = [
            {"@type": "EducationalOccupationalCredential", "credentialCategory": c}
            for c in credentials
        ]

    # Authoritative social / profile links
    if same_as:
        clean_same_as = [str(s).strip() for s in same_as if str(s).strip()]
        if clean_same_as:
            schema["sameAs"] = clean_same_as

    return schema


def generate_organization_schema(
    name: str = "Dispatch Media Group",
    url: str = "https://example.com",
    logo_url: Optional[str] = None,
    same_as_links: Optional[List[str]] = None,
    description: Optional[str] = None,
    publishing_principles: Optional[str] = None,
    founding_date: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates a verified Schema.org Organization schema with brand Knowledge Graph resolution.
    """
    site_url = url.rstrip("/") if url else "https://example.com"
    org_uri = f"{site_url}#organization"

    schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "@id": org_uri,
        "name": name,
        "legalName": name,
        "url": site_url,
    }

    if logo_url:
        schema["logo"] = {
            "@type": "ImageObject",
            "@id": f"{site_url}#logo",
            "url": logo_url,
            "caption": f"{name} Official Logo",
        }

    if description:
        schema["description"] = clean_markdown_text(description)
    if founding_date:
        schema["foundingDate"] = founding_date

    # E-E-A-T editorial standard verification URL
    if publishing_principles:
        schema["publishingPrinciples"] = publishing_principles

    if same_as_links:
        clean_same_as = [str(s).strip() for s in same_as_links if str(s).strip()]
        if clean_same_as:
            schema["sameAs"] = clean_same_as

    return schema


def generate_breadcrumb_schema(
    items: List[Dict[str, str]],
    base_url: str = "https://example.com",
) -> Dict[str, Any]:
    """
    Generates a Google-compliant BreadcrumbList schema.
    items: [{"name": "Home", "url": "/"}, {"name": "Guides", "url": "/guides"}, {"name": "Post Title", "url": "/posts/slug"}]
    """
    site_prefix = base_url.rstrip("/") if base_url else "https://example.com"
    breadcrumb_elements = []

    for idx, item in enumerate(items):
        item_url = item.get("url", "")
        if item_url.startswith("/"):
            full_url = f"{site_prefix}{item_url}"
        elif not item_url.startswith("http"):
            full_url = f"{site_prefix}/{item_url}"
        else:
            full_url = item_url

        breadcrumb_elements.append({
            "@type": "ListItem",
            "position": idx + 1,
            "name": clean_markdown_text(item.get("name", f"Level {idx + 1}")),
            "item": full_url,
        })

    return {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": breadcrumb_elements,
    }


def generate_product_schema(
    name: str,
    description: str,
    brand: Optional[str] = None,
    image_url: Optional[str] = None,
    sku: Optional[str] = None,
    offers: Optional[Dict[str, Any]] = None,
    rating_value: Optional[float] = None,
    review_count: Optional[int] = None,
    author_name: Optional[str] = None,
    url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates a Schema.org Product schema for software tools, hardware, and product reviews.
    Supports offers, aggregateRating, and review fields.
    """
    clean_title = clean_markdown_text(name)
    clean_desc = clean_markdown_text(description) or clean_title

    schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": clean_title,
        "description": clean_desc,
    }

    if url:
        schema["url"] = url
    if image_url:
        schema["image"] = [image_url]
    if sku:
        schema["sku"] = sku

    if brand:
        schema["brand"] = {
            "@type": "Brand",
            "name": brand,
        }

    if rating_value is not None:
        schema["aggregateRating"] = {
            "@type": "AggregateRating",
            "ratingValue": round(rating_value, 1),
            "reviewCount": review_count or 1,
            "bestRating": 5,
            "worstRating": 1,
        }

    if offers:
        schema["offers"] = {
            "@type": "Offer",
            "priceCurrency": offers.get("currency", "USD"),
            "price": str(offers.get("price", "0.00")),
            "availability": offers.get("availability", "https://schema.org/InStock"),
            "url": offers.get("url", url or ""),
        }

    if author_name and rating_value:
        schema["review"] = {
            "@type": "Review",
            "author": {
                "@type": "Person",
                "name": author_name,
            },
            "reviewRating": {
                "@type": "Rating",
                "ratingValue": round(rating_value, 1),
                "bestRating": 5,
                "worstRating": 1,
            },
        }

    return schema


def generate_howto_schema(
    name: str,
    description: str,
    steps: List[Dict[str, Any]],
    url: Optional[str] = None,
    image_url: Optional[str] = None,
    total_time: Optional[str] = "PT15M",
    tools: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Generates a standalone Schema.org HowTo schema for technical walk-throughs and guides.
    """
    clean_title = clean_markdown_text(name)
    clean_desc = clean_markdown_text(description) or clean_title

    step_elements = []
    for idx, s in enumerate(steps):
        step_name = clean_markdown_text(s.get("name") or f"Step {idx + 1}")
        step_body = clean_markdown_text(s.get("text") or "")
        step_node: Dict[str, Any] = {
            "@type": "HowToStep",
            "position": idx + 1,
            "name": step_name,
            "text": step_body,
            "url": f"{url}#step-{idx + 1}" if url else f"#step-{idx + 1}",
        }
        if s.get("image"):
            step_node["image"] = s["image"]
        step_elements.append(step_node)

    schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "HowTo",
        "name": clean_title,
        "description": clean_desc,
        "step": step_elements,
    }

    if total_time:
        schema["totalTime"] = total_time
    if image_url:
        schema["image"] = image_url
    if tools:
        schema["tool"] = [{"@type": "HowToTool", "name": t} for t in tools]

    return schema


def generate_video_schema(
    title: str,
    description: str,
    video_url: str,
    thumbnail_url: str,
    upload_date: Optional[str] = None,
    duration_seconds: Optional[int] = 45,
    embed_url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generates a Schema.org VideoObject schema (e.g. for Remotion 9:16 vertical video assets).
    """
    clean_title = clean_markdown_text(title)
    clean_desc = clean_markdown_text(description) or clean_title
    now_iso = datetime.now(timezone.utc).isoformat()
    duration_iso = f"PT{duration_seconds}S" if duration_seconds else "PT45S"

    schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": "VideoObject",
        "name": clean_title,
        "description": clean_desc,
        "thumbnailUrl": [thumbnail_url],
        "uploadDate": upload_date or now_iso,
        "contentUrl": video_url,
        "duration": duration_iso,
    }
    if embed_url:
        schema["embedUrl"] = embed_url
    return schema


def generate_claim_review_schema(
    verified_claims: List[Dict[str, Any]],
    article_url: str,
    author_name: str = "The Dispatch Verification Bureau",
    publisher_name: str = "Dispatch Media Group",
) -> List[Dict[str, Any]]:
    """
    Generates Schema.org ClaimReview schemas for fact-checked assertions (Pillar I).
    Exposes factual transparency directly to search engines and AI fact-check crawlers.
    """
    reviews: List[Dict[str, Any]] = []
    verdict_map = {
        "supported": ("True", 5),
        "contradicted": ("False", 1),
        "unsubstantiated": ("Unsubstantiated", 2),
    }

    for c in verified_claims[:5]:
        statement = c.get("statement")
        if not statement:
            continue
        verdict = str(c.get("verdict", "supported")).lower()
        rating_text, rating_num = verdict_map.get(verdict, ("Unverified", 3))

        reviews.append({
            "@context": "https://schema.org",
            "@type": "ClaimReview",
            "claimReviewed": statement,
            "url": article_url,
            "author": {
                "@type": "Organization",
                "name": f"{publisher_name} Verification Bureau",
            },
            "reviewRating": {
                "@type": "Rating",
                "ratingValue": rating_num,
                "bestRating": 5,
                "worstRating": 1,
                "alternateName": rating_text,
            },
            "itemReviewed": {
                "@type": "CreativeWork",
                "author": {"@type": "Person", "name": author_name},
            },
        })

    return reviews


# =====================================================================
# MASTER BUILDER & GRAPH ORCHESTRATION
# =====================================================================

def build_json_ld_schemas(
    title: str,
    slug: str,
    content: str,
    meta_description: Optional[str] = None,
    hero_image_url: Optional[str] = None,
    author_name: str = "The Dispatch Editorial Bureau",
    author_role: Optional[str] = "Senior Technical Editor",
    author_bio: Optional[str] = None,
    publisher_name: str = "Dispatch Media Group",
    published_url: Optional[str] = None,
    same_as_links: Optional[List[str]] = None,
    date_published: Optional[str] = None,
    date_modified: Optional[str] = None,
    tags: Optional[List[str]] = None,
    category: Optional[str] = "Engineering & AI",
    video_url: Optional[str] = None,
    verified_claims: Optional[List[Dict[str, Any]]] = None,
    article_type: str = "Article",
    product_info: Optional[Dict[str, Any]] = None,
    include_howto_schema: Optional[bool] = None,
    visible_faq_required: bool = True,
) -> List[Dict[str, Any]]:
    """
    Constructs an exhaustive suite of Schema.org structured data schemas:
    1. Primary Article (with entity resolution, wordCount, speakable, and external citations).
    2. FAQPage (ONLY when visible FAQ content exists in the page; tagged as unproven/AB test per A12).
    3. HowTo (optional toggleable markup; Google retired HowTo rich snippets in 2023, HTML steps preserved).
    4. BreadcrumbList (Home > Category > Article).
    5. Organization (brand authority and sameAs knowledge-graph profiles).
    6. Person (authoritative author profile with E-E-A-T credentials).
    7. Product (where applicable: software comparison, product reviews, specifications).
    8. VideoObject (if video asset is present).
    9. ClaimReview (if fact-checked claims are provided).

    Returns a list of schema dictionaries, maintaining 100% backwards compatibility
    with existing tests while offering enterprise-grade entity depth.
    """
    now_iso = datetime.now(timezone.utc).isoformat()
    pub_date = date_published or now_iso
    mod_date = date_modified or now_iso

    site_url = published_url.split("/posts")[0] if published_url and "/posts" in published_url else (
        published_url.split("/content")[0] if published_url and "/content" in published_url else "https://example.com"
    )
    url = published_url or f"{site_url}/posts/{slug}"

    schemas: List[Dict[str, Any]] = []

    # Clean text values
    clean_title = clean_markdown_text(title)
    clean_desc = clean_markdown_text(meta_description or title)
    clean_content = clean_markdown_text(content)
    words = clean_content.split()
    word_count = len(words) if words else 500

    # Stable graph URIs
    article_uri = f"{url}#article"
    webpage_uri = f"{url}#webpage"
    org_uri = f"{site_url}#organization"
    author_slug = _slugify(author_name)
    author_uri = f"{site_url}#author-{author_slug}"

    # Extract entities and citations
    about_ents, mention_ents = extract_entity_mentions(content, title=title, tags=tags)
    citations = extract_citations_from_markdown(content)

    # 1. Primary Article Schema (supports Article, TechArticle, NewsArticle, BlogPosting)
    valid_types = {"Article", "TechArticle", "NewsArticle", "BlogPosting"}
    chosen_type = article_type if article_type in valid_types else "Article"
    if article_type == "auto":
        if "```" in content or "api" in title.lower() or "architecture" in title.lower():
            chosen_type = "TechArticle"
        elif "news" in title.lower() or "announced" in title.lower():
            chosen_type = "NewsArticle"
        else:
            chosen_type = "Article"


    article_schema: Dict[str, Any] = {
        "@context": "https://schema.org",
        "@type": chosen_type,
        "@id": article_uri,
        "isPartOf": {"@type": "WebPage", "@id": webpage_uri},
        "mainEntityOfPage": {"@type": "WebPage", "@id": webpage_uri},
        "headline": clean_title,
        "name": clean_title,
        "description": clean_desc,
        "datePublished": pub_date,
        "dateModified": mod_date,
        "inLanguage": "en-US",
        "wordCount": word_count,
        "isAccessibleForFree": True,
        "author": {
            "@type": "Person",
            "@id": author_uri,
            "name": author_name,
            "url": f"{site_url}/authors/{author_slug}",
        },
        "publisher": {
            "@type": "Organization",
            "@id": org_uri,
            "name": publisher_name,
            "url": site_url,
            "logo": {
                "@type": "ImageObject",
                "url": f"{site_url}/logo.png",
            },
        },
        "speakable": {
            "@type": "SpeakableSpecification",
            "cssSelector": ["h1", "article p:first-of-type", ".executive-summary"],
        },
    }

    if hero_image_url:
        full_img_url = f"{site_url}{hero_image_url}" if hero_image_url.startswith("/") else hero_image_url
        article_schema["image"] = [hero_image_url]
        article_schema["primaryImageOfPage"] = {
            "@type": "ImageObject",
            "@id": f"{url}#primaryimage",
            "url": full_img_url,
            "contentUrl": full_img_url,
            "caption": clean_title,
            "width": 1200,
            "height": 675,
        }

    if tags:
        article_schema["keywords"] = [str(t).strip() for t in tags if str(t).strip()]
    if category:
        article_schema["articleSection"] = category

    if about_ents:
        article_schema["about"] = about_ents
    if mention_ents:
        article_schema["mentions"] = mention_ents
    if citations:
        article_schema["citation"] = citations

    schemas.append(article_schema)

    # 2. FAQPage Schema (ONLY emitted when visible FAQ content exists)
    faq_pairs = extract_faq_pairs_from_markdown(content)
    if faq_pairs and (not visible_faq_required or len(faq_pairs) >= 1):
        faq_schema: Dict[str, Any] = {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "@id": f"{url}#faq",
            "comment": "Valid Schema.org FAQPage. Retired as Google rich snippet for commercial sites; AI citation benefit is unproven and subject to A/B testing (A12).",
            "abTestGroup": "ai_citation_experiment",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": pair["question"],
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": pair["answer"],
                    },
                }
                for pair in faq_pairs
            ],
        }
        schemas.append(faq_schema)

    howto_steps = extract_howto_steps_from_markdown(content)
    should_include_howto = include_howto_schema if include_howto_schema is not None else (
        len(howto_steps) >= 3 and any(w in title.lower() or w in content.lower()[:300] for w in ("how", "guide", "step", "tutorial", "walkthrough", "setup"))
    )
    if should_include_howto and len(howto_steps) >= 3:
        howto_schema = generate_howto_schema(
            name=clean_title,
            description=clean_desc,
            steps=howto_steps,
            url=url,
            image_url=hero_image_url,
        )
        howto_schema["@id"] = f"{url}#howto"
        schemas.append(howto_schema)

    # 4. Product Schema (where applicable: software comparison, product reviews, specifications)
    if product_info:
        prod_schema = generate_product_schema(
            name=product_info.get("name", clean_title),
            description=product_info.get("description", clean_desc),
            brand=product_info.get("brand", publisher_name),
            image_url=product_info.get("image_url", hero_image_url),
            sku=product_info.get("sku"),
            offers=product_info.get("offers"),
            rating_value=product_info.get("rating_value"),
            review_count=product_info.get("review_count"),
            author_name=author_name,
            url=url,
        )
        prod_schema["@id"] = f"{url}#product"
        schemas.append(prod_schema)

    # 5. BreadcrumbList Schema (Google Rich Snippets cornerstone)
    breadcrumb_items = [
        {"name": "Home", "url": "/"},
        {"name": category or "Articles", "url": f"/category/{_slugify(category or 'articles')}"},
        {"name": clean_title, "url": url},
    ]
    breadcrumb_schema = generate_breadcrumb_schema(breadcrumb_items, base_url=site_url)
    breadcrumb_schema["@id"] = f"{url}#breadcrumb"
    schemas.append(breadcrumb_schema)

    # 5. Organization Entity Resolution Schema (with sameAs links)
    org_schema = generate_organization_schema(
        name=publisher_name,
        url=site_url,
        logo_url=f"{site_url}/logo.png",
        same_as_links=same_as_links,
    )
    schemas.append(org_schema)

    # 6. Person (Author) E-E-A-T Schema
    author_schema = generate_person_schema(
        author_name=author_name,
        author_role=author_role,
        author_bio=author_bio,
        organization_name=publisher_name,
        base_url=site_url,
        same_as=same_as_links,
    )
    schemas.append(author_schema)

    # 7. VideoObject Schema (if video URL provided)
    if video_url:
        video_schema = generate_video_schema(
            title=f"Video Summary: {clean_title}",
            description=clean_desc,
            video_url=video_url,
            thumbnail_url=hero_image_url or f"{site_url}/video-thumb.jpg",
            upload_date=pub_date,
        )
        video_schema["@id"] = f"{url}#video"
        schemas.append(video_schema)

    # 8. ClaimReview Schema (if fact-checked claims provided)
    if verified_claims:
        claim_reviews = generate_claim_review_schema(
            verified_claims=verified_claims,
            article_url=url,
            author_name=author_name,
            publisher_name=publisher_name,
        )
        schemas.extend(claim_reviews)

    logger.info(
        f"Built {len(schemas)} JSON-LD schemas for post '{title}' "
        f"(Type: {chosen_type}, FAQs: {len(faq_pairs)}, Steps: {len(howto_steps)}, Ents: {len(about_ents) + len(mention_ents)})"
    )
    return schemas


def build_json_ld_graph(
    title: str,
    slug: str,
    content: str,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    Generates a unified Schema.org @graph representation.
    All entity nodes (Article, FAQ, HowTo, BreadcrumbList, Organization, Person)
    are joined under a single '@graph' array with connected '@id' URIs.
    """
    schemas = build_json_ld_schemas(title=title, slug=slug, content=content, **kwargs)
    graph_nodes = []
    for s in schemas:
        node = dict(s)
        node.pop("@context", None)
        graph_nodes.append(node)

    return {
        "@context": "https://schema.org",
        "@graph": graph_nodes,
    }


def render_json_ld_script(
    schemas_or_graph: Union[List[Dict[str, Any]], Dict[str, Any]],
    indent: int = 2,
) -> str:
    """
    Renders an HTML <script type="application/ld+json"> tag containing
    the formatted JSON-LD for direct injection into Next.js/HTML pages.
    """
    if isinstance(schemas_or_graph, list):
        # Convert loose list to connected @graph
        graph_nodes = []
        for s in schemas_or_graph:
            node = dict(s)
            node.pop("@context", None)
            graph_nodes.append(node)
        payload: Dict[str, Any] = {
            "@context": "https://schema.org",
            "@graph": graph_nodes,
        }
    else:
        payload = schemas_or_graph

    json_str = json.dumps(payload, indent=indent, ensure_ascii=False)
    return f'<script type="application/ld+json">\n{json_str}\n</script>'


# =====================================================================
# RICH RESULTS VALIDATOR
# =====================================================================

def validate_schema_for_rich_results(schemas: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Audits generated schemas against Google Search Central Rich Results requirements.
    Detects missing required or recommended properties for Article, FAQPage, HowTo, and BreadcrumbList.
    """
    issues: List[str] = []
    warnings: List[str] = []
    detected_types: List[str] = []

    for s in schemas:
        stype = s.get("@type")
        if not stype:
            continue
        detected_types.append(stype)

        if stype in ("Article", "TechArticle", "NewsArticle", "BlogPosting"):
            if not s.get("headline"):
                issues.append(f"{stype} is missing required 'headline'.")
            if not s.get("image"):
                warnings.append(f"{stype} is missing recommended 'image'.")
            if not s.get("datePublished"):
                issues.append(f"{stype} is missing required 'datePublished'.")
            if not s.get("author"):
                issues.append(f"{stype} is missing required 'author'.")
            if not s.get("publisher"):
                issues.append(f"{stype} is missing required 'publisher'.")

        elif stype == "FAQPage":
            entities = s.get("mainEntity") or []
            if not entities:
                issues.append("FAQPage has empty 'mainEntity'.")
            for idx, q in enumerate(entities):
                if not q.get("name"):
                    issues.append(f"FAQ question #{idx + 1} is missing 'name'.")
                ans = q.get("acceptedAnswer", {}).get("text")
                if not ans:
                    issues.append(f"FAQ answer #{idx + 1} is missing 'acceptedAnswer.text'.")

        elif stype == "HowTo":
            steps = s.get("step") or []
            if not steps:
                issues.append("HowTo is missing 'step' list.")
            for idx, step in enumerate(steps):
                if not step.get("name") and not step.get("text"):
                    issues.append(f"HowTo step #{idx + 1} is missing name and text.")

        elif stype == "BreadcrumbList":
            items = s.get("itemListElement") or []
            if len(items) < 2:
                warnings.append("BreadcrumbList has fewer than 2 items.")

    return {
        "valid": len(issues) == 0,
        "errors": issues,
        "warnings": warnings,
        "detected_types": detected_types,
        "schema_count": len(schemas),
    }


# =====================================================================
# VISIBLE PAGE MATCHING & CI ROUND-TRIP VALIDATOR
# =====================================================================

def validate_page_content_matching(
    schemas: List[Dict[str, Any]],
    visible_markdown_or_html: str,
) -> Dict[str, Any]:
    """
    Validates that Schema.org values strictly match the visible page content.
    Prevents Google manual actions for deceptive/hidden structured data.
    Checks:
    - Headline appears in visible page
    - Author appears in visible page
    - FAQ questions/answers appear in visible page
    """
    clean_visible = clean_markdown_text(visible_markdown_or_html).lower()
    mismatches: List[str] = []
    matches: List[str] = []

    for s in schemas:
        stype = s.get("@type")
        if stype in ("Article", "TechArticle", "NewsArticle", "BlogPosting"):
            headline = (s.get("headline") or "").lower()
            if headline:
                # Check for significant substring presence (at least 60% of significant terms)
                terms = [w for w in re.findall(r"\b\w{4,}\b", headline)]
                matched_terms = sum(1 for t in terms if t in clean_visible)
                if terms and (matched_terms / len(terms) >= 0.6):
                    matches.append(f"{stype}.headline matched visible content.")
                else:
                    mismatches.append(f"{stype}.headline ('{headline[:50]}...') does not match visible content.")

            author_obj = s.get("author")
            author_name = author_obj.get("name") if isinstance(author_obj, dict) else None
            if author_name and author_name.lower() in clean_visible:
                matches.append(f"{stype}.author ('{author_name}') confirmed on page.")

        elif stype == "FAQPage":
            entities = s.get("mainEntity") or []
            for idx, q in enumerate(entities):
                q_name = (q.get("name") or "").lower()
                q_terms = [w for w in re.findall(r"\b\w{4,}\b", q_name)]
                if q_terms:
                    matched_q = sum(1 for t in q_terms if t in clean_visible)
                    if matched_q / len(q_terms) >= 0.6:
                        matches.append(f"FAQPage Q#{idx + 1} confirmed in visible content.")
                    else:
                        mismatches.append(f"FAQPage Q#{idx + 1} ('{q_name[:40]}...') not found in visible content.")

    return {
        "passed": len(mismatches) == 0,
        "mismatches": mismatches,
        "matches": matches,
    }


def validate_json_ld_ci(
    html_or_script: str,
    visible_text: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Automated CI Validator for JSON-LD structured data.
    Simulates 'extruct' round-trip parsing from HTML:
    1. Extracts all <script type="application/ld+json"> blocks.
    2. Parses JSON and verifies valid Schema.org context and types.
    3. Verifies required properties for Article, Person, Organization, BreadcrumbList, Product.
    4. Validates that values match visible page text (if visible_text is provided).
    """
    json_blocks: List[Dict[str, Any]] = []

    # 1. Try extruct if installed
    try:
        import extruct
        data = extruct.extract(html_or_script, syntaxes=["json-ld"])
        extracted_ld = data.get("json-ld", [])
        for item in extracted_ld:
            if isinstance(item, dict):
                json_blocks.append(item)
    except (ImportError, Exception):
        # Built-in robust regex extractor
        raw_scripts = re.findall(
            r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
            html_or_script,
            re.DOTALL | re.IGNORECASE,
        )
        if not raw_scripts and html_or_script.strip().startswith("{"):
            # Raw JSON string passed directly
            raw_scripts = [html_or_script]

        for s in raw_scripts:
            try:
                parsed = json.loads(s.strip())
                if isinstance(parsed, dict):
                    if "@graph" in parsed:
                        for node in parsed["@graph"]:
                            if isinstance(node, dict):
                                json_blocks.append(node)
                    else:
                        json_blocks.append(parsed)
                elif isinstance(parsed, list):
                    for p in parsed:
                        if isinstance(p, dict):
                            json_blocks.append(p)
            except json.JSONDecodeError as err:
                return {
                    "valid": False,
                    "errors": [f"Invalid JSON syntax in JSON-LD script: {err}"],
                    "warnings": [],
                    "detected_types": [],
                }

    if not json_blocks:
        return {
            "valid": False,
            "errors": ["No valid JSON-LD structured data blocks found in payload."],
            "warnings": [],
            "detected_types": [],
        }

    # Rich results check
    rich_res = validate_schema_for_rich_results(json_blocks)

    # Visible page content matching
    page_matching = None
    if visible_text:
        page_matching = validate_page_content_matching(json_blocks, visible_text)
        if not page_matching["passed"]:
            rich_res["warnings"].extend(page_matching["mismatches"])

    return {
        "valid": rich_res["valid"] and (page_matching["passed"] if page_matching else True),
        "errors": rich_res["errors"],
        "warnings": rich_res["warnings"],
        "detected_types": rich_res["detected_types"],
        "schema_count": len(json_blocks),
        "page_matching": page_matching,
    }

