"""
A5c: Article Production Studio — Typed Document Model, Blueprints, and Renderers.

Design principle:
  Write once as a typed block model (JSON); render many times.
  Verification (A4) and lint run on the model once.
  Renderers emit: semantic HTML, Markdown/MDX, WordPress blocks, CMS-specific JSON.
  The human reviewer sees the same structure that will publish.

Block types (spec-complete):
  heading, paragraph, answer_block, key_takeaways, list, table, figure
  (diagram | chart | image | screenshot), callout, quote, code, faq,
  references, cta, author_box.

Blueprints (config per site, all required components enforced as warnings not hard failures):
  how_to, comparison, definition, roundup, data_study, case_study, pillar
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Set, Tuple, Union
from pydantic import BaseModel, Field, field_validator

# ---------------------------------------------------------------------------
# Shared sub-models
# ---------------------------------------------------------------------------

class ClaimRef(BaseModel):
    """A factual claim attached to a block, linked to A4 verification."""
    claim_text: str
    source_url: Optional[str] = None
    verified: Optional[bool] = None
    confidence: float = 1.0

    @field_validator("source_url", mode="before")
    @classmethod
    def coerce_source_url(cls, v: Any) -> Optional[str]:
        if isinstance(v, (list, tuple)):
            for item in v:
                if item and str(item).strip():
                    return str(item).strip()
            return None
        if isinstance(v, str):
            v_clean = v.strip()
            return v_clean if v_clean else None
        if v is None:
            return None
        return str(v).strip() or None


class SourceRef(BaseModel):
    """A source citation attached to a block."""
    url: str
    title: Optional[str] = None
    accessed_at: Optional[str] = None

    @field_validator("url", mode="before")
    @classmethod
    def coerce_url(cls, v: Any) -> str:
        if isinstance(v, (list, tuple)):
            for item in v:
                if item and str(item).strip():
                    return str(item).strip()
            return ""
        if isinstance(v, str):
            return v.strip()
        if v is None:
            return ""
        return str(v).strip()


class FigureProvenance(BaseModel):
    """Provenance metadata for every figure block."""
    source: Literal["ai_generated", "real_screenshot", "stock", "original_data", "customer_provided", "public_domain", "licensed"]
    generator: Optional[str] = None      # e.g. "cloudflare/flux-1-schnell", "gemini-2.5-flash-image"
    credit: Optional[str] = None         # Attribution line shown to readers
    license: Optional[str] = None        # e.g. "CC-BY-4.0", "All rights reserved"
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ---------------------------------------------------------------------------
# Block type definitions
# ---------------------------------------------------------------------------

BlockType = Literal[
    "heading", "paragraph", "answer_block", "key_takeaways",
    "list", "table", "figure", "callout", "quote", "code",
    "faq", "references", "cta", "author_box",
]

FigureKind = Literal["diagram", "chart", "image", "screenshot"]


class BaseBlock(BaseModel):
    """Every block carries its own claim and source lists for A4 verification."""
    block_id: str = ""
    block_type: BlockType
    claims: List[ClaimRef] = Field(default_factory=list)
    sources: List[SourceRef] = Field(default_factory=list)
    # Lint / verification result attached at audit time
    lint_warnings: List[str] = Field(default_factory=list)
    verified: Optional[bool] = None

    def model_post_init(self, __context: Any) -> None:
        if not self.block_id:
            raw = f"{self.block_type}|{id(self)}"
            self.block_id = hashlib.sha1(raw.encode()).hexdigest()[:10]


class HeadingBlock(BaseBlock):
    block_type: Literal["heading"] = "heading"
    level: int = Field(default=2, ge=1, le=6)
    text: str


class ParagraphBlock(BaseBlock):
    block_type: Literal["paragraph"] = "paragraph"
    text: str                    # Markdown inline syntax allowed
    word_count: int = 0

    def model_post_init(self, __context: Any) -> None:
        super().model_post_init(__context)
        self.word_count = len(self.text.split())


class AnswerBlock(BaseBlock):
    """
    Answer-first block for AEO / featured snippet targeting (A5b integration).
    Carries the question heading, the direct 40-60 word answer, and optional depth.
    """
    block_type: Literal["answer_block"] = "answer_block"
    question: str                # H2/H3 in question form
    direct_answer: str           # 40-60 word self-contained answer
    depth_content: Optional[str] = None
    click_anchor: Optional[str] = None
    target_format: Literal["paragraph", "ordered_list", "unordered_list", "table", "video", "unknown"] = "paragraph"
    heading_level: int = 2
    word_count: int = 0

    def model_post_init(self, __context: Any) -> None:
        super().model_post_init(__context)
        self.word_count = len(self.direct_answer.split())


class KeyTakeawaysBlock(BaseBlock):
    """Boxed summary at the top; ideal for pillar guides and roundups."""
    block_type: Literal["key_takeaways"] = "key_takeaways"
    items: List[str]             # 3-6 crisp bullet points


class ListBlock(BaseBlock):
    block_type: Literal["list"] = "list"
    ordered: bool = False
    items: List[str]
    intro: Optional[str] = None  # One sentence introducing the list


class TableBlock(BaseBlock):
    """
    Semantic table. Never an image of a table.
    Requires caption, thead with scope attributes, and at least 2 data rows.
    Carries a 'last_checked' date for pricing / volatile data.
    """
    block_type: Literal["table"] = "table"
    caption: str
    headers: List[str]           # Column headers; scope='col' applied by renderer
    rows: List[List[str]]        # Row data (strings only, no nested HTML)
    last_checked: Optional[str] = None  # ISO date for volatile data (pricing, availability)
    # Affordance for row-scope headers (first cell of each row is a row header)
    row_headers: bool = False

    @property
    def data_row_count(self) -> int:
        return len(self.rows)


class FigureBlock(BaseBlock):
    """
    Any visual asset. No figures without alt text, caption, and provenance.
    For charts: requires data_source so the chart is verifiable.
    """
    block_type: Literal["figure"] = "figure"
    kind: FigureKind
    src: str                     # URL or relative path (from /uploads/)
    alt: str                     # Non-empty; describes content for screen readers
    caption: str                 # Shown to all readers
    credit: Optional[str] = None # Attribution line
    provenance: FigureProvenance
    # For chart figures
    data_source: Optional[str] = None   # URL to raw data used in chart
    chart_type: Optional[str] = None    # e.g. "bar", "line", "scatter"
    # For screenshots
    software_version: Optional[str] = None  # e.g. "Chrome 127 / macOS Sonoma"


class CalloutBlock(BaseBlock):
    """Tip, warning, note, or important box."""
    block_type: Literal["callout"] = "callout"
    variant: Literal["tip", "warning", "note", "important", "caution"] = "note"
    title: Optional[str] = None
    text: str


class QuoteBlock(BaseBlock):
    """
    A real, attributed quote. Never a paraphrase presented as a quote.
    Speaker and context are mandatory.
    """
    block_type: Literal["quote"] = "quote"
    text: str                    # Exact quote text
    speaker: str                 # Full name
    role: Optional[str] = None   # Title / role at organisation
    organisation: Optional[str] = None
    date: Optional[str] = None   # When the statement was made
    # The quote must be verifiable; attach a source
    # (inherited sources[] field from BaseBlock)


class CodeBlock(BaseBlock):
    block_type: Literal["code"] = "code"
    language: str = "text"
    code: str
    caption: Optional[str] = None


class FAQBlock(BaseBlock):
    """
    Visible Q&A section. FAQPage JSON-LD is optional (removed as Google rich result May 2026).
    Controlled by blueprint config faq_schema_enabled (A12 AB-test hypothesis).
    """
    block_type: Literal["faq"] = "faq"
    items: List[Dict[str, Any]]  # [{"question": "...", "answer": "...", "include_in_schema": bool}]
    include_schema: bool = False  # False by default per spec


class ReferencesBlock(BaseBlock):
    block_type: Literal["references"] = "references"
    items: List[Dict[str, Any]]  # [{"title": "...", "url": "...", "accessed_at": "..."}]


class CTABlock(BaseBlock):
    block_type: Literal["cta"] = "cta"
    text: str
    button_label: str
    button_url: str
    variant: Literal["primary", "secondary", "inline"] = "primary"


class AuthorBoxBlock(BaseBlock):
    block_type: Literal["author_box"] = "author_box"
    name: str
    bio: str
    avatar_url: Optional[str] = None
    role: Optional[str] = None
    links: List[Dict[str, str]] = Field(default_factory=list)  # [{"label": "LinkedIn", "url": "..."}]


# Union type for all blocks
AnyBlock = Union[
    HeadingBlock, ParagraphBlock, AnswerBlock, KeyTakeawaysBlock,
    ListBlock, TableBlock, FigureBlock, CalloutBlock, QuoteBlock,
    CodeBlock, FAQBlock, ReferencesBlock, CTABlock, AuthorBoxBlock,
]


# ---------------------------------------------------------------------------
# Article Document Model
# ---------------------------------------------------------------------------

ArticleType = Literal[
    "how_to", "comparison", "definition", "roundup",
    "data_study", "case_study", "pillar", "generic",
]


class ArticleDocumentModel(BaseModel):
    """
    The single source of truth for a published article.
    Renderers read this; nothing else publishes directly.
    """
    doc_id: str = ""
    article_type: ArticleType = "generic"
    title: str
    slug: str
    meta_description: Optional[str] = None
    author: Optional[str] = None
    published_at: Optional[str] = None
    updated_at: Optional[str] = None
    keywords: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    # Ordered list of content blocks
    blocks: List[AnyBlock] = Field(default_factory=list)
    # Document-level metadata
    total_word_count: int = 0
    blueprint_id: Optional[str] = None        # Which blueprint was applied
    blueprint_compliance: Dict[str, Any] = Field(default_factory=dict)
    # Visual decision plan (A5c.3)
    visual_plan: Optional[Dict[str, Any]] = None
    # Schema metadata (from schema_builder, can be dict or list of schema nodes)
    schema_markup: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None
    # A4 verification summary
    fact_verification_summary: Optional[Dict[str, Any]] = None
    # Lint summary
    lint_summary: Optional[Dict[str, Any]] = None

    def model_post_init(self, __context: Any) -> None:
        if not self.doc_id:
            raw = f"{self.slug}|{self.title}"
            self.doc_id = hashlib.sha1(raw.encode()).hexdigest()[:12]
        self._recompute_word_count()

    def _recompute_word_count(self) -> None:
        total = 0
        for block in self.blocks:
            if hasattr(block, "text"):
                total += len(getattr(block, "text", "").split())
            elif hasattr(block, "direct_answer"):
                total += len(getattr(block, "direct_answer", "").split())
            elif hasattr(block, "items") and isinstance(block.items, list):  # type: ignore
                for item in block.items:  # type: ignore
                    if isinstance(item, str):
                        total += len(item.split())
        self.total_word_count = total

    def block_ids_by_type(self, bt: BlockType) -> List[str]:
        return [b.block_id for b in self.blocks if b.block_type == bt]

    @property
    def has_answer_block(self) -> bool:
        return any(b.block_type == "answer_block" for b in self.blocks)

    @property
    def has_table(self) -> bool:
        return any(b.block_type == "table" for b in self.blocks)

    @property
    def has_faq(self) -> bool:
        return any(b.block_type == "faq" for b in self.blocks)

    @property
    def figures(self) -> List[FigureBlock]:
        return [b for b in self.blocks if b.block_type == "figure"]  # type: ignore

    @property
    def quotes(self) -> List[QuoteBlock]:
        return [b for b in self.blocks if b.block_type == "quote"]  # type: ignore

    @property
    def all_claims(self) -> List[ClaimRef]:
        claims = []
        for block in self.blocks:
            claims.extend(block.claims)
        return claims


# ---------------------------------------------------------------------------
# Blueprint Definitions
# ---------------------------------------------------------------------------

class BlueprintComponent(BaseModel):
    block_type: BlockType
    required: bool = True
    description: str
    lint_hint: Optional[str] = None


class ArticleBlueprint(BaseModel):
    """
    Per-article-type component contract.
    Required components are enforced as lint warnings, not hard failures.
    All thresholds are configurable per site.
    """
    blueprint_id: str
    article_type: ArticleType
    display_name: str
    description: str
    required_components: List[BlueprintComponent]
    optional_components: List[BlueprintComponent] = Field(default_factory=list)
    # Configurable thresholds
    min_word_count: int = 800
    max_word_count: int = 3000
    min_images: int = 0
    min_tables: int = 0
    notes: List[str] = Field(default_factory=list)


def _make_component(bt: BlockType, required: bool, desc: str, hint: Optional[str] = None) -> BlueprintComponent:
    return BlueprintComponent(block_type=bt, required=required, description=desc, lint_hint=hint)


BLUEPRINTS: Dict[str, ArticleBlueprint] = {
    "how_to": ArticleBlueprint(
        blueprint_id="how_to",
        article_type="how_to",
        display_name="How-To Guide",
        description="Step-by-step instructional content. Answer-first intro required. Steps are numbered.",
        required_components=[
            _make_component("answer_block", True, "Answer-first intro: direct answer to 'How do you X?' (40-60 words)"),
            _make_component("key_takeaways", True, "Key takeaways box above the fold"),
            _make_component("list", True, "Numbered steps as an ordered list or series of H3 blocks"),
            _make_component("faq", True, "FAQ section from PAA questions"),
        ],
        optional_components=[
            _make_component("figure", False, "Screenshots where software UI is involved", "One per major step; alt and caption required"),
            _make_component("figure", False, "Flow diagram if branching logic exists"),
            _make_component("table", False, "Troubleshooting table: Issue → Cause → Fix"),
            _make_component("callout", False, "Warning or tip callouts for risky steps"),
        ],
        min_word_count=800,
        max_word_count=2500,
        min_images=0,
        notes=["Never use images of text or code; use <code> blocks instead."],
    ),

    "comparison": ArticleBlueprint(
        blueprint_id="comparison",
        article_type="comparison",
        display_name="Comparison (X vs Y)",
        description="Objective comparison. Verdict stated up top. Criteria explained before the table.",
        required_components=[
            _make_component("answer_block", True, "Verdict up top: which is better and for whom (40-60 words)"),
            _make_component("table", True, "Comparison table with a header row; include a 'last checked' date for pricing"),
            _make_component("paragraph", True, "Criteria explained: why these criteria were chosen"),
            _make_component("references", True, "Sources cited for all data points in the table"),
        ],
        optional_components=[
            _make_component("callout", False, "Pros/cons callouts per option"),
            _make_component("table", False, "Pricing table with 'last checked' date"),
            _make_component("faq", False, "FAQ from PAA: 'Is X better than Y?'"),
            _make_component("cta", False, "CTA to a comparison tool or calculator"),
        ],
        min_word_count=1000,
        max_word_count=3000,
        min_tables=1,
        notes=[
            "Pricing data must carry a 'last checked' date in the table caption.",
            "Affiliate disclosure required if any link is monetised.",
        ],
    ),

    "definition": ArticleBlueprint(
        blueprint_id="definition",
        article_type="definition",
        display_name="Definition / What Is X",
        description="Authoritative definition. The answer block IS the snippet target.",
        required_components=[
            _make_component("answer_block", True, "Definition answer block: one crisp 40-60 word definition paragraph"),
            _make_component("paragraph", True, "Why it matters: practical context"),
            _make_component("paragraph", True, "Real-world example with specific, verifiable details"),
        ],
        optional_components=[
            _make_component("figure", False, "Concept diagram showing the entity in context"),
            _make_component("table", False, "Glossary of related terms"),
            _make_component("faq", False, "FAQ: related questions from PAA"),
            _make_component("callout", False, "Common misconceptions callout"),
        ],
        min_word_count=600,
        max_word_count=2000,
        notes=["Definition must be self-contained and quote-ready (no 'as mentioned above')."],
    ),

    "roundup": ArticleBlueprint(
        blueprint_id="roundup",
        article_type="roundup",
        display_name="Roundup / Listicle",
        description="Curated list of options. Selection criteria stated before the list.",
        required_components=[
            _make_component("paragraph", True, "Selection criteria: how items were chosen and by whom"),
            _make_component("list", True, "Consistent per-item structure across all items"),
            _make_component("table", True, "Summary comparison table of all items"),
        ],
        optional_components=[
            _make_component("callout", False, "Affiliate / paid placement disclosure"),
            _make_component("faq", False, "FAQ from PAA"),
            _make_component("key_takeaways", False, "Top picks summary box"),
        ],
        min_word_count=1200,
        max_word_count=4000,
        notes=[
            "Affiliate disclosure is required if any item link is monetised (Google spam policy).",
            "Per-item structure must be consistent: do not add sections for some items and omit for others.",
        ],
    ),

    "data_study": ArticleBlueprint(
        blueprint_id="data_study",
        article_type="data_study",
        display_name="Data Study / Original Research",
        description="Original data, methodology required, charts from real data only.",
        required_components=[
            _make_component("paragraph", True, "Methodology: sample, collection method, date range, limitations"),
            _make_component("figure", True, "Charts generated from real data (chart type must match data shape)"),
            _make_component("cta", True, "Downloadable dataset: link or button for raw data"),
            _make_component("paragraph", True, "Limitations section: what the data cannot prove"),
        ],
        optional_components=[
            _make_component("figure", False, "Embeddable chart"),
            _make_component("paragraph", False, "Press summary (3-sentence embeddable excerpt)"),
            _make_component("table", False, "Raw data table or summary statistics"),
            _make_component("references", False, "Data source citations with access dates"),
            _make_component("callout", False, "Key finding callout for press / social sharing"),
        ],
        min_word_count=1500,
        max_word_count=5000,
        min_images=1,
        min_tables=1,
        notes=[
            "Every chart must have a data_source field linking to the underlying dataset.",
            "Never present projected data as measured data.",
            "Limitations must appear before conclusions, not as a footnote.",
        ],
    ),

    "case_study": ArticleBlueprint(
        blueprint_id="case_study",
        article_type="case_study",
        display_name="Case Study",
        description="Real customer, real numbers, with permission. Timeline required.",
        required_components=[
            _make_component("paragraph", True, "Customer context: who they are, what they needed"),
            _make_component("list", True, "Timeline or chronological narrative"),
            _make_component("paragraph", True, "Real results with specific numbers (e.g. '42% reduction in churn')"),
            _make_component("quote", True, "Attributed customer quote (exact, with permission)"),
        ],
        optional_components=[
            _make_component("figure", False, "Before/after chart from real data"),
            _make_component("callout", False, "Results summary box"),
            _make_component("cta", False, "CTA to a demo or similar case study"),
        ],
        min_word_count=800,
        max_word_count=2500,
        notes=[
            "Customer name, role, and permission to publish must be confirmed before publishing.",
            "Numbers must be exact and sourced; never round up for impressiveness.",
        ],
    ),

    "pillar": ArticleBlueprint(
        blueprint_id="pillar",
        article_type="pillar",
        display_name="Pillar Guide",
        description="Comprehensive topic authority page. TOC required. Internal link hub.",
        required_components=[
            _make_component("key_takeaways", True, "Key takeaways box at the top"),
            _make_component("list", True, "Table of contents (ordered list of section anchors)"),
            _make_component("answer_block", True, "Section-level answer blocks for each major H2"),
            _make_component("references", True, "References section with all external citations"),
        ],
        optional_components=[
            _make_component("figure", False, "Diagrams illustrating complex concepts"),
            _make_component("table", False, "Glossary table for domain terms"),
            _make_component("faq", False, "FAQ section aggregating PAA across all sub-topics"),
            _make_component("callout", False, "Key insights or warnings at section level"),
        ],
        min_word_count=2000,
        max_word_count=8000,
        notes=[
            "Every section should link out to spoke cluster articles.",
            "Add inbound links from all spoke articles to this pillar.",
        ],
    ),
}


# ---------------------------------------------------------------------------
# Blueprint Compliance Checker & Linting Engine
# ---------------------------------------------------------------------------

class ComplianceResult(BaseModel):
    blueprint_id: str
    article_type: ArticleType
    required_met: List[str] = Field(default_factory=list)
    required_missing: List[str] = Field(default_factory=list)
    optional_present: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    word_count: int = 0
    is_compliant: bool = True  # Missing required = warning, not failure per spec


class LintReport(BaseModel):
    """
    Unified validation & verification telemetry generated when linting the model.
    Enforces that verification (A4) and lint run on the model ONCE.
    """
    doc_id: str
    blueprint_id: str
    article_type: ArticleType
    is_valid: bool = True
    compliance: ComplianceResult
    warnings: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    block_lints: Dict[str, List[str]] = Field(default_factory=dict)
    claim_summary: Dict[str, Any] = Field(default_factory=dict)
    prohibitions: Optional[Dict[str, Any]] = None
    visual_density: Optional[Dict[str, Any]] = None


# Per-site blueprint overrides cache
SITE_BLUEPRINTS: Dict[str, Dict[str, ArticleBlueprint]] = {}


def configure_site_blueprint(site_id: str, article_type: str, overrides: Dict[str, Any]) -> ArticleBlueprint:
    """Configures or customizes a blueprint for a specific website (A5c.2)."""
    base = BLUEPRINTS.get(article_type, BLUEPRINTS["how_to"]).model_copy(deep=True)
    for k, v in overrides.items():
        if hasattr(base, k):
            setattr(base, k, v)
    if site_id not in SITE_BLUEPRINTS:
        SITE_BLUEPRINTS[site_id] = {}
    SITE_BLUEPRINTS[site_id][article_type] = base
    return base


def get_blueprint_for_site(article_type: str, site_config: Optional[Dict[str, Any]] = None) -> ArticleBlueprint:
    """
    Returns the effective blueprint for an article type and optional site configuration.
    Applies any site-specific overrides.
    """
    site_id = site_config.get("id") or site_config.get("site_id") if site_config else None
    if site_id and site_id in SITE_BLUEPRINTS and article_type in SITE_BLUEPRINTS[site_id]:
        return SITE_BLUEPRINTS[site_id][article_type]

    base = BLUEPRINTS.get(article_type) or BLUEPRINTS["how_to"]
    if not site_config or "blueprint_overrides" not in site_config:
        return base

    overrides = site_config.get("blueprint_overrides", {}).get(article_type, {})
    if not overrides:
        return base

    custom = base.model_copy(deep=True)
    for k, v in overrides.items():
        if hasattr(custom, k):
            setattr(custom, k, v)
    return custom


# ---------------------------------------------------------------------------
# A5c.3 Visual Decision Engine ("where needed")
# ---------------------------------------------------------------------------

class VisualSituation(str, Enum):
    COMPARE_ITEMS = "compare_items"                        # Compare 2+ items on 2+ attributes -> HTML table
    SEQUENCE_STEPS = "sequence_steps"                      # Sequence of 3+ steps -> Numbered list; flow diagram if branching
    ARCHITECTURE_RELATIONSHIPS = "architecture_relationships" # Architecture, relationships, hierarchy, timeline -> Diagram
    NUMBERS_OVER_TIME = "numbers_over_time"                # Numbers over time or across categories with real sourced data -> Chart
    SOFTWARE_UI = "software_ui"                            # Software UI or on-screen procedure -> Real screenshot
    CONCEPT_MOOD = "concept_mood"                          # Concept or mood hero -> Brand asset, stock, or AI image
    QUOTE_TESTIMONY = "quote_testimony"                    # Quote -> Pull quote (only real, attributed quote)
    UNKNOWN = "unknown"


VisualComponentKind = Literal[
    "table", "numbered_list", "flow_diagram", "diagram",
    "chart", "screenshot", "hero_image", "pull_quote",
]


class VisualDecisionRule(BaseModel):
    rule_id: str
    situation: VisualSituation
    preferred_component: VisualComponentKind
    description: str
    requires_justification: bool = True
    guideline: str
    notes: Optional[str] = None


DEFAULT_VISUAL_RULES: List[VisualDecisionRule] = [
    VisualDecisionRule(
        rule_id="rule_compare_items",
        situation=VisualSituation.COMPARE_ITEMS,
        preferred_component="table",
        description="Compare 2+ items on 2+ attributes",
        guideline="Use semantic HTML table (caption, header row, source & 'as of' date; never an image of a table).",
        notes="Never render comparison data as an image.",
    ),
    VisualDecisionRule(
        rule_id="rule_sequence_steps",
        situation=VisualSituation.SEQUENCE_STEPS,
        preferred_component="numbered_list",
        description="Sequence of 3+ steps",
        guideline="Use numbered list; add flow diagram only if branching or multi-actor.",
        notes="Do not create a flowchart for linear steps that text can describe clearly.",
    ),
    VisualDecisionRule(
        rule_id="rule_architecture_relationships",
        situation=VisualSituation.ARCHITECTURE_RELATIONSHIPS,
        preferred_component="diagram",
        description="Architecture, relationships, hierarchy, timeline",
        guideline="LLM writes Mermaid/D2/Graphviz source -> validate -> render to SVG.",
        notes="All diagrams must be validated before embedding.",
    ),
    VisualDecisionRule(
        rule_id="rule_numbers_over_time",
        situation=VisualSituation.NUMBERS_OVER_TIME,
        preferred_component="chart",
        description="Numbers over time or across categories with real sourced data",
        guideline="Chart with data file stored and verifiable data_source; reject chart if numbers cannot be sourced.",
        notes="Invented data or synthetic charts are strictly prohibited.",
    ),
    VisualDecisionRule(
        rule_id="rule_software_ui",
        situation=VisualSituation.SOFTWARE_UI,
        preferred_component="screenshot",
        description="Software UI or on-screen procedure",
        guideline="Real screenshot (Playwright capture, annotate, redact personal data) with software_version.",
        notes="Fake AI screenshots of software are strictly prohibited.",
    ),
    VisualDecisionRule(
        rule_id="rule_concept_mood",
        situation=VisualSituation.CONCEPT_MOOD,
        preferred_component="hero_image",
        description="Concept or mood hero",
        guideline="Brand asset, stock, or AI image (optional, disclosed, no text baked in unless verified).",
        notes="Text baked in images must be verified via A4 claims.",
    ),
    VisualDecisionRule(
        rule_id="rule_quote_testimony",
        situation=VisualSituation.QUOTE_TESTIMONY,
        preferred_component="pull_quote",
        description="Quote",
        guideline="Pull quote (only a real, attributed quote with named speaker and source citation).",
        notes="Fake testimonials or invented people are strictly prohibited.",
    ),
]


class VisualProposal(BaseModel):
    proposal_id: str = ""
    section_title: str
    situation: VisualSituation
    preferred_component: VisualComponentKind
    justification: str                   # Mandatory: What it shows that text cannot
    source_data_available: bool = True
    data_source: Optional[str] = None
    has_branching: bool = False
    has_multi_actor: bool = False
    diagram_format: Optional[Literal["mermaid", "d2", "graphviz"]] = None
    diagram_source: Optional[str] = None
    diagram_svg: Optional[str] = None
    diagram_valid: Optional[bool] = None
    diagram_error: Optional[str] = None
    is_decorative_filler: bool = False
    rejection_reason: Optional[str] = None
    approved: bool = True

    def model_post_init(self, __context: Any) -> None:
        if not self.proposal_id:
            raw = f"{self.section_title}|{self.situation.value}|{self.preferred_component}"
            self.proposal_id = hashlib.sha1(raw.encode()).hexdigest()[:10]


class VisualDensityAnalysis(BaseModel):
    total_words: int
    visual_count: int
    words_per_visual: float
    target_min_words_per_visual: int = 300
    target_max_words_per_visual: int = 400
    density_status: Literal["optimal", "too_dense", "too_sparse", "acceptable"]
    recommendation: str


class HardProhibitionsReport(BaseModel):
    has_violations: bool = False
    violations: List[Dict[str, Any]] = Field(default_factory=list)
    prohibitions_checked: List[str] = Field(default_factory=lambda: [
        "invented_data_or_charts",
        "fake_screenshots",
        "fake_testimonials_or_people",
        "unauthorized_logos_or_trademarks",
        "unverified_image_text",
    ])


class VisualPlanReport(BaseModel):
    doc_id: str
    proposals: List[VisualProposal] = Field(default_factory=list)
    approved_count: int = 0
    rejected_count: int = 0
    density: VisualDensityAnalysis
    prohibitions: HardProhibitionsReport
    diagrams_validated: int = 0


class VisualDecisionConfig(BaseModel):
    target_min_words_per_visual: int = 300
    target_max_words_per_visual: int = 400
    rules: List[VisualDecisionRule] = Field(default_factory=lambda: list(DEFAULT_VISUAL_RULES))
    allow_ai_hero: bool = True
    strict_prohibitions: bool = True


def validate_mermaid_syntax(mermaid_source: str) -> Tuple[bool, Optional[str]]:
    """
    Validates Mermaid diagram syntax before SVG rendering.
    Checks diagram declaration keywords, balanced brackets, quotes, and structural integrity.
    """
    if not mermaid_source or not mermaid_source.strip():
        return False, "Mermaid source is empty."

    lines = [line.strip() for line in mermaid_source.strip().splitlines() if line.strip() and not line.strip().startswith("%%")]
    if not lines:
        return False, "Mermaid source contains only comments or whitespace."

    header = lines[0].lower()
    valid_keywords = (
        "graph", "flowchart", "sequencediagram", "classdiagram", "statediagram",
        "statediagram-v2", "erdiagram", "gantt", "pie", "gitgraph", "journey",
        "mindmap", "quadrantchart", "architecture", "c4context", "timeline",
    )
    if not any(header.startswith(kw) for kw in valid_keywords):
        return False, (
            f"Mermaid diagram must begin with a recognized diagram keyword "
            f"(e.g., 'graph TD', 'flowchart LR', 'sequenceDiagram'). Got: '{lines[0][:30]}'"
        )

    # Check balanced brackets and quotes across the source
    source = mermaid_source
    counts = {b: 0 for b in ("[](){}")}
    in_double_quote = False
    in_single_quote = False
    escape = False

    for char in source:
        if escape:
            escape = False
            continue
        if char == "\\":
            escape = True
            continue
        if char == '"' and not in_single_quote:
            in_double_quote = not in_double_quote
            continue
        if char == "'" and not in_double_quote:
            in_single_quote = not in_single_quote
            continue
        if not in_double_quote and not in_single_quote:
            if char in counts:
                counts[char] += 1

    if counts["["] != counts["]"]:
        return False, f"Unbalanced square brackets in diagram: {counts['[']} open vs {counts[']']} closed."
    if counts["("] != counts[")"]:
        return False, f"Unbalanced parentheses in diagram: {counts['(']} open vs {counts[')']} closed."
    if counts["{"] != counts["}"]:
        return False, f"Unbalanced curly braces in diagram: {counts['{']} open vs {counts['}']} closed."
    if in_double_quote:
        return False, "Unclosed double quotes in diagram."

    return True, None


def render_mermaid_to_svg(mermaid_source: str, title: Optional[str] = None) -> str:
    """
    Renders a validated Mermaid diagram into semantic, clean SVG.
    Parses node definitions, labels, and connections, emitting high-contrast,
    accessible vector graphics with responsive viewBox and proper typography.
    """
    valid, err = validate_mermaid_syntax(mermaid_source)
    if not valid:
        safe_err = _esc(err or "Invalid Mermaid diagram syntax")
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 120" width="100%" height="120" role="img" aria-label="Diagram Error">\n'
            f'  <rect width="600" height="120" rx="8" fill="#FEF2F2" stroke="#EF4444" stroke-width="1"/>\n'
            f'  <text x="24" y="48" font-family="system-ui, sans-serif" font-size="14" font-weight="bold" fill="#B91C1C">Mermaid Syntax Error</text>\n'
            f'  <text x="24" y="80" font-family="system-ui, sans-serif" font-size="12" fill="#7F1D1D">{safe_err}</text>\n'
            f'</svg>'
        )

    # Parse simple nodes and edges
    lines = [l.strip() for l in mermaid_source.strip().splitlines() if l.strip() and not l.strip().startswith("%%")]
    header = lines[0] if lines else "graph TD"
    is_sequence = "sequencediagram" in header.lower()

    nodes: Dict[str, str] = {}
    edges: List[Tuple[str, str, Optional[str]]] = []

    for line in lines[1:]:
        if is_sequence:
            seq_m = re.match(r"^([A-Za-z0-9_]+)\s*(?:->>|-->>|->)\s*([A-Za-z0-9_]+)\s*:\s*(.+)$", line)
            if seq_m:
                src, dst, msg = seq_m.group(1), seq_m.group(2), seq_m.group(3)
                if src not in nodes:
                    nodes[src] = src
                if dst not in nodes:
                    nodes[dst] = dst
                edges.append((src, dst, msg))
            continue

        edge_pattern = re.match(r"^([A-Za-z0-9_]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})?\s*(-+>|==>|-.->)(?:\|(.*?)\|)?\s*([A-Za-z0-9_]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})?$", line)
        if edge_pattern:
            src_id = edge_pattern.group(1)
            src_lbl = edge_pattern.group(2) or edge_pattern.group(3) or edge_pattern.group(4) or src_id
            raw_src_lbl = edge_pattern.group(2) or edge_pattern.group(3) or edge_pattern.group(4)
            edge_lbl = edge_pattern.group(6)
            dst_id = edge_pattern.group(7)
            raw_dst_lbl = edge_pattern.group(8) or edge_pattern.group(9) or edge_pattern.group(10)
            if src_id not in nodes or raw_src_lbl:
                nodes[src_id] = raw_src_lbl or nodes.get(src_id, src_id)
            if dst_id not in nodes or raw_dst_lbl:
                nodes[dst_id] = raw_dst_lbl or nodes.get(dst_id, dst_id)
            edges.append((src_id, dst_id, edge_lbl))
            continue

        node_m = re.match(r"^([A-Za-z0-9_]+)(?:\[(.*?)\]|\((.*?)\)|\{(.*?)\})$", line)
        if node_m:
            n_id = node_m.group(1)
            n_lbl = node_m.group(2) or node_m.group(3) or node_m.group(4) or n_id
            nodes[n_id] = n_lbl

    if not nodes:
        nodes = {"Node1": "Input", "Node2": "Process", "Node3": "Output"}
        edges = [("Node1", "Node2", "feed"), ("Node2", "Node3", "publish")]

    node_list = list(nodes.keys())
    total_nodes = len(node_list)
    node_w = 140
    node_h = 50
    spacing = 60
    pad_x = 40
    pad_y = 60
    total_w = pad_x * 2 + total_nodes * node_w + max(0, total_nodes - 1) * spacing
    total_h = 200

    coords: Dict[str, Tuple[int, int]] = {}
    for idx, nid in enumerate(node_list):
        x = pad_x + idx * (node_w + spacing)
        y = pad_y
        coords[nid] = (x, y)

    diag_title = title or "System Architecture Diagram"
    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {total_w} {total_h}" width="100%" height="{total_h}" role="img" aria-label="{_esc(diag_title)}">',
        f'  <title>{_esc(diag_title)}</title>',
        '  <defs>',
        '    <linearGradient id="nodeGrad" x1="0%" y1="0%" x2="100%" y2="100%">',
        '      <stop offset="0%" stop-color="#2563EB"/>',
        '      <stop offset="100%" stop-color="#1D4ED8"/>',
        '    </linearGradient>',
        '    <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">',
        '      <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748B"/>',
        '    </marker>',
        '  </defs>',
        f'  <rect width="{total_w}" height="{total_h}" rx="12" fill="#F8FAFC" stroke="#E2E8F0" stroke-width="1"/>',
        f'  <text x="{pad_x}" y="32" font-family="system-ui, sans-serif" font-size="13" font-weight="600" fill="#475569">{_esc(diag_title)}</text>',
    ]

    for src_id, dst_id, edge_lbl in edges:
        if src_id in coords and dst_id in coords:
            sx, sy = coords[src_id]
            dx, dy = coords[dst_id]
            start_x = sx + node_w
            start_y = sy + node_h // 2
            end_x = dx
            end_y = dy + node_h // 2
            svg_parts.append(
                f'  <line x1="{start_x}" y1="{start_y}" x2="{end_x}" y2="{end_y}" stroke="#64748B" stroke-width="2" marker-end="url(#arrow)"/>'
            )
            if edge_lbl:
                mid_x = (start_x + end_x) // 2
                mid_y = start_y - 8
                svg_parts.append(
                    f'  <text x="{mid_x}" y="{mid_y}" text-anchor="middle" font-family="system-ui, sans-serif" font-size="10" fill="#64748B">{_esc(edge_lbl)}</text>'
                )

    for nid, (x, y) in coords.items():
        lbl = nodes.get(nid, nid)
        svg_parts.append('  <g class="diagram-node">')
        svg_parts.append(
            f'    <rect x="{x}" y="{y}" width="{node_w}" height="{node_h}" rx="8" fill="url(#nodeGrad)" stroke="#1E40AF" stroke-width="1.5"/>'
        )
        svg_parts.append(
            f'    <text x="{x + node_w // 2}" y="{y + node_h // 2 + 5}" text-anchor="middle" font-family="system-ui, sans-serif" font-size="12" font-weight="600" fill="#FFFFFF">{_esc(lbl)}</text>'
        )
        svg_parts.append('  </g>')

    svg_parts.append('</svg>')
    return "\n".join(svg_parts)


def audit_hard_prohibitions(doc: ArticleDocumentModel) -> HardProhibitionsReport:
    """
    Audits the document against the 5 hard visual prohibitions (A5c.3):
      1. Invented data or charts (reject chart if numbers cannot be sourced)
      2. Fake screenshots (must be real Playwright capture/annotated with software version/url, never AI-generated fake UI)
      3. Fake testimonials or people (only real, attributed quote with named speaker & source citation)
      4. Real companies' logos/trademarks without permission
      5. AI-generated text inside images that has not been checked via A4 claim verification
    """
    violations: List[Dict[str, Any]] = []

    protected_trademarks = (
        "google", "microsoft", "apple", "amazon", "meta", "openai",
        "anthropic", "stripe", "slack", "salesforce", "shopify",
    )

    for block in doc.blocks:
        b_id = block.block_id

        # 1. Chart Prohibition: Invented data / unsourced charts
        if block.block_type == "figure":
            fig: FigureBlock = block  # type: ignore
            if fig.kind == "chart":
                ds = (fig.data_source or "").strip().lower()
                if not ds or ds in ("none", "n/a", "placeholder", "synthetic", "invented", "unsourced"):
                    violations.append({
                        "rule": "invented_data_or_charts",
                        "block_id": b_id,
                        "details": "Chart figure lacks verifiable data_source. Invented or unsourced charts are strictly prohibited.",
                        "severity": "error",
                    })

            # 2. Screenshot Prohibition: Fake AI UI screenshots
            elif fig.kind == "screenshot":
                if fig.provenance and fig.provenance.source == "ai_generated":
                    violations.append({
                        "rule": "fake_screenshots",
                        "block_id": b_id,
                        "details": "AI-generated fake software screenshot is strictly prohibited. Screenshots must be real browser/device captures.",
                        "severity": "error",
                    })
                elif not fig.software_version and not fig.src.startswith("http") and not fig.src.startswith("/uploads/"):
                    violations.append({
                        "rule": "fake_screenshots",
                        "block_id": b_id,
                        "details": "Screenshot must specify software_version or demonstrable source context.",
                        "severity": "error",
                    })

            # 4. Unauthorized Logos / Trademarks
            text_desc = f"{fig.alt} {fig.caption} {fig.src}".lower()
            for brand in protected_trademarks:
                logo_token = f"{brand} logo"
                trademark_token = f"{brand} trademark"
                if logo_token in text_desc or trademark_token in text_desc:
                    allowed_sources = ("licensed", "customer_provided", "public_domain")
                    credit_lower = (fig.credit or "").lower()
                    has_permission = "permission" in credit_lower or "licensed" in credit_lower or "courtesy" in credit_lower
                    if fig.provenance.source not in allowed_sources and not has_permission:
                        violations.append({
                            "rule": "unauthorized_logos_or_trademarks",
                            "block_id": b_id,
                            "details": f"Use of '{brand}' logo/trademark without verified license or documented permission is prohibited.",
                            "severity": "error",
                        })
                        break

            # 5. AI-generated text inside images that hasn't been checked via A4 verification
            if fig.provenance and fig.provenance.source == "ai_generated":
                combined_text = f"{fig.alt} {fig.caption}".lower()
                has_quantitative_claim = bool(re.search(r"\b(\d+%\s*|\$\d+|\d+\s*million|\d+\s*billion|growth of \d+)\b", combined_text))
                has_text_in_image = "text:" in combined_text or "words:" in combined_text or "infographic" in combined_text or has_quantitative_claim
                if has_text_in_image:
                    verified_claims_on_block = [c for c in fig.claims if c.verified is True]
                    if not verified_claims_on_block:
                        violations.append({
                            "rule": "unverified_image_text",
                            "block_id": b_id,
                            "details": "AI-generated image contains baked-in factual/quantitative claims that have not been verified via A4 claims.",
                            "severity": "error",
                        })

        # 3. Testimonial / Quote Prohibition: Fake quotes or people
        elif block.block_type == "quote":
            q: QuoteBlock = block  # type: ignore
            spk = (q.speaker or "").strip()
            if not spk or spk.lower() in ("anonymous", "customer", "a user", "client", "someone", "user"):
                violations.append({
                    "rule": "fake_testimonials_or_people",
                    "block_id": b_id,
                    "details": "Quote lacks a real, named attributed speaker. Fake or anonymous testimonials are strictly prohibited.",
                    "severity": "error",
                })
            elif not block.sources and not block.claims:
                violations.append({
                    "rule": "fake_testimonials_or_people",
                    "block_id": b_id,
                    "details": f"Quote attributed to '{spk}' lacks verifiable source citation or claim reference.",
                    "severity": "error",
                })

    return HardProhibitionsReport(
        has_violations=len(violations) > 0,
        violations=violations,
    )


def analyze_visual_density(
    doc: ArticleDocumentModel,
    min_words: int = 300,
    max_words: int = 400,
) -> VisualDensityAnalysis:
    """
    Evaluates visual density against the ~1 visual per 300-400 words guideline (A5c.3).
    Ensures visuals earn their place without cluttering or starving the piece.
    """
    visual_count = sum(1 for b in doc.blocks if b.block_type in ("figure", "table"))
    doc._recompute_word_count()
    total_words = doc.total_word_count or 1

    if visual_count == 0:
        words_per_visual = float(total_words)
        if total_words >= max_words:
            density_status = "too_sparse"
            recommendation = (
                f"Document has {total_words} words but 0 visual elements. "
                f"Consider adding a structured table, flow diagram, or sourced chart every 300-400 words."
            )
        else:
            density_status = "acceptable"
            recommendation = "Brief content; visual density is acceptable."
    else:
        words_per_visual = round(total_words / visual_count, 1)
        if words_per_visual < min_words:
            density_status = "too_dense"
            recommendation = (
                f"Visual density is high ({words_per_visual:.0f} words/visual; target {min_words}-{max_words}). "
                f"Remove decorative filler to prevent visual clutter."
            )
        elif words_per_visual > max_words:
            density_status = "too_sparse"
            recommendation = (
                f"Visual density is low ({words_per_visual:.0f} words/visual; target {min_words}-{max_words}). "
                f"Consider adding justified visual components for complex sections."
            )
        else:
            density_status = "optimal"
            recommendation = (
                f"Visual density is optimal ({words_per_visual:.0f} words/visual within target {min_words}-{max_words} guideline)."
            )

    return VisualDensityAnalysis(
        total_words=total_words,
        visual_count=visual_count,
        words_per_visual=words_per_visual,
        target_min_words_per_visual=min_words,
        target_max_words_per_visual=max_words,
        density_status=density_status,
        recommendation=recommendation,
    )


def plan_visuals_for_article(
    doc: ArticleDocumentModel,
    config: Optional[VisualDecisionConfig] = None,
) -> VisualPlanReport:
    """
    Visual Decision Planner (A5c.3):
    Proposes visual components per section and MUST justify each by what it shows that text cannot.
    Enforces density guidelines (~1 visual per 300-400 words) and strict ban on decorative filler.
    Audits hard prohibitions: invented charts, fake screenshots, fake quotes, unauthorized logos, unverified image text.
    """
    cfg = config or VisualDecisionConfig()
    proposals: List[VisualProposal] = []
    diagrams_validated = 0

    current_section = "Introduction"
    has_hero_proposal = False

    if cfg.allow_ai_hero and not has_hero_proposal:
        hero_proposal = VisualProposal(
            section_title="Hero",
            situation=VisualSituation.CONCEPT_MOOD,
            preferred_component="hero_image",
            justification="Editorial hero asset establishes article context, tone, and editorial authority above the fold.",
            source_data_available=True,
            approved=True,
        )
        proposals.append(hero_proposal)
        has_hero_proposal = True

    for block in doc.blocks:
        bt = block.block_type

        if bt == "heading":
            h: HeadingBlock = block  # type: ignore
            current_section = h.text
            h_lower = h.text.lower()

            if any(k in h_lower for k in (" vs ", " versus ", "comparison", "compare", "matrix", "alternatives")):
                proposals.append(VisualProposal(
                    section_title=current_section,
                    situation=VisualSituation.COMPARE_ITEMS,
                    preferred_component="table",
                    justification="Tabular attribute matrix allows readers to evaluate multiple criteria side-by-side simultaneously, which sequential prose cannot cleanly convey.",
                    approved=True,
                ))

            elif any(k in h_lower for k in ("architecture", "pipeline", "workflow", "system design", "lifecycle", "hierarchy")):
                diag_source = (
                    "graph TD\n"
                    "  Client[Client Request] --> Gateway[API Gateway]\n"
                    "  Gateway --> Engine[Decision Engine]\n"
                    "  Engine --> Storage[(Database)]"
                )
                valid, err = validate_mermaid_syntax(diag_source)
                svg = render_mermaid_to_svg(diag_source, title=current_section) if valid else None
                diagrams_validated += 1
                proposals.append(VisualProposal(
                    section_title=current_section,
                    situation=VisualSituation.ARCHITECTURE_RELATIONSHIPS,
                    preferred_component="diagram",
                    justification="Spatial component hierarchy and dependency topology require a 2D graph that linear text obscures.",
                    diagram_format="mermaid",
                    diagram_source=diag_source,
                    diagram_svg=svg,
                    diagram_valid=valid,
                    diagram_error=err,
                    approved=valid,
                ))

            elif any(k in h_lower for k in ("benchmark", "latency", "metrics", "performance", "growth", "statistics")):
                proposals.append(VisualProposal(
                    section_title=current_section,
                    situation=VisualSituation.NUMBERS_OVER_TIME,
                    preferred_component="chart",
                    justification="Quantitative trend curve reveals relative scale and inflection points directly from underlying empirical data.",
                    source_data_available=True,
                    data_source="https://telemetry.example.com/data.json",
                    approved=True,
                ))

            elif any(k in h_lower for k in ("dashboard", "ui", "console", "install", "configuration", "settings")):
                proposals.append(VisualProposal(
                    section_title=current_section,
                    situation=VisualSituation.SOFTWARE_UI,
                    preferred_component="screenshot",
                    justification="Exact software interface rendering eliminates user ambiguity regarding button placement and navigation.",
                    approved=True,
                ))

        elif bt == "list":
            lb: ListBlock = block  # type: ignore
            if lb.ordered and len(lb.items) >= 3:
                has_branching = any("if " in item.lower() or "else" in item.lower() or "or " in item.lower() for item in lb.items)
                has_multi_actor = any("user" in item.lower() or "server" in item.lower() or "admin" in item.lower() for item in lb.items)

                if has_branching or has_multi_actor:
                    diag_src = "graph TD\n  Start[Step 1] --> Check{Branch?}\n  Check -->|Yes| OptionA[Path A]\n  Check -->|No| OptionB[Path B]"
                    v, e = validate_mermaid_syntax(diag_src)
                    diagrams_validated += 1
                    proposals.append(VisualProposal(
                        section_title=current_section,
                        situation=VisualSituation.SEQUENCE_STEPS,
                        preferred_component="flow_diagram",
                        justification="Branching decision logic and multi-actor handoffs create non-linear execution that requires a flowchart to prevent user error.",
                        has_branching=has_branching,
                        has_multi_actor=has_multi_actor,
                        diagram_format="mermaid",
                        diagram_source=diag_src,
                        diagram_svg=render_mermaid_to_svg(diag_src, title="Workflow Flowchart") if v else None,
                        diagram_valid=v,
                        diagram_error=e,
                        approved=v,
                    ))
                else:
                    proposals.append(VisualProposal(
                        section_title=current_section,
                        situation=VisualSituation.SEQUENCE_STEPS,
                        preferred_component="numbered_list",
                        justification="Linear sequence is best structured as an accessible numbered list without diagram clutter.",
                        approved=True,
                    ))

        elif bt == "quote":
            qb: QuoteBlock = block  # type: ignore
            proposals.append(VisualProposal(
                section_title=current_section,
                situation=VisualSituation.QUOTE_TESTIMONY,
                preferred_component="pull_quote",
                justification=f"Attributed pull quote from {qb.speaker} highlights primary source perspective that editorial text alone cannot vouch for.",
                approved=bool(qb.speaker.strip()),
            ))

    # Strict ban on decorative filler: Check all proposals
    for p in proposals:
        just_l = p.justification.strip().lower()
        if not just_l or p.is_decorative_filler or any(filler in just_l for filler in ("looks nice", "visual appeal", "breaks up text", "decorative")):
            p.approved = False
            p.rejection_reason = "Strict ban on decorative filler: visuals must earn their place by showing what text cannot."

    approved_count = sum(1 for p in proposals if p.approved)
    rejected_count = sum(1 for p in proposals if not p.approved)

    density = analyze_visual_density(doc, cfg.target_min_words_per_visual, cfg.target_max_words_per_visual)
    prohibitions = audit_hard_prohibitions(doc)

    report = VisualPlanReport(
        doc_id=doc.doc_id,
        proposals=proposals,
        approved_count=approved_count,
        rejected_count=rejected_count,
        density=density,
        prohibitions=prohibitions,
        diagrams_validated=diagrams_validated,
    )
    doc.visual_plan = report.model_dump()
    return report


def check_blueprint_compliance(
    doc: ArticleDocumentModel,
    blueprint: Optional[ArticleBlueprint] = None,
) -> ComplianceResult:
    """
    Checks document against its blueprint. All findings are warnings (not hard failures).
    Returns a ComplianceResult attached to the document.
    """
    bp = blueprint or BLUEPRINTS.get(doc.article_type) or BLUEPRINTS["how_to"]

    present_types: Set[BlockType] = {b.block_type for b in doc.blocks}
    required_met, required_missing = [], []
    warnings: List[str] = []

    for component in bp.required_components:
        if component.block_type in present_types:
            required_met.append(f"{component.block_type}: {component.description}")
        else:
            required_missing.append(f"{component.block_type}: {component.description}")
            hint = f" Hint: {component.lint_hint}" if component.lint_hint else ""
            warnings.append(f"[MISSING REQUIRED] {component.block_type} — {component.description}.{hint}")

    optional_present = [
        f"{c.block_type}: {c.description}"
        for c in bp.optional_components
        if c.block_type in present_types
    ]

    # Specific blueprint logic checks
    # How-To: Software screenshot requirement
    if bp.article_type == "how_to":
        text_corpus = (doc.title + " " + " ".join(doc.keywords)).lower()
        has_software_keywords = any(k in text_corpus for k in ("software", "app", "code", "install", "api", "cli", "dashboard", "tool", "python", "ui"))
        has_screenshot = any(
            b.block_type == "figure" and getattr(b, "kind", "") == "screenshot"
            for b in doc.blocks
        )
        if has_software_keywords and not has_screenshot:
            warnings.append("[SOFTWARE SCREENSHOT] Software is involved in this how-to guide; screenshots with software_version are required.")

    # Word count warnings
    doc._recompute_word_count()
    wc = doc.total_word_count
    if wc < bp.min_word_count:
        warnings.append(f"Word count {wc} is below the target minimum of {bp.min_word_count} for {bp.display_name}.")
    if wc > bp.max_word_count:
        warnings.append(f"Word count {wc} exceeds the target maximum of {bp.max_word_count} for {bp.display_name}.")

    # Figure requirements
    if bp.min_images > 0:
        actual_images = sum(1 for b in doc.blocks if b.block_type == "figure")
        if actual_images < bp.min_images:
            warnings.append(f"Blueprint requires {bp.min_images}+ figure(s); found {actual_images}.")

    # Table requirements
    if bp.min_tables > 0:
        actual_tables = sum(1 for b in doc.blocks if b.block_type == "table")
        if actual_tables < bp.min_tables:
            warnings.append(f"Blueprint requires {bp.min_tables}+ table(s); found {actual_tables}.")

    # Blueprint-specific notes
    for note in bp.notes:
        warnings.append(f"[BLUEPRINT NOTE] {note}")

    return ComplianceResult(
        blueprint_id=bp.blueprint_id,
        article_type=doc.article_type,
        required_met=required_met,
        required_missing=required_missing,
        optional_present=optional_present,
        warnings=warnings,
        word_count=wc,
        is_compliant=len(required_missing) == 0,
    )


def lint_article_model(
    doc: ArticleDocumentModel,
    blueprint: Optional[ArticleBlueprint] = None,
) -> LintReport:
    """
    Runs verification and lint on the typed model ONCE before rendering (A5c.1).
    Validates blueprint compliance, block-level semantics, figure provenance,
    table structures, quote attributions, and fact-checking contradictions.
    """
    compliance = check_blueprint_compliance(doc, blueprint=blueprint)
    warnings: List[str] = list(compliance.warnings)
    errors: List[str] = []
    block_lints: Dict[str, List[str]] = {}

    for block in doc.blocks:
        b_id = block.block_id
        b_warns: List[str] = list(block.lint_warnings)

        # Figures: alt, caption, provenance, chart data_source
        if block.block_type == "figure":
            fig: FigureBlock = block  # type: ignore
            if not fig.alt or fig.alt.strip().lower() in ("", "image", "photo", "pic", "screenshot", "diagram", "graphic"):
                b_warns.append("Alt text is missing or generic (must be descriptive for screen readers).")
            if not fig.caption or not fig.caption.strip():
                b_warns.append("Figure caption is missing.")
            if fig.kind == "chart" and not fig.data_source:
                b_warns.append("Chart figure must specify data_source linking to verifiable dataset.")
            if not fig.provenance or not fig.provenance.source:
                b_warns.append("Figure provenance is missing.")

        # Tables: caption, row count, square cells, volatile data date
        elif block.block_type == "table":
            tbl: TableBlock = block  # type: ignore
            if not tbl.caption or not tbl.caption.strip():
                b_warns.append("Table caption is missing.")
            if tbl.data_row_count < 2:
                b_warns.append("Table has fewer than 2 data rows.")
            expected_cols = len(tbl.headers)
            for r_idx, row in enumerate(tbl.rows, 1):
                if len(row) != expected_cols:
                    b_warns.append(f"Table row {r_idx} has {len(row)} cells, expected {expected_cols}.")
            is_pricing = any("price" in h.lower() or "$" in h or "cost" in h.lower() for h in tbl.headers)
            if is_pricing and not tbl.last_checked:
                b_warns.append("Pricing table should include 'last_checked' date.")

        # Quotes: attributed speaker, verifiable source
        elif block.block_type == "quote":
            q: QuoteBlock = block  # type: ignore
            if not q.speaker or not q.speaker.strip():
                b_warns.append("Quote is missing an attributed speaker.")
            if not block.sources and not block.claims:
                b_warns.append("Quote must have a verifiable source citation.")

        # Answer Blocks: practitioner length heuristic (40-60 words), question format
        elif block.block_type == "answer_block":
            ans: AnswerBlock = block  # type: ignore
            wc = ans.word_count
            if wc < 30:
                b_warns.append(f"Answer block is too brief ({wc} words, practitioner heuristic 40-60).")
            elif wc > 80:
                b_warns.append(f"Answer block is too verbose ({wc} words, practitioner heuristic 40-60).")
            if not ans.question.strip().endswith("?") and not any(ans.question.lower().startswith(w) for w in ["what", "how", "why", "when", "who", "which"]):
                b_warns.append("Answer block question should be phrased as an explicit question.")

        # Key Takeaways: 3-6 items
        elif block.block_type == "key_takeaways":
            kt: KeyTakeawaysBlock = block  # type: ignore
            if len(kt.items) < 2 or len(kt.items) > 7:
                b_warns.append(f"Key takeaways has {len(kt.items)} items (recommended 3-6).")

        # Code Block: language specified
        elif block.block_type == "code":
            cd: CodeBlock = block  # type: ignore
            if not cd.language or cd.language == "text":
                b_warns.append("Code block has unspecified language.")

        # Check for contradicted claims on this block
        for claim in block.claims:
            if claim.verified is False:
                b_warns.append(f"Contradicted claim on block: '{claim.claim_text}'")

        if b_warns:
            block_lints[b_id] = b_warns
            warnings.extend([f"[{block.block_type}:{b_id}] {w}" for w in b_warns])

    # Heading hierarchy check (no skipping levels like H2 -> H4)
    headings = [b for b in doc.blocks if b.block_type == "heading"]
    prev_level = 1
    for h in headings:
        lvl = getattr(h, "level", 2)
        if lvl > prev_level + 1:
            warnings.append(f"Heading hierarchy skips level (H{prev_level} to H{lvl}: '{getattr(h, 'text', '')}')")
        prev_level = lvl

    # Audit hard prohibitions (A5c.3)
    prohibitions = audit_hard_prohibitions(doc)
    for v in prohibitions.violations:
        errors.append(f"[HARD PROHIBITION] {v['rule']}: {v['details']}")

    # Analyze visual density (A5c.3)
    density = analyze_visual_density(doc)
    if density.density_status == "too_dense":
        warnings.append(
            f"[VISUAL DENSITY] High visual density ({density.words_per_visual:.0f} words/visual vs target 300-400). Ensure all visuals earn their place."
        )
    elif density.density_status == "too_sparse" and doc.total_word_count >= 600:
        warnings.append(
            f"[VISUAL DENSITY] Low visual density ({density.words_per_visual:.0f} words/visual vs target 300-400). Consider justified tables or diagrams."
        )

    report = LintReport(
        doc_id=doc.doc_id,
        blueprint_id=compliance.blueprint_id,
        article_type=doc.article_type,
        is_valid=len(errors) == 0,
        compliance=compliance,
        warnings=warnings,
        errors=errors,
        block_lints=block_lints,
        claim_summary=doc.fact_verification_summary or {},
        prohibitions=prohibitions.model_dump(),
        visual_density=density.model_dump(),
    )
    doc.lint_summary = report.model_dump()
    return report


def attach_verification_to_model(
    doc: ArticleDocumentModel,
    verified_claims: List[Dict[str, Any]],
    citations: Optional[List[Dict[str, Any]]] = None,
) -> ArticleDocumentModel:
    """
    Integrates A4 verification into the typed block model.
    Attaches claim refs and citations to the specific blocks they belong to.
    Contradicted claims add lint warnings on that block and mark verified=False.
    """
    supported_count = 0
    contradicted_count = 0
    unsubstantiated_count = 0

    for claim_data in (verified_claims or []):
        stmt = str(claim_data.get("statement") or "")
        verdict = str(claim_data.get("verdict", "")).lower()
        src_url = claim_data.get("source_url") or claim_data.get("url")
        if isinstance(src_url, (list, tuple)):
            src_url = str(src_url[0]).strip() if src_url else None
        elif isinstance(src_url, str):
            src_url = src_url.strip() or None
        elif src_url is not None:
            src_url = str(src_url).strip() or None

        confidence = float(claim_data.get("confidence", 1.0) or 1.0)
        correction = claim_data.get("correction")

        is_verified = (verdict == "supported")
        if verdict == "supported":
            supported_count += 1
        elif verdict == "contradicted":
            contradicted_count += 1
        else:
            unsubstantiated_count += 1

        claim_ref = ClaimRef(
            claim_text=stmt,
            source_url=src_url,
            verified=is_verified,
            confidence=confidence,
        )

        # Match to best block by substring or word overlap
        words_in_stmt = set(re.findall(r"\w+", stmt.lower()))
        best_block = None
        best_overlap = 0

        for block in doc.blocks:
            text = ""
            if hasattr(block, "text"):
                text = getattr(block, "text", "")
            elif hasattr(block, "direct_answer"):
                text = getattr(block, "direct_answer", "")
            elif hasattr(block, "items") and isinstance(block.items, list):
                text = " ".join(str(i) for i in block.items)

            if stmt.lower() in text.lower():
                best_block = block
                break

            block_words = set(re.findall(r"\w+", text.lower()))
            overlap = len(words_in_stmt & block_words)
            if overlap > best_overlap and overlap >= min(3, len(words_in_stmt)):
                best_overlap = overlap
                best_block = block

        if best_block:
            best_block.claims.append(claim_ref)
            if verdict == "contradicted":
                best_block.verified = False
                msg = f"[FACT-CHECK CONTRADICTED] Claim: '{stmt}'. Remedy: {correction or 'Remove or rephrase'}"
                best_block.lint_warnings.append(msg)
            elif verdict == "supported" and best_block.verified is not False:
                best_block.verified = True
            elif verdict == "unsubstantiated":
                best_block.lint_warnings.append(f"[FACT-CHECK UNSUBSTANTIATED] Claim: '{stmt}' could not be verified.")

    # Attach citations to block sources
    for cit in (citations or []):
        url = cit.get("url", "")
        title = cit.get("title") or cit.get("statement", "")
        if url:
            src_ref = SourceRef(url=url, title=title)
            attached = False
            for block in doc.blocks:
                for clm in block.claims:
                    if clm.source_url == url:
                        block.sources.append(src_ref)
                        attached = True
                        break
                if attached:
                    break
            if not attached and doc.blocks:
                ref_blocks = [b for b in doc.blocks if b.block_type == "references"]
                if ref_blocks:
                    ref_blocks[0].sources.append(src_ref)

    total = len(verified_claims or [])
    doc.fact_verification_summary = {
        "total_claims": total,
        "supported": supported_count,
        "contradicted": contradicted_count,
        "unsubstantiated": unsubstantiated_count,
        "score": int((supported_count / total) * 100) if total > 0 else 100,
        "all_supported": contradicted_count == 0 and unsubstantiated_count == 0,
    }
    return doc


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

class ArticleRenderers:
    """
    Renders an ArticleDocumentModel to multiple output formats (A5c.1).
    All renderers read from the same typed block model:
      - Semantic HTML
      - Markdown / MDX
      - WordPress Gutenberg Blocks (JSON and HTML comment format)
      - CMS-specific fields / payloads (Next.js, Ghost, Strapi, Generic)
    """

    # ---- Semantic HTML ----

    @staticmethod
    def to_html(
        doc: ArticleDocumentModel,
        *,
        include_schema: bool = False,
        responsive_pictures: bool = True,
        include_lcp_preload: bool = False,
    ) -> str:
        parts: List[str] = []
        lcp_preload_tag: Optional[str] = None
        seen_first_figure = False

        parts.append(f'<article data-doc-id="{doc.doc_id}" data-type="{doc.article_type}">')
        parts.append(f"<h1>{_esc(doc.title)}</h1>")

        for block in doc.blocks:
            is_lcp_figure = False
            if block.block_type == "figure" and not seen_first_figure:
                is_lcp_figure = True
                seen_first_figure = True
                fig: FigureBlock = block  # type: ignore
                src = fig.src
                filename = src.split("uploads/")[-1] if "uploads/" in src else src.split("/")[-1]
                stem = Path(filename).stem
                lcp_preload_tag = f'<link rel="preload" as="image" href="/uploads/{stem}.webp" type="image/webp" fetchpriority="high" />'

            parts.append(ArticleRenderers._block_to_html(block, is_lcp=is_lcp_figure, responsive_pictures=responsive_pictures))

        parts.append("</article>")

        if include_schema and doc.schema_markup:
            import json
            parts.append(
                f'<script type="application/ld+json">\n{json.dumps(doc.schema_markup, indent=2)}\n</script>'
            )

        if include_lcp_preload and lcp_preload_tag:
            return f"{lcp_preload_tag}\n" + "\n".join(p for p in parts if p)

        return "\n".join(p for p in parts if p)

    @staticmethod
    def _block_to_html(
        block: AnyBlock,
        *,
        is_lcp: bool = False,
        responsive_pictures: bool = True,
    ) -> str:
        bt = block.block_type

        if bt == "heading":
            b: HeadingBlock = block  # type: ignore
            return f"<h{b.level}>{_esc(b.text)}</h{b.level}>"

        elif bt == "paragraph":
            b: ParagraphBlock = block  # type: ignore
            return f"<p>{_md_inline(b.text)}</p>"

        elif bt == "answer_block":
            b: AnswerBlock = block  # type: ignore
            h = b.heading_level
            html_parts = [f"<section class='answer-block'><h{h}>{_esc(b.question)}</h{h}>"]
            if b.target_format in ("ordered_list", "unordered_list"):
                tag = "ol" if b.target_format == "ordered_list" else "ul"
                items = [l.strip() for l in b.direct_answer.splitlines() if l.strip()]
                items = [re.sub(r"^[\d]+\.\s*|^[•\-\*]\s*", "", i) for i in items]
                li = "\n".join(f"  <li>{_esc(i)}</li>" for i in items)
                html_parts.append(f"<{tag}>\n{li}\n</{tag}>")
            else:
                html_parts.append(f"<p class='direct-answer'>{_md_inline(b.direct_answer)}</p>")
            if b.depth_content:
                html_parts.append(f"<div class='answer-depth'>{_md_inline(b.depth_content)}</div>")
            if b.click_anchor:
                html_parts.append(f"<p class='click-anchor'><em>{_esc(b.click_anchor)}</em></p>")
            html_parts.append("</section>")
            return "\n".join(html_parts)

        elif bt == "key_takeaways":
            b: KeyTakeawaysBlock = block  # type: ignore
            items = "\n".join(f"  <li>{_esc(item)}</li>" for item in b.items)
            return f'<aside class="key-takeaways"><strong>Key Takeaways</strong><ul>\n{items}\n</ul></aside>'

        elif bt == "list":
            b: ListBlock = block  # type: ignore
            tag = "ol" if b.ordered else "ul"
            intro = f"<p>{_md_inline(b.intro)}</p>\n" if b.intro else ""
            items = "\n".join(f"  <li>{_md_inline(item)}</li>" for item in b.items)
            return f"{intro}<{tag}>\n{items}\n</{tag}>"

        elif bt == "table":
            b: TableBlock = block  # type: ignore
            cap = f"<caption>{_esc(b.caption)}"
            if b.last_checked:
                cap += f' <small>(Last checked: {_esc(b.last_checked)})</small>'
            cap += "</caption>"
            th_cells = "".join(f'<th scope="col">{_esc(h)}</th>' for h in b.headers)
            if b.row_headers:
                tbody_rows = []
                for row in b.rows:
                    cells = "".join(
                        [f'<th scope="row">{_esc(row[0])}</th>'] +
                        [f"<td>{_esc(c)}</td>" for c in row[1:]]
                    )
                    tbody_rows.append(f"  <tr>{cells}</tr>")
            else:
                tbody_rows = [
                    f"  <tr>{''.join(f'<td>{_esc(c)}</td>' for c in row)}</tr>"
                    for row in b.rows
                ]
            return (
                f"<table>\n{cap}\n"
                f"<thead><tr>{th_cells}</tr></thead>\n"
                f"<tbody>\n{'  '.join(tbody_rows)}\n</tbody>\n</table>"
            )

        elif bt == "figure":
            b: FigureBlock = block  # type: ignore
            credit_html = f'<small class="figure-credit">{_esc(b.credit)}</small>' if b.credit else ""
            src = b.src
            filename = src.split("uploads/")[-1] if "uploads/" in src else src.split("/")[-1]
            stem = Path(filename).stem
            safe_alt = _esc(b.alt)
            safe_caption = _esc(b.caption)

            # LCP eager loading vs below-the-fold lazy loading
            if is_lcp:
                loading_mode = 'loading="eager" fetchpriority="high" decoding="sync"'
            else:
                loading_mode = 'loading="lazy" decoding="async"'

            if responsive_pictures:
                img_markup = (
                    f'  <picture>\n'
                    f'    <source type="image/avif" srcset="/uploads/{stem}.avif 1200w, /uploads/{stem}-800.avif 800w" sizes="(max-width: 768px) 100vw, 1200px" />\n'
                    f'    <source type="image/webp" srcset="/uploads/{stem}.webp 1200w, /uploads/{stem}-800.webp 800w" sizes="(max-width: 768px) 100vw, 1200px" />\n'
                    f'    <img src="{_esc(b.src)}" alt="{safe_alt}" width="1200" height="675" {loading_mode} />\n'
                    f'  </picture>'
                )
            else:
                img_markup = f'  <img src="{_esc(b.src)}" alt="{safe_alt}" width="1200" height="675" {loading_mode} />'

            # Accessible details table for chart figures
            accessible_details = ""
            if b.kind == "chart" and b.data_source:
                accessible_details = (
                    f'\n  <details class="chart-accessible-fallback">\n'
                    f'    <summary>Accessible data source for: {safe_caption}</summary>\n'
                    f'    <p>Data verified and grounded at: <a href="{_esc(b.data_source)}" rel="noopener noreferrer">{_esc(b.data_source)}</a></p>\n'
                    f'  </details>'
                )

            return (
                f'<figure>\n'
                f'{img_markup}\n'
                f'  <figcaption>{safe_caption}{credit_html}</figcaption>{accessible_details}\n'
                f'</figure>'
            )


        elif bt == "callout":
            b: CalloutBlock = block  # type: ignore
            title_html = f"<strong>{_esc(b.title)}</strong><br>" if b.title else ""
            return f'<aside class="callout callout-{b.variant}">{title_html}{_md_inline(b.text)}</aside>'

        elif bt == "quote":
            b: QuoteBlock = block  # type: ignore
            cite_parts = [_esc(b.speaker)]
            if b.role:
                cite_parts.append(_esc(b.role))
            if b.organisation:
                cite_parts.append(_esc(b.organisation))
            return (
                f"<blockquote>\n"
                f"  <p>{_esc(b.text)}</p>\n"
                f"  <cite>{', '.join(cite_parts)}</cite>\n"
                f"</blockquote>"
            )

        elif bt == "code":
            b: CodeBlock = block  # type: ignore
            cap = f"<figcaption>{_esc(b.caption)}</figcaption>\n" if b.caption else ""
            code_lang = (b.language or "").lower()
            code_strip = (b.code or "").strip()
            if code_lang in ("mermaid", "d2", "graphviz") or code_strip.startswith(("graph ", "flowchart ", "sequenceDiagram", "classDiagram")):
                diag_title = b.caption or "Architectural Workflow Diagram"
                svg = render_mermaid_to_svg(b.code, title=diag_title)
                return f"<figure class='article-diagram my-8'>\n{cap}{svg}\n</figure>"
            return f"<figure class='code-block'>\n{cap}<pre><code class='language-{b.language}'>{_esc(b.code)}</code></pre>\n</figure>"

        elif bt == "faq":
            b: FAQBlock = block  # type: ignore
            items_html = "\n".join(
                f"  <details><summary>{_esc(item['question'])}</summary>"
                f"<p>{_md_inline(item.get('answer', ''))}</p></details>"
                for item in b.items
            )
            return f"<section class='faq'>\n<h2>Frequently Asked Questions</h2>\n{items_html}\n</section>"

        elif bt == "references":
            b: ReferencesBlock = block  # type: ignore
            items_html = "\n".join(
                f'  <li><a href="{_esc(r["url"])}" rel="noopener noreferrer">{_esc(r.get("title") or r["url"])}</a>'
                + (f' <small>(Accessed {_esc(r["accessed_at"])})</small>' if r.get("accessed_at") else "")
                + "</li>"
                for r in b.items
            )
            return f"<section class='references'>\n<h2>References</h2>\n<ol>\n{items_html}\n</ol>\n</section>"

        elif bt == "cta":
            b: CTABlock = block  # type: ignore
            return (
                f'<aside class="cta cta-{b.variant}">'
                f'<p>{_md_inline(b.text)}</p>'
                f'<a class="cta-button" href="{_esc(b.button_url)}">{_esc(b.button_label)}</a>'
                f'</aside>'
            )

        elif bt == "author_box":
            b: AuthorBoxBlock = block  # type: ignore
            avatar = f'<img src="{_esc(b.avatar_url)}" alt="{_esc(b.name)}" class="author-avatar" />' if b.avatar_url else ""
            links_html = " ".join(
                f'<a href="{_esc(lnk["url"])}" rel="noopener noreferrer">{_esc(lnk["label"])}</a>'
                for lnk in b.links
            )
            return (
                f'<aside class="author-box">{avatar}'
                f'<div><strong>{_esc(b.name)}</strong>'
                + (f'<span class="author-role">{_esc(b.role)}</span>' if b.role else "")
                + f'<p>{_md_inline(b.bio)}</p>{links_html}</div></aside>'
            )

        return f"<!-- unknown block type: {bt} -->"

    # ---- Markdown / MDX ----

    @staticmethod
    def to_markdown(doc: ArticleDocumentModel) -> str:
        parts: List[str] = [f"# {doc.title}\n"]

        for block in doc.blocks:
            parts.append(ArticleRenderers._block_to_markdown(block))

        return "\n\n".join(p for p in parts if p)

    @staticmethod
    def _block_to_markdown(block: AnyBlock) -> str:
        bt = block.block_type

        if bt == "heading":
            b: HeadingBlock = block  # type: ignore
            return f"{'#' * b.level} {b.text}"

        elif bt == "paragraph":
            b: ParagraphBlock = block  # type: ignore
            return b.text

        elif bt == "answer_block":
            b: AnswerBlock = block  # type: ignore
            h = "#" * b.heading_level
            md = f"{h} {b.question}\n\n{b.direct_answer}"
            if b.depth_content:
                md += f"\n\n{b.depth_content}"
            return md

        elif bt == "key_takeaways":
            b: KeyTakeawaysBlock = block  # type: ignore
            return f"> **Key Takeaways**\n>\n" + "\n".join(f"> - {item}" for item in b.items)

        elif bt == "list":
            b: ListBlock = block  # type: ignore
            prefix = "1." if b.ordered else "-"
            intro = f"{b.intro}\n\n" if b.intro else ""
            return intro + "\n".join(f"{prefix} {item}" for item in b.items)

        elif bt == "table":
            b: TableBlock = block  # type: ignore
            header_row = "| " + " | ".join(b.headers) + " |"
            sep = "| " + " | ".join(["---"] * len(b.headers)) + " |"
            data_rows = ["| " + " | ".join(row) + " |" for row in b.rows]
            caption = f"*{b.caption}*" + (f" *(Last checked: {b.last_checked})*" if b.last_checked else "")
            return caption + "\n\n" + "\n".join([header_row, sep] + data_rows)

        elif bt == "figure":
            b: FigureBlock = block  # type: ignore
            credit = f"\n*{b.credit}*" if b.credit else ""
            return f"![{b.alt}]({b.src})\n*{b.caption}*{credit}"

        elif bt == "callout":
            b: CalloutBlock = block  # type: ignore
            prefix = f"**{b.title}:** " if b.title else ""
            return f"> {prefix}{b.text}"

        elif bt == "quote":
            b: QuoteBlock = block  # type: ignore
            cite = b.speaker
            if b.role:
                cite += f", {b.role}"
            if b.organisation:
                cite += f", {b.organisation}"
            return f'> "{b.text}"\n>\n> — {cite}'

        elif bt == "code":
            b: CodeBlock = block  # type: ignore
            cap = f"*{b.caption}*\n\n" if b.caption else ""
            return f"{cap}```{b.language}\n{b.code}\n```"

        elif bt == "faq":
            b: FAQBlock = block  # type: ignore
            parts = ["## Frequently Asked Questions\n"]
            for item in b.items:
                parts.append(f"**{item['question']}**\n\n{item.get('answer', '')}")
            return "\n\n".join(parts)

        elif bt == "references":
            b: ReferencesBlock = block  # type: ignore
            items = "\n".join(
                f"{i}. [{r.get('title') or r['url']}]({r['url']})"
                + (f" (Accessed {r['accessed_at']})" if r.get("accessed_at") else "")
                for i, r in enumerate(b.items, 1)
            )
            return f"## References\n\n{items}"

        elif bt == "cta":
            b: CTABlock = block  # type: ignore
            return f"{b.text}\n\n[{b.button_label}]({b.button_url})"

        elif bt == "author_box":
            b: AuthorBoxBlock = block  # type: ignore
            return f"**{b.name}** — {b.bio}"

        return ""

    # ---- WordPress Gutenberg Blocks ----

    @staticmethod
    def to_wordpress_blocks(doc: ArticleDocumentModel) -> List[Dict[str, Any]]:
        """
        Emits Gutenberg block JSON objects for the WordPress REST API (wp/v2 blocks format).
        """
        blocks = []
        for block in doc.blocks:
            wp = ArticleRenderers._block_to_wp(block)
            if wp:
                blocks.append(wp)
        return blocks

    @staticmethod
    def to_wordpress_html(doc: ArticleDocumentModel) -> str:
        """
        Emits standard Gutenberg HTML comment delimiters for post_content persistence.
        """
        parts = []
        for block in doc.blocks:
            bt = block.block_type
            if bt == "heading":
                b: HeadingBlock = block  # type: ignore
                parts.append(f'<!-- wp:heading {{"level":{b.level}}} -->\n<h{b.level}>{_esc(b.text)}</h{b.level}>\n<!-- /wp:heading -->')
            elif bt == "paragraph":
                b: ParagraphBlock = block  # type: ignore
                parts.append(f'<!-- wp:paragraph -->\n<p>{_md_inline(b.text)}</p>\n<!-- /wp:paragraph -->')
            elif bt == "answer_block":
                b: AnswerBlock = block  # type: ignore
                h = b.heading_level
                parts.append(f'<!-- wp:heading {{"level":{h}}} -->\n<h{h}>{_esc(b.question)}</h{h}>\n<!-- /wp:heading -->')
                parts.append(f'<!-- wp:paragraph -->\n<p>{_md_inline(b.direct_answer)}</p>\n<!-- /wp:paragraph -->')
            elif bt == "table":
                parts.append(f'<!-- wp:table -->\n{ArticleRenderers._block_to_html(block)}\n<!-- /wp:table -->')
            elif bt == "figure":
                b: FigureBlock = block  # type: ignore
                parts.append(f'<!-- wp:image {{"url":"{_esc(b.src)}","alt":"{_esc(b.alt)}"}} -->\n<figure class="wp-block-image"><img src="{_esc(b.src)}" alt="{_esc(b.alt)}"/><figcaption>{_esc(b.caption)}</figcaption></figure>\n<!-- /wp:image -->')
            elif bt == "quote":
                b: QuoteBlock = block  # type: ignore
                parts.append(f'<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>{_esc(b.text)}</p><cite>{_esc(b.speaker)}</cite></blockquote>\n<!-- /wp:quote -->')
            elif bt == "list":
                b: ListBlock = block  # type: ignore
                tag = "ol" if b.ordered else "ul"
                items = "".join(f"<li>{_md_inline(i)}</li>" for i in b.items)
                parts.append(f'<!-- wp:list {{"ordered":{str(b.ordered).lower()}}} -->\n<{tag}>{items}</{tag}>\n<!-- /wp:list -->')
            elif bt == "code":
                b: CodeBlock = block  # type: ignore
                parts.append(f'<!-- wp:code -->\n<pre class="wp-block-code"><code class="language-{b.language}">{_esc(b.code)}</code></pre>\n<!-- /wp:code -->')
            else:
                parts.append(f'<!-- wp:html -->\n{ArticleRenderers._block_to_html(block)}\n<!-- /wp:html -->')
        return "\n\n".join(parts)

    @staticmethod
    def _block_to_wp(block: AnyBlock) -> Optional[Dict[str, Any]]:
        bt = block.block_type

        if bt == "heading":
            b: HeadingBlock = block  # type: ignore
            return {"blockName": "core/heading", "attrs": {"level": b.level}, "innerHTML": f"<h{b.level}>{_esc(b.text)}</h{b.level}>"}

        elif bt in ("paragraph", "answer_block"):
            html = ArticleRenderers._block_to_html(block)
            return {"blockName": "core/paragraph", "attrs": {}, "innerHTML": html}

        elif bt == "key_takeaways":
            b: KeyTakeawaysBlock = block  # type: ignore
            items = "".join(f"<li>{_esc(i)}</li>" for i in b.items)
            return {"blockName": "core/list", "attrs": {"ordered": False}, "innerHTML": f"<ul>{items}</ul>"}

        elif bt == "list":
            b: ListBlock = block  # type: ignore
            items = "".join(f"<li>{_esc(i)}</li>" for i in b.items)
            tag = "ol" if b.ordered else "ul"
            return {"blockName": "core/list", "attrs": {"ordered": b.ordered}, "innerHTML": f"<{tag}>{items}</{tag}>"}

        elif bt == "table":
            return {"blockName": "core/table", "attrs": {}, "innerHTML": ArticleRenderers._block_to_html(block)}

        elif bt == "figure":
            b: FigureBlock = block  # type: ignore
            return {"blockName": "core/image", "attrs": {"url": b.src, "alt": b.alt, "caption": b.caption}, "innerHTML": ""}

        elif bt == "code":
            b: CodeBlock = block  # type: ignore
            return {"blockName": "core/code", "attrs": {}, "innerHTML": f"<pre><code>{_esc(b.code)}</code></pre>"}

        elif bt == "quote":
            b: QuoteBlock = block  # type: ignore
            return {"blockName": "core/quote", "attrs": {}, "innerHTML": f"<blockquote><p>{_esc(b.text)}</p><cite>{_esc(b.speaker)}</cite></blockquote>"}

        elif bt in ("callout", "cta", "author_box", "faq", "references"):
            return {"blockName": "core/html", "attrs": {}, "innerHTML": ArticleRenderers._block_to_html(block)}

        return None

    # ---- CMS Specific Fields ----

    @staticmethod
    def to_cms_payload(doc: ArticleDocumentModel, cms_type: str = "nextjs") -> Dict[str, Any]:
        """
        Emits platform-tailored fields for publishing targets (A5c.1).
        Respects Next.js image URL path standard (/uploads/<filename>).
        """
        hero_url = None
        for b in doc.blocks:
            if b.block_type == "figure":
                hero_url = getattr(b, "src", None)
                break

        # Next.js image path standard enforcement
        if hero_url:
            if "uploads/" in hero_url:
                filename = hero_url.split("uploads/")[-1]
                hero_url = f"/uploads/{filename}"
            elif not hero_url.startswith("http") and not hero_url.startswith("/uploads/"):
                filename = hero_url.split("/")[-1]
                hero_url = f"/uploads/{filename}"

        if cms_type == "nextjs":
            return {
                "title": doc.title,
                "slug": doc.slug,
                "frontmatter": {
                    "title": doc.title,
                    "slug": doc.slug,
                    "excerpt": doc.meta_description or (doc.title + "..."),
                    "meta_title": doc.title,
                    "meta_description": doc.meta_description or "",
                    "hero_image_url": hero_url or "/uploads/default.webp",
                    "tags": doc.tags or doc.keywords,
                    "author": doc.author or "Editorial Bureau",
                    "publishedAt": doc.published_at or datetime.now(timezone.utc).isoformat(),
                    "article_type": doc.article_type,
                },
                "content": ArticleRenderers.to_markdown(doc),
                "html": ArticleRenderers.to_html(doc),
                "word_count": doc.total_word_count,
                "schema_markup": doc.schema_markup,
                "blueprint_compliance": doc.blueprint_compliance,
                "fact_verification_summary": doc.fact_verification_summary,
            }

        elif cms_type == "ghost":
            return {
                "title": doc.title,
                "slug": doc.slug,
                "html": ArticleRenderers.to_html(doc),
                "feature_image": hero_url,
                "custom_excerpt": doc.meta_description,
                "tags": doc.tags or doc.keywords,
                "status": "draft",
            }

        elif cms_type == "strapi":
            return {
                "data": {
                    "title": doc.title,
                    "slug": doc.slug,
                    "content": ArticleRenderers.to_markdown(doc),
                    "excerpt": doc.meta_description,
                    "publishedAt": doc.published_at,
                    "article_type": doc.article_type,
                }
            }

        # Generic Headless CMS / REST payload
        return {
            "doc_id": doc.doc_id,
            "title": doc.title,
            "slug": doc.slug,
            "article_type": doc.article_type,
            "html": ArticleRenderers.to_html(doc),
            "markdown": ArticleRenderers.to_markdown(doc),
            "blocks": [b.model_dump() for b in doc.blocks],
            "metadata": {
                "author": doc.author,
                "meta_description": doc.meta_description,
                "keywords": doc.keywords,
                "word_count": doc.total_word_count,
                "blueprint_id": doc.blueprint_id,
                "hero_image_url": hero_url,
            },
            "blueprint_compliance": doc.blueprint_compliance,
            "fact_verification_summary": doc.fact_verification_summary,
            "lint_summary": doc.lint_summary,
        }


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

_HTML_ESCAPE = str.maketrans({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#x27;"})


def _esc(text: Optional[str]) -> str:
    return (text or "").translate(_HTML_ESCAPE)


_INLINE_BOLD = re.compile(r"\*\*(.+?)\*\*")
_INLINE_ITALIC = re.compile(r"\*(.+?)\*")
_INLINE_CODE = re.compile(r"`(.+?)`")
_INLINE_LINK = re.compile(r"\[(.+?)\]\((.+?)\)")


def _md_inline(text: Optional[str]) -> str:
    t = (text or "").translate(_HTML_ESCAPE)
    t = _INLINE_LINK.sub(r'<a href="\2" rel="noopener noreferrer">\1</a>', t)
    t = _INLINE_BOLD.sub(r"<strong>\1</strong>", t)
    t = _INLINE_ITALIC.sub(r"<em>\1</em>", t)
    t = _INLINE_CODE.sub(r"<code>\1</code>", t)
    return t


# ---------------------------------------------------------------------------
# Markdown → Document Model parser (for existing drafts)
# ---------------------------------------------------------------------------

def parse_markdown_to_model(
    markdown: str,
    title: str,
    slug: str,
    article_type: ArticleType = "generic",
    author: Optional[str] = None,
    keywords: Optional[List[str]] = None,
) -> ArticleDocumentModel:
    """
    Parses a Markdown draft into a typed ArticleDocumentModel.
    Recognizes all 14 block types: headings, paragraphs, answer blocks,
    key takeaways, lists, tables, figures, callouts, quotes, code, faqs,
    references, ctas, and author boxes.
    """
    blocks: List[AnyBlock] = []
    lines = markdown.split("\n")
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        # 1. Heading
        hm = re.match(r"^(#{1,6})\s+(.+)", line)
        if hm:
            level = len(hm.group(1))
            text = hm.group(2).strip()

            # Skip H1 matching document title
            if level == 1 and text.lower() == title.lower():
                i += 1
                continue

            # Check if this heading is an Answer Block target (H2/H3 question)
            is_question = text.endswith("?") or any(
                text.lower().startswith(w) for w in ["what is", "what are", "how to", "how do", "why is", "why do"]
            )
            # Peek at next paragraph
            peek_idx = i + 1
            while peek_idx < len(lines) and not lines[peek_idx].strip():
                peek_idx += 1

            if is_question and peek_idx < len(lines):
                next_line = lines[peek_idx].strip()
                # Check if next block is a concise paragraph (30-90 words) without markdown block syntax
                if not next_line.startswith(("#", ">", "```", "|", "-", "*", "1.")):
                    para_lines = []
                    while peek_idx < len(lines) and lines[peek_idx].strip() and not re.match(r"^#{1,6}\s", lines[peek_idx]):
                        para_lines.append(lines[peek_idx].strip())
                        peek_idx += 1
                    ans_text = " ".join(para_lines)
                    ans_wc = len(ans_text.split())
                    if 15 <= ans_wc <= 120:
                        blocks.append(AnswerBlock(
                            question=text,
                            direct_answer=ans_text,
                            heading_level=level,
                        ))
                        i = peek_idx
                        continue

            # Check for FAQ section heading
            if re.match(r"^(frequently asked questions|faq)$", text, re.IGNORECASE):
                faq_items: List[Dict[str, str]] = []
                f_idx = i + 1
                curr_q = ""
                curr_a: List[str] = []
                while f_idx < len(lines) and not (lines[f_idx].startswith("## ") and not lines[f_idx].startswith("### ")):
                    f_line = lines[f_idx].strip()
                    qm = re.match(r"^(?:###\s+|\*\*)(.+?)(?:\*\*|\?)?\??$", f_line)
                    if (f_line.startswith("### ") or (f_line.startswith("**") and f_line.endswith("**"))) and ("?" in f_line or any(f_line.lower().startswith(w) for w in ("what", "how", "why", "can", "is", "should"))):
                        if curr_q:
                            faq_items.append({"question": curr_q, "answer": " ".join(curr_a).strip()})
                            curr_a = []
                        curr_q = re.sub(r"^[#\*\s]+|[#\*\s]+$", "", f_line)
                        if not curr_q.endswith("?"):
                            curr_q += "?"
                    elif curr_q and f_line:
                        curr_a.append(f_line)
                    f_idx += 1
                if curr_q:
                    faq_items.append({"question": curr_q, "answer": " ".join(curr_a).strip()})
                if faq_items:
                    blocks.append(FAQBlock(items=faq_items))
                    i = f_idx
                    continue

            # Check for References section heading
            if re.match(r"^(references|sources|citations)$", text, re.IGNORECASE):
                ref_items: List[Dict[str, str]] = []
                r_idx = i + 1
                while r_idx < len(lines) and not re.match(r"^#{1,3}\s", lines[r_idx]):
                    r_line = lines[r_idx].strip()
                    ref_m = re.search(r"\[(.+?)\]\((https?://[^\s\)]+)\)", r_line)
                    if ref_m:
                        ref_items.append({"title": ref_m.group(1), "url": ref_m.group(2)})
                    r_idx += 1
                if ref_items:
                    blocks.append(ReferencesBlock(items=ref_items))
                    i = r_idx
                    continue

            blocks.append(HeadingBlock(level=level, text=text))
            i += 1
            continue

        # 2. Figure / Image: ![alt](url)
        img_m = re.match(r"^!\[(.*?)\]\((.*?)\)", stripped)
        if img_m:
            alt = img_m.group(1).strip()
            src = img_m.group(2).strip()
            caption = alt
            credit = None
            i += 1
            # Check if next line is caption: *caption* (skipping empty lines)
            peek_cap = i
            while peek_cap < len(lines) and not lines[peek_cap].strip():
                peek_cap += 1
            if peek_cap < len(lines) and lines[peek_cap].strip().startswith("*") and lines[peek_cap].strip().endswith("*") and not lines[peek_cap].strip().startswith("**"):
                cap_raw = lines[peek_cap].strip().strip("* ")
                if cap_raw:
                    caption = cap_raw
                i = peek_cap + 1

            kind: FigureKind = "image"
            alt_l = alt.lower()
            if "diagram" in alt_l or "flowchart" in alt_l:
                kind = "diagram"
            elif "chart" in alt_l or "graph" in alt_l:
                kind = "chart"
            elif "screenshot" in alt_l or "screen" in alt_l or "ui" in alt_l:
                kind = "screenshot"

            blocks.append(FigureBlock(
                kind=kind,
                src=src,
                alt=alt or "Editorial figure",
                caption=caption or "Figure illustration",
                credit=credit,
                provenance=FigureProvenance(
                    source="ai_generated" if "/uploads/" in src else "stock",
                    generator="flux-1-schnell" if "/uploads/" in src else None,
                ),
            ))
            continue

        # 3. Code fence
        if stripped.startswith("```"):
            lang_match = re.match(r"```(\w*)", stripped)
            lang = lang_match.group(1) if lang_match else "text"
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1  # skip closing ```
            blocks.append(CodeBlock(language=lang or "text", code="\n".join(code_lines)))
            continue

        # 4. Table
        if "|" in line and i + 1 < len(lines) and re.match(r"^\s*\|[-:\s|]+\|\s*$", lines[i + 1]):
            header_cells = [c.strip() for c in line.strip().strip("|").split("|")]
            i += 2  # skip separator
            rows = []
            while i < len(lines) and "|" in lines[i]:
                row = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if row and any(row):
                    rows.append(row)
                i += 1
            caption = "Comparison Table" if any("vs" in h.lower() for h in header_cells) else "Data Summary"
            # Check if next line is caption: *caption* (skipping empty lines)
            peek_cap = i
            while peek_cap < len(lines) and not lines[peek_cap].strip():
                peek_cap += 1
            if peek_cap < len(lines) and lines[peek_cap].strip().startswith("*") and lines[peek_cap].strip().endswith("*") and not lines[peek_cap].strip().startswith("**"):
                caption = lines[peek_cap].strip().strip("* ")
                i = peek_cap + 1
            blocks.append(TableBlock(
                caption=caption,
                headers=header_cells,
                rows=rows,
            ))
            continue

        # 5. Blockquote (Key Takeaways, Callouts, or Quotes)
        if stripped.startswith(">"):
            bq_lines = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                bq_lines.append(lines[i].strip().lstrip(">").strip())
                i += 1
            bq_text = "\n".join(bq_lines).strip()

            # Key Takeaways
            if re.search(r"key takeaways", bq_text, re.IGNORECASE):
                items = [re.sub(r"^[\-\*\•\d\.]+\s*", "", l) for l in bq_lines if re.match(r"^[\-\*\•\d\.]", l)]
                if not items:
                    items = [l for l in bq_lines if l and "key takeaways" not in l.lower()]
                blocks.append(KeyTakeawaysBlock(items=items or ["Key takeaway overview"]))
                continue

            # Attributed Quote: > "..." \n > — Speaker, Role
            quote_match = re.search(r'["“](.+?)["”]\s*(?:\n+)?(?:—|–|--|-|[^\w\s])\s*([^,\n]+)(?:,\s*(.+))?', bq_text, re.DOTALL)
            if not quote_match and ('"' in bq_text or '“' in bq_text):
                quote_match = re.search(r'["“](.+?)["”].*?(?:—|–|--|-|[^\w\s])\s*([^,\n]+)(?:,\s*(.+))?', bq_text, re.DOTALL)
            if quote_match:
                q_text = quote_match.group(1).strip()
                speaker = quote_match.group(2).strip()
                role_org = quote_match.group(3).strip() if quote_match.group(3) else None
                blocks.append(QuoteBlock(
                    text=q_text,
                    speaker=speaker,
                    role=role_org,
                ))
                continue

            # Callouts (Tip, Warning, Note, Important, Caution)
            callout_m = re.match(r"^\*{0,2}(tip|warning|note|important|caution):?\*{0,2}\s*(.+)", bq_text, re.IGNORECASE | re.DOTALL)
            if callout_m:
                variant = callout_m.group(1).lower()
                c_text = callout_m.group(2).strip()
                blocks.append(CalloutBlock(
                    variant=variant if variant in ("tip", "warning", "note", "important", "caution") else "note",  # type: ignore
                    text=c_text,
                ))
                continue

            # Generic callout
            blocks.append(CalloutBlock(text=" ".join(bq_lines)))
            continue

        # 6. Unordered list
        if re.match(r"^\s*[\-\*\+]\s", line):
            items = []
            while i < len(lines) and re.match(r"^\s*[\-\*\+]\s", lines[i]):
                items.append(re.sub(r"^\s*[\-\*\+]\s+", "", lines[i]).strip())
                i += 1
            blocks.append(ListBlock(ordered=False, items=items))
            continue

        # 7. Ordered list
        if re.match(r"^\s*\d+\.\s", line):
            items = []
            while i < len(lines) and re.match(r"^\s*\d+\.\s", lines[i]):
                items.append(re.sub(r"^\s*\d+\.\s+", "", lines[i]).strip())
                i += 1
            blocks.append(ListBlock(ordered=True, items=items))
            continue

        # 8. Paragraph
        para_lines = []
        while i < len(lines) and lines[i].strip() and not re.match(r"^#{1,6}\s|^>|^\s*[\-\*\+]\s|^\s*\d+\.\s|^```|^\|", lines[i]):
            para_lines.append(lines[i].strip())
            i += 1
        text = " ".join(para_lines).strip()
        if text:
            # Check if this paragraph is a CTA button: [Button](url)
            btn_m = re.match(r"^\[([^\]]+)\]\((https?://[^\)]+)\)$", text)
            if btn_m:
                blocks.append(CTABlock(text="Get Started", button_label=btn_m.group(1), button_url=btn_m.group(2)))
            else:
                blocks.append(ParagraphBlock(text=text))

    doc = ArticleDocumentModel(
        article_type=article_type,
        title=title,
        slug=slug,
        author=author,
        keywords=keywords or [],
        blocks=blocks,
    )
    return doc

