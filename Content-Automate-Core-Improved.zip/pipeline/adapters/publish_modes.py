"""
pipeline/adapters/publish_modes.py

A5d.2: Three Publish Modes & Regulatory Governance Engine.

Modes (per site, in config):
1. Mode 1: Automated publish after approval (Default: ON)
   - Staging, media upload, scheduling, publishing, post-publish checks run unattended
     ONCE all quality gates pass and a human reviewer attestation exists.
2. Mode 2: Low-risk refresh autopilot (Default: OFF, opt-in)
   - Small updates to already-approved pages run unattended IF:
     * No new or changed factual claims, or every changed claim supported by 2+ sources;
     * No regulated/YMYL topics;
     * Edit size under a threshold (diff < 20%);
     * Previous version was human-approved;
     * Random sample audited by a human (e.g., 15%).
3. Mode 3: Unattended new-article autopilot (Default: OFF, Not Recommended)
   - Entire article lifecycle unattended ONLY WITH:
     * Explicit tenant opt-in;
     * Counsel sign-off with officer identity & date;
     * Topic allow-list strictly excluding regulated/YMYL topics;
     * Strict daily velocity caps (e.g. <= 3/day);
     * Transparent AI disclosure label settings;
     * Mandatory human audit scheduled within 24-48 hours with automatic unpublish on failure.

Regulatory & Compliance Guardrails:
- Google 1 Oct 2026 guidance mandates manual fact-checking & review before publishing
  (titles, metas, schema, and alt text included).
- Google September 2026 spam update targets scaled low-oversight content.
- EU AI Act Article 50 exemption requires human review with editorial responsibility.
- Marketing Rule: Do NOT market "fully hands-off" publishing. Market "hands-off mechanics, human-approved content".
"""

import hashlib
import json
import logging
import random
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Dict, Any, List, Optional, Tuple
from pydantic import BaseModel, Field

from storage.db import (
    get_publish_record_by_dedupe,
    get_publish_record_by_slug,
    count_daily_published_records,
    get_pending_mode3_audits,
    update_publish_record_status,
)

logger = logging.getLogger("pipeline.adapters.publish_modes")

# Regulatory & Search Engine Governance Standards
GOOGLE_OCT_2026_GUIDANCE = (
    "Google's 1 Oct 2026 search guidance calls manual fact-checking and human review before publishing "
    "critical (titles, metas, schema, and alt text included)."
)
GOOGLE_SEPT_2026_SPAM_UPDATE = (
    "Google's September 2026 spam update targets scaled low-oversight content. "
    "Unsupervised publishing exposes domains to systemic de-indexing and algorithmic penalties."
)
EU_AI_ACT_ART_50_EXEMPTION = (
    "Under EU AI Act Article 50, publication exemptions and safe-harbors require human review "
    "with documented editorial responsibility."
)
EDITORIAL_POSITIONING = (
    "Hands-off mechanics, human-approved content. Fully unattended publishing is not recommended."
)

REGULATED_YMYL_KEYWORDS = [
    "medical", "medicine", "health", "disease", "treatment", "cure", "drug", "pharma",
    "financial", "finance", "investment", "stocks", "crypto", "banking", "loan", "tax",
    "legal", "lawyer", "attorney", "litigation", "court", "compliance", "regulatory"
]


class PublishMode(str, Enum):
    MODE_1_AFTER_APPROVAL = "mode_1_after_approval"
    MODE_2_REFRESH_AUTOPILOT = "mode_2_refresh_autopilot"
    MODE_3_UNATTENDED_AUTOPILOT = "mode_3_unattended_autopilot"


class ReviewerAttestation(BaseModel):
    reviewer_name: str
    reviewer_email: Optional[str] = None
    role: str = "Human Editor"
    attestation_timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    sign_off_notes: Optional[str] = None
    checklist_confirmed: bool = True


class Mode2RefreshConfig(BaseModel):
    enabled: bool = False
    max_char_diff_pct: float = 20.0
    max_word_diff_pct: float = 25.0
    min_sources_per_claim: int = 2
    regulated_topics_blacklist: List[str] = Field(default_factory=lambda: list(REGULATED_YMYL_KEYWORDS))
    human_audit_sample_rate: float = 0.15  # 15% random sample


class Mode3AutopilotConfig(BaseModel):
    enabled: bool = False  # Default OFF. Not recommended.
    tenant_opt_in: bool = False
    counsel_sign_off: bool = False
    counsel_officer_name: Optional[str] = None
    counsel_sign_off_date: Optional[str] = None
    topic_allow_list: List[str] = Field(default_factory=list)
    daily_velocity_cap: int = 3
    ai_disclosure_label: bool = True
    audit_window_hours: int = 24  # 24 to 48 hours
    auto_unpublish_on_failure: bool = True


class SitePublishConfig(BaseModel):
    mode: PublishMode = PublishMode.MODE_1_AFTER_APPROVAL
    mode_2: Mode2RefreshConfig = Field(default_factory=Mode2RefreshConfig)
    mode_3: Mode3AutopilotConfig = Field(default_factory=Mode3AutopilotConfig)


class PublishEligibilityResult(BaseModel):
    is_eligible: bool
    mode: PublishMode
    can_proceed_unattended: bool
    blocking_reasons: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    requires_human_review: bool = True
    audit_sample_selected: bool = False
    audit_deadline_at: Optional[str] = None
    regulatory_notes: List[str] = Field(default_factory=list)


def compute_dedupe_key(website_id: Optional[str], slug: str, content: str, mode: str = "publish") -> str:
    """
    Computes a deterministic SHA-256 dedupe key for idempotency across all publishing operations.
    """
    normalized_content = "".join(content.split())
    raw = f"{website_id or 'default'}::{slug}::{hashlib.sha256(normalized_content.encode('utf-8')).hexdigest()}::{mode}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def compute_content_diff_pct(old_text: str, new_text: str) -> float:
    """
    Computes character-level edit distance ratio between old and new version.
    """
    if not old_text:
        return 100.0
    len_old = len(old_text)
    len_new = len(new_text)
    len_diff = abs(len_new - len_old)
    # Character difference ratio against original length
    return round((len_diff / max(len_old, 1)) * 100.0, 2)


def is_regulated_or_ymyl_topic(topic: str, keywords: Optional[List[str]] = None, blacklist: Optional[List[str]] = None) -> Tuple[bool, Optional[str]]:
    """
    Checks if a topic or keyword set touches regulated / YMYL domains.
    """
    words = (blacklist or REGULATED_YMYL_KEYWORDS)
    haystack = f"{topic or ''} {' '.join(keywords or [])}".lower()
    for word in words:
        if word in haystack:
            return True, word
    return False, None


def evaluate_publish_eligibility(
    article_title: str,
    slug: str,
    content: str,
    topic: str,
    keywords: Optional[List[str]] = None,
    quality_gates_passed: bool = True,
    quality_gate_blocking_count: int = 0,
    reviewer_attestation: Optional[ReviewerAttestation] = None,
    site_config: Optional[SitePublishConfig] = None,
    website_id: Optional[str] = None,
    verified_claims: Optional[List[Dict[str, Any]]] = None,
    previous_content: Optional[str] = None,
    is_refresh: bool = False,
) -> PublishEligibilityResult:
    """
    Evaluates article publication eligibility based on the per-site Publish Mode.
    Strictly enforces quality gates, reviewer attestation, diff caps, velocity limits,
    and regulatory guardrails.
    """
    cfg = site_config or SitePublishConfig()
    mode = cfg.mode

    blocking: List[str] = []
    warnings: List[str] = []
    reg_notes: List[str] = [
        GOOGLE_OCT_2026_GUIDANCE,
        GOOGLE_SEPT_2026_SPAM_UPDATE,
        EU_AI_ACT_ART_50_EXEMPTION,
        EDITORIAL_POSITIONING,
    ]

    # Pre-publish quality gates are always a hard baseline across all modes
    if not quality_gates_passed or quality_gate_blocking_count > 0:
        blocking.append(
            f"Pre-publish quality gates failed with {quality_gate_blocking_count} blocking issues. Remediation required."
        )

    # -------------------------------------------------------------------------
    # MODE 1: Automated publish after approval (Default)
    # -------------------------------------------------------------------------
    if mode == PublishMode.MODE_1_AFTER_APPROVAL:
        if not reviewer_attestation or not reviewer_attestation.reviewer_name:
            blocking.append("Mode 1 requires a verified human reviewer attestation before publishing dispatch.")
            return PublishEligibilityResult(
                is_eligible=False,
                mode=mode,
                can_proceed_unattended=False,
                blocking_reasons=blocking,
                warnings=warnings,
                requires_human_review=True,
                regulatory_notes=reg_notes,
            )

        is_eligible = len(blocking) == 0
        return PublishEligibilityResult(
            is_eligible=is_eligible,
            mode=mode,
            can_proceed_unattended=is_eligible,
            blocking_reasons=blocking,
            warnings=warnings,
            requires_human_review=False if is_eligible else True,
            regulatory_notes=reg_notes,
        )

    # -------------------------------------------------------------------------
    # MODE 2: Low-risk refresh autopilot (Opt-in)
    # -------------------------------------------------------------------------
    elif mode == PublishMode.MODE_2_REFRESH_AUTOPILOT:
        m2 = cfg.mode_2
        if not m2.enabled:
            blocking.append("Mode 2 (Refresh Autopilot) is disabled in site configuration.")

        if not is_refresh:
            blocking.append("Mode 2 applies only to existing, already-approved articles. New articles must use Mode 1.")

        # Check regulated / YMYL topics
        is_ymyl, matched_word = is_regulated_or_ymyl_topic(topic, keywords, m2.regulated_topics_blacklist)
        if is_ymyl:
            blocking.append(
                f"Mode 2 blocked: Topic touches regulated/YMYL domain ('{matched_word}'). Human review is mandatory."
            )

        # Check edit size diff cap
        if previous_content:
            diff_pct = compute_content_diff_pct(previous_content, content)
            if diff_pct > m2.max_char_diff_pct:
                blocking.append(
                    f"Mode 2 blocked: Content edit size ({diff_pct}%) exceeds the low-risk threshold ({m2.max_char_diff_pct}%)."
                )

        # Check factual claims: every changed claim supported by 2+ sources
        claims = verified_claims or []
        for c in claims:
            sources = c.get("sources") or c.get("source_urls") or []
            if len(sources) < m2.min_sources_per_claim:
                status = c.get("status", "unverified")
                if status != "supported":
                    blocking.append(
                        f"Mode 2 blocked: Claim '{c.get('claim', '')[:60]}...' requires at least {m2.min_sources_per_claim} verified sources (found {len(sources)})."
                    )

        # Random human audit sampling
        audit_selected = False
        if random.random() < m2.human_audit_sample_rate:
            audit_selected = True
            warnings.append(
                f"Audit Sampling: Article was randomly selected for post-refresh human quality audit ({int(m2.human_audit_sample_rate * 100)}% sample rate)."
            )

        is_eligible = len(blocking) == 0
        return PublishEligibilityResult(
            is_eligible=is_eligible,
            mode=mode,
            can_proceed_unattended=is_eligible and not audit_selected,
            blocking_reasons=blocking,
            warnings=warnings,
            requires_human_review=not is_eligible or audit_selected,
            audit_sample_selected=audit_selected,
            regulatory_notes=reg_notes,
        )

    # -------------------------------------------------------------------------
    # MODE 3: Unattended new-article autopilot (Off / Not Recommended)
    # -------------------------------------------------------------------------
    elif mode == PublishMode.MODE_3_UNATTENDED_AUTOPILOT:
        m3 = cfg.mode_3
        warnings.append("CAUTION: Mode 3 unattended autopilot is NOT recommended under Google Oct 2026 guidelines.")

        if not m3.enabled or not m3.tenant_opt_in:
            blocking.append("Mode 3 blocked: Explicit tenant opt-in is required.")

        if not m3.counsel_sign_off or not m3.counsel_officer_name:
            blocking.append("Mode 3 blocked: Documented legal counsel sign-off is mandatory for fully unattended publishing.")

        # Regulated / YMYL prohibition
        is_ymyl, matched_word = is_regulated_or_ymyl_topic(topic, keywords)
        if is_ymyl:
            blocking.append(
                f"Mode 3 blocked: Topic touches regulated/YMYL domain ('{matched_word}'). Unattended publishing strictly prohibited."
            )

        # Topic allow-list verification
        if m3.topic_allow_list:
            norm_topic = topic.lower()
            if not any(al.lower() in norm_topic for al in m3.topic_allow_list):
                blocking.append(
                    f"Mode 3 blocked: Topic '{topic}' is not on the approved non-regulated allow-list."
                )

        # Daily velocity cap check
        if website_id:
            daily_count = count_daily_published_records(website_id)
            if daily_count >= m3.daily_velocity_cap:
                blocking.append(
                    f"Mode 3 blocked: Daily velocity cap reached ({daily_count}/{m3.daily_velocity_cap} articles in 24h) to prevent spam pattern detection."
                )

        # AI disclosure label requirement
        if not m3.ai_disclosure_label:
            blocking.append("Mode 3 blocked: EU AI Act Art. 50 compliant AI-generated content disclosure label must be enabled.")

        # 24-48h audit countdown
        deadline = (datetime.now(timezone.utc) + timedelta(hours=m3.audit_window_hours)).isoformat()
        warnings.append(
            f"Mode 3 Countdown: Human audit must be completed by {deadline} ({m3.audit_window_hours}h). If audit fails or lapses, article will auto-unpublish."
        )

        is_eligible = len(blocking) == 0
        return PublishEligibilityResult(
            is_eligible=is_eligible,
            mode=mode,
            can_proceed_unattended=is_eligible,
            blocking_reasons=blocking,
            warnings=warnings,
            requires_human_review=False if is_eligible else True,
            audit_deadline_at=deadline if is_eligible else None,
            regulatory_notes=reg_notes,
        )

    return PublishEligibilityResult(
        is_eligible=False,
        mode=mode,
        can_proceed_unattended=False,
        blocking_reasons=["Unknown or unsupported publish mode."],
        regulatory_notes=reg_notes,
    )


def process_mode3_audit_timeouts() -> List[Dict[str, Any]]:
    """
    Checks Mode 3 publish records where the 24-48 hour audit window has expired without
    human approval. Automatically unpublishes articles to prevent low-oversight spam penalties.
    """
    pending = get_pending_mode3_audits()
    now_iso = datetime.now(timezone.utc).isoformat()
    actioned = []

    for rec in pending:
        deadline = rec.get("audit_deadline_at")
        if deadline and deadline < now_iso:
            dedupe_key = rec.get("dedupe_key")
            slug = rec.get("slug")
            logger.warning(
                f"Mode 3 audit timeout expired for post '{slug}'. Automatically unpublishing to comply with EU Art. 50 & Google Spam policies."
            )
            update_publish_record_status(
                dedupe_key=dedupe_key,
                status="unpublished",
                audit_status="auto_unpublished_timeout",
            )
            actioned.append({
                "dedupe_key": dedupe_key,
                "slug": slug,
                "action": "auto_unpublished",
                "reason": "Human audit window (24-48h) expired without editorial sign-off.",
            })

    return actioned
