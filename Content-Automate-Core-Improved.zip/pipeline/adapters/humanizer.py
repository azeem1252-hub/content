"""
Humanizer Skill Adapter for Content Pipeline Agent.

Loads and applies the Humanizer skill (.agents/skills/humanizer/SKILL.md) to eliminate
AI writing patterns from generated articles, drafts, and social distribution content.
Based on Wikipedia's "Signs of AI writing" guidelines.
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from config import BASE_DIR
from pipeline.llm_client import call_llm
from pipeline.utils import clean_article_content

logger = logging.getLogger("pipeline.adapters.humanizer")

# Default location for the humanizer skill file
HUMANIZER_SKILL_PATH = BASE_DIR / ".agents" / "skills" / "humanizer" / "SKILL.md"


def get_humanizer_skill_path() -> Path:
    """Returns the resolved path to the humanizer skill."""
    if HUMANIZER_SKILL_PATH.exists():
        return HUMANIZER_SKILL_PATH
    
    # Fallback to global config root if workspace copy is missing
    user_home = Path.home()
    global_path = user_home / ".gemini" / "config" / "skills" / "humanizer" / "SKILL.md"
    if global_path.exists():
        return global_path
        
    return HUMANIZER_SKILL_PATH


def load_humanizer_skill() -> str:
    """
    Dynamically loads the humanizer skill instructions from disk.
    Allows real-time customization if the user updates SKILL.md.
    """
    path = get_humanizer_skill_path()
    if path.exists():
        try:
            content = path.read_text(encoding="utf-8")
            logger.info(f"Loaded humanizer skill from: {path} ({len(content)} chars)")
            return content
        except Exception as e:
            logger.warning(f"Failed to read humanizer skill at {path}: {e}")
    else:
        logger.warning(f"Humanizer skill file not found at {path}")
    
    return ""


# High-frequency AI words identified in §12 of the Humanizer skill
OVERUSED_AI_WORDS = [
    "delve", "delves", "delving",
    "testament", "tapestry",
    "pivotal", "paramount",
    "beacon", "fostering",
    "interplay", "intricate",
    "bolstered", "garner",
    "quietly", "robust",
    "showcase", "showcases",
    "underscore", "underscores",
    "revolutionize", "game-changer",
    "landscape", "deep dive"
]

# Patterns for staging, fake contrasts, and empty openers
STAGING_PATTERNS = [
    (r"(?i)\bnot\s+(?:only|just|merely)\s+[^,\.\n]+,\s*but\s+", "Not-X-but-Y contrast (§1)"),
    (r"(?i)\bit'?s\s+not\s+[^,\.\n]+,\s*it'?s\s+", "Not-X-but-Y contrast (§1)"),
    (r"(?i)\blet'?s\s+(?:dive\s+in|explore|break\s+this\s+down)\b", "Staged opener (§4)"),
    (r"(?i)\bhere'?s\s+what\s+you\s+need\s+to\s+know\b", "Staged opener (§4)"),
    (r"(?i)\bhere'?s\s+the\s+thing\b", "Staged candor (§4)"),
    (r"(?i)\bhonestly\?|real\s+talk\b", "Staged candor (§4)"),
    (r"(?i)\bthat\s+is\s+the\s+real\s+win\.?\b", "One-line dramatic closer (§2)"),
    (r"(?i)\bread\s+that\s+again\.?\b", "One-line dramatic closer (§2)"),
    (r"(?i)\blet\s+that\s+sink\s+in\.?\b", "One-line dramatic closer (§2)"),
    (r"(?i)\bat\s+its\s+core\b", "Saying that sounds deep (§3)"),
    (r"(?i)\bwhat\s+really\s+matters\b", "Saying that sounds deep (§3)"),
    (r"(?i)\bstands\s+as\s+a\s+testament\b", "Inflated significance (§13)"),
    (r"(?i)\bmarking\s+a\s+pivotal\s+moment\b", "Inflated significance (§13)"),
    (r"(?i)\bevolving\s+landscape\b", "Inflated significance (§13)"),
    (r"(?i)\bi\s+hope\s+this\s+helps!?", "Chatbot residue (§22)"),
    (r"(?i)\bcertainly!|of\s+course!|great\s+question!", "Chatbot residue (§22)")
]


def detect_ai_tells(text: str) -> List[Dict[str, Any]]:
    """
    Audits a piece of text against the Humanizer skill rules.
    Returns a list of detected AI tells and their locations.
    """
    if not text:
        return []

    tells = []

    # 1. Em-dashes and en-dashes (§8)
    # Check outside code blocks
    lines = text.split("\n")
    in_code_block = False
    for i, line in enumerate(lines):
        if line.strip().startswith("```"):
            in_code_block = not in_code_block
            continue
        if in_code_block:
            continue

        if "—" in line or "–" in line or " -- " in line:
            tells.append({
                "rule": "§8 Em/En-dashes",
                "line": i + 1,
                "snippet": line.strip()[:80],
                "description": "Em-dash or en-dash connector used in prose"
            })

    # 2. Check for staging patterns (§1, §2, §3, §4, §13, §22)
    for pattern, name in STAGING_PATTERNS:
        matches = list(re.finditer(pattern, text))
        for m in matches:
            tells.append({
                "rule": name,
                "matched": m.group(0),
                "position": m.start(),
                "description": f"Found AI pattern: '{m.group(0)}'"
            })

    # 3. Check for overused AI vocabulary (§12)
    for word in OVERUSED_AI_WORDS:
        regex = r"(?i)\b" + re.escape(word) + r"\b"
        matches = list(re.finditer(regex, text))
        if matches:
            tells.append({
                "rule": "§12 Overused AI words",
                "word": word,
                "count": len(matches),
                "description": f"Overused AI vocabulary: '{word}' ({len(matches)} occurrences)"
            })

    return tells


def clean_deterministic_tells(text: str) -> str:
    """
    Deterministically cleans mechanical AI writing tells:
    - Normalizes em-dashes (—) and en-dashes (–) to commas, periods, or clean hyphens outside code blocks (§8).
    - Normalizes curly quotes to straight quotes (§21).
    - Strips chatbot greetings and sign-offs (§22).
    - Eliminates decorative empty openers (§4).
    """
    if not text:
        return ""

    # Process line-by-line to protect code fences
    lines = text.split("\n")
    processed_lines = []
    in_code_block = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            processed_lines.append(line)
            continue

        if in_code_block:
            processed_lines.append(line)
            continue

        # Chatbot residue (§22)
        if re.match(r"(?i)^(?:i hope this helps|of course!|certainly!|great question!|let me know if you need).*$", stripped):
            continue

        # Staged run-up openers (§4) on their own line
        if re.match(r"(?i)^(?:let's dive in|here's what you need to know|without further ado)[\.!\:]?$", stripped):
            continue

        cleaned_line = line

        # §21: Curly quotes to straight quotes
        cleaned_line = cleaned_line.replace("“", '"').replace("”", '"')
        cleaned_line = cleaned_line.replace("‘", "'").replace("’", "'")

        # §8: Em-dashes and en-dashes outside code
        # Pattern 1: Word — word -> Word, word or Word - word
        cleaned_line = re.sub(r"\s*[—–]\s*", ", ", cleaned_line)
        cleaned_line = re.sub(r"\s+--\s+", ", ", cleaned_line)
        # Avoid duplicate commas or trailing comma before period
        cleaned_line = re.sub(r",\s*,+", ", ", cleaned_line)
        cleaned_line = re.sub(r",\s*\.", ".", cleaned_line)

        processed_lines.append(cleaned_line)

    result = "\n".join(processed_lines)
    return result.strip()


def _rewrite_is_plausible(original: str, rewritten: str) -> bool:
    """True when a humanizer rewrite is a usable article rather than a truncated,
    summarised, or gutted LLM response. Guards the article's bulk and structure."""
    if not rewritten or not rewritten.strip():
        return False
    orig_body = clean_article_content(original or "")
    new_body = rewritten.strip()
    if len(new_body.split()) < max(1, len(orig_body.split())) * 0.6:
        return False
    if orig_body.count("# ") >= 1 and new_body.count("# ") < 1:
        return False
    if orig_body.count("##") >= 2 and new_body.count("##") < 1:
        return False
    if orig_body.count("```") >= 2 and new_body.count("```") < 2:
        return False
    return True


def humanize_article_with_llm(draft: str, topic: str = "", voice_sample: Optional[str] = None) -> str:
    """
    Executes a refinement humanizing pass on article prose using the Humanizer skill rules.
    Runs in 'Embedded mode': returns only the final polished Markdown article without commentary.
    A rewrite that fails validation (too short, or missing the article's headings or
    code fences) is discarded in favor of the original draft.
    """
    skill_content = load_humanizer_skill()
    if not skill_content:
        logger.warning("No humanizer skill available for LLM humanization pass.")
        return clean_deterministic_tells(draft)

    system_instruction = (
        "You are an expert human prose editor. Your task is to apply the Humanizer skill to rewrite "
        "AI-sounding draft text into natural, authentic human prose written by an experienced practitioner. "
        "Strictly adhere to the Humanizer rules: eliminate not-X-but-Y formulas, one-line closers, "
        "staged openers, forced triads, em-dashes, overused AI vocabulary, and decorative bold labels. "
        "Keep ALL facts, technical claims, code blocks, and source URLs unchanged. "
        "Output ONLY the revised Markdown article. Do not include chat preamble or commentary."
    )

    prompt = f"""Apply the Humanizer skill to rewrite and humanize the following article draft.

=== HUMANIZER SKILL INSTRUCTIONS ===
{skill_content}
=== END SKILL INSTRUCTIONS ===

=== DRAFT ARTICLE TO HUMANIZE ===
{draft}
=== END DRAFT ARTICLE ===

INSTRUCTIONS:
1. Act on the tells listed in the Humanizer skill (§1-§25).
2. Remove all em-dashes (—), not-X-but-Y contrasts, one-line dramatic fragments, and staged openers.
3. Replace overused AI words ('delve', 'testament', 'tapestry', 'pivotal', 'fostering', 'landscape') with concrete, natural wording.
4. Keep all technical substance, code blocks, Markdown headers, and link URLs intact.
5. Return ONLY the final humanized Markdown article.
"""

    logger.info(f"Running LLM Humanizer pass on article draft ({len(draft)} chars)")
    try:
        raw_result = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.4)
        cleaned = clean_article_content(raw_result)
        if not _rewrite_is_plausible(draft, cleaned):
            logger.warning(
                "Humanizer rewrite failed validation (truncated or structural loss); keeping the original draft."
            )
            return clean_deterministic_tells(draft)
        final_text = clean_deterministic_tells(cleaned)
        return final_text
    except Exception as e:
        logger.error(f"LLM Humanizer pass failed: {e}. Falling back to deterministic cleaning.")
        return clean_deterministic_tells(draft)
