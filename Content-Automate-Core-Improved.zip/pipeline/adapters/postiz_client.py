"""
Headless Postiz Client (Pillar V: Omnichannel Syndication).

Connects to self-hosted Postiz (gitroomhq/postiz-app) REST API to schedule
and dispatch multi-modal content (MP4 videos, carousels, and copy) across 30+ social platforms:
- YouTube Shorts
- TikTok
- Instagram Reels
- X (Twitter)
- LinkedIn
- Threads
- Reddit
- Pinterest
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
import httpx

import config

logger = logging.getLogger("pipeline.adapters.postiz")


def schedule_postiz_publication(
    title: str,
    copy_by_platform: Dict[str, str],
    media_urls: Optional[List[str]] = None,
    platforms: Optional[List[str]] = None,
    scheduled_at: Optional[str] = None
) -> Dict[str, Any]:
    """
    Submits structured omnichannel payloads to a self-hosted Postiz instance.
    If Postiz is not configured, safely stages the payloads for offline execution.
    """
    postiz_url = (os.getenv("POSTIZ_API_URL", "").strip() or getattr(config, "POSTIZ_API_URL", "")).rstrip("/")
    postiz_key = os.getenv("POSTIZ_API_KEY", "").strip() or getattr(config, "POSTIZ_API_KEY", "")

    target_platforms = platforms or ["twitter", "linkedin", "tiktok", "youtube"]
    clean_media = [m for m in (media_urls or []) if m]

    if not postiz_url or not postiz_key:
        logger.info("POSTIZ_API_URL or POSTIZ_API_KEY not set. Omnichannel payload staged locally.")
        return {
            "status": "staged_locally",
            "platforms": target_platforms,
            "media_urls": clean_media,
            "copy_by_platform": copy_by_platform,
            "message": "Postiz client staged social payloads locally."
        }

    endpoint = f"{postiz_url}/api/v1/posts"
    headers = {
        "Authorization": f"Bearer {postiz_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "title": title,
        "platforms": target_platforms,
        "content": copy_by_platform,
        "media": clean_media,
        "scheduledAt": scheduled_at
    }

    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(endpoint, json=payload, headers=headers)
            if resp.status_code in (200, 201):
                logger.info(f"Postiz successfully scheduled publication across {len(target_platforms)} channels.")
                return {
                    "status": "success",
                    "platforms": target_platforms,
                    "postiz_response": resp.json()
                }
            else:
                logger.warning(f"Postiz API returned status {resp.status_code}: {resp.text[:200]}")
                return {
                    "status": "warning",
                    "status_code": resp.status_code,
                    "error": resp.text[:200]
                }
    except Exception as e:
        logger.error(f"Postiz HTTP request failed: {e}")
        return {"status": "error", "error": str(e)}
