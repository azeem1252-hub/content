"""
Dense Embedding Client & Vector Store Bridge (Pillar: Knowledge Graph / GraphRAG).

Provides real dense vector embeddings for semantic retrieval, anti-cannibalization
matching, verification faithfulness scoring, and knowledge-graph entity linking.

Provider order (configurable via EMBEDDING_PROVIDER):
  1. Mistral     `mistral-embed` (1024d)              (MISTRAL_API_KEY / EMBEDDING_API_KEY)
  2. OpenAI      `text-embedding-3-small` (1536d)     (OPENAI_API_KEY / EMBEDDING_API_KEY)
  3. Custom      OpenAI-compatible /embeddings        (EMBEDDING_BASE_URL)
  4. Local       deterministic hashed n-gram (256d)   (100% free, offline, always available)
  5. Google      `text-embedding-004`                 (optional, demoted due to 404s on free tiers)

The local provider is a 100% free offline dense vector produced via feature hashing,
so cosine similarity stays meaningful without network access, API keys, or dependencies.
"""

from __future__ import annotations

import hashlib
import logging
import math
import os
import sys
import re
from typing import Any, Dict, List, Optional

import httpx

import config

logger = logging.getLogger("pipeline.adapters.embedding")

LOCAL_DIM = 256
LOCAL_MODEL = "local-hashed-ngram-256"
_MISTRAL_DEFAULT_MODEL = "mistral-embed"
_OPENAI_DEFAULT_MODEL = "text-embedding-3-small"
_GEMINI_DEFAULT_MODEL = "text-embedding-004"

_TOKEN_RE = re.compile(r"[a-z0-9]+")


# ---------------------------------------------------------------------------
# Math helpers (pure Python — no numpy dependency)
# ---------------------------------------------------------------------------

def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """Cosine similarity between two dense vectors in [-1, 1] (0.0 when degenerate)."""
    if not vec_a or not vec_b:
        return 0.0
    n = min(len(vec_a), len(vec_b))
    dot = 0.0
    norm_a = 0.0
    norm_b = 0.0
    for i in range(n):
        a = float(vec_a[i])
        b = float(vec_b[i])
        dot += a * b
        norm_a += a * a
        norm_b += b * b
    if norm_a <= 0.0 or norm_b <= 0.0:
        return 0.0
    return dot / (math.sqrt(norm_a) * math.sqrt(norm_b))


def l2_normalize(vec: List[float]) -> List[float]:
    """Returns the L2-normalized vector (identity when the norm is zero)."""
    norm = math.sqrt(sum(float(x) * float(x) for x in vec))
    if norm <= 0.0:
        return list(vec)
    return [float(x) / norm for x in vec]


# ---------------------------------------------------------------------------
# Local hashed n-gram embedding (offline, deterministic)
# ---------------------------------------------------------------------------

def local_embed_text(text: str, dim: int = LOCAL_DIM) -> List[float]:
    """Feature-hashed bag-of-ngrams embedding.

    Tokens plus character 3-grams are hashed into `dim` buckets with sub-linear
    term weighting, producing a dense unit vector that behaves like a hashed
    TF-IDF: documents sharing vocabulary land close together in cosine space.
    """
    vec = [0.0] * dim
    if not text:
        return vec

    lowered = text.lower()
    tokens = _TOKEN_RE.findall(lowered)
    counts: Dict[int, float] = {}

    def add(feature: str, weight: float) -> None:
        h = int(hashlib.sha1(feature.encode("utf-8")).hexdigest()[:8], 16)
        counts[h % dim] = counts.get(h % dim, 0.0) + weight

    for tok in tokens:
        add(f"t:{tok}", 1.0)
    for a, b in zip(tokens, tokens[1:]):
        add(f"b:{a}_{b}", 1.5)

    compact = re.sub(r"\s+", " ", lowered)
    for i in range(len(compact) - 2):
        add(f"c:{compact[i:i + 3]}", 0.35)

    for bucket, weight in counts.items():
        vec[bucket] = 1.0 + math.log(weight) if weight > 1.0 else weight
    return l2_normalize(vec)


# ---------------------------------------------------------------------------
# Provider resolution
# ---------------------------------------------------------------------------

def _mistral_key() -> str:
    return (
        getattr(config, "EMBEDDING_API_KEY", "")
        or os.getenv("EMBEDDING_API_KEY", "").strip()
        or getattr(config, "MISTRAL_API_KEY", "")
        or os.getenv("MISTRAL_API_KEY", "").strip()
    )


def _openai_key() -> str:
    return (
        getattr(config, "EMBEDDING_API_KEY", "")
        or os.getenv("EMBEDDING_API_KEY", "").strip()
        or getattr(config, "OPENAI_API_KEY", "")
        or os.getenv("OPENAI_API_KEY", "").strip()
    )


def _gemini_key() -> str:
    return (
        getattr(config, "EMBEDDING_API_KEY", "")
        or os.getenv("EMBEDDING_API_KEY", "").strip()
        or getattr(config, "GEMINI_API_KEY", "")
        or os.getenv("GEMINI_API_KEY", "").strip()
    )


def _custom_base_url() -> str:
    return (
        getattr(config, "EMBEDDING_BASE_URL", "")
        or os.getenv("EMBEDDING_BASE_URL", "").strip()
    ).rstrip("/")


def _is_testing_offline() -> bool:
    if os.environ.get("PYTEST_ALLOW_LIVE_EMBEDDINGS"):
        return False
    return "pytest" in sys.modules or "PYTEST_CURRENT_TEST" in os.environ or "unittest" in sys.modules


def resolve_provider() -> str:
    """Resolves the embedding provider to use for this process."""
    requested = (getattr(config, "EMBEDDING_PROVIDER", "") or os.getenv("EMBEDDING_PROVIDER", "") or "auto").strip().lower()
    available = {
        "mistral": bool(_mistral_key()),
        "openai": bool(_openai_key()),
        "custom": bool(_custom_base_url()),
        "local": True,
        "gemini": bool(_gemini_key()),
    }
    if requested in available and requested != "auto":
        return requested
    # Default priority: Mistral (1024d) -> OpenAI -> Custom -> Free local hashed n-gram (256d)
    for candidate in ("mistral", "openai", "custom", "local"):
        if available.get(candidate):
            return candidate
    return "local"


def get_model_name(provider: Optional[str] = None) -> str:
    """Returns the active embedding model."""
    provider = provider or resolve_provider()
    explicit = (getattr(config, "EMBEDDING_MODEL", "") or os.getenv("EMBEDDING_MODEL", "")).strip()
    if provider == "mistral":
        return explicit or _MISTRAL_DEFAULT_MODEL
    if provider == "openai":
        return explicit or _OPENAI_DEFAULT_MODEL
    if provider == "gemini":
        return explicit or _GEMINI_DEFAULT_MODEL
    if provider == "custom":
        return explicit or "custom-embedding"
    return LOCAL_MODEL


# ---------------------------------------------------------------------------
# Provider calls
# ---------------------------------------------------------------------------

def _embed_mistral(texts: List[str]) -> Optional[List[List[float]]]:
    if _is_testing_offline():
        return None
    key = _mistral_key()
    if not key:
        return None
    model = get_model_name("mistral")
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                "https://api.mistral.ai/v1/embeddings",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": model, "input": texts},
            )
            if resp.status_code != 200:
                logger.warning(f"Mistral embeddings HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            data = resp.json().get("data", [])
            data.sort(key=lambda d: d.get("index", 0))
            vectors = [d.get("embedding") for d in data]
            if len(vectors) != len(texts) or any(v is None for v in vectors):
                return None
            return [list(map(float, v)) for v in vectors]
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Mistral embeddings request failed: {e}")
        return None


def _embed_openai(texts: List[str]) -> Optional[List[List[float]]]:
    if _is_testing_offline():
        return None
    key = _openai_key()
    if not key:
        return None
    base = _custom_base_url() or "https://api.openai.com/v1"
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                f"{base}/embeddings",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": get_model_name("openai"), "input": texts},
            )
            if resp.status_code != 200:
                logger.warning(f"OpenAI embeddings HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            data = resp.json().get("data", [])
            data.sort(key=lambda d: d.get("index", 0))
            vectors = [d.get("embedding") for d in data]
            if len(vectors) != len(texts) or any(v is None for v in vectors):
                return None
            return [list(map(float, v)) for v in vectors]
    except Exception as e:  # noqa: BLE001
        logger.warning(f"OpenAI embeddings request failed: {e}")
        return None


def _embed_gemini(texts: List[str]) -> Optional[List[List[float]]]:
    if _is_testing_offline():
        return None
    key = _gemini_key()
    if not key:
        return None
    model = get_model_name("gemini")
    try:
        with httpx.Client(timeout=30.0) as client:
            requests = [{"model": f"models/{model}", "content": {"parts": [{"text": t or " "}]}} for t in texts]
            resp = client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:batchEmbedContents",
                params={"key": key},
                json={"requests": requests},
            )
            if resp.status_code != 200:
                logger.warning(f"Gemini embeddings HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            embeddings = resp.json().get("embeddings", [])
            if len(embeddings) != len(texts):
                return None
            return [list(map(float, e.get("values") or [])) for e in embeddings]
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Gemini embeddings request failed: {e}")
        return None


def _embed_custom(texts: List[str]) -> Optional[List[List[float]]]:
    if _is_testing_offline():
        return None
    base = _custom_base_url()
    if not base:
        return None
    key = getattr(config, "EMBEDDING_API_KEY", "") or os.getenv("EMBEDDING_API_KEY", "").strip()
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    try:
        with httpx.Client(timeout=30.0) as client:
            resp = client.post(
                f"{base}/embeddings",
                headers=headers,
                json={"model": get_model_name("custom"), "input": texts},
            )
            if resp.status_code != 200:
                logger.warning(f"Custom embeddings HTTP {resp.status_code}: {resp.text[:200]}")
                return None
            data = resp.json().get("data", [])
            data.sort(key=lambda d: d.get("index", 0))
            vectors = [d.get("embedding") for d in data]
            if len(vectors) != len(texts) or any(v is None for v in vectors):
                return None
            return [list(map(float, v)) for v in vectors]
    except Exception as e:  # noqa: BLE001
        logger.warning(f"Custom embeddings request failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_last_used_provider: str = "local"


def embed_texts(texts: List[str]) -> List[List[float]]:
    """Embeds a batch of texts, always returning one vector per input.

    Remote providers are attempted in order; on any failure the deterministic
    local embedding is used so callers never receive a partial result.
    """
    global _last_used_provider
    if not texts:
        return []
    provider = resolve_provider()
    vectors: Optional[List[List[float]]] = None
    if provider == "mistral":
        vectors = _embed_mistral(texts)
    elif provider == "openai":
        vectors = _embed_openai(texts)
    elif provider == "gemini":
        vectors = _embed_gemini(texts)
    elif provider == "custom":
        vectors = _embed_custom(texts)

    if vectors is None:
        if provider != "local":
            logger.info(f"Embedding provider '{provider}' unavailable; using local hashed embedding.")
        _last_used_provider = "local"
        vectors = [local_embed_text(t) for t in texts]
    else:
        _last_used_provider = provider
    return vectors


def embed_text(text: str) -> List[float]:
    """Embeds a single text."""
    vectors = embed_texts([text or ""])
    return vectors[0] if vectors else local_embed_text("")


def is_remote_provider() -> bool:
    """True when a network embedding provider is active."""
    if _is_testing_offline():
        return False
    return resolve_provider() != "local"


def last_used_provider() -> str:
    """Returns the provider actually used in the most recent embedding batch."""
    return _last_used_provider


def provider_status() -> Dict[str, Any]:
    """Human-readable status for the Settings/Health UI."""
    provider = resolve_provider()
    dim = LOCAL_DIM
    if provider == "mistral":
        dim = 1024
    elif provider == "openai":
        dim = 1536
    elif provider == "gemini":
        dim = 768
    return {
        "provider": provider,
        "model": get_model_name(provider),
        "remote": provider != "local",
        "dimension": dim,
    }
