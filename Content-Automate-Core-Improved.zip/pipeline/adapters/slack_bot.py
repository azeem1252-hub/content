import os
import json
import logging
import re
import httpx
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
import config
from pipeline.state import ContentState
from pipeline.utils import sign_quick_action, quick_action_signing_configured

logger = logging.getLogger("pipeline.adapters.slack_bot")


def build_slack_review_card(
    state: ContentState,
    website_name: Optional[str] = None,
    website_id: Optional[str] = None
) -> Dict[str, Any]:
    """
    Generates an interactive Slack Block Kit payload representing an editorial review gate.
    Displays target Next.js site, headline, excerpt, hero image, SEO score, and approval buttons.
    """
    title = state.get("title", "Untitled Dispatch")
    slug = state.get("slug", "post")
    excerpt = state.get("meta_description") or (state.get("draft", "")[:200].replace("#", "").strip() + "...")
    hero_image_url = state.get("hero_image_url")
    word_count = state.get("word_count", 0)
    read_time = state.get("read_time", 1)
    seo_score = state.get("seo_score", 0)
    thread_id = state.get("thread_id", "thread-default")
    revision_count = state.get("revision_count", 1)
    site_label = website_name or state.get("destination_name") or "Next.js Production Blog"
    target_web_id = website_id or state.get("website_id") or ""

    kws = state.get("discovered_keywords") or state.get("keywords") or []
    kws_str = ", ".join(kws[:4]) if kws else "Content Pipeline"

    # Resolve public image URL for Slack rendering
    img_candidate = state.get("public_image_url") or state.get("hero_image_full_url") or hero_image_url
    has_valid_web_image = bool(img_candidate and (img_candidate.startswith("http://") or img_candidate.startswith("https://")))

    section_block = {
        "type": "section",
        "text": {
            "type": "mrkdwn",
            "text": f"🌐 *Target Next.js Website:* `{site_label}`\n\n*{title}*\n\n{excerpt}"
        }
    }
    if has_valid_web_image:
        section_block["accessory"] = {
            "type": "image",
            "image_url": img_candidate,
            "alt_text": title
        }

    # Extract clean article preview for reading directly in Slack
    raw_draft = state.get("draft", "")
    clean_draft = re.sub(r"^---\s*[\r\n]+[\s\S]*?[\r\n]+---\s*", "", raw_draft).strip()
    clean_draft = re.sub(r"^#+\s+.*?\n+", "", clean_draft).strip()
    draft_snippet = clean_draft[:900].strip() if clean_draft else excerpt

    # Config-driven public base URL so links are reachable from Slack
    # (localhost links are dead for anyone outside this machine)
    base_url = (
        os.getenv("PUBLIC_BASE_URL", "").strip()
        or getattr(config, "PUBLIC_BASE_URL", "http://127.0.0.1:8000")
    ).rstrip("/")
    studio_url = f"{base_url}/dashboard?review={thread_id}"
    preview_url = f"{base_url}/preview/{thread_id}"
    # One-click approve links are HMAC-signed so the state-changing endpoint is
    # not an unauthenticated GET. Unsigned deployments keep the legacy URL, and
    # the endpoint refuses unsigned requests only when a signing key exists.
    quick_publish_url = f"{base_url}/api/slack/quick-approve?thread_id={thread_id}&action=approve"
    quick_sig = sign_quick_action(thread_id, "approve")
    if quick_sig:
        quick_publish_url += f"&sig={quick_sig}"

    if len(clean_draft) > 900:
        draft_snippet += f"...\n\n_([Read the full draft preview]({preview_url}))_"

    blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": "📰 Editorial Review: New Blog Ready to Publish",
                "emoji": True
            }
        },
        section_block,
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"📖 *Article Draft Preview:*\n>{draft_snippet.replace(chr(10), chr(10) + '>')}"
            }
        },
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": f"📊 *SEO Score:* `{seo_score}/100`  |  ⏱️ *Length:* `{word_count} words` (~{read_time} min)  |  🔄 *Revision:* `#{revision_count}`"
                },
                {
                    "type": "mrkdwn",
                    "text": f"🎯 *Keywords:* _{kws_str}_"
                }
            ]
        },
        {"type": "divider"},
        {
            "type": "actions",
            "block_id": f"review_actions_{thread_id}",
            "elements": [
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "🚀 One-Click Publish",
                        "emoji": True
                    },
                    "style": "primary",
                    "url": quick_publish_url,
                    "action_id": "quick_publish_link"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "👁 Preview Draft",
                        "emoji": True
                    },
                    "url": preview_url,
                    "action_id": "open_preview_review"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "📖 Read in Studio",
                        "emoji": True
                    },
                    "url": studio_url,
                    "action_id": "open_studio_review"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": f"✅ Approve (Slack)",
                        "emoji": True
                    },
                    "value": json.dumps({
                        "action": "approve",
                        "thread_id": thread_id,
                        "slug": slug,
                        "website_id": target_web_id
                    }),
                    "action_id": "action_approve"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "✏️ Request Changes",
                        "emoji": True
                    },
                    "value": json.dumps({
                        "action": "request_changes",
                        "thread_id": thread_id,
                        "slug": slug,
                        "website_id": target_web_id
                    }),
                    "action_id": "action_request_changes"
                },
                {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": "🗑 Reject",
                        "emoji": True
                    },
                    "style": "danger",
                    "value": json.dumps({
                        "action": "reject",
                        "thread_id": thread_id,
                        "slug": slug,
                        "website_id": target_web_id
                    }),
                    "action_id": "action_reject"
                }
            ]
        }
    ]

    default_channel = os.getenv("SLACK_CHANNEL_ID", "").strip() or getattr(config, "SLACK_CHANNEL_ID", "") or "C_EDITORIAL_REVIEW"
    return {
        "channel": default_channel,
        "text": f"New Next.js Dispatch for Review: {title}",
        "blocks": blocks
    }


def build_feedback_modal(thread_id: str, current_title: str) -> Dict[str, Any]:
    """Constructs a Slack Modal view for human reviewers to type revision feedback."""
    return {
        "type": "modal",
        "callback_id": "modal_editorial_feedback",
        "private_metadata": json.dumps({"thread_id": thread_id}),
        "title": {
            "type": "plain_text",
            "text": "Editorial Revision"
        },
        "submit": {
            "type": "plain_text",
            "text": "Submit Feedback"
        },
        "close": {
            "type": "plain_text",
            "text": "Cancel"
        },
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"Provide revision instructions for *\"{current_title}\"*. The pipeline will automatically incorporate your feedback."
                }
            },
            {
                "type": "input",
                "block_id": "feedback_input_block",
                "element": {
                    "type": "plain_text_input",
                    "action_id": "feedback_text",
                    "multiline": True,
                    "placeholder": {
                        "type": "plain_text",
                        "text": "e.g., Deepen technical benchmarks and explain Next.js server actions."
                    }
                },
                "label": {
                    "type": "plain_text",
                    "text": "Editorial Instructions"
                }
            }
        ]
    }


def build_approval_banner(title: str, user_name: str, published_url: Optional[str], site_name: str = "Next.js Blog") -> List[Dict[str, Any]]:
    """Generates updated message blocks replacing buttons with a verified green approval banner.

    ``published_url`` may be None when the site confirmed a publish but did not
    report a post URL. Never render a fabricated deep link in that case.
    """
    now = datetime.now().strftime("%I:%M %p")
    title_text = f"*<{published_url}|{title}>*" if published_url else f"*{title}*"
    link_text = (
        f"🔗 *Live Next.js Article:* <{published_url}|{published_url}>"
        if published_url
        else "🔗 *Live URL:* not reported by the website's API route"
    )
    return [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": "✅ Dispatch Published to Next.js",
                "emoji": True
            }
        },
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"{title_text}\n\nApproved by *@{user_name}* at `{now}` &bull; Published live to *{site_name}*."
            }
        },
        {
            "type": "context",
            "elements": [
                {
                    "type": "mrkdwn",
                    "text": link_text
                }
            ]
        }
    ]


def _clean_channel_id(ch: Optional[str]) -> str:
    """Extracts a valid Slack Channel ID (e.g. C0123456789) from raw inputs, URLs, or #names."""
    if not ch:
        return ""
    clean = ch.strip()
    # Match Slack web URL format: .../archives/C0123456789
    m = re.search(r"/archives/([A-Z0-9]+)", clean)
    if m:
        return m.group(1)
    # Match standalone channel ID format: C... or G... or D...
    m = re.search(r"\b([CGD][A-Z0-9]{8,})\b", clean)
    if m:
        return m.group(1)
    if clean.startswith("#"):
        return clean.lstrip("#")
    return clean


def send_slack_card(
    card_payload: Dict[str, Any],
    webhook_url: Optional[str] = None,
    channel_override: Optional[str] = None
) -> Dict[str, Any]:
    """
    Sends the Block Kit payload via direct Slack Incoming Webhook (preferred for individual websites)
    or Slack WebClient if configured.
    """
    # 1. Direct Webhook Dispatch (easiest per-website setup)
    effective_webhook = None
    if webhook_url and webhook_url.startswith("https://hooks.slack.com/"):
        effective_webhook = webhook_url
    elif channel_override and channel_override.startswith("https://hooks.slack.com/"):
        effective_webhook = channel_override

    if effective_webhook:
        try:
            with httpx.Client(timeout=10.0) as client:
                res = client.post(effective_webhook, json={
                    "text": card_payload.get("text"),
                    "blocks": card_payload.get("blocks")
                })
                if res.status_code == 200:
                    logger.info("Successfully dispatched Slack review card via Incoming Webhook.")
                    return {"ok": True, "method": "webhook"}
                else:
                    logger.warning(f"Slack webhook failed ({res.status_code}): {res.text}")
                    return {"ok": False, "error": f"Slack webhook returned {res.status_code}: {res.text}"}
        except Exception as e:
            logger.error(f"Error posting to Slack webhook: {e}")
            return {"ok": False, "error": str(e)}

    # 2. Slack WebClient Token Dispatch
    bot_token = (os.getenv("SLACK_BOT_TOKEN", "").strip() or getattr(config, "SLACK_BOT_TOKEN", "")).strip()
    default_channel = (os.getenv("SLACK_CHANNEL_ID", "").strip() or getattr(config, "SLACK_CHANNEL_ID", "")).strip()
    placeholders = ("your-", "your_", "placeholder", "c0123456789", "xxxx", "enter-", "todo")
    if not bot_token or any(p in bot_token.lower() for p in placeholders):
        logger.info("SLACK_BOT_TOKEN not configured or placeholder detected. Skipping bot dispatch.")
        return {
            "ok": False,
            "skipped": True,
            "channel": channel_override or card_payload.get("channel"),
            "reason": "SLACK_BOT_TOKEN not configured or placeholder detected"
        }

    try:
        from slack_sdk import WebClient
    except ImportError:
        logger.info("slack_sdk library not installed. Skipping bot dispatch.")
        return {
            "ok": False,
            "skipped": True,
            "channel": channel_override or card_payload.get("channel"),
            "reason": "slack_sdk library not installed"
        }

    try:
        client = WebClient(token=bot_token)
        raw_ch = channel_override or card_payload.get("channel") or default_channel
        channel = _clean_channel_id(raw_ch)

        # Attempt auto-join in case it's a public channel
        if channel:
            try:
                client.conversations_join(channel=channel)
            except Exception:
                pass

        response = client.chat_postMessage(
            channel=channel,
            text=card_payload["text"],
            blocks=card_payload["blocks"]
        )
        return {
            "ok": True,
            "ts": response.get("ts"),
            "channel": response.get("channel"),
            "method": "bot_token"
        }
    except Exception as e:
        logger.error(f"Failed to post Slack message via WebClient: {e}")
        return {"ok": False, "error": str(e)}


def test_slack_bot_connection(bot_token: Optional[str] = None, channel_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Tests Slack Bot credentials by performing auth.test and posting a diagnostic message
    to the specified channel.
    """
    token = (bot_token or os.getenv("SLACK_BOT_TOKEN", "").strip() or getattr(config, "SLACK_BOT_TOKEN", "")).strip()
    target_channel = (channel_id or os.getenv("SLACK_CHANNEL_ID", "").strip() or getattr(config, "SLACK_CHANNEL_ID", "")).strip()

    if not token:
        return {"ok": False, "error": "SLACK_BOT_TOKEN is not configured in .env. Enter your Bot User OAuth Token (starts with xoxb-)."}

    placeholders = ("your-", "your_", "placeholder", "c0123456789", "xxxx", "enter-", "todo")
    if any(p in token.lower() for p in placeholders):
        return {
            "ok": False,
            "error": f"Placeholder token detected ('{token}'). Please enter a real Slack Bot User OAuth Token from your Slack App dashboard."
        }

    try:
        from slack_sdk import WebClient
        client = WebClient(token=token)
        auth_res = client.auth_test()
        bot_user = auth_res.get("user", "Bot")
        team = auth_res.get("team", "Workspace")

        if target_channel:
            clean_ch = _clean_channel_id(target_channel)

            # 1. Attempt to auto-join if it's a public channel
            try:
                client.conversations_join(channel=clean_ch)
            except Exception as join_err:
                logger.debug(f"conversations_join attempt on {clean_ch}: {join_err}")

            # 2. Dispatch diagnostic message
            try:
                client.chat_postMessage(
                    channel=clean_ch,
                    text=f"🟢 *Diagnostic Ping from Content Pipeline Agent*\nConnected as `@{bot_user}` on workspace *{team}* at `{datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC`. Review gate ready!"
                )
            except Exception as post_err:
                err_str = str(post_err)
                if "channel_not_found" in err_str or "not_in_channel" in err_str:
                    return {
                        "ok": False,
                        "bot_user": bot_user,
                        "team": team,
                        "channel": clean_ch,
                        "error": (
                            f"Slack returned 'channel_not_found'. Authenticated as @{bot_user} on workspace '{team}', "
                            f"but the bot is not a member of channel '{clean_ch}'.\n\n"
                            f"👉 Fix:\n"
                            f"1. Open channel '{clean_ch}' in Slack.\n"
                            f"2. Type:  /invite @{bot_user}  and press Enter.\n"
                            f"3. Make sure the channel is in workspace '{team}'.\n"
                            f"4. Click 'Test Slack Connectivity' again."
                        )
                    }
                raise post_err

            return {
                "ok": True,
                "bot_user": bot_user,
                "team": team,
                "channel": clean_ch,
                "message": f"Successfully authenticated as @{bot_user} on '{team}' and dispatched test ping to channel '{clean_ch}'!"
            }
        else:
            return {
                "ok": True,
                "bot_user": bot_user,
                "team": team,
                "message": f"Successfully authenticated as @{bot_user} on workspace '{team}'! (No Channel ID provided, skipping test message dispatch)."
            }
    except Exception as e:
        logger.error(f"Slack connection test failed: {e}")
        return {"ok": False, "error": str(e)}
