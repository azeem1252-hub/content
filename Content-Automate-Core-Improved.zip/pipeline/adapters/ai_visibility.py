"""
AI Search Visibility Engine (Pillar: Measurement Paradigms / Unified GEO Tracking).

Measures — rather than estimates — whether generative answer engines cite a brand.
Tracked queries are dispatched to configured answer engines, and the returned
answer + source list are analyzed for brand inclusion, cited URLs, competing
domains, sentiment, and share of voice.

Providers (all optional):
  1. Perplexity  (PERPLEXITY_API_KEY)   — real citations via `sonar`
  2. OpenRouter  (OPENROUTER_API_KEY)   — any :online search model
  3. OpenAI      (OPENAI_API_KEY)       — citation-free, measures model recall/mentions

When nothing is configured, `measure_query` returns ``measured: False`` with an
explicit reason. Callers must surface that as "not measured" — never as zero.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import httpx

import config

logger = logging.getLogger("pipeline.adapters.ai_visibility")

PERPLEXITY_ENDPOINT = "https://api.perplexity.ai/chat/completions"
OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
OPENAI_ENDPOINT = "https://api.openai.com/v1/chat/completions"

POSITIVE_WORDS = {
    "best", "leading", "excellent", "recommended", "powerful", "reliable", "trusted",
    "authoritative", "robust", "superior", "popular", "top", "strong", "effective",
    "innovative", "praised", "widely used", "industry standard",
}
NEGATIVE_WORDS = {
    "worst", "poor", "unreliable", "outdated", "limited", "criticized", "controversial",
    "flawed", "expensive", "difficult", "weak", "deprecated", "obsolete", "complaints",
    "drawback", "downside", "fails",
}


def _cfg(name: str, default: str = "") -> str:
    return (getattr(config, name, "") or os.getenv(name, "") or default).strip()


def _domain_of(url: str) -> str:
    try:
        netloc = urlparse(url).netloc.lower()
        return netloc[4:] if netloc.startswith("www.") else netloc
    except Exception:  # noqa: BLE001
        return ""


def resolve_provider() -> str:
    """Returns the active answer-engine provider."""
    requested = (_cfg("AI_VISIBILITY_PROVIDER", "auto") or "auto").lower()
    available = {
        "perplexity": bool(_cfg("PERPLEXITY_API_KEY")),
        "openrouter": bool(_cfg("OPENROUTER_API_KEY")),
        "openai": bool(_cfg("OPENAI_API_KEY")),
    }
    if requested in available and available[requested]:
        return requested
    for candidate in ("perplexity", "openrouter", "openai"):
        if available[candidate]:
            return candidate
    # Fallback to configured core LLMs (Groq, Mistral, Gemini)
    if _cfg("GROQ_API_KEY") or _cfg("MISTRAL_API_KEY") or _cfg("GEMINI_API_KEY"):
        return "primary_llm"
    return "unconfigured"


def provider_status() -> Dict[str, Any]:
    """Status descriptor for Settings/Health UI."""
    provider = resolve_provider()
    return {
        "provider": provider,
        "configured": provider != "unconfigured",
        "citations_supported": provider in ("perplexity", "openrouter", "primary_llm"),
        "note": (
            "No AI visibility provider or primary LLM configured."
        ) if provider == "unconfigured" else "",
    }


# ---------------------------------------------------------------------------
# Engine dispatch
# ---------------------------------------------------------------------------

_VISIBILITY_PROMPT = (
    "Answer the following question as you normally would for a user, citing the "
    "sources and domain references you rely on. Question: {query}"
)


def query_engine(query: str, provider: Optional[str] = None, timeout: float = 45.0) -> Dict[str, Any]:
    """Sends a tracked query to the configured answer engine.

    Returns {"answer", "citations", "provider", "measured", "error"}.
    """
    provider = provider or resolve_provider()
    if provider == "unconfigured":
        return {"measured": False, "provider": provider, "answer": "", "citations": [],
                "error": "No AI visibility provider configured"}

    if provider == "primary_llm":
        from pipeline.llm_client import call_llm
        llm_prompt = (
            f"You are evaluating generative search engine citations.\n"
            f"Question: {query}\n\n"
            f"Answer thoroughly and objectively. Mention specific leading products, tools, websites, "
            f"or publications in this domain that you recommend, including their web domains (e.g. domain.com)."
        )
        try:
            answer = call_llm(llm_prompt, temperature=0.3)
            found_urls = re.findall(r"https?://[^\s)\]]+", answer)
            found_domains = re.findall(r"\b([a-zA-Z0-9-]+\.(?:com|org|io|dev|app|net|co))\b", answer)
            combined_citations = found_urls + [f"https://{d}" for d in found_domains if d not in str(found_urls)]
            return {
                "measured": True,
                "provider": "Generative AI Engine",
                "answer": answer,
                "citations": list(dict.fromkeys(combined_citations)),
            }
        except Exception as e:
            logger.warning(f"primary_llm visibility query failed: {e}")
            return {"measured": False, "provider": "primary_llm", "answer": "", "citations": [], "error": str(e)}

    prompt = _VISIBILITY_PROMPT.format(query=query)
    headers: Dict[str, str] = {"Content-Type": "application/json"}
    payload: Dict[str, Any] = {"messages": [{"role": "user", "content": prompt}], "temperature": 0.2}

    if provider == "perplexity":
        url = PERPLEXITY_ENDPOINT
        headers["Authorization"] = f"Bearer {_cfg('PERPLEXITY_API_KEY')}"
        payload["model"] = "sonar"
    elif provider == "openrouter":
        url = OPENROUTER_ENDPOINT
        headers["Authorization"] = f"Bearer {_cfg('OPENROUTER_API_KEY')}"
        headers["HTTP-Referer"] = "https://localhost"
        payload["model"] = _cfg("AI_VISIBILITY_MODEL", "perplexity/sonar")
    else:  # openai
        url = OPENAI_ENDPOINT
        headers["Authorization"] = f"Bearer {_cfg('OPENAI_API_KEY')}"
        payload["model"] = _cfg("OPENAI_MODEL", "gpt-4o-mini")

    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.post(url, headers=headers, json=payload)
            if resp.status_code != 200:
                logger.warning(f"{provider} visibility query HTTP {resp.status_code}: {resp.text[:200]}")
                return {"measured": False, "provider": provider, "answer": "", "citations": [],
                        "error": f"HTTP {resp.status_code}"}
            data = resp.json()
            answer = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
            citations: List[str] = []
            for key in ("citations", "search_results", "sources"):
                raw = data.get(key)
                if isinstance(raw, list):
                    for item in raw:
                        if isinstance(item, str):
                            citations.append(item)
                        elif isinstance(item, dict) and item.get("url"):
                            citations.append(item["url"])
            return {
                "measured": True,
                "provider": provider,
                "answer": answer,
                "citations": list(dict.fromkeys(citations)),
            }
    except Exception as e:  # noqa: BLE001
        logger.warning(f"{provider} visibility query failed: {e}")
        return {"measured": False, "provider": provider, "answer": "", "citations": [], "error": str(e)}


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def _sentiment_around_brand(text: str, brand_terms: List[str], window: int = 160) -> float:
    """Lexicon sentiment in [-1, 1] measured within a window around brand mentions."""
    lowered = (text or "").lower()
    hits = 0
    score = 0.0
    for term in brand_terms:
        if not term:
            continue
        for m in re.finditer(re.escape(term.lower()), lowered):
            hits += 1
            snippet = lowered[max(0, m.start() - window): m.end() + window]
            pos = sum(1 for w in POSITIVE_WORDS if w in snippet)
            neg = sum(1 for w in NEGATIVE_WORDS if w in snippet)
            if pos or neg:
                score += (pos - neg) / max(1, pos + neg)
    if not hits:
        return 0.0
    return max(-1.0, min(1.0, score / hits))


def analyze_answer(
    answer: str,
    citations: List[str],
    brand: str,
    domain: str,
) -> Dict[str, Any]:
    """Determines whether the brand is cited and quantifies the result."""
    brand_terms = [t for t in {brand.strip().lower(), (brand or "").replace(" ", "").lower()} if t and len(t) > 2]
    lowered = (answer or "").lower()
    clean_domain = (domain or "").lower().replace("www.", "")

    brand_mentioned = any(term in lowered for term in brand_terms) if brand_terms else False
    own_citations = [u for u in citations if clean_domain and clean_domain in _domain_of(u)]
    competitor_domains = sorted({_domain_of(u) for u in citations if _domain_of(u) and _domain_of(u) != clean_domain})

    brand_cited = bool(own_citations) or brand_mentioned
    share_voice = None
    total_sources = len(citations)
    if total_sources:
        share_voice = round(100.0 * len(own_citations) / total_sources, 1)

    return {
        "brand_cited": brand_cited,
        "brand_mentioned": brand_mentioned,
        "cited_urls": own_citations,
        "all_cited_urls": citations,
        "competitor_domains": competitor_domains[:15],
        "share_voice": share_voice,
        "sentiment": round(_sentiment_around_brand(answer, brand_terms), 2),
    }


def measure_query(
    website_id: Optional[str],
    query: str,
    brand: str,
    domain: str,
    provider: Optional[str] = None,
) -> Dict[str, Any]:
    """Measures one tracked query and returns a snapshot record (unpersisted)."""
    result = query_engine(query, provider=provider)
    if not result.get("measured"):
        return {
            "website_id": website_id,
            "provider": result.get("provider"),
            "query": query,
            "measured": False,
            "error": result.get("error"),
        }
    analysis = analyze_answer(result.get("answer", ""), result.get("citations") or [], brand, domain)
    return {
        "website_id": website_id,
        "provider": result.get("provider"),
        "query": query,
        "measured": True,
        "brand_cited": analysis["brand_cited"],
        "cited_urls": analysis["cited_urls"],
        "competitor_domains": analysis["competitor_domains"],
        "share_voice": analysis["share_voice"],
        "sentiment": analysis["sentiment"],
        "answer_excerpt": (result.get("answer") or "")[:1200],
    }


def measure_queries(
    website_id: Optional[str],
    queries: List[str],
    brand: str,
    domain: str,
    limit: Optional[int] = None,
    provider: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Measures a batch of tracked queries, capped by AI_VISIBILITY_QUERY_LIMIT."""
    cap = limit or int(getattr(config, "AI_VISIBILITY_QUERY_LIMIT", 25) or 25)
    out: List[Dict[str, Any]] = []
    for query in (queries or [])[:cap]:
        if not (query or "").strip():
            continue
        out.append(measure_query(website_id, query, brand, domain, provider=provider))
    return out


def summarize_visibility(snapshots: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Aggregates measured snapshots into an inclusion-rate / share-of-voice report.

    Only rows where ``measured`` is true contribute to the metrics, so the UI can
    distinguish "not configured / not measured" from "measured zero".
    """
    measured = [s for s in snapshots if s.get("measured")]
    if not measured:
        return {
            "measured": False,
            "total_queries_tracked": 0,
            "inclusion_rate_percent": None,
            "average_share_voice": None,
            "average_sentiment": None,
            "platform_distribution": [],
            "top_competitors": [],
            "unmeasured_reason": (snapshots[0].get("error") if snapshots else None)
            or "No AI visibility measurements have been collected yet.",
        }

    cited = [s for s in measured if s.get("brand_cited")]
    inclusion = round(100.0 * len(cited) / len(measured), 1)

    share_values = [s["share_voice"] for s in measured if s.get("share_voice") is not None]
    sentiment_values = [s["sentiment"] for s in measured if s.get("sentiment") is not None]

    by_provider: Dict[str, Dict[str, int]] = {}
    for s in measured:
        prov = s.get("provider") or "unknown"
        entry = by_provider.setdefault(prov, {"cited": 0, "total": 0})
        entry["total"] += 1
        if s.get("brand_cited"):
            entry["cited"] += 1

    competitor_counts: Dict[str, int] = {}
    for s in measured:
        for d in s.get("competitor_domains") or []:
            competitor_counts[d] = competitor_counts.get(d, 0) + 1

    platform_distribution = []
    for prov, agg in by_provider.items():
        platform_distribution.append({
            "platform": prov.title(),
            "queries": agg["total"],
            "citation_rate_percent": round(100.0 * agg["cited"] / agg["total"], 1) if agg["total"] else 0.0,
        })

    top_competitors = sorted(
        [{"domain": d, "appearances": c} for d, c in competitor_counts.items()],
        key=lambda x: x["appearances"],
        reverse=True,
    )[:10]

    return {
        "measured": True,
        "total_queries_tracked": len(measured),
        "cited_queries": len(cited),
        "inclusion_rate_percent": inclusion,
        "average_share_voice": round(sum(share_values) / len(share_values), 1) if share_values else None,
        "average_sentiment": round(sum(sentiment_values) / len(sentiment_values), 2) if sentiment_values else None,
        "platform_distribution": platform_distribution,
        "top_competitors": top_competitors,
        "unmeasured_reason": None,
    }
