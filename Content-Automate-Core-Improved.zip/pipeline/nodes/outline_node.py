import os
import re
import json
import logging
import httpx
from typing import Dict, Any, List, Optional
from pipeline.state import ContentState
from pipeline.llm_client import call_llm
from pipeline.utils import (
    extract_json_block,
    merge_unique_keywords,
    fetch_tavily_intelligence,
    fetch_tavily_extract,
)
from pipeline.topic_researcher import get_archetype_for_niche
from pipeline.editorial_archetypes import get_design_archetype_by_slug, detect_editorial_archetype
from pipeline.adapters.internal_linker import get_cluster_candidates
from pipeline.adapters.brief_builder import (
    build_evidence_based_brief,
    brief_to_outline_markdown,
    ContentBrief,
)
import config

logger = logging.getLogger("pipeline.nodes.outline")


def research_keywords_and_audience(
    topic: str,
    seed_keywords: Optional[List[str]] = None,
    target_audience_hint: Optional[str] = None,
    niche_slug: Optional[str] = None,
    editorial_niche: Optional[str] = None,
    angle_or_hook: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Scrapes high-ranking keywords, search intent, community discussions, and Information Gain gaps
    using multi-angle Tavily web search tailored to the target website's editorial archetype.
    """
    arch = get_archetype_for_niche(niche_slug, f"{topic} {editorial_niche or ''}")
    persona = arch.get("persona", "Chief Content Officer and Head of SEO Strategy")
    default_aud = arch.get("default_audience") or "Discerning practitioners, enthusiasts, and active readers"

    seeds = seed_keywords or []
    seeds_str = ", ".join(seeds) if seeds else topic

    # 1. Search Angle A: Domain-adaptive high-ranking keywords & SERP consensus
    seo_template = arch.get("seo_query_template") or "{topic} {seeds_str} best practices guide 2026"
    try:
        search_query_seo = seo_template.format(topic=topic, seeds_str=seeds_str)
    except Exception:
        search_query_seo = f"{topic} {seeds_str} comprehensive guide 2026"
    seo_data = fetch_tavily_intelligence(search_query_seo, max_results=4)

    # 2. Search Angle B: Target audience pain points, objections, and community discussions
    community_template = arch.get("community_query") or "{topic} problems challenges questions discussion site:reddit.com"
    try:
        search_query_audience = community_template.format(topic=topic)
    except Exception:
        search_query_audience = f"{topic} problems challenges questions discussion site:reddit.com"
    audience_data = fetch_tavily_intelligence(search_query_audience, max_results=3, search_depth="basic")

    # 3. Search Angle C: Information Gain Gap Audit (what ranking articles miss)
    gap_template = arch.get("gap_query") or "{topic} common mistakes what guides miss"
    try:
        search_query_gap = gap_template.format(topic=topic)
    except Exception:
        search_query_gap = f"{topic} common mistakes what guides miss"
    gap_data = fetch_tavily_intelligence(search_query_gap, max_results=2, search_depth="basic")

    research_errors: Dict[str, str] = {}
    for engine_label, payload in (
        ("tavily_search", seo_data),
        ("tavily_audience", audience_data),
        ("tavily_gap", gap_data),
    ):
        if payload.get("error"):
            research_errors[engine_label] = payload["error"]

    # 4. Deep page scraping on the top results: pull real page content so the
    #    article can cite genuine facts instead of shallow search snippets.
    combined_results = (
        seo_data.get("results", []) +
        audience_data.get("results", []) +
        gap_data.get("results", [])
    )
    top_urls = [r.get("url") for r in combined_results if r.get("url")][:4]
    if top_urls:
        page_data = fetch_tavily_extract(top_urls)
        scraped_pages = page_data.get("results", [])
    else:
        scraped_pages = []

    direct_answer = seo_data.get("answer") or audience_data.get("answer") or gap_data.get("answer")

    search_sources = []
    snippets_text = []
    scraped_by_url = {p.get("url"): p.get("raw_content") or "" for p in scraped_pages if p.get("url")}

    seen_urls = set()
    for r in combined_results:
        title = r.get("title", "")
        url = r.get("url", "")
        snippet = r.get("content", "")
        if url and snippet and url not in seen_urls:
            seen_urls.add(url)
            full_page = scraped_by_url.get(url, "")
            search_sources.append({
                "title": title,
                "url": url,
                "snippet": snippet[:250],
                "page_content": full_page[:3000] if full_page else ""
            })
            if full_page:
                snippets_text.append(f"Source: {title} ({url})\nFull Page Excerpt: {full_page[:1200]}")
            else:
                snippets_text.append(f"Source: {title} ({url})\nExcerpt: {snippet[:350]}")

    dossier_text = "\n\n".join(snippets_text) if snippets_text else "No external search API results available."

    # 5. Synthesize high-ranking keywords, audience persona, and Information Gain gaps via LLM
    analysis_system = (
        f"You are an elite {persona}. "
        "Analyze the scraped search dossier (including full page content from top-ranking articles) and produce "
        "high-ranking search keywords, a target audience persona, and specific 2026 Information Gain differentiators. "
        "Return a strict JSON object with: 'high_ranking_keywords', 'target_audience', 'audience_pain_points', "
        "'competitor_gaps', 'novel_information_gain', and 'direct_answer_summary'."
    )

    analysis_prompt = f"""Topic: {topic}
Editorial Niche: {editorial_niche or arch.get('niche', 'Authoritative Editorial')}
Seed Keywords: {seeds_str}
Audience Hint: {target_audience_hint or default_aud}
Unique Angle / Hook: {angle_or_hook or 'Novel craft secrets and practical masterclass'}

Search Intelligence Dossier (ranked pages, full scraped content where available):
\"\"\"{dossier_text[:6500]}\"\"\"

Direct Web Answer:
{direct_answer or 'N/A'}

Task:
Extract the most valuable high-ranking keywords, audience friction points, and unique Information Gain angles.
Return a valid JSON object formatted EXACTLY as:
{{
  "high_ranking_keywords": [
    "Primary target keyword",
    "4 to 6 long-tail and high-intent LSI keyword variations"
  ],
  "target_audience": "Specific reader persona actively searching for this topic",
  "audience_pain_points": [
    "Specific friction point or technique challenge 1",
    "Specific friction point or technique challenge 2",
    "Specific friction point or technique challenge 3"
  ],
  "competitor_gaps": "What existing top ranking articles completely miss that our article must deliver",
  "novel_information_gain": "The proprietary insight, practical ratio/temperature/config, or counter-intuitive secret this piece contributes",
  "direct_answer_summary": "A concise, authoritative 40-50 word direct answer to the main search intent (ideal for Google AI Overviews and Featured Snippets)"
}}
"""
    raw_analysis = call_llm(prompt=analysis_prompt, system_instruction=analysis_system, temperature=0.3)

    discovered_keywords = list(seeds)
    target_audience = target_audience_hint or default_aud
    audience_insights = f"Target Audience: {target_audience}. Readers demand practical, reproducible mastery with zero fluff."
    novel_ig = angle_or_hook or "Original pro techniques and reproducible execution"
    direct_answer_summary = ""

    parsed = extract_json_block(raw_analysis)
    if parsed:
        raw_scraped = parsed.get("high_ranking_keywords", [])
        scraped_kws = []
        if isinstance(raw_scraped, list):
            for k in raw_scraped:
                if isinstance(k, str) and k.strip():
                    scraped_kws.append(k.strip())
                elif isinstance(k, dict):
                    scraped_kws.extend(str(v).strip() for v in k.values() if v)
                elif k:
                    scraped_kws.append(str(k).strip())
        elif isinstance(raw_scraped, str) and raw_scraped.strip():
            scraped_kws = [raw_scraped.strip()]

        discovered_keywords = merge_unique_keywords(discovered_keywords, scraped_kws)

        if parsed.get("target_audience"):
            target_audience = str(parsed["target_audience"]).strip()

        raw_pain_points = parsed.get("audience_pain_points", [])
        clean_pain_points = []
        if isinstance(raw_pain_points, list):
            for p in raw_pain_points:
                if isinstance(p, str) and p.strip():
                    clean_pain_points.append(p.strip())
                elif isinstance(p, dict):
                    clean_pain_points.extend(str(v).strip() for v in p.values() if v)
                elif p:
                    clean_pain_points.append(str(p).strip())
        elif isinstance(raw_pain_points, str) and raw_pain_points.strip():
            clean_pain_points = [raw_pain_points.strip()]

        gaps = str(parsed.get("competitor_gaps") or "").strip()
        novel_ig = str(parsed.get("novel_information_gain") or novel_ig).strip()
        direct_answer_summary = str(parsed.get("direct_answer_summary") or "").strip()

        pain_str = "; ".join(clean_pain_points) if clean_pain_points else "Comprehensive domain implementation patterns"
        audience_insights = (
            f"Target Audience: {target_audience}. Key Friction Points: {pain_str}. "
            f"Competitor Gaps: {gaps}. Information Gain Novelty: {novel_ig}."
        )
    else:
        logger.debug("Keyword/audience JSON parsing failed. Using extracted heuristics.")
        # Domain-appropriate heuristic fallback keywords
        domain_name = arch.get("slug", "editorial")
        discovered_keywords = merge_unique_keywords(
            discovered_keywords,
            [topic, f"{topic} guide", f"{topic} pro techniques", f"{topic} 2026", f"{domain_name} masterclass"]
        )

    return {
        "discovered_keywords": discovered_keywords,
        "target_audience": target_audience,
        "audience_insights": audience_insights,
        "novel_information_gain": novel_ig,
        "direct_answer_summary": direct_answer_summary,
        "search_sources": search_sources[:5],
        "engine_errors": research_errors
    }


def generate_outline(
    topic: str,
    keywords: Optional[List[str]] = None,
    target_audience: Optional[str] = None,
    niche_slug: Optional[str] = None,
    editorial_niche: Optional[str] = None,
    angle_or_hook: Optional[str] = None,
    content_format: Optional[str] = None,
    editorial_archetype: Optional[str] = None,
    design_guide: Optional[Dict[str, Any]] = None,
    website_id: Optional[str] = None,
    slug: Optional[str] = None,
    evidence_pack: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Core business logic (Pillar A2):
    Replaces generic 'outline from LLM memory' with an empirical evidence-based content brief.
    Executes live SERP analysis, extracts competitor features with trafilatura, conducts gap analysis,
    pulls unique angle from evidence pack (A3.2), and generates a fully-typed ContentBrief.
    """
    logger.info(f"Building evidence-based brief for: '{topic}' (niche: {niche_slug or 'auto'}, design: {editorial_archetype or 'auto'})")
    
    arch = get_archetype_for_niche(niche_slug, f"{topic} {editorial_niche or ''}")
    design = design_guide or get_design_archetype_by_slug(editorial_archetype)

    primary_keyword = (keywords[0] if (keywords and keywords[0]) else topic).strip()

    # 1. Build typed evidence-based brief (Pillar A2)
    brief: ContentBrief = build_evidence_based_brief(
        topic=topic,
        primary_keyword=primary_keyword,
        website_id=website_id,
        brand_profile=None,
        evidence_pack=evidence_pack,
        niche_slug=niche_slug,
        editorial_niche=editorial_niche,
        target_audience=target_audience,
        angle_or_hook=angle_or_hook,
        editorial_archetype=editorial_archetype,
        design_guide=design,
        slug=slug,
        max_competitors_to_scrape=5,
    )

    # 2. Render typed brief into comprehensive Markdown outline for downstream drafting
    outline_content = brief_to_outline_markdown(brief)

    # 3. Discover high-ranking keywords and entities
    discovered_kws = merge_unique_keywords(keywords or [primary_keyword], brief.required_entities[:10])

    direct_ans = ""
    if brief.questions_to_answer:
        direct_ans = brief.questions_to_answer[0].get("answer_first_form", "")

    search_sources = []
    if brief.serp_summary and brief.serp_summary.get("ai_overview_sources"):
        search_sources = brief.serp_summary["ai_overview_sources"]

    return {
        "outline": outline_content,
        "content_brief": brief.model_dump(),
        "serp_analysis": brief.serp_summary,
        "evidence_pack": evidence_pack,
        "discovered_keywords": discovered_kws,
        "target_audience": brief.target_reader,
        "audience_insights": f"Target Audience: {brief.target_reader}. Search Intent: {brief.intent}.",
        "novel_information_gain": brief.unique_angle,
        "direct_answer_summary": direct_ans,
        "search_sources": search_sources,
        "editorial_archetype": design.get("slug"),
        "design_guide": design,
        "engine_errors": {},
        "status": "outlined",
    }


def outline_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node adapter: Builds evidence-based brief from live SERP intelligence,
    sets content_brief, serp_analysis, and outline in ContentState.
    """
    topic = state.get("topic", "")
    keywords = list(state.get("keywords") or [])
    sec_kws = list(state.get("secondary_keywords") or [])
    for sk in sec_kws:
        if sk and sk not in keywords:
            keywords.append(sk)
    target_audience = state.get("target_audience")
    niche_slug = state.get("niche_slug")
    site_niche = state.get("site_niche")
    angle_or_hook = state.get("angle_or_hook")
    content_format = state.get("content_format")
    editorial_archetype = state.get("editorial_archetype")
    design_guide = state.get("design_guide")
    website_id = state.get("website_id")
    slug = state.get("slug")
    evidence_pack = state.get("evidence_pack")

    result = generate_outline(
        topic=topic,
        keywords=keywords,
        target_audience=target_audience,
        niche_slug=niche_slug,
        editorial_niche=site_niche,
        angle_or_hook=angle_or_hook,
        content_format=content_format,
        editorial_archetype=editorial_archetype,
        design_guide=design_guide,
        website_id=website_id,
        slug=slug,
        evidence_pack=evidence_pack,
    )

    return {
        "outline": result["outline"],
        "content_brief": result["content_brief"],
        "serp_analysis": result.get("serp_analysis"),
        "evidence_pack": result.get("evidence_pack"),
        "discovered_keywords": result["discovered_keywords"],
        "target_audience": result["target_audience"],
        "audience_insights": result["audience_insights"],
        "search_sources": result["search_sources"],
        "editorial_archetype": result.get("editorial_archetype"),
        "design_guide": result.get("design_guide"),
        # Merge with any errors already recorded in state (e.g. image engines)
        "engine_errors": {**(state.get("engine_errors") or {}), **(result.get("engine_errors") or {})},
        "status": "outlined",
    }
