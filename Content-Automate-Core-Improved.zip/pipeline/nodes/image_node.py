import logging
from pathlib import Path
from typing import Dict, Any, Optional
from pipeline.state import ContentState
from pipeline.adapters.codex_image import synthesize_visual_prompt, generate_and_save_image

logger = logging.getLogger("pipeline.nodes.image")


def _existing_hero_usable(state: Dict[str, Any], title: str, slug: Optional[str]) -> bool:
    """True when a previously generated hero asset can be reused: either a valid
    hero_image_url is already present, or the asset file exists on disk and the title hasn't radically changed."""
    old_url = state.get("hero_image_url")
    if old_url and (old_url.startswith("http") or old_url.startswith("/static/") or old_url.startswith("/uploads/")):
        return True

    old_path = state.get("hero_image_path")
    if not old_path:
        return False
    try:
        if not Path(old_path).is_file():
            return False
    except OSError:
        return False
    old_title = state.get("title")
    old_slug = state.get("slug")
    same_title = bool(old_title) and old_title == title
    same_slug = (old_slug or None) == (slug or None)
    return same_title or same_slug


def _site_public_dir_override(state: Dict[str, Any]) -> Optional[str]:
    """Per-website uploads target for the local Next.js clone, or None.

    Keeps two side-by-side websites from writing (and overwriting) each other's
    hero images when they share one global NEXTJS_PUBLIC_DIR.
    """
    website_id = state.get("website_id")
    if not website_id:
        return None
    try:
        from storage.db import get_website_by_id
        from pipeline.utils import discover_local_nextjs_public_dir
        return discover_local_nextjs_public_dir(get_website_by_id(website_id))
    except Exception as err:
        logger.debug(f"Per-site public dir resolution skipped: {err}")
        return None


def generate_hero_image_for_article(
    title: str,
    topic: str,
    slug: Optional[str] = None,
    draft_excerpt: str = "",
    public_dir: Optional[str] = None,
    editorial_archetype: Optional[str] = None
) -> Dict[str, Any]:
    """
    Core business logic: Synthesizes a visual prompt matching the article narrative
    and generates/saves the hero asset using Codex session auth or resilient fallback.
    """
    from pipeline.utils import clean_slug

    article_slug = clean_slug(slug or title, max_len=60, fallback="hero")
    logger.info(f"Initiating hero image generation for: '{title}' (slug: {article_slug}, archetype: {editorial_archetype or 'auto'})")

    # 1. Synthesize visual prompt
    prompt = synthesize_visual_prompt(title=title, topic=topic, draft_excerpt=draft_excerpt, editorial_archetype=editorial_archetype)

    # 2. Generate and store asset locally
    asset_info = generate_and_save_image(prompt=prompt, slug=article_slug, public_dir=public_dir)

    return {
        "hero_image_path": asset_info["hero_image_path"],
        "hero_image_url": asset_info["hero_image_url"],
        "hero_image_full_url": asset_info.get("hero_image_full_url"),
        "public_image_url": asset_info.get("public_image_url"),
        "image_prompt": prompt,
        # Keep the per-engine failure reasons in state so the dashboard can show
        # which engine actually produced the asset (or why each one failed).
        "engine_errors": asset_info.get("engine_errors") or {},
        "status": "image_generated"
    }


def image_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node adapter: Extracts title, topic, slug, and draft excerpt from ContentState
    and executes hero image generation. Reuses the existing hero asset when the
    title/slug is unchanged (e.g. an editorial revision that didn't alter the story).
    """
    title = state.get("title") or state.get("topic", "Autonomous AI Agents")
    topic = state.get("topic", "AI Systems")
    slug = state.get("slug")
    editorial_archetype = state.get("editorial_archetype")

    # Respect user-configured visual asset toggles (ON/OFF buttons)
    content_options = state.get("content_options") or {}
    enable_hero_image = content_options.get("enable_hero_image", state.get("enable_hero_image", state.get("enable_visual_assets", True)))
    if enable_hero_image is False:
        logger.info(f"User disabled visual assets: skipping hero image generation for '{title}'.")
        return {
            "hero_image_path": None,
            "hero_image_url": None,
            "hero_image_full_url": None,
            "public_image_url": None,
            "image_prompt": None,
            "image_provenance": None,
            "status": "image_skipped"
        }

    if _existing_hero_usable(state, title, slug):
        logger.info(f"Reusing existing hero asset for '{title}' (title unchanged since last generation).")
        return {
            "hero_image_path": state.get("hero_image_path"),
            "hero_image_url": state.get("hero_image_url"),
            "hero_image_full_url": state.get("hero_image_full_url"),
            "public_image_url": state.get("public_image_url"),
            "image_prompt": state.get("image_prompt"),
            "image_provenance": state.get("image_provenance"),
            "status": "image_generated"
        }

    draft = state.get("draft", "")
    result = generate_hero_image_for_article(
        title=title,
        topic=topic,
        slug=slug,
        draft_excerpt=draft[:500],
        public_dir=_site_public_dir_override(state),
        editorial_archetype=editorial_archetype
    )

    from pipeline.adapters.image_provenance import create_image_provenance
    provenance = create_image_provenance(
        image_url=result.get("hero_image_url") or "",
        image_path=result.get("hero_image_path"),
        image_type="ai_generated",
        ai_engine="cloudflare",
        model_name="flux-1-schnell",
        generation_prompt=result.get("image_prompt"),
    )

    return {
        "hero_image_path": result["hero_image_path"],
        "hero_image_url": result["hero_image_url"],
        "hero_image_full_url": result.get("hero_image_full_url"),
        "public_image_url": result.get("public_image_url"),
        "image_prompt": result.get("image_prompt"),
        "image_provenance": provenance.model_dump(),
        "engine_errors": {**(state.get("engine_errors") or {}), **(result.get("engine_errors") or {})},
        "status": "image_generated"
    }
