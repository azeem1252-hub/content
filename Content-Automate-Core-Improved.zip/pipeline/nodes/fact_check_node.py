"""
Agentic Multi-Source Fact Verification Node (Pillar I).

Implements the 3-subagent fact-checking pipeline from the blueprints:
1. Claim Extraction Agent: Identifies discrete, verifiable factual statements (statistics, metrics, benchmarks).
2. Evidence Search Agent: Queries live multi-source web endpoints via Tavily API.
3. Fact-Check Critic Agent: Evaluates claims against evidence, categorizing verdicts as
   'Supported', 'Contradicted', or 'Unsubstantiated' with confidence scores and source URLs.
4. Auto-Correction Pass: Directly rectifies or purges contradicted claims in the draft.
"""

import json
import logging
import re
from typing import Dict, Any, List, Optional
from pipeline.state import ContentState
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block, fetch_tavily_intelligence, clean_article_content
from pipeline.adapters.embedding_client import embed_text, cosine_similarity, is_remote_provider

logger = logging.getLogger("pipeline.nodes.fact_check")


def extract_verifiable_claims(draft: str, max_claims: int = 5) -> List[Dict[str, Any]]:
    """
    Sub-Agent 1 (Claim Extraction):
    Scans the draft text and extracts the most significant, discrete, testable empirical claims.
    """
    if not draft or len(draft.strip()) < 100:
        return []

    prompt = f"""
You are a Lead Fact-Checking Investigative Editor.
Analyze the following article draft and extract up to {max_claims} discrete, empirical, verifiable factual claims.
Focus on:
- Quantitative metrics, percentages, dollar figures, or benchmarks.
- Technical architecture statements (e.g. "X uses Y to do Z").
- Historical events, company actions, or comparative claims.

Ignore general philosophical thoughts, broad metaphors, and subjective opinions.

Draft Excerpt:
{draft[:4000]}

Return a strict JSON object with a "claims" list formatted as:
```json
{{
  "claims": [
    {{
      "claim_id": "c1",
      "statement": "Exact or concise statement of the claim",
      "search_query": "Optimal Google/Tavily search query to verify this specific fact"
    }}
  ]
}}
```
"""
    try:
        raw = call_llm(prompt, temperature=0.1)
        data = extract_json_block(raw)
        if data and isinstance(data.get("claims"), list):
            return data["claims"][:max_claims]
    except Exception as e:
        logger.warning(f"Claim extraction encountered an error: {e}")

    return []


def gather_evidence_for_claims(claims: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Sub-Agent 2 (Evidence Search Agent):
    Dispatches targeted web queries for each claim using the Tavily API.
    """
    enriched_claims = []
    for claim in claims:
        query = claim.get("search_query") or claim.get("statement", "")
        if not query:
            continue

        search_res = fetch_tavily_intelligence(query, max_results=3, search_depth="basic")
        results = search_res.get("results", [])

        evidence_snippets = []
        for r in results:
            evidence_snippets.append({
                "title": r.get("title", ""),
                "url": r.get("url", ""),
                "snippet": r.get("content", "")[:350]
            })

        enriched_claims.append({
            **claim,
            "evidence": evidence_snippets,
            "answer_summary": search_res.get("answer")
        })

    return enriched_claims


def evaluate_claims_verdict(claims_with_evidence: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Sub-Agent 3 (Fact-Check Critic Agent):
    Compares original claims against synthesized evidence and assigns structured verdicts.
    """
    if not claims_with_evidence:
        return {
            "verified_claims": [],
            "fact_check_score": 100,
            "verdict": "supported",
            "summary": "No discrete empirical claims required external verification."
        }

    claims_text = json.dumps(claims_with_evidence, indent=2)
    prompt = f"""
You are an uncompromising Fact-Check Critic applying Google E-E-A-T verification standards.
Compare each extracted claim against the retrieved multi-source evidence.

For each claim, decide one of three verdicts:
1. "Supported": The evidence directly corroborates the assertion.
2. "Contradicted": The evidence directly disproves or contradicts the assertion.
3. "Unsubstantiated": The evidence is missing, ambiguous, or insufficient.

Extracted Claims and Retrieved Evidence:
{claims_text}

Return a strict JSON object with:
```json
{{
  "verified_claims": [
    {{
      "claim_id": "c1",
      "statement": "...",
      "verdict": "Supported" | "Contradicted" | "Unsubstantiated",
      "confidence_score": 0.95,
      "source_url": "https://...",
      "reasoning": "Brief explanation of why evidence supports or refutes the claim.",
      "correction": "If contradicted, provide the factual correction. Otherwise null."
    }}
  ],
  "overall_verdict": "supported" | "needs_revision" | "rejected",
  "summary": "1-2 sentence executive assessment of factual grounding."
}}
```
"""
    try:
        raw = call_llm(prompt, temperature=0.1)
        data = extract_json_block(raw)
        if data and isinstance(data.get("verified_claims"), list):
            verified = data["verified_claims"]
            for c in verified:
                raw_src = c.get("source_url")
                if isinstance(raw_src, (list, tuple)):
                    raw_src = raw_src[0] if raw_src else None
                c["source_url"] = str(raw_src).strip() if raw_src else None

            supported_count = sum(1 for c in verified if str(c.get("verdict", "")).lower() == "supported")
            contradicted_count = sum(1 for c in verified if str(c.get("verdict", "")).lower() == "contradicted")
            unsubstantiated_count = sum(1 for c in verified if str(c.get("verdict", "")).lower() == "unsubstantiated")
            total = len(verified)

            if total == 0:
                score = 100
            else:
                # E-E-A-T Scoring Framework:
                # - Supported: 100 points (empirically corroborated by external sources)
                # - Unsubstantiated: 75 points (niche domain claim / subjective assertion not found in search, but not disproven)
                # - Contradicted: 0 points (verifiable falsehood or confabulation)
                weighted_sum = (supported_count * 100) + (unsubstantiated_count * 75) + (contradicted_count * 0)
                base_score = int(weighted_sum / total)
                if contradicted_count > 0:
                    penalty = int((contradicted_count / total) * 35)
                    score = max(0, base_score - penalty)
                else:
                    score = base_score

            data["fact_check_score"] = score
            if contradicted_count > 0:
                data["overall_verdict"] = "needs_revision"
            elif unsubstantiated_count > total / 2 and supported_count == 0:
                data["overall_verdict"] = "needs_review"
            else:
                data["overall_verdict"] = "supported"
            return data
    except Exception as e:
        logger.warning(f"Fact-check critic encountered an error: {e}")

    # Fallback heuristic scoring if LLM fails
    fallback_verified = []
    for c in claims_with_evidence:
        has_ev = bool(c.get("evidence"))
        fallback_verified.append({
            "claim_id": c.get("claim_id", "c0"),
            "statement": c.get("statement", ""),
            "verdict": "Supported" if has_ev else "Unsubstantiated",
            "confidence_score": 0.85 if has_ev else 0.5,
            "source_url": c.get("evidence", [{}])[0].get("url") if has_ev else None,
            "reasoning": "Corroborated by web retrieval." if has_ev else "No direct evidence retrieved.",
            "correction": None
        })

    return {
        "verified_claims": fallback_verified,
        "fact_check_score": 85,
        "overall_verdict": "supported",
        "summary": "Heuristic factual verification completed."
    }


HIGH_TRUST_TLDS = (".gov", ".edu", ".org")
HIGH_TRUST_DOMAINS = (
    "github.com", "arxiv.org", "ietf.org", "w3.org", "developer.mozilla.org",
    "wikipedia.org", "rfc-editor.org", "python.org", "react.dev", "nextjs.org",
    "nodejs.org", "microsoft.com", "google.com", "cloudflare.com", "aws.amazon.com",
    "doi.org", "ncbi.nlm.nih.gov", "who.int", "europa.eu",
)
ESTABLISHED_MEDIA = (
    "reuters.com", "bloomberg.com", "wired.com", "theverge.com", "techcrunch.com",
    "nature.com", "science.org", "ieee.org", "acm.org", "wsj.com", "nytimes.com",
    "arstechnica.com", "ft.com", "economist.com",
)
# TLDs disproportionately used by low-quality/spammy sources. Trusting these at
# face value is how hallucinated content gets laundered into an article.
SUSPICIOUS_TLDS = (
    ".xyz", ".click", ".top", ".buzz", ".loan", ".work", ".gq", ".cf",
    ".tk", ".ml", ".ga", ".icu", ".rest", ".monster",
)
TRUSTED_COMMERCIAL_TLDS = (".com", ".io", ".ai", ".dev", ".net", ".co")


def compute_source_trust_score(sources: List[Dict[str, Any]]) -> int:
    """
    Layer 4: Source Trust Scoring.
    Scores the reliability/authority of sources retrieved during web RAG.

    Accepts a flat list of evidence dicts (each with a ``url``), so it can be
    applied to sources directly. High-authority domains (gov/edu/major docs)
    score ~95, established media ~88, ordinary commercial sites ~78, unknown or
    suspicious TLDs ~35-45.
    """
    if not sources:
        return 80  # Neutral default when there is nothing to evaluate

    scores = []
    for src in sources:
        url = (src.get("url") or "").lower()
        if not url:
            continue
        domain_match = re.search(r"https?://(?:www\.)?([^/]+)", url)
        domain = domain_match.group(1) if domain_match else ""
        if not domain:
            continue

        if any(domain.endswith(tld) for tld in SUSPICIOUS_TLDS):
            scores.append(35)
        elif any(domain.endswith(tld) for tld in HIGH_TRUST_TLDS) or any(d in domain for d in HIGH_TRUST_DOMAINS):
            scores.append(95)
        elif any(d in domain for d in ESTABLISHED_MEDIA):
            scores.append(88)
        elif any(domain.endswith(tld) for tld in TRUSTED_COMMERCIAL_TLDS):
            scores.append(78)
        else:
            scores.append(45)

    return round(sum(scores) / len(scores)) if scores else 80


def _lexical_grounding_ratio(statement: str, combined_ev: str) -> float:
    """Token-overlap grounding ratio, used when embeddings are unavailable."""
    words = [w for w in re.findall(r"\b\w{4,}\b", statement)]
    if not words:
        return 1.0
    matched = sum(1 for w in words if w in combined_ev)
    return min(1.0, (matched / len(words)) * 1.2)


def compute_rag_grounding_score(
    claims: Optional[List[Dict[str, Any]]] = None,
    evidence: Optional[List[Dict[str, Any]]] = None,
    claims_with_evidence: Optional[List[Dict[str, Any]]] = None,
) -> int:
    """
    Layer 2: RAG Grounding Verification.
    Measures how well each claim is actually present in its retrieved evidence.

    Two call shapes are supported:
      compute_rag_grounding_score(claims, evidence)   # shared evidence pool
      compute_rag_grounding_score(claims_with_evidence)  # per-claim evidence

    Prefers dense embedding similarity (cosine between the claim and its best
    supporting evidence chunk) and falls back to token overlap when no embedding
    provider is available, so a score is always produced.
    """
    claims = claims or claims_with_evidence or []
    if not claims:
        return 100

    shared_chunks: List[str] = []
    for e in evidence or []:
        if not isinstance(e, dict):
            continue
        chunk = f"{e.get('title', '')} {e.get('snippet', '')}".strip()
        if chunk:
            shared_chunks.append(chunk)

    grounding_ratios = []
    for item in claims:
        statement = (item.get("statement") or item.get("claim") or "").strip()
        evidence_list = shared_chunks or [
            f"{e.get('title', '')} {e.get('snippet', '')}".strip()
            for e in (item.get("evidence") or [])
            if isinstance(e, dict) and (e.get("snippet") or e.get("title"))
        ]
        if not statement:
            grounding_ratios.append(1.0)
            continue
        if not evidence_list:
            grounding_ratios.append(0.0)
            continue

        combined_ev = " ".join(evidence_list).lower()
        lexical = _lexical_grounding_ratio(statement.lower(), combined_ev)
        grounded = 0.0
        try:
            claim_vec = embed_text(statement)
            best = 0.0
            for chunk in evidence_list:
                sim = cosine_similarity(claim_vec, embed_text(chunk))
                if sim > best:
                    best = sim
            # Dense cosine for paraphrases in remote embeddings (Mistral/OpenAI) has a
            # baseline noise floor around ~0.60, whereas local hashed n-grams baseline around ~0.10.
            remote = is_remote_provider()
            floor = 0.60 if remote else 0.10
            ceil = 0.88 if remote else 0.50
            if best <= floor:
                grounded = 0.0
            else:
                grounded = min(1.0, (best - floor) / (ceil - floor))
        except Exception:  # noqa: BLE001
            grounded = 0.0
        grounding_ratios.append(max(grounded, lexical))

    avg_ratio = sum(grounding_ratios) / len(grounding_ratios) if grounding_ratios else 1.0
    return round(min(1.0, avg_ratio) * 100)


def evaluate_decision_risk(
    fact_check_score: Optional[int] = None,
    trust_score: Optional[int] = None,
    rag_grounding: Optional[int] = None,
    contradicted_count: int = 0,
    unsubstantiated_count: Optional[int] = None,
    verified_claims: Optional[List[Dict[str, Any]]] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    """
    Layer 3: Agent Decision Verification.
    Assesses factual risk to decide whether the dispatch can be auto-approved or
    must escalate to human review.

    Scores are 0-100: ``fact_check_score`` (faithfulness of claims to evidence),
    ``trust_score`` (Layer 4 source trust), ``rag_grounding`` (Layer 2 grounding).
    ``verified_claims`` is accepted for convenience so callers holding the claim
    list need not pre-count verdicts.
    """
    if fact_check_score is None:
        fact_check_score = int(kwargs.get("faithfulness_score", 100))
    if trust_score is None:
        trust_score = int(kwargs.get("source_trust_score", 80))
    if rag_grounding is None:
        rag_grounding = int(kwargs.get("grounding_score", 80))

    if verified_claims:
        contradicted_count = max(
            contradicted_count,
            sum(1 for c in verified_claims if str(c.get("verdict", "")).lower() == "contradicted"),
        )
        if unsubstantiated_count is None:
            unsubstantiated_count = sum(
                1 for c in verified_claims if str(c.get("verdict", "")).lower() == "unsubstantiated"
            )
    unsubstantiated_count = unsubstantiated_count or 0


    if contradicted_count > 0:
        risk_level = "High"
        routing = "human_review_required"
        reason = f"{contradicted_count} contradicted claim(s) detected; human editorial sign-off required."
    elif fact_check_score < 50:
        risk_level = "High"
        routing = "human_review_required"
        reason = f"Low factual grounding confidence ({fact_check_score}%); editorial review required."
    elif unsubstantiated_count >= 2 or fact_check_score < 80 or rag_grounding < 60 or trust_score < 60:
        risk_level = "Moderate"
        routing = "human_review_recommended"
        if unsubstantiated_count > 0:
            reason = f"{unsubstantiated_count} claim(s) unverified by search; editorial review recommended."
        else:
            reason = "Verification confidence is below the auto-approve threshold; editorial review recommended."
    else:
        risk_level = "Low"
        routing = "auto_approve_eligible"
        reason = "All empirical claims verified with high confidence against authoritative sources."

    return {
        "risk_level": risk_level,
        "routing_action": routing,
        "reasoning": reason,
        "fact_check_score": fact_check_score,
        "faithfulness_score": fact_check_score,
        "grounding_score": rag_grounding,
        "rag_grounding": rag_grounding,
        "source_trust_score": trust_score,
        "trust_score": trust_score,
        "contradiction_count": contradicted_count,
        "unsubstantiated_count": unsubstantiated_count,
    }


def auto_correct_draft_claims(draft: str, verified_claims: List[Dict[str, Any]]) -> str:
    """
    Applies targeted revisions to the draft for any claims flagged as Contradicted.
    """
    contradictions = [c for c in verified_claims if c.get("verdict", "").lower() == "contradicted" and c.get("correction")]
    if not contradictions:
        return draft

    logger.info(f"Auto-correcting {len(contradictions)} contradicted claims in draft.")
    corrections_instructions = "\n".join([
        f"- Replace incorrect claim: \"{c['statement']}\" with verified fact: \"{c['correction']}\""
        for c in contradictions
    ])

    prompt = f"""
You are an expert copy editor fixing factual inaccuracies in an article.
Apply these specific factual corrections without changing the tone or structure of the rest of the text:

Corrections to apply:
{corrections_instructions}

Article Draft:
{draft}

Output the complete, corrected Markdown article only.
"""
    try:
        corrected = call_llm(prompt, temperature=0.2)
        cleaned = clean_article_content(corrected.strip())
        if len(cleaned) > len(draft) * 0.7:
            return cleaned
    except Exception as e:
        logger.error(f"Error auto-correcting draft claims: {e}")

    return draft


def reflexion_critique_pass(draft: str, verified_claims: List[Dict[str, Any]], risk_notes: str) -> str:
    """
    Reflexion Loop (Pillar III: Architectural Escalation).
    Performs an autonomous self-critique and revision loop when fact-checking detects significant risk.
    """
    weak_claims = [c for c in verified_claims if c.get("verdict", "").lower() in ("contradicted", "unsubstantiated")]
    if not weak_claims:
        return draft

    critique_list = "\n".join([
        f"- Issue with claim: '{c.get('statement')}': {c.get('reasoning')} -> Remedy: {c.get('correction') or 'Ground claim in verifiable consensus or remove exaggeration.'}"
        for c in weak_claims
    ])

    prompt = f"""
You are a Lead Fact-Check Editor executing an autonomous Reflexion self-critique loop.
Revise the following article draft to resolve these specific factual weaknesses while preserving the core voice and structure:

Fact-Check Critique:
{critique_list}

Risk Assessment:
{risk_notes}

Original Draft:
{draft}

Output ONLY the revised, factually grounded Markdown article.
"""
    try:
        revised = call_llm(prompt, temperature=0.2)
        cleaned = clean_article_content(revised.strip())
        if len(cleaned) > len(draft) * 0.7:
            logger.info("Reflexion self-critique loop successfully refined draft.")
            return cleaned
    except Exception as e:
        logger.error(f"Error during Reflexion critique pass: {e}")

    return draft


def fact_check_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: Invokes the Fact Verification Sub-Graph (Pillar A4).
    Dataflow:
    Extract Claims (body, titles, meta descriptions, schema, alt text)
    -> Multi-Source Evidence Search (>= 2 independent domains, passage hashing)
    -> Model Verdict (ROLE_VERIFICATION strong model)
    -> Deterministic Policy Engine (Plain Python, rewritten/removed stats, human approval gates)
    -> Verification Report Generation
    """
    from pipeline.adapters.fact_verification_subgraph import (
        build_fact_verification_subgraph,
        run_fact_verification_subgraph,
    )

    draft = state.get("draft") or ""
    logger.info("Initiating LangGraph Fact Verification Sub-Graph pass (Pillar A4)...")

    if not draft or len(draft.strip()) < 150:
        logger.info("Draft is empty or too short for fact checking; bypassing.")
        empty_report = {
            "promise": "every claim sourced and auditable",
            "disclaimer": "Empirical verification with precision/recall benchmarking (A10 ready); never zero hallucinations.",
            "total_claims": 0,
            "supported_count": 0,
            "contradicted_count": 0,
            "unsubstantiated_count": 0,
            "regulated_or_high_risk_count": 0,
            "fact_check_score": 100,
            "overall_verdict": "supported",
            "requires_human_approval": False,
            "named_human_approver": None,
            "audited_metadata": {
                "title": state.get("title"),
                "meta_description": state.get("meta_description"),
                "schema_snippet_audited": False,
                "alt_text": None,
                "google_oct_2026_guidance_compliant": True,
            },
            "claims_audit": [],
            "policy_actions": [],
        }
        return {
            "verified_claims": [],
            "fact_check_score": 100,
            "fact_check_verdict": "supported",
            "verification_report": empty_report,
            "requires_human_approval": False,
            "named_human_approver": None,
            "fact_check_escalated": False,
            "verification_layers": {
                "hallucination_score": 100,
                "grounding_score": 100,
                "source_trust_score": 85,
                "decision_risk_level": "Low",
                "routing_action": "auto_approve_eligible"
            }
        }

    # Prepare input for the Fact-Verification Sub-Graph
    title = state.get("title") or state.get("meta_title") or ""
    meta_desc = state.get("meta_description") or ""
    schema_snippet = state.get("schema_snippet") or ""
    alt_text = (state.get("design_guide") or {}).get("hero_image_alt") or state.get("image_prompt") or ""
    tenant_id = state.get("website_id") or "default"

    subgraph_input = {
        "draft": draft,
        "title": title,
        "meta_description": meta_desc,
        "schema_snippet": schema_snippet,
        "alt_text": alt_text,
        "tenant_id": tenant_id,
        "tenant_trust_config": None,
        "extracted_claims": None,
        "claims_with_evidence": None,
        "claim_verdicts": None,
        "policy_actions": None,
        "updated_draft": None,
        "updated_title": None,
        "updated_meta_description": None,
        "updated_schema_snippet": None,
        "updated_alt_text": None,
        "verified_claims": None,
        "verification_report": None,
        "fact_check_score": None,
        "fact_check_verdict": None,
        "requires_human_approval": None,
        "named_human_approver": None,
        "escalated": None,
    }

    sub_res = None
    try:
        subgraph = build_fact_verification_subgraph()
        sub_res = subgraph.invoke(subgraph_input)
    except Exception as sub_err:
        logger.info(f"Fact verification sub-graph invoke failed ({sub_err}); proceeding with thread-safe direct runner.")
        try:
            sub_res = run_fact_verification_subgraph(subgraph_input)
        except Exception as direct_err:
            logger.warning(f"Direct fact runner failed: {direct_err}. Executing legacy heuristic fallback.")
            claims = extract_verifiable_claims(draft)
            enriched_claims = gather_evidence_for_claims(claims)
            evaluation = evaluate_claims_verdict(enriched_claims)
            verified_claims = evaluation.get("verified_claims", [])
            overall_verdict = evaluation.get("overall_verdict", "supported")
            faithfulness_score = evaluation.get("fact_check_score", 100)
            updated_draft = auto_correct_draft_claims(draft, verified_claims)
            grounding_score = compute_rag_grounding_score(enriched_claims)
            source_trust_score = compute_source_trust_score([s for c in enriched_claims for s in c.get("evidence", [])])
            decision = evaluate_decision_risk(faithfulness_score, source_trust_score, grounding_score, verified_claims=verified_claims)
            return {
                "draft": updated_draft,
                "verified_claims": verified_claims,
                "fact_check_score": faithfulness_score,
                "fact_check_verdict": overall_verdict,
                "verification_report": {
                    "promise": "every claim sourced and auditable",
                    "fact_check_score": faithfulness_score,
                    "overall_verdict": overall_verdict,
                    "claims_audit": verified_claims,
                },
                "verification_layers": {
                    "hallucination_score": faithfulness_score,
                    "grounding_score": grounding_score,
                    "source_trust_score": source_trust_score,
                    "decision_risk_level": decision["risk_level"],
                    "routing_action": decision["routing_action"],
                }
            }

    # Extract verified outputs from the Sub-Graph
    updated_draft = sub_res.get("updated_draft") or draft
    updated_title = sub_res.get("updated_title") or title
    updated_meta_desc = sub_res.get("updated_meta_description") or meta_desc
    verification_report = sub_res.get("verification_report") or {}
    verified_claims = sub_res.get("verified_claims") or verification_report.get("claims_audit") or []
    fact_check_score = sub_res.get("fact_check_score", 100)
    fact_check_verdict = sub_res.get("fact_check_verdict", "supported")
    requires_human_approval = sub_res.get("requires_human_approval", False)
    named_human_approver = sub_res.get("named_human_approver")
    escalated = sub_res.get("escalated", False)

    # Compute 4-Layer Verification Framework telemetry
    # Layer 1: Hallucination Detection (faithfulness_score)
    claims_with_ev = sub_res.get("claims_with_evidence") or []
    grounding_score = compute_rag_grounding_score(claims_with_ev)
    all_evidence_sources = [ev for c in claims_with_ev for ev in c.get("evidence", [])]
    source_trust_score = compute_source_trust_score(all_evidence_sources)

    decision = evaluate_decision_risk(
        fact_check_score=fact_check_score,
        trust_score=source_trust_score,
        rag_grounding=grounding_score,
        verified_claims=verified_claims,
    )

    # Extract citations
    citations = []
    for c in verified_claims:
        if c.get("source_url") and str(c.get("verdict", "")).lower() == "supported":
            citations.append({
                "statement": c.get("statement"),
                "url": c.get("source_url"),
                "supporting_span": c.get("supporting_span"),
            })

    verification_layers = {
        "hallucination_score": fact_check_score,
        "grounding_score": grounding_score,
        "source_trust_score": source_trust_score,
        "decision_risk_level": decision["risk_level"],
        "routing_action": "human_review_required" if requires_human_approval else decision["routing_action"],
        "reasoning": decision["reasoning"],
    }

    logger.info(
        f"Fact-Check Sub-Graph Complete: Verdict={fact_check_verdict}, Score={fact_check_score}% "
        f"(RequiresApproval={requires_human_approval}, Approver={named_human_approver}, ClaimsAudited={len(verified_claims)})"
    )

    out_dict: Dict[str, Any] = {
        "draft": updated_draft,
        "title": updated_title,
        "meta_description": updated_meta_desc,
        "verified_claims": verified_claims,
        "verification_report": verification_report,
        "fact_check_score": fact_check_score,
        "fact_check_verdict": fact_check_verdict,
        "requires_human_approval": requires_human_approval,
        "named_human_approver": named_human_approver,
        "fact_check_escalated": escalated,
        "verification_layers": verification_layers,
        "source_citations": citations,
    }
    return out_dict


