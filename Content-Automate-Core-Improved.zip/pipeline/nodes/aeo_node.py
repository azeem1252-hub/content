"""
A5b: AEO (Answer Engine Optimization) LangGraph Node.

Runs question discovery, eligibility gating, answer-block generation,
click-worthiness analysis, FAQ module, and measurement snapshot assembly.
Attaches the full AEO report to ContentState.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from pipeline.state import ContentState
from pipeline.adapters.aeo_engine import (
    AEOConfig,
    EntityLayerConfig,
    run_aeo_analysis,
    infer_format_from_serp,
    SnippetFormat,
)
from pipeline.adapters.question_naturalizer import (
    clean_double_question,
    naturalize_question,
)

logger = logging.getLogger("pipeline.nodes.aeo_node")


def _extract_paa_questions(search_sources: Optional[List[dict]]) -> List[str]:
    """
    Extracts People Also Ask questions from the Tavily search sources.
    Tavily returns PAA-style questions in 'related_questions' or 'paa' keys.
    """
    if not search_sources:
        return []
    questions: List[str] = []
    for src in search_sources:
        for q in src.get("related_questions", []) + src.get("paa", []):
            raw_q = ""
            if isinstance(q, str) and q.strip():
                raw_q = q.strip()
            elif isinstance(q, dict) and q.get("question"):
                raw_q = str(q["question"]).strip()
            if raw_q:
                clean_q = naturalize_question(clean_double_question(raw_q))
                questions.append(clean_q)
    return list(dict.fromkeys(questions))  # dedup, preserve order


def _extract_related_searches(search_sources: Optional[List[dict]]) -> List[str]:
    """Extracts related searches from Tavily search source metadata."""
    if not search_sources:
        return []
    searches: List[str] = []
    for src in search_sources:
        for s in src.get("related_searches", []):
            if isinstance(s, str) and s.strip():
                searches.append(s.strip())
    return list(dict.fromkeys(searches))


def _build_snippet_data(search_sources: Optional[List[dict]], keywords: List[str]) -> Dict[str, Dict[str, Any]]:
    """
    Builds a snippet_data map from SERP source metadata:
    { keyword: { format: str, owner_domain: str } }
    """
    if not search_sources:
        return {}
    snippet_data: Dict[str, Dict[str, Any]] = {}
    for src in search_sources:
        kw = src.get("query", "")
        if not kw:
            continue
        snippet_type = src.get("snippet_type") or src.get("answer_type", "")
        snippet_text = src.get("snippet", "")
        fmt = infer_format_from_serp(snippet_text).value if snippet_text else snippet_type or "unknown"
        owner = ""
        url = src.get("snippet_url") or (src.get("results") or [{}])[0].get("url", "")
        if url:
            try:
                from urllib.parse import urlparse
                owner = urlparse(url).netloc.lower().replace("www.", "")
            except Exception:
                pass
        snippet_data[kw] = {"format": fmt, "owner_domain": owner}
    return snippet_data


def _build_rank_data(search_sources: Optional[List[dict]], our_domain: str) -> Dict[str, int]:
    """
    Infers organic rank from SERP result positions in search_sources.
    If our URL appears in position N, records it.
    """
    if not search_sources or not our_domain:
        return {}
    rank_data: Dict[str, int] = {}
    for src in search_sources:
        kw = src.get("query", "")
        if not kw:
            continue
        for i, result in enumerate(src.get("results", []), start=1):
            url = result.get("url", "")
            if our_domain.lower() in url.lower():
                rank_data[kw] = i
                break
    return rank_data


def aeo_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: A5b Answer Engine Optimization.
    Reads pipeline state and produces aeo_report, answer_blocks, faq_items.
    """
    draft = state.get("draft") or ""
    keywords = state.get("keywords") or []
    topic = state.get("topic") or (keywords[0] if keywords else "")
    search_sources = state.get("search_sources")
    published_url = state.get("published_url") or state.get("destination_url") or ""
    website_id = state.get("website_id")
    slug = state.get("slug") or ""

    # Load website profile if website_id available
    site = None
    if website_id:
        try:
            from storage.db import get_website_by_id
            site = get_website_by_id(website_id)
        except Exception as e:
            logger.debug("Could not load site from DB: %s", e)

    # Extract our domain
    our_domain = ""
    if published_url:
        try:
            from urllib.parse import urlparse
            our_domain = urlparse(published_url).netloc.lower().replace("www.", "")
        except Exception:
            pass

    if not our_domain and site and site.get("url"):
        try:
            from urllib.parse import urlparse
            our_domain = urlparse(site["url"]).netloc.lower().replace("www.", "")
        except Exception:
            pass

    # Load per-tenant AEO config if available
    tenant_cfg = site.get("aeo_config", {}) if site else {}
    config = AEOConfig(**tenant_cfg) if tenant_cfg else AEOConfig()

    # Build entity layer config from site
    entity_cfg = None
    if site:
        entity_cfg = EntityLayerConfig(
            organization_name=site.get("name"),
            organization_url=site.get("url"),
            organization_logo=site.get("logo_url"),
            google_business_profile_url=site.get("google_business_profile_url"),
            wikidata_id=site.get("wikidata_id"),
            same_as_links=site.get("same_as_links", []),
            is_local_brand=bool(site.get("is_local_brand") or site.get("google_business_profile_url")),
        )

    # Build inputs
    paa_questions = _extract_paa_questions(search_sources)
    related_searches = _extract_related_searches(search_sources)
    snippet_data = _build_snippet_data(search_sources, keywords)
    rank_data = _build_rank_data(search_sources, our_domain)

    # GSC question queries: attach from state if keyword research node populated them
    gsc_queries = state.get("gsc_question_queries") or []

    logger.info(
        "AEO node: topic='%s', %d keywords, %d PAA, %d related, %d gsc, rank_data=%s",
        topic, len(keywords), len(paa_questions), len(related_searches), len(gsc_queries),
        rank_data,
    )

    try:
        aeo_result = run_aeo_analysis(
            article_keyword=topic,
            keywords=keywords,
            draft=draft,
            paa_questions=paa_questions,
            related_searches=related_searches,
            gsc_question_queries=gsc_queries,
            our_url=published_url or None,
            rank_data=rank_data,
            snippet_data=snippet_data,
            entity_config=entity_cfg,
            search_sources=search_sources,
            config=config,
        )

        # Persist targets and answer blocks to DB if website_id is present
        if website_id and aeo_result.get("aeo_report"):
            try:
                from storage.db import upsert_answer_target, upsert_answer_block
                for t in aeo_result.get("eligible_targets", []) + aeo_result.get("near_miss_targets", []):
                    t_dict = dict(t)
                    t_dict["website_id"] = website_id
                    upsert_answer_target(t_dict)
                for b in aeo_result.get("answer_blocks", []):
                    b_dict = dict(b)
                    b_dict["website_id"] = website_id
                    b_dict["post_slug"] = slug
                    upsert_answer_block(b_dict)
            except Exception as e:
                logger.warning("Failed to persist AEO targets/blocks to DB: %s", e)

    except Exception as exc:
        logger.error("AEO analysis failed: %s", exc, exc_info=True)
        aeo_result = {
            "aeo_report": None,
            "answer_blocks": [],
            "faq_items": [],
            "eligible_targets": [],
            "near_miss_targets": [],
            "not_eligible_targets": [],
            "entity_layer": None,
            "error": str(exc),
        }

    return {
        "aeo_report": aeo_result.get("aeo_report"),
        "answer_blocks": aeo_result.get("answer_blocks", []),
        "aeo_faq_items": aeo_result.get("faq_items", []),
        "aeo_eligible_targets": aeo_result.get("eligible_targets", []),
        "aeo_near_miss_targets": aeo_result.get("near_miss_targets", []),
        "aeo_not_eligible_targets": aeo_result.get("not_eligible_targets", []),
        "aeo_entity_layer": aeo_result.get("entity_layer"),
        "aeo_click_worthiness": aeo_result.get("click_worthiness", []),
        "aeo_faqpage_schema": aeo_result.get("faqpage_schema"),
        "aeo_config": aeo_result.get("config"),
    }
