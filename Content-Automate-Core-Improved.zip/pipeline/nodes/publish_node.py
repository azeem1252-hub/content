import os
import re
import json
import logging
import subprocess
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Tuple, List
from pathlib import Path
import config
from pipeline.state import ContentState
from pipeline.adapters.website_client import publish_to_nextjs
from pipeline.adapters.schema_builder import build_json_ld_schemas
from pipeline.adapters.indexnow_client import submit_indexnow_urls
from pipeline.adapters.llms_txt_builder import sync_llms_txt_to_targets
from pipeline.utils import resolve_full_published_url
from storage.db import resolve_run_website, save_post
from pipeline.adapters.cms_publishers import (
    CMSPublishCoordinator,
    CMSArticlePayload,
    CMSMetadata,
    CMSMediaAsset,
    get_cms_adapter,
)
from pipeline.adapters.publish_modes import (
    PublishMode,
    ReviewerAttestation,
    SitePublishConfig,
    compute_dedupe_key,
)

logger = logging.getLogger("pipeline.nodes.publish")

# Persistent-storage engine hints: substrings matched (case-insensitively)
# against each engine name the site reports in its publish response, e.g.
# {"engines": ["cloudflare_kv"]}. Serverless platforms persist in different
# places than classic SQL databases - Cloudflare Workers/Pages store in KV,
# D1 or R2 - and an `auto`-storage site must not trigger a pointless GitHub
# commit when its own endpoint already durably stored the article.
_PERSISTENT_STORAGE_HINTS = (
    "database", "upstash", "redis", "prisma", "supabase", "postgres",
    "mysql", "sqlite", "libsql", "turso", "neon", "mongo", "firebase",
    "firestore", "dynamo", "elasticsearch", "meilisearch", "cockroach",
    "cassandra", "memcached", "xata", "fauna", "durable", "sql", "db",
)
# Short names like Cloudflare's "kv", "d1" and "r2" are only trusted as
# whole tokens so an unrelated value ("wrangler2") cannot match by accident.
_PERSISTENT_STORAGE_TOKENS = frozenset({"kv", "d1", "r2"})


def engines_indicate_persistent_storage(engines: Any) -> bool:
    """True when the endpoint-reported engines include durable storage.

    Recognizes classic databases (Prisma/Postgres/Supabase/Upstash) as well
    as serverless-native stores (Cloudflare KV/D1/R2, Durable Objects), so
    publishing to a Cloudflare Worker or Pages Function that keeps articles
    in KV/D1 skips the git fallback commit.
    """
    for engine in engines or []:
        name = str(engine).lower()
        if any(hint in name for hint in _PERSISTENT_STORAGE_HINTS):
            return True
        tokens = {tok for tok in re.split(r"[^a-z0-9]+", name) if tok}
        if tokens & _PERSISTENT_STORAGE_TOKENS:
            return True
    return False


def _render_mdx_article(
    title: str, slug: str, excerpt: str, meta_title: str,
    meta_description: str, hero_image_url: str, tags: list,
    author: str, published_at: str, content: str
) -> str:
    """Renders the canonical .mdx artifact so the git path and the GitHub
    Contents-API fallback always commit the same complete file pair."""
    fm = [
        "---",
        f"title: {json.dumps(title)}",
        f"slug: {json.dumps(slug)}",
        f"excerpt: {json.dumps(excerpt)}",
        f"meta_title: {json.dumps(meta_title or title)}",
        f"meta_description: {json.dumps(meta_description or excerpt)}",
        f"hero_image_url: {json.dumps(hero_image_url)}",
        f"tags: {json.dumps(tags or [])}",
        f"author: {json.dumps(author or 'The Dispatch Editorial Bureau')}",
        f"publishedAt: {json.dumps(published_at)}",
        "---",
        "",
        content,
    ]
    return "\n".join(fm)


def _git_probe(args: list, cwd: Path, timeout: int = 10, env: Optional[dict] = None):
    """Runs a git command and returns the completed process, or None when git
    could not even be launched (missing binary, timeout).

    Callers must inspect the return code themselves: an unproven git state is
    never treated as success.
    """
    try:
        return subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
    except Exception as git_err:
        logger.debug(f"git {' '.join(args)} could not run in {cwd}: {git_err}")
        return None


def _render_markdown_html(content: str) -> str:
    try:
        import markdown
        return markdown.markdown(
            content,
            extensions=["fenced_code", "tables", "nl2br", "sane_lists"]
        )
    except Exception:
        return ""


def _discover_local_nextjs_dirs(target_site: Optional[dict] = None) -> list:
    """Discovers candidate local Next.js project directories that use the
    content/posts storage layout. Matches target website repo name if provided.
    Preference order:
      1. NEXTJS_LOCAL_DIR env var (explicit override)
      2. Sibling or child directories matching target site repo/name
      3. Any directory containing content/posts
    """
    from config import BASE_DIR

    override = os.getenv("NEXTJS_LOCAL_DIR", "").strip()
    if override:
        p = Path(override)
        if (p / "content" / "posts").exists() or (p / "public").exists():
            return [p]
        return []

    if target_site:
        for field in ("local_dir", "repo_path", "local_path", "project_dir"):
            val = str(target_site.get(field) or "").strip()
            if val:
                p = Path(val)
                if p.exists() and p.is_dir():
                    return [p.resolve()]

    target_repo_folder = ""
    site_name_clean = ""
    if target_site and target_site.get("github_repo"):
        target_repo_folder = target_site["github_repo"].split("/")[-1].strip().lower()
    if target_site and target_site.get("name"):
        site_name_clean = target_site["name"].strip().lower()
        if not target_repo_folder:
            target_repo_folder = site_name_clean.replace(" ", "-")

    target_url = (target_site.get("url") or "") if target_site else ""
    is_local_dev = "localhost" in target_url or "127.0.0.1" in target_url

    seen = set()
    base = BASE_DIR.resolve()

    search_roots = [
        base,
        base.parent,
    ]

    search_dirs = []
    for root in search_roots:
        try:
            if root and root.exists() and root.is_dir():
                search_dirs.extend([s for s in root.iterdir() if s.is_dir()])
        except Exception:
            pass

    matched_dirs = []
    for d in search_dirs:
        try:
            # Check for signature Next.js project markers
            has_posts_dir = (d / "content" / "posts").exists()
            has_api_route = (d / "app" / "api" / "posts").exists() or (d / "src" / "app" / "api" / "posts").exists()
            has_next_config = (d / "next.config.mjs").exists() or (d / "next.config.ts").exists() or (d / "next.config.js").exists()

            has_public_uploads = (d / "public" / "uploads").exists()

            if not (has_posts_dir or has_api_route or has_next_config or has_public_uploads):
                continue

            rp = d.resolve()
            if rp in seen:
                continue
            seen.add(rp)

            d_name = d.name.lower()
            name_tokens = set(re.split(r"[-_\s]+", d_name))
            site_tokens = set(re.split(r"[-_\s]+", site_name_clean)) | set(re.split(r"[-_\s]+", target_repo_folder))

            is_match = False
            if target_repo_folder and (d_name == target_repo_folder or target_repo_folder in d_name or d_name in target_repo_folder):
                is_match = True
            elif site_tokens and (name_tokens & site_tokens):
                is_match = True
            elif is_local_dev and (has_api_route or has_posts_dir or has_public_uploads):
                # When developing locally and target matches localhost, prioritize local Next.js sites with content/posts or public/uploads
                is_match = True

            if is_match:
                matched_dirs.append(rp)
        except Exception:
            pass

    return matched_dirs


def _sync_hero_image_to_local_targets(hero_image_url: Optional[str], target_site: Optional[dict] = None) -> None:
    """Copies generated hero image and all rendered diagram SVGs into target Next.js public/uploads/ directories."""
    import shutil
    from config import BASE_DIR

    candidate_dirs = _discover_local_nextjs_dirs(target_site)
    if not candidate_dirs:
        return

    # 1. Sync hero image if present
    if hero_image_url:
        img_name = Path(hero_image_url).name
        source_img = BASE_DIR / "web" / "static" / "uploads" / img_name
        if source_img.exists() and source_img.stat().st_size > 0:
            for c_dir in candidate_dirs:
                try:
                    dest_dir = c_dir / "public" / "uploads"
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest_file = dest_dir / img_name
                    if not dest_file.exists() or dest_file.stat().st_size != source_img.stat().st_size:
                        shutil.copy2(source_img, dest_file)
                        logger.info(f"Synchronized hero image '{img_name}' to local Next.js project at: {dest_file}")
                except Exception as err:
                    logger.debug(f"Failed to copy hero image to {c_dir}: {err}")

    # 2. Sync all rendered diagram SVGs from static/uploads/diagrams
    source_diagrams_dir = BASE_DIR / "web" / "static" / "uploads" / "diagrams"
    if source_diagrams_dir.exists() and source_diagrams_dir.is_dir():
        for svg_file in source_diagrams_dir.glob("*.svg"):
            for c_dir in candidate_dirs:
                try:
                    dest_diag_dir = c_dir / "public" / "uploads" / "diagrams"
                    dest_diag_dir.mkdir(parents=True, exist_ok=True)
                    dest_svg = dest_diag_dir / svg_file.name
                    if not dest_svg.exists() or dest_svg.stat().st_size != svg_file.stat().st_size:
                        shutil.copy2(svg_file, dest_svg)
                        logger.info(f"Synchronized diagram asset '{svg_file.name}' to local Next.js project at: {dest_svg}")
                except Exception as err:
                    logger.debug(f"Failed to copy diagram {svg_file.name} to {c_dir}: {err}")


def prerender_and_publish_diagrams(
    content: str,
    slug: str,
    target_site: Optional[dict] = None
) -> Tuple[str, list]:
    """
    Renders all Mermaid / flowchart / sequence diagrams embedded in article Markdown into
    clean, standalone, high-contrast vector SVGs.
    
    1. Writes each SVG to web/static/uploads/diagrams/<slug>-diagram-<id>.svg
    2. Syncs each SVG into all candidate local Next.js targets at public/uploads/diagrams/
    3. Replaces the raw ```mermaid code block in the Markdown with a semantic HTML <figure>
       containing <img src="/uploads/diagrams/...svg" ... /> and <figcaption>.
       
    This eliminates ANY client-side Mermaid.js dependency on user websites, ensuring
    every diagram renders immediately and crisply in 100% of browsers and CMS platforms.
    """
    if not content or ("```mermaid" not in content.lower() and "graph " not in content):
        return content, []

    import shutil
    from config import BASE_DIR
    from pipeline.adapters.article_model import validate_mermaid_syntax, render_mermaid_to_svg

    pattern = re.compile(r"```(?:mermaid|d2|graphviz)?\s*\n((?:graph\s+[A-Za-z]+|flowchart\s+[A-Za-z]+|sequenceDiagram|classDiagram|stateDiagram|erDiagram|gantt|%%)[\s\S]*?)```", re.IGNORECASE)
    
    # Also support general ```mermaid blocks even without explicit diagram header
    general_mermaid_pattern = re.compile(r"```mermaid\s*\n([\s\S]*?)```", re.IGNORECASE)

    active_pattern = pattern if pattern.search(content) else general_mermaid_pattern
    if not active_pattern.search(content):
        return content, []

    static_dir = BASE_DIR / "web" / "static" / "uploads" / "diagrams"
    static_dir.mkdir(parents=True, exist_ok=True)

    candidate_dirs = _discover_local_nextjs_dirs(target_site)

    diagram_counter = 0
    rendered_diagrams = []

    def _replace_diagram(match: re.Match) -> str:
        nonlocal diagram_counter
        diagram_counter += 1
        raw_code = match.group(1).strip()
        clean_slug = re.sub(r"[^a-z0-9]+", "-", slug.lower()).strip("-") or "diagram"
        filename = f"{clean_slug}-diagram-{diagram_counter}.svg"

        # Derive a human-readable title from preceding context or slug
        title = f"{slug.replace('-', ' ').title()} Architectural Workflow {diagram_counter}"
        
        valid, err = validate_mermaid_syntax(raw_code)
        svg_content = render_mermaid_to_svg(raw_code, title=title) if valid else render_mermaid_to_svg(raw_code, title="System Architecture Workflow")

        # 1. Write to local studio static uploads
        svg_file_path = static_dir / filename
        svg_file_path.write_text(svg_content, encoding="utf-8")

        # 2. Sync to candidate local Next.js public uploads
        for c_dir in candidate_dirs:
            try:
                dest_diag_dir = c_dir / "public" / "uploads" / "diagrams"
                dest_diag_dir.mkdir(parents=True, exist_ok=True)
                dest_file = dest_diag_dir / filename
                dest_file.write_text(svg_content, encoding="utf-8")
                logger.info(f"Synchronized pre-rendered diagram '{filename}' to {dest_file}")
            except Exception as sync_err:
                logger.debug(f"Could not copy diagram to {c_dir}: {sync_err}")

        img_url = f"/uploads/diagrams/{filename}"
        rendered_diagrams.append({
            "url": img_url,
            "filename": filename,
            "title": title,
            "valid": valid,
        })

        return (
            f'<figure class="article-diagram my-8">\n'
            f'  <img src="{img_url}" alt="{title}" class="w-full rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm" width="100%" height="auto" loading="lazy" />\n'
            f'  <figcaption class="text-center text-xs text-slate-500 mt-2">{title}</figcaption>\n'
            f'</figure>'
        )

    updated_content = active_pattern.sub(_replace_diagram, content)
    return updated_content, rendered_diagrams


def _sync_local_nextjs_repo(
    slug: str, title: str, content: str, excerpt: str,
    meta_title: str, meta_description: str, hero_image_url: str,
    tags: list, author: str, published_at: str,
    target_site: Optional[dict] = None
) -> bool:
    """Syncs the published article into the website's GitHub repository.
    First writes to local matching Next.js clone (if present) and pushes,
    or falls back to GitHub Contents REST API commit.

    Uses per-website github_repo, github_branch, and github_token when available.
    Returns True when the article successfully reached GitHub.
    """
    if target_site:
        # Git-backed websites must use their own destination and credentials;
        # global repository settings can otherwise cross-publish between sites.
        gh_token = (target_site.get("github_token") or "").strip()
        repo_name = (target_site.get("github_repo") or "").strip().replace("https://github.com/", "").strip("/")
        branch_name = (target_site.get("github_branch") or "main").strip() or "main"
    else:
        # Preserve the standalone archive fallback when no website is selected.
        gh_token = (os.getenv("GITHUB_TOKEN", "") or getattr(config, "GITHUB_TOKEN", "")).strip()
        repo_name = (os.getenv("GITHUB_REPO", "") or getattr(config, "GITHUB_REPO", "")).strip().replace("https://github.com/", "").strip("/")
        branch_name = (os.getenv("GITHUB_BRANCH", "") or getattr(config, "GITHUB_BRANCH", "main")).strip() or "main"

    if not gh_token or not repo_name:
        logger.info(
            f"GitHub sync skipped for '{slug}': "
            f"{'github_repo not specified' if not repo_name else 'GITHUB_TOKEN not configured'}."
        )
        return False

    from config import BASE_DIR
    import shutil

    # Ensure hero_image_url uses /uploads/ format for Next.js
    clean_hero_url = hero_image_url or ""
    if clean_hero_url.startswith("/static/uploads/"):
        clean_hero_url = clean_hero_url.replace("/static/uploads/", "/uploads/")

    rendered_html = _render_markdown_html(content)
    article_data = {
        "title": title,
        "slug": slug,
        "content": content,
        "html": rendered_html,
        "excerpt": excerpt,
        "meta_title": meta_title or title,
        "meta_description": meta_description or excerpt,
        "hero_image_url": clean_hero_url,
        "tags": tags or [],
        "author": author or "The Dispatch Editorial Bureau",
        "publishedAt": published_at,
    }

    try:
        from pipeline.adapters.schema_builder import build_json_ld_graph
        article_data["json_ld"] = build_json_ld_graph(
            title=title,
            slug=slug,
            content=content,
            meta_description=meta_description or excerpt,
            hero_image_url=clean_hero_url,
            author_name=author,
            publisher_name=(target_site.get("name") if target_site else "Dispatch Media Group"),
            tags=tags,
        )
    except Exception as sch_err:
        logger.debug(f"JSON-LD graph generation notice: {sch_err}")

    push_succeeded = False
    try:
        candidate_dirs = _discover_local_nextjs_dirs(target_site)
        for candidate_dir in candidate_dirs:
            # 1. Sync hero image file into public/uploads/
            if hero_image_url:
                img_name = Path(hero_image_url).name
                source_img = BASE_DIR / "web" / "static" / "uploads" / img_name
                if source_img.exists():
                    dest_dir = candidate_dir / "public" / "uploads"
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest_file = dest_dir / img_name
                    if not dest_file.exists() or dest_file.stat().st_size == 0:
                        try:
                            shutil.copy2(source_img, dest_file)
                            logger.info(f"Copied hero image {img_name} to {dest_file}")
                        except Exception as cp_err:
                            logger.debug(f"Copy image error: {cp_err}")

            # 2. Write content files
            posts_dir = candidate_dir / "content" / "posts"
            posts_dir.mkdir(parents=True, exist_ok=True)

            json_path = posts_dir / f"{slug}.json"
            json_path.write_text(json.dumps(article_data, indent=2), encoding="utf-8")

            mdx_path = posts_dir / f"{slug}.mdx"
            mdx_path.write_text(
                _render_mdx_article(
                    title=title, slug=slug, excerpt=excerpt,
                    meta_title=meta_title, meta_description=meta_description,
                    hero_image_url=clean_hero_url, tags=tags,
                    author=author, published_at=published_at, content=content
                ),
                encoding="utf-8"
            )
            logger.info(f"Synced article to local Next.js repo at {json_path}")

            # 3. Probe the remote branch before touching the index. A stale
            #    clone would race (and lose to) any newer remote commit, and a
            #    clone carrying unrelated unpushed commits would publish work
            #    that isn't ours — both defer to the Contents-API fallback,
            #    which always commits on top of the live branch tip.
            remote_url = f"https://github.com/{repo_name}.git"
            helper = f'!f() {{ echo "username=x-access-token"; echo "password={gh_token}"; }}; f'
            env = dict(os.environ)
            env["GIT_TERMINAL_PROMPT"] = "0"
            env["GIT_CONFIG_COUNT"] = "1"
            env["GIT_CONFIG_KEY_0"] = "credential.helper"
            env["GIT_CONFIG_VALUE_0"] = helper
            artifact_rel = f"content/posts/{slug}.json"
            branch_is_current = True
            # None means the remote state is unknown (fetch failed) — push is
            # then only allowed when we created a fresh commit ourselves.
            ahead_count: Optional[int] = None
            remote_artifact = False
            try:
                fetch_res = subprocess.run(
                    ["git", "fetch", "--quiet", remote_url, branch_name],
                    cwd=str(candidate_dir), check=False, capture_output=True, text=True, timeout=20, env=env
                )
                if fetch_res.returncode == 0:
                    behind_res = _git_probe(["rev-list", "--count", "HEAD..FETCH_HEAD"], candidate_dir)
                    behind_count = (behind_res.stdout or "").strip() if behind_res else ""
                    if behind_res and behind_res.returncode == 0 and behind_count.isdigit() and int(behind_count) > 0:
                        branch_is_current = False
                        logger.warning(
                            f"Local clone at {candidate_dir} is {behind_count} commit(s) behind "
                            f"{repo_name}:{branch_name}; using the Contents-API fallback to publish on the branch tip."
                        )
                    ahead_res = _git_probe(["rev-list", "--count", "FETCH_HEAD..HEAD"], candidate_dir)
                    ahead_raw = (ahead_res.stdout or "").strip() if ahead_res else ""
                    if ahead_res and ahead_res.returncode == 0 and ahead_raw.isdigit():
                        ahead_count = int(ahead_raw)
                        if ahead_count > 0:
                            logger.warning(
                                f"Local clone at {candidate_dir} carries {ahead_count} unpushed commit(s); "
                                f"using the Contents-API fallback so only this article is committed."
                            )
                    remote_proof = _git_probe(["cat-file", "-e", f"FETCH_HEAD:{artifact_rel}"], candidate_dir)
                    remote_artifact = bool(remote_proof and remote_proof.returncode == 0)
            except Exception as fetch_err:
                logger.debug(f"Local clone freshness check notice: {fetch_err}")

            # 4. Local git add & commit (strictly posts and uploads; never touch
            #    untracked config or docs), then *prove* the artifact is inside
            #    HEAD before any push. If the commit silently fails (missing
            #    user.email, a hook, an index lock) the working tree stays dirty
            #    and pushing an already-current branch would exit 0 and report a
            #    publish that never happened.
            head_before_res = _git_probe(["rev-parse", "HEAD"], candidate_dir)
            head_before = (head_before_res.stdout or "").strip() if head_before_res else ""

            add_res = _git_probe(["add", "content/posts/", "public/uploads/"], candidate_dir)
            if add_res and add_res.returncode != 0:
                logger.warning(f"git add failed in {candidate_dir}: {(add_res.stderr or '').strip()[:200]}")

            commit_res = _git_probe(["commit", "-m", f"Publish article: {title[:50]}"], candidate_dir)
            head_after_res = _git_probe(["rev-parse", "HEAD"], candidate_dir)
            head_after = (head_after_res.stdout or "").strip() if head_after_res else ""
            commit_created = bool(head_before and head_after and head_after != head_before)

            proof_res = _git_probe(["cat-file", "-e", f"HEAD:{artifact_rel}"], candidate_dir)
            artifact_at_head = bool(proof_res and proof_res.returncode == 0)
            if commit_res and commit_res.returncode != 0:
                logger.info(
                    f"git commit in {candidate_dir} exited {commit_res.returncode} "
                    f"({(commit_res.stdout or commit_res.stderr or '').strip()[:160]}); "
                    f"artifact present at HEAD: {artifact_at_head}."
                )
            if not artifact_at_head:
                logger.warning(
                    f"No commit contains '{artifact_rel}' in {candidate_dir}; "
                    f"deferring to the GitHub Contents-API fallback instead of pushing."
                )

            # 5. Push only with proof: the artifact must exist inside HEAD, the
            #    clone must be current, and it must not carry unrelated unpushed
            #    commits. When the remote tip already contains the artifact the
            #    local sync is already done and no push is needed.
            push_allowed = artifact_at_head and branch_is_current and (
                ahead_count == 0 or (ahead_count is None and commit_created)
            )
            if push_allowed:
                try:
                    push_res = subprocess.run(
                        ["git", "push", remote_url, f"{branch_name}:{branch_name}"],
                        cwd=str(candidate_dir), check=False, capture_output=True, text=True, timeout=30, env=env
                    )
                    if push_res.returncode == 0:
                        push_succeeded = True
                        logger.info(f"Pushed article '{slug}' to GitHub {repo_name}:{branch_name}.")
                    else:
                        logger.warning(f"Git push to {repo_name} failed: {(push_res.stderr or '')[:200]}")
                except Exception as p_err:
                    logger.warning(f"Authenticated git push error: {p_err}")
            elif artifact_at_head and remote_artifact:
                push_succeeded = True
                logger.info(
                    f"'{artifact_rel}' is already present on the remote tip of "
                    f"{repo_name}:{branch_name}; no push needed."
                )

    except Exception as e:
        logger.warning(f"Local Next.js repo sync notice: {e}")

    # 6. GitHub Contents-API fallback / cloud commit
    if not push_succeeded:
        try:
            import httpx, base64
            headers = {
                "Authorization": f"Bearer {gh_token}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "ContentPipelineAgent/2.0"
            }

            # If there is a hero image, commit the image binary to public/uploads/
            if hero_image_url:
                img_name = Path(hero_image_url).name
                source_img = BASE_DIR / "web" / "static" / "uploads" / img_name
                if source_img.exists():
                    img_api_url = f"https://api.github.com/repos/{repo_name}/contents/public/uploads/{img_name}"
                    try:
                        with httpx.Client(timeout=20.0) as client:
                            img_chk = client.get(f"{img_api_url}?ref={branch_name}", headers=headers)
                            img_sha = img_chk.json().get("sha") if img_chk.status_code == 200 else None
                            img_b64 = base64.b64encode(source_img.read_bytes()).decode("ascii")
                            img_body = {
                                "message": f"Upload hero image: {img_name}",
                                "content": img_b64,
                                "branch": branch_name
                            }
                            if img_sha:
                                img_body["sha"] = img_sha
                            client.put(img_api_url, json=img_body, headers=headers)
                            logger.info(f"Uploaded hero image '{img_name}' via GitHub API cloud commit.")
                    except Exception as img_err:
                        logger.debug(f"GitHub image cloud commit notice: {img_err}")

            with httpx.Client(timeout=15.0) as client:
                # Commit the complete artifact pair (.json + .mdx) so the API
                # fallback produces the same files as the local git path.
                mdx_text = _render_mdx_article(
                    title=title, slug=slug, excerpt=excerpt,
                    meta_title=meta_title, meta_description=meta_description,
                    hero_image_url=clean_hero_url, tags=tags,
                    author=author, published_at=published_at, content=content
                )
                artifacts = [
                    (f"content/posts/{slug}.json", json.dumps(article_data, indent=2)),
                    (f"content/posts/{slug}.mdx", mdx_text),
                ]
                json_committed = False
                mdx_committed = False
                for artifact_path, artifact_text in artifacts:
                    api_url = f"https://api.github.com/repos/{repo_name}/contents/{artifact_path}"
                    sha = None
                    chk = client.get(f"{api_url}?ref={branch_name}", headers=headers)
                    if chk.status_code == 200:
                        sha = chk.json().get("sha")
                    b64_content = base64.b64encode(artifact_text.encode("utf-8")).decode("ascii")
                    body = {
                        "message": f"Publish article: {title[:50]}",
                        "content": b64_content,
                        "branch": branch_name
                    }
                    if sha:
                        body["sha"] = sha
                    put_res = client.put(api_url, json=body, headers=headers)
                    if put_res.status_code in (200, 201):
                        if artifact_path.endswith(".json"):
                            json_committed = True
                        else:
                            mdx_committed = True
                        logger.info(f"Committed {artifact_path} to GitHub ({repo_name}:{branch_name}) via REST API.")
                    else:
                        logger.warning(f"GitHub Contents API responded with HTTP {put_res.status_code} for {artifact_path}: {put_res.text[:150]}")
                # The .json artifact is the canonical data source; the .mdx is
                # best-effort so a partial write cannot block a real publish.
                if json_committed:
                    push_succeeded = True
                    if not mdx_committed:
                        logger.warning(f"Article '{slug}' committed as .json only — the .mdx artifact failed.")
                    logger.info(f"Published article '{slug}' directly to GitHub ({repo_name}:{branch_name}) via REST API cloud commit.")
        except Exception as api_err:
            logger.warning(f"GitHub direct API commit error: {api_err}")

    return push_succeeded


def publish_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: Submits the approved article and hero image to the
    connected website.

    Architecture Rules:
    1. If the target website persists articles itself (database, Upstash/
       Redis, or a serverless store such as Cloudflare KV/D1/R2 reported
       via the response `engines`):
       NO GitHub token or GitHub commit is needed or attempted.
    2. ONLY if the website is serverless with no persistent storage engine
       (pure Git-backed markdown files on Vercel / Cloudflare Pages / etc.):
       A GitHub commit is made to the website's configured GitHub repo.
    3. Multi-Website Isolation:
       Each website uses its own repository, branch, and token if configured.
    """
    title = state.get("title", "Untitled Article")
    raw_content = state.get("draft", "")
    slug = state.get("slug")
    website_id = state.get("website_id")

    # Respect user-configured content module toggles (ON/OFF buttons)
    content_options = state.get("content_options") or {}
    enable_diagrams = content_options.get("enable_diagrams", state.get("enable_diagrams", True))
    enable_tables = content_options.get("enable_tables", state.get("enable_tables", True))
    enable_faqs = content_options.get("enable_faqs", state.get("enable_faqs", True))
    enable_takeaways = content_options.get("enable_takeaways", state.get("enable_takeaways", True))

    # 1. Resolve Target Website. A run that names a website which no longer
    # exists must fail loudly: falling back to the default website would
    # cross-publish the article to a site the operator never selected.
    target_site = None
    site_lookup_error: Optional[str] = None
    try:
        target_site = resolve_run_website(website_id)
    except ValueError as lookup_err:
        site_lookup_error = str(lookup_err)
        logger.error(f"Refusing to publish '{title}': {site_lookup_error}")

    content = raw_content
    if not enable_diagrams:
        logger.info(f"User disabled diagrams: stripping diagram blocks for '{slug}'.")
        content = re.sub(r"```(?:mermaid|d2|graphviz)\s*[\s\S]*?```\n*", "", content)
        content = re.sub(r"<figure class=[\"']article-diagram[\"'][\s\S]*?</figure>\n*", "", content)
    else:
        # Pre-render diagrams to standalone vector SVGs and upload/sync them
        # so destination websites render them natively without client-side Mermaid.js
        content, _diagrams = prerender_and_publish_diagrams(
            content=content,
            slug=slug or "post",
            target_site=target_site
        )

    if not enable_tables:
        logger.info(f"User disabled tables: stripping markdown tables for '{slug}'.")
        content = re.sub(r"(?:\|[^\n]+\|\n)+\|[-:\s|]+\|\n(?:\|[^\n]+\|\n*)+", "", content)

    if not enable_faqs:
        logger.info(f"User disabled FAQs: stripping FAQ section for '{slug}'.")
        content = re.sub(r"(?i)##\s+(?:Frequently Asked Questions|FAQ)[\s\S]*?(?=\n##\s+|\Z)", "", content)

    if not enable_takeaways:
        logger.info(f"User disabled takeaways: stripping Key Takeaways for '{slug}'.")
        content = re.sub(r"(?i)>\s*(?:\*{2})?Key Takeaways[\s\S]*?(?=\n\n\n|\Z)", "", content)

    excerpt = state.get("meta_description") or (content[:160].replace("#", "").strip() + "...")
    hero_image_url = state.get("hero_image_url")
    tags_list = state.get("tags") or state.get("discovered_keywords") or state.get("keywords") or []
    tags_str = ", ".join(tags_list[:5])
    meta_title = state.get("meta_title")
    meta_description = state.get("meta_description")
    word_count = state.get("word_count")
    read_time = state.get("read_time")
    author = state.get("author")

    published_url = None
    publish_error = site_lookup_error
    publish_ok = False
    site_public_base = None
    preview_url = None
    dedupe_key = None
    post_publish_checks = {}
    res: Dict[str, Any] = {}

    if target_site and target_site.get("url"):
        site_name = target_site.get("name", "Website")
        logger.info(f"Publishing approved article '{title}' to website '{site_name}' ({target_site['url']})...")
        # Public origin of the target site (API route stripped) for the case
        # where the site confirms the publish but reports no post URL.
        site_public_base = re.sub(r"/api(/.*)?$", "", target_site["url"].strip()).rstrip("/")
        if site_public_base and not site_public_base.startswith(("http://", "https://")):
            site_public_base = f"https://{site_public_base}"

        # Setup A5d CMS Article Payload with media hash deduplication & metadata
        clean_hero = hero_image_url or ""
        if clean_hero.startswith("/static/uploads/"):
            clean_hero = clean_hero.replace("/static/uploads/", "/uploads/")
        hero_media = None
        if clean_hero:
            hero_media = CMSMediaAsset(
                filename=os.path.basename(clean_hero) or "hero.webp",
                source_url=clean_hero,
                alt=state.get("hero_image_alt") or f"{title} Hero Image",
                caption=state.get("hero_image_caption"),
                credit=state.get("hero_image_credit"),
                is_hero=True,
            )

        cms_meta = CMSMetadata(
            title=title,
            meta_title=meta_title or title,
            meta_description=meta_description or excerpt or "",
            slug=slug,
            canonical_url=state.get("canonical_url"),
            author=author or (target_site.get("author_name") if target_site else None) or "The Dispatch Editorial Bureau",
            tags=tags_list,
            categories=state.get("categories") or [],
            scheduled_time=state.get("scheduled_time"),
        )

        cms_payload = CMSArticlePayload(
            title=title,
            slug=slug,
            html_content=_render_markdown_html(content),
            markdown_content=content,
            excerpt=excerpt or meta_description or "",
            metadata=cms_meta,
            hero_image=hero_media,
            scheduled_time=state.get("scheduled_time"),
        )

        # Attestation and Quality gates
        attest_data = state.get("reviewer_attestation")
        attestation = None
        if attest_data:
            attestation = ReviewerAttestation(**attest_data) if isinstance(attest_data, dict) else attest_data
        else:
            attestation = ReviewerAttestation(
                reviewer_name=state.get("human_reviewer_name") or "Human Editorial Lead",
                role="Editorial Reviewer",
                sign_off_notes="Approved via Editorial Review Gate",
            )

        qg_report = state.get("pre_publish_quality_report") or {}
        qg_passed = qg_report.get("can_publish", True)
        qg_blocking = len(qg_report.get("blocking_failures", []))

        pub_mode_str = target_site.get("publish_mode") or "mode_1_after_approval"
        pub_cfg_data = {}
        if target_site.get("publish_config_json"):
            try:
                pub_cfg_data = json.loads(target_site["publish_config_json"])
            except Exception:
                pass
        site_pub_cfg = SitePublishConfig(
            mode=PublishMode(pub_mode_str) if pub_mode_str in PublishMode._value2member_map_ else PublishMode.MODE_1_AFTER_APPROVAL,
            **pub_cfg_data
        )

        coordinator = CMSPublishCoordinator(target_site)
        coordinator_res = coordinator.execute_publish_pipeline(
            payload=cms_payload,
            topic=state.get("topic") or title,
            reviewer_attestation=attestation,
            site_publish_config=site_pub_cfg,
            quality_gates_passed=qg_passed,
            quality_gate_blocking_count=qg_blocking,
            thread_id=state.get("thread_id"),
        )

        res = coordinator_res.raw_response or {}
        if coordinator_res.success:
            publish_ok = True
            published_url = coordinator_res.published_url
            preview_url = coordinator_res.preview_url
            dedupe_key = coordinator_res.dedupe_key
            post_publish_checks = coordinator_res.post_publish_checks
            logger.info(f"Article published live via {coordinator_res.cms_type}: {published_url}")
        else:
            publish_error = coordinator_res.error or "Website publish failed"
            preview_url = coordinator_res.preview_url
            logger.error(f"Website publish failed for '{title}': {publish_error}")
    else:
        # No configured target website: fall back to the local archive (+ GitHub
        # sync when explicitly configured) and report success with the local URL.
        # This keeps standalone/demo deployments working end-to-end.
        logger.warning(f"No target website configured for article '{title}'. Archiving locally.")

    def _archive(status: str) -> Optional[Dict[str, Any]]:
        """Saves/updates the local SQLite archive copy for history and search.

        Best-effort by design: the archive is a convenience copy, so a
        transient SQLite lock must never turn a verified publish into an
        'error' run by raising out of this node.
        """
        try:
            return save_post(
                title=title,
                content=content,
                slug=slug or "post",
                excerpt=excerpt,
                hero_image_url=hero_image_url,
                tags=tags_str,
                meta_title=meta_title,
                meta_description=meta_description,
                author=author or (target_site.get("author_name") if target_site else None) or "The Dispatch Editorial Bureau",
                status=status
            )
        except Exception as archive_err:
            logger.warning(f"Local archive write failed for '{slug}' ({archive_err}); publish state is unaffected.")
            return None

    saved = _archive(
        "published" if (publish_ok or (not target_site and not site_lookup_error)) else "failed"
    )

    final_slug = (saved or {}).get("slug") or slug or "post"
    destination_url = (target_site or {}).get("url")
    if published_url:
        full_published_url = resolve_full_published_url(
            published_url,
            run_or_state=state,
            slug=final_slug
        )
    elif publish_ok and site_public_base:
        # Verified publish without a reported deep link: link to the publication
        # itself rather than fabricating /posts/<slug> (which may 404).
        full_published_url = site_public_base
    elif not target_site and not site_lookup_error:
        # Local archive / demo mode: only a reported destination can produce a
        # link. Without one the URL stays None ("link not reported") instead of
        # a fabricated /posts/<slug> deep link that may 404.
        full_published_url = resolve_full_published_url(
            None,
            run_or_state=state,
            slug=final_slug
        )
    else:
        full_published_url = None

    # 2. Storage Strategy Evaluation
    # Check if storage is persistent (database, KV, or other serverless store):
    storage_type = (target_site.get("storage_type") or "auto").strip().lower() if target_site else "auto"
    resp_data = res.get("response") or {}
    engines = resp_data.get("engines") or []

    has_database_or_upstash = (
        storage_type == "database"
        or engines_indicate_persistent_storage(engines)
    )

    target_url = (target_site.get("url") or "") if target_site else ""
    is_local_dev = "localhost" in target_url or "127.0.0.1" in target_url

    # Build JSON-LD schemas and dispatch IndexNow notification if publish succeeded
    json_ld_schemas = []
    indexnow_status = "skipped"
    if publish_ok and full_published_url:
        try:
            json_ld_schemas = build_json_ld_schemas(
                title=title,
                slug=final_slug,
                content=content,
                meta_description=meta_description,
                hero_image_url=hero_image_url,
                author_name=(target_site.get("author_name") if target_site else None) or "The Dispatch Editorial Bureau",
                publisher_name=(target_site.get("name") if target_site else None) or "Dispatch Media Group",
                published_url=full_published_url,
                tags=tags_list,
                verified_claims=state.get("verified_claims"),
                video_url=state.get("video_asset_path"),
            )
            inow_res = submit_indexnow_urls([full_published_url])
            indexnow_status = inow_res.get("status", "skipped")
            sync_llms_txt_to_targets(
                site_name=target_site.get("name", "Dispatch Editorial") if target_site else "Dispatch Editorial",
                site_url=full_published_url
            )
        except Exception as sch_err:
            logger.warning(f"Schema / IndexNow / llms.txt execution notice: {sch_err}")

    # RULE 1: If database or Upstash is present (or local dev):
    # Straightforward! No GitHub token or commit is needed at all.
    if publish_ok and (has_database_or_upstash or is_local_dev):
        _sync_hero_image_to_local_targets(hero_image_url, target_site)
        logger.info(
            f"Article '{final_slug}' published to persistent storage "
            f"(engines: {engines or storage_type}). No GitHub commit or token required."
        )
        return {
            "slug": final_slug,
            "published_url": full_published_url,
            "destination_url": destination_url,
            "publish_error": None,
            "status": "published",
            "json_ld_schemas": json_ld_schemas,
            "indexnow_status": indexnow_status,
            "preview_url": preview_url,
            "dedupe_key": dedupe_key,
            "post_publish_checks": post_publish_checks,
        }

    # RULE 2: Serverless with NO database and NO Upstash (or git storage type):
    # Only in this case is a GitHub commit made to persist the article.
    pushed_to_github = False
    needs_github_commit = (
        not site_lookup_error
        and (
            storage_type == "git"
            or (storage_type == "auto" and not has_database_or_upstash and not is_local_dev)
        )
    )

    if needs_github_commit:
        now_utc = datetime.now(timezone.utc).isoformat()
        pushed_to_github = _sync_local_nextjs_repo(
            slug=final_slug,
            title=title,
            content=content,
            excerpt=excerpt,
            meta_title=meta_title,
            meta_description=meta_description,
            hero_image_url=hero_image_url or "",
            tags=tags_list,
            author=author or (target_site.get("author_name") if target_site else None) or "The Dispatch Editorial Bureau",
            published_at=now_utc,
            target_site=target_site
        )

    if pushed_to_github and not publish_ok:
        # The GitHub commit persisted the article even though the HTTP API
        # failed or never confirmed: treat it as published and refresh the archive.
        publish_ok = True
        _archive("published")
        if not full_published_url:
            full_published_url = site_public_base

    if publish_error and not publish_ok:
        return {
            "slug": final_slug,
            "published_url": None,
            "destination_url": destination_url,
            "publish_error": publish_error,
            "status": "failed",
            "preview_url": preview_url,
            "dedupe_key": dedupe_key,
            "post_publish_checks": post_publish_checks,
        }

    return {
        "slug": final_slug,
        "published_url": full_published_url,
        "destination_url": destination_url,
        "publish_error": None,
        "status": "published",
        "json_ld_schemas": json_ld_schemas,
        "indexnow_status": indexnow_status,
        "preview_url": preview_url,
        "dedupe_key": dedupe_key,
        "post_publish_checks": post_publish_checks,
    }
