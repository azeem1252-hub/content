"""
A5c: Article Production Studio Node.

Parses the draft Markdown into a typed ArticleDocumentModel,
applies the site blueprint, runs verification (A4) and lint on the model once,
and attaches the serialised model and renderers' outputs to ContentState.

The same model is consumed by:
  - The human reviewer (always sees what will publish)
  - Renderers: Semantic HTML, Markdown/MDX, WordPress blocks, CMS-specific fields
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, List

from pipeline.state import ContentState
from pipeline.adapters.article_model import (
    ArticleDocumentModel,
    ArticleType,
    ArticleBlueprint,
    ArticleRenderers,
    AnswerBlock,
    FAQBlock,
    get_blueprint_for_site,
    lint_article_model,
    attach_verification_to_model,
    parse_markdown_to_model,
    plan_visuals_for_article,
)
from pipeline.adapters.image_delivery import (
    ImageDeliveryAsset,
    generate_responsive_picture_markup,
    validate_and_audit_alt_text,
    generate_image_object_schema,
    generate_robots_meta_directives,
)
from pipeline.adapters.links_engine import (
    audit_article_links,
)
from pipeline.adapters.layout_blueprints import (
    audit_document_layout_blueprint,
)
from pipeline.adapters.quality_gates import (
    execute_pre_publish_quality_gates,
)

logger = logging.getLogger("pipeline.nodes.article_studio_node")


def _infer_article_type(state: ContentState) -> ArticleType:
    """
    Infers the article type from content_brief or content_format fields.
    Falls back to 'how_to' or 'generic'.
    """
    brief: Dict[str, Any] = state.get("content_brief") or {}
    at = brief.get("article_type") or state.get("content_format") or ""
    at_lower = at.lower().replace(" ", "_").replace("-", "_")

    type_map = {
        "how_to": "how_to", "howto": "how_to", "tutorial": "how_to", "guide": "how_to",
        "comparison": "comparison", "vs": "comparison", "versus": "comparison",
        "definition": "definition", "what_is": "definition", "glossary": "definition",
        "roundup": "roundup", "listicle": "roundup", "best_of": "roundup", "top": "roundup",
        "data_study": "data_study", "research": "data_study", "study": "data_study",
        "case_study": "case_study", "customer_story": "case_study",
        "pillar": "pillar", "pillar_guide": "pillar", "ultimate_guide": "pillar",
    }

    for key, value in type_map.items():
        if key in at_lower:
            return value  # type: ignore

    # Infer from title if not set
    title_lower = (state.get("title") or state.get("topic") or "").lower()
    if title_lower.startswith("how to") or "step-by-step" in title_lower:
        return "how_to"
    elif " vs " in title_lower or " versus " in title_lower:
        return "comparison"
    elif title_lower.startswith("what is") or title_lower.startswith("what are"):
        return "definition"
    elif any(title_lower.startswith(f"{n} ") for n in ["5", "7", "10", "15", "top", "best"]):
        return "roundup"
    elif "case study" in title_lower:
        return "case_study"
    elif "study" in title_lower or "data" in title_lower or "report" in title_lower:
        return "data_study"
    elif "complete guide" in title_lower or "definitive guide" in title_lower:
        return "pillar"

    return "generic"


def article_studio_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: A5c Article Production Studio.

    Reads: draft, title, slug, content_brief, keywords, author, verified_claims, source_citations, answer_blocks, aeo_faq_items
    Writes: article_model (JSON), article_html, article_markdown,
            article_wp_blocks, article_wp_html, article_cms_payload,
            blueprint_compliance, lint_summary
    """
    draft = state.get("draft") or ""
    title = state.get("title") or state.get("topic") or ""
    slug = state.get("slug") or ""
    keywords = state.get("keywords") or []
    author = state.get("editorial_persona") or state.get("author") or "Editorial Bureau"
    site_config = state.get("site_config") or {}

    if not draft:
        logger.warning("article_studio_node: no draft in state; skipping.")
        return {}

    article_type = _infer_article_type(state)

    logger.info(
        "Article Studio: title='%s', type='%s', slug='%s', %d keywords",
        title, article_type, slug, len(keywords),
    )

    # 1. Parse draft Markdown → typed document model
    try:
        doc = parse_markdown_to_model(
            markdown=draft,
            title=title,
            slug=slug,
            article_type=article_type,
            author=author,
            keywords=keywords,
        )
    except Exception as exc:
        logger.error("parse_markdown_to_model failed: %s", exc, exc_info=True)
        return {"article_model_error": str(exc)}

    # 2. Inject AEO Answer Blocks and FAQs from state if not already in document
    aeo_answer_blocks = state.get("answer_blocks") or []
    if aeo_answer_blocks and not doc.has_answer_block:
        for ab in aeo_answer_blocks[:2]:
            q = ab.get("question", "")
            ans = ab.get("direct_answer", "")
            if q and ans:
                doc.blocks.insert(0, AnswerBlock(
                    question=q,
                    direct_answer=ans,
                    target_format=ab.get("target_format", "paragraph"),
                    click_anchor=ab.get("click_anchor"),
                ))

    aeo_faq_items = state.get("aeo_faq_items") or []
    if aeo_faq_items and not doc.has_faq:
        doc.blocks.append(FAQBlock(items=aeo_faq_items))

    # 3. Attach Fact Verification (A4) & Grounding to model
    verified_claims = state.get("verified_claims") or []
    source_citations = state.get("source_citations") or []
    if verified_claims or source_citations:
        attach_verification_to_model(doc, verified_claims, source_citations)

    # 4. Attach schema markup from state
    schema_from_state = state.get("schema_markup")
    if schema_from_state:
        doc.schema_markup = schema_from_state

    # 5. Get Blueprint (with per-site configuration) and run linting once
    blueprint = get_blueprint_for_site(article_type, site_config)
    lint_report = lint_article_model(doc, blueprint=blueprint)
    compliance = lint_report.compliance

    # 5b. Run Visual Decision Engine (A5c.3)
    visual_plan_report = plan_visuals_for_article(doc)
    doc.visual_plan = visual_plan_report.model_dump()

    doc.blueprint_id = compliance.blueprint_id
    doc.blueprint_compliance = compliance.model_dump()
    doc.lint_summary = lint_report.model_dump()

    # 5c. Run Editorial Links Engine Audit (A5c.6)
    claim_sources = [c.get("source_url") for c in verified_claims if c.get("source_url")]
    link_engine_report = audit_article_links(
        content_markdown=draft,
        word_count=doc.total_word_count,
        verified_claim_sources=claim_sources,
    )

    # 5d. Run Image Delivery & Performance Audit (A5c.5)
    figure_blocks = [b for b in doc.blocks if b.block_type == "figure"]
    image_delivery_audits = []
    lcp_preload_tag = None
    for idx, fb in enumerate(figure_blocks):
        is_lcp = (idx == 0)
        asset = ImageDeliveryAsset(
            src=fb.src,
            alt=fb.alt,
            caption=fb.caption,
            credit=fb.credit,
            is_lcp=is_lcp,
        )
        pic_html, preload = generate_responsive_picture_markup(asset)
        alt_audit = validate_and_audit_alt_text(fb.alt)
        if is_lcp and preload:
            lcp_preload_tag = preload
        image_delivery_audits.append({
            "src": fb.src,
            "is_lcp": is_lcp,
            "alt_audit": alt_audit.model_dump(),
            "picture_html": pic_html,
            "schema_image_object": generate_image_object_schema(asset, article_title=doc.title),
        })

    # 5e. Run Professional Layout Checklist & Typography Lint (A5c.7)
    target_aud = state.get("target_audience") or "general"
    layout_audit = audit_document_layout_blueprint(
        doc=doc,
        content_markdown=draft,
        target_audience=target_aud,
    )

    # 6. Render all output formats from the single typed document model
    try:
        html_output = ArticleRenderers.to_html(doc, include_schema=bool(schema_from_state))
    except Exception as exc:
        logger.error("HTML renderer failed: %s", exc, exc_info=True)
        html_output = ""

    try:
        md_output = ArticleRenderers.to_markdown(doc)
    except Exception as exc:
        logger.error("Markdown renderer failed: %s", exc, exc_info=True)
        md_output = draft

    try:
        wp_blocks = ArticleRenderers.to_wordpress_blocks(doc)
    except Exception as exc:
        logger.error("WP blocks JSON renderer failed: %s", exc, exc_info=True)
        wp_blocks = []

    try:
        wp_html = ArticleRenderers.to_wordpress_html(doc)
    except Exception as exc:
        logger.error("WP HTML renderer failed: %s", exc, exc_info=True)
        wp_html = ""

    try:
        cms_payload = ArticleRenderers.to_cms_payload(doc, cms_type="nextjs")
    except Exception as exc:
        logger.error("CMS payload renderer failed: %s", exc, exc_info=True)
        cms_payload = {}

    # 6b. Run Pre-Publish Quality Gates (A5c.8)
    schema_markup_data = schema_from_state or doc.schema_markup
    quality_report = execute_pre_publish_quality_gates(
        html_content=html_output,
        markdown_content=md_output,
        schema_markup=schema_markup_data,
        website_id=state.get("website_id"),
        post_slug=doc.slug,
        article_title=doc.title,
        persist_tasks_to_db=True,
    )

    # 7. Observability logging
    logger.info(
        "Article Studio Complete: %d blocks, %d words, compliant=%s, warnings=%d, visual_proposals=%d, links=%d, can_publish=%s",
        len(doc.blocks), doc.total_word_count, compliance.is_compliant, len(lint_report.warnings), len(visual_plan_report.proposals), link_engine_report.total_links, quality_report.can_publish
    )

    return {
        "article_model": doc.model_dump(),
        "article_html": html_output,
        "article_markdown": md_output,
        "article_wp_blocks": wp_blocks,
        "article_wp_html": wp_html,
        "article_cms_payload": cms_payload,
        "blueprint_compliance": compliance.model_dump(),
        "lint_summary": lint_report.model_dump(),
        "visual_plan": visual_plan_report.model_dump(),
        "visual_density": visual_plan_report.density.model_dump(),
        "prohibitions_report": visual_plan_report.prohibitions.model_dump(),
        "link_audit": link_engine_report.model_dump(),
        "image_delivery_audit": {
            "figures_audited": len(image_delivery_audits),
            "assets": image_delivery_audits,
            "lcp_preload_tag": lcp_preload_tag,
            "robots_meta": generate_robots_meta_directives(),
        },
        "layout_audit": layout_audit.model_dump(),
        "pre_publish_quality_report": quality_report.model_dump(),
    }


