import logging
from typing import Dict, Any
from langgraph.types import interrupt
from pipeline.state import ContentState
from pipeline.adapters.slack_bot import build_slack_review_card, send_slack_card

logger = logging.getLogger("pipeline.nodes.review")

def review_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: Dispatches Slack Block Kit interactive review card
    and uses LangGraph's native interrupt() to pause for human editorial review.
    """
    title = state.get("title", "Untitled Dispatch")
    current_status = state.get("review_status", "pending")
    thread_id = state.get("thread_id", "thread-default")

    logger.info(f"Dispatching human review gate for '{title}' (Thread: {thread_id}, Status: {current_status})")

    # 1. Build the Slack Block Kit card. Standalone runners (CLI) dispatch it here;
    #    the PipelineManager sets slack_dispatch=False and sends its own
    #    website-targeted card after the interrupt, avoiding double dispatch.
    card = build_slack_review_card(state)
    slack_ts = state.get("slack_message_ts")
    if state.get("slack_dispatch", True):
        dispatch_res = send_slack_card(card)
        slack_ts = dispatch_res.get("ts") or slack_ts

    # 2. If review is already pre-approved (e.g. headless CI / CLI with --auto-approve)
    if current_status == "approved":
        return {
            "review_status": "approved",
            "slack_message_ts": slack_ts,
            "status": "review_approved"
        }

    # 3. Native LangGraph Interrupt: Pauses execution until a human decision is received
    logger.info(f"Pausing graph at human review gate via interrupt() (Thread: {thread_id})...")
    decision = interrupt({
        "task": "Review article dispatch",
        "title": title,
        "slug": state.get("slug"),
        "seo_score": state.get("seo_score"),
        "word_count": state.get("word_count"),
        "revision_count": state.get("revision_count", 1)
    })

    # 4. Handle resumption decision (received via Command(resume=...))
    if isinstance(decision, dict):
        # Fail closed: unknown/malformed dict resumes are treated as rejection
        action = decision.get("action", "rejected")
        feedback = decision.get("feedback") or decision.get("reviewer_feedback")
    else:
        action = str(decision).lower()
        feedback = None

    logger.info(f"Resuming graph after human review: action='{action}'")

    if action in ["approve", "approved"]:
        return {
            "review_status": "approved",
            "slack_message_ts": slack_ts,
            "status": "review_approved"
        }
    elif action in ["request_changes", "changes_requested"]:
        return {
            "review_status": "changes_requested",
            "reviewer_feedback": feedback,
            "slack_message_ts": slack_ts,
            "status": "review_changes_requested"
        }
    else:
        return {
            "review_status": "rejected",
            "slack_message_ts": slack_ts,
            "status": "review_rejected"
        }
