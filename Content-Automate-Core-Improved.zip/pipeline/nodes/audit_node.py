import re
import logging
from typing import Dict, Any, List, Optional
from pipeline.state import ContentState
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block, merge_unique_keywords, strip_markdown, count_words
from pipeline.utils import clean_slug as slugify
from pipeline.adapters.humanizer import detect_ai_tells
from pipeline.adapters.citable_evaluator import evaluate_citable_score
from pipeline.adapters.serp_nlp import extract_serp_semantic_footprint, evaluate_serp_coverage

logger = logging.getLogger("pipeline.nodes.audit")

STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for", "with",
    "by", "about", "against", "between", "into", "through", "during", "before",
    "after", "above", "below", "from", "up", "down", "of", "off", "over", "under",
    "again", "further", "then", "once", "here", "there", "when", "where", "why",
    "how", "all", "any", "both", "each", "few", "more", "most", "other", "some",
    "such", "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very",
    "can", "will", "just", "don", "should", "now", "is", "are", "was", "were",
    "be", "been", "being", "have", "has", "had", "do", "does", "did", "vs", "versus"
}


def extract_search_terms(text: str) -> List[str]:
    """Extract significant lowercase content words (min 3 chars) from a query or topic."""
    words = re.findall(r"\b[a-zA-Z0-9]{3,}\b", text.lower())
    return [w for w in words if w not in STOPWORDS]


def check_keyword_presence(target_phrase: str, text: str, all_keywords: Optional[List[str]] = None) -> bool:
    """
    Evaluates whether a target keyword, its core query terms, or any related target keyword
    is naturally present in the text without requiring robotic verbatim matching.
    """
    text_lower = text.lower()

    # 1. Direct exact or substring match
    if target_phrase and target_phrase.lower() in text_lower:
        return True

    # 2. Check any secondary target keywords
    if all_keywords:
        for kw in all_keywords:
            if kw and len(kw) > 3 and kw.lower() in text_lower:
                return True

    # 3. Core content terms match for multi-word phrases:
    # If the phrase has multiple words (e.g. "2026 pay-to-win esports integrity crisis analysis"),
    # verify if a strong threshold (>= 60% of significant terms) appears in the text.
    terms = extract_search_terms(target_phrase)
    if terms:
        matched = sum(1 for term in terms if term in text_lower)
        ratio = matched / len(terms)
        if len(terms) >= 3 and ratio >= 0.6:
            return True
        elif len(terms) < 3 and matched >= 1:
            return True

    # 4. Check if any secondary keyword's significant terms match
    if all_keywords:
        for kw in all_keywords:
            kw_terms = extract_search_terms(kw)
            if len(kw_terms) >= 2:
                matched = sum(1 for term in kw_terms if term in text_lower)
                if matched / len(kw_terms) >= 0.6:
                    return True

    return False


def format_serp_title(title_candidate: str, fallback: str) -> str:
    """Clamps meta title cleanly between 30 and 60 characters for Google SERP compliance."""
    raw = (title_candidate or fallback).strip()
    raw = re.sub(r'[\r\n\t]+', ' ', raw)
    raw = re.sub(r'\s+', ' ', raw)
    if len(raw) <= 60:
        return raw
    # Trim to last word before 57 chars and append ellipsis
    trimmed = raw[:57].rsplit(' ', 1)[0].rstrip('.,;:-')
    return f"{trimmed}..."


def format_serp_description(desc_candidate: str, fallback: str) -> str:
    """
    Formats and clamps meta description to optimal 120-158 characters for Google SERP snippet display.
    Avoids trailing mid-word truncations.
    """
    raw = (desc_candidate or fallback).strip()
    raw = re.sub(r'[\r\n\t]+', ' ', raw)
    raw = re.sub(r'[#*`]', '', raw)
    raw = re.sub(r'\s+', ' ', raw)

    if 120 <= len(raw) <= 160:
        return raw

    if len(raw) > 160:
        # Intelligently trim at the last word boundary before 155 chars
        trimmed = raw[:155].rsplit(' ', 1)[0].rstrip('.,;:-')
        return f"{trimmed}..."

    # If shorter than 120 chars, pad cleanly with fallback context if available
    if len(raw) < 120 and fallback and fallback != desc_candidate:
        clean_fb = re.sub(r'[#*`\r\n\t]+', ' ', fallback).strip()
        combined = f"{raw} {clean_fb}".strip()
        if len(combined) <= 160:
            return combined
        trimmed = combined[:155].rsplit(' ', 1)[0].rstrip('.,;:-')
        return f"{trimmed}..."

    return raw


def audit_and_optimize_seo(
    title: str,
    draft: str,
    topic: str,
    keywords: Optional[List[str]] = None,
    discovered_keywords: Optional[List[str]] = None,
    search_sources_hint: bool = False,
    search_sources: Optional[List[Dict[str, Any]]] = None,
    live_serp_snippets: Optional[List[str]] = None,
    rank_position: Optional[int] = None,
    author: Optional[str] = None,
    published_at: Optional[str] = None,
    updated_at: Optional[str] = None,
    website_id: Optional[str] = None,
    published_url: Optional[str] = None,
    publisher_name: Optional[str] = None,
    fact_verification_report: Optional[dict] = None,
) -> Dict[str, Any]:
    """
    Core business logic: Evaluates draft readability, audits placement of primary and
    discovered high-ranking keywords, generates metadata (slug, meta_title, meta_description, tags),
    and computes an SEO quality score with intelligent semantic keyword matching and SERP auto-formatting.
    """
    all_kws = merge_unique_keywords(keywords, discovered_keywords)

    # Deterministic metrics (markdown-stripped so markup isn't counted as words)
    word_count = count_words(draft)
    read_time = max(1, round(word_count / 200))

    primary_keyword = all_kws[0] if all_kws else topic
    plain_draft = strip_markdown(draft)
    plain_lower = plain_draft.lower()
    first_300_words = " ".join(plain_lower.split()[:300])

    # Semantic keyword presence evaluation
    kw_in_intro = check_keyword_presence(primary_keyword, first_300_words, all_kws)
    kw_in_body = check_keyword_presence(primary_keyword, plain_lower, all_kws)

    system_instruction = (
        "You are an expert Technical SEO Specialist and Editorial Auditor. "
        "Analyze the provided blog article draft and output a strict JSON object with metadata. "
        "Do not include any text outside the JSON block."
    )

    prompt = f"""Analyze this draft and produce SEO metadata:

Article Title: {title}
Primary Topic: {topic}
High-Ranking & Target Keywords: {', '.join(all_kws)}

Draft Excerpt (first 2000 characters):
{draft[:2000]}

Return a JSON object with EXACTLY these keys:
{{
  "slug": "url-friendly-lowercase-slug-under-80-chars",
  "meta_title": "Compelling Title strictly between 40 and 60 chars including primary topic",
  "meta_description": "Engaging summary strictly between 130 and 155 chars with a hook",
  "tags": ["3 to 5 concise topic tags, each strictly under 24 characters"],
  "seo_score": 95,
  "audit_notes": "Brief 1-2 sentence assessment of keyword distribution, structure, and readability."
}}
"""

    logger.info(f"Auditing draft and generating SEO metadata for: '{title}'")
    raw_response = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.3)

    parsed = extract_json_block(raw_response)
    if not parsed:
        logger.warning("Failed to parse LLM JSON for SEO audit. Generating fallback metadata.")
        fallback_slug = re.sub(r"[^\w\s-]", "", title.lower()).strip()
        fallback_slug = re.sub(r"[\s_-]+", "-", fallback_slug)
        dynamic_fallback_tags = (
            [k[:24].strip() for k in all_kws[:5]]
            if all_kws
            else ([w.title() for w in topic.split() if len(w) > 4][:4] or ["Editorial", "Guide"])
        )
        parsed = {
            "slug": fallback_slug[:50],
            "meta_title": title[:60],
            "meta_description": draft.replace("#", "").strip()[:150],
            "tags": dynamic_fallback_tags,
            "seo_score": 90 if kw_in_intro else 85,
            "audit_notes": f"Word count: {word_count}. Primary keyword verified: {kw_in_intro}."
        }

    # LLM JSON is untyped: only a string slug is usable, anything else falls
    # back to the title (clean_slug itself also tolerates odd scalar input).
    raw_slug = parsed.get("slug")
    clean_slug = slugify(raw_slug if isinstance(raw_slug, str) else title)

    raw_tags = parsed.get("tags")
    if not isinstance(raw_tags, (list, tuple)):
        if raw_tags:
            logger.warning("LLM returned a non-list 'tags' value; using discovered keywords instead.")
        raw_tags = (
            all_kws[:5]
            or [w.title() for w in topic.split() if len(w) > 4][:4]
            or ["Editorial", "Guide"]
        )
    clean_tags = []
    for t in raw_tags:
        s = str(t).strip()[:24].strip()
        if s and s not in clean_tags:
            clean_tags.append(s)
        if len(clean_tags) >= 8:
            break

    # Humanizer check: audit for AI tells
    ai_tells = detect_ai_tells(draft)
    # Proportional tell penalty (1 pt per persistent tell, capped at 5 pts)
    tell_penalty = min(5, len(ai_tells) * 1)

    # --- Intelligent SERP Clamping & Deterministic SEO Checks ---
    raw_meta_title = str(parsed.get("meta_title") or title)
    meta_title_v = format_serp_title(raw_meta_title, title)

    raw_meta_desc = str(parsed.get("meta_description") or draft[:155])
    meta_desc_v = format_serp_description(raw_meta_desc, draft[:155])

    ref_links = len(re.findall(r"\[[^\]]+\]\((https?://[^)]+)\)", draft))
    h2_count = len(re.findall(r"^##\s+", draft, flags=re.MULTILINE))

    checks_pass = 0
    checks_total = 6
    check_notes = []

    if kw_in_intro:
        checks_pass += 1
    else:
        check_notes.append("primary search terms missing from intro")

    if kw_in_body:
        checks_pass += 1
    else:
        check_notes.append("primary search terms missing from body")

    if 30 <= len(meta_title_v) <= 60:
        checks_pass += 1
    else:
        check_notes.append(f"meta title length {len(meta_title_v)} (target 30-60)")

    if 120 <= len(meta_desc_v) <= 160:
        checks_pass += 1
    else:
        check_notes.append(f"meta description length {len(meta_desc_v)} (target 120-160)")

    if h2_count >= 3:
        checks_pass += 1
    else:
        check_notes.append(f"only {h2_count} H2 sections (target 3+)")

    if word_count >= 800:
        checks_pass += 1
    else:
        check_notes.append(f"word count {word_count} below 800")

    if ref_links == 0 and search_sources_hint:
        check_notes.append("no reference links cited")

    deterministic_score = round(checks_pass / checks_total * 100)

    # Blend LLM qualitative score (40%) with technical deterministic score (60%)
    try:
        raw_score = int(round(float(parsed.get("seo_score", 90))))
    except (TypeError, ValueError):
        raw_score = 90
    # Clamp without an artificial floor: an inflated score hides real problems
    # from the operator, and nothing downstream routes on seo_score anyway.
    raw_score = max(0, min(100, raw_score))

    blended = round(0.6 * deterministic_score + 0.4 * raw_score)
    seo_score = max(0, min(100, blended - tell_penalty))

    raw_notes = parsed.get("audit_notes")
    base_notes = (
        raw_notes.strip()
        if isinstance(raw_notes, str) and raw_notes.strip()
        else "Passed editorial checks."
    )
    if check_notes:
        base_notes = f"{base_notes} | Checks note: {'; '.join(check_notes[:2])}".strip(" |")
    if ai_tells:
        humanizer_summary = f"Humanizer: {len(ai_tells)} minor stylistic tell(s) monitored."
    else:
        humanizer_summary = "Humanizer: Clean human tone verified."

    audit_notes = f"{base_notes} | {humanizer_summary}" if base_notes else humanizer_summary

    citable_eval = evaluate_citable_score(
        title=title,
        draft=draft,
        keywords=all_kws,
        has_citations=bool(search_sources_hint or ref_links > 0)
    )
    citable_score = citable_eval.get("citable_score", 85)

    # SERP coverage: prefer live Page-1 competitor snippets when available,
    # falling back to whatever the research stage retrieved.
    serp_coverage = {}
    snippets: List[str] = [s for s in (live_serp_snippets or []) if s]
    if not snippets and search_sources:
        snippets = [s.get("snippet", "") for s in search_sources if s.get("snippet")]
    if snippets:
        footprint = extract_serp_semantic_footprint(snippets)
        serp_coverage = evaluate_serp_coverage(draft, footprint)
        if rank_position is not None:
            serp_coverage["current_rank_position"] = rank_position
        serp_coverage["source"] = "live_serp" if live_serp_snippets else "research_cache"

    # Semantic keyword alignment (dense embeddings; falls back to lexical above)
    semantic_alignment = None
    # Pillar A5: On-Page SEO, Answer-First, and Quality Linting
    from pipeline.adapters.on_page_seo_linter import run_on_page_seo_audit
    on_page_seo = run_on_page_seo_audit(
        draft=draft,
        title=meta_title_v,
        meta_description=meta_desc_v,
        slug=clean_slug,
        author=author,
        published_at=published_at,
        updated_at=updated_at,
        fact_verification_report=fact_verification_report,
    )

    # Pillar A5: Schema JSON-LD Generation (Article, Person, Org, BreadcrumbList)
    from pipeline.adapters.schema_builder import build_json_ld_schemas
    schema_markup = build_json_ld_schemas(
        title=title,
        slug=clean_slug,
        content=draft,
        meta_description=meta_desc_v,
        author_name=author or "The Editorial Bureau",
        publisher_name=publisher_name or "Editorial Bureau",
        published_url=published_url,
        date_published=published_at,
        date_modified=updated_at,
        tags=clean_tags,
    )

    # Pillar A5: Contextual Internal Link Proposals (Outbound & Inbound)
    from pipeline.adapters.internal_linker import propose_contextual_internal_links
    link_proposals_data = propose_contextual_internal_links(
        draft=draft,
        new_post_slug=clean_slug,
        new_post_title=title,
        website_id=website_id,
    )

    return {
        "slug": clean_slug,
        "meta_title": meta_title_v,
        "meta_description": meta_desc_v,
        "tags": clean_tags,
        "seo_score": seo_score,
        "on_page_seo": on_page_seo,
        "schema_markup": schema_markup,
        "internal_link_proposals": link_proposals_data.get("outbound_proposals", []),
        "inbound_link_proposals": link_proposals_data.get("inbound_proposals", []),
        "citable_score": citable_score,
        "citable_evaluation": citable_eval,
        "citation_readiness": citable_eval.get("citation_readiness"),
        "serp_coverage": serp_coverage,
        "semantic_alignment": semantic_alignment,
        "audit_notes": audit_notes,
        "word_count": word_count,
        "read_time": read_time,
        "status": "audited"
    }


def audit_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node adapter: Extracts state inputs and executes SEO auditing.
    """
    live_snippets: List[str] = []
    rank_position: Optional[int] = None
    try:
        from pipeline.adapters.serp_client import competitor_footprint, find_domain_rank
        from storage.db import get_website_by_id

        site = get_website_by_id(state.get("website_id")) if state.get("website_id") else None
        own_domain = ""
        if site and site.get("url"):
            from urllib.parse import urlparse
            own_domain = (urlparse(site["url"]).netloc or "").lower().replace("www.", "")

        query = (state.get("keywords") or [state.get("topic", "")])[0] or state.get("topic", "")
        footprint = competitor_footprint(query, exclude_domain=own_domain or None)
        if footprint.get("measured"):
            live_snippets = footprint.get("snippets") or []
            if own_domain:
                rank_position = find_domain_rank(footprint.get("results") or [], own_domain)
    except Exception as e:  # noqa: BLE001
        logger.debug(f"Live SERP audit enrichment skipped: {e}")

    return audit_and_optimize_seo(
        title=state.get("title", ""),
        draft=state.get("draft", ""),
        topic=state.get("topic", ""),
        keywords=state.get("keywords", []),
        discovered_keywords=state.get("discovered_keywords"),
        search_sources_hint=bool(state.get("search_sources")),
        search_sources=state.get("search_sources"),
        live_serp_snippets=live_snippets or None,
        rank_position=rank_position,
        author=state.get("editorial_persona") or state.get("named_human_approver"),
        published_at=state.get("published_at"),
        updated_at=state.get("updated_at"),
        website_id=state.get("website_id"),
        published_url=state.get("published_url"),
        publisher_name=state.get("destination_name"),
        fact_verification_report=state.get("verification_report"),
    )
