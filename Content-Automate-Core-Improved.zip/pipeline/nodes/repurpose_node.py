import logging
from typing import Dict, Any, List
import config
from pipeline.state import ContentState
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block, resolve_full_published_url
from pipeline.adapters.humanizer import clean_deterministic_tells

logger = logging.getLogger("pipeline.nodes.repurpose")

def repurpose_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node: Automatically generates high-converting social media distribution assets
    (LinkedIn post & X/Twitter thread) linked to the live published article.
    """
    if not getattr(config, "GENERATE_SOCIAL_ASSETS", True):
        logger.info("Social media asset generation disabled in settings. Skipping repurpose step.")
        return {
            "linkedin_post": "",
            "twitter_thread": []
        }

    title = state.get("title", "")
    topic = state.get("topic", "")
    excerpt = state.get("meta_description", "")
    # resolve_full_published_url returns None when the site never reported a
    # public URL; keep it None and omit the link instead of shipping a
    # fabricated deep link that may 404 for every reader.
    published_url = resolve_full_published_url(
        state.get("published_url"),
        run_or_state=state,
        slug=state.get("slug")
    )
    link_tail = f"\n\nRead the full dispatch: {published_url}" if published_url else ""
    final_tweet_text = (
        f"Read the complete dispatch and architectural analysis here: {published_url}"
        if published_url
        else "Read the complete dispatch in our archive."
    )
    link_requirement = (
        f"linking to: {published_url}"
        if published_url
        else "without a link (the site did not report a public URL)"
    )
    draft = state.get("draft", "")

    system_instruction = (
        "You are a Senior Editorial Growth Architect and Social Media Director. "
        "Repurpose technical blog posts into authoritative, non-cringe social content. "
        "Return a valid JSON object with 'linkedin_post' (string) and 'twitter_thread' (list of strings)."
    )

    prompt = f"""Repurpose this published blog dispatch for social media distribution:

Article Title: {title}
Core Topic: {topic}
Published URL: {published_url or '(not reported by the site)'}
Excerpt: {excerpt}

Draft Excerpt (first 1000 chars):
{draft[:1000]}

Requirements:
1. LinkedIn Post:
   - Strong contrarian or insight-driven hook (no cringe corporate buzzwords).
   - 3 bullet points highlighting core technical takeaways.
   - Clean call-to-action inviting discussion, {link_requirement}.
2. X / Twitter Thread:
   - 4-5 tweets.
   - Tweet 1: Provocative hook + core thesis.
   - Tweets 2-4: Concrete technical takeaways and architectural patterns.
   - Final Tweet: Actionable conclusion, {link_requirement}.

Return a JSON object formatted EXACTLY as:
{{
  "linkedin_post": "Full text of the LinkedIn post with emojis and formatting...",
  "twitter_thread": [
    "1/5 Tweet 1 text...",
    "2/5 Tweet 2 text...",
    "3/5 Tweet 3 text...",
    "4/5 Tweet 4 text...",
    "5/5 Tweet 5 text..."
  ]
}}
"""

    logger.info(f"Generating social repurposing assets for: '{title}'")
    raw_response = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.7)

    linkedin_post = ""
    twitter_thread = []

    # LLM JSON is untyped: accept only the shapes we can actually use so a
    # stray null/dict/number cannot crash this node with an AttributeError
    # after the article is already live.
    parsed = extract_json_block(raw_response)
    if isinstance(parsed, dict):
        raw_linkedin = parsed.get("linkedin_post")
        raw_thread = parsed.get("twitter_thread")

        if isinstance(raw_linkedin, str) and raw_linkedin.strip():
            linkedin_post = raw_linkedin.strip()
        elif raw_linkedin not in (None, ""):
            logger.warning("LLM returned a non-string 'linkedin_post'; falling back to article metadata.")

        if isinstance(raw_thread, str) and raw_thread.strip():
            twitter_thread = [raw_thread.strip()]
        elif isinstance(raw_thread, list):
            twitter_thread = [t.strip() for t in raw_thread if isinstance(t, str) and t.strip()]
            dropped = len(raw_thread) - len(twitter_thread)
            if dropped:
                logger.warning(f"Dropped {dropped} non-string or empty tweet(s) from the LLM response.")
        elif raw_thread not in (None, ""):
            logger.warning("LLM returned a non-list 'twitter_thread'; falling back to article metadata.")
    else:
        logger.warning("Could not parse social repurposing JSON. Generating formatted social assets from article metadata.")

    if not linkedin_post:
        linkedin_post = f"""🚀 {title}

{excerpt}

Key Takeaways:
• Deep technical dive on {topic}
• Production patterns, architecture, and practical takeaways.{link_tail}"""

    if not twitter_thread:
        twitter_thread = [
            f"1/3 🧵 We just published a deep dive on '{title}'. Here are the key insights:",
            f"2/3 {excerpt[:240]}",
            f"3/3 {final_tweet_text}"
        ]

    if linkedin_post:
        linkedin_post = clean_deterministic_tells(linkedin_post)
    twitter_thread = [
        clean_deterministic_tells(tweet) for tweet in twitter_thread if isinstance(tweet, str) and tweet
    ]

    # Headless Postiz Omnichannel Syndication for Article Distribution
    media_assets = []
    hero_img = state.get("hero_image_url")
    if hero_img:
        media_assets.append(hero_img)

    copy_by_platform = {
        "linkedin": linkedin_post,
        "twitter": "\n\n".join(twitter_thread[:2])
    }

    from pipeline.adapters.postiz_client import schedule_postiz_publication
    postiz_res = schedule_postiz_publication(
        title=title,
        copy_by_platform=copy_by_platform,
        media_urls=media_assets
    )

    return {
        "linkedin_post": linkedin_post,
        "twitter_thread": twitter_thread,
        "postiz_status": postiz_res.get("status", "staged"),
        "status": "completed"
    }
