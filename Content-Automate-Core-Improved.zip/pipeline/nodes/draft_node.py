import logging
from typing import Dict, Any, List, Optional
from langgraph.types import interrupt

import config
from pipeline.state import ContentState
from pipeline.llm_client import call_llm
from pipeline.utils import clean_article_content, extract_h1_title, merge_unique_keywords
from pipeline.topic_researcher import get_archetype_for_niche
from pipeline.editorial_archetypes import get_design_archetype_by_slug
from pipeline.adapters.humanizer import (
    load_humanizer_skill,
    detect_ai_tells,
    clean_deterministic_tells,
    humanize_article_with_llm,
)
from pipeline.adapters.brand_dna import load_soul_guidelines
from pipeline.adapters.internal_linker import (
    get_cluster_candidates,
    build_internal_linking_prompt,
    verify_and_inject_internal_links,
    extract_topic_cluster_summary,
)
from pipeline.adapters.evidence_pack import (
    has_minimum_evidence,
    load_site_evidence_pack,
)
from pipeline.adapters.brand_voice import get_active_style_profile
from pipeline.adapters.brief_builder import build_evidence_based_brief
from pipeline.adapters.section_drafter import generate_structured_article_draft
from pipeline.adapters.self_critic import execute_critique_and_revision_loop
from pipeline.adapters.structured_draft import StructuredDraft

logger = logging.getLogger("pipeline.nodes.draft")


def generate_draft(
    outline: str,
    topic: str,
    title: Optional[str] = None,
    keywords: Optional[List[str]] = None,
    discovered_keywords: Optional[List[str]] = None,
    audience_insights: Optional[str] = None,
    search_sources: Optional[List[Dict[str, str]]] = None,
    reviewer_feedback: Optional[str] = None,
    revision_count: int = 0,
    review_status: str = "pending",
    existing_draft: Optional[str] = None,
    niche_slug: Optional[str] = None,
    editorial_persona: Optional[str] = None,
    angle_or_hook: Optional[str] = None,
    content_format: Optional[str] = None,
    editorial_archetype: Optional[str] = None,
    design_guide: Optional[Dict[str, Any]] = None,
    live_serp_context: Optional[str] = None,
    knowledge_graph_context: Optional[str] = None,
    website_id: Optional[str] = None,
    slug: Optional[str] = None,
    content_brief: Optional[Dict[str, Any]] = None,
    evidence_pack: Optional[Any] = None,
    thread_id: Optional[str] = None,
    inject_evidence: bool = True,
) -> Dict[str, Any]:
    """
    Core generation & revision logic:
    Pillar A3.1 Section-by-section drafting, structured Pydantic tree, empirical brand voice,
    Pillar A3.2 Evidence Pack originality gating (Google Scaled Content Policy),
    Pillar A3.3 Self-critique & surgical revision loop (max 2 iterations).
    """
    all_kws = merge_unique_keywords(keywords, discovered_keywords)
    keywords_str = ", ".join(all_kws) if all_kws else topic

    arch = get_archetype_for_niche(niche_slug, topic)
    persona = editorial_persona or arch.get("persona", "Senior Editorial Columnist and Domain Specialist")
    design = design_guide or get_design_archetype_by_slug(editorial_archetype)

    humanizer_skill = load_humanizer_skill()
    soul_guidelines = load_soul_guidelines()

    cluster_candidates = get_cluster_candidates(topic=topic, website_id=website_id, exclude_slug=slug, limit=4)
    cluster_prompt = build_internal_linking_prompt(cluster_candidates)

    is_revision = bool(reviewer_feedback and existing_draft and existing_draft.strip())

    # =========================================================================
    # HUMAN EDITORIAL REVISION (FAST PATH)
    # =========================================================================
    if is_revision:
        system_instruction = (
            f"You are an acclaimed {persona}. Apply editorial revision instructions directly.\n\n"
            f"--- BRAND DNA DIRECTIVES ---\n{soul_guidelines}\n--- END BRAND DNA ---"
        )
        sources_prompt = ""
        if search_sources:
            sources_lines = [
                f"- [{s.get('title', 'Ref')}]({s.get('url', '#')}): {(s.get('page_content') or s.get('snippet', ''))[:200]}"
                for s in search_sources[:5]
            ]
            sources_prompt = f"Authoritative Reference Sources:\n{chr(10).join(sources_lines)}"

        prompt = f"""You are revising the technical Markdown article below based on direct editorial feedback from the human editor.

EDITORIAL REVISION INSTRUCTIONS (Revision #{revision_count + 1}):
\"\"\"{reviewer_feedback}\"\"\"

--- CURRENT ARTICLE DRAFT TO REVISE ---
{existing_draft}
--- END CURRENT ARTICLE DRAFT ---

Context:
- Primary Topic: {topic}
- Target Keywords: {keywords_str}
{sources_prompt}
{cluster_prompt}

Guidelines:
- DIRECTLY AND THOROUGHLY APPLY the editor's revision instructions.
- Preserve high-value technical sections, citations, and benchmark data.
- Enforce Generative Engine Optimization (GEO): cite exact figures/years from sources, include expert quotes, and front-load answers.
- Enforce Answer Engine Optimization (AEO): format question headings with direct 30-word answers, use Markdown comparison tables and ordered steps.
- Output ONLY the revised Markdown article starting directly with the # Title header.
"""
        logger.info(f"Revising article for '{topic}' (Revision: {revision_count + 1})")
        raw_draft = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.7).strip()
        draft_content = clean_article_content(raw_draft)
        draft_content = clean_deterministic_tells(draft_content)
        title = extract_h1_title(draft_content, fallback=topic)
        draft_content, _injected = verify_and_inject_internal_links(draft_content, cluster_candidates)
        cluster_summary = extract_topic_cluster_summary(draft=draft_content, title=title, slug=slug or "", website_id=website_id)

        return {
            "title": title,
            "draft": draft_content,
            "topic_cluster": cluster_summary,
            "revision_count": revision_count + 1,
            "review_status": "approved" if review_status == "approved" else "pending",
            "reviewer_feedback": None,
            "status": "drafted",
        }

    # =========================================================================
    # A3.2 ORIGINALITY: THE EVIDENCE PACK GATING (SCALED CONTENT POLICY)
    # =========================================================================
    raw_evidence = evidence_pack
    evidence_items: List[Dict[str, Any]] = []

    if isinstance(raw_evidence, list):
        evidence_items = raw_evidence
    elif isinstance(raw_evidence, dict):
        evidence_items = raw_evidence.get("items") or [raw_evidence]

    if not evidence_items:
        evidence_items = load_site_evidence_pack(website_id or "default", topic=topic)

    # Google Scaled Content Policy Enforcer:
    # If no proprietary evidence exists and gating is active, pause and ask
    if inject_evidence and getattr(config, "REQUIRE_EVIDENCE_PACK", False) and not has_minimum_evidence(evidence_items):
        logger.info(f"Google Scaled Content Policy gate: Pausing draft for '{topic}' to request original evidence pack.")
        decision = interrupt({
            "type": "evidence_required",
            "message": (
                "Google Scaled Content Policy Gate: Original evidence pack required before drafting. "
                "To ensure ranking durability and authority, provide at least one piece of genuine first-party "
                "evidence (benchmark data, customer case study, expert quote, or lab results)."
            ),
            "topic": topic,
            "thread_id": thread_id,
            "website_id": website_id,
        })
        if isinstance(decision, dict) and decision.get("evidence_pack"):
            new_ev = decision.get("evidence_pack")
            evidence_items = new_ev if isinstance(new_ev, list) else [new_ev]

    # If no proprietary evidence items provided, maintain clean empty evidence list
    # and rely on factual, verifiable domain knowledge without fabricating synthetic benchmarks (AUD-26)
    if not evidence_items:
        evidence_items = []

    # =========================================================================
    # A3.1 BRAND VOICE FROM DATA & STYLE PROFILE
    # =========================================================================
    style_profile = get_active_style_profile(website_id or "default", topic=topic)

    # =========================================================================
    # A2 / A3.1 EVIDENCE-BASED BRIEF RESOLUTION
    # =========================================================================
    brief = content_brief
    if not brief:
        primary_kw = all_kws[0] if all_kws else topic
        brief = build_evidence_based_brief(
            topic=topic,
            primary_keyword=primary_kw,
            website_id=website_id or "default",
            evidence_pack=evidence_items,
            target_audience=audience_insights,
            angle_or_hook=angle_or_hook,
        )

    # =========================================================================
    # A3.1 SECTION-BY-SECTION DRAFTING ENGINE (STRUCTURED PYDANTIC OUTPUT)
    # =========================================================================
    logger.info(f"Beginning section-by-section structured generation for '{topic}'...")
    structured_draft = generate_structured_article_draft(
        brief=brief,
        evidence_items=evidence_items,
        style_profile=style_profile,
        topic=topic,
        title=title,
        slug=slug,
    )

    # =========================================================================
    # A3.3 SELF-CRITIQUE LOOP (MAX 2 REVISIONS)
    # =========================================================================
    logger.info(f"Dispatching self-critique loop for '{topic}'...")
    structured_draft, critique, loops_executed = execute_critique_and_revision_loop(
        draft=structured_draft,
        brief=brief,
        style_profile=style_profile,
        max_loops=getattr(config, "MAX_CRITIQUE_LOOPS", 2),
    )

    # Compile structured tree into clean publication Markdown
    draft_content = structured_draft.to_markdown()
    draft_content = clean_article_content(draft_content)
    draft_content = clean_deterministic_tells(draft_content)

    # Run humanizer scan
    tells = detect_ai_tells(draft_content)
    if any("§1" in t.get("rule", "") or "Staged" in t.get("rule", "") for t in tells) or len(tells) >= 4:
        logger.info(f"Humanizer refining final draft ({len(tells)} patterns detected)...")
        draft_content = humanize_article_with_llm(draft_content, topic=topic)

    title = extract_h1_title(draft_content, fallback=structured_draft.title or topic)

    # Verify and inject contextual internal links
    draft_content, _injected_links = verify_and_inject_internal_links(draft_content, cluster_candidates)
    cluster_summary = extract_topic_cluster_summary(
        draft=draft_content,
        title=title,
        slug=slug or "",
        website_id=website_id,
    )

    return {
        "title": title,
        "draft": draft_content,
        "structured_draft": structured_draft.model_dump(),
        "style_profile": style_profile,
        "evidence_pack": evidence_items,
        "prompt_versions": structured_draft.prompt_versions,
        "critique_result": critique.model_dump(),
        "critique_loop_count": loops_executed,
        "evidence_status": "provided",
        "topic_cluster": cluster_summary,
        "revision_count": revision_count + 1,
        "review_status": "approved" if review_status == "approved" else "pending",
        "reviewer_feedback": None,
        "editorial_archetype": design.get("slug"),
        "live_serp_context": live_serp_context or "",
        "knowledge_graph_context": knowledge_graph_context or "",
        "status": "drafted",
    }


def _gather_live_research(state: ContentState) -> tuple:
    """Collects live SERP competitor footprints and GraphRAG entity context."""
    topic = state.get("topic", "") or ""

    serp_block = state.get("live_serp_context") or ""
    if not serp_block and topic:
        try:
            from pipeline.adapters.serp_client import serp_context_block
            serp_block = serp_context_block(topic)
        except Exception as e:
            logger.debug(f"Live SERP context unavailable: {e}")

    kg_block = state.get("knowledge_graph_context") or ""
    if not kg_block and topic:
        try:
            from pipeline.adapters.knowledge_graph import graph_rag_context
            kg_block = graph_rag_context(state.get("website_id"), topic)
        except Exception as e:
            logger.debug(f"Knowledge graph context unavailable: {e}")

    return serp_block, kg_block


def draft_node(state: ContentState) -> Dict[str, Any]:
    """
    LangGraph Node adapter: Extracts state inputs and executes longform drafting.
    """
    live_serp_context, knowledge_graph_context = _gather_live_research(state)
    return generate_draft(
        outline=state.get("outline", ""),
        topic=state.get("topic", ""),
        title=state.get("title"),
        keywords=state.get("keywords", []),
        discovered_keywords=state.get("discovered_keywords"),
        audience_insights=state.get("audience_insights"),
        search_sources=state.get("search_sources"),
        reviewer_feedback=state.get("reviewer_feedback"),
        revision_count=state.get("revision_count", 0),
        review_status=state.get("review_status", "pending"),
        existing_draft=state.get("draft"),
        niche_slug=state.get("niche_slug"),
        editorial_persona=state.get("editorial_persona"),
        angle_or_hook=state.get("angle_or_hook"),
        content_format=state.get("content_format"),
        editorial_archetype=state.get("editorial_archetype"),
        design_guide=state.get("design_guide"),
        live_serp_context=live_serp_context,
        knowledge_graph_context=knowledge_graph_context,
        website_id=state.get("website_id"),
        slug=state.get("slug"),
        content_brief=state.get("content_brief"),
        evidence_pack=state.get("evidence_pack"),
        thread_id=state.get("thread_id"),
        inject_evidence=state.get("inject_evidence", True),
    )
