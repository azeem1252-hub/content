"""Autonomous content pipeline: LangGraph nodes, adapters, and the run manager."""
