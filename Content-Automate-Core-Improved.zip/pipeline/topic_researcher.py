"""
Autonomous Topic Researcher & Web Scraper (2026 Enterprise Edition)
Dynamically scrapes connected websites (HTML, JSON-LD, RSS feeds, sitemaps, Next.js API routes)
to discover existing published articles, deduce the exact editorial niche across 12 distinct domains,
queries live search trends via Tavily, and prompts LLM to generate fresh, high-intent topics
with unique "Information Gain" angles that have NOT yet been published on the site.
"""

import copy
import html
import json
import logging
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
import httpx
from bs4 import BeautifulSoup

import config
from storage.db import (
    get_website_by_id,
    get_default_website,
    get_published_topics_by_website,
)
from pipeline.llm_client import call_llm
from pipeline.utils import extract_json_block, is_duplicate_topic, fetch_tavily_intelligence
from pipeline.editorial_archetypes import detect_editorial_archetype, get_design_archetype_by_slug

logger = logging.getLogger("pipeline.topic_researcher")

DUPLICATE_TOPIC_THRESHOLD = 0.76
MAX_DISCOVERY_ATTEMPTS = 3

# Common navigation/utility strings to ignore when extracting article titles
GENERIC_DISCARD = {
    "home", "about", "about us", "contact", "contact us", "privacy policy", "terms of service",
    "terms", "privacy", "latest articles", "popular games", "latest videos", "join 50,000+ gamers",
    "trending now", "get gaming news in your inbox", "build the perfect gaming setup",
    "platforms", "explore", "stay updated", "newsletter", "subscribe", "read more", "continue",
    "view all", "next", "prev", "previous", "share", "author", "comment", "comments",
    "sign in", "login", "register", "all posts", "menu", "search", "table of contents",
    "category", "categories", "tag", "tags", "filter", "filters", "recent posts", "featured",
    "recipe of the week", "cuisines & categories", "kitchen studio", "the sunday digest",
    "saved", "articles", "post blog", "reviews", "all recipes", "read story & cook"
}

# =========================================================================
# 12 COMPREHENSIVE EDITORIAL ARCHETYPES & INTELLIGENCE DEFINITIONS
# =========================================================================

EDITORIAL_ARCHETYPES = [
    {
        "slug": "fashion",
        "pattern": r"\b(fashion|couture|haute couture|runway|luxury|luxary|atelier|ateliers|savoir-faire|jewelry|jewellery|garment|apparel|tailoring|textile|silhouette|draping|vogue|maison|catwalk|model|wardrobe|designer fashion|paris fashion week|milan fashion week)\b",
        "niche": "Haute Couture, Luxury Fashion Journalism, Ateliers & Savoir-Faire, Runway Architecture, and High Jewelry",
        "persona": "Editor-in-Chief, Haute Couture Fashion Critic, and Parisian Luxury Editorial Columnist",
        "search_query": "{site_name} haute couture runway trends ateliers craftsmanship luxury fashion 2026",
        "seo_query_template": "{topic} haute couture runway collection analysis atelier review 2026",
        "community_query": "{topic} couture review runway discussion site:reddit.com/r/femalefashionadvice OR site:reddit.com/r/malefashionadvice OR site:vogue.com",
        "gap_query": "{topic} atelier techniques textile craftsmanship what fashion critics miss",
        "default_audience": "Haute couture collectors, luxury fashion patrons, atelier craft enthusiasts, and fashion industry insiders",
        "formats": ["Runway Critique & Collection Analysis", "Atelier Savoir-Faire Masterclass", "Textile & Silhouette Architectural Deep Dive"],
        "fallback_dossier": (
            "- 2026 Haute Couture Trends: Rejection of ephemeral fast fashion in favor of archival heirloom craftsmanship.\n"
            "- Craftsmanship Intent: Bullion thread embroidery, neoclassical corsetry, sculptural double-silk velvet, and sustainable atelier sourcing.\n"
            "- High Jewelry & Accessories: 80-carat Colombian emeralds, transformable tiara-collars, and bespoke horology."
        ),
        "guidance": (
            "1. Autonomously analyze what authoritative haute couture collection review, atelier craftsmanship critique, or luxury fashion trend breakdown is missing from this publication.\n"
            "2. Propose a prestigious, literary fashion critique or savoir-faire deep dive that treats haute couture with the reverence of fine art.\n"
            "3. Formulate an evocative, poetic headline that captures the drama of the runway or the intimacy of the Parisian atelier.\n"
            "4. Target audience: Discerning fashion patrons, couture collectors, and style theorists.\n\n"
            "CRITICAL RULES FOR FASHION & LUXURY SITES:\n"
            "- Focus strictly on garments, haute couture collections, runway architecture, fabric drapery, high jewelry, and atelier savoir-faire.\n"
            "- Do NOT propose software UI, digital web design, typography engineering, or tech topics."
        )
    },
    {
        "slug": "culinary",
        "pattern": r"\b(food|cooking|culinary|recipe|recipes|baking|chef|gourmet|epicurean|pasta|dish|dishes|kitchen|gastronomy|cuisine|ingredients|restaurant|dessert|sauce|pastry|roast|simmer|braise|sourdough|truffle|tagliatelle|pavlova|ramen|cocktail|fermentation|dinner)\b",
        "niche": "Gourmet Culinary Arts, Artisanal Recipes, Gastronomy, Specialty Cooking Techniques, and Epicurean Food Culture",
        "persona": "Executive Chef, Gastronomy Critic, and Editor-in-Chief of an artisanal culinary journal",
        "search_query": "{site_name} gourmet recipe culinary trends seasonal ingredients dishes 2026",
        "seo_query_template": "{topic} recipe ingredients preparation pro techniques tips 2026",
        "community_query": "{topic} pro tips mistakes questions site:reddit.com/r/Cooking OR site:reddit.com/r/AskCulinary",
        "gap_query": "{topic} common mistakes what recipes get wrong chef secrets emulsion technique",
        "default_audience": "Gourmet home cooks, culinary enthusiasts, and dinner hosts seeking restaurant-grade technique",
        "formats": ["Artisanal Masterclass Recipe", "Chef Technique Deep Dive", "Seasonal Flavor Exploration"],
        "fallback_dossier": (
            "- 2026 Culinary Shifts: Elevating humble root vegetables with compound cultured butters; cold-infusion herbal broths.\n"
            "- High-Demand Reader Intent: Mastering restaurant-quality pan sauces and emulsion science at home without synthetic stabilizers.\n"
            "- Trending Flavors: Foraged wild botanicals, black garlic port reductions, artisanal lamination in viennoiserie, heirloom grain pasta doughs."
        ),
        "guidance": (
            "1. Autonomously analyze what delicious gourmet recipe, seasonal specialty, or chef technique is missing from this culinary publication.\n"
            "2. Propose a single mouth-watering, publication-grade gourmet recipe or culinary masterclass (e.g. handmade pasta, artisan viennoiserie, pan-seared cuts with complex reductions, decadent pastry, or coastal seafood) with rich ingredients.\n"
            "3. Formulate an appetizing, evocative headline with key flavor notes.\n"
            "4. Define 4-6 culinary SEO keywords (recipe, technique, key ingredient variations).\n"
            "5. Specify the target home cook persona and the exact culinary technique.\n\n"
            "CRITICAL RULES FOR CULINARY SITES:\n"
            "- Do NOT propose industrial food science, biotech whitepapers, or lab-grown meat debates unless the site is specifically a food tech blog.\n"
            "- Propose genuine, delicious artisanal recipes with chef tips, seasonal ingredients, and precise culinary technique.\n"
            "- Target audience MUST be home cooks, culinary enthusiasts, dinner hosts, or foodies."
        )
    },
    {
        "slug": "gaming",
        "pattern": r"\b(game|games|gaming|gamer|gamers|esport|esports|steam|playstation|ps5|xbox|nintendo|switch|rpg|fps|gameplay|unreal|unity|steamdeck|boss|loadout|narrative|speedrun|graphics|multiplayer)\b",
        "niche": "Video Games, Game Systems & Engine Architecture, AAA/Indie Analysis, Esports, and Gaming Hardware",
        "persona": "Senior Games Journalist and Editor-in-Chief of an authoritative video game editorial desk",
        "search_query": "{site_name} video games popular releases mechanics critique analysis 2026",
        "seo_query_template": "{topic} guide walkthrough strategy tips meta analysis 2026",
        "community_query": "{topic} discussion tips problems site:reddit.com/r/games OR site:reddit.com",
        "gap_query": "{topic} hidden mechanics advanced strategies what guides miss",
        "default_audience": "Dedicated gamers, build optimizers, and video game systems analysts",
        "formats": ["Systems Architecture Breakdown", "Definitive Walkthrough & Strategy Guide", "Critical Game Design Essay"],
        "fallback_dossier": (
            "- 2026 Gaming Shifts: Player fatigue with open-world bloat in favor of handcrafted systems-driven narratives.\n"
            "- High-Demand Reader Intent: Deep technical breakdowns of frame-pacing, physics simulation engines, and procedural level generation.\n"
            "- Trending Genres: Atmospheric tactical shooters with diagetic UI; literary indie puzzle mysteries; retro-fps Renaissance."
        ),
        "guidance": (
            "1. Analyze what critical game system teardown, design critique, or narrative breakdown is missing from this gaming publication.\n"
            "2. Propose an authoritative, literary video game essay or systems critique that treats the medium with serious craft.\n"
            "3. Formulate an evocative headline that avoids generic review clichés.\n"
            "4. Target audience: Discerning players, game designers, and interactive narrative enthusiasts."
        )
    },
    {
        "slug": "ai",
        "pattern": r"\b(ai|artificial intelligence|llm|llms|machine learning|deep learning|neural network|neural networks|langgraph|langchain|prompt engineering|autonomous agent|autonomous agents|rag|embedding|transformer|diffusion)\b",
        "niche": "Artificial Intelligence, Autonomous AI Agents, Machine Learning Engineering, and Applied LLM Systems",
        "persona": "Principal AI Architect and Head of Machine Learning Research",
        "search_query": "{site_name} artificial intelligence LLM agent architectures real-world benchmarks 2026",
        "seo_query_template": "{topic} architecture benchmarks implementation guide 2026",
        "community_query": "{topic} production challenges evaluation site:reddit.com/r/MachineLearning OR site:news.ycombinator.com",
        "gap_query": "{topic} latency cost production failure modes what tutorials miss",
        "default_audience": "Machine learning engineers, AI researchers, and technical founders",
        "formats": ["Production Architecture Teardown", "Empirical Benchmark Analysis", "Engineering Implementation Field Guide"],
        "fallback_dossier": (
            "- 2026 AI Trends: Multi-agent state machines replacing brittle prompt chains; local small-language model distillation.\n"
            "- Technical Demand: Production latency benchmarks, memory footprint optimization, structured JSON output validation, and deterministic guardrails.\n"
            "- Emerging Architectures: Agentic self-healing pipelines, hybrid vector-graph retrieval (GraphRAG), speculative decoding."
        ),
        "guidance": (
            "1. Analyze what technical architecture, benchmark comparison, or agentic workflow is missing from this AI publication.\n"
            "2. Propose an engineering deep-dive with practical architectures, latency numbers, and real-world system tradeoffs.\n"
            "3. Avoid basic 'What is ChatGPT' introductory fluff. Target seasoned AI engineers and tech leads."
        )
    },
    {
        "slug": "cloud",
        "pattern": r"\b(saas|devops|cloud|kubernetes|docker|microservices|infrastructure|serverless|aws|gcp|azure|nextjs|react|typescript|backend|database|postgres|prisma|redis|edge)\b",
        "niche": "Cloud Infrastructure, B2B SaaS Architecture, DevOps Engineering, and Distributed Systems",
        "persona": "Staff Cloud Architect and Lead Systems Engineer",
        "search_query": "{site_name} cloud infrastructure kubernetes serverless devops architecture 2026",
        "seo_query_template": "{topic} architecture best practices implementation guide 2026",
        "community_query": "{topic} production issues migration war stories site:reddit.com/r/devops OR site:news.ycombinator.com",
        "gap_query": "{topic} edge cases failure modes real world bottlenecks tradeoffs",
        "default_audience": "Staff DevOps engineers, site reliability engineers, and cloud architects",
        "formats": ["Reliability Engineering Playbook", "Infrastructure Migration Teardown", "Production Systems Architecture"],
        "fallback_dossier": (
            "- 2026 Cloud Shifts: Platform engineering consolidation; FinOps cost attribution; edge compute runtime migrations.\n"
            "- Engineering Demand: Zero-downtime database migrations, micro-frontends vs monolithic App Routers, distributed tracing.\n"
            "- Architectural Hotspots: SQLite at the edge, serverless cold-start elimination, Terraform to OpenTofu migrations."
        ),
        "guidance": (
            "1. Analyze what architectural blueprint, reliability teardown, or infrastructure migration guide is missing.\n"
            "2. Propose a pragmatic, production-tested technical guide with real config tradeoffs and performance measurements.\n"
            "3. Target audience: Staff engineers, DevOps practitioners, cloud architects, and engineering managers."
        )
    },
    {
        "slug": "finance",
        "pattern": r"\b(finance|financial|invest|investing|investors|stocks|stock market|fintech|wealth|equity|etf|trading|portfolio|macroeconomic|interest rate|yield|inflation|hedge|dividend)\b",
        "niche": "Financial Markets, Fintech Engineering, Quantitative Investment, and Economic Analysis",
        "persona": "Chief Market Strategist and Senior Financial Columnist",
        "search_query": "{site_name} financial markets macroeconomic trends investment strategy 2026",
        "seo_query_template": "{topic} market analysis strategy risk assessment 2026",
        "community_query": "{topic} portfolio strategy risks discussion site:reddit.com/r/investing OR site:reddit.com",
        "gap_query": "{topic} contrarian perspective institutional risks hidden downsides",
        "default_audience": "Institutional investors, financial analysts, and sophisticated capital allocators",
        "formats": ["Macroeconomic Risk Assessment", "Portfolio Strategy Blueprint", "Quantitative Valuation Model"],
        "fallback_dossier": (
            "- 2026 Macro Environment: Central bank liquidity cycles, sovereign bond yield curve shifts, private equity liquidity crunches.\n"
            "- High-Demand Reader Intent: Defensive dividend positioning, quantitative risk parity models, institutional capital flows.\n"
            "- Fintech Shifts: Real-time settlement rails (FedNow, SEPA Instant), tokenized treasury bills, automated algorithmic portfolio balancing."
        ),
        "guidance": (
            "1. Analyze what macroeconomic breakdown, portfolio strategy, or fintech infrastructure analysis is missing.\n"
            "2. Propose an authoritative, data-backed market analysis with clear risk/reward frameworks.\n"
            "3. Forbid get-rich-quick schemes, penny stocks, or ungrounded hype. Focus on institutional-grade financial insight."
        )
    },
    {
        "slug": "crypto",
        "pattern": r"\b(crypto|cryptocurrency|blockchain|web3|defi|ethereum|solana|bitcoin|nft|tokenomics|layer 2|zero-knowledge|rollup|smart contract|dao|staking)\b",
        "niche": "Blockchain Architecture, Web3 Infrastructure, Decentralized Finance (DeFi), and Cryptoeconomics",
        "persona": "Lead Web3 Protocol Researcher and Cryptoeconomics Analyst",
        "search_query": "{site_name} crypto blockchain web3 defi protocol developments 2026",
        "seo_query_template": "{topic} protocol mechanics security audit tokenomics 2026",
        "community_query": "{topic} security attack vectors mechanics site:reddit.com/r/ethereum OR site:reddit.com",
        "gap_query": "{topic} economic vulnerabilities attack vectors protocol tradeoffs",
        "default_audience": "Web3 protocol engineers, cryptoeconomic researchers, and DeFi builders",
        "formats": ["Protocol Architecture Teardown", "Cryptoeconomic Risk Audit", "Smart Contract Security Analysis"],
        "fallback_dossier": (
            "- 2026 Web3 Landscape: ZK-rollup scaling maturation; restaking protocol risk models; institutional tokenization of real-world assets (RWA).\n"
            "- Developer Demand: Cross-chain intent solvers, account abstraction UX improvements, MEV mitigation strategies.\n"
            "- Protocol Debates: Monolithic high-throughput chains vs modular execution environments."
        ),
        "guidance": (
            "1. Propose an objective, protocol-level deep-dive or cryptoeconomic risk analysis.\n"
            "2. Forbid meme coin promotions or speculative price predictions. Focus on cryptographic engineering, liquidity dynamics, and protocol mechanics."
        )
    },
    {
        "slug": "health",
        "pattern": r"\b(health|fitness|workout|nutrition|diet|longevity|wellness|cardio|strength training|biomarkers|sleep|hypertrophy|metabolism|gut microbiome|recovery|mobility)\b",
        "niche": "Health Science, Athletic Performance, Clinical Nutrition, and Longevity Technology",
        "persona": "Sports Science Physiologist and Clinical Nutrition Researcher",
        "search_query": "{site_name} health fitness longevity nutrition research performance 2026",
        "seo_query_template": "{topic} protocol clinical research physiological mechanism 2026",
        "community_query": "{topic} protocol results evidence discussion site:reddit.com/r/AdvancedFitness OR site:reddit.com",
        "gap_query": "{topic} physiological mechanisms common mistakes protocol pitfalls",
        "default_audience": "Performance athletes, biohackers, and evidence-based longevity practitioners",
        "formats": ["Evidence-Based Clinical Protocol", "Physiological Mechanism Teardown", "Biomarker Optimization Blueprint"],
        "fallback_dossier": (
            "- 2026 Health Science: Continuous biomarker monitoring (glucose, lactate); zone-2 mitochondrial biogenesis training protocols.\n"
            "- High-Demand Reader Intent: Periodized strength training for longevity, sleep architecture optimization, gut microbiome diversity.\n"
            "- Nutrition Trends: Whole-food protein pacing, micronutrient bioavailability, chrononutrition meal timing."
        ),
        "guidance": (
            "1. Analyze what evidence-based training protocol, nutritional guide, or longevity science breakdown is missing.\n"
            "2. Forbid bro-science, fad diets, and miracle cure claims. Cite physiological mechanisms and actionable protocols."
        )
    },
    {
        "slug": "security",
        "pattern": r"\b(cybersecurity|infosec|pentest|penetration testing|malware|vulnerability|zero-day|threat intel|ransomware|siem|soc|zero trust|phishing|exploit|firewall|cve)\b",
        "niche": "Cybersecurity, Threat Intelligence, Application Security, and Penetration Testing",
        "persona": "Principal Security Researcher and Threat Intelligence Director",
        "search_query": "{site_name} cybersecurity threat intelligence vulnerabilities defense 2026",
        "seo_query_template": "{topic} vulnerability analysis mitigation threat intelligence 2026",
        "community_query": "{topic} exploit detection bypass mitigation site:reddit.com/r/netsec OR site:news.ycombinator.com",
        "gap_query": "{topic} bypass techniques detection blindspots real world exploit analysis",
        "default_audience": "Security engineers, SOC analysts, and penetration testers",
        "formats": ["Threat Intelligence Briefing", "Vulnerability Root-Cause Teardown", "Defensive Hardening Playbook"],
        "fallback_dossier": (
            "- 2026 Security Vector: AI-generated spear-phishing payloads; software supply chain dependency poisoning.\n"
            "- SecOps Intent: Zero Trust lateral movement defense, automated CVE triage, eBPF-based kernel observability.\n"
            "- Threat Trends: Cloud IAM privilege escalation pathways, memory-safe language migrations (Rust for system services)."
        ),
        "guidance": (
            "1. Propose an authoritative vulnerability teardown, threat modeling guide, or defensive architecture blueprint.\n"
            "2. Focus on defensive hardening, forensic analysis, and enterprise security posture."
        )
    },
    {
        "slug": "travel",
        "pattern": r"\b(travel|destination|itinerary|hotel|flight|wanderlust|backpacking|tourism|adventure|road trip|culture|heritage|local guide|scenic|nomad)\b",
        "niche": "Travel Journalism, Destination Masterclasses, Cultural Expeditions, and Experiential Tourism",
        "persona": "Senior Travel Journalist and Cultural Expedition Columnist",
        "search_query": "{site_name} travel destination guides itineraries culture expeditions 2026",
        "seo_query_template": "{topic} itinerary travel guide local secrets logistics 2026",
        "community_query": "{topic} recommendations hidden gems pitfalls site:reddit.com/r/travel",
        "gap_query": "{topic} tourist traps local secrets timing logistical pitfalls what guides miss",
        "default_audience": "Curious travelers, experiential explorers, and independent adventurers",
        "formats": ["Immersive Cultural Itinerary", "Off-the-Beaten-Path Expedition Guide", "Curated Regional Field Guide"],
        "fallback_dossier": (
            "- 2026 Travel Trends: Slow overland train travel, regional culinary immersion, lesser-known micro-destinations.\n"
            "- High-Demand Intent: Complete 7-day immersive itineraries, seasonal crowd mitigation tips, cultural etiquette deep-dives."
        ),
        "guidance": (
            "1. Propose an immersive travel essay or curated regional itinerary with authentic local experiences.\n"
            "2. Focus on evocative scene-setting, practical logistics, and off-the-beaten-path cultural insights."
        )
    },
    {
        "slug": "design",
        "pattern": r"\b(design|ui|ux|typography|visual|layout|branding|aesthetic|figma|css|animation|creative|graphic design|design systems|color palette)\b",
        "niche": "Design Craft, Digital Typography, Design Systems, and Aesthetic Interface Engineering",
        "persona": "Design Director and Creative Craftsman",
        "search_query": "{site_name} digital design systems UI UX typography craft trends 2026",
        "seo_query_template": "{topic} design system UI UX typography craft architecture 2026",
        "community_query": "{topic} UI UX critique design systems site:reddit.com/r/web_design OR site:reddit.com/r/UXDesign",
        "gap_query": "{topic} usability pitfalls contrast accessibility design tokens edge cases",
        "default_audience": "Product designers, design system engineers, and creative directors",
        "formats": ["Design System Architecture Guide", "Typographic Craft Masterclass", "Interface Usability Teardown"],
        "fallback_dossier": (
            "- 2026 Design Shifts: Moving away from sterile corporate minimalist SaaS toward tactile, editorial, high-contrast aesthetics.\n"
            "- Designer Intent: Mastering variable typography, micro-interactions, dark mode color science, and fluid spacing tokens."
        ),
        "guidance": (
            "1. Propose an in-depth design critique, typographic masterclass, or UI architecture guide.\n"
            "2. Emphasize visual hierarchy, tactile delight, editorial craft, and anti-slop design principles."
        )
    },
    {
        "slug": "ecommerce",
        "pattern": r"\b(ecommerce|e-commerce|shopify|dtc|retail|store|inventory|checkout|conversion|merchandising|shipping|fulfillment|brands)\b",
        "niche": "E-Commerce Strategy, Direct-to-Consumer Growth, Merchandising, and Retail Operations",
        "persona": "Head of E-Commerce Growth and Retail Operations Strategist",
        "search_query": "{site_name} ecommerce direct to consumer retail strategies conversion 2026",
        "seo_query_template": "{topic} conversion optimization retention metrics DTC strategy 2026",
        "community_query": "{topic} conversion bottlenecks retention strategy site:reddit.com/r/ecommerce",
        "gap_query": "{topic} checkout friction retention bottlenecks unit economics what playbooks miss",
        "default_audience": "E-commerce operators, growth engineers, and DTC brand founders",
        "formats": ["Conversion Rate Optimization Playbook", "DTC Unit Economics Blueprint", "Retention Engine Architecture"],
        "fallback_dossier": (
            "- 2026 E-Commerce Shifts: Post-cookie customer acquisition; retention through VIP memberships; unified headless checkouts."
        ),
        "guidance": (
            "1. Propose an actionable e-commerce playbook covering checkout optimization, retention loops, or supply chain resilience."
        )
    },
    {
        "slug": "science",
        "pattern": r"\b(science|physics|astronomy|space|biology|chemistry|quantum|energy|climate|aerospace|genetics|evolution|research|laboratory)\b",
        "niche": "Scientific Inquiry, Space Exploration, Deep Tech, and Fundamental Research",
        "persona": "Senior Science Editor and Deep Technology Researcher",
        "search_query": "{site_name} science space exploration deep tech breakthroughs 2026",
        "seo_query_template": "{topic} scientific breakthrough mechanisms empirical data 2026",
        "community_query": "{topic} experimental findings research questions site:reddit.com/r/science",
        "gap_query": "{topic} experimental challenges open questions mathematical proof limitations",
        "default_audience": "Researchers, scientific thinkers, and deep-technology leaders",
        "formats": ["Mechanism Explainer & Teardown", "Empirical Research Synthesis", "Deep Tech Frontier Analysis"],
        "fallback_dossier": (
            "- 2026 Science Highlights: Fusion energy net-gain engineering; next-generation orbital telescope discoveries; clean hydrogen catalysts."
        ),
        "guidance": (
            "1. Propose a rigorous scientific explainer breaking down complex mechanisms with clarity and wonder."
        )
    }
]


def get_archetype_for_niche(niche_slug: Optional[str] = None, fallback_text: str = "") -> Dict[str, Any]:
    """
    Returns the matching editorial archetype for a given niche slug or text signals.
    Provides domain-specific search templates, community search patterns, personas, and guidance.
    """
    if niche_slug:
        slug_clean = niche_slug.lower().strip()
        for arch in EDITORIAL_ARCHETYPES:
            if arch["slug"] == slug_clean:
                return arch

    # Fallback to pattern matching on provided text
    if fallback_text:
        text_lower = fallback_text.lower()
        best_arch = None
        best_score = 0
        for arch in EDITORIAL_ARCHETYPES:
            matches = re.findall(arch["pattern"], text_lower, re.IGNORECASE)
            if len(matches) > best_score:
                best_score = len(matches)
                best_arch = arch
        if best_arch and best_score >= 1:
            return best_arch

    # General archetype default
    return {
        "slug": "general",
        "niche": "Authoritative Industry Journalism, Practical Guides, and In-Depth Insights",
        "persona": "Chief Content Officer and Head of SEO Strategy",
        "search_query": "{site_name} trending questions developments 2026",
        "seo_query_template": "{topic} comprehensive guide best practices insights 2026",
        "community_query": "{topic} practical problems questions discussion site:reddit.com",
        "gap_query": "{topic} common misconceptions practical nuance what guides miss",
        "default_audience": "Discerning practitioners, enthusiasts, and active readers",
        "formats": ["Comprehensive Field Guide", "In-Depth Practical Masterclass", "Strategic Industry Analysis"],
        "fallback_dossier": (
            "- Emerging 2026 Themes: Cross-functional efficiency, pragmatic workflows, audience-first editorial value.\n"
            "- High-Demand Reader Intent: Deep practical frameworks, avoiding generic fluff, actionable step-by-step guidance."
        ),
        "guidance": (
            "1. Autonomously analyze what authoritative content gap is missing from this publication in its niche.\n"
            "2. Propose a high-intent, compelling headline that provides genuine Information Gain.\n"
            "3. Define 4-6 primary and long-tail SEO keywords.\n"
            "4. Specify the exact reader persona."
        )
    }


def clean_slug_to_title(slug: str) -> str:
    """Converts a URL slug (e.g. 'silky-black-truffle-tagliatelle') to a readable title string."""
    clean = slug.strip("/").split("/")[-1]
    clean = re.sub(r"[?#].*$", "", clean)
    parts = clean.split("-")
    words = [w for w in parts if w]
    return " ".join(words).title()


def _scrape_website_context_uncached(site: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Exhaustively scrapes the target website to discover:
    1. Real page title, OpenGraph branding, and meta description.
    2. Comprehensive list of existing articles/recipes published on the site
       (via HTML scraping, JSON-LD Recipe/Article schemas, RSS/Atom, Sitemap, and API routes).
    3. Multi-domain editorial niche scoring (using word-boundary regexes, never substring collisions).
    4. Local workspace content/posts files if this website maps to a local directory.
    5. Database history of past runs and posts published specifically for this website.
    """
    if not site:
        site = get_default_website()

    site_name = (site.get("name") or "Editorial Publication").strip() if site else "Editorial Publication"
    site_url = str(site.get("url", "")).strip() if site else ""
    site_id = site.get("id") if site else None

    # Derive base URL by stripping /api/posts or similar
    base_url = re.sub(r"/api(/.*)?$", "", site_url).rstrip("/")
    if base_url and not base_url.startswith("http://") and not base_url.startswith("https://"):
        base_url = f"https://{base_url}"

    existing_titles: Set[str] = set()
    categories: Set[str] = set()
    site_meta_title = ""
    site_meta_desc = ""

    # =========================================================================
    # 1. LIVE WEB SCRAPING (HTML, JSON-LD, RSS, Sitemap, API Routes)
    # =========================================================================
    if base_url:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/126.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }

        # A. Probe Multi-Channel HTML Pages
        probe_pages = [
            base_url,
            f"{base_url}/posts",
            f"{base_url}/recipes",
            f"{base_url}/blog",
            f"{base_url}/articles",
            f"{base_url}/dishes",
            f"{base_url}/essays",
            f"{base_url}/reviews",
            f"{base_url}/news",
            f"{base_url}/guides",
        ]

        successful_probes = 0
        for probe_url in probe_pages:
            if successful_probes >= 5 or len(existing_titles) >= 40:
                break
            try:
                with httpx.Client(timeout=6.0, follow_redirects=True) as client:
                    res = client.get(probe_url, headers=headers)
                    if res.status_code != 200 or not res.text:
                        continue
                    successful_probes += 1
                    soup = BeautifulSoup(res.text, "html.parser")

                    # Extract site title from homepage
                    if not site_meta_title:
                        if soup.title and soup.title.string:
                            site_meta_title = soup.title.string.strip()
                        og_site = soup.find("meta", property="og:site_name")
                        if og_site and og_site.get("content"):
                            site_meta_title = og_site["content"].strip()

                    # Extract site description
                    if not site_meta_desc:
                        for meta_attr in [
                            {"name": "description"},
                            {"property": "og:description"},
                            {"name": "twitter:description"},
                        ]:
                            m = soup.find("meta", attrs=meta_attr)
                            if m and m.get("content"):
                                site_meta_desc = m["content"].strip()
                                break

                    # Extract JSON-LD structured schemas (Recipes, Articles, BlogPosting, HowTo)
                    for ld_tag in soup.find_all("script", type="application/ld+json"):
                        try:
                            ld_content = json.loads(ld_tag.string or "{}")
                            ld_items = ld_content if isinstance(ld_content, list) else [ld_content]
                            for item in ld_items:
                                item_type = item.get("@type", "")
                                if isinstance(item_type, list):
                                    item_type = item_type[0] if item_type else ""
                                
                                supported_schemas = [
                                    "Recipe", "Article", "BlogPosting", "NewsArticle",
                                    "TechArticle", "HowTo", "Review", "Product"
                                ]
                                if item_type in supported_schemas:
                                    h = item.get("headline") or item.get("name")
                                    if h and len(h) > 5 and h.lower() not in GENERIC_DISCARD:
                                        existing_titles.add(html.unescape(h).strip())
                                    if item.get("recipeCategory"):
                                        cat = item.get("recipeCategory")
                                        if isinstance(cat, list):
                                            categories.update(str(c).strip() for c in cat if c)
                                        elif isinstance(cat, str):
                                            categories.add(cat.strip())
                                elif item.get("itemListElement"):
                                    for sub in item.get("itemListElement", []):
                                        sub_name = sub.get("name") or (sub.get("item", {}) or {}).get("name")
                                        if sub_name and len(sub_name) > 5 and sub_name.lower() not in GENERIC_DISCARD:
                                            existing_titles.add(html.unescape(sub_name).strip())
                        except Exception:
                            pass

                    # Extract article and recipe titles from card elements
                    for art in soup.find_all(["article", "section", "div"]):
                        card_classes = " ".join(art.get("class", [])) if art.get("class") else ""
                        if any(c in card_classes.lower() for c in ["card", "post", "article", "story", "recipe"]):
                            h = art.find(["h1", "h2", "h3", "h4"])
                            if h:
                                t = h.get_text(" ", strip=True)
                                if len(t) > 5 and t.lower() not in GENERIC_DISCARD:
                                    existing_titles.add(html.unescape(t).strip())

                    # Extract titles from internal links
                    for a in soup.find_all("a", href=True):
                        href = a["href"]
                        match = re.search(
                            r"/(?:posts|blog|article|articles|essays|reviews|guides|recipes|recipe|stories|dishes)/([^/?#]+)",
                            href,
                            re.IGNORECASE
                        )
                        if match:
                            slug = match.group(1)
                            h = a.find(["h1", "h2", "h3", "h4", "span"])
                            if h:
                                link_h = h.get_text(" ", strip=True)
                                if (
                                    len(link_h) > 5 and
                                    not re.match(r"^\d+$", link_h) and
                                    not re.match(r"^\d{1,2}:\d{2}$", link_h) and
                                    link_h.lower() not in GENERIC_DISCARD
                                ):
                                    existing_titles.add(html.unescape(link_h).strip())
                            
                            # Fallback: extract title directly from slug
                            slug_title = clean_slug_to_title(slug)
                            if len(slug_title.split()) >= 2 and slug_title.lower() not in GENERIC_DISCARD:
                                existing_titles.add(slug_title)

                    # Extract category tags / pills
                    for tag_el in soup.find_all(class_=re.compile(r"(?:pill|tag|category|badge|chip|cat)", re.I)):
                        txt = tag_el.get_text(strip=True)
                        if 2 < len(txt) < 30 and not any(skip in txt.lower() for skip in ["read", "min", "new", "hot", "view", "all", "total", "reviews"]):
                            categories.add(txt)

                    meta_kw = soup.find("meta", attrs={"name": "keywords"})
                    if meta_kw and meta_kw.get("content"):
                        for kw in meta_kw["content"].split(","):
                            if kw.strip():
                                categories.add(kw.strip())

            except Exception as e:
                logger.debug(f"Live HTML scrape failed for {probe_url}: {e}")

        # B. Probe Next.js JSON API Route (/api/posts)
        try:
            with httpx.Client(timeout=5.0, follow_redirects=True) as client:
                api_res = client.get(f"{base_url}/api/posts", headers={"Accept": "application/json"})
                if api_res.status_code == 200:
                    api_json = api_res.json()
                    if isinstance(api_json, list):
                        for p in api_json:
                            if isinstance(p, dict) and p.get("title"):
                                existing_titles.add(str(p["title"]).strip())
        except Exception:
            pass

        # C. Probe RSS / Atom Feeds
        feed_candidates = [
            f"{base_url}/feed.xml",
            f"{base_url}/rss.xml",
            f"{base_url}/atom.xml",
            f"{base_url}/feed",
            f"{base_url}/rss",
        ]
        for feed_url in feed_candidates:
            if len(existing_titles) >= 40:
                break
            try:
                with httpx.Client(timeout=5.0, follow_redirects=True) as client:
                    res = client.get(feed_url, headers=headers)
                    if res.status_code == 200 and ("<rss" in res.text or "<feed" in res.text or "<channel" in res.text):
                        try:
                            root = ET.fromstring(res.text)
                            for el in root.iter():
                                tag_name = el.tag.split("}")[-1].lower()
                                if tag_name == "title" and el.text:
                                    t = el.text.strip()
                                    if len(t) > 5 and t.lower() not in GENERIC_DISCARD:
                                        existing_titles.add(html.unescape(t).strip())
                        except Exception:
                            matches = re.findall(r"<title[^>]*>(.*?)</title>", res.text, re.IGNORECASE | re.DOTALL)
                            for m in matches[1:]:
                                clean_t = html.unescape(re.sub(r"<[^>]+>", "", m)).strip()
                                if len(clean_t) > 5 and clean_t.lower() not in GENERIC_DISCARD:
                                    existing_titles.add(clean_t)
                        break
            except Exception:
                pass

        # D. Probe Sitemap XML
        try:
            with httpx.Client(timeout=5.0, follow_redirects=True) as client:
                res = client.get(f"{base_url}/sitemap.xml", headers=headers)
                if res.status_code == 200 and "<urlset" in res.text:
                    locs = re.findall(r"<loc>(.*?)</loc>", res.text, re.IGNORECASE)
                    for loc in locs:
                        match = re.search(r"/(?:posts|blog|article|articles|essays|recipes|recipe)/([^/?#]+)", loc, re.IGNORECASE)
                        if match:
                            st = clean_slug_to_title(match.group(1))
                            if len(st.split()) >= 2 and st.lower() not in GENERIC_DISCARD:
                                existing_titles.add(st)
        except Exception:
            pass

    # =========================================================================
    # 2. LOCAL WORKSPACE AND SIBLING FOLDERS INSPECTION
    # =========================================================================
    try:
        from config import BASE_DIR
        candidate_dirs = [BASE_DIR]
        # Include parent directories to detect sibling sites (e.g. gaming-editorial or blog web)
        try:
            candidate_dirs.extend([p for p in BASE_DIR.parent.iterdir() if p.is_dir()])
        except Exception:
            pass

        site_name_clean = site_name.lower().strip()
        site_slug = re.sub(r"[^a-z0-9]+", "", site_name_clean)
        for item in candidate_dirs:
            dir_name = item.name.lower()
            # Only match directories explicitly tied to this website's name or domain
            is_relevant_folder = False
            if site_slug and len(site_slug) >= 3 and (site_slug in dir_name or dir_name in site_slug):
                is_relevant_folder = True
            elif dir_name in site_name_clean and len(dir_name) >= 4:
                is_relevant_folder = True
            elif base_url and len(dir_name) >= 4 and dir_name in base_url.lower():
                is_relevant_folder = True
            if is_relevant_folder:
                # 1. Inspect content/posts/
                posts_dir = item / "content" / "posts"
                if posts_dir.exists():
                    for p_file in posts_dir.glob("*.json"):
                        try:
                            p_data = json.loads(p_file.read_text(encoding="utf-8"))
                            if p_data.get("title") and p_data["title"].lower() not in GENERIC_DISCARD:
                                existing_titles.add(str(p_data["title"]).strip())
                            if p_data.get("tags"):
                                raw_tags = p_data["tags"]
                                if isinstance(raw_tags, list):
                                    categories.update(str(t).strip() for t in raw_tags if str(t).strip())
                                elif isinstance(raw_tags, str):
                                    categories.update(t.strip() for t in raw_tags.split(",") if t.strip())
                        except Exception:
                            pass

                # 2. Inspect data/recipes.js or data/posts.js if present
                for data_cand in [item / "data" / "recipes.js", item / "src" / "data" / "recipes.js"]:
                    if data_cand.exists():
                        try:
                            text_data = data_cand.read_text(encoding="utf-8")
                            matches = re.findall(r'title:\s*["\'](.*?)["\']', text_data)
                            for tm in matches:
                                if len(tm) > 5 and tm.lower() not in GENERIC_DISCARD:
                                    existing_titles.add(tm.strip())
                        except Exception:
                            pass
    except Exception as local_err:
        logger.debug(f"Local content inspection notice: {local_err}")

    # =========================================================================
    # 3. DATABASE HISTORY INSPECTION (Scoped to THIS website)
    # =========================================================================
    try:
        db_titles = get_published_topics_by_website(site_id)
        for t in db_titles:
            if t and t.lower() not in GENERIC_DISCARD:
                existing_titles.add(t.strip())
    except Exception as db_err:
        logger.debug(f"Database history lookup notice: {db_err}")

    # =========================================================================
    # 4. CLEAN AND DEDUPLICATE EXISTING TITLES
    # =========================================================================
    filtered_titles: List[str] = []
    seen_lower = set()
    for t in sorted(existing_titles):
        clean_t = re.sub(r"\s+", " ", t).strip()
        k = clean_t.lower()
        if len(clean_t) >= 5 and k not in GENERIC_DISCARD and k not in seen_lower:
            seen_lower.add(k)
            filtered_titles.append(clean_t)

    # =========================================================================
    # 5. MULTI-DOMAIN EDITORIAL NICHE SYNTHESIS (Word-Boundary Scored)
    # =========================================================================
    combined_signals = (
        f"{site_name} {site_meta_title} {site_meta_desc} "
        f"{' '.join(categories)} {' '.join(filtered_titles[:10])}"
    ).lower()

    best_archetype = None
    best_score = 0

    for arch in EDITORIAL_ARCHETYPES:
        matches = re.findall(arch["pattern"], combined_signals, re.IGNORECASE)
        score = len(matches)
        if score > best_score:
            best_score = score
            best_archetype = arch

    if best_score >= 1 and best_archetype:
        inferred_niche = best_archetype["niche"]
        niche_slug = best_archetype["slug"]
        archetype_obj = best_archetype
    else:
        # Dynamic fallback: build directly from site name and meta description
        clean_name = site_meta_title or site_name
        inferred_niche = f"{clean_name} — High-Intent Industry Coverage, Practical Guides, and In-Depth Insights"
        niche_slug = "general"
        archetype_obj = {
            "slug": "general",
            "niche": inferred_niche,
            "persona": "Chief Content Officer and Head of SEO Strategy",
            "search_query": f"{site_name} trending questions developments 2026",
            "fallback_dossier": (
                "- Emerging 2026 Themes: Cross-functional efficiency, pragmatic workflows, audience-first editorial value.\n"
                "- High-Demand Reader Intent: Deep practical frameworks, avoiding generic fluff, actionable step-by-step guidance."
            ),
            "guidance": (
                "1. Autonomously analyze what authoritative content gap is missing from this publication in its niche.\n"
                "2. Propose a high-intent, compelling headline that provides genuine Information Gain.\n"
                "3. Define 4-6 primary and long-tail SEO keywords.\n"
                "4. Specify the exact reader persona."
            )
        }

    # 6. Detect the matching Editorial Design Archetype (out of the 36 master archetypes)
    design_arch = detect_editorial_archetype(
        site_name=site_name,
        site_desc=site_meta_desc,
        categories=sorted(list(categories)),
        titles=filtered_titles,
        fallback_niche=inferred_niche
    )

    return {
        "site_name": site_name,
        "site_url": site_url,
        "base_url": base_url,
        "site_title": site_meta_title or site_name,
        "site_desc": site_meta_desc,
        "editorial_niche": inferred_niche,
        "niche_slug": niche_slug,
        "archetype": archetype_obj,
        "editorial_archetype": design_arch["slug"],
        "design_guide": design_arch,
        "categories": sorted(list(categories))[:10],
        "existing_articles": filtered_titles
    }


# One run scrapes the same site several times (custom-topic dedupe plus each
# topic-discovery retry) with identical results; cache the evidence briefly so
# one run performs one scrape. Deep-copied so callers can mutate their copy.
_SCRAPE_CACHE_TTL_SECONDS = 90
_scrape_cache: Dict[str, Any] = {}
_scrape_cache_lock = threading.Lock()


def scrape_website_context(site: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Returns the website's scrape context, reusing a recent scrape when available."""
    cache_key = ""
    if site:
        cache_key = str(site.get("id") or site.get("url") or "")
    if cache_key:
        with _scrape_cache_lock:
            cached = _scrape_cache.get(cache_key)
        if cached and (time.time() - cached[0]) < _SCRAPE_CACHE_TTL_SECONDS:
            logger.debug(f"Using cached website scrape for '{cache_key}'.")
            return copy.deepcopy(cached[1])

    ctx = _scrape_website_context_uncached(site)
    if cache_key:
        with _scrape_cache_lock:
            _scrape_cache[cache_key] = (time.time(), copy.deepcopy(ctx))
    return ctx


def autonomous_discover_topic(
    website_id: Optional[str] = None,
    site_obj: Optional[Dict[str, Any]] = None,
    exclude_titles: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Autonomously researches the target website's editorial niche, past published dispatches,
    and trending search demand to select a high-intent, publication-grade topic with unique Information Gain.
    Extracts high-ranking keywords, content format, hook angle, and target audience profile.

    exclude_titles: extra headlines the proposal must avoid (e.g. titles fetched
    live from the target website or rejected duplicates from earlier attempts).
    """
    site = site_obj or (get_website_by_id(website_id) if website_id else None)
    if not site:
        site = get_default_website()

    ctx = scrape_website_context(site)
    site_name = ctx["site_name"]
    site_url = ctx["base_url"] or ctx["site_url"]
    editorial_niche = ctx["editorial_niche"]
    archetype = ctx.get("archetype", {})
    site_title = ctx["site_title"]
    site_desc = ctx["site_desc"]

    # Combine existing articles from scraping with explicit exclusions
    all_past_titles = list(ctx["existing_articles"])
    all_past_titles.extend(exclude_titles or [])

    # Dedupe case-insensitively while preserving order
    seen = set()
    unique_past = []
    for t in all_past_titles:
        k = t.lower().strip()
        if k not in seen:
            seen.add(k)
            unique_past.append(t)
    all_past_titles = unique_past

    past_topics_summary = (
        "\n".join([f"- {t}" for t in all_past_titles])
        if all_past_titles
        else "No previous articles found on the website."
    )

    # 1. Search Angle: Gather live web intelligence on trending topics in THIS specific niche
    primary_domain = editorial_niche.split(",")[0].strip()
    search_query_template = archetype.get("search_query") or "{site_name} {primary_domain} trending topics 2026"
    search_query = search_query_template.format(site_name=site_name, primary_domain=primary_domain)

    tavily_data = fetch_tavily_intelligence(search_query, max_results=3, search_depth="basic")
    snippets = [r.get("content", "")[:280] for r in tavily_data.get("results", []) if r.get("content")]
    
    if snippets:
        dossier = "\n".join(snippets)
    else:
        dossier = archetype.get("fallback_dossier") or "Emerging 2026 trends focusing on practical craft and reader value."

    system_instruction = (
        f"You are an expert {archetype.get('persona', 'Chief Content Officer and Head of SEO Strategy')}. "
        f"Analyze the target website's brand identity, category coverage, and list of existing articles already on the site. "
        f"Propose a single high-intent, authoritative article topic that solves a real 2026 reader need, delivers high Information Gain, "
        f"and is COMPLETELY MISSING from this website. "
        f"Return a strict JSON object with 'topic', 'content_format', 'angle_or_hook', 'reasoning', 'keywords', 'target_audience', 'editorial_pillars', and 'estimated_read_time'."
    )

    task_guidance = archetype.get("guidance", "Propose an authoritative, high-intent topic tailored to this publication.")

    design_guide = ctx.get("design_guide") or detect_editorial_archetype(site_name=site_name, fallback_niche=editorial_niche)

    prompt = f"""Target Website: {site_name} ({site_url})
Website Identity & Meta: {site_title} — {site_desc}
Editorial Niche: {editorial_niche}
Editorial Design Archetype: #{design_guide.get('id', 28)} {design_guide.get('name', 'Contemporary Editorial')}
Aesthetic & Narrative Mood: {design_guide.get('feeling', '')}
Visual & Pacing Identity: {design_guide.get('characteristics', '')}
Categories Covered: {", ".join(ctx["categories"]) if ctx["categories"] else "General"}

Existing Articles / Content Already Implemented on Website (DO NOT duplicate or rewrite these):
{past_topics_summary}

Search Intelligence Dossier (Real 2026 Trends & Intent):
\"\"\"{dossier}\"\"\"

Task:
{task_guidance}

CRITICAL RULES:
- Do NOT propose generic, cookie-cutter AI slop. Infuse genuine craft, pro secrets, and specific techniques.
- Do NOT duplicate, rehash, or copy any of the existing articles listed above.
- The keywords MUST be specific to this article and niche, not generic placeholders.

Return a valid JSON object formatted EXACTLY as:
{{
  "topic": "Specific, authoritative, publication-ready headline or recipe title",
  "content_format": "Editorial format (e.g. Artisanal Recipe Guide, Systems Architecture Teardown, Practical Masterclass)",
  "angle_or_hook": "The unique Information Gain angle or pro secret that sets this piece apart",
  "information_gain_score": 94,
  "reasoning": "1-2 sentence explanation of why this topic is in high search demand right now and fills a gap on this website",
  "keywords": ["Primary high-ranking keyword", "3 to 5 long-tail high-intent keyword variations"],
  "target_audience": "Specific reader persona actively searching for this topic",
  "editorial_pillars": ["Core section 1", "Core section 2", "Core section 3"],
  "estimated_read_time": "Estimated read or cooking time (e.g. 12 MIN READ or 35 MINS TOTAL)"
}}
"""

    logger.info(f"Agent researching autonomous topic proposal for website '{site_name}' (niche: {editorial_niche}, design: {design_guide.get('slug')})...")
    raw_response = call_llm(prompt=prompt, system_instruction=system_instruction, temperature=0.75)

    data = extract_json_block(raw_response)
    if data and data.get("topic"):
        topic = str(data.get("topic")).strip()
        reasoning = str(data.get("reasoning") or "Identified high search volume and emerging niche demand.").strip()
        raw_kws = data.get("keywords") or []
        if isinstance(raw_kws, list):
            keywords = [str(k).strip() for k in raw_kws if str(k).strip()]
        elif isinstance(raw_kws, str):
            keywords = [k.strip() for k in raw_kws.split(",") if k.strip()]
        else:
            keywords = []
        target_audience = str(data.get("target_audience") or f"Core audience and readers of {site_name}").strip()

        try:
            ig_score = int(data.get("information_gain_score") or 92)
            ig_score = max(80, min(99, ig_score))
        except (ValueError, TypeError):
            ig_score = 92

        return {
            "topic": topic,
            "content_format": str(data.get("content_format") or "Authoritative Editorial Guide").strip(),
            "angle_or_hook": str(data.get("angle_or_hook") or "").strip(),
            "information_gain_score": ig_score,
            "reasoning": reasoning,
            "keywords": keywords,
            "target_audience": target_audience,
            "editorial_pillars": data.get("editorial_pillars") or [],
            "estimated_read_time": str(data.get("estimated_read_time") or "10 MIN READ").strip(),
            "site_niche": editorial_niche,
            "niche_slug": ctx.get("niche_slug", "general"),
            "editorial_persona": archetype.get("persona", "Chief Content Officer"),
            "editorial_archetype": ctx.get("editorial_archetype", "contemporary_editorial"),
            "design_guide": ctx.get("design_guide", {}),
            "existing_articles_count": len(all_past_titles)
        }
    else:
        logger.warning(f"Could not parse autonomous topic discovery JSON for '{site_name}'. Generating dynamic niche topic.")
        return {
            "topic": f"The 2026 Masterclass in {primary_domain}: Essential Techniques & Modern Standards",
            "content_format": "Comprehensive Field Guide",
            "angle_or_hook": f"Actionable masterclass tailored to the editorial voice of {site_name}.",
            "reasoning": f"High-demand emerging topic tailored specifically to {site_name}'s coverage of {primary_domain}.",
            "keywords": [primary_domain, f"{primary_domain} 2026", "Step-by-Step Guide", "Professional Techniques"],
            "target_audience": f"Enthusiasts, practitioners, and core readers of {site_name}",
            "editorial_pillars": ["Foundations & Setup", "Core Execution & Techniques", "Mastery & Common Pitfalls"],
            "estimated_read_time": "12 MIN READ",
            "site_niche": editorial_niche,
            "niche_slug": ctx.get("niche_slug", "general"),
            "existing_articles_count": len(all_past_titles)
        }


def discover_unique_topic(
    website_id: Optional[str] = None,
    site_obj: Optional[Dict[str, Any]] = None,
    max_attempts: int = MAX_DISCOVERY_ATTEMPTS,
) -> Dict[str, Any]:
    """
    Topic discovery with a duplicate guard: after each LLM proposal, the topic is
    similarity-checked against BOTH the local archive and the target website's
    live scraped article list. Near-duplicates (>= DUPLICATE_TOPIC_THRESHOLD) are rejected
    and the agent proposes a new topic, up to max_attempts. The rejected attempts
    are fed back as exclusion context so each retry avoids what came before.
    """
    site = site_obj or (get_website_by_id(website_id) if website_id else None)
    if not site:
        site = get_default_website()

    # Scrape website intelligence first to get all existing titles
    ctx = scrape_website_context(site)
    blocked_titles = list(ctx["existing_articles"])

    proposal: Dict[str, Any] = {}
    for attempt in range(1, max_attempts + 1):
        proposal = autonomous_discover_topic(
            website_id=website_id,
            site_obj=site,
            exclude_titles=blocked_titles if blocked_titles else None,
        )
        topic = (proposal.get("topic") or "").strip()

        duplicate = is_duplicate_topic(topic, blocked_titles, threshold=DUPLICATE_TOPIC_THRESHOLD)
        if duplicate:
            logger.warning(
                f"Attempt {attempt}/{max_attempts}: proposed topic '{topic}' is {duplicate['score']:.0%} similar "
                f"to existing article '{duplicate['title']}'. Rejecting and rediscovering."
            )
            blocked_titles.append(topic)
            continue

        proposal["dedupe"] = {
            "checked_against": len(blocked_titles),
            "attempt": attempt,
        }
        return proposal

    logger.warning(
        f"Topic discovery exhausted {max_attempts} attempts against {len(blocked_titles)} existing titles; "
        "returning last proposal flagged as fallback."
    )
    if proposal:
        proposal["dedupe"] = {
            "checked_against": len(blocked_titles),
            "attempt": max_attempts,
            "fallback": True,
        }
    return proposal


def fetch_remote_site_titles(site: Optional[Dict[str, Any]] = None) -> List[str]:
    """Scrapes the target website and returns existing article headlines."""
    ctx = scrape_website_context(site)
    return ctx.get("existing_articles", [])
